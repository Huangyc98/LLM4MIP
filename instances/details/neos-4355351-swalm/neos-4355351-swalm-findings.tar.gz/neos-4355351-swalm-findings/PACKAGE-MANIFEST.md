# Package manifest: neos-4355351-swalm

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 27
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/exact-solution-audit.txt`
- `artifacts/recovered-structure.json`
- `artifacts/state-steiner.json`
- `artifacts/steiner-relaxation.json`
- `artifacts/structure-summary.json`
- `artifacts/turn-steiner-30s.json`
- `experiments/baseline-copt/summary.json`
- `experiments/baseline-gurobi/gurobi.log`
- `experiments/baseline-gurobi/incumbent.sol`
- `experiments/baseline-gurobi/summary.json`
- `experiments/state-proof-gurobi/gurobi.log`
- `experiments/state-proof-gurobi/incumbent.sol`
- `experiments/state-proof-gurobi/summary.json`
- `reports/optimality-proof.zh.md`
- `scripts/analyze_structure.py`
- `scripts/recover_structure.py`
- `scripts/run_copt.py`
- `scripts/run_gurobi.py`
- `scripts/solve_state_steiner.py`
- `scripts/solve_steiner_relaxation.py`
- `scripts/solve_turn_restricted_steiner.py`
- `solutions/miplib-solution-2.sol`
- `solutions/miplib-solution-2.sol.gz`
- `solutions/state-steiner.sol`
- `solutions/steiner-relaxation.sol`
- `solutions/turn-steiner-30s.sol`

## Excluded files

- `input/neos-4355351-swalm.mps.gz (1435246 bytes; raw benchmark input; sha256 83b5acc7a1c763ef6a397c5b11bff4f8def686d33128de75d0eeb1e7ef95cba0)`
