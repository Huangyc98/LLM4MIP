# `neos-4355351-swalm` — OPT = 33.45763

## Result

**The global optimum of the original MPS is 33.45763.**  The proof does not
rely on a long generic MIP search.  It recovers a four-terminal, forbidden-turn
directed Steiner problem from the anonymous MPS, solves a state-expanded
Steiner relaxation exactly by dynamic programming, and maps the optimum back
to a zero-violation original-MPS witness.

The compressed input has SHA-256
`83b5acc7a1c763ef6a397c5b11bff4f8def686d33128de75d0eeb1e7ef95cba0`.

## Recovered structure

The 21,065 anonymous columns and 21,609 rows reduce as follows.

- The first 555 equalities contain 275 exact duplicate rows.  The remaining
  280 distinct equalities are node balances.
- There are 10,530 nonnegative flow variables and 10,530 paired integer
  activation variables.  Every link row is exactly
  `y_a - 0.25 f_a >= 0`, so an activated arc has capacity four.
- The flow columns encode 10,530 directed arcs.  There are 5,208 physical
  edges with both orientations and 114 terminal-incident edges with one useful
  orientation.
- Five additional continuous columns identify source `R0132` with supply four
  and unit-demand terminals `R0014`, `R0140`, `R0141`, and `R0271`.
- Every one of the 10,524 remaining rows has the form
  `d_a y_a + sum(y_b for b in F(a)) <= d_a`.  For integral variables this is
  exactly the collection of conflicts `y_a + y_b <= 1`.  Deduplication yields
  292,664 conflict pairs: 5,208 forbid the two orientations of one physical
  edge and the other 287,456 forbid consecutive directed turns.  No conflict
  joins two arcs with disjoint endpoints.

Thus an optimum can be taken to be a source-rooted directed arborescence that
reaches the four terminals and avoids every forbidden parent-child turn.

## Lower-bound proof

Create one state for every directed arc, plus an artificial root state.  A
transition from arc `a=(u,v)` to arc `b=(v,w)` is present exactly when the MPS
does not declare `a` and `b` incompatible; entering `b` costs its original MPS
objective coefficient.  The artificial root connects to arcs leaving
`R0132`.  This gives 10,531 states and 125,453 allowed transitions.  Each
terminal is a group consisting of all states whose arc ends at that terminal.

Any feasible original solution contains a directed arborescence reaching all
four terminals: decompose its nonnegative flow into source-terminal paths and
discard cycles and unused activated arcs.  Mapping every arborescence arc to
its state yields a directed Steiner tree in the state graph with the same
cost.  Therefore the state-graph optimum is a valid lower bound for the MPS.

`scripts/solve_state_steiner.py` solves this four-terminal directed Steiner
problem using the exact subset recurrence

```text
D[S,v] = min(
    min over nonempty A proper subset of S: D[A,v] + D[S\A,v],
    min over transitions v->w: cost(v,w) + D[S,w]
)
```

with reverse shortest-path closures.  Every objective coefficient is scaled
by 100,000 and handled as an integer, so this computation has no floating-point
comparison ambiguity.  It returns the lower bound `3,345,763 / 100,000`.

## Matching feasible witness

The recovered optimum uses 15 directed arcs.  It has no duplicate physical
arrival, no selected conflict, and maps directly to a source-rooted tree.  The
subtree terminal counts provide integral flows from one through four on its
arcs.  A separate `Decimal` evaluation of the original compressed MPS reports:

```text
objective=33.45763
rows=21609 exact_row_violations=0 row_violations_above_0.000001=0 max_row_violation=0
bound_violations_above_0.000001=0 exact_integrality_violations=0 integrality_violations_above_0.000001=0 max_integrality_violation=0
```

The state relaxation and original-MPS feasible value coincide, proving
`OPT = 33.45763`.  Gurobi 13.0.1 independently reoptimized the continuous
variables with all 10,530 integer values fixed and also reported objective
33.45763 with zero constraint, bound, and integrality violation.

## Why the MIPLIB headline differs

The MIPLIB page currently displays the starred value `33.45757454008309`.
That number is not on the original objective lattice of `1e-5`.  The site's
solution table reports a `7.7e-6` integrality violation for that candidate.
The site's second solution, and the exact witness here, have objective
33.45763.  The latter is the strict feasible optimum of the archived MPS.

## Reproduction

```sh
python scripts/analyze_structure.py input/neos-4355351-swalm.mps.gz \
  --json artifacts/structure-summary.json --quiet

python scripts/recover_structure.py input/neos-4355351-swalm.mps.gz \
  --solution solutions/miplib-solution-2.sol \
  --json artifacts/recovered-structure.json --quiet

python scripts/solve_state_steiner.py input/neos-4355351-swalm.mps.gz \
  --json artifacts/state-steiner.json \
  --solution solutions/state-steiner.sol

python ../../common/exact_mps_solution_check.py \
  input/neos-4355351-swalm.mps.gz solutions/state-steiner.sol \
  --tolerance 0
```

The key compact artifacts are
[`state-steiner.json`](artifacts/state-steiner.json),
[`state-steiner.sol`](solutions/state-steiner.sol), and
[`exact-solution-audit.txt`](artifacts/exact-solution-audit.txt).
The generic 900-second baselines are retained under `experiments/`: Gurobi
ended with a 31.49% gap and COPT had not found an incumbent.  They document why
the structural reduction, rather than more generic search, closed the case.

- [MIPLIB metadata](https://miplib.zib.de/instance_details_neos-4355351-swalm.html)
