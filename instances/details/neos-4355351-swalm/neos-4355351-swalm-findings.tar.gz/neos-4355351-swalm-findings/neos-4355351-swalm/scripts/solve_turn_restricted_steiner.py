#!/usr/bin/env python3
"""Exact branch-and-bound for the five-terminal Steiner tree with forbidden turns.

Each node relaxation is an exact directed Steiner arborescence solved by the
Dreyfus--Wagner dynamic program.  A violated pairwise conflict y_a+y_b<=1 is
handled by the exhaustive disjunction y_a=0 or y_b=0.
"""

from __future__ import annotations

import argparse
import heapq
import json
import time
from collections import Counter, defaultdict, deque
from decimal import Decimal
from pathlib import Path

from analyze_structure import compact_decimal, parse_mps


SCALE = 100_000
INF = 10**30


def scaled(value: Decimal) -> int:
    result = value * SCALE
    if result != result.to_integral_value():
        raise ValueError(f"non-integral scaled cost {value}")
    return int(result)


def load_incumbent(path: Path, binaries: set[str], objective: dict[str, Decimal]):
    values: dict[str, Decimal] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        tokens = line.split()
        if len(tokens) >= 2 and not tokens[0].startswith("=obj="):
            values[tokens[0]] = Decimal(tokens[1])
    selected = {v for v in binaries if values.get(v, Decimal(0)) > Decimal("0.5")}
    cost = scaled(sum(objective.get(v, Decimal(0)) for v in selected))
    return cost, selected


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("incumbent", type=Path)
    parser.add_argument("--seconds", type=float, default=3600)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--solution", type=Path, required=True)
    args = parser.parse_args()

    started = time.monotonic()
    model = parse_mps(args.mps)
    variables = model["variable_order"]
    integers = model["integer_variables"]
    binaries = {
        v
        for v in integers
        if model["lower"][v] == 0 and model["upper"][v] == 1
    }
    continuous = set(variables) - integers
    entries = model["row_entries"]
    equality_rows = [r for r in model["row_order"] if model["row_types"][r] == "E"]

    variable_equalities: dict[str, list[tuple[str, Decimal]]] = defaultdict(list)
    for row in equality_rows:
        for variable, coefficient in entries[row]:
            variable_equalities[variable].append((row, coefficient))
    fingerprints: dict[tuple, list[str]] = defaultdict(list)
    for row in equality_rows:
        fingerprints[tuple(sorted((v, a) for v, a in entries[row]))].append(row)
    nodes = sorted(rows[0] for rows in fingerprints.values())
    node_set = set(nodes)
    if len(nodes) != 280:
        raise ValueError(f"expected 280 unique balance rows, got {len(nodes)}")
    node_index = {node: i for i, node in enumerate(nodes)}

    links: dict[str, str] = {}
    conflict_pairs: set[tuple[str, str]] = set()
    for row in model["row_order"]:
        sense = model["row_types"][row]
        if sense == "G":
            bterms = [(v, a) for v, a in entries[row] if v in binaries]
            cterms = [(v, a) for v, a in entries[row] if v in continuous]
            if len(bterms) == len(cterms) == 1 and bterms[0][1] == 1 and cterms[0][1] == Decimal("-0.25"):
                links[cterms[0][0]] = bterms[0][0]
        elif sense == "L":
            rhs = model["rhs"][row]
            center = [v for v, a in entries[row] if a == rhs]
            neighbors = [v for v, a in entries[row] if a == 1]
            if len(center) != 1 or len(neighbors) != len(entries[row]) - 1:
                raise ValueError(f"unexpected conflict row {row}")
            for neighbor in neighbors:
                conflict_pairs.add(tuple(sorted((center[0], neighbor))))
    conflicts: dict[str, set[str]] = defaultdict(set)
    for left, right in conflict_pairs:
        conflicts[left].add(right)
        conflicts[right].add(left)

    arc_data: dict[str, dict] = {}
    outgoing: list[list[str]] = [[] for _ in nodes]
    incoming: list[list[str]] = [[] for _ in nodes]
    for flow, binary in links.items():
        incidence = [(r, a) for r, a in variable_equalities[flow] if r in node_set]
        positive = [r for r, a in incidence if a == 1]
        negative = [r for r, a in incidence if a == -1]
        if len(positive) != 1 or len(negative) != 1:
            raise ValueError(f"bad network column {flow}: {incidence}")
        tail, head = positive[0], negative[0]
        data = {
            "tail": node_index[tail],
            "head": node_index[head],
            "tail_name": tail,
            "head_name": head,
            "flow": flow,
            "cost": scaled(model["objective"][binary]),
        }
        arc_data[binary] = data
        outgoing[data["tail"]].append(binary)
        incoming[data["head"]].append(binary)

    unlinked = sorted(continuous - set(links))
    boundary = []
    for variable in unlinked:
        incidence = [(r, a) for r, a in variable_equalities[variable] if r in node_set]
        if len(incidence) != 1:
            raise ValueError(f"bad boundary variable {variable}: {incidence}")
        boundary.append((variable, incidence[0][0], incidence[0][1], model["lower"][variable]))
    sources = [(v, r, lb) for v, r, a, lb in boundary if a < 0]
    sinks = [(v, r, lb) for v, r, a, lb in boundary if a > 0]
    if len(sources) != 1 or len(sinks) != 4:
        raise ValueError(f"unexpected boundary {boundary}")
    source_name = sources[0][1]
    source = node_index[source_name]
    sink_names = sorted(r for _, r, _ in sinks)
    sink_indices = [node_index[r] for r in sink_names]

    incumbent_cost, incumbent_selected = load_incumbent(
        args.incumbent, binaries, model["objective"]
    )
    incumbent_origin = "official_solution_2"

    masks = 1 << len(sink_indices)

    def solve_relaxation(forbidden: frozenset[str]):
        dp = [[INF] * len(nodes) for _ in range(masks)]
        predecessor: list[list[tuple | None]] = [[None] * len(nodes) for _ in range(masks)]

        def reverse_closure(mask: int, initial_predecessor: list[tuple | None]) -> None:
            predecessor[mask] = initial_predecessor
            heap = [(d, v) for v, d in enumerate(dp[mask]) if d < INF]
            heapq.heapify(heap)
            while heap:
                distance, head = heapq.heappop(heap)
                if distance != dp[mask][head]:
                    continue
                for binary in incoming[head]:
                    if binary in forbidden:
                        continue
                    data = arc_data[binary]
                    tail = data["tail"]
                    candidate = distance + data["cost"]
                    if candidate < dp[mask][tail]:
                        dp[mask][tail] = candidate
                        predecessor[mask][tail] = ("arc", head, binary)
                        heapq.heappush(heap, (candidate, tail))

        for bit, terminal in enumerate(sink_indices):
            mask = 1 << bit
            dp[mask][terminal] = 0
            reverse_closure(mask, [None] * len(nodes))

        for mask in range(1, masks):
            if mask & (mask - 1) == 0:
                continue
            initial: list[tuple | None] = [None] * len(nodes)
            lowbit = mask & -mask
            submask = (mask - 1) & mask
            while submask:
                other = mask ^ submask
                if other and submask & lowbit:
                    for vertex in range(len(nodes)):
                        candidate = dp[submask][vertex] + dp[other][vertex]
                        if candidate < dp[mask][vertex]:
                            dp[mask][vertex] = candidate
                            initial[vertex] = ("split", submask, other)
                submask = (submask - 1) & mask
            reverse_closure(mask, initial)

        full = masks - 1
        lower_bound = dp[full][source]
        if lower_bound >= INF:
            return lower_bound, set()
        selected: set[str] = set()
        seen_states: set[tuple[int, int]] = set()

        def recover(mask: int, vertex: int) -> None:
            state = mask, vertex
            if state in seen_states:
                return
            seen_states.add(state)
            step = predecessor[mask][vertex]
            if step is None:
                return
            if step[0] == "arc":
                _, head, binary = step
                selected.add(binary)
                recover(mask, head)
            else:
                _, left, right = step
                recover(left, vertex)
                recover(right, vertex)

        recover(full, source)
        union_cost = sum(arc_data[b]["cost"] for b in selected)
        if union_cost > lower_bound:
            raise ValueError(f"recovered cost {union_cost} exceeds DP value {lower_bound}")
        # A cheaper union remains a valid lower bound; close the rare overlap gap
        # conservatively instead of asserting equality.
        return min(lower_bound, union_cost), selected

    def selected_conflicts(selected: set[str]) -> list[tuple[str, str]]:
        return sorted(
            (left, right)
            for left in selected
            for right in conflicts.get(left, set())
            if left < right and right in selected
        )

    root_lb, root_selected = solve_relaxation(frozenset())
    counter = 0
    queue = [(root_lb, counter, frozenset(), root_selected)]
    seen_forbidden = {frozenset()}
    explored = 0
    generated = 1
    pruned_by_bound = 0
    infeasible_nodes = 0
    max_queue = 1
    lower_bound_at_stop = root_lb

    while queue and time.monotonic() - started < args.seconds:
        lower_bound, _serial, forbidden, selected = heapq.heappop(queue)
        lower_bound_at_stop = lower_bound
        if lower_bound >= incumbent_cost:
            pruned_by_bound += 1
            continue
        explored += 1
        violations = selected_conflicts(selected)
        if not violations:
            incumbent_cost = lower_bound
            incumbent_selected = selected
            incumbent_origin = f"branch_and_bound_node_{explored}"
            print(
                f"incumbent {incumbent_cost / SCALE:.5f} at node {explored}; "
                f"queue={len(queue)} forbidden={len(forbidden)}",
                flush=True,
            )
            continue

        # Prefer a conflict involving high-conflict arcs in the current tree.
        violation = max(
            violations,
            key=lambda pair: (
                sum(1 for x in conflicts[pair[0]] if x in selected)
                + sum(1 for x in conflicts[pair[1]] if x in selected),
                pair,
            ),
        )
        for binary in violation:
            child_forbidden = forbidden | {binary}
            if child_forbidden in seen_forbidden:
                continue
            seen_forbidden.add(child_forbidden)
            child_lb, child_selected = solve_relaxation(child_forbidden)
            generated += 1
            if child_lb >= INF:
                infeasible_nodes += 1
            elif child_lb >= incumbent_cost:
                pruned_by_bound += 1
            else:
                counter += 1
                heapq.heappush(
                    queue,
                    (child_lb, counter, child_forbidden, child_selected),
                )
        max_queue = max(max_queue, len(queue))
        if explored % 100 == 0:
            best_open = queue[0][0] / SCALE if queue else incumbent_cost / SCALE
            print(
                f"nodes={explored} generated={generated} queue={len(queue)} "
                f"best_open={best_open:.5f} incumbent={incumbent_cost / SCALE:.5f}",
                flush=True,
            )

    complete = not queue
    if queue:
        lower_bound_at_stop = queue[0][0]
    else:
        lower_bound_at_stop = incumbent_cost

    # Reconstruct flow on the incumbent directed arborescence.
    selected_outgoing: dict[int, list[tuple[int, str]]] = defaultdict(list)
    indegree = Counter()
    for binary in incumbent_selected:
        data = arc_data[binary]
        selected_outgoing[data["tail"]].append((data["head"], binary))
        indegree[data["head"]] += 1
    parent = {source: None}
    parent_binary: dict[int, str] = {}
    order = [source]
    for vertex in order:
        for head, binary in selected_outgoing.get(vertex, []):
            if head in parent:
                continue
            parent[head] = vertex
            parent_binary[head] = binary
            order.append(head)
    incumbent_tree_ok = all(sink in parent for sink in sink_indices)
    used_vertices = set()
    for sink in sink_indices:
        current = sink
        while current in parent and current is not None:
            used_vertices.add(current)
            current = parent[current]
    used_binaries = {parent_binary[v] for v in used_vertices if v != source}
    if used_binaries != incumbent_selected:
        incumbent_selected = used_binaries
        incumbent_cost = sum(arc_data[b]["cost"] for b in incumbent_selected)

    subtree_demand = {vertex: int(vertex in set(sink_indices)) for vertex in reversed(order)}
    for vertex in reversed(order[1:]):
        if vertex in used_vertices:
            subtree_demand[parent[vertex]] += subtree_demand[vertex]

    values = {v: Decimal(0) for v in variables}
    for variable, _row, _coefficient, lower in boundary:
        values[variable] = lower
    oriented_edges = []
    for child in order[1:]:
        if child not in used_vertices:
            continue
        binary = parent_binary[child]
        data = arc_data[binary]
        flow_value = subtree_demand[child]
        values[binary] = Decimal(1)
        values[data["flow"]] = Decimal(flow_value)
        oriented_edges.append(
            {
                "tail": data["tail_name"],
                "head": data["head_name"],
                "binary_variable": binary,
                "flow_variable": data["flow"],
                "flow": flow_value,
                "cost": data["cost"] / SCALE,
            }
        )

    violated_rows = []
    max_violation = Decimal(0)
    for row in model["row_order"]:
        activity = sum(a * values[v] for v, a in entries[row])
        rhs = model["rhs"][row]
        sense = model["row_types"][row]
        if sense == "E":
            violation = abs(activity - rhs)
        elif sense == "G":
            violation = max(Decimal(0), rhs - activity)
        else:
            violation = max(Decimal(0), activity - rhs)
        max_violation = max(max_violation, violation)
        if violation:
            violated_rows.append(row)
    objective_value = sum(model["objective"].get(v, Decimal(0)) * values[v] for v in variables)

    args.solution.parent.mkdir(parents=True, exist_ok=True)
    with args.solution.open("w", encoding="utf-8") as handle:
        handle.write(f"=obj= {objective_value}\n")
        for variable in variables:
            if values[variable]:
                handle.write(f"{variable} {values[variable]}\n")

    report = {
        "algorithm": "branch on violated arc conflicts; exact directed Steiner DP at every node",
        "scale": SCALE,
        "source": source_name,
        "sinks": sink_names,
        "nodes": len(nodes),
        "directed_arcs": len(arc_data),
        "pairwise_conflicts": len(conflict_pairs),
        "root_lower_bound_scaled": root_lb,
        "root_lower_bound": root_lb / SCALE,
        "incumbent_scaled": incumbent_cost,
        "incumbent": incumbent_cost / SCALE,
        "incumbent_origin": incumbent_origin,
        "best_open_lower_bound_scaled": lower_bound_at_stop,
        "best_open_lower_bound": lower_bound_at_stop / SCALE,
        "complete": complete,
        "optimal": complete and incumbent_tree_ok and not violated_rows,
        "explored_nodes": explored,
        "generated_nodes": generated,
        "pruned_by_bound": pruned_by_bound,
        "infeasible_nodes": infeasible_nodes,
        "max_queue": max_queue,
        "remaining_queue": len(queue),
        "elapsed_seconds": time.monotonic() - started,
        "selected_arc_count": len(incumbent_selected),
        "selected_binaries": sorted(incumbent_selected),
        "selected_conflicts": selected_conflicts(incumbent_selected),
        "oriented_edges": oriented_edges,
        "exact_objective_from_mps": compact_decimal(objective_value),
        "max_exact_row_violation": compact_decimal(max_violation),
        "violated_row_count": len(violated_rows),
        "violated_rows_head": violated_rows[:30],
    }
    payload = json.dumps(report, indent=2, sort_keys=True) + "\n"
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(payload, encoding="utf-8")
    print(payload, end="")


if __name__ == "__main__":
    main()
