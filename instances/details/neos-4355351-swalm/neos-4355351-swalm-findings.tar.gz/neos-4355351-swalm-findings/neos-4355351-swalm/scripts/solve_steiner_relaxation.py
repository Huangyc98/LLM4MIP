#!/usr/bin/env python3
"""Solve the exact five-terminal Steiner relaxation and test it in the MIP."""

from __future__ import annotations

import argparse
import heapq
import json
from collections import defaultdict, deque
from decimal import Decimal
from pathlib import Path

from analyze_structure import compact_decimal, parse_mps


SCALE = 100_000
INF = 10**30


def scaled(value: Decimal) -> int:
    result = value * SCALE
    if result != result.to_integral_value():
        raise ValueError(f"non-integral scaled cost {value}")
    return int(result)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--solution", type=Path, required=True)
    args = parser.parse_args()

    model = parse_mps(args.mps)
    variables = model["variable_order"]
    integers = model["integer_variables"]
    binaries = {
        v
        for v in integers
        if model["lower"][v] == 0 and model["upper"][v] == 1
    }
    continuous = set(variables) - integers
    entries = model["row_entries"]
    equality_rows = [r for r in model["row_order"] if model["row_types"][r] == "E"]

    variable_equalities: dict[str, list[tuple[str, Decimal]]] = defaultdict(list)
    for row in equality_rows:
        for variable, coefficient in entries[row]:
            variable_equalities[variable].append((row, coefficient))

    # Exact duplicate removal reveals the 280-node physical network.
    fingerprints: dict[tuple, list[str]] = defaultdict(list)
    for row in equality_rows:
        fingerprint = tuple(sorted((v, a) for v, a in entries[row]))
        fingerprints[fingerprint].append(row)
    physical_rows = sorted(rows[0] for rows in fingerprints.values())
    if len(physical_rows) != 280:
        raise ValueError(f"expected 280 unique balance rows, got {len(physical_rows)}")
    physical_set = set(physical_rows)

    # Recover the one-to-one x--y capacity links.
    links: dict[str, str] = {}
    for row in model["row_order"]:
        if model["row_types"][row] != "G":
            continue
        bterms = [(v, a) for v, a in entries[row] if v in binaries]
        cterms = [(v, a) for v, a in entries[row] if v in continuous]
        if len(bterms) == len(cterms) == 1 and bterms[0][1] == 1 and cterms[0][1] == Decimal("-0.25"):
            links[cterms[0][0]] = bterms[0][0]
    if len(links) != 10530:
        raise ValueError(f"expected 10530 x--y links, got {len(links)}")

    arcs: dict[tuple[str, str], tuple[str, str, int]] = {}
    physical_edge_arcs: dict[tuple[str, str], list[tuple[str, str]]] = defaultdict(list)
    for flow, binary in links.items():
        incidence = [(r, a) for r, a in variable_equalities[flow] if r in physical_set]
        positive = [r for r, a in incidence if a == 1]
        negative = [r for r, a in incidence if a == -1]
        if len(positive) != 1 or len(negative) != 1:
            raise ValueError(f"bad network column {flow}: {incidence}")
        tail, head = positive[0], negative[0]
        cost = scaled(model["objective"][binary])
        if (tail, head) in arcs:
            raise ValueError(f"parallel directed arc {(tail, head)}")
        arcs[tail, head] = (flow, binary, cost)
        physical_edge_arcs[tuple(sorted((tail, head)))].append((tail, head))
    edge_size_counts = defaultdict(int)
    for orientations in physical_edge_arcs.values():
        edge_size_counts[len(orientations)] += 1
    if len(physical_edge_arcs) != 5322 or dict(edge_size_counts) != {2: 5208, 1: 114}:
        sizes = defaultdict(int)
        for orientations in physical_edge_arcs.values():
            sizes[len(orientations)] += 1
        raise ValueError(
            f"unexpected physical edge/orientation counts: "
            f"edges={len(physical_edge_arcs)}, size_counts={dict(sizes)}"
        )
    for edge, orientations in physical_edge_arcs.items():
        if len(orientations) == 2 and set(orientations) != {
            (edge[0], edge[1]),
            (edge[1], edge[0]),
        }:
            raise ValueError(f"bad orientations for {edge}")
        if len(orientations) == 2 and arcs[orientations[0]][2] != arcs[orientations[1]][2]:
            raise ValueError(f"asymmetric costs for {edge}")

    # Boundary variables identify four unit-demand terminals and one supply of four.
    unlinked = sorted(continuous - set(links))
    boundary = []
    for variable in unlinked:
        incidence = [(r, a) for r, a in variable_equalities[variable] if r in physical_set]
        if len(incidence) != 1:
            raise ValueError(f"bad boundary variable {variable}: {incidence}")
        row, coefficient = incidence[0]
        boundary.append(
            (variable, row, coefficient, model["lower"][variable])
        )
    sources = [(v, r, lb) for v, r, a, lb in boundary if a < 0]
    sinks = [(v, r, lb) for v, r, a, lb in boundary if a > 0]
    if len(sources) != 1 or len(sinks) != 4:
        raise ValueError(f"unexpected boundary: {boundary}")
    source = sources[0][1]
    sink_rows = sorted(r for _, r, _ in sinks)
    terminals = [source] + sink_rows

    nodes = physical_rows
    node_index = {node: i for i, node in enumerate(nodes)}
    adjacency: list[list[tuple[int, int, tuple[str, str]]]] = [[] for _ in nodes]
    for edge, orientations in physical_edge_arcs.items():
        u, v = edge
        weight = arcs[orientations[0]][2]
        ui, vi = node_index[u], node_index[v]
        adjacency[ui].append((vi, weight, edge))
        adjacency[vi].append((ui, weight, edge))

    terminal_indices = [node_index[t] for t in terminals]
    masks = 1 << len(terminals)
    dp = [[INF] * len(nodes) for _ in range(masks)]
    predecessor: list[list[tuple | None]] = [[None] * len(nodes) for _ in range(masks)]

    def closure(mask: int, initial_predecessor: list[tuple | None]) -> None:
        heap = []
        predecessor[mask] = initial_predecessor
        for vertex, distance in enumerate(dp[mask]):
            if distance < INF:
                heapq.heappush(heap, (distance, vertex))
        while heap:
            distance, vertex = heapq.heappop(heap)
            if distance != dp[mask][vertex]:
                continue
            for neighbor, weight, edge in adjacency[vertex]:
                candidate = distance + weight
                if candidate < dp[mask][neighbor]:
                    dp[mask][neighbor] = candidate
                    predecessor[mask][neighbor] = ("edge", vertex, edge)
                    heapq.heappush(heap, (candidate, neighbor))

    for bit, terminal in enumerate(terminal_indices):
        mask = 1 << bit
        dp[mask][terminal] = 0
        closure(mask, [None] * len(nodes))

    for mask in range(1, masks):
        if mask & (mask - 1) == 0:
            continue
        initial_predecessor: list[tuple | None] = [None] * len(nodes)
        lowbit = mask & -mask
        submask = (mask - 1) & mask
        while submask:
            other = mask ^ submask
            if other and submask & lowbit:
                left = dp[submask]
                right = dp[other]
                current = dp[mask]
                for vertex in range(len(nodes)):
                    candidate = left[vertex] + right[vertex]
                    if candidate < current[vertex]:
                        current[vertex] = candidate
                        initial_predecessor[vertex] = ("split", submask, other)
            submask = (submask - 1) & mask
        closure(mask, initial_predecessor)

    full = masks - 1
    root_vertex = min(range(len(nodes)), key=lambda v: dp[full][v])
    optimum = dp[full][root_vertex]
    tree_edges: set[tuple[str, str]] = set()
    seen_states: set[tuple[int, int]] = set()

    def recover(mask: int, vertex: int) -> None:
        state = mask, vertex
        if state in seen_states:
            return
        seen_states.add(state)
        step = predecessor[mask][vertex]
        if step is None:
            return
        if step[0] == "edge":
            _, previous, edge = step
            tree_edges.add(edge)
            recover(mask, previous)
        elif step[0] == "split":
            _, left, right = step
            recover(left, vertex)
            recover(right, vertex)
        else:
            raise ValueError(step)

    recover(full, root_vertex)
    tree_cost = sum(arcs[physical_edge_arcs[edge][0]][2] for edge in tree_edges)

    # Prune accidental nonterminal leaves (normally the recovered union already
    # is a tree), then orient all edges away from the four-unit source.
    tree_adjacency: dict[str, set[str]] = defaultdict(set)
    for u, v in tree_edges:
        tree_adjacency[u].add(v)
        tree_adjacency[v].add(u)
    queue = deque(v for v in tree_adjacency if len(tree_adjacency[v]) == 1 and v not in terminals)
    while queue:
        leaf = queue.popleft()
        if len(tree_adjacency[leaf]) != 1 or leaf in terminals:
            continue
        neighbor = next(iter(tree_adjacency[leaf]))
        tree_adjacency[neighbor].remove(leaf)
        tree_adjacency[leaf].clear()
        tree_edges.remove(tuple(sorted((leaf, neighbor))))
        if len(tree_adjacency[neighbor]) == 1 and neighbor not in terminals:
            queue.append(neighbor)

    parent = {source: None}
    order = [source]
    for vertex in order:
        for neighbor in sorted(tree_adjacency[vertex]):
            if neighbor == parent[vertex]:
                continue
            if neighbor in parent:
                raise ValueError("recovered Steiner support contains a cycle")
            parent[neighbor] = vertex
            order.append(neighbor)
    if any(t not in parent for t in terminals):
        raise ValueError("recovered support does not connect every terminal")

    sink_set = set(sink_rows)
    subtree_demand = {vertex: int(vertex in sink_set) for vertex in reversed(order)}
    for vertex in reversed(order[1:]):
        subtree_demand[parent[vertex]] += subtree_demand[vertex]

    values = {v: Decimal(0) for v in variables}
    for variable, _row, _coefficient, lower in boundary:
        values[variable] = lower
    selected_binaries = []
    oriented_edges = []
    for child in order[1:]:
        par = parent[child]
        if (par, child) not in arcs:
            raise ValueError(f"Steiner tree uses forbidden orientation {(par, child)}")
        flow, binary, cost = arcs[par, child]
        values[flow] = Decimal(subtree_demand[child])
        values[binary] = Decimal(1)
        selected_binaries.append(binary)
        oriented_edges.append(
            {
                "tail": par,
                "head": child,
                "flow_variable": flow,
                "binary_variable": binary,
                "flow": subtree_demand[child],
                "cost": cost / SCALE,
            }
        )

    # Exact arithmetic audit against every original MPS row and bound.
    max_row_violation = Decimal(0)
    violated_rows = []
    for row in model["row_order"]:
        activity = sum(coefficient * values[variable] for variable, coefficient in entries[row])
        rhs = model["rhs"][row]
        sense = model["row_types"][row]
        if sense == "E":
            violation = abs(activity - rhs)
        elif sense == "G":
            violation = max(Decimal(0), rhs - activity)
        else:
            violation = max(Decimal(0), activity - rhs)
        max_row_violation = max(max_row_violation, violation)
        if violation:
            violated_rows.append(
                {
                    "row": row,
                    "sense": sense,
                    "rhs": compact_decimal(rhs),
                    "activity": compact_decimal(activity),
                    "violation": compact_decimal(violation),
                    "selected_terms": [
                        [variable, compact_decimal(coefficient)]
                        for variable, coefficient in entries[row]
                        if values[variable]
                    ],
                }
            )
    objective = sum(model["objective"].get(v, Decimal(0)) * values[v] for v in variables)

    args.solution.parent.mkdir(parents=True, exist_ok=True)
    with args.solution.open("w", encoding="utf-8") as handle:
        handle.write(f"=obj= {objective}\n")
        for variable in variables:
            if values[variable]:
                handle.write(f"{variable} {values[variable]}\n")

    report = {
        "physical_nodes": len(nodes),
        "physical_edges": len(physical_edge_arcs),
        "terminals": terminals,
        "source": source,
        "sinks": sink_rows,
        "steiner_lower_bound_scaled": optimum,
        "steiner_lower_bound": optimum / SCALE,
        "recovered_union_cost_scaled": tree_cost,
        "recovered_union_cost": tree_cost / SCALE,
        "selected_edge_count": len(selected_binaries),
        "selected_binaries": sorted(selected_binaries),
        "oriented_edges": oriented_edges,
        "objective": compact_decimal(objective),
        "max_exact_row_violation": compact_decimal(max_row_violation),
        "violated_row_count": len(violated_rows),
        "violated_rows_head": violated_rows[:30],
        "full_mip_feasible": not violated_rows,
    }
    payload = json.dumps(report, indent=2, sort_keys=True) + "\n"
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(payload, encoding="utf-8")
    print(payload, end="")


if __name__ == "__main__":
    main()
