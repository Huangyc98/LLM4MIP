"""Extract and exhaustively audit the 375-variable exact core of ns1828997.

Gurobi is used only as an MPS parser.  No optimization or presolve is called.
The script fails closed unless every original row and variable belongs to one
of the recognized logical templates.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter, defaultdict

import gurobipy as gp


def file_sha256(path: str) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps")
    parser.add_argument("output")
    args = parser.parse_args()

    model = gp.read(args.mps)
    variables = model.getVars()
    variable_by_name = {var.VarName: var for var in variables}

    raw_rows = []
    for row in model.getConstrs():
        expression = model.getRow(row)
        terms = tuple(
            sorted(
                (expression.getVar(k).VarName, expression.getCoeff(k))
                for k in range(expression.size())
            )
        )
        raw_rows.append((row.ConstrName, row.Sense, row.RHS, terms))

    cardinality = []
    recognized_rows = set()
    for name, sense, rhs, terms in raw_rows:
        if sense == "=" and rhs == 5 and len(terms) == 25 and all(value == 1 for _, value in terms):
            cardinality.append([var for var, _ in terms])
            recognized_rows.add(name)

    assert len(cardinality) == 15
    core_names = [name for group in cardinality for name in group]
    assert len(core_names) == len(set(core_names)) == 375
    core = set(core_names)
    core_id = {name: index + 1 for index, name in enumerate(core_names)}

    packing = []
    product_of = {}
    implications = []
    for name, sense, rhs, terms in raw_rows:
        if name in recognized_rows:
            continue
        positives = [var for var, value in terms if value == 1]
        negatives = [var for var, value in terms if value == -1]
        if (
            sense == "<"
            and rhs == 1
            and len(terms) == 2
            and len(positives) == 2
            and not negatives
            and set(positives) <= core
        ):
            packing.append(tuple(positives))
            recognized_rows.add(name)
        elif (
            sense == "<"
            and rhs == 1
            and len(terms) == 3
            and len(positives) == 2
            and len(negatives) == 1
            and set(positives) <= core
            and negatives[0] not in core
        ):
            product = negatives[0]
            assert product not in product_of
            product_of[product] = tuple(positives)
            recognized_rows.add(name)
        elif (
            rhs == 0
            and len(terms) == 2
            and len(positives) == 1
            and len(negatives) == 1
            and sense in {"<", ">"}
        ):
            if sense == ">":
                source, target = negatives[0], positives[0]
            else:
                source, target = positives[0], negatives[0]
            implications.append((name, source, target))

    assert len(packing) == 710
    assert len(product_of) == 26875

    product_names = set(product_of)
    extras = set(variable_by_name) - core - product_names
    assert len(extras) == 25
    assert all(variable_by_name[name].Obj == 0 for name in extras)

    product_upper = defaultdict(set)
    extra_lower = defaultdict(set)
    for row_name, source, target in implications:
        if source in product_names and target in core:
            product_upper[source].add(target)
            recognized_rows.add(row_name)
        elif source in core and target in extras:
            extra_lower[target].add(source)
            recognized_rows.add(row_name)
        else:
            raise AssertionError(f"unrecognized implication {row_name}: {source} -> {target}")

    assert len(product_upper) == 26875
    for product, factors in product_of.items():
        assert product_upper[product] == set(factors)
    assert len(extra_lower) == 25
    assert all(len(sources) == 15 for sources in extra_lower.values())

    # Extras are zero-cost OR upper indicators and: setting-declare them one.
    for group_index, group in enumerate(cardinality):
        for position, name in enumerate(group):
            expected = f"C{376 + position:04d}"
            assert name in extra_lower[expected], (group_index, position, name, expected)

    assert len(recognized_rows) == len(raw_rows) == 81725
    assert len(variables) == 27275
    assert all(var.VType in {gp.GRB.BINARY, gp.GRB.INTEGER} and var.LB == 0 and var.UB == 1 for var in variables)
    assert all(variable_by_name[name].Obj == 0 for name in core | extras)

    cost_histogram = Counter()
    cost_terms = []
    for product, factors in product_of.items():
        cost = variable_by_name[product].Obj
        assert cost in {0, 1, 2, 3}
        cost_histogram[cost] += 1
        if cost:
            cost_terms.append(
                {
                    "product": product,
                    "a": core_id[factors[0]],
                    "b": core_id[factors[1]],
                    "cost": int(cost),
                }
            )

    assert cost_histogram == Counter({0: 24817, 1: 588, 2: 882, 3: 588})
    assert len(cost_terms) == 2058

    payload = {
        "format": "ns1828997-exact-core-v1",
        "source": args.mps,
        "source_sha256": file_sha256(args.mps),
        "proof_of_equivalence": {
            "original_variables": len(variables),
            "original_rows": len(raw_rows),
            "recognized_rows": len(recognized_rows),
            "cardinality_groups": len(cardinality),
            "core_variables": len(core),
            "packing_exclusions": len(packing),
            "exact_product_variables": len(product_of),
            "zero_cost_products_eliminated": cost_histogram[0],
            "positive_cost_products_retained": len(cost_terms),
            "zero_cost_extra_indicators_eliminated": len(extras),
            "objective_cost_histogram_all_products": {str(key): value for key, value in sorted(cost_histogram.items())},
        },
        "core_names": core_names,
        "groups": [[core_id[name] for name in group] for group in cardinality],
        "packing": [[core_id[a], core_id[b]] for a, b in packing],
        "cost_terms": cost_terms,
    }
    with open(args.output, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, indent=2, sort_keys=True)
    print(json.dumps(payload["proof_of_equivalence"], indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
