# Effort ledger

| Time (Asia/Shanghai) | Activity | Generic solver seconds | Result |
|---|---|---:|---|
| 03:49 | Research started; official MIPLIB page and solution history checked | 0 | Open, public incumbent 8 |
| 03:53 | Workspace and reproducibility protocol created | 0 | In progress |
| 03:53 | Official MPS and public solution IDs 4/5 fetched through `euler4`; SHA-256 verified | 0 | Inputs fixed |
| 03:53 | Two independent original-MPS solution audits | 0 | ID4 exact feasible at 8; ID5 feasible within 5.7e-13 |
| 03:54 | Read-only Gurobi structure extraction | 0 | 27,275 binaries; five exact row templates |
| 03:55-03:59 | Direct API segment 1: classify and design structure-specific routes | 0 | 9,465 tokens; executable structural audit proposed |
| 04:42-04:44 | Execute and diagnose API audit code | 0 | Stopped: accidental cubic separator enumeration on 375-node graph |
| 04:43-04:54 | Independent exact-core exporter and cutoff CNF construction/audit | 0 | 375-core exact projection; cutoff-7 CNF created |
| 04:55-04:58 | Direct API segment 2 with execution feedback | 0 | 15,806 tokens; corrected exporter and proof-aware PB/SAT route |
| 05:03-05:04 | Independent Glucose4 cutoff-8 free search | 0 | 60.1 s, `UNKNOWN` |
| 05:05-05:06 | Fixed-incumbent CNF direction check with CaDiCaL195 | 0 | SAT immediately; compact objective 8 |
| 05:06-05:08 | Analyze label-distance patterns and 15-node block graph | 0 | 42 soft and 11 hard block pairs; greedy width upper bound 7 |
| 04:45-05:08 | CaDiCaL195 cutoff-7 decision run (separate exact SAT route) | 0 | About 20 minutes CPU; no final status or proof artifact, hence `UNKNOWN` |
| 05:09-05:15 | Kissat cutoff-7 backend attempt | 0 | Stalled with effectively zero CPU; terminated as infrastructure `UNKNOWN` |
| 05:16 | Final audit: no active research processes; report closed | 0 | Validated upper bound 8; no certified matching lower bound |

Generic MIP optimization used: **0 seconds**. SAT runtimes are reported
separately and are not counted as generic MIP solver time.

Research wall-clock: 2026-09-09 03:49:08 to 05:16:13 Asia/Shanghai,
approximately **87 minutes**.
