# Package manifest: ns1828997

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 21
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/audit_public_id4.json`
- `artifacts/audit_public_id5.json`
- `artifacts/core_pattern_analysis.json`
- `artifacts/cutoff8_glucose_result.json`
- `artifacts/cutoff8_incumbent_validation.json`
- `artifacts/exact_core.json`
- `artifacts/structural_audit.json`
- `logs/effort_ledger.md`
- `logs/reproducibility.md`
- `reports/final_report.md`
- `scripts/analyze_core_patterns.py`
- `scripts/audit_ns1828997.py`
- `scripts/extract_exact_core.py`
- `scripts/root_probe.py`
- `scripts/solve_exact_core_sat.py`
- `scripts/validate_cnf_with_incumbent.py`
- `solutions/public_id4_localmip.sol.gz`
- `solutions/public_id5_copt.sol.gz`
- `sources/official_background.md`
- `structure/gurobi_structure.json`

## Excluded files

- `input/ns1828997.mps.gz (1021978 bytes; raw benchmark input; sha256 fd75a2046132b9a7cdac326b4fcaf2f953b5f59934ee80b3f120a6082cd1ca90)`
