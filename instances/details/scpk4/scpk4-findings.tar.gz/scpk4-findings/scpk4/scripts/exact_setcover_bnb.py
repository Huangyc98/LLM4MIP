#!/usr/bin/env python3
"""Produce a checkable branch-and-bound proof for a set-cover objective cutoff.

Floating-point LPs choose branches only.  Every logical pruning decision uses
an integer-scaled feasible dual that is stored in the output certificate.
"""

import argparse
import heapq
import json
import math
import time
from pathlib import Path

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import csc_matrix

from setcover_structure import parse_mps


def safe_dual_numerators(raw, active_columns, column_rows, costs, denominator):
    numerators = [max(0, math.floor(float(value) * denominator - 1e-4)) for value in raw]
    # Repair any residual floating-point excess using exact integer arithmetic.
    while True:
        worst = 0
        repair = 0
        for column in active_columns:
            positive_rows = [row for row in column_rows[column] if numerators[row] > 0]
            excess = sum(numerators[row] for row in positive_rows) - costs[column] * denominator
            if excess > worst:
                worst = excess
            if excess > 0:
                repair = max(repair, (excess + len(positive_rows) - 1) // len(positive_rows))
        if worst <= 0:
            break
        assert repair > 0
        numerators = [max(0, value - repair) for value in numerators]
    return numerators


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("dual_structure", type=Path)
    parser.add_argument("--target", type=int, required=True)
    parser.add_argument("--denominator", type=int, default=1_000_000)
    parser.add_argument("--strong-candidates", type=int, default=8)
    parser.add_argument("--time-limit", type=float, default=3600)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    senses, rhs, cost_values, columns_by_name = parse_mps(args.model)
    assert all(sense == "G" and rhs[row] == 1 for row, sense in senses.items())
    names = list(columns_by_name)
    name_index = {name: index for index, name in enumerate(names)}
    rows = list(senses)
    row_index = {row: index for index, row in enumerate(rows)}
    costs = [int(cost_values[name]) for name in names]
    column_rows = [tuple(row_index[row] for row in columns_by_name[name]) for name in names]
    column_row_masks = [sum(1 << row for row in covered) for covered in column_rows]
    row_columns = [[] for _ in rows]
    matrix_row = []
    matrix_col = []
    for column, covered in enumerate(column_rows):
        for row in covered:
            row_columns[row].append(column)
            matrix_row.append(row)
            matrix_col.append(column)
    matrix = csc_matrix(
        (np.ones(len(matrix_row)), (matrix_row, matrix_col)),
        shape=(len(rows), len(names)),
    )

    dual_data = json.loads(args.dual_structure.read_text(encoding="utf-8"))["lp_relaxation"]["exact_dual_certificate"]
    root_denominator = int(dual_data["denominator"])
    root_dual = {row_index[row]: int(value) for row, value in dual_data["row_numerators"].items()}
    root_bound = int(dual_data["bound_numerator"])
    root_gap = args.target * root_denominator - root_bound
    root_reduced_cost = [
        costs[column] * root_denominator - sum(root_dual[row] for row in column_rows[column])
        for column in range(len(names))
    ]
    assert min(root_reduced_cost) >= 0
    global_fixed_zero = frozenset(
        column for column, reduced_cost in enumerate(root_reduced_cost) if reduced_cost > root_gap
    )

    all_rows_mask = (1 << len(rows)) - 1
    denominator = args.denominator
    target_numerator = args.target * denominator
    certificate_nodes = {}
    queue = []
    next_node_id = 0
    started = time.perf_counter()
    solved_lps = 0
    strong_lps = 0
    incumbent = None

    def push(parent, branch_value, fixed_zero, fixed_one, priority):
        nonlocal next_node_id
        node_id = next_node_id
        next_node_id += 1
        heapq.heappush(queue, (priority, node_id, parent, branch_value, fixed_zero, fixed_one))
        return node_id

    root_id = push(None, None, global_fixed_zero, frozenset(), -math.inf)

    def residual_state(fixed_zero, fixed_one):
        covered_mask = 0
        fixed_cost = 0
        for column in fixed_one:
            covered_mask |= column_row_masks[column]
            fixed_cost += costs[column]
        uncovered = [row for row in range(len(rows)) if not (covered_mask >> row) & 1]
        uncovered_mask = all_rows_mask ^ covered_mask
        active = [
            column
            for column in range(len(names))
            if column not in fixed_zero
            and column not in fixed_one
            and column_row_masks[column] & uncovered_mask
        ]
        return fixed_cost, uncovered, active

    def solve_lp(fixed_zero, fixed_one):
        fixed_cost, uncovered, active = residual_state(fixed_zero, fixed_one)
        if fixed_cost > args.target:
            return {"kind": "cost", "fixed_cost": fixed_cost}
        active_set = set(active)
        for row in uncovered:
            if not any(column in active_set for column in row_columns[row]):
                return {"kind": "uncovered", "row": row, "fixed_cost": fixed_cost}
        if not uncovered:
            return {"kind": "feasible", "fixed_cost": fixed_cost, "active": active, "uncovered": uncovered}
        submatrix = matrix[uncovered, :][:, active]
        result = linprog(
            np.array([costs[column] for column in active], dtype=float),
            A_ub=-submatrix,
            b_ub=-np.ones(len(uncovered)),
            bounds=(0, None),
            method="highs",
        )
        if not result.success:
            return {"kind": "numeric_infeasible", "fixed_cost": fixed_cost, "active": active, "uncovered": uncovered}
        raw = [0.0] * len(rows)
        for local_row, original_row in enumerate(uncovered):
            raw[original_row] = max(0.0, -float(result.ineqlin.marginals[local_row]))
        numerators = safe_dual_numerators(raw, active, column_rows, costs, denominator)
        return {
            "kind": "lp",
            "fixed_cost": fixed_cost,
            "uncovered": uncovered,
            "active": active,
            "objective": fixed_cost + float(result.fun),
            "x": result.x,
            "dual": numerators,
            "dual_bound_numerator": fixed_cost * denominator + sum(numerators),
        }

    while queue and time.perf_counter() - started < args.time_limit and incumbent is None:
        priority, node_id, parent, branch_value, fixed_zero, fixed_one = heapq.heappop(queue)
        record = {
            "id": node_id,
            "parent": parent,
            "branch_value": branch_value,
            "reductions": [],
        }
        certificate_nodes[node_id] = record
        while True:
            state = solve_lp(fixed_zero, fixed_one)
            solved_lps += state["kind"] == "lp"
            if state["kind"] in ("cost", "uncovered"):
                record["leaf"] = state
                break
            if state["kind"] == "numeric_infeasible":
                record["unfinished_numeric_infeasible"] = True
                queue.clear()
                break
            if state["kind"] == "feasible":
                incumbent = sorted(fixed_one)
                record["counterexample"] = incumbent
                break
            sparse_dual = {rows[row]: value for row, value in enumerate(state["dual"]) if value}
            if state["dual_bound_numerator"] > target_numerator:
                record["leaf"] = {
                    "kind": "dual",
                    "fixed_cost": state["fixed_cost"],
                    "dual_row_numerators": sparse_dual,
                    "bound_numerator": state["dual_bound_numerator"],
                }
                break
            new_fixed = []
            dual_sum = sum(state["dual"])
            for column in state["active"]:
                reduced_cost = costs[column] * denominator - sum(
                    state["dual"][row] for row in column_rows[column]
                )
                if state["fixed_cost"] * denominator + dual_sum + reduced_cost > target_numerator:
                    new_fixed.append(column)
            if new_fixed:
                record["reductions"].append(
                    {
                        "fixed_cost": state["fixed_cost"],
                        "dual_row_numerators": sparse_dual,
                        "fixed_zero_columns": new_fixed,
                    }
                )
                fixed_zero = fixed_zero.union(new_fixed)
                continue

            fractional = [
                (local, column, value)
                for local, (column, value) in enumerate(zip(state["active"], state["x"]))
                if 1e-7 < value < 1 - 1e-7
            ]
            if not fractional:
                selected = set(fixed_one)
                selected.update(
                    column for column, value in zip(state["active"], state["x"]) if value >= 1 - 1e-7
                )
                if sum(costs[column] for column in selected) <= args.target:
                    incumbent = sorted(selected)
                    record["counterexample"] = incumbent
                else:
                    record["unfinished_integral_numeric"] = True
                    queue.clear()
                break

            candidates = sorted(fractional, key=lambda item: abs(item[2] - 0.5))[: args.strong_candidates]
            best = None
            for _, column, value in candidates:
                child_bounds = []
                for take in (0, 1):
                    child_zero = fixed_zero.union((column,)) if take == 0 else fixed_zero
                    child_one = fixed_one.union((column,)) if take == 1 else fixed_one
                    child = solve_lp(child_zero, child_one)
                    strong_lps += child["kind"] == "lp"
                    if child["kind"] == "lp":
                        child_bounds.append(child["objective"])
                    elif child["kind"] in ("cost", "uncovered", "numeric_infeasible"):
                        child_bounds.append(float("inf"))
                    else:
                        child_bounds.append(child["fixed_cost"])
                score = (min(child_bounds), max(child_bounds), -abs(value - 0.5))
                if best is None or score > best[0]:
                    best = (score, column, child_bounds)
            _, branch_column, child_bounds = best
            record["branch_column"] = branch_column
            record["branch_name"] = names[branch_column]
            child0 = push(node_id, 0, fixed_zero.union((branch_column,)), fixed_one, child_bounds[0])
            child1 = push(node_id, 1, fixed_zero, fixed_one.union((branch_column,)), child_bounds[1])
            record["children"] = [child0, child1]
            break

        if len(certificate_nodes) % 10 == 0:
            print(
                json.dumps(
                    {
                        "processed_nodes": len(certificate_nodes),
                        "open_nodes": len(queue),
                        "solved_lps": solved_lps,
                        "strong_lps": strong_lps,
                        "elapsed": time.perf_counter() - started,
                        "best_open_numeric_bound": queue[0][0] if queue else None,
                    }
                ),
                flush=True,
            )

    status = "PROVED_INFEASIBLE" if not queue and incumbent is None else "COUNTEREXAMPLE" if incumbent else "INCOMPLETE"
    certificate = {
        "status": status,
        "target": args.target,
        "dual_denominator": denominator,
        "source_columns": len(names),
        "global_fixed_zero_by_root_reduced_cost": [names[column] for column in sorted(global_fixed_zero)],
        "root_dual_denominator": root_denominator,
        "root_dual_bound_numerator": root_bound,
        "root_id": root_id,
        "nodes": [certificate_nodes[node] for node in sorted(certificate_nodes)],
        "open_node_count": len(queue),
        "processed_nodes": len(certificate_nodes),
        "lp_solves": solved_lps,
        "strong_branch_lp_solves": strong_lps,
        "elapsed_seconds": time.perf_counter() - started,
        "counterexample_names": [names[column] for column in incumbent] if incumbent else None,
    }
    args.output.write_text(json.dumps(certificate, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in certificate.items() if key not in ("nodes", "global_fixed_zero_by_root_reduced_cost")}, indent=2))


if __name__ == "__main__":
    main()
