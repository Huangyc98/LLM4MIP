#!/usr/bin/env python3
"""Safely delete columns dominated by explicit collections of cost-one columns."""

import argparse
from collections import defaultdict
import gzip
import json
from pathlib import Path

from setcover_structure import parse_mps, parse_solution


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--model-output", type=Path, required=True)
    parser.add_argument("--start-output", type=Path, required=True)
    parser.add_argument("--certificate", type=Path, required=True)
    args = parser.parse_args()

    senses, rhs, costs, columns = parse_mps(args.model)
    declared, solution = parse_solution(args.solution)
    variables = list(columns)
    supports = {var: frozenset(columns[var]) for var in variables}
    cost_one = [var for var in variables if costs[var] == 1]
    row_candidates = defaultdict(list)
    for var in cost_one:
        for row in supports[var]:
            row_candidates[row].append(var)

    dominated = {}
    for target in variables:
        budget = int(round(costs[target]))
        if budget <= 1:
            continue
        remaining = set(supports[target])
        candidate_pool = set()
        for row in remaining:
            candidate_pool.update(row_candidates[row])
        chosen = []
        while remaining and len(chosen) < budget:
            best = max(
                candidate_pool,
                key=lambda var: (len(supports[var] & remaining), -int(var.split("x")[-1])),
                default=None,
            )
            if best is None or not (supports[best] & remaining):
                break
            chosen.append(best)
            remaining -= supports[best]
            candidate_pool.remove(best)
        if not remaining and len(chosen) <= budget:
            dominated[target] = chosen

    retained = [var for var in variables if var not in dominated]
    selected = [var for var in variables if solution.get(var, 0.0) > 0.5]
    assert all(var in retained for var in selected)

    with args.model_output.open("wt", encoding="ascii", newline="\n") as stream:
        stream.write("NAME scpk4_dominance_reduced\nROWS\n N OBJ\n")
        for row in senses:
            stream.write(f" G {row}\n")
        stream.write("COLUMNS\n")
        stream.write(" MARK0000 'MARKER' 'INTORG'\n")
        for var in retained:
            entries = [("OBJ", costs[var]), *columns[var].items()]
            for offset in range(0, len(entries), 2):
                chunk = entries[offset:offset + 2]
                stream.write(" " + var)
                for row, value in chunk:
                    stream.write(f" {row} {value:.12g}")
                stream.write("\n")
        stream.write(" MARK0001 'MARKER' 'INTEND'\nRHS\n")
        for offset in range(0, len(senses), 2):
            chunk = list(senses)[offset:offset + 2]
            stream.write(" RHS1")
            for row in chunk:
                stream.write(f" {row} {rhs[row]:.12g}")
            stream.write("\n")
        stream.write("BOUNDS\n")
        for var in retained:
            stream.write(f" BV BND1 {var}\n")
        stream.write("ENDATA\n")

    with args.start_output.open("wt", encoding="ascii", newline="\n") as stream:
        stream.write(f"=obj= {declared:.17g}\n")
        for var in retained:
            stream.write(f"{var} {1 if solution.get(var, 0.0) > 0.5 else 0}\n")

    certificate = {
        "instance": "scpk4",
        "method": "explicit domination by cost-one column collections",
        "original_columns": len(variables),
        "retained_columns": len(retained),
        "dominated_columns": len(dominated),
        "selected_public_columns_retained": True,
        "dominated": dominated,
    }
    args.certificate.write_text(json.dumps(certificate, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in certificate.items() if key != "dominated"}, indent=2))


if __name__ == "__main__":
    main()
