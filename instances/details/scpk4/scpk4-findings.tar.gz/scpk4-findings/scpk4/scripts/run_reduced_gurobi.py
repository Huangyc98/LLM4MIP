#!/usr/bin/env python3
"""Run a documented Gurobi baseline on the dominance-reduced set-cover model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("--start", type=Path)
    parser.add_argument("--time-limit", type=float, default=300.0)
    parser.add_argument("--threads", type=int, default=32)
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--solution", type=Path)
    args = parser.parse_args()

    args.log.parent.mkdir(parents=True, exist_ok=True)
    model = gp.read(str(args.model))
    if args.start:
        model.read(str(args.start))
    model.Params.LogFile = str(args.log)
    model.Params.TimeLimit = args.time_limit
    model.Params.Threads = args.threads
    model.Params.Seed = args.seed
    model.Params.MIPFocus = 3
    model.Params.Cuts = 2
    model.Params.Heuristics = 0.05
    model.Params.IntegralityFocus = 1
    model.optimize()

    report = {
        "instance": "scpk4",
        "model": str(args.model),
        "method": "Gurobi 13 branch-and-cut on certified dominance reduction",
        "gurobi_version": list(gp.gurobi.version()),
        "parameters": {
            "time_limit": args.time_limit,
            "threads": args.threads,
            "seed": args.seed,
            "mip_focus": 3,
            "cuts": 2,
            "heuristics": 0.05,
            "integrality_focus": 1,
        },
        "status": int(model.Status),
        "status_name": {
            GRB.OPTIMAL: "OPTIMAL",
            GRB.TIME_LIMIT: "TIME_LIMIT",
            GRB.INFEASIBLE: "INFEASIBLE",
            GRB.INTERRUPTED: "INTERRUPTED",
        }.get(model.Status, str(model.Status)),
        "runtime": model.Runtime,
        "work": model.Work,
        "node_count": model.NodeCount,
        "solution_count": model.SolCount,
        "objective": model.ObjVal if model.SolCount else None,
        "best_bound": model.ObjBound,
        "relative_gap": model.MIPGap if model.SolCount else None,
    }
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    if args.solution and model.SolCount:
        args.solution.parent.mkdir(parents=True, exist_ok=True)
        model.write(str(args.solution))
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
