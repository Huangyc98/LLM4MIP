# scpk4 — strict interval [283, 318]

Official MIPLIB page: <https://miplib.zib.de/instance_details_scpk4.html>

## Current result

The public objective-318 solution is feasible, and this study proves the
independently checkable global lower bound **283**. Therefore

```text
283 <= OPT <= 318.
```

Global optimality remains open. A 300-second Gurobi run reached numerical bound
284, but that floating-point bound is kept separate from the exact certificate.

## Exact proof chain

The original instance is a binary set cover with 2,000 rows, 100,000 columns,
and 1,000,000 unit covering coefficients. The public solution selects 294
columns and covers every row at cost 318.

1. [`verify_dominance.py`](scripts/verify_dominance.py) checks 86,293 explicit
   domination replacements against the original MPS and confirms that the
   13,707-column reduced MPS contains exactly the retained original columns,
   with unchanged costs and supports.
2. The root LP value is 280.54420019725717. A denominator-`10^9` feasible
   integer dual has value 280.544199711 and gives the initial integer bound 281.
3. [`proof-target282.json`](artifacts/proof-target282.json) is a complete
   27-node branch-and-bound certificate excluding every cover of cost at most
   282. Floating-point LPs choose branches only; all pruning decisions use
   stored integer-scaled feasible duals.
4. [`verify_setcover_bnb.py`](scripts/verify_setcover_bnb.py) independently
   replays 26 dual certificates, 4,961 dynamic reduced-cost fixings, and all 14
   proof leaves without calling an optimizer. The checked result is archived in
   [`replay-target282.json`](artifacts/replay-target282.json).

Key artifact hashes:

| Artifact | SHA-256 |
|---|---|
| dominance certificate | `52ffc32315bfb2da31dfdad380bc0edaf558d338effd742f65c2b7f7b1d5cee7` |
| reduced MPS | `ea8e1d653f28f44ecdacb16fae7a1e0962f447fc84c3685df58f2409d6ff6ecb` |
| target-282 proof | `e5b898aa694d2e1380d246b75a7ec9efa10885c50d5c5dad57dfab2db0527132` |
| replay result | `9a59366b06f8b5e6fd6bfe1bf9fa001979bf0284359d2e761713bc7b7848b9b5` |

## Reproduction

The two decisive checks require only Python 3:

```sh
python instances/scpk4/scripts/verify_dominance.py \
  instances/scpk4/input/scpk4.mps.gz \
  instances/scpk4/artifacts/dominance-certificate.json \
  instances/scpk4/artifacts/scpk4-dominance-reduced.mps

python instances/scpk4/scripts/verify_setcover_bnb.py \
  instances/scpk4/artifacts/scpk4-dominance-reduced.mps \
  instances/scpk4/artifacts/structure-lp-audit.json \
  instances/scpk4/artifacts/proof-target282.json \
  --output replay-target282.json
```

Input hashes are recorded in [`input/SHA256SUMS`](input/SHA256SUMS).
