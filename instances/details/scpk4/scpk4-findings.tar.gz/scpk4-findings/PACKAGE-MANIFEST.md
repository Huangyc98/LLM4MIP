# Package manifest: scpk4

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 17
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/dominance-certificate.json`
- `artifacts/dominance-verification.json`
- `artifacts/gurobi-reduced-300s.json`
- `artifacts/proof-target282.json`
- `artifacts/replay-target282.json`
- `artifacts/scpk4-dominance-reduced.mps`
- `artifacts/structure-lp-audit.json`
- `input/SHA256SUMS`
- `logs/gurobi-reduced-300s.log`
- `scripts/dominance_reduce.py`
- `scripts/exact_setcover_bnb.py`
- `scripts/run_reduced_gurobi.py`
- `scripts/setcover_structure.py`
- `scripts/verify_dominance.py`
- `scripts/verify_setcover_bnb.py`
- `solutions/scpk4-public-7.sol.gz`

## Excluded files

- `input/scpk4.mps.gz (5068100 bytes; raw benchmark input; sha256 093059e2d4caa1a724dd429342ee301517ac00e4163872e3eb9f310228a7fe9d)`
