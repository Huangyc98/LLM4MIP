import json
import re
import time
from pathlib import Path

import gurobipy as gp


ROOT = Path(r"D:\sufe\code\AI+MIP\direct-api-research\batch-20260908\s82")
MPS = ROOT / "input" / "s82-official.mps.gz"
SOL = ROOT / "input" / "s82.sol"
OUT = ROOT / "results" / "global-all37-iis.json"
ILP = ROOT / "results" / "global-all37-iis.ilp"
LOG = ROOT / "logs" / "global-all37-iis.log"

values = {}
for line in SOL.read_text(encoding="utf-8").splitlines():
    fields = line.split()
    if len(fields) >= 2 and not fields[0].startswith("=obj="):
        values[fields[0]] = float(fields[1])

started = time.time()
m = gp.read(str(MPS))
m.Params.LogFile = str(LOG)
m.Params.TimeLimit = 180
m.Params.Threads = 4
m.Params.Presolve = 1
m.Params.PrePasses = 2
m.Params.Aggregate = 0
m.Params.PreSparsify = 0

fixed_to_one = []
for v in m.getVars():
    if re.fullmatch(r"A8_\d+", v.VarName) and (
        values.get(v.VarName, 0.0) > 0.5 or v.VarName == "A8_11"
    ):
        v.LB = 1.0
        fixed_to_one.append(v.VarName)
m.setObjective(0.0)
m.optimize()

if m.Status != gp.GRB.INFEASIBLE:
    raise RuntimeError(f"Expected INFEASIBLE, got status {m.Status}")

iis_started = time.time()
m.computeIIS()
iis_seconds = time.time() - iis_started
m.write(str(ILP))

iis_rows = [c.ConstrName for c in m.getConstrs() if c.IISConstr]
iis_lb = [v.VarName for v in m.getVars() if v.IISLB]
iis_ub = [v.VarName for v in m.getVars() if v.IISUB]
out = {
    "instance": "s82",
    "subproblem": "all 37 algebraically available A8 accept variables fixed to one",
    "fixed_to_one": fixed_to_one,
    "fixed_to_one_count": len(fixed_to_one),
    "status": "INFEASIBLE",
    "iis_minimal": int(m.IISMinimal),
    "iis_constraint_count": len(iis_rows),
    "iis_lower_bound_count": len(iis_lb),
    "iis_upper_bound_count": len(iis_ub),
    "iis_constraints": iis_rows,
    "iis_lower_bounds": iis_lb,
    "iis_upper_bounds": iis_ub,
    "iis_seconds": iis_seconds,
    "wall_seconds": time.time() - started,
    "ilp_file": str(ILP),
    "evidence_boundary": (
        "Gurobi IIS is a compact reproducibility aid, not a solver-independent "
        "formal proof certificate. Infeasibility is additionally reproducible by "
        "running the original-MPS all37 script."
    ),
}
OUT.write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8")
print(json.dumps(out, indent=2, ensure_ascii=False))
