import argparse
import json
from pathlib import Path

import gurobipy as gp


parser = argparse.ArgumentParser(
    description="Check the two original-MPS rows that force A8_11 to zero."
)
parser.add_argument("mps", type=Path)
parser.add_argument("output", type=Path)
args = parser.parse_args()

m = gp.read(str(args.mps))
m.update()
c96 = m.getConstrByName("c96")
c258 = m.getConstrByName("c258")
r96 = m.getRow(c96)
r258 = m.getRow(c258)

terms96 = {r96.getVar(i).VarName: r96.getCoeff(i) for i in range(r96.size())}
terms258 = {
    r258.getVar(i).VarName: r258.getCoeff(i) for i in range(r258.size())
}
support96 = set(terms96) - {"A8_11"}
support258 = set(terms258)
same_support = support96 == support258
all_binary = all(
    m.getVarByName(name).VType in (gp.GRB.BINARY, gp.GRB.INTEGER)
    and m.getVarByName(name).LB == 0
    and m.getVarByName(name).UB == 1
    for name in support96
)
all_c96_unit = all(terms96[name] == 1 for name in support96)
all_c258_8712 = all(terms258[name] == 8712 for name in support258)

out = {
    "instance": "s82",
    "claim": "A8_11 is forced to zero in every feasible solution",
    "row_c96": {
        "canonical_form": "-A8_11 + S >= 0",
        "sense": c96.Sense,
        "rhs": c96.RHS,
        "path_term_count": len(support96),
        "all_path_coefficients_one": all_c96_unit,
    },
    "row_c258": {
        "canonical_form": "8712*S <= 6500",
        "sense": c258.Sense,
        "rhs": c258.RHS,
        "path_term_count": len(support258),
        "all_path_coefficients_8712": all_c258_8712,
    },
    "same_path_support": same_support,
    "all_path_terms_binary_0_1": all_binary,
    "upper_bound_on_S": 6500 / 8712,
    "derivation": [
        "c258 gives S <= 6500/8712 < 1.",
        "S is a sum of 93 binary variables, hence S is a nonnegative integer and S=0.",
        "c96 gives A8_11 <= S=0; together with A8_11>=0, A8_11=0.",
    ],
    "machine_check_passed": same_support
    and all_binary
    and all_c96_unit
    and all_c258_8712
    and terms96.get("A8_11") == -1
    and c96.Sense == ">"
    and c96.RHS == 0
    and c258.Sense == "<"
    and c258.RHS == 6500,
    "path_variables": sorted(support96),
}
args.output.write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8")
print(json.dumps({k: v for k, v in out.items() if k != "path_variables"}, indent=2))
