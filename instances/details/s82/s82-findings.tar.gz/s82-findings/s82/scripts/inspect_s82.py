import collections
import gzip
import hashlib
import json
import math
import re
import time
from pathlib import Path

import gurobipy as gp
import numpy as np


ROOT = Path(r"D:\sufe\code\AI+MIP\direct-api-research\batch-20260908\s82")
MPS = ROOT / "input" / "s82-official.mps.gz"
SOL = ROOT / "input" / "s82.sol"
OUT = ROOT / "results" / "structure-and-public-audit.json"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(8 << 20), b""):
            h.update(block)
    return h.hexdigest()


def prefix(name: str) -> str:
    match = re.match(r"[A-Za-z]+", name)
    return match.group(0) if match else name.split("_")[0]


def parse_sol(path: Path):
    values = {}
    declared_obj = None
    with path.open("r", encoding="utf-8") as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            fields = line.split()
            if fields[0].startswith("=obj="):
                declared_obj = float(fields[-1])
            elif len(fields) >= 2:
                values[fields[0]] = float(fields[1])
    return declared_obj, values


started = time.time()
m = gp.read(str(MPS))
m.update()
read_seconds = time.time() - started

vars_ = m.getVars()
constrs = m.getConstrs()
names = m.getAttr("VarName", vars_)
row_names = m.getAttr("ConstrName", constrs)
vtypes = m.getAttr("VType", vars_)
lbs = np.asarray(m.getAttr("LB", vars_), dtype=float)
ubs = np.asarray(m.getAttr("UB", vars_), dtype=float)
obj = np.asarray(m.getAttr("Obj", vars_), dtype=float)
rhs = np.asarray(m.getAttr("RHS", constrs), dtype=float)
senses = np.asarray(m.getAttr("Sense", constrs))
A = m.getA().tocsr()

declared_obj, sol_values = parse_sol(SOL)
name_to_index = {name: i for i, name in enumerate(names)}
unknown = sorted(set(sol_values) - set(name_to_index))
x = np.zeros(m.NumVars, dtype=float)
for name, value in sol_values.items():
    idx = name_to_index.get(name)
    if idx is not None:
        x[idx] = value

activity = A.dot(x)
row_violation = np.zeros(m.NumConstrs, dtype=float)
le = senses == "<"
ge = senses == ">"
eq = senses == "="
row_violation[le] = np.maximum(activity[le] - rhs[le], 0.0)
row_violation[ge] = np.maximum(rhs[ge] - activity[ge], 0.0)
row_violation[eq] = np.abs(activity[eq] - rhs[eq])
bound_violation = np.maximum(np.maximum(lbs - x, x - ubs), 0.0)
integer_mask = np.asarray([t in (gp.GRB.BINARY, gp.GRB.INTEGER) for t in vtypes])
integrality_violation = np.zeros(m.NumVars, dtype=float)
integrality_violation[integer_mask] = np.abs(
    x[integer_mask] - np.rint(x[integer_mask])
)

largest_rows = np.argsort(row_violation)[-20:][::-1]
largest_bounds = np.argsort(bound_violation)[-20:][::-1]
largest_int = np.argsort(integrality_violation)[-20:][::-1]
row_nnz = A.getnnz(axis=1)
col_nnz = A.getnnz(axis=0)

nonzero_obj = obj[np.abs(obj) > 0]
unique_obj, unique_obj_counts = np.unique(nonzero_obj, return_counts=True)
obj_frequency = sorted(
    zip(unique_obj.tolist(), unique_obj_counts.tolist()),
    key=lambda pair: (-pair[1], pair[0]),
)[:30]

result = {
    "instance": "s82",
    "timestamp_local": time.strftime("%Y-%m-%d %H:%M:%S %z"),
    "read_seconds": read_seconds,
    "files": {
        "mps": str(MPS),
        "mps_sha256": sha256(MPS),
        "public_solution": str(SOL),
        "public_solution_sha256": sha256(SOL),
    },
    "model": {
        "model_name": m.ModelName,
        "objective_sense": "min" if m.ModelSense == gp.GRB.MINIMIZE else "max",
        "objective_constant": m.ObjCon,
        "rows": m.NumConstrs,
        "cols": m.NumVars,
        "nonzeros": m.NumNZs,
        "quadratic_nonzeros": m.NumQNZs,
        "sos": m.NumSOS,
        "general_constraints": m.NumGenConstrs,
        "var_types": dict(collections.Counter(vtypes)),
        "constraint_senses": dict(collections.Counter(senses.tolist())),
        "objective_nonzeros": int(nonzero_obj.size),
        "objective_min": float(nonzero_obj.min()) if nonzero_obj.size else 0.0,
        "objective_max": float(nonzero_obj.max()) if nonzero_obj.size else 0.0,
        "objective_value_frequency_top30": obj_frequency,
        "var_name_prefix_top30": collections.Counter(map(prefix, names)).most_common(30),
        "row_name_prefix_top30": collections.Counter(map(prefix, row_names)).most_common(30),
        "row_nnz": {
            "min": int(row_nnz.min()),
            "median": float(np.median(row_nnz)),
            "mean": float(row_nnz.mean()),
            "max": int(row_nnz.max()),
            "zero": int(np.count_nonzero(row_nnz == 0)),
        },
        "col_nnz": {
            "min": int(col_nnz.min()),
            "median": float(np.median(col_nnz)),
            "mean": float(col_nnz.mean()),
            "max": int(col_nnz.max()),
            "zero": int(np.count_nonzero(col_nnz == 0)),
        },
        "continuous_nonzero_solution_names": [
            names[i]
            for i, t in enumerate(vtypes)
            if t == gp.GRB.CONTINUOUS and abs(x[i]) > 0
        ],
        "sample_var_names": names[:80],
        "sample_row_names": row_names[:80],
    },
    "public_solution_audit": {
        "declared_objective": declared_obj,
        "recomputed_objective": float(m.ObjCon + obj.dot(x)),
        "listed_nonzeros": len(sol_values),
        "unknown_names": unknown,
        "max_bound_violation": float(bound_violation.max()),
        "num_bound_violations_gt_1e-9": int(np.count_nonzero(bound_violation > 1e-9)),
        "max_integrality_violation": float(integrality_violation.max()),
        "num_integrality_violations_gt_1e-9": int(
            np.count_nonzero(integrality_violation > 1e-9)
        ),
        "max_row_violation": float(row_violation.max()),
        "num_row_violations_gt_1e-9": int(np.count_nonzero(row_violation > 1e-9)),
        "num_row_violations_gt_1e-6": int(np.count_nonzero(row_violation > 1e-6)),
        "largest_row_violations": [
            {
                "row": row_names[i],
                "sense": senses[i],
                "lhs": float(activity[i]),
                "rhs": float(rhs[i]),
                "violation": float(row_violation[i]),
            }
            for i in largest_rows
            if row_violation[i] > 0
        ],
        "largest_bound_violations": [
            {
                "var": names[i],
                "value": float(x[i]),
                "lb": float(lbs[i]),
                "ub": float(ubs[i]),
                "violation": float(bound_violation[i]),
            }
            for i in largest_bounds
            if bound_violation[i] > 0
        ],
        "largest_integrality_violations": [
            {
                "var": names[i],
                "value": float(x[i]),
                "violation": float(integrality_violation[i]),
            }
            for i in largest_int
            if integrality_violation[i] > 0
        ],
    },
    "total_seconds": time.time() - started,
}

OUT.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
print(json.dumps(result, indent=2, ensure_ascii=False))
