import collections
import json
import re
from pathlib import Path

import gurobipy as gp
import numpy as np


ROOT = Path(r"D:\sufe\code\AI+MIP\direct-api-research\batch-20260908\s82")
MPS = ROOT / "input" / "s82-official.mps.gz"
SOL = ROOT / "input" / "s82.sol"
OUT = ROOT / "results" / "recovered-structure.json"


def broad(name):
    if name.startswith("variable_volumen"):
        return "volume"
    for tag in ("Atp", "Atr", "Tp", "FC", "Slinea"):
        if name.startswith(tag):
            return tag
    if name.startswith("A"):
        return "A_other"
    if name.startswith("F"):
        return "F"
    return "other"


values = {}
for raw in SOL.read_text(encoding="utf-8").splitlines():
    fields = raw.split()
    if len(fields) >= 2 and not fields[0].startswith("=obj="):
        values[fields[0]] = float(fields[1])

m = gp.read(str(MPS))
m.update()
vars_ = m.getVars()
names = m.getAttr("VarName", vars_)
obj = m.getAttr("Obj", vars_)
lb = m.getAttr("LB", vars_)
ub = m.getAttr("UB", vars_)
vtype = m.getAttr("VType", vars_)

counts = collections.Counter()
selected = collections.Counter()
samples = collections.defaultdict(list)
selected_samples = collections.defaultdict(list)
domain_counts = collections.Counter()
regex_counts = collections.Counter()
parsed_index_stats = collections.defaultdict(lambda: collections.defaultdict(set))

patterns = [
    ("Atp_4index", re.compile(r"^Atp_(\d+)tr_(\d+)_li(\d+)$")),
    ("Atr_4index", re.compile(r"^Atr_(\d+)tr_(\d+)_li(\d+)$")),
    ("A_4index", re.compile(r"^A(\d+)_(\d+)tr_(\d+)_li(\d+)$")),
    ("A_2index", re.compile(r"^A(\d+)_(\d+)$")),
    ("Tp", re.compile(r"^Tp_(\d+)$")),
    ("FC", re.compile(r"^FC_(\d+)$")),
    ("Slinea", re.compile(r"^Slinea_(\d+)$")),
    ("F", re.compile(r"^F_(\d+)$")),
    ("volume", re.compile(r"^variable_volumen(\d+)$")),
]

for i, name in enumerate(names):
    group = broad(name)
    counts[group] += 1
    domain_counts[(group, vtype[i], lb[i], ub[i])] += 1
    if len(samples[group]) < 12:
        samples[group].append({"name": name, "obj": obj[i], "lb": lb[i], "ub": ub[i]})
    if name in values and abs(values[name]) > 1e-12:
        selected[group] += 1
        if len(selected_samples[group]) < 25:
            selected_samples[group].append(
                {"name": name, "value": values[name], "obj": obj[i]}
            )
    for label, pattern in patterns:
        match = pattern.match(name)
        if match:
            regex_counts[label] += 1
            for pos, val in enumerate(match.groups()):
                parsed_index_stats[label][str(pos)].add(int(val))
            break

# Detailed row blocks by contiguous matrix signature.
A = m.getA().tocsr()
rhs = np.asarray(m.getAttr("RHS", m.getConstrs()), dtype=float)
sense = m.getAttr("Sense", m.getConstrs())
row_nnz = A.getnnz(axis=1)
row_signature = []
for i in range(m.NumConstrs):
    start, end = A.indptr[i], A.indptr[i + 1]
    coeff = A.data[start:end]
    if coeff.size == 0:
        coef_key = "empty"
    elif np.all(coeff == 1):
        coef_key = "all+1"
    elif np.all(coeff == -1):
        coef_key = "all-1"
    elif np.all(np.isin(coeff, (-1.0, 1.0))):
        coef_key = "pm1"
    else:
        coef_key = "general"
    row_signature.append((sense[i], int(row_nnz[i]), float(rhs[i]), coef_key))

blocks = []
block_start = 0
previous = row_signature[0]
for i in range(1, len(row_signature) + 1):
    current = row_signature[i] if i < len(row_signature) else None
    if current != previous:
        blocks.append(
            {
                "start_row_1based": block_start + 1,
                "end_row_1based": i,
                "count": i - block_start,
                "sense": previous[0],
                "nnz": previous[1],
                "rhs": previous[2],
                "coefficient_class": previous[3],
            }
        )
        block_start = i
        previous = current

largest_rows = np.argsort(row_nnz)[-30:][::-1]
out = {
    "counts": counts,
    "selected_nonzeros": selected,
    "samples": samples,
    "selected_samples": selected_samples,
    "domain_counts": [
        {"group": key[0], "vtype": key[1], "lb": key[2], "ub": key[3], "count": count}
        for key, count in domain_counts.most_common()
    ],
    "regex_counts": regex_counts,
    "parsed_index_ranges": {
        label: {
            pos: {"min": min(vals), "max": max(vals), "unique": len(vals)}
            for pos, vals in positions.items()
        }
        for label, positions in parsed_index_stats.items()
    },
    "contiguous_row_blocks": blocks,
    "largest_rows": [
        {
            "row_1based": int(i + 1),
            "name": f"c{i+1}",
            "sense": sense[i],
            "rhs": rhs[i],
            "nnz": int(row_nnz[i]),
            "sample_vars": [names[j] for j in A.indices[A.indptr[i]:A.indptr[i+1]][:20]],
        }
        for i in largest_rows
    ],
}
OUT.write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8")
print(json.dumps(out, indent=2, ensure_ascii=False))
