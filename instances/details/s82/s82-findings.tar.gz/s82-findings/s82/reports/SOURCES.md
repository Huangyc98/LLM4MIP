# s82 背景与来源

## 与本实例直接相关的一手来源

1. **MIPLIB 2017 官方实例页**  
   https://miplib.zib.de/instance_details_s82.html  
   官方页将 `s82` 描述为“82 个作业、4 台加工机器的葡萄酒排程问题”，提交者为 Daniel Espinoza，来源为 MIPLIB 2010 submissions；截至页面最新状态仍为 `open`，当前公开 primal 为 `-33.7970576238223`。官方页还给出原始模型的 1,690,631 个变量、87,878 条约束及分类统计。页面明确注明没有可用的 bibliographic information。

2. **MIPLIB 官方实例与解文件**  
   实例：https://miplib.zib.de/WebData/instances/s82.mps.gz  
   当前解：https://miplib.zib.de/downloads/solutions/s82/3/s82.sol.gz  
   原始结构分解链接：https://miplib.zib.de/WebData/decomps_orig/s82.dec  
   本研究保留下载文件、SHA-256 以及原始 MPS 上的独立可行性审计。该结构分解链接实际返回了网站错误页而不是 `.dec` 内容，因此没有把它当作有效分解证据；错误响应另存为 `s82-dec-download-error.html`。

3. **PartiMIP 的官方论文**  
   Peng Lin, Shaowei Cai, Mengchuan Zou, Shengqi Chen, “Parallel MIP Solving with Dynamic Task Decomposition,” CP 2025.  
   DOI：https://doi.org/10.4230/LIPIcs.CP.2025.26  
   论文提出动态任务分解的并行 MIP 框架；MIPLIB 页面记载当前 `s82` 解由 Peng Lin 与 Shaowei Cai 于 2024-10-02 提交，说明为 PartiMIP。

4. **PartiMIP 官方代码和记录仓库**  
   https://github.com/shaowei-cai-group/PartiMIP  
   本地审查提交：`044cee49a0e98914d73ef855f3d5ad69e5dbfa00`。仓库 `Record/s82.sol.gz` 与 MIPLIB 当前下载文件 SHA-256 完全相同：`d7c5e7476436b69d008400975c3e45933a51f97bdb1e051edd864216ff6cfc59`。这表明当前公开解确为该项目发布的记录解。

5. **MIPLIB 2010 论文与官方站点**  
   T. Koch et al., “MIPLIB 2010: Mixed Integer Programming Library version 5,” Mathematical Programming Computation 3, 103–163 (2011).  
   DOI：https://doi.org/10.1007/s12532-011-0025-9  
   官方站：https://miplib2010.zib.de/  
   用于确认实例的 MIPLIB 2010 submission 背景以及基准库对精确解检查的要求；论文并没有公开 `s82` 的专门数学模型。

## 领域背景（相关但不能视为 s82 的原始模型来源）

6. **葡萄酒灌装排程的并行机背景**  
   C. Cataldo et al., “A MIP formulation and a heuristic solution approach for the bottling scheduling problem in the wine industry,” Computers & Industrial Engineering 105 (2017), 136–145.  
   DOI：https://doi.org/10.1016/j.cie.2016.12.029  
   该论文说明葡萄酒灌装订单需分配到生产线，模型可退化为 NP-hard 的并行机排程问题，并开发贪心构造启发式。由于发表时间晚于 MIPLIB 2010 submission，**它只作为领域背景，不能声称是 `s82` 的原始论文或同一模型**。

## 证据边界

- MIPLIB 官方页明确写明 `No bibliographic information available`，所以没有把后来发表的葡萄酒排程论文冒充为 `s82` 的原始来源。
- `s82` 的具体语义主要从官方 MPS 变量名与稀疏结构恢复；恢复出的结构会在报告中标记为“从模型推断”，而不是作为论文中的已知事实。
- 全局最优只接受完整 gap closure 或可复核证书；局部邻域最优与限时未改进会单独标记。
