# s82 — exact high-level result max sum(A8) = 36

Official MIPLIB page: <https://miplib.zib.de/instance_details_s82.html>

## Result

The public objective `-33.7970576238223` remains the best strict primal in this
study.  The full objective is **not** proved globally optimal.

The new global structural conclusion is that at most 36 of the 42 high-level
acceptance variables `A8_j` can be selected, and the public solution selects
exactly those 36.  Hence:

```text
max sum_j A8_j = 36
```

This cardinality result is global and solver-independent, but it does not close
the full weighted objective, which also contains volume, route and timing
terms.

## Two-row proof

Five omitted variables are fixed to zero by singleton original-MPS rows:
`A8_2`, `A8_3`, `A8_8`, `A8_12`, and `A8_41`.

For the only remaining omitted variable, let `S` be the sum of the same 93
binary path variables appearing in rows `c96` and `c258`:

```text
c96:  -A8_11 + S >= 0
c258: 8712 S <= 6500
```

Since `S` is a nonnegative integer and `6500/8712 < 1`, the second row gives
`S=0`; the first then gives `A8_11=0`.  Thus six of 42 acceptance variables
are globally impossible.  The compact machine check is
[`a8-11-two-row-certificate.json`](artifacts/a8-11-two-row-certificate.json).
The publication-copy replay of the portable command is
[`replay-a8-11-two-row-certificate.json`](artifacts/replay-a8-11-two-row-certificate.json).

## Model and additional experiments

Gurobi reads 1,690,631 variables, 87,878 rows and 7,022,608 nonzeros.  The
public solution has no bound or integrality violation and maximum row violation
`5.82e-11`.

With the other three production-line paths fixed, line 4 was reoptimized to
zero gap with no improvement.  Lines 0, 1 and 2 were explored for 420, 180 and
180 seconds; they did not improve the incumbent but did not close, so no local
optimality claim is made for those lines.

The detailed Chinese report is
[`deep-study-2026-09-08.zh.md`](reports/deep-study-2026-09-08.zh.md).

## Input provenance and reproduction

The 47.17 MiB official MPS is not duplicated in this Git repository.  Download
it from MIPLIB and verify SHA-256
`c8c38e3cd2fd4cf20a749d8e245a37b1301978da5d5bc77c8b88d0b6b8570fc4`.
The public solution is archived locally and identified in
[`input/SHA256SUMS`](input/SHA256SUMS).

After saving the model as `input/s82-official.mps.gz`, replay the decisive
certificate with:

```sh
python scripts/a8_11_certificate.py \
  input/s82-official.mps.gz /tmp/a8-11-certificate.json
```
