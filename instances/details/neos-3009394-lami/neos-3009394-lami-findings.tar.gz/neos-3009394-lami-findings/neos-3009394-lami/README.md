# `neos-3009394-lami`

## Result

The published objective **5.5 is globally optimal**.  This study gives an exact,
independently reproducible proof:

```text
OPT = 5.5.
```

The original 2,757-variable MIP reduces exactly to assigning 26 labelled points
injectively to the 30 cells of a 5-by-6 integer grid.  At every objective below
5.5, the sixth grid row is unavailable, leaving only 25 cells for 26 distinct
points.  This one-unit Hall deficiency proves the lower bound.  A generated
matching solution at 5.5 passes all 2,028 original MPS rows, bounds, and
integrality conditions with zero tolerance.

## Input and provenance

- MPS SHA-256: `E394F664A010D3AEDDBBD8494A85A66B673A57E6BFD8F5C0AF8849168D3E0E0B`
- Official compressed solution SHA-256: `44AFAB472B7C73AD2A8AAD518853B82059D4552D6E159FA94C333C78D9C9C750`
- Reconstructed optimal solution SHA-256: `18186465ED9B83CDE205BA8A116C6EE4FD097C6CCF0616D961870D28FB72029A`
- [MIPLIB instance page](https://miplib.zib.de/instance_details_neos-3009394-lami.html)
- [MIPLIB download and solution archives](https://miplib.zib.de/download.html)

MIPLIB currently lists the instance as open.  Its exact 5.5 solution was found
during the MIPLIB 2017 selection process and published in October 2018.

## Recovered structure

The variables are

- one continuous objective variable `t = C0001`;
- 2,704 binary variables;
- 26 first coordinates `a_i` in `{0,...,4}`; and
- 26 second coordinates `b_i` in `{0,...,5}`.

The 676 set-partitioning rows form a 26-by-26 array with four binary options per
cell.  Only the 325 strict upper-triangular cells represent unordered point
pairs.  Their 1,300 active binaries select one of

```text
a_i > a_j,  a_i < a_j,  b_i > b_j,  b_i < b_j.
```

Thus every pair of points must occupy different grid cells.  The 1,404 binaries
in the diagonal and lower triangle occur only in their one-hot rows and are
irrelevant.  Gurobi presolve independently removes exactly those 1,404 columns.

For each labelled point the final two rows impose

```text
t >=  a_i + b_i + c_i
t >= -a_i + b_i + d_i,
```

where `c_i` and `d_i` are the exact decimal right-hand sides stored in the MPS.
The objective is to minimize the maximum of these 52 expressions.

## Exact lower-bound certificate

[`solve_bottleneck_matching.py`](scripts/solve_bottleneck_matching.py) enumerates
the exact MPS-decimal cost of every item-cell edge and solves a bipartite
bottleneck matching using only the Python standard library.

For every item and every first coordinate, a cell with `b_i=5` costs at least
5.5.  Therefore a hypothetical solution with `t<5.5` can use only

```text
5 first coordinates * 5 remaining second coordinates = 25 cells.
```

The four-way pair disjunctions require 26 distinct cells, a contradiction.  In
matching language, at the predecessor threshold `5.428571429`, the set of all
26 items has only the 25 cells with `b<=4` as neighbors.  The certificate records
this Hall witness explicitly.  At threshold 5.5 a matching of all 26 items
exists, and the script translates it back to every original MPS variable.

The full structural audit and solve take about 0.15 seconds on the local
machine; the proof does not require a commercial solver.

## Experiments

| Method | CPU threads | Limit | Result |
|---|---:|---:|---|
| Gurobi 13.0.1, original MPS, official start | 64 | 300 s | incumbent 5.5; bound 1.7142857143; 3,737,930 nodes |
| COPT 8.0.4, original MPS, official start | 64 | 300 s | incumbent 5.5; bound 1.642857143; 2,289,531 nodes |
| exact bottleneck matching + Hall witness | 1 | 0.15 s | **proved `OPT=5.5`** |

Both generic MIP runs timed out with gaps above 68%.  All COPT work on
`altman` used CPU only; **GPU0 was not used**.

## Reproduction

Run from the repository root:

```powershell
python .\instances\neos-3009394-lami\scripts\analyze_structure.py `
  .\instances\neos-3009394-lami\input\neos-3009394-lami.mps.gz `
  .\instances\neos-3009394-lami\solutions\official-5.5.sol `
  --json .\instances\neos-3009394-lami\artifacts\structure-and-solution-audit.json

python .\instances\neos-3009394-lami\scripts\solve_bottleneck_matching.py `
  .\instances\neos-3009394-lami\input\neos-3009394-lami.mps.gz `
  --official-solution .\instances\neos-3009394-lami\solutions\official-5.5.sol `
  --certificate .\instances\neos-3009394-lami\artifacts\bottleneck-matching-certificate.json `
  --solution-output .\instances\neos-3009394-lami\solutions\matching-optimal.sol

python .\common\exact_mps_solution_check.py `
  .\instances\neos-3009394-lami\input\neos-3009394-lami.mps.gz `
  .\instances\neos-3009394-lami\solutions\matching-optimal.sol --tolerance 0
```

See the [Chinese study report](reports/neos-3009394-lami-study-zh.md),
[`artifacts/`](artifacts/), and [`logs/`](logs/).
