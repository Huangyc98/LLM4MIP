#!/usr/bin/env python3
"""Recover the repeated structure of neos-3009394-lami from its MPS."""

from __future__ import annotations

import argparse
import collections
import gzip
import json
import math
from pathlib import Path


SECTIONS = {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}


def open_text(path: Path):
    return gzip.open(path, "rt", encoding="latin-1") if path.suffix == ".gz" else path.open("rt", encoding="latin-1")


def parse_mps(path: Path):
    row_type: dict[str, str] = {}
    rhs: dict[str, float] = collections.defaultdict(float)
    rows: dict[str, dict[str, float]] = collections.defaultdict(dict)
    objective: dict[str, float] = collections.defaultdict(float)
    lower: dict[str, float] = collections.defaultdict(float)
    upper: dict[str, float] = {}
    variables: set[str] = set()
    integers: set[str] = set()
    integer_mode = False
    objective_row = None
    section = None
    with open_text(path) as handle:
        for raw in handle:
            fields = raw.split()
            if not fields or fields[0].startswith("*"):
                continue
            if not raw[0].isspace() and fields[0] in SECTIONS:
                section = fields[0]
                continue
            if section == "ROWS":
                row_type[fields[1]] = fields[0]
                if fields[0] == "N":
                    objective_row = fields[1]
            elif section == "COLUMNS":
                if "'MARKER'" in fields:
                    integer_mode = "'INTORG'" in fields
                    continue
                variable = fields[0]
                variables.add(variable)
                if integer_mode:
                    integers.add(variable)
                for offset in range(1, len(fields), 2):
                    row, value = fields[offset], float(fields[offset + 1])
                    if row == objective_row:
                        objective[variable] += value
                    else:
                        rows[row][variable] = rows[row].get(variable, 0.0) + value
            elif section == "RHS":
                for offset in range(1, len(fields), 2):
                    rhs[fields[offset]] += float(fields[offset + 1])
            elif section == "BOUNDS":
                kind, variable = fields[0], fields[2]
                value = float(fields[3]) if len(fields) > 3 else 0.0
                if kind == "LO":
                    lower[variable] = value
                elif kind == "UP":
                    upper[variable] = value
                elif kind == "FX":
                    lower[variable] = upper[variable] = value
                elif kind == "BV":
                    lower[variable], upper[variable] = 0.0, 1.0
                    integers.add(variable)
                elif kind == "FR":
                    lower[variable], upper[variable] = -math.inf, math.inf
                elif kind == "MI":
                    lower[variable] = -math.inf
                elif kind == "PL":
                    upper[variable] = math.inf
                elif kind == "LI":
                    lower[variable] = value
                    integers.add(variable)
                elif kind == "UI":
                    upper[variable] = value
                    integers.add(variable)
                else:
                    raise ValueError(f"unsupported bound type {kind}")
    return row_type, rhs, rows, objective, lower, upper, variables, integers


def read_solution(path: Path) -> dict[str, float]:
    values = {}
    with path.open("rt", encoding="utf-8") as handle:
        for raw in handle:
            fields = raw.split()
            if len(fields) != 2 or fields[0].startswith(("#", "=")):
                continue
            values[fields[0]] = float(fields[1])
    return values


def variable_number(name: str) -> int:
    if not name.startswith("C") or not name[1:].isdigit():
        raise ValueError(f"unexpected variable name {name}")
    return int(name[1:])


def family(variable: str, binaries: set[str], general_integers: set[str], continuous: set[str]) -> str:
    if variable in binaries:
        return "binary"
    if variable in general_integers:
        return "integer"
    if variable in continuous:
        return "continuous"
    raise RuntimeError(variable)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()

    row_type, rhs, rows, objective, lower, upper, variables, integers = parse_mps(args.mps)
    values = read_solution(args.solution)
    binaries = {v for v in integers if lower[v] == 0 and upper.get(v) == 1}
    general_integers = integers - binaries
    continuous = variables - integers

    partition_rows = []
    for row, coefficients in rows.items():
        if (
            row_type[row] == "E"
            and rhs[row] == 1
            and len(coefficients) == 4
            and set(coefficients.values()) == {1.0}
            and set(coefficients) <= binaries
        ):
            partition_rows.append(row)
    partition_rows.sort()
    side = math.isqrt(len(partition_rows))
    if side * side != len(partition_rows):
        raise RuntimeError("set-partitioning rows do not form a square")

    option_by_binary = {}
    selected_option = []
    partition_supports = []
    for index, row in enumerate(partition_rows):
        support = sorted(rows[row], key=variable_number)
        partition_supports.append(support)
        for option, variable in enumerate(support):
            option_by_binary[variable] = (index, option)
        chosen = [option for option, variable in enumerate(support) if values.get(variable, 0.0) > 0.5]
        if len(chosen) != 1:
            raise RuntimeError(f"official solution does not select one option in {row}")
        selected_option.append(chosen[0])

    row_signatures = collections.Counter()
    detailed_nonpartition_signatures = collections.Counter()
    for row, coefficients in rows.items():
        coefficient_signature = tuple(sorted(round(value, 12) for value in coefficients.values()))
        row_signatures[(row_type[row], round(rhs[row], 12), len(coefficients), coefficient_signature)] += 1
        if row not in set(partition_rows):
            family_counts = collections.Counter(family(v, binaries, general_integers, continuous) for v in coefficients)
            detailed_nonpartition_signatures[
                (
                    row_type[row],
                    round(rhs[row], 12),
                    tuple(sorted(family_counts.items())),
                    coefficient_signature,
                )
            ] += 1

    integer_values = [round(values.get(v, 0.0)) for v in sorted(general_integers, key=variable_number)]
    option_matrix = [selected_option[offset : offset + side] for offset in range(0, len(selected_option), side)]

    # Determine how every non-partition row touches grid cells and auxiliary variables.
    grid_row_patterns = collections.Counter()
    for row, coefficients in rows.items():
        if row in set(partition_rows):
            continue
        cells = sorted({option_by_binary[v][0] for v in coefficients if v in option_by_binary})
        integer_vars = sorted((v for v in coefficients if v in general_integers), key=variable_number)
        continuous_vars = sorted(v for v in coefficients if v in continuous)
        cell_coordinates = [(cell // side, cell % side) for cell in cells]
        if len(cell_coordinates) == 2:
            (r1, c1), (r2, c2) = cell_coordinates
            relationship = "same_row" if r1 == r2 else "same_column" if c1 == c2 else "other"
            separation = abs(c1 - c2) if r1 == r2 else abs(r1 - r2) if c1 == c2 else -1
        elif len(cell_coordinates) == 1:
            relationship, separation = "single_cell", 0
        elif not cell_coordinates:
            relationship, separation = "no_cell", 0
        else:
            relationship, separation = "multi_cell", -1
        grid_row_patterns[(relationship, separation, len(integer_vars), len(continuous_vars), len(cells))] += 1

    result = {
        "instance": "neos-3009394-lami",
        "variables": len(variables),
        "constraints": len(rows),
        "nonzeros": sum(len(coefficients) for coefficients in rows.values()),
        "variable_counts": {
            "binary": len(binaries),
            "integer": len(general_integers),
            "continuous": len(continuous),
        },
        "objective_coefficients": dict(sorted(collections.Counter(objective.values()).items())),
        "set_partitioning_rows": len(partition_rows),
        "partition_grid_side": side,
        "options_per_grid_cell": sorted({len(support) for support in partition_supports}),
        "selected_option_histogram": dict(sorted(collections.Counter(selected_option).items())),
        "selected_option_matrix": option_matrix,
        "general_integer_bounds": [
            {"lower": bounds[0], "upper": bounds[1], "count": count}
            for bounds, count in sorted(
                collections.Counter((lower[v], upper.get(v, math.inf)) for v in general_integers).items()
            )
        ],
        "official_general_integer_values": integer_values,
        "official_continuous_values": {v: values.get(v, 0.0) for v in sorted(continuous)},
        "row_signature_counts": [
            {
                "count": count,
                "sense": key[0],
                "rhs": key[1],
                "nonzeros": key[2],
                "coefficients": list(key[3]),
            }
            for key, count in row_signatures.most_common()
        ],
        "nonpartition_signature_counts": [
            {
                "count": count,
                "sense": key[0],
                "rhs": key[1],
                "families": dict(key[2]),
                "coefficients": list(key[3]),
            }
            for key, count in detailed_nonpartition_signatures.most_common()
        ],
        "grid_row_patterns": [
            {
                "count": count,
                "relationship": key[0],
                "separation": key[1],
                "integer_variables": key[2],
                "continuous_variables": key[3],
                "grid_cells": key[4],
            }
            for key, count in grid_row_patterns.most_common()
        ],
        "checks": {
            "partition_rows_are_26_by_26": side == 26,
            "four_options_per_cell": len(partition_rows) * 4 == len(binaries),
            "all_binaries_are_in_one_partition": len(option_by_binary) == len(binaries),
            "two_integer_vectors_of_length_26": len(general_integers) == 2 * side,
            "one_continuous_variable": len(continuous) == 1,
        },
    }
    if not all(result["checks"].values()):
        raise SystemExit("one or more structural checks failed")
    rendered = json.dumps(result, indent=2, ensure_ascii=False)
    print(rendered)
    if args.json:
        args.json.write_text(rendered + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
