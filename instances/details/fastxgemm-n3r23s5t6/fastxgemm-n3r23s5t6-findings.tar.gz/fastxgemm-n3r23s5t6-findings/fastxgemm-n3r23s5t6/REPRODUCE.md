# Reproduce `fastxgemm-n3r23s5t6` continuation

Date: 2026-09-09. Run commands from this instance directory with Python 3.13;
the official-MPS completion and probes additionally require Gurobi 13.0.2.

The original MPS is archived at `input/fastxgemm-n3r23s5t6.mps.gz`.

## External BILR construction

The exact source transcription and official-MPS completion scripts are in
`artifacts/external-audit/`:

```powershell
python .\artifacts\external-audit\verify_ballard_laderman_z3.py `
  .\artifacts\external-audit\ballard-laderman-z3-audit.json

python .\artifacts\external-audit\complete_ballard_candidate_on_mps.py `
  .\input\fastxgemm-n3r23s5t6.mps.gz `
  .\artifacts\external-audit\ballard-laderman-z3-audit.json `
  --solution .\solutions\external-bilr2018-strict-153.sol `
  --report .\artifacts\external-audit\ballard-laderman-z3-mps-completion.json `
  --log .\artifacts\external-audit\ballard-laderman-z3-mps-completion.log
```

Expected audited statistics are `E=0`, `K=51`, objective 153, and zero row,
bound, integrality, and exact tensor violations. The archived strict solution is
`solutions/external-bilr2018-strict-153.sol`.

## Lower bound 90

```powershell
python .\scripts\verify_lb90_combinatorics.py `
  --json .\artifacts\lb90_combinatorial_audit.json

python .\scripts\build_and_probe_lb90.py `
  .\input\fastxgemm-n3r23s5t6.mps.gz `
  --solution .\artifacts\bilr-equivalent-shear-strict-153.sol `
  --output-model .\artifacts\fastxgemm-n3r23s5t6-lb90.mps.gz `
  --json .\artifacts\lb90_probe.json `
  --original-lp-log .\logs\lb90_original_lp.log `
  --augmented-lp-log .\logs\lb90_augmented_lp.log `
  --root-log .\logs\lb90_augmented_root.log
```

The finite audit must report all 9,108 cases checked and no counterexample.
The probe should report original LP 84 and augmented LP/root bound 90.

## Bounded conjugation and truncation search

```powershell
python .\scripts\truncation_conjugation_orbit.py `
  .\solutions\author-2017-exact-174.sol `
  --json .\artifacts\truncation_conjugation_orbit.json `
  --r22-core .\artifacts\truncation_orbit_best_r22_core.sol `
  --r21-core .\artifacts\truncation_orbit_best_r21_core.sol
```

Expected finite-domain minima are 153 for R23, 1150 for one fixed-A deletion
(R22), and 2147 for two fixed-A deletions (R21). These are scoped enumeration
results, not global optimality proofs.
