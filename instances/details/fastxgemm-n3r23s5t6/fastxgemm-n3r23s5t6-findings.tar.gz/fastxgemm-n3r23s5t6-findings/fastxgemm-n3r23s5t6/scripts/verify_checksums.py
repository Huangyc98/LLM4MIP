#!/usr/bin/env python3
"""Verify byte counts and SHA-256 digests listed in an input manifest."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def digest(path: Path) -> str:
    hasher = hashlib.sha256()
    buffer = memoryview(bytearray(1024 * 1024))
    with path.open("rb", buffering=0) as stream:
        while count := stream.readinto(buffer):
            hasher.update(buffer[:count])
    return hasher.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "manifest",
        type=Path,
        nargs="?",
        default=Path("artifacts/input_checksums.json"),
    )
    args = parser.parse_args()
    data = json.loads(args.manifest.read_text(encoding="utf-8"))
    root = args.manifest.parent.parent
    failures = []
    for record in data["files"]:
        path = root / record["path"]
        actual_bytes = path.stat().st_size if path.exists() else None
        actual_sha256 = digest(path) if path.exists() else None
        ok = actual_bytes == record["bytes"] and actual_sha256 == record["sha256"]
        print(f"{'OK' if ok else 'FAIL'}  {record['path']}")
        if not ok:
            failures.append(
                {
                    "path": record["path"],
                    "expected_bytes": record["bytes"],
                    "actual_bytes": actual_bytes,
                    "expected_sha256": record["sha256"],
                    "actual_sha256": actual_sha256,
                }
            )
    if failures:
        raise SystemExit(json.dumps(failures, indent=2))
    print(f"CHECKSUMS_OK {len(data['files'])}")


if __name__ == "__main__":
    main()
