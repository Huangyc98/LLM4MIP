#!/usr/bin/env python3
"""Exact semantic audit for fastxgemm-N3-R23-S5-T6 solutions.

The MIPLIB solution is a floating-point assignment to the linearized MILP.
This script reads only the 414 binary POS/NEG variables, reconstructs the
ternary A/B/C/D factors, expands the 3x3 matrix multiplication tensor using
integer arithmetic, and reports the exact residual and support objective.

No solver is used.  Consequently, E, K, and 1000*E + 3*K are exact integers.
"""

from __future__ import annotations

import argparse
import gzip
import json
import math
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple


N = 3
R = 23
S = 5
T = 6
BLOCK_WIDTHS = {"A": S, "B": T, "C": T, "D": T}


def open_text(path: Path):
    if path.suffix == ".gz":
        return gzip.open(path, "rt", encoding="utf-8")
    return path.open("r", encoding="utf-8")


def read_solution(path: Path) -> Tuple[Dict[str, float], float | None]:
    values: Dict[str, float] = {}
    stated_objective = None
    with open_text(path) as stream:
        for raw_line in stream:
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            fields = line.split()
            if fields[0] == "=obj=":
                stated_objective = float(fields[1])
                continue
            if len(fields) < 2:
                continue
            values[fields[0]] = float(fields[1])
    return values, stated_objective


def reconstruct_blocks(values: Dict[str, float], tolerance: float):
    blocks: Dict[str, List[List[int]]] = {}
    binary_diagnostics = []
    missing = []

    for letter, width in BLOCK_WIDTHS.items():
        matrix = [[0 for _ in range(width)] for _ in range(N * N)]
        for i in range(N * N):
            for col in range(width):
                names = (f"POS_{letter}_{i}_{col}", f"NEG_{letter}_{i}_{col}")
                if any(name not in values for name in names):
                    missing.extend(name for name in names if name not in values)
                    continue
                pos_raw, neg_raw = (values[name] for name in names)
                pos, neg = int(round(pos_raw)), int(round(neg_raw))
                if (
                    abs(pos_raw - pos) > tolerance
                    or abs(neg_raw - neg) > tolerance
                    or pos not in (0, 1)
                    or neg not in (0, 1)
                    or pos + neg > 1
                ):
                    binary_diagnostics.append(
                        {
                            "block": letter,
                            "row": i,
                            "column": col,
                            "pos": pos_raw,
                            "neg": neg_raw,
                        }
                    )
                matrix[i][col] = pos - neg
        blocks[letter] = matrix

    if missing:
        preview = ", ".join(missing[:10])
        raise ValueError(f"solution is missing {len(missing)} encoding variables: {preview}")
    if binary_diagnostics:
        raise ValueError(
            f"found {len(binary_diagnostics)} invalid/nonintegral POS/NEG pairs; "
            f"first={binary_diagnostics[0]}"
        )
    return blocks


def hstack(blocks: Sequence[List[List[int]]]) -> List[List[int]]:
    return [[value for block in blocks for value in block[row]] for row in range(N * N)]


def factors_from_blocks(blocks):
    a, b, c, d = (blocks[letter] for letter in "ABCD")
    u = hstack((a, b, c, d))
    v = hstack((a, d, b, c))
    w = hstack((a, c, d, b))
    assert all(len(row) == R for matrix in (u, v, w) for row in matrix)
    return u, v, w


def target_value(i: int, j: int, k: int) -> int:
    """Entry of the order-three matrix multiplication tensor.

    This is the direct integer equivalent of multiplication_tensor() in the
    instance author's model.py, which uses C-order np.ravel_multi_index.
    """
    for n in range(N):
        for m in range(N):
            for q in range(N):
                if i == n * N + q and j == q * N + m and k == m * N + n:
                    return 1
    return 0


def expand_entry(u, v, w, i: int, j: int, k: int) -> int:
    return sum(u[i][r] * v[j][r] * w[k][r] for r in range(R))


def cyclic_orbit(coordinate: Tuple[int, int, int]):
    i, j, k = coordinate
    return sorted({(i, j, k), (j, k, i), (k, i, j)})


def audit(path: Path, tolerance: float):
    values, stated_objective = read_solution(path)
    blocks = reconstruct_blocks(values, tolerance)
    u, v, w = factors_from_blocks(blocks)

    errors = []
    expansion_histogram: Dict[int, int] = {}
    residual_sum = 0
    max_abs_residual = 0
    for i in range(N * N):
        for j in range(N * N):
            for k in range(N * N):
                target = target_value(i, j, k)
                expansion = expand_entry(u, v, w, i, j, k)
                difference = target - expansion
                absolute = abs(difference)
                residual_sum += absolute
                max_abs_residual = max(max_abs_residual, absolute)
                expansion_histogram[expansion] = expansion_histogram.get(expansion, 0) + 1
                if difference:
                    errors.append(
                        {
                            "coordinate": [i, j, k],
                            "target": target,
                            "expansion": expansion,
                            "target_minus_expansion": difference,
                            "cyclic_orbit": [list(x) for x in cyclic_orbit((i, j, k))],
                        }
                    )

    k_support = sum(value != 0 for matrix in blocks.values() for row in matrix for value in row)
    full_factor_support = sum(value != 0 for matrix in (u, v, w) for row in matrix for value in row)
    assert full_factor_support == 3 * k_support
    exact_objective = 1000 * residual_sum + full_factor_support

    supplied_residuals = {
        name: value for name, value in values.items() if name.startswith("RESIDUAL_")
    }
    supplied_residual_sum = sum(supplied_residuals.values())
    negative_supplied_residuals = [
        {"variable": name, "value": value}
        for name, value in sorted(supplied_residuals.items())
        if value < 0
    ]

    row_degrees = {
        letter: [sum(value != 0 for value in row) for row in blocks[letter]]
        for letter in "ABCD"
    }
    underlying_column_support = {
        letter: [
            sum(blocks[letter][i][col] != 0 for i in range(N * N))
            for col in range(BLOCK_WIDTHS[letter])
        ]
        for letter in "ABCD"
    }

    return {
        "instance": "fastxgemm-n3r23s5t6",
        "input_solution": path.name,
        "interpretation": {
            "N": N,
            "R": R,
            "S": S,
            "T": T,
            "factor_domain": [-1, 0, 1],
            "cyclic_block_order": {
                "U": ["A", "B", "C", "D"],
                "V": ["A", "D", "B", "C"],
                "W": ["A", "C", "D", "B"],
            },
        },
        "stated_floating_point_objective": stated_objective,
        "exact_from_binary_pattern": {
            "E_tensor_l1_error": residual_sum,
            "K_underlying_ABCD_support": k_support,
            "full_UVW_support": full_factor_support,
            "objective_1000E_plus_3K": exact_objective,
            "strictly_below_public_exact_3090": exact_objective < 3090,
            "max_coordinate_absolute_error": max_abs_residual,
            "nonzero_error_coordinates": len(errors),
        },
        "supplied_residual_variables": {
            "count": len(supplied_residuals),
            "sum": supplied_residual_sum,
            "negative_count": len(negative_supplied_residuals),
            "negative_values": negative_supplied_residuals,
        },
        "errors": errors,
        "expansion_value_histogram": {
            str(key): value for key, value in sorted(expansion_histogram.items())
        },
        "ABCD_row_degrees": row_degrees,
        "ABCD_column_support": underlying_column_support,
        "ABCD_factors": blocks,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("solution", type=Path, help="MIPLIB .sol or .sol.gz file")
    parser.add_argument("--json", type=Path, help="optional JSON output path")
    parser.add_argument("--tolerance", type=float, default=1e-6)
    args = parser.parse_args()

    result = audit(args.solution, args.tolerance)
    rendered = json.dumps(result, indent=2, sort_keys=False)
    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(rendered + "\n", encoding="utf-8")
    print(rendered)


if __name__ == "__main__":
    main()
