#!/usr/bin/env python3
"""Audit R22/R21 fixed-A truncations over the finite R23 conjugation orbit."""

from __future__ import annotations

import argparse
import collections
import itertools
import json
import sys
import time
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import exact_semantic_audit as semantic  # noqa: E402


def key(matrix: np.ndarray) -> bytes:
    return np.asarray(matrix, dtype=np.int8).tobytes()


def block_matrices(blocks: dict) -> tuple[np.ndarray, list[tuple[str, int]]]:
    matrices = []
    labels = []
    for letter in "ABCD":
        array = np.asarray(blocks[letter], dtype=np.int32)
        for column in range(array.shape[1]):
            matrices.append(array[:, column].reshape(3, 3))
            labels.append((letter, column))
    return np.asarray(matrices, dtype=np.int32), labels


def tensor_cube(vector: np.ndarray) -> np.ndarray:
    return np.einsum("i,j,k->ijk", vector, vector, vector, optimize=True)


def write_child_core(
    transformed: np.ndarray,
    labels: list[tuple[str, int]],
    deleted_a: tuple[int, ...],
    path: Path,
) -> None:
    deleted = set(deleted_a)
    kept_by_letter: dict[str, list[np.ndarray]] = {x: [] for x in "ABCD"}
    for matrix, (letter, column) in zip(transformed, labels):
        if letter == "A" and column in deleted:
            continue
        kept_by_letter[letter].append(matrix.reshape(9))
    lines = [
        "# fixed-A truncation of an exact S5T6 R23 parent",
        f"# deleted original A columns: {sorted(deleted)}",
    ]
    for letter in "ABCD":
        for column, vector in enumerate(kept_by_letter[letter]):
            for row, value in enumerate(vector):
                lines.append(f"POS_{letter}_{row}_{column} {int(value == 1)}")
                lines.append(f"NEG_{letter}_{row}_{column} {int(value == -1)}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("start", type=Path)
    parser.add_argument("--max-depth", type=int, default=10)
    parser.add_argument("--entry-bound", type=int, default=6)
    parser.add_argument("--batch-size", type=int, default=4096)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--r22-core", type=Path, required=True)
    parser.add_argument("--r21-core", type=Path, required=True)
    args = parser.parse_args()
    for path in (args.json, args.r22_core, args.r21_core):
        path.parent.mkdir(parents=True, exist_ok=True)

    values, _ = semantic.read_solution(args.start)
    blocks = semantic.reconstruct_blocks(values, tolerance=1e-6)
    matrices, matrix_labels = block_matrices(blocks)
    assert len(matrices) == 23
    a_indexes = [i for i, label in enumerate(matrix_labels) if label[0] == "A"]
    assert len(a_indexes) == 5

    generators = []
    for i, j in itertools.permutations(range(3), 2):
        for sign in (-1, 1):
            generator = np.eye(3, dtype=np.int32)
            generator[i, j] = sign
            inverse = np.eye(3, dtype=np.int32)
            inverse[i, j] = -sign
            assert np.array_equal(generator @ inverse, np.eye(3, dtype=np.int32))
            generators.append((generator, inverse))

    identity = np.eye(3, dtype=np.int32)
    queue = collections.deque([(identity, identity, 0)])
    seen = {key(identity)}
    depth_counts: collections.Counter[int] = collections.Counter()
    matrices_evaluated = 0
    ternary_count = 0
    parent_k_hist: collections.Counter[int] = collections.Counter()
    child_hist = {"R22": collections.Counter(), "R21": collections.Counter()}
    best = {"R22": None, "R21": None}
    pending: list[tuple[np.ndarray, np.ndarray, int]] = []
    start_time = time.perf_counter()

    def evaluate_batch(batch: list[tuple[np.ndarray, np.ndarray, int]]) -> None:
        nonlocal matrices_evaluated, ternary_count
        if not batch:
            return
        ps = np.asarray([item[0] for item in batch], dtype=np.int32)
        pinvs = np.asarray([item[1] for item in batch], dtype=np.int32)
        transformed_batch = np.einsum(
            "bij,njk,bkl->bnil", pinvs.transpose(0, 2, 1), matrices,
            ps.transpose(0, 2, 1), optimize=True,
        )
        admissible = np.max(np.abs(transformed_batch), axis=(1, 2, 3)) <= 1
        matrices_evaluated += len(batch)
        for batch_index in np.flatnonzero(admissible):
            p, _, depth = batch[int(batch_index)]
            transformed = transformed_batch[int(batch_index)]
            ternary_count += 1
            parent_k = int(np.count_nonzero(transformed))
            parent_k_hist[parent_k] += 1
            a_vectors = [transformed[index].reshape(9) for index in a_indexes]

            for deleted_local in itertools.combinations(range(5), 1):
                removed = [a_vectors[i] for i in deleted_local]
                error_tensor = sum((tensor_cube(v) for v in removed), np.zeros((9, 9, 9), dtype=np.int32))
                error = int(np.abs(error_tensor).sum())
                removed_support = sum(int(np.count_nonzero(v)) for v in removed)
                child_k = parent_k - removed_support
                objective = 1000 * error + 3 * child_k
                child_hist["R22"][objective] += 1
                record = {
                    "objective": objective,
                    "E": error,
                    "K": child_k,
                    "full_raw_support": 3 * child_k,
                    "parent_K": parent_k,
                    "deleted_A_columns": list(deleted_local),
                    "deleted_A_supports": [int(np.count_nonzero(v)) for v in removed],
                    "P": p.tolist(),
                    "depth": depth,
                    "transformed": transformed.copy(),
                }
                if best["R22"] is None or objective < best["R22"]["objective"]:
                    best["R22"] = record

            for deleted_local in itertools.combinations(range(5), 2):
                removed = [a_vectors[i] for i in deleted_local]
                error_tensor = sum((tensor_cube(v) for v in removed), np.zeros((9, 9, 9), dtype=np.int32))
                error = int(np.abs(error_tensor).sum())
                removed_support = sum(int(np.count_nonzero(v)) for v in removed)
                child_k = parent_k - removed_support
                objective = 1000 * error + 3 * child_k
                child_hist["R21"][objective] += 1
                record = {
                    "objective": objective,
                    "E": error,
                    "K": child_k,
                    "full_raw_support": 3 * child_k,
                    "parent_K": parent_k,
                    "deleted_A_columns": list(deleted_local),
                    "deleted_A_supports": [int(np.count_nonzero(v)) for v in removed],
                    "P": p.tolist(),
                    "depth": depth,
                    "transformed": transformed.copy(),
                }
                if best["R21"] is None or objective < best["R21"]["objective"]:
                    best["R21"] = record

    while queue:
        p, p_inv, depth = queue.popleft()
        depth_counts[depth] += 1
        pending.append((p, p_inv, depth))
        if len(pending) >= args.batch_size:
            evaluate_batch(pending)
            pending.clear()
        if depth >= args.max_depth:
            continue
        for generator, generator_inv in generators:
            child = p @ generator
            child_key = key(child)
            if child_key in seen:
                continue
            child_inv = generator_inv @ p_inv
            if np.max(np.abs(child)) > args.entry_bound:
                continue
            if np.max(np.abs(child_inv)) > args.entry_bound:
                continue
            seen.add(child_key)
            queue.append((child, child_inv, depth + 1))
    evaluate_batch(pending)

    assert matrices_evaluated == 1_487_976, matrices_evaluated
    assert ternary_count == 480, ternary_count
    assert best["R22"] is not None and best["R21"] is not None
    write_child_core(
        best["R22"].pop("transformed"), matrix_labels,
        tuple(best["R22"]["deleted_A_columns"]), args.r22_core,
    )
    write_child_core(
        best["R21"].pop("transformed"), matrix_labels,
        tuple(best["R21"]["deleted_A_columns"]), args.r21_core,
    )
    report = {
        "source_parent": str(args.start),
        "scope": (
            "finite orbit of small unimodular simultaneous conjugations generated by 12 elementary "
            "shears, BFS depth<=10, |P_ij| and |P^-1_ij|<=6; only transformed parents that remain "
            "balanced ternary; fixed-A deletion only"
        ),
        "parameters": {
            "max_depth": args.max_depth,
            "entry_bound_for_P_and_inverse": args.entry_bound,
            "generators": len(generators),
        },
        "runtime_seconds": time.perf_counter() - start_time,
        "matrices_evaluated": matrices_evaluated,
        "ternary_admissible_transforms": ternary_count,
        "depth_counts": {str(k): v for k, v in sorted(depth_counts.items())},
        "parent_K_histogram": {str(k): v for k, v in sorted(parent_k_hist.items())},
        "R22_delete_one_fixed_A": {
            "candidates": ternary_count * 5,
            "minimum": best["R22"],
            "objective_histogram": {str(k): v for k, v in sorted(child_hist["R22"].items())},
            "strictly_below_reference_1150": best["R22"]["objective"] < 1150,
            "best_core": str(args.r22_core),
        },
        "R21_delete_two_fixed_A": {
            "candidates": ternary_count * 10,
            "minimum": best["R21"],
            "objective_histogram": {str(k): v for k, v in sorted(child_hist["R21"].items())},
            "strictly_below_reference_2147": best["R21"]["objective"] < 2147,
            "best_core": str(args.r21_core),
        },
        "interpretation": (
            "No conclusion outside this finite conjugation orbit and fixed-A truncation operation. "
            "Raw factor support is not a CSE/SLP addition count."
        ),
    }
    args.json.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({
        "matrices_evaluated": matrices_evaluated,
        "ternary_admissible_transforms": ternary_count,
        "R22_minimum": best["R22"],
        "R21_minimum": best["R21"],
        "runtime_seconds": report["runtime_seconds"],
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
