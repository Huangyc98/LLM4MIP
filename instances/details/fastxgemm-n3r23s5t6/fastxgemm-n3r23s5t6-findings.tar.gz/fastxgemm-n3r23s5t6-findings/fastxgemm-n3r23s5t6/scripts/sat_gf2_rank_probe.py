#!/usr/bin/env python3
"""SAT probe for the GF(2) support shadow of fastxgemm N3-R23-S5-T6.

This is a necessary-condition model for an exact balanced-ternary cyclic
decomposition.  It contains the mod-2 Brent equations, the official column
nonzero restrictions, the support bound, and contraction-rank inequalities.
An UNSAT result rules out an integer exact solution at the same support cap;
a SAT result is only a Boolean support witness and need not lift to signs.
"""

from __future__ import annotations

import argparse
import gzip
import itertools
import json
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path


HERE = Path(__file__).resolve().parent
VENDOR = HERE / "vendor"
if VENDOR.exists():
    sys.path.insert(0, str(VENDOR))

from pysat.card import CardEnc, EncType  # noqa: E402
from pysat.formula import CNF, IDPool  # noqa: E402
from pysat.solvers import Solver  # noqa: E402


N = 3
ROWS = 9
S = 5
T = 6
R = S + 3 * T
BLOCK_WIDTHS = {"A": S, "B": T, "C": T, "D": T}


class Encoder:
    def __init__(self) -> None:
        self.pool = IDPool()
        self.cnf = CNF()
        self.counts: dict[str, int] = {}

    def add(self, clause: list[int], family: str) -> None:
        self.cnf.append(clause)
        self.counts[family] = self.counts.get(family, 0) + 1

    def extend(self, clauses: list[list[int]], family: str) -> None:
        self.cnf.extend(clauses)
        self.counts[family] = self.counts.get(family, 0) + len(clauses)

    def xor2(self, a: int, b: int, name: tuple) -> int:
        """Return c with c <-> (a xor b)."""
        c = self.pool.id(name)
        self.add([a, b, -c], "xor")
        self.add([a, -b, c], "xor")
        self.add([-a, b, c], "xor")
        self.add([-a, -b, -c], "xor")
        return c

    def xor_many(self, lits: list[int], name: tuple) -> int:
        assert lits
        value = lits[0]
        for index, lit in enumerate(lits[1:], start=1):
            value = self.xor2(value, lit, name + (index,))
        return value

    def exactly_and(self, inputs: list[int], name: tuple) -> int:
        inputs = list(dict.fromkeys(inputs))
        assert inputs
        y = self.pool.id(name)
        for lit in inputs:
            self.add([-y, lit], "and")
        self.add([y] + [-lit for lit in inputs], "and")
        return y

    def cardinality(self, lits: list[int], bound: int, at_least: bool,
                    family: str) -> None:
        if at_least:
            encoded = CardEnc.atleast(
                lits=lits, bound=bound, vpool=self.pool,
                encoding=EncType.seqcounter,
            )
        else:
            encoded = CardEnc.atmost(
                lits=lits, bound=bound, vpool=self.pool,
                encoding=EncType.seqcounter,
            )
        self.extend(encoded.clauses, family)

    def lex_leq(self, left: list[int], right: list[int], name: tuple) -> None:
        """Encode left <=lex right using exact prefix-equality variables."""
        assert len(left) == len(right) and left
        prefix = self.pool.id(name + ("prefix", 0))
        self.add([prefix], "symmetry_lex")
        for index, (a, b) in enumerate(zip(left, right)):
            # If the prefix is equal, the first difference cannot be 1,0.
            self.add([-prefix, -a, b], "symmetry_lex")
            if index == len(left) - 1:
                break
            nxt = self.pool.id(name + ("prefix", index + 1))
            # nxt <-> prefix AND (a == b).
            self.add([-nxt, prefix], "symmetry_lex")
            self.add([-nxt, -a, b], "symmetry_lex")
            self.add([-nxt, a, -b], "symmetry_lex")
            self.add([-prefix, -a, -b, nxt], "symmetry_lex")
            self.add([-prefix, a, b, nxt], "symmetry_lex")
            prefix = nxt


def xkey(letter: str, row: int, column: int) -> tuple:
    return ("x", letter, row, column)


def source_for_rank(mode: str, row: int, rank: int) -> tuple:
    if rank < S:
        return xkey("A", row, rank)
    offset = rank - S
    group, column = divmod(offset, T)
    orders = {"U": "BCD", "V": "DBC", "W": "CDB"}
    return xkey(orders[mode][group], row, column)


def target_value(i: int, j: int, k: int) -> int:
    for n in range(N):
        for m in range(N):
            for q in range(N):
                if i == n * N + q and j == q * N + m and k == m * N + n:
                    return 1
    return 0


def gf2_rank_3x3(mask: int) -> int:
    rows = []
    for r in range(3):
        value = sum(((mask >> (3 * r + c)) & 1) << c for c in range(3))
        rows.append(value)
    rank = 0
    for bit in range(2, -1, -1):
        pivot = next((idx for idx in range(rank, 3) if (rows[idx] >> bit) & 1), None)
        if pivot is None:
            continue
        rows[rank], rows[pivot] = rows[pivot], rows[rank]
        for idx in range(3):
            if idx != rank and ((rows[idx] >> bit) & 1):
                rows[idx] ^= rows[rank]
        rank += 1
    return rank


def support_variable_order(enc: Encoder) -> list[int]:
    """Order aligned with the column/group permutation symmetry blocks."""
    ordered = []
    for col in range(S):
        ordered.extend(enc.pool.id(xkey("A", row, col)) for row in range(ROWS))
    for col in range(T):
        for letter in "BCD":
            ordered.extend(enc.pool.id(xkey(letter, row, col)) for row in range(ROWS))
    assert len(ordered) == 207 and len(set(ordered)) == 207
    return ordered


def add_symmetry_breaking(enc: Encoder) -> None:
    # Five A^3 terms are freely permutable.
    a_columns = [
        [enc.pool.id(xkey("A", row, col)) for row in range(ROWS)]
        for col in range(S)
    ]
    for col in range(S - 1):
        enc.lex_leq(a_columns[col], a_columns[col + 1], ("sym", "A", col))

    # Each (B,C,D) orbit may be cyclically rotated, and the six whole orbits
    # are freely permutable.
    groups = []
    for col in range(T):
        blocks = {
            letter: [enc.pool.id(xkey(letter, row, col)) for row in range(ROWS)]
            for letter in "BCD"
        }
        base = blocks["B"] + blocks["C"] + blocks["D"]
        rot1 = blocks["C"] + blocks["D"] + blocks["B"]
        rot2 = blocks["D"] + blocks["B"] + blocks["C"]
        enc.lex_leq(base, rot1, ("sym", "rotation1", col))
        enc.lex_leq(base, rot2, ("sym", "rotation2", col))
        groups.append(base)
    for col in range(T - 1):
        enc.lex_leq(groups[col], groups[col + 1], ("sym", "group", col))

    # Simultaneously relabelling the three matrix indices by sigma in S_3
    # applies the same row permutation (a,b)->(sigma(a),sigma(b)) to A/B/C/D.
    # Matrix multiplication and support are invariant under this action.
    base = support_variable_order(enc)
    identity = (0, 1, 2)
    for permutation in itertools.permutations(range(3)):
        if permutation == identity:
            continue
        transformed = []
        for col in range(S):
            for row in range(ROWS):
                a, b = divmod(row, 3)
                new_row = 3 * permutation[a] + permutation[b]
                transformed.append(enc.pool.id(xkey("A", new_row, col)))
        for col in range(T):
            for letter in "BCD":
                for row in range(ROWS):
                    a, b = divmod(row, 3)
                    new_row = 3 * permutation[a] + permutation[b]
                    transformed.append(enc.pool.id(xkey(letter, new_row, col)))
        enc.lex_leq(base, transformed, ("sym", "coordinate", permutation))


def build(cap: int, contraction_cuts: bool, symmetry: bool,
          known_lb: int) -> tuple[Encoder, list[int], dict]:
    enc = Encoder()
    support = support_variable_order(enc)
    enc.cardinality(support, cap, at_least=False, family="support_atmost")
    enc.cardinality(support, known_lb, at_least=True, family="support_atleast")

    # These are part of the official model: every rank-one factor column is
    # nonzero.  For an orbit this is equivalent to nonzero B, C and D vectors.
    for col in range(S):
        enc.add([enc.pool.id(xkey("A", row, col)) for row in range(ROWS)],
                "column_nonzero")
    for letter in "BCD":
        for col in range(T):
            enc.add([enc.pool.id(xkey(letter, row, col)) for row in range(ROWS)],
                    "column_nonzero")

    # Brent identities modulo two. Each rank contribution is an exact AND;
    # the XOR of all 23 contributions equals the target bit.
    product_count = 0
    for i in range(ROWS):
        for j in range(ROWS):
            for k in range(ROWS):
                products = []
                for rank in range(R):
                    inputs = [
                        enc.pool.id(source_for_rank("U", i, rank)),
                        enc.pool.id(source_for_rank("V", j, rank)),
                        enc.pool.id(source_for_rank("W", k, rank)),
                    ]
                    products.append(enc.exactly_and(
                        inputs, ("product", i, j, k, rank)
                    ))
                    product_count += 1
                parity = enc.xor_many(products, ("tensor_xor", i, j, k))
                enc.add([parity if target_value(i, j, k) else -parity],
                        "tensor_parity_target")

    contraction_summary = {"enabled": contraction_cuts, "count": 0,
                           "rank_histogram": {"1": 0, "2": 0, "3": 0}}
    if contraction_cuts:
        # If lambda is a 3x3 binary matrix, contracting the multiplication
        # tensor in one mode gives three disjoint copies of lambda^T and hence
        # rank 3*rank(lambda).  The same contraction of a rank-one expansion
        # uses exactly wt(lambda^T U) rank-one matrices. Therefore
        # wt(lambda^T U) >= 3*rank(lambda).  V and W are column permutations
        # of U in this cyclic model, so one family suffices for all modes.
        u_columns = []
        for col in range(S):
            u_columns.append([enc.pool.id(xkey("A", row, col)) for row in range(ROWS)])
        for letter in "BCD":
            for col in range(T):
                u_columns.append([enc.pool.id(xkey(letter, row, col)) for row in range(ROWS)])
        assert len(u_columns) == R

        # Dynamic parity table: p[mask,col] = XOR of selected row bits.
        parity_table: dict[tuple[int, int], int] = {}
        for mask in range(1, 1 << ROWS):
            lsb = mask & -mask
            row = lsb.bit_length() - 1
            rest = mask ^ lsb
            for col in range(R):
                bit = u_columns[col][row]
                if rest == 0:
                    parity_table[mask, col] = bit
                else:
                    parity_table[mask, col] = enc.xor2(
                        parity_table[rest, col], bit,
                        ("contraction_xor", mask, col),
                    )
            rank = gf2_rank_3x3(mask)
            enc.cardinality(
                [parity_table[mask, col] for col in range(R)],
                3 * rank, at_least=True, family="contraction_rank",
            )
            contraction_summary["count"] += 1
            contraction_summary["rank_histogram"][str(rank)] += 1

    if symmetry:
        add_symmetry_breaking(enc)

    metadata = {
        "underlying_support_variables": len(support),
        "rank_product_variables": product_count,
        "contraction_cuts": contraction_summary,
        "symmetry_enabled": symmetry,
    }
    return enc, support, metadata


def write_dimacs_gz(enc: Encoder, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with gzip.open(path, "wt", encoding="ascii", newline="\n") as stream:
        stream.write(f"p cnf {enc.pool.top} {len(enc.cnf.clauses)}\n")
        for clause in enc.cnf.clauses:
            stream.write(" ".join(map(str, clause)) + " 0\n")


def read_support_solution(path: Path) -> dict[tuple[str, int, int], int]:
    values: dict[str, float] = {}
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8") as stream:
        for raw in stream:
            fields = raw.strip().split()
            if len(fields) >= 2 and fields[0] != "=obj=" and not fields[0].startswith("#"):
                try:
                    values[fields[0]] = float(fields[1])
                except ValueError:
                    pass
    result = {}
    for letter, width in BLOCK_WIDTHS.items():
        for row in range(ROWS):
            for col in range(width):
                pos = int(round(values.get(f"POS_{letter}_{row}_{col}", 0.0)))
                neg = int(round(values.get(f"NEG_{letter}_{row}_{col}", 0.0)))
                if pos not in (0, 1) or neg not in (0, 1) or pos + neg > 1:
                    raise ValueError(f"invalid POS/NEG pair {letter},{row},{col}: {pos},{neg}")
                result[(letter, row, col)] = int(pos or neg)
    return result


def canonicalize_support(raw: dict[tuple[str, int, int], int]) -> dict[tuple[str, int, int], int]:
    """Return a representative satisfying all support symmetry constraints."""
    candidates = []
    for permutation in itertools.permutations(range(3)):
        inverse = [0, 0, 0]
        for old, new in enumerate(permutation):
            inverse[new] = old

        def transformed_column(letter: str, col: int) -> tuple[int, ...]:
            values = []
            for new_row in range(ROWS):
                a, b = divmod(new_row, 3)
                old_row = 3 * inverse[a] + inverse[b]
                values.append(raw[letter, old_row, col])
            return tuple(values)

        a_columns = sorted(transformed_column("A", col) for col in range(S))
        groups = []
        for col in range(T):
            triple = tuple(transformed_column(letter, col) for letter in "BCD")
            rotations = [triple[offset:] + triple[:offset] for offset in range(3)]
            groups.append(min(rotations, key=lambda item: sum(item, ())))
        groups.sort(key=lambda item: sum(item, ()))
        flat = tuple(value for column in a_columns for value in column) + tuple(
            value for group in groups for column in group for value in column
        )
        candidates.append((flat, a_columns, groups))
    _, a_columns, groups = min(candidates, key=lambda item: item[0])
    result = {}
    for col, column in enumerate(a_columns):
        for row, value in enumerate(column):
            result["A", row, col] = value
    for col, group in enumerate(groups):
        for letter, column in zip("BCD", group):
            for row, value in enumerate(column):
                result[letter, row, col] = value
    return result


def write_dimacs_plain(enc: Encoder, path: Path, units: list[int]) -> None:
    with path.open("w", encoding="ascii", newline="\n") as stream:
        stream.write(f"p cnf {enc.pool.top} {len(enc.cnf.clauses) + len(units)}\n")
        for clause in enc.cnf.clauses:
            stream.write(" ".join(map(str, clause)) + " 0\n")
        for unit in units:
            stream.write(f"{unit} 0\n")


def worker_main() -> None:
    """Internal subprocess entry point; isolates a native solver for timeout."""
    parser = argparse.ArgumentParser()
    parser.add_argument("--worker-cnf", type=Path, required=True)
    parser.add_argument("--worker-result", type=Path, required=True)
    parser.add_argument("--worker-solver", required=True)
    parser.add_argument("--worker-support-max", type=int, required=True)
    parser.add_argument("--worker-proof", type=Path)
    args = parser.parse_args()
    cnf = CNF(from_file=str(args.worker_cnf))
    use_proof = args.worker_proof is not None
    with Solver(name=args.worker_solver, bootstrap_with=cnf.clauses,
                with_proof=use_proof) as solver:
        solved = solver.solve()
        stats = solver.accum_stats()
        selected = None
        proof_lines = None
        if solved:
            positive = {lit for lit in solver.get_model() if lit > 0}
            selected = [lit for lit in range(1, args.worker_support_max + 1)
                        if lit in positive]
        elif use_proof:
            proof = solver.get_proof()
            args.worker_proof.parent.mkdir(parents=True, exist_ok=True)
            args.worker_proof.write_text("\n".join(proof) + "\n", encoding="ascii")
            proof_lines = len(proof)
    args.worker_result.write_text(json.dumps({
        "solved": solved,
        "stats": stats,
        "selected_support_variables": selected,
        "proof_lines": proof_lines,
    }), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--support-cap", type=int, default=57)
    parser.add_argument("--known-lb", type=int, default=29)
    parser.add_argument("--solver", default="cadical195")
    parser.add_argument("--time-limit", type=float, default=600.0)
    parser.add_argument("--no-contraction-cuts", action="store_true")
    parser.add_argument("--no-symmetry", action="store_true")
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--dimacs-gz", type=Path)
    parser.add_argument("--proof", type=Path)
    parser.add_argument(
        "--fix-solution", type=Path,
        help="fix x to the symmetry-canonical support of a POS/NEG solution (audit mode)",
    )
    args = parser.parse_args()
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.log.parent.mkdir(parents=True, exist_ok=True)

    log_lines = []

    def log(message: str) -> None:
        rendered = f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {message}"
        print(rendered, flush=True)
        log_lines.append(rendered)
        args.log.write_text("\n".join(log_lines) + "\n", encoding="utf-8")

    log("building CNF")
    build_start = time.perf_counter()
    enc, support, metadata = build(
        args.support_cap,
        contraction_cuts=not args.no_contraction_cuts,
        symmetry=not args.no_symmetry,
        known_lb=args.known_lb,
    )
    build_seconds = time.perf_counter() - build_start
    log(f"built vars={enc.pool.top} clauses={len(enc.cnf.clauses)} "
        f"seconds={build_seconds:.3f}")
    if args.dimacs_gz:
        log(f"writing DIMACS {args.dimacs_gz}")
        write_dimacs_gz(enc, args.dimacs_gz)

    assumptions = []
    fixed_support_count = None
    if args.fix_solution:
        fixed = canonicalize_support(read_support_solution(args.fix_solution))
        fixed_support_count = sum(fixed.values())
        for letter, width in BLOCK_WIDTHS.items():
            for row in range(ROWS):
                for col in range(width):
                    variable = enc.pool.id(xkey(letter, row, col))
                    assumptions.append(variable if fixed[letter, row, col] else -variable)
        log(f"fixed canonical support from {args.fix_solution}; support={fixed_support_count}")

    use_proof = args.proof is not None
    log(f"starting solver={args.solver} limit={args.time_limit:.3f}s proof={use_proof}")
    solve_start = time.perf_counter()
    temporary_cnf = tempfile.NamedTemporaryFile(
        prefix="r23_sat_", suffix=".cnf", dir=args.json.parent,
        delete=False,
    )
    temporary_cnf.close()
    temporary_result = Path(temporary_cnf.name + ".result.json")
    temporary_cnf_path = Path(temporary_cnf.name)
    write_dimacs_plain(enc, temporary_cnf_path, assumptions)
    command = [
        sys.executable, str(Path(__file__).resolve()),
        "--worker-cnf", str(temporary_cnf_path),
        "--worker-result", str(temporary_result),
        "--worker-solver", args.solver,
        "--worker-support-max", str(max(support)),
    ]
    if args.proof:
        command.extend(["--worker-proof", str(args.proof)])
    worker_stdout = ""
    worker_stderr = ""
    try:
        completed = subprocess.run(
            command, capture_output=True, text=True,
            timeout=args.time_limit, check=False,
        )
        worker_stdout = completed.stdout
        worker_stderr = completed.stderr
        worker_result = (
            json.loads(temporary_result.read_text(encoding="utf-8"))
            if completed.returncode == 0 and temporary_result.exists()
            else None
        )
    except subprocess.TimeoutExpired as error:
        worker_stdout = error.stdout or ""
        worker_stderr = error.stderr or ""
        worker_result = None
    finally:
        for temporary in (temporary_cnf_path, temporary_result):
            try:
                os.unlink(temporary)
            except FileNotFoundError:
                pass
    solve_seconds = time.perf_counter() - solve_start
    solved = worker_result["solved"] if worker_result is not None else None
    stats = worker_result["stats"] if worker_result is not None else {}
    selected_support = (
        set(worker_result["selected_support_variables"])
        if worker_result is not None and worker_result["selected_support_variables"] is not None
        else None
    )
    proof_lines = worker_result["proof_lines"] if worker_result is not None else None

    status = "SAT" if solved is True else "UNSAT" if solved is False else "TIME_LIMIT"
    log(f"finished status={status} solve_seconds={solve_seconds:.3f} stats={stats}")
    pattern = []
    if selected_support is not None:
        for letter, width in BLOCK_WIDTHS.items():
            for row in range(ROWS):
                for col in range(width):
                    if enc.pool.id(xkey(letter, row, col)) in selected_support:
                        pattern.append({"letter": letter, "row": row, "column": col})
        log(f"SAT support={len(pattern)}")
    if proof_lines is not None and args.proof is not None:
        log(f"wrote proof lines={proof_lines} path={args.proof}")

    report = {
        "instance": "fastxgemm-n3r23s5t6",
        "model": "GF(2) necessary-condition SAT encoding with contraction-rank cuts",
        "logical_scope": {
            "UNSAT": (
                "rules out every exact balanced-ternary solution of the official "
                "cyclic model with K at most the support cap"
            ),
            "SAT": "only a mod-2 support witness; integer sign lifting remains necessary",
            "TIME_LIMIT": "no mathematical conclusion",
        },
        "support_cap": args.support_cap,
        "known_valid_lower_bound_imposed": args.known_lb,
        "solver": args.solver,
        "time_limit_seconds": args.time_limit,
        "status": status,
        "build_seconds": build_seconds,
        "solve_seconds": solve_seconds,
        "variables": enc.pool.top,
        "clauses": len(enc.cnf.clauses),
        "clause_families": enc.counts,
        "solver_stats": stats,
        "worker_stdout": worker_stdout,
        "worker_stderr": worker_stderr,
        "fixed_solution": str(args.fix_solution) if args.fix_solution else None,
        "fixed_support_count": fixed_support_count,
        **metadata,
    }
    if pattern:
        report["found_support"] = len(pattern)
        report["found_pattern"] = pattern
    if args.dimacs_gz:
        report["dimacs_gz"] = str(args.dimacs_gz)
    if proof_lines is not None and args.proof is not None:
        report["proof"] = str(args.proof)
        report["proof_lines"] = proof_lines
    args.json.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in report.items() if k != "found_pattern"}, indent=2))


if __name__ == "__main__":
    if "--worker-cnf" in sys.argv:
        worker_main()
    else:
        main()
