#!/usr/bin/env python3
"""Exhaustively replace each of the 23 underlying ternary vectors.

For every A/B/C/D column, enumerate all 3^9 possible vectors in {-1,0,1}^9.
The tensor, residual, support, and the original structural constraints are
evaluated with integer arithmetic.  This proves the best objective within the
union of these 23 complete one-vector neighborhoods.
"""

from __future__ import annotations

import argparse
import itertools
import json
import time
from pathlib import Path

import numpy as np

import exact_semantic_audit as semantic


def tensor_from_factors(u, v, w):
    return np.einsum("ir,jr,kr->ijk", u, v, w, optimize=True, dtype=np.int16)


def cyclic_group(b, c, d):
    return (
        np.einsum("i,j,k->ijk", b, d, c, optimize=True)
        + np.einsum("i,j,k->ijk", c, b, d, optimize=True)
        + np.einsum("i,j,k->ijk", d, c, b, optimize=True)
    )


def candidate_contributions(letter, candidates, b=None, c=None, d=None):
    if letter == "A":
        return np.einsum(
            "bi,bj,bk->bijk", candidates, candidates, candidates,
            optimize=True, dtype=np.int16
        )
    if letter == "B":
        return (
            np.einsum("bi,j,k->bijk", candidates, d, c, optimize=True)
            + np.einsum("i,bj,k->bijk", c, candidates, d, optimize=True)
            + np.einsum("i,j,bk->bijk", d, c, candidates, optimize=True)
        )
    if letter == "C":
        return (
            np.einsum("i,j,bk->bijk", b, d, candidates, optimize=True)
            + np.einsum("bi,j,k->bijk", candidates, b, d, optimize=True)
            + np.einsum("i,bj,k->bijk", d, candidates, b, optimize=True)
        )
    if letter == "D":
        return (
            np.einsum("i,bj,k->bijk", b, candidates, c, optimize=True)
            + np.einsum("i,j,bk->bijk", c, b, candidates, optimize=True)
            + np.einsum("bi,j,k->bijk", candidates, c, b, optimize=True)
        )
    raise ValueError(letter)


def target_tensor():
    target = np.zeros((9, 9, 9), dtype=np.int16)
    for i in range(9):
        for j in range(9):
            for k in range(9):
                target[i, j, k] = semantic.target_value(i, j, k)
    return target


def all_ternary_vectors():
    return np.asarray(list(itertools.product((-1, 0, 1), repeat=9)), dtype=np.int8)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--json", type=Path)
    parser.add_argument("--batch-size", type=int, default=256)
    args = parser.parse_args()

    started = time.perf_counter()
    values, _ = semantic.read_solution(args.solution)
    original = semantic.reconstruct_blocks(values, tolerance=1e-6)
    blocks = {letter: np.asarray(matrix, dtype=np.int8) for letter, matrix in original.items()}
    u0, v0, w0 = semantic.factors_from_blocks(original)
    incumbent_tensor = tensor_from_factors(
        np.asarray(u0, dtype=np.int8),
        np.asarray(v0, dtype=np.int8),
        np.asarray(w0, dtype=np.int8),
    )
    target = target_tensor()
    candidates = all_ternary_vectors()
    candidate_support = np.count_nonzero(candidates, axis=1)
    incumbent_k = sum(np.count_nonzero(matrix) for matrix in blocks.values())
    incumbent_e = int(np.abs(target - incumbent_tensor).sum())
    incumbent_objective = 1000 * incumbent_e + 3 * incumbent_k
    base_row_coverage = sum(np.count_nonzero(matrix, axis=1) for matrix in blocks.values())

    scans = []
    global_best = incumbent_objective
    improving = []

    for letter in "ABCD":
        width = semantic.BLOCK_WIDTHS[letter]
        for col in range(width):
            old_vector = blocks[letter][:, col]
            old_support = int(np.count_nonzero(old_vector))
            if letter == "A":
                old_contribution = np.einsum(
                    "i,j,k->ijk", old_vector, old_vector, old_vector,
                    optimize=True, dtype=np.int16
                )
                b = c = d = None
            else:
                b, c, d = (blocks[x][:, col] for x in "BCD")
                old_contribution = cyclic_group(b, c, d)

            remainder = incumbent_tensor - old_contribution
            best_objective = None
            best_e = None
            best_k = None
            best_vectors = []
            exactly_feasible_count = 0

            for first in range(0, len(candidates), args.batch_size):
                batch = candidates[first:first + args.batch_size]
                contributions = candidate_contributions(letter, batch, b=b, c=c, d=d)
                new_tensor = remainder[None, :, :, :] + contributions
                differences = target[None, :, :, :] - new_tensor
                max_error = np.max(np.abs(differences), axis=(1, 2, 3))
                e_values = np.sum(np.abs(differences), axis=(1, 2, 3))
                k_values = incumbent_k - old_support + candidate_support[first:first + len(batch)]

                # Original integer-side structure: K>=28, no zero factor
                # column, every factor row covered, and residual upper bound 1.
                row_coverage = (
                    base_row_coverage[None, :]
                    - (old_vector != 0).astype(np.int8)[None, :]
                    + (batch != 0).astype(np.int8)
                )
                valid = (
                    (candidate_support[first:first + len(batch)] > 0)
                    & (k_values >= 28)
                    & np.all(row_coverage >= 1, axis=1)
                    & (max_error <= 1)
                )
                exactly_feasible_count += int(np.count_nonzero(valid))
                objectives = 1000 * e_values + 3 * k_values
                objectives = np.where(valid, objectives, np.iinfo(np.int64).max)
                local_best = int(objectives.min())
                if best_objective is None or local_best < best_objective:
                    best_objective = local_best
                    indexes = np.flatnonzero(objectives == local_best)
                    best_vectors = [batch[index].astype(int).tolist() for index in indexes[:20]]
                    if indexes.size:
                        best_e = int(e_values[indexes[0]])
                        best_k = int(k_values[indexes[0]])
                elif local_best == best_objective:
                    indexes = np.flatnonzero(objectives == local_best)
                    room = max(0, 20 - len(best_vectors))
                    best_vectors.extend(batch[index].astype(int).tolist() for index in indexes[:room])

                strict_indexes = np.flatnonzero(valid & (objectives < incumbent_objective))
                for index in strict_indexes[:20]:
                    improving.append(
                        {
                            "letter": letter,
                            "column": col,
                            "vector": batch[index].astype(int).tolist(),
                            "E": int(e_values[index]),
                            "K": int(k_values[index]),
                            "objective": int(objectives[index]),
                        }
                    )

            global_best = min(global_best, best_objective)
            scans.append(
                {
                    "vector": f"{letter}{col}",
                    "old_vector": old_vector.astype(int).tolist(),
                    "old_support": old_support,
                    "enumerated": len(candidates),
                    "original_model_integer_feasible": exactly_feasible_count,
                    "best_E": best_e,
                    "best_K": best_k,
                    "best_objective": best_objective,
                    "best_vector_count_saved": len(best_vectors),
                    "best_vectors": best_vectors,
                }
            )
            print(
                f"{letter}{col}: feasible={exactly_feasible_count} "
                f"best={best_objective} (E={best_e}, K={best_k})",
                flush=True,
            )

    result = {
        "instance": "fastxgemm-n3r23s5t6",
        "method": "exhaustive replacement of one complete 9-entry ternary vector",
        "domain_per_vector": "{-1,0,1}^9",
        "vectors_scanned": 23,
        "candidates_per_vector": len(candidates),
        "total_candidates": 23 * len(candidates),
        "incumbent": {"E": incumbent_e, "K": incumbent_k, "objective": incumbent_objective},
        "best_objective": global_best,
        "strict_improvement_found": bool(improving),
        "improving_examples": improving[:100],
        "elapsed_seconds": time.perf_counter() - started,
        "scans": scans,
    }
    rendered = json.dumps(result, indent=2)
    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(rendered + "\n", encoding="utf-8")
    print(rendered)


if __name__ == "__main__":
    main()
