#!/usr/bin/env python3
"""Audit a complete fastxgemm assignment on the official MPS in three ways."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import gurobipy as gp

from repair_and_audit_incumbent import (
    audit,
    decompressed_sha256,
    exact_decimal_audit,
    exact_integer_audit,
    parse_value_tokens,
    parse_values,
    sha256,
)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    lines = args.solution.read_text(encoding="utf-8").splitlines(keepends=True)
    declared, values = parse_values(lines)
    tokens = parse_value_tokens(lines)
    model = gp.read(str(args.mps))
    model.Params.OutputFlag = 0

    names = {v.VarName for v in model.getVars()}
    missing = sorted(names - set(values))
    unknown = sorted(set(values) - names)
    if missing or unknown:
        raise RuntimeError(f"name mismatch: missing={len(missing)} unknown={len(unknown)}")

    float_result = audit(model, values)
    decimal_result = exact_decimal_audit(model, tokens)
    integer_result = exact_integer_audit(model, values)
    if (
        float_result["recomputed_objective_float"] != 174
        or float_result["violated_rows_gt_1e_12"]
        or float_result["violated_bounds_gt_1e_12"]
        or decimal_result["violated_constraint_count"]
        or decimal_result["violated_bound_count"]
        or integer_result["violated_constraint_count"]
        or integer_result["violated_bound_count"]
    ):
        raise RuntimeError("strict audit failed")

    report = {
        "instance": "fastxgemm-n3r23s5t6",
        "result": {
            "strict_feasible_upper_bound": 174,
            "global_optimality_proved": False,
            "warning": "A feasible exact rank-23 decomposition is not a proof that support 174 is minimum.",
        },
        "inputs": {"mps": str(args.mps), "solution": str(args.solution)},
        "sha256": {
            "mps_gzip": sha256(args.mps),
            "mps_decompressed": decompressed_sha256(args.mps),
            "solution": sha256(args.solution),
        },
        "variable_matching": {
            "mps_variables": model.NumVars,
            "supplied_variables": len(values),
            "missing": missing,
            "unknown": unknown,
        },
        "objective_decomposition": {
            "tensor_l1_error_E": 0,
            "underlying_ABCD_support_K": 58,
            "full_UVW_support": 174,
            "identity": "1000*0 + 3*58 = 174",
        },
        "declared_objective_token": declared,
        "float_matrix_audit": float_result,
        "exact_decimal_matrix_audit": decimal_result,
        "exact_integer_matrix_audit": integer_result,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
