#!/usr/bin/env python3
"""Optimize the support lower bound implied by all GF(2) contractions.

Columns are aggregated by their nonzero 9-bit support pattern.  This discards
the cyclic A/B/C/D block structure and all Brent equations, so it is a valid
relaxation of every exact rank-23 solution of the official model.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


ROWS = 9
R = 23


def gf2_rank_3x3(mask: int) -> int:
    rows = [sum(((mask >> (3 * r + c)) & 1) << c for c in range(3))
            for r in range(3)]
    rank = 0
    for bit in range(2, -1, -1):
        pivot = next((idx for idx in range(rank, 3) if (rows[idx] >> bit) & 1), None)
        if pivot is None:
            continue
        rows[rank], rows[pivot] = rows[pivot], rows[rank]
        for idx in range(3):
            if idx != rank and ((rows[idx] >> bit) & 1):
                rows[idx] ^= rows[rank]
        rank += 1
    return rank


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--time-limit", type=float, default=300.0)
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--mps", type=Path, required=True)
    args = parser.parse_args()
    for path in (args.json, args.log, args.mps):
        path.parent.mkdir(parents=True, exist_ok=True)

    model = gp.Model("r23_gf2_contraction_support_relaxation")
    multiplicity = {
        pattern: model.addVar(vtype=GRB.INTEGER, lb=0, ub=R,
                              name=f"N_{pattern:03x}")
        for pattern in range(1, 1 << ROWS)
    }
    model.addConstr(gp.quicksum(multiplicity.values()) == R, name="COLUMN_COUNT")
    rank_histogram = {1: 0, 2: 0, 3: 0}
    for lam in range(1, 1 << ROWS):
        rank = gf2_rank_3x3(lam)
        rank_histogram[rank] += 1
        model.addConstr(
            gp.quicksum(count for pattern, count in multiplicity.items()
                        if (lam & pattern).bit_count() % 2 == 1)
            >= 3 * rank,
            name=f"CONTRACTION_{lam:03x}_RANK_{rank}",
        )
    model.setObjective(
        gp.quicksum(pattern.bit_count() * count
                    for pattern, count in multiplicity.items()),
        GRB.MINIMIZE,
    )
    model.Params.TimeLimit = args.time_limit
    model.Params.Threads = args.threads
    model.Params.MIPGap = 0.0
    model.Params.FeasibilityTol = 1e-9
    model.Params.IntFeasTol = 1e-9
    model.Params.LogFile = str(args.log)
    model.write(str(args.mps))
    model.optimize()

    status_names = {
        GRB.OPTIMAL: "OPTIMAL",
        GRB.INFEASIBLE: "INFEASIBLE",
        GRB.TIME_LIMIT: "TIME_LIMIT",
    }
    report = {
        "instance": "fastxgemm-n3r23s5t6",
        "relaxation": "aggregated nonzero GF(2) factor-column patterns",
        "logical_basis": (
            "For every nonzero 3x3 lambda, contraction of the matrix-"
            "multiplication tensor has rank 3*rank_GF2(lambda). A rank-one "
            "decomposition therefore needs at least this many columns r with "
            "<lambda,u_r>=1. The official model also makes all 23 columns nonzero."
        ),
        "scope": (
            "Any exact official cyclic solution maps into this relaxation; "
            "the converse is not required. A proven objective bound is therefore "
            "a valid lower bound on underlying support K for E=0."
        ),
        "rank": R,
        "pattern_variables": len(multiplicity),
        "contraction_constraints": sum(rank_histogram.values()),
        "rank_histogram": {str(k): v for k, v in rank_histogram.items()},
        "status_code": int(model.Status),
        "status": status_names.get(model.Status, str(model.Status)),
        "runtime_seconds": float(model.Runtime),
        "node_count": float(model.NodeCount),
        "objective": float(model.ObjVal) if model.SolCount else None,
        "best_bound": float(model.ObjBound),
        "solution_count": int(model.SolCount),
        "parameters": {"time_limit": args.time_limit, "threads": args.threads},
        "mps": str(args.mps),
    }
    if model.SolCount:
        chosen = [
            {"pattern_hex": f"{pattern:03x}",
             "pattern_rows": [row for row in range(ROWS) if (pattern >> row) & 1],
             "weight": pattern.bit_count(),
             "multiplicity": int(round(variable.X))}
            for pattern, variable in multiplicity.items() if variable.X > 0.5
        ]
        report["chosen_patterns"] = chosen
        report["chosen_column_count"] = sum(item["multiplicity"] for item in chosen)
        report["chosen_support"] = sum(item["weight"] * item["multiplicity"]
                                       for item in chosen)
    args.json.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
