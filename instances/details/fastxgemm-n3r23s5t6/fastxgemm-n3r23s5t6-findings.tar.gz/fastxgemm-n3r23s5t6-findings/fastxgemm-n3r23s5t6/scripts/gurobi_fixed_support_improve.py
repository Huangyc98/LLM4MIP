#!/usr/bin/env python3
"""Prove/search a sub-174 exact decomposition without new support locations.

The 58 support locations of the author-provided exact solution remain ternary:
their signs may change and they may be deleted.  The other 149 underlying
locations are fixed to zero.  A strict improvement must have objective at most
171; because tensor errors are integral and cost 1000, all residuals are zero.
"""

from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB

import exact_semantic_audit as semantic


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model", type=Path)
    parser.add_argument("start", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--solution", type=Path)
    parser.add_argument("--time-limit", type=float, default=300.0)
    args = parser.parse_args()
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.log.parent.mkdir(parents=True, exist_ok=True)
    if args.solution:
        args.solution.parent.mkdir(parents=True, exist_ok=True)

    started = time.perf_counter()
    start_values, _ = semantic.read_solution(args.start)
    model = gp.read(str(args.model))
    model.Params.OutputFlag = 1
    model.Params.LogFile = str(args.log)
    model.Params.Threads = 2
    model.Params.TimeLimit = args.time_limit
    model.Params.FeasibilityTol = 1e-9
    model.Params.IntFeasTol = 1e-9
    model.Params.OptimalityTol = 1e-9
    model.Params.NumericFocus = 3
    model.Params.Presolve = 2
    model.Params.MIPFocus = 1

    fixed_zero_locations = 0
    free_locations = 0
    for letter, width in semantic.BLOCK_WIDTHS.items():
        for row in range(9):
            for column in range(width):
                pos_name = f"POS_{letter}_{row}_{column}"
                neg_name = f"NEG_{letter}_{row}_{column}"
                pos_value = int(round(start_values[pos_name]))
                neg_value = int(round(start_values[neg_name]))
                if pos_value == 0 and neg_value == 0:
                    model.getVarByName(pos_name).UB = 0.0
                    model.getVarByName(neg_name).UB = 0.0
                    fixed_zero_locations += 1
                else:
                    free_locations += 1

    residuals_fixed_zero = 0
    for i in range(9):
        for j in range(9):
            for k in range(9):
                variable = model.getVarByName(f"RESIDUAL_{i}_{j}_{k}")
                variable.UB = 0.0
                residuals_fixed_zero += 1

    model.addConstr(model.getObjective() <= 171, name="STRICT_IMPROVEMENT_LATTICE_CAP")
    model.update()
    model.read(str(args.start))
    model.optimize()

    result = {
        "instance": "fastxgemm-n3r23s5t6",
        "scope": "author support locations only; arbitrary deletion and resigning",
        "fixed_zero_underlying_locations": fixed_zero_locations,
        "free_underlying_locations": free_locations,
        "residuals_fixed_zero": residuals_fixed_zero,
        "objective_cap": 171,
        "status_code": int(model.Status),
        "status": {
            GRB.OPTIMAL: "OPTIMAL",
            GRB.INFEASIBLE: "INFEASIBLE",
            GRB.TIME_LIMIT: "TIME_LIMIT",
            GRB.INTERRUPTED: "INTERRUPTED",
        }.get(model.Status, str(model.Status)),
        "solution_count": int(model.SolCount),
        "runtime_seconds": float(model.Runtime),
        "wall_seconds": time.perf_counter() - started,
        "node_count": float(model.NodeCount),
        "best_bound": (
            float(model.ObjBound)
            if model.IsMIP and math.isfinite(float(model.ObjBound))
            else None
        ),
        "best_objective": float(model.ObjVal) if model.SolCount else None,
    }
    if args.solution and model.SolCount:
        model.write(str(args.solution))
    args.json.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
