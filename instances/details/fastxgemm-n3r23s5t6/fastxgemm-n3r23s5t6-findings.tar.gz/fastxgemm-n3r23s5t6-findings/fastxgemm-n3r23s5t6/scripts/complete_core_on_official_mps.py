#!/usr/bin/env python3
"""Complete a 414-variable POS/NEG core on the official R23 MPS."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import gurobipy as gp
import numpy as np


HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import complete_author_mst as completion  # noqa: E402


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_core(path: Path) -> dict[str, int]:
    values = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        fields = raw.strip().split()
        if len(fields) >= 2 and not fields[0].startswith(("#", "=")):
            value = float(fields[1])
            rounded = round(value)
            if abs(value - rounded) > 1e-9 or rounded not in (0, 1):
                raise ValueError(f"nonbinary core value: {fields[0]}={value}")
            values[fields[0]] = rounded
    return values


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("core", type=Path)
    parser.add_argument("--solution", type=Path, required=True)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--time-limit", type=float, default=120.0)
    parser.add_argument("--threads", type=int, default=8)
    args = parser.parse_args()
    for path in (args.solution, args.json, args.log):
        path.parent.mkdir(parents=True, exist_ok=True)

    core = parse_core(args.core)
    model = gp.read(str(args.mps))
    variables = model.getVars()
    integer_variables = [
        variable for variable in variables
        if variable.VType in {gp.GRB.BINARY, gp.GRB.INTEGER}
    ]
    integer_names = {variable.VarName for variable in integer_variables}
    unknown = sorted(set(core) - integer_names)
    missing = sorted(integer_names - set(core))
    if unknown or missing:
        raise RuntimeError(
            f"core mismatch: supplied={len(core)} unknown={len(unknown)} missing={len(missing)}"
        )
    for variable in integer_variables:
        value = core[variable.VarName]
        variable.LB = value
        variable.UB = value
    model.update()

    model.Params.FeasibilityTol = 1e-9
    model.Params.IntFeasTol = 1e-9
    model.Params.OptimalityTol = 1e-9
    model.Params.NumericFocus = 3
    model.Params.Presolve = 2
    model.Params.Method = 1
    model.Params.Threads = args.threads
    model.Params.TimeLimit = args.time_limit
    model.Params.LogFile = str(args.log)
    model.optimize()
    if model.Status != gp.GRB.OPTIMAL or model.SolCount < 1:
        raise RuntimeError(f"completion failed status={model.Status} solcount={model.SolCount}")
    model.write(str(args.solution))
    x = np.array([variable.X for variable in variables])
    strict_audit = completion.audit(model, x)
    report = {
        "instance": "fastxgemm-n3r23s5t6",
        "purpose": "strict official-MPS completion of transformed POS/NEG core",
        "inputs": {"mps": str(args.mps), "core": str(args.core)},
        "outputs": {"solution": str(args.solution), "log": str(args.log)},
        "sha256": {
            "mps_gzip": sha256(args.mps),
            "core": sha256(args.core),
            "solution": sha256(args.solution),
        },
        "gurobi_version": ".".join(map(str, gp.gurobi.version())),
        "model_fingerprint": "0x%08x" % (model.Fingerprint & 0xFFFFFFFF),
        "dimensions": {
            "variables": model.NumVars,
            "constraints": model.NumConstrs,
            "nonzeros": model.NumNZs,
            "integer_variables": len(integer_variables),
        },
        "core_check": {
            "supplied": len(core), "unknown": len(unknown), "missing": len(missing),
            "ones": sum(core.values()),
        },
        "solve": {
            "status_code": int(model.Status),
            "status": "OPTIMAL",
            "runtime_seconds": float(model.Runtime),
            "objective": float(model.ObjVal),
            "objective_bound": float(model.ObjBound),
            "solution_count": int(model.SolCount),
        },
        "strict_solution_audit": strict_audit,
        "conclusion": (
            "The transformed core completes to a feasible solution of the official "
            "MPS. This is a strict upper bound; it is not a global optimality proof."
        ),
    }
    args.json.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n",
                         encoding="utf-8")
    print(json.dumps(report, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
