#!/usr/bin/env python3
"""Native-XOR CryptoMiniSat probe for the R23 GF(2) support system."""

from __future__ import annotations

import argparse
import array
import json
import sys
import time
from pathlib import Path


HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "vendor"))

from pycryptosat import Solver  # noqa: E402

import sat_gf2_rank_probe as base  # noqa: E402


def build(cap: int, known_lb: int, symmetry: bool):
    enc = base.Encoder()
    support = base.support_variable_order(enc)
    enc.cardinality(support, cap, at_least=False, family="support_atmost")
    enc.cardinality(support, known_lb, at_least=True, family="support_atleast")

    for col in range(base.S):
        enc.add([enc.pool.id(base.xkey("A", row, col)) for row in range(base.ROWS)],
                "column_nonzero")
    for letter in "BCD":
        for col in range(base.T):
            enc.add([enc.pool.id(base.xkey(letter, row, col)) for row in range(base.ROWS)],
                    "column_nonzero")

    xor_equations: list[tuple[list[int], bool, str]] = []
    product_count = 0
    for i in range(base.ROWS):
        for j in range(base.ROWS):
            for k in range(base.ROWS):
                products = []
                for rank in range(base.R):
                    inputs = [
                        enc.pool.id(base.source_for_rank("U", i, rank)),
                        enc.pool.id(base.source_for_rank("V", j, rank)),
                        enc.pool.id(base.source_for_rank("W", k, rank)),
                    ]
                    products.append(enc.exactly_and(
                        inputs, ("product", i, j, k, rank)
                    ))
                    product_count += 1
                xor_equations.append((products, bool(base.target_value(i, j, k)),
                                      "tensor_parity"))

    u_columns = []
    for col in range(base.S):
        u_columns.append([enc.pool.id(base.xkey("A", row, col))
                          for row in range(base.ROWS)])
    for letter in "BCD":
        for col in range(base.T):
            u_columns.append([enc.pool.id(base.xkey(letter, row, col))
                              for row in range(base.ROWS)])
    rank_histogram = {1: 0, 2: 0, 3: 0}
    for mask in range(1, 1 << base.ROWS):
        selected_rows = [row for row in range(base.ROWS) if (mask >> row) & 1]
        parities = []
        for col in range(base.R):
            parity = enc.pool.id(("contraction_parity", mask, col))
            parities.append(parity)
            # parity XOR all selected factor bits = 0.
            xor_equations.append(
                ([parity] + [u_columns[col][row] for row in selected_rows],
                 False, "contraction_definition")
            )
        rank = base.gf2_rank_3x3(mask)
        rank_histogram[rank] += 1
        enc.cardinality(parities, 3 * rank, at_least=True,
                        family="contraction_rank")

    if symmetry:
        base.add_symmetry_breaking(enc)
    metadata = {
        "underlying_support_variables": len(support),
        "rank_product_variables": product_count,
        "native_xor_equations": len(xor_equations),
        "tensor_xor_equations": 729,
        "contraction_definition_xors": 511 * base.R,
        "contraction_rank_histogram": {str(k): v for k, v in rank_histogram.items()},
        "symmetry_enabled": symmetry,
    }
    return enc, support, xor_equations, metadata


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--support-cap", type=int, default=57)
    parser.add_argument("--known-lb", type=int, default=29)
    parser.add_argument("--time-limit", type=float, default=600.0)
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--no-symmetry", action="store_true")
    parser.add_argument("--fix-solution", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    args = parser.parse_args()
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.log.parent.mkdir(parents=True, exist_ok=True)
    log_lines = []

    def log(message: str) -> None:
        rendered = f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {message}"
        print(rendered, flush=True)
        log_lines.append(rendered)
        args.log.write_text("\n".join(log_lines) + "\n", encoding="utf-8")

    start = time.perf_counter()
    log("building CNF plus native XOR system")
    enc, support, xors, metadata = build(
        args.support_cap, args.known_lb, not args.no_symmetry
    )
    build_seconds = time.perf_counter() - start
    log(f"built vars={enc.pool.top} cnf_clauses={len(enc.cnf.clauses)} "
        f"xor_equations={len(xors)} seconds={build_seconds:.3f}")

    assumptions = []
    fixed_support_count = None
    if args.fix_solution:
        fixed = base.canonicalize_support(base.read_support_solution(args.fix_solution))
        fixed_support_count = sum(fixed.values())
        for letter, width in base.BLOCK_WIDTHS.items():
            for row in range(base.ROWS):
                for col in range(width):
                    variable = enc.pool.id(base.xkey(letter, row, col))
                    assumptions.append(variable if fixed[letter, row, col] else -variable)
        log(f"fixed canonical support={fixed_support_count} from {args.fix_solution}")

    solver = Solver(verbose=0, time_limit=args.time_limit, threads=args.threads)
    # The contiguous zero-delimited API avoids hundreds of thousands of
    # Python-to-C extension calls on Windows.
    flat_clauses = array.array("i")
    for clause in enc.cnf.clauses:
        flat_clauses.extend(clause)
        flat_clauses.append(0)
    solver.add_clauses(flat_clauses)
    for lits, rhs, _ in xors:
        solver.add_xor_clause(lits, rhs)
    log(f"starting CryptoMiniSat time_limit={args.time_limit}s threads={args.threads}")
    solve_start = time.perf_counter()
    solved, assignment = solver.solve(assumptions=assumptions)
    solve_seconds = time.perf_counter() - solve_start
    status = "SAT" if solved is True else "UNSAT" if solved is False else "TIME_LIMIT"
    log(f"finished status={status} solve_seconds={solve_seconds:.3f}")

    pattern = []
    if assignment is not None:
        for letter, width in base.BLOCK_WIDTHS.items():
            for row in range(base.ROWS):
                for col in range(width):
                    if assignment[enc.pool.id(base.xkey(letter, row, col))]:
                        pattern.append({"letter": letter, "row": row, "column": col})
        log(f"SAT support={len(pattern)}")

    report = {
        "instance": "fastxgemm-n3r23s5t6",
        "model": "GF(2) necessary condition with native XOR and contraction-rank cuts",
        "logical_scope": {
            "UNSAT": "rules out exact official cyclic solutions at or below the cap",
            "SAT": "mod-2 support only; integer sign lifting still required",
            "TIME_LIMIT": "no mathematical conclusion",
        },
        "support_cap": args.support_cap,
        "known_valid_lower_bound_imposed": args.known_lb,
        "status": status,
        "build_seconds": build_seconds,
        "solve_seconds": solve_seconds,
        "time_limit_seconds": args.time_limit,
        "threads": args.threads,
        "variables": enc.pool.top,
        "cnf_clauses": len(enc.cnf.clauses),
        "clause_families": enc.counts,
        "fixed_solution": str(args.fix_solution) if args.fix_solution else None,
        "fixed_support_count": fixed_support_count,
        **metadata,
    }
    if pattern:
        report["found_support"] = len(pattern)
        report["found_pattern"] = pattern
    args.json.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in report.items() if k != "found_pattern"}, indent=2))


if __name__ == "__main__":
    main()
