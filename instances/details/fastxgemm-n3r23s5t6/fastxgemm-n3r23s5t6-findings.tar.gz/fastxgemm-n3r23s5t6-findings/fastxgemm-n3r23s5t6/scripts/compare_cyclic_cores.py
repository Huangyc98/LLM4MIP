#!/usr/bin/env python3
"""Compare two S5/T6 cores modulo standard exact template symmetries."""

from __future__ import annotations

import argparse
import itertools
import json
import sys
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import exact_semantic_audit as semantic  # noqa: E402


def load(path: Path):
    values, _ = semantic.read_solution(path)
    return {letter: np.asarray(matrix, dtype=int)
            for letter, matrix in semantic.reconstruct_blocks(values, 1e-7).items()}


def transform(blocks, p: np.ndarray):
    p_inv = np.rint(np.linalg.inv(p)).astype(int)
    result = {}
    for letter, matrix in blocks.items():
        output = np.empty_like(matrix)
        for col in range(matrix.shape[1]):
            coefficient = matrix[:, col].reshape(3, 3)
            output[:, col] = (p_inv.T @ coefficient @ p.T).reshape(9)
        result[letter] = output
    return result


def group_key(vectors) -> tuple[int, ...]:
    variants = []
    for rotation in range(3):
        rotated = vectors[rotation:] + vectors[:rotation]
        for signs in ((1, 1, 1), (-1, -1, 1), (-1, 1, -1), (1, -1, -1)):
            variants.append(tuple(
                int(value)
                for vector, sign in zip(rotated, signs)
                for value in sign * vector
            ))
    return min(variants)


def canonical_key(blocks) -> tuple:
    a_columns = sorted(tuple(int(x) for x in blocks["A"][:, col])
                       for col in range(semantic.S))
    groups = sorted(
        group_key([blocks[letter][:, col] for letter in "BCD"])
        for col in range(semantic.T)
    )
    return tuple(a_columns), tuple(groups)


def signed_permutations():
    for permutation in itertools.permutations(range(3)):
        for signs in itertools.product((-1, 1), repeat=3):
            matrix = np.zeros((3, 3), dtype=int)
            for row, col in enumerate(permutation):
                matrix[row, col] = signs[row]
            yield matrix


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("left", type=Path)
    parser.add_argument("right", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    args = parser.parse_args()
    args.json.parent.mkdir(parents=True, exist_ok=True)
    left = load(args.left)
    right = load(args.right)
    right_key = canonical_key(right)
    matches = []
    tested = 0
    for p in signed_permutations():
        tested += 1
        candidate = transform(left, p)
        if canonical_key(candidate) == right_key:
            matches.append(p.tolist())
    raw_differences = sum(
        int(np.count_nonzero(left[letter] != right[letter])) for letter in "ABCD"
    )
    report = {
        "left": str(args.left),
        "right": str(args.right),
        "equivalence_group": (
            "simultaneous signed-coordinate conjugation (48 monomial 3x3 maps), "
            "A-column permutation, BCD-group permutation, cyclic rotation within "
            "each BCD group, and BCD sign gauges with product +1"
        ),
        "raw_coefficient_differences": raw_differences,
        "signed_coordinate_maps_tested": tested,
        "equivalent": bool(matches),
        "matching_maps": matches,
        "interpretation": (
            "equivalent=true proves equivalence within this explicit finite symmetry "
            "group; false would not prove inequivalence under the full tensor isotropy group"
        ),
    }
    args.json.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
