#!/usr/bin/env python3
"""Search/prove K<=50 around the published BILR-153 support."""

from __future__ import annotations

import argparse
import json
import math
import sys
import time
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import exact_semantic_audit as semantic  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model", type=Path)
    parser.add_argument("start", type=Path)
    parser.add_argument("--max-new-support", type=int, default=0)
    parser.add_argument("--support-cap", type=int, default=50)
    parser.add_argument("--time-limit", type=float, default=600.0)
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--solution", type=Path)
    args = parser.parse_args()
    for path in (args.json, args.log, args.solution):
        if path is not None:
            path.parent.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()

    start_values, _ = semantic.read_solution(args.start)
    model = gp.read(str(args.model))
    model.Params.LogFile = str(args.log)
    model.Params.Threads = args.threads
    model.Params.TimeLimit = args.time_limit
    model.Params.FeasibilityTol = 1e-9
    model.Params.IntFeasTol = 1e-9
    model.Params.OptimalityTol = 1e-9
    model.Params.NumericFocus = 3
    model.Params.Presolve = 2
    model.Params.MIPFocus = 1

    outside = []
    all_core = []
    incumbent_support = 0
    for letter, width in semantic.BLOCK_WIDTHS.items():
        for row in range(9):
            for col in range(width):
                pos_name, neg_name = f"POS_{letter}_{row}_{col}", f"NEG_{letter}_{row}_{col}"
                pos, neg = model.getVarByName(pos_name), model.getVarByName(neg_name)
                all_core.extend((pos, neg))
                if round(start_values[pos_name]) == 0 and round(start_values[neg_name]) == 0:
                    outside.extend((pos, neg))
                else:
                    incumbent_support += 1
    for i in range(9):
        for j in range(9):
            for k in range(9):
                model.getVarByName(f"RESIDUAL_{i}_{j}_{k}").UB = 0.0

    model.addConstr(gp.quicksum(all_core) <= args.support_cap, name="K_CAP")
    model.addConstr(gp.quicksum(outside) <= args.max_new_support,
                    name="MAX_NEW_SUPPORT_OUTSIDE_BILR153")
    model.update()
    model.read(str(args.start))
    model.optimize()

    status = {
        GRB.OPTIMAL: "FEASIBLE_FOUND",
        GRB.INFEASIBLE: "INFEASIBLE",
        GRB.TIME_LIMIT: "TIME_LIMIT",
        GRB.INTERRUPTED: "INTERRUPTED",
    }.get(model.Status, str(model.Status))
    report = {
        "instance": "fastxgemm-n3r23s5t6",
        "scope": (
            "exact official MPS, arbitrary deletion/resigning of published BILR-153 "
            "locations, with bounded new underlying support locations"
        ),
        "start": str(args.start),
        "incumbent_support": incumbent_support,
        "outside_support_locations": len(outside) // 2,
        "support_cap": args.support_cap,
        "max_new_support": args.max_new_support,
        "status_code": int(model.Status),
        "status": status,
        "solution_count": int(model.SolCount),
        "runtime_seconds": float(model.Runtime),
        "wall_seconds": time.perf_counter() - started,
        "node_count": float(model.NodeCount),
        "best_bound": (
            float(model.ObjBound)
            if model.IsMIP and math.isfinite(float(model.ObjBound)) else None
        ),
        "best_objective": float(model.ObjVal) if model.SolCount else None,
        "logical_scope": (
            "INFEASIBLE is a complete certificate only for this bounded neighborhood; "
            "TIME_LIMIT proves nothing; a feasible solution must be independently audited."
        ),
    }
    if args.solution and model.SolCount:
        model.write(str(args.solution))
        report["solution"] = str(args.solution)
    args.json.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
