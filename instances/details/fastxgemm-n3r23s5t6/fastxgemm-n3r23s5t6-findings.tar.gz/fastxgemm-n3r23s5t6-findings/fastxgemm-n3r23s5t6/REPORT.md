# `fastxgemm-n3r23s5t6` 续研报告

日期：2026-09-09

## 严格结论

```text
旧项目区间：[87,174]
新严格区间：[90,153]
```

三点必须同时说明：

1. **153 不是项目/GPT primal 贡献。** 它是 Ballard、Ikenmeyer、Landsberg、
   Ryder 在 [arXiv:1801.00843](https://arxiv.org/abs/1801.00843) 附录 B
   给出的 `S_Lader-Z3` 分解。本文只是完成来源识别、转录、模型映射和独立核验。
2. **90 是本项目的新 global lower bound。** 证明排除了 exact `K=29`，从而
   把旧下界 87 提高到 90。
3. **问题仍然 open。** 目前没有排除 exact `30<=K<=50`，因此不能把 153 写成
   optimal。

## 外部 exact UB 153

BILR 构造由 5 个固定项和 6 个三循环 orbit 组成，共 `R=23`。按官方
balanced-ternary 编码精确展开得到

```text
E = 0
K = 51
raw factor support = 3K = 153
official objective = 1000E + 3K = 153
```

我们把全部 414 个 POS/NEG 整数变量固定到该构造，在未修改的官方 MPS 上由
Gurobi 完成其余变量；20,394 个变量、240,116 条约束的结果目标为 153。随后又用
整数张量展开独立检查全部 729 个 Brent identities，并检查行、上下界与整数性，
违约数均为 0。主证据位于 `artifacts/external-audit/`，论文原式的直接转录严格解
为 `solutions/external-bilr2018-strict-153.sol`。

研究过程中还从 Laurent Sorber 的 `K=58` start 通过一个小 unimodular shear
独立得到 `K=51`。有限群映射证明它与 BILR 构造等价；这份数值不同的严格解单独
归档为 `artifacts/bilr-equivalent-shear-strict-153.sol`。它是对外部结果的独立
再发现与交叉核验，不构成新的 primal authorship。

## global LB 90

每个 mode 的 9 个 target slices 都有秩 3，因此每个 factor row 的 degree 至少为
3；同一 mode 中两个 degree-3 tight rows 不能共享 rank position。

若 exact `K=29`，度数型只可能为 `(5,3^8)` 或 `(4,4,3^7)`：

- `(5,3^8)` 需要 `8*3=24` 个互异 rank positions，但实例只有 23 个；
- `(4,4,3^7)` 中七个 tight rows 在三种 mode 各覆盖 21 个位置，只留下两个
  underlying vectors。按照两者属于固定 A 或 B/C/D orbit 的四种组合逐类估计，
  可达到的 `K` 上界依次不超过 25、28、27、27，全部小于 29。

因此 exact 点满足 `K>=30`，即 support 至少 90。inexact 整数点已有官方
support floor 84，且 residual sum 至少 1，所以对官方整数可行域有全局有效 cut：

```text
sum(ABS_ALT_U, ABS_ALT_V, ABS_ALT_W) + 6*sum(RESIDUAL) >= 90.
```

有限审计枚举了 253 个 uncovered-vector pairs 与 36 个 non-tight-row pairs，共
9,108 个坐标/orbit 情形；全部通过。加入该 cut 后，官方 MPS 的 LP bound 与
root bound 都从 84 提高到 90。数学有效性来自组合证明，Gurobi probe 只验证模型
实现。完整证明见 `artifacts/LB90_PROOF.md`。

## 继续搜索结果与边界

围绕 BILR 153 构造完成了 coefficient Hamming radius 1/2、全部
`23*3^9=452,709` 个单完整向量替换，以及固定 51 个 support locations 下的
exact `K<=50` MIP；均无改进，最后一个分支完整返回 `INFEASIBLE`。这些只证明
相应局部或固定-support 范围。

同时枚举了 1,487,976 个有界 simultaneous-conjugation 矩阵，其中 480 个保持
ternary，最佳仍为 BILR 等价的 `K=51`。对这 480 个 parent 再做固定 A 删除，
完整检查 2,400 个 R22 与 4,800 个 R21 候选，最小分别为 1150 与 2147。

允许一个新 support 的 MIP、GF(2) SAT/XOR probes 均因 `TIME_LIMIT` 结束；它们
没有给出 infeasibility certificate，不能作为全局证明。现在要继续实质改进，
核心目标是对 exact `30<=K<=50` 生成可核验的 UNSAT/PB 证书，或找到新的
`K<=50` exact 构造。

## 可发布口径

可以声称严格区间 `[90,153]`、项目 LB 贡献 `84->90`、BILR 外部 UB 153 已在
官方 MPS 上独立严格核验。不能声称 153 是 GPT 找到的新 primal，也不能声称本题
已经 optimal。`3K` 是 raw factor support，不是 CSE 后的实际 addition count。
