#!/usr/bin/env python3
"""Finite audit for the post-tight-row case split in the R23 LB90 proof.

This script does not replace the linear-algebra lemmas.  It exhausts the
classification of the two underlying vectors that are uncovered by the seven
tight rows when an exact S=5,T=6,R=23 core is assumed to have K=29, and it
checks the small 3x3 row/column-line incidence lemma used in the last case.
"""

from __future__ import annotations

import argparse
import itertools
import json
from collections import Counter
from pathlib import Path


N = 3
A_LABELS = tuple(f"A{i}" for i in range(5))
ORBIT_LABELS = tuple(f"{letter}{orbit}" for orbit in range(6) for letter in "BCD")
LABELS = A_LABELS + ORBIT_LABELS
GRID = tuple((row, column) for row in range(N) for column in range(N))


def kind(pair: tuple[str, str]) -> str:
    a_count = sum(label.startswith("A") for label in pair)
    if a_count == 2:
        return "two_A"
    if a_count == 1:
        return "A_plus_BCD"
    orbit_ids = {label[1:] for label in pair}
    return "two_BCD_same_orbit" if len(orbit_ids) == 1 else "two_BCD_distinct_orbits"


def upper_bound(case: str) -> int:
    # Every common-covered position is a nonzero coordinate singleton.
    # An uncovered A has support at most two (the two non-tight rows).
    # A one-uncovered BCD orbit has support at most 1+3+3=7.
    # A two-uncovered BCD orbit has 20 common singletons.  They consume 20
    # of the 21 tight incidences, so its remaining vector has one tight and
    # at most two non-tight entries; the orbit contributes at most 2+2+3=7.
    # With two distinct affected orbits, the line-incidence lemma below
    # sharpens each orbit from the naive 7 to at most 5.
    return {
        "two_A": 21 + 2 + 2,
        "A_plus_BCD": 19 + 2 + 7,
        "two_BCD_same_orbit": 20 + 7,
        "two_BCD_distinct_orbits": 17 + 5 + 5,
    }[case]


def audit_line_incidence() -> dict:
    """Check the at-most-two non-tight incidences in a row/column pair.

    Canonically let B be the uncovered vector of one affected orbit.  Tight
    slice geometry gives B=(x,y), C contained in grid row a, and D contained
    in grid column a.  Their required tight primary entries are (a,x) and
    (y,a).  Enumerate every two-cell non-tight set, every B cell in it, and
    every a for which those primary entries really are tight.  The two line
    supports meet the non-tight set with total multiplicity at most two.
    """
    checks = 0
    maximum = -1
    examples = []
    for non_tight in itertools.combinations(GRID, 2):
        non_tight_set = set(non_tight)
        for x, y in non_tight:
            for a in range(N):
                c_primary = (a, x)
                d_primary = (y, a)
                if c_primary in non_tight_set or d_primary in non_tight_set:
                    continue
                c_extra = sum(cell[0] == a for cell in non_tight)
                d_extra = sum(cell[1] == a for cell in non_tight)
                total = c_extra + d_extra
                checks += 1
                maximum = max(maximum, total)
                if len(examples) < 8:
                    examples.append(
                        {
                            "non_tight": non_tight,
                            "B": (x, y),
                            "a": a,
                            "C_required_tight": c_primary,
                            "D_required_tight": d_primary,
                            "non_tight_line_incidences": total,
                        }
                    )
                if total > 2:
                    raise AssertionError((non_tight, (x, y), a, total))
    return {"checks": checks, "maximum_non_tight_line_incidences": maximum, "examples": examples}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", type=Path, required=True)
    args = parser.parse_args()

    pairs = list(itertools.combinations(LABELS, 2))
    counts = Counter(kind(pair) for pair in pairs)
    expected = Counter(
        {
            "two_A": 10,
            "A_plus_BCD": 90,
            "two_BCD_same_orbit": 18,
            "two_BCD_distinct_orbits": 135,
        }
    )
    if counts != expected or len(pairs) != 253:
        raise AssertionError((counts, expected, len(pairs)))

    bounds = {case: upper_bound(case) for case in expected}
    line_audit = audit_line_incidence()
    result = {
        "instance": "fastxgemm-n3r23s5t6",
        "assumption_under_audit": "exact reconstruction with K=29",
        "post_lemma_structure": {
            "degree_multiset": [4, 4, 3, 3, 3, 3, 3, 3, 3],
            "tight_rows": 7,
            "rank_positions_used_per_mode": 21,
            "uncovered_underlying_vectors": 2,
            "non_tight_grid_rows": 2,
        },
        "uncovered_pair_count": len(pairs),
        "case_counts": dict(sorted(counts.items())),
        "one_factor_support_upper_bounds": bounds,
        "all_bounds_below_29": all(value < 29 for value in bounds.values()),
        "different_orbit_line_incidence_audit": line_audit,
        "conclusion": "The complete post-lemma case split contradicts K=29.",
        "scope": "finite case audit conditional on the tight-row linear-algebra lemmas",
    }
    if not result["all_bounds_below_29"] or line_audit["maximum_non_tight_line_incidences"] > 2:
        raise RuntimeError("R23 LB90 case audit failed")
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
