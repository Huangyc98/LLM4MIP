#!/usr/bin/env python3
"""Exact audit of the cyclic Laderman-family decomposition in BILR 2018.

The matrices below are transcribed from equations (77)--(84), page 29, of
Ballard--Ikenmeyer--Landsberg--Ryder, arXiv:1801.00843v1.  Matrix entries are
flattened row-major as trilinear forms in trace(XYZ).
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path


Matrix = list[list[int]]
Vector = tuple[int, ...]


FIXED: list[Matrix] = [
    [[0, 0, 0], [0, 1, 0], [0, 0, 0]],
    [[0, 0, 0], [0, 0, 0], [0, 0, 1]],
    [[-1, 1, 0], [-1, 0, 0], [0, 0, 0]],
    [[1, 0, 0], [1, 0, 0], [0, 0, 0]],
    [[1, -1, 0], [0, 0, 0], [0, 0, 0]],
]


ORBIT_SEEDS: list[tuple[Matrix, Matrix, Matrix]] = [
    (
        [[1, 0, 0], [0, 0, 0], [0, 0, 0]],
        [[0, 0, 1], [0, 0, 0], [0, 0, 0]],
        [[0, 0, 0], [0, 0, 0], [1, 0, 0]],
    ),
    (
        [[0, 0, 0], [0, 0, 1], [0, -1, -1]],
        [[0, 0, 0], [1, 0, 0], [-1, 1, 0]],
        [[0, -1, -1], [0, 0, -1], [0, 0, 0]],
    ),
    (
        [[0, -1, 0], [0, 0, 0], [0, 0, 0]],
        [[1, -1, 0], [1, -1, -1], [0, 1, 1]],
        [[0, 0, 0], [1, 0, 0], [0, 0, 0]],
    ),
    (
        [[0, 0, 0], [0, 0, 0], [0, -1, 0]],
        [[0, 1, 1], [-1, 1, 1], [1, -1, 0]],
        [[0, 0, 0], [0, 0, -1], [0, 0, 0]],
    ),
    (
        [[0, 0, 0], [0, 0, -1], [0, 0, 1]],
        [[0, 0, 0], [-1, 0, 0], [1, 0, 0]],
        [[0, 0, 1], [0, 0, 1], [0, 0, 0]],
    ),
    (
        [[0, 0, 0], [0, 0, 0], [0, 1, 1]],
        [[0, 0, 0], [0, 0, 0], [1, -1, 0]],
        [[0, 1, 1], [0, 0, 0], [0, 0, 0]],
    ),
]


def flatten(matrix: Matrix) -> Vector:
    return tuple(value for row in matrix for value in row)


def support(vector: Vector) -> int:
    return sum(value != 0 for value in vector)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    fixed = [flatten(matrix) for matrix in FIXED]
    seeds = [tuple(flatten(matrix) for matrix in seed) for seed in ORBIT_SEEDS]
    terms: list[tuple[Vector, Vector, Vector]] = [(a, a, a) for a in fixed]
    for x, y, z in seeds:
        terms.extend([(x, y, z), (y, z, x), (z, x, y)])

    residuals = []
    for a in range(9):
        ai, aj = divmod(a, 3)
        for b in range(9):
            bj, bk = divmod(b, 3)
            for c in range(9):
                ck, ci = divmod(c, 3)
                target = int(aj == bj and bk == ck and ci == ai)
                actual = sum(u[a] * v[b] * w[c] for u, v, w in terms)
                if actual != target:
                    residuals.append(
                        {"u": a, "v": b, "w": c, "actual": actual, "target": target}
                    )

    fixed_core_supports = [support(a) for a in fixed]
    orbit_core_supports = [[support(vector) for vector in seed] for seed in seeds]
    core_support = sum(fixed_core_supports) + sum(map(sum, orbit_core_supports))
    full_support = sum(
        support(vector) for term in terms for vector in term
    )

    # In fastxgemm's block order, a seed x*y*z is represented by B=x, D=y, C=z.
    core = {
        "A": [list(vector) for vector in fixed],
        "B": [list(seed[0]) for seed in seeds],
        "C": [list(seed[2]) for seed in seeds],
        "D": [list(seed[1]) for seed in seeds],
    }
    report = {
        "source": {
            "paper": "The geometry of rank decompositions of matrix multiplication II: 3x3 matrices",
            "authors": ["Grey Ballard", "Christian Ikenmeyer", "J. M. Landsberg", "Nick Ryder"],
            "arxiv": "1801.00843v1",
            "location": "Appendix B, equations (77)-(84), PDF page 29",
            "decomposition": "S_Lader-Z3",
        },
        "transcription": {
            "fixed_count": len(fixed),
            "orbit_seed_count": len(seeds),
            "rank": len(terms),
            "coefficient_domain": sorted({value for term in terms for vector in term for value in vector}),
            "row_major_matrix_coordinates": True,
        },
        "exact_integer_tensor_audit": {
            "identity_count": 9**3,
            "nonzero_residual_count": len(residuals),
            "residual_l1": sum(abs(item["actual"] - item["target"]) for item in residuals),
            "exact": not residuals,
            "residual_examples": residuals[:20],
        },
        "support": {
            "fixed_core_supports": fixed_core_supports,
            "orbit_seed_supports": orbit_core_supports,
            "core_K": core_support,
            "full_factor_support": full_support,
            "three_times_core": 3 * core_support,
            "candidate_fastxgemm_objective_if_mapped": full_support,
            "strictly_below_author_174": full_support < 174,
        },
        "fastxgemm_core_mapping": core,
        "interpretation": (
            "If the published matrices have been transcribed correctly, this is an exact ternary "
            "S=5,T=6 decomposition with K=51 and fastxgemm objective 153. It must still be "
            "encoded into and checked against the official MPS before claiming a strict upper bound."
        ),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
