# `fastxgemm-n3r23s5t6` 的历史全局下界 87

> 该证明已被同目录的 `LB90_PROOF.md` 严格加强；保留它是为了记录证明演进。

本证明只针对官方 MIP 中的 balanced-ternary、cyclic、`N=3,R=23,S=5,T=6`
模型。它不证明一般的 3×3 矩阵乘法 rank 下界，也不证明当时使用的 Sorber 174
最优。

## 记号

模型使用

```text
U = [A B C D],   V = [A D B C],   W = [A C D B],
```

其中 `A` 有 5 列，`B,C,D` 各有 6 列。记 `K` 为 `[A B C D]` 中
非零系数总数。三个因子矩阵只是这些 block 的列置换，所以各自都恰有
`K` 个非零，完整因子支撑为 `F=3K`。

## 引理 1：exact 分解的每个因子行至少含 3 个非零

把第一模态的一行写成 `i=(n,q)`。相应的目标 tensor slice 是一个
9×9 矩阵，在

```text
((q,m),(m,n)), m=0,1,2
```

处有三个 1，因此矩阵秩为 3。该 slice 在分解中等于

```text
sum_{r: U[i,r] != 0} U[i,r] V[:,r] W[:,r]^T.
```

若 `U` 第 `i` 行的非零数为 `d_i`，右侧秩至多为 `d_i`，故
`d_i>=3`。同理适用于所有九行和另外两个模态。特别地
`K=sum_i d_i>=27`。

## 引理 2：两个不同的 degree-3 行不能共用 rank column

称 `d_i=3` 的行为 tight。一个秩 3 slice 恰由三个 rank-one 矩阵相加时，
三个相对模态向量必须分别位于该 slice 的精确行空间和列空间。
对 `i=(n,q)`，每个参与列 `r` 因而满足

```text
V[:,r] in span{e_(q,m): m=0,1,2},
W[:,r] in span{e_(m,n): m=0,1,2}.
```

若两个不同 tight 行 `(n,q)` 与 `(n',q')` 共用列：当 `q!=q'` 时，
两个允许的 `V[:,r]` 坐标子空间不交，迫使 `V[:,r]=0`；当 `q=q'`
时必有 `n!=n'`，两个允许的 `W[:,r]` 子空间不交，迫使 `W[:,r]=0`。
两种情况都会使共享列对应的 rank-one 项为零；tight slice 随即至多只剩
两个非零 rank-one 项，不可能得到秩 3。这个矛盾甚至不需要额外依赖模型的
“每个 factor column 非零”约束。因此不同 tight 行各使用互不相交的三个
rank columns。

## exact 情形：`K>=29`

若 `K<=28`，九个行度数均至少为 3，而超出最小总和 27 的余量至多为 1。
所以至少八行 tight。引理 2 要求至少 `8*3=24` 个不同 rank columns，
但模型只有 23 列，矛盾。因此 exact reconstruction 必有

```text
K >= 29,   F=3K >= 87.
```

此方法不能排除 `K=29`：度数模式 `3^7 4^2` 只占用 21 个由 tight 行
覆盖的 rank columns，仍留下两列。故这里不能把下界写成 90，更不能据此
断言 174 optimal。

## 对整个 MIP 有效的 cut

官方模型原有两条 RHS 为 84 的支撑约束，因此任意整数可行点满足
`sum(ABS_ALT)>=84`。整数 factor pattern 使每个重构 tensor 系数为整数；
若不 exact，至少一个 tensor discrepancy 的绝对值至少为 1，于是
`sum(RESIDUAL)>=1`。结合 exact 情形的 `F>=87`，所有整数可行点都满足

```text
sum(ABS_ALT) + 3 sum(RESIDUAL) >= 87.                 (CUT-87)
```

这是一条 **integer-valid cut**：证明使用了离散 factor pattern，不声称它
对原始 LP relaxation 中任意分数点自动成立。原目标为

```text
1000 sum(RESIDUAL) + sum(ABS_ALT) + 0.001 sum(ABS_DIFF),
```

所有变量非负，所以 `(CUT-87)` 同时给出全局目标下界 87。

当时使用的 Sorber 历史解 174 有 `E=0,F=174`，在 cut 左侧取 174，当然仍严格
可行。本文件保留为早期 LB87 证明；当前更强结果为 `LB=90, UB=153`，见实例
README 与 `LB90_PROOF.md`。
