# 目标 174 解的来源核查

## 结论

`fastxgemm-N3-R23-S5-T6.lp.mst` 不仅位于 Laurent Sorber 的公开作者仓库，
也位于 MIPLIB 2017 的原始官方 submission 中。原始 submission 副本与本地
作者仓库 checkout 的文件 **逐字节相同**：

```text
bytes:   492838
SHA256:  03ad7e05cef5af4a2d9fd701eda2a9522bc2ef06a8953aacd26c5c3d28233a8c
```

本项目保留了两份来源文件：

- `source/fastxgemm-N3-R23-S5-T6.lp.mst`：作者仓库 snapshot；
- `source/official-submission-fastxgemm-N3-R23-S5-T6.lp.mst`：从 ZIB 原始
  submission 固定 commit 下载的副本。

## 固定来源

- 作者仓库：<https://github.com/lsorber/fast-matrix-multiplication>
- 本地作者仓库 snapshot：`c2adb64ebac59571a6bf04ac6e4ede38c4850378`
- 文件首次引入 commit：
  [`165ac7dc40e3cb0bbb8d03008a2b787acd9cbe9e`](https://github.com/lsorber/fast-matrix-multiplication/commit/165ac7dc40e3cb0bbb8d03008a2b787acd9cbe9e)
- Git blob：`645cfd87c08f99615be4effe326ae1ef0b8d1ce3`
- MIPLIB 原始 submission commit：
  [`26a7703fda632540c6df3c537f41b07f61d7de37`](https://git.zib.de/miplib2017/submissions/-/commit/26a7703fda632540c6df3c537f41b07f61d7de37)
- submission 路径：
  [`9e830.../misc/fastxgemm-N3-R23-S5-T6.lp.mst`](https://git.zib.de/miplib2017/submissions/-/blob/26a7703fda632540c6df3c537f41b07f61d7de37/9e830301-898b-4340-97f7-c8478277e652/misc/fastxgemm-N3-R23-S5-T6.lp.mst)

作者仓库中 LP 的 SHA-256 为
`22b3511c630c094f89d2634592adfa95632396cc1c732cbfe7f5febe8e88a71b`。
逐项模型对比 `lp_mps_equivalence.json` 证明它与当前官方 MPS 的变量、行、
上下界、目标、RHS、sense 和全部 786402 个矩阵系数相同；唯一序列化差异是
414 个 `[0,1]` 变量在 LP 中标作 binary，在 MPS 中标作 bounded integer，
二者可行域相同。

## 能够与不能够声称的内容

可以确定：目标 174 的 start 在 2017 年原始提交时已经存在，且对当前官方
MPS 严格可行；MIPLIB 当前公开解历史没有登记它。

公开资料没有解释为什么 supplementary `.mst` 没进入 best-solution archive。
因此只能把“标准化流程没有自动导入 submitter-specific start”作为合理推测，
不能声称 MIPLIB 拒绝了它、文件未提交、或它曾因数值问题被判无效。

最后，174 构造来源于外部作者；本轮研究的贡献是发现、迁移和独立严格核验，
不能标作 GPT 自主构造。
