# GF(2) necessary-condition encoding audit

> **Historical, superseded experiment.** This probe targeted the earlier
> Sorber upper bound 174 and interval `[87,174]`. The current strict interval is
> `[90,153]`; improving its upper bound requires an exact construction with
> `K<=50`. The `K<=57` run below is retained only as an audit of the earlier
> encoding and contributes no current bound.

This audit documents `scripts/mod2_support_probe.py`. The 600-second `K<=57`
run timed out, so this encoding produced **no lower-bound certificate** in this
study; the notes below only establish why an eventual `INFEASIBLE` result would
be relevant.

## Mapping

- One support binary is created for each underlying coefficient of
  `[A B C D]`: `9*(5+3*6)=207` binaries.
- `x=1` means the ternary coefficient is `+1` or `-1`. Both reduce to 1 in
  GF(2); zero reduces to 0.
- The cyclic maps are exactly
  `U=[A B C D], V=[A D B C], W=[A C D B]`.
- Each of the `9^3*23=16,767` tensor/rank products is an exact Boolean AND.
  Duplicate A inputs in a cube are deduplicated before the standard AND
  linearization; this is correct because `x*x=x` over `{0,1}`.
- Each of 729 tensor coordinates enforces
  `sum_r y_ijkr - 2*q_ijk = T_ijk`, with `0<=q<=11`. This is exactly parity:
  at most 23 products contribute, so 11 is a sufficient upper bound.
- Column-nonzero constraints cover 5 A vectors and 18 B/C/D vectors. In a
  cyclic orbit term each of B/C/D appears once in every factor triple.
- Nine row-degree constraints are valid because each factor has the same row
  support count under the block permutations; exact tensor slices have rank 3.
- `sum x<=57` is exactly the candidate strict-improvement condition `K<=57`.

The resulting dimensions are 17,703 integer variables, 66,660 constraints and
182,277 nonzeros. The row count independently reconciles as 1 support cap + 23
column constraints + 9 row constraints + 65,898 AND constraints + 729 parity
constraints.

## Logical direction

Every exact integer ternary cyclic decomposition with `K<=57` maps to a feasible
point of this GF(2) model. The converse is not guaranteed because a Boolean
support pattern may fail to lift to signs over the integers. Consequently:

- proven `INFEASIBLE` would rule out `K<=57`;
- GF(2) feasibility would only be a necessary-condition witness;
- `TIME_LIMIT` proves nothing either way.

## Positive control and actual run

With cap 58, the known exact author support is accepted in 0.005 seconds with
`found_support=58`. With cap 57, Gurobi explored 17,764 nodes for 600.014 seconds,
found no incumbent, and returned `TIME_LIMIT`. At that historical stage this
left the interval at `[87,174]`; it proves nothing about the current `[90,153]`
interval.
