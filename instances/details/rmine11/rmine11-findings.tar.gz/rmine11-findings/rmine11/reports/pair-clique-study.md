# rmine11 precedence-clique cut 实验

## 结果

从已精确验证的 394 条 precedence pair cuts 模型出发，三轮连续 root-LP clique separation 得到：

| 项目 | 数值 |
|---|---:|
| 394-pair 基线 root LP | -2521.5301057139704 |
| 加 clique 后 root LP | -2521.355937803649 |
| 相对 pair 基线提高 | 0.1741679103216 |
| clique cuts | 70 |
| 最大已加入 clique | 8 个节点 |
| 实验脚本用时 | 25.80 s |

每轮结果：

| 轮次 | 新增 cuts | root LP | 相对 pair 基线提高 |
|---:|---:|---:|---:|
| 1 | 44 | -2521.378595318067 | 0.151510395904 |
| 2 | 20 | -2521.360255765306 | 0.169849948664 |
| 3 | 6 | -2521.355937803649 | 0.174167910322 |

用最终增强 LP 的 row dual 有理化后，整数 max-flow/min-cut 证书给出并已独立验证：

```text
strict LB = -126067796890182353808399509 / 50000000000000000000000
          = -2521.355937803647076
```

相比先前 394-pair 的严格下界 `-2521.530105713968618`，严格提高 `0.174167910321542`；相比原始 root 严格下界 `-2522.047106832620469`，累计提高 `0.691169028973393`。

相对精确公开 incumbent `-2508.404143999999991662`，新绝对 gap 为 `12.951793803647084338`，MIPLIB 分母下约 `0.513684%`。从原始 root gap 计，pair+clique 共关闭约 `5.06612%`。

## 图与 clique 构造

脚本先解 394-pair 模型的连续 LP，然后在已有 pair 图涉及的时期 `2,3,4,6` 上：

1. 保留全部 394 条 seed edge 的端点；
2. 每期加入有限数量的高 LP 值、高 closure-pressure 候选；
3. 对候选的每一对，回到原始 MPS，以 `Fraction` 重算同周期 precedence closure union；
4. 只在至少一个资源的累计容量上严格超额时建立 conflict edge；
5. 完整枚举候选图中的 maximal cliques，按当前 LP 节点权重选择违反最大的、规模至少为 3 的 clique；
6. 加入 `sum_{i in Q} x_i,t <= 1`，重新解连续 LP，共三轮。

候选图统计：

| period | seed nodes | candidate nodes | exact conflict edges | size>=3 maximal cliques | 最大候选 clique | 枚举截断 |
|---:|---:|---:|---:|---:|---:|---|
| 2 | 54 | 164 | 1411 | 10668 | 9 | false |
| 3 | 37 | 154 | 971 | 1104 | 9 | false |
| 4 | 22 | 130 | 159 | 4 | 3 | false |
| 6 | 61 | 162 | 366 | 165 | 4 | false |

所有时期的 maximal-clique enumeration 都完整结束，没有触及 `200000` 上限。这里的 “maximal” 是相对于明确记录在 JSON 中的有限候选图，并不声称相对于全部 12,292 个变量的完整冲突图 maximal。

已加入 cuts 的分布：period 2 有 2 条 size-4；period 3 有 48 条（size 4--8）；period 4 有 2 条 size-3；period 6 有 20 条 size-4。

## 精确验证

`validate_clique_bundle.py` 不信任结果 JSON 中的结论，而是重新读取原始 MPS 并完成：

- 394/394 条 seed pair 逐条 closure/capacity 复核；
- 四个候选图全部重建，2,907/2,907 条 edge 由精确累计超额推出，规范化 graph hash 一致；
- 70/70 条 clique 的每一对节点都是重建图中的 exact conflict；
- 增强 MPS 未改变变量、目标或 precedence arcs；
- 394 条原 pair rows 和 70 条 clique rows 的变量、系数及 RHS 均逐项一致。

所有已加入 clique 内 pair 的最小精确超额为：

```text
6545007 / 1000000 = 6.545007
```

因此不是容差边缘结果。增强 MPS SHA-256：

```text
50fef2b056c6e072db59c2fbe6ad8602d99f2c6f8af09dd2c891969e7c37617d
```

证明分两层：validator 证明新增 rows 对原始模型全局有效；`exact-lb-cert.json.gz` 的 flow=cut witness 再证明增强模型的有理 Lagrangian 下界。两层合用才把该数值变成原始 rmine11 的严格全局下界。

## 文件

- `../artifacts/proof-bundle/agent-clique/clique_experiment.py`：候选图、maximal/maximum-weight separation 和 LP 轮次；
- `../artifacts/proof-bundle/agent-clique/validate_clique_bundle.py`：独立 cut/graph/MPS validator；
- `../artifacts/proof-bundle/agent-clique/run/result.json`：候选节点、graph hash、逐轮结果及每条 clique 的所有 pair witnesses；
- `../artifacts/proof-bundle/agent-clique/run/validation.json`：独立验证摘要；
- `../artifacts/proof-bundle/agent-clique/run/rmine11-pairs-plus-cliques.mps.gz`：394 pair + 70 clique 的整数模型。

pair+clique 阶段随后被 triple-cover 阶段继续增强，因此发布包只保留最终的
`../artifacts/exact-lb-lambda.json`、`../artifacts/exact-lb-cert.json.gz` 和
`../artifacts/exact-lb-verification.json`；完整命令见
`../artifacts/proof-bundle/README.md`。

## 边界

- 只做了有限候选图和三轮 separation；没有穷举完整 rmine11 conflict graph。
- 只加入规模至少 3 的 clique，因此改善不是靠额外 size-2 pair rows 冒充 clique 收益。
- 每个 clique 的不同边可以由不同资源证明冲突；只要任意两节点都不能共存，clique inequality 仍然有效。
- 全程只解连续 root LP、组合图枚举和 closure min-cut，没有启动长整数 MIP。
