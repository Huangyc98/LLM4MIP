# `rmine11` 三元 precedence-cover 实验

## 结果

实验从已经严格验证的 `394 pair + 70 clique` 模型出发，不运行整数
branch-and-bound，只在连续 root LP 上分离一种不被 pair conflict 解释的三元 cover：

```text
pair + clique strict LB                  -2521.355937803647076
+ 5 exact minimal triple covers         -2521.353274311517894
strict improvement                          0.002663492129182
```

新的严格全局下界为

```text
-126067663715575894697637121 / 50000000000000000000000
= -2521.353274311517894
```

相对原始 closure 证书 `-2522.047106832620469` 累计提高
`0.693832521102575`。相对严格 incumbent
`-2508.404143999999991662`，当前可复核区间宽度为
`12.949130311517902338`。

## 不等式

固定时期 `t` 后，令 `H(i)` 为选择 `x_i,t=1` 时由原始 precedence rows 强制
选择的同周期 closure。若三个变量 `i,j,k` 满足：

1. `H(i) union H(j)`、`H(i) union H(k)`、`H(j) union H(k)` 对两个累计资源都不
   超容量；
2. 但 `H(i) union H(j) union H(k)` 在至少一个累计资源上严格超容量；

则原整数模型中三者不可能同时等于 1，因此

```text
x_i,t + x_j,t + x_k,t <= 2
```

全局有效。因为每个 proper pair 都能共同存在于累计 knapsack 中，这五条并非把
已有 size-2 conflict 换个写法，也不是 clique inequality。

有限、确定性的候选筛选在 period 4 找到 5 条违反 cut，root LP 从
`-2521.355937803650` 数值提高到 `-2521.353274311527`。五条在加入前的 LP
violation 均约为 `0.0098672544`。所有三元 closure 的最小精确超容量为

```text
17131931 / 1000000 = 17.131931.
```

## 独立验证

`validate_triple_covers.py` 重新读取官方 MPS、pair+clique 基线 MPS、结果 JSON
和最终 MPS，并检查：

- 官方 MPS SHA-256 为
  `c78691fd9a3aba94f6a74cc62701e41f42d086125dd586bbd96f6d067aafafb1`；
- 5/5 个三元组的每个 proper pair 对两个累计资源均精确不超容量；
- 5/5 个完整三元 closure 均有严格正的精确超容量；
- 最终 MPS 未改变变量、目标、precedence arcs 或任何基线 side row；
- 5 条新 row 的变量、系数 `1` 和 RHS `2` 均逐项一致。

增强 MPS SHA-256：

```text
98bc534c9f97fc5d4166046d3ce2ba5c1b6b4c98a119b66f3cd1f954c7a2f639
```

最后，以增强 LP 的有理化 row multipliers 构造整数 max-flow 与同容量 min-cut；
`exact_lagrangian_certificate.py verify` 已检查 flow 容量、守恒、cut 容量和最终
有理 bound，结果为 `verified=true`。

## 文件与边界

- `../artifacts/proof-bundle/agent-cover-rmine11/triple_cover_experiment.py`：有限候选筛选与 LP separation；
- `../artifacts/proof-bundle/agent-cover-rmine11/validate_triple_covers.py`：独立原始-MPS cut/model validator；
- `../artifacts/proof-bundle/agent-cover-rmine11/run/result.json`：完整候选统计与五条 cut witness；
- `../artifacts/proof-bundle/agent-cover-rmine11/run/validation.json`：cut/model 验证摘要；
- `../artifacts/proof-bundle/agent-cover-rmine11/run/rmine11-pair-clique-plus-triple-covers.mps.gz`：最终增强整数模型；
- `../artifacts/exact-lb-lambda.json`、`../artifacts/exact-lb-cert.json.gz`、
  `../artifacts/exact-lb-verification.json`：严格下界证据链。

逐层复核命令见 `../artifacts/proof-bundle/README.md`。

候选筛选只取每期有限数量的高 LP 值/高 closure-pressure 变量，并受 600 秒预算
限制，因此未找到更多 cut 不代表完整三元分离结束。本实验也没有证明
`rmine11` 最优。
