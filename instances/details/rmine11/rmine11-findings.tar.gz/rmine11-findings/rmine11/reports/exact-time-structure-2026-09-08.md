# `rmine11` exact-time structural supplement

Date: 2026-09-08

## Result boundary

This imported experiment adds an integer-equivalent extraction-time
formulation and a safe dominance fixing. It does **not** improve any published
bound in this repository and does not prove optimality. The retained headline
interval remains

```text
-2521.353274311517894 <= OPT <= -2508.404143999999991662.
```

The attachment's best original-formulation floating-point bound,
`-2522.030959725`, is weaker than the repository's portable exact lower bound
`-2521.353274311517894` by `0.677685413482106`. Its compact-formulation bound
is weaker still. Those numerical runs are therefore documented only as
formulation diagnostics, not imported as headline evidence.

## Exact-time reformulation

The submitted cumulative binary has the meaning

```text
x[b,t] = 1 iff block b has been extracted by the end of period t.
```

Define an event binary `y[b,t] = x[b,t] - x[b,t-1]`. Temporal monotonicity is
then an at-most-one condition for each physical block, and an all-zero event
vector means that the block is never extracted. Both resource rows for a
period become ordinary positive knapsacks in the event variables.

For a physical precedence arc `child -> parent`, set

```text
S[b] = sum_t (11-t) y[b,t].
```

At an integer at-most-one point, the cumulative precedence family for that
arc is equivalent to the single weighted inequality
`S[child] <= S[parent]`. The resulting model has:

| component | count |
|---|---:|
| binary event variables | 12,292 |
| block at-most-one rows | 1,331 |
| physical precedence rows | 9,610 |
| positive resource rows | 22 |
| total rows | 10,963 |
| matrix nonzeros | 215,149 |

The bijection `y[b,t]=x[b,t]-x[b,t-1]` and
`x[b,t]=sum_{s<=t} y[b,s]` establishes integer equivalence. The transformed
official incumbent has the same exact-decimal objective and, in the supplied
audit, zero row, bound and integrality violations.

This compactness does not strengthen the LP relaxation: one weighted-time
precedence inequality is weaker at fractional points than the whole
cumulative family. The attachment reports root relaxations of about
`-2522.0471068` for the original model and `-2616.494` for the compact model.
A 60-second compact run ended at `-2549.137305817`, compared with
`-2522.030959725` from its 30-second original-model run. This is why the
reformulation is retained as a platform for specialized branching or lazy
cumulative-row separation, not as a better generic MIP.

## Dominance fixing

There are 909 blocks with negative direct extraction cost and 422 with
positive direct cost. Taking the full geometric predecessor closure of all
negative-cost blocks leaves exactly 47 blocks outside it. Every outside block
has positive direct cost and cannot enable a negative-cost descendant.
Deleting those outside blocks preserves feasibility for all retained blocks,
reduces both resource consumptions and strictly reduces objective cost whenever
one had been extracted. Hence an optimum can be chosen with all 47 blocks
unextracted.

This fixes 249 original time-indexed binaries. In the compact model it removes
47 choice rows and 388 physical precedence rows; the supplied presolve account
therefore reduces 12,292 to 12,043 variables and 10,963 to 10,528 rows. The
official incumbent already leaves precisely these 47 blocks unextracted, so
the fixing produces no primal improvement.

## Reproduction and provenance

The curated generator is
[`scripts/build_exact_time_model.py`](../scripts/build_exact_time_model.py).
Generated MPS and solution files are intentionally not stored. After
downloading the original model from the
[official MIPLIB link](https://miplib.zib.de/WebData/instances/rmine11.mps.gz),
the exact-time model and transformed public solution can be regenerated under
`replay/`:

```sh
python scripts/build_exact_time_model.py \
  input/rmine11.mps.gz \
  replay/rmine11-exact-time.mps \
  solutions/rmine11-public.sol.gz \
  replay/rmine11-public-exact-time.sol
```

The source model's expected SHA-256 is recorded in
[`input/SHA256SUMS`](../input/SHA256SUMS). No original or generated MPS was
added by this supplement.
