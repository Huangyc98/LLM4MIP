#!/usr/bin/env python3
"""Separate exact cumulative precedence-clique cuts for rmine11 root LP.

The experiment starts from the already verified 394-pair strengthened model.
It rebuilds a richer, exact conflict graph on a bounded candidate set, enumerates
candidate-graph maximal cliques, and adds the most violated cliques of size at
least three in a few continuous-LP rounds.  No original integer MIP is solved.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import re
import sys
import time
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, Sequence, Tuple

sys.dont_write_bytecode = True
import gurobipy as gp
import networkx as nx


HERE = Path(__file__).resolve().parent
SHARED = HERE.parent / "agent-dual"
sys.path.insert(0, str(SHARED))
from exact_lagrangian_certificate import ClosureModel, parse_mps  # noqa: E402


CAP_RE = re.compile(r"^tcap_c(.+)_t(-?\d+)$")
VAR_RE = re.compile(r"^x_B(.+)_t(-?\d+)$")


def period_of(var: str) -> int:
    match = VAR_RE.match(var)
    if not match:
        raise ValueError(f"unexpected rmine variable name {var}")
    return int(match.group(2))


@dataclass
class Catalog:
    periods: List[int]
    resources: List[str]
    row: Dict[Tuple[str, int], str]
    variables_at: Dict[int, List[str]]
    weights: Dict[Tuple[str, int], Dict[str, Fraction]]
    prefix_capacity: Dict[Tuple[str, int], Fraction]


def discover(model: ClosureModel) -> Catalog:
    rows = {}
    for name in model.side_rows:
        match = CAP_RE.match(name)
        if match:
            rows[(match.group(1), int(match.group(2)))] = name
    periods = sorted({period for _resource, period in rows})
    resources = sorted({resource for resource, _period in rows})
    if not periods or not resources:
        raise ValueError("no tcap_c*_t* grid found")
    if any((resource, period) not in rows for resource in resources for period in periods):
        raise ValueError("incomplete period/resource capacity grid")
    variables_at = {period: [] for period in periods}
    for var in model.variables:
        period = period_of(var)
        if period not in variables_at:
            raise ValueError(f"variable period {period} absent from capacity grid")
        variables_at[period].append(var)
    weights = {}
    prefix_capacity = {}
    for resource in resources:
        running = Fraction(0)
        for period in periods:
            row = rows[(resource, period)]
            running += model.side_rhs[row]
            prefix_capacity[(resource, period)] = running
            weights[(resource, period)] = {}
            for var in variables_at[period]:
                value = model.side_columns[row].get(var, Fraction(0))
                if value <= 0:
                    raise ValueError(f"missing positive weight for {var} in {row}")
                weights[(resource, period)][var] = value
    return Catalog(periods, resources, rows, variables_at, weights, prefix_capacity)


def closures_for_period(model: ClosureModel, catalog: Catalog, period: int):
    nodes = catalog.variables_at[period]
    node_set = set(nodes)
    successors = {node: [] for node in nodes}
    for tail, head in model.arcs:
        if tail in node_set and head in node_set:
            successors[tail].append(head)
    memo: Dict[str, frozenset[str]] = {}
    active = set()

    def visit(node: str) -> frozenset[str]:
        if node in memo:
            return memo[node]
        if node in active:
            raise ValueError("cycle in same-period precedence graph")
        active.add(node)
        result = {node}
        for successor in successors[node]:
            result.update(visit(successor))
        active.remove(node)
        memo[node] = frozenset(result)
        return memo[node]

    for node in nodes:
        visit(node)
    return memo


def closure_weight(catalog: Catalog, period: int, closure: Iterable[str], resource: str) -> Fraction:
    weight = catalog.weights[(resource, period)]
    return sum((weight[node] for node in closure), Fraction(0))


def conflict_witness(
    catalog: Catalog,
    period: int,
    closures: Mapping[str, frozenset[str]],
    left: str,
    right: str,
):
    union = closures[left] | closures[right]
    witnesses = []
    for resource in catalog.resources:
        total = closure_weight(catalog, period, union, resource)
        capacity = catalog.prefix_capacity[(resource, period)]
        if total > capacity:
            witnesses.append((total - capacity, resource, total, capacity, len(union)))
    if not witnesses:
        return None
    margin, resource, total, capacity, size = max(witnesses)
    return {
        "resource": resource,
        "closure_union_weight": str(total),
        "prefix_capacity": str(capacity),
        "exact_overload_margin": str(margin),
        "closure_union_size": size,
    }


def seed_records(payload: dict):
    return [record for round_data in payload["rounds"] for record in round_data.get("records", [])]


def choose_candidates(
    catalog: Catalog,
    period: int,
    closures: Mapping[str, frozenset[str]],
    x_value: Mapping[str, float],
    seed_nodes: Iterable[str],
    extra: int,
):
    positive = [node for node in catalog.variables_at[period] if x_value[node] > 1e-9]
    weights = {
        node: {
            resource: closure_weight(catalog, period, closures[node], resource)
            for resource in catalog.resources
        }
        for node in positive
    }

    def pressure(node: str) -> float:
        return max(
            float(weights[node][resource] / catalog.prefix_capacity[(resource, period)])
            for resource in catalog.resources
        )

    fractional = [node for node in positive if x_value[node] < 1.0 - 1e-9]
    integral = [node for node in positive if x_value[node] >= 1.0 - 1e-9]
    selected = set(seed_nodes)
    selected.update(sorted(fractional, key=lambda node: x_value[node], reverse=True)[:extra])
    selected.update(sorted(fractional, key=pressure, reverse=True)[:extra])
    selected.update(sorted(integral, key=pressure, reverse=True)[: max(1, extra // 2)])
    return sorted(selected), {
        "positive_nodes": len(positive),
        "fractional_nodes": len(fractional),
        "seed_nodes": len(set(seed_nodes)),
        "candidate_nodes": len(selected),
    }


def build_exact_graph(
    catalog: Catalog,
    period: int,
    closures: Mapping[str, frozenset[str]],
    candidates: Sequence[str],
):
    graph = nx.Graph()
    graph.add_nodes_from(candidates)
    witnesses = {}
    singleton_overloads = []
    for node in candidates:
        for resource in catalog.resources:
            total = closure_weight(catalog, period, closures[node], resource)
            if total > catalog.prefix_capacity[(resource, period)]:
                singleton_overloads.append((node, resource, str(total)))
    if singleton_overloads:
        raise ValueError(f"candidate contains an individually impossible node: {singleton_overloads[:3]}")
    for left, right in itertools.combinations(candidates, 2):
        if right in closures[left] or left in closures[right]:
            continue
        witness = conflict_witness(catalog, period, closures, left, right)
        if witness is not None:
            edge = tuple(sorted((left, right)))
            graph.add_edge(*edge)
            witnesses[edge] = witness
    return graph, witnesses


def graph_digest(graph: nx.Graph) -> str:
    edges = sorted(tuple(sorted(edge)) for edge in graph.edges())
    encoded = json.dumps(edges, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def enumerate_large_maximal_cliques(graph: nx.Graph, limit: int, deadline: float):
    cliques = []
    truncated = False
    total_seen = 0
    for clique in nx.find_cliques(graph):
        total_seen += 1
        if len(clique) >= 3:
            cliques.append(tuple(sorted(clique)))
        if total_seen >= limit or time.perf_counter() >= deadline:
            truncated = True
            break
    return sorted(set(cliques)), total_seen, truncated


def clique_pair_witnesses(clique: Sequence[str], witnesses: Mapping[Tuple[str, str], dict]):
    result = []
    for left, right in itertools.combinations(clique, 2):
        edge = tuple(sorted((left, right)))
        if edge not in witnesses:
            raise ValueError(f"non-conflicting pair in proposed clique: {edge}")
        result.append({"variables": list(edge), **witnesses[edge]})
    return result


def validate_seed_edges(
    records: Sequence[dict],
    graphs: Mapping[int, nx.Graph],
):
    for index, record in enumerate(records):
        left, right = record["variables"]
        period = int(record["period"])
        if period not in graphs or not graphs[period].has_edge(left, right):
            raise ValueError(f"seed pair {index} absent from rebuilt exact graph")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("original_mps")
    parser.add_argument("seed_pair_result")
    parser.add_argument("seed_pair_mps")
    parser.add_argument("output_dir")
    parser.add_argument("--rounds", type=int, default=3)
    parser.add_argument("--extra-candidates", type=int, default=60)
    parser.add_argument("--cliques-per-period", type=int, default=20)
    parser.add_argument("--max-enumerated-per-period", type=int, default=200000)
    parser.add_argument("--wall-seconds", type=float, default=540.0)
    parser.add_argument("--threads", type=int, default=4)
    args = parser.parse_args()
    started = time.perf_counter()
    deadline = started + args.wall_seconds
    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    original = parse_mps(args.original_mps)
    catalog = discover(original)
    seed_payload = json.loads(Path(args.seed_pair_result).read_text(encoding="utf-8"))
    if seed_payload["model_sha256"] != original.sha256:
        raise ValueError("seed pair result does not match original MPS")
    pairs = seed_records(seed_payload)
    seed_by_period: Dict[int, set[str]] = {}
    for record in pairs:
        period = int(record["period"])
        seed_by_period.setdefault(period, set()).update(record["variables"])

    integer_model = gp.read(args.seed_pair_mps)
    relaxation = integer_model.relax()
    relaxation.Params.OutputFlag = 0
    relaxation.Params.Threads = args.threads
    relaxation.Params.TimeLimit = max(1.0, deadline - time.perf_counter())
    relaxation.optimize()
    if relaxation.Status != gp.GRB.OPTIMAL:
        raise RuntimeError(f"pair baseline LP not optimal; status={relaxation.Status}")
    baseline = relaxation.ObjVal
    lp_vars = {var.VarName: var for var in relaxation.getVars()}
    mip_vars = {var.VarName: var for var in integer_model.getVars()}
    initial_x = {name: var.X for name, var in lp_vars.items()}

    graphs = {}
    witnesses_by_period = {}
    cliques_by_period = {}
    graph_records = []
    for period in sorted(seed_by_period):
        if time.perf_counter() >= deadline:
            raise TimeoutError("wall budget exhausted while constructing conflict graphs")
        closures = closures_for_period(original, catalog, period)
        candidates, stats = choose_candidates(
            catalog, period, closures, initial_x, seed_by_period[period], args.extra_candidates
        )
        graph, witnesses = build_exact_graph(catalog, period, closures, candidates)
        maximal, total_seen, truncated = enumerate_large_maximal_cliques(
            graph, args.max_enumerated_per_period, deadline
        )
        graphs[period] = graph
        witnesses_by_period[period] = witnesses
        cliques_by_period[period] = maximal
        graph_records.append({
            "period": period,
            **stats,
            "edges": graph.number_of_edges(),
            "graph_sha256": graph_digest(graph),
            "maximal_cliques_size_at_least_3": len(maximal),
            "all_maximal_cliques_seen": total_seen,
            "enumeration_truncated": truncated,
            "largest_candidate_maximal_clique": max((len(c) for c in maximal), default=2),
            "candidates": candidates,
        })
    validate_seed_edges(pairs, graphs)

    added = set()
    cut_records = []
    rounds = []
    for round_index in range(1, args.rounds + 1):
        if time.perf_counter() >= deadline:
            break
        x_value = {name: var.X for name, var in lp_vars.items()}
        chosen = []
        for period in sorted(cliques_by_period):
            ranked = sorted(
                (
                    (sum(x_value[node] for node in clique), clique)
                    for clique in cliques_by_period[period] if clique not in added
                ),
                reverse=True,
            )
            accepted = 0
            for rank, (weight, clique) in enumerate(ranked, 1):
                if weight <= 1.0 + 1e-7:
                    break
                pair_witnesses = clique_pair_witnesses(clique, witnesses_by_period[period])
                record = {
                    "round": round_index,
                    "period": period,
                    "candidate_maximal": True,
                    "separation_rank_in_period": rank,
                    "maximum_weight_size_ge_3_for_period": accepted == 0,
                    "variables": list(clique),
                    "size": len(clique),
                    "lp_weight": weight,
                    "lp_violation": weight - 1.0,
                    "minimum_pair_overload_margin": str(min(
                        Fraction(witness["exact_overload_margin"]) for witness in pair_witnesses
                    )),
                    "pair_witnesses": pair_witnesses,
                }
                chosen.append(record)
                added.add(clique)
                accepted += 1
                if accepted >= args.cliques_per_period:
                    break
        if not chosen:
            rounds.append({"round": round_index, "cuts": 0, "objective": relaxation.ObjVal})
            break
        for record in chosen:
            cut_index = len(cut_records)
            variables = record["variables"]
            name = f"certified_clique_{cut_index}"
            relaxation.addConstr(gp.quicksum(lp_vars[v] for v in variables) <= 1, name=name)
            integer_model.addConstr(gp.quicksum(mip_vars[v] for v in variables) <= 1, name=name)
            cut_records.append(record)
        relaxation.Params.TimeLimit = max(1.0, deadline - time.perf_counter())
        relaxation.optimize()
        if relaxation.Status != gp.GRB.OPTIMAL:
            raise RuntimeError(f"clique-strengthened LP not optimal; status={relaxation.Status}")
        rounds.append({
            "round": round_index,
            "cuts": len(chosen),
            "objective": relaxation.ObjVal,
            "improvement_over_pair_baseline": relaxation.ObjVal - baseline,
        })

    enhanced_mps = output_dir / "rmine11-pairs-plus-cliques.mps.gz"
    integer_model.write(str(enhanced_mps))
    result = {
        "method": "candidate_graph_maximal_and_maximum_weight_precedence_clique_cuts",
        "original": {
            "path": str(Path(args.original_mps).resolve()),
            "sha256": original.sha256,
            "periods": catalog.periods,
            "resources": catalog.resources,
        },
        "seed_pair_result": str(Path(args.seed_pair_result).resolve()),
        "seed_pair_mps": str(Path(args.seed_pair_mps).resolve()),
        "seed_pair_count": len(pairs),
        "parameters": {
            "rounds": args.rounds,
            "extra_candidates": args.extra_candidates,
            "cliques_per_period": args.cliques_per_period,
            "max_enumerated_per_period": args.max_enumerated_per_period,
            "wall_seconds": args.wall_seconds,
            "threads": args.threads,
            "minimum_clique_size": 3,
        },
        "pair_baseline_root_lp": baseline,
        "clique_strengthened_root_lp": relaxation.ObjVal,
        "root_lp_improvement_over_pairs": relaxation.ObjVal - baseline,
        "conflict_graphs": graph_records,
        "rounds": rounds,
        "clique_cuts": cut_records,
        "enhanced_mps": str(enhanced_mps),
        "enhanced_mps_sha256": hashlib.sha256(enhanced_mps.read_bytes()).hexdigest(),
        "elapsed_seconds": time.perf_counter() - started,
        "scope_note": "Continuous LP rounds plus exact graph logic only; no long original MIP.",
    }
    result_path = output_dir / "result.json"
    result_path.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "pair_baseline_root_lp": baseline,
        "clique_strengthened_root_lp": relaxation.ObjVal,
        "root_lp_improvement_over_pairs": relaxation.ObjVal - baseline,
        "clique_cuts": len(cut_records),
        "maximum_clique_size": max((record["size"] for record in cut_records), default=0),
        "elapsed_seconds": result["elapsed_seconds"],
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
