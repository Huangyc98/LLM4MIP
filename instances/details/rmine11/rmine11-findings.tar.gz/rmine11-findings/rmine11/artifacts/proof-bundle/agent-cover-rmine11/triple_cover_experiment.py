#!/usr/bin/env python3
"""Separate exact minimal three-variable precedence-cover cuts for rmine11.

For a fixed cumulative period, x_i=1 forces the complete same-period
precedence closure H(i).  If every pair of three candidates fits both
cumulative resources, but H(i) union H(j) union H(k) exceeds one cumulative
capacity, then x_i + x_j + x_k <= 2 is a globally valid, genuinely
three-way cover inequality.  All overload decisions use Fraction arithmetic;
Gurobi is used only for continuous LP reoptimization and writing the model.
"""

from __future__ import annotations

import argparse
import hashlib
import heapq
import itertools
import json
import sys
import time
from fractions import Fraction
from pathlib import Path
from typing import Dict, Mapping, Sequence

sys.dont_write_bytecode = True
import gurobipy as gp

HERE = Path(__file__).resolve().parent
DUAL = HERE.parent / "agent-dual"
CLIQUE = HERE.parent / "agent-clique"
sys.path.insert(0, str(DUAL))
sys.path.insert(0, str(CLIQUE))

from exact_lagrangian_certificate import parse_mps  # noqa: E402
from clique_experiment import (  # noqa: E402
    Catalog,
    closure_weight,
    closures_for_period,
    discover,
)


def select_candidates(
    catalog: Catalog,
    period: int,
    closures: Mapping[str, frozenset[str]],
    values: Mapping[str, float],
    limit: int,
) -> list[str]:
    positive = [v for v in catalog.variables_at[period] if values[v] > 1e-8]

    def pressure(v: str) -> float:
        return max(
            float(closure_weight(catalog, period, closures[v], r)
                  / catalog.prefix_capacity[(r, period)])
            for r in catalog.resources
        )

    by_value = sorted(positive, key=lambda v: (values[v], pressure(v), v), reverse=True)
    by_score = sorted(
        positive,
        key=lambda v: (values[v] * pressure(v), values[v], v),
        reverse=True,
    )
    chosen = by_value[:limit]
    chosen.extend(by_score[: max(1, limit // 3)])
    # Preserve deterministic ordering while removing duplicates.
    return list(dict.fromkeys(chosen))


def exact_pair_compatible(
    catalog: Catalog,
    period: int,
    closures: Mapping[str, frozenset[str]],
    left: str,
    right: str,
) -> bool:
    union = closures[left] | closures[right]
    return all(
        closure_weight(catalog, period, union, resource)
        <= catalog.prefix_capacity[(resource, period)]
        for resource in catalog.resources
    )


def separate_period(
    catalog: Catalog,
    period: int,
    closures: Mapping[str, frozenset[str]],
    candidates: Sequence[str],
    values: Mapping[str, float],
    already_added: set[tuple[str, str, str]],
    keep: int,
    deadline: float,
):
    pair_ok: Dict[tuple[str, str], bool] = {}
    for left, right in itertools.combinations(candidates, 2):
        pair_ok[tuple(sorted((left, right)))] = exact_pair_compatible(
            catalog, period, closures, left, right
        )

    heap: list[tuple[float, tuple[str, str, str], dict]] = []
    examined = 0
    lp_eligible = 0
    for raw in itertools.combinations(candidates, 3):
        if time.perf_counter() >= deadline:
            break
        triple = tuple(sorted(raw))
        if triple in already_added:
            continue
        examined += 1
        lp_sum = sum(values[v] for v in triple)
        violation = lp_sum - 2.0
        if violation <= 1e-8:
            continue
        lp_eligible += 1
        if not all(pair_ok[tuple(sorted(pair))] for pair in itertools.combinations(triple, 2)):
            continue
        union = closures[triple[0]] | closures[triple[1]] | closures[triple[2]]
        witnesses = []
        for resource in catalog.resources:
            total = closure_weight(catalog, period, union, resource)
            capacity = catalog.prefix_capacity[(resource, period)]
            if total > capacity:
                witnesses.append((total - capacity, resource, total, capacity))
        if not witnesses:
            continue
        margin, resource, total, capacity = max(witnesses)
        record = {
            "period": period,
            "variables": list(triple),
            "size": 3,
            "lp_sum": lp_sum,
            "lp_violation": violation,
            "resource": resource,
            "closure_union_weight": str(total),
            "prefix_capacity": str(capacity),
            "exact_overload_margin": str(margin),
            "closure_union_size": len(union),
            "all_pairs_fit_all_resources": True,
        }
        entry = (violation, triple, record)
        if len(heap) < keep:
            heapq.heappush(heap, entry)
        elif entry[:2] > heap[0][:2]:
            heapq.heapreplace(heap, entry)
    records = [entry[2] for entry in sorted(heap, reverse=True)]
    return records, {
        "period": period,
        "candidates": len(candidates),
        "triples_examined": examined,
        "lp_eligible_triples": lp_eligible,
        "violated_exact_minimal_triples_kept": len(records),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("original_mps")
    parser.add_argument("baseline_mps")
    parser.add_argument("output_dir")
    parser.add_argument("--rounds", type=int, default=4)
    parser.add_argument("--candidate-limit", type=int, default=70)
    parser.add_argument("--cuts-per-period", type=int, default=15)
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--wall-seconds", type=float, default=600.0)
    args = parser.parse_args()

    started = time.perf_counter()
    deadline = started + args.wall_seconds
    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    original = parse_mps(args.original_mps)
    catalog = discover(original)
    closures = {
        period: closures_for_period(original, catalog, period)
        for period in catalog.periods
    }

    integer_model = gp.read(args.baseline_mps)
    integer_model.Params.OutputFlag = 0
    relaxation = integer_model.relax()
    relaxation.Params.OutputFlag = 0
    relaxation.Params.Threads = args.threads
    relaxation.Params.Method = 1
    relaxation.Params.TimeLimit = max(1.0, deadline - time.perf_counter())
    relaxation.optimize()
    if relaxation.Status != gp.GRB.OPTIMAL:
        raise RuntimeError(f"baseline LP not optimal: {relaxation.Status}")
    baseline = relaxation.ObjVal
    lp_vars = {v.VarName: v for v in relaxation.getVars()}
    mip_vars = {v.VarName: v for v in integer_model.getVars()}

    added: set[tuple[str, str, str]] = set()
    records = []
    rounds = []
    for round_index in range(1, args.rounds + 1):
        if time.perf_counter() >= deadline:
            break
        values = {name: var.X for name, var in lp_vars.items()}
        chosen = []
        stats = []
        for period in catalog.periods:
            if time.perf_counter() >= deadline:
                break
            candidates = select_candidates(
                catalog, period, closures[period], values, args.candidate_limit
            )
            found, period_stats = separate_period(
                catalog,
                period,
                closures[period],
                candidates,
                values,
                added,
                args.cuts_per_period,
                deadline,
            )
            stats.append(period_stats)
            for record in found:
                triple = tuple(record["variables"])
                if triple not in added:
                    record["round"] = round_index
                    chosen.append(record)
                    added.add(triple)
        if not chosen:
            rounds.append({
                "round": round_index,
                "cuts": 0,
                "objective": relaxation.ObjVal,
                "period_stats": stats,
            })
            break
        for record in chosen:
            index = len(records)
            name = f"certified_triple_cover_{index}"
            variables = record["variables"]
            relaxation.addConstr(gp.quicksum(lp_vars[v] for v in variables) <= 2, name=name)
            integer_model.addConstr(gp.quicksum(mip_vars[v] for v in variables) <= 2, name=name)
            records.append(record)
        relaxation.update()
        relaxation.Params.TimeLimit = max(1.0, deadline - time.perf_counter())
        relaxation.optimize()
        if relaxation.Status != gp.GRB.OPTIMAL:
            raise RuntimeError(f"strengthened LP not optimal: {relaxation.Status}")
        rounds.append({
            "round": round_index,
            "cuts": len(chosen),
            "objective": relaxation.ObjVal,
            "improvement_over_baseline": relaxation.ObjVal - baseline,
            "period_stats": stats,
        })

    enhanced = output_dir / f"{original.name}-pair-clique-plus-triple-covers.mps.gz"
    integer_model.write(str(enhanced))
    payload = {
        "method": "exact_pairwise-compatible_three-way_precedence_covers",
        "original_mps": str(Path(args.original_mps).resolve()),
        "original_sha256": original.sha256,
        "baseline_mps": str(Path(args.baseline_mps).resolve()),
        "baseline_sha256": hashlib.sha256(Path(args.baseline_mps).read_bytes()).hexdigest(),
        "parameters": vars(args),
        "baseline_root_lp": baseline,
        "strengthened_root_lp": relaxation.ObjVal,
        "root_lp_improvement": relaxation.ObjVal - baseline,
        "rounds": rounds,
        "cover_cuts": records,
        "enhanced_mps": str(enhanced),
        "enhanced_sha256": hashlib.sha256(enhanced.read_bytes()).hexdigest(),
        "elapsed_seconds": time.perf_counter() - started,
        "scope_note": "Finite deterministic candidate screening; zero cuts is not an exhaustive nonexistence result.",
    }
    (output_dir / "result.json").write_text(
        json.dumps(payload, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps({
        "baseline_root_lp": baseline,
        "strengthened_root_lp": relaxation.ObjVal,
        "root_lp_improvement": relaxation.ObjVal - baseline,
        "cover_cuts": len(records),
        "elapsed_seconds": payload["elapsed_seconds"],
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
