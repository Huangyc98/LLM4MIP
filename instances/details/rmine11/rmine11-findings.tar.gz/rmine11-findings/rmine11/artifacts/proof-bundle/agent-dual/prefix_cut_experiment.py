#!/usr/bin/env python3
"""Small root-LP experiment with cumulative rmine cover/conflict cuts.

This is deliberately an experiment, not a proof generator.  Every added row is
globally valid for the integer model:

* standard/surrogate covers use the prefix capacity row obtained by summing
  periods 0..t;
* pair conflicts use the union of the two blocks' same-period precedence
  closures in that prefix row.
"""

from __future__ import annotations

import argparse
import json
import re
import time
from fractions import Fraction
from pathlib import Path

import gurobipy as gp

from exact_lagrangian_certificate import parse_mps


VAR_RE = re.compile(r"^x_B(\d+)_t(\d+)$")


def period_of(name: str) -> int:
    match = VAR_RE.match(name)
    if not match:
        raise ValueError(f"unexpected rmine variable name {name}")
    return int(match.group(2))


def prefix_rows(model, period: int):
    rows = {}
    for resource in (0, 1):
        row = f"tcap_c{resource}_t{period}"
        weights = {
            var: value
            for var, value in model.side_columns[row].items()
            if period_of(var) == period and value > 0
        }
        capacity = sum(model.side_rhs[f"tcap_c{resource}_t{k}"] for k in range(period + 1))
        rows[(period, f"r{resource}")] = (weights, capacity)
    # A simple two-resource surrogate. More theta ratios can be added later.
    w0, c0 = rows[(period, "r0")]
    w1, c1 = rows[(period, "r1")]
    rows[(period, "r0+r1")] = ({v: w0[v] + w1[v] for v in w0.keys() & w1.keys()}, c0 + c1)
    return rows


def exact_cover(weights, capacity, x_value, seconds: float):
    """Return a violated cover selected by an exact 0/1 covering knapsack."""
    names = list(weights)
    scale = capacity.denominator
    for value in weights.values():
        scale = scale * value.denominator // __import__("math").gcd(scale, value.denominator)
    integer_weight = {v: int(weights[v] * scale) for v in names}
    integer_capacity = int(capacity * scale)
    if sum(integer_weight.values()) <= integer_capacity:
        return None
    separation = gp.Model()
    separation.Params.OutputFlag = 0
    separation.Params.Threads = 1
    separation.Params.TimeLimit = seconds
    z = separation.addVars(names, vtype=gp.GRB.BINARY)
    separation.setObjective(gp.quicksum((1.0 - x_value[v]) * z[v] for v in names), gp.GRB.MINIMIZE)
    separation.addConstr(gp.quicksum(integer_weight[v] * z[v] for v in names) >= integer_capacity + 1)
    separation.optimize()
    if separation.SolCount == 0 or separation.ObjVal >= 1.0 - 1e-7:
        return None
    cover = [v for v in names if z[v].X > 0.5]
    total = sum(integer_weight[v] for v in cover)
    # Removing an item from a still-valid cover can only increase violation.
    for var in sorted(cover, key=lambda v: (integer_weight[v], 1.0 - x_value[v])):
        if total - integer_weight[var] > integer_capacity:
            cover.remove(var)
            total -= integer_weight[var]
    violation = sum(x_value[v] for v in cover) - (len(cover) - 1)
    return cover, violation


def same_period_closures(model, period: int):
    nodes = [v for v in model.variables if period_of(v) == period]
    node_set = set(nodes)
    successors = {v: [] for v in nodes}
    for tail, head in model.arcs:
        if tail in node_set and head in node_set:
            successors[tail].append(head)
    memo = {}
    visiting = set()

    def closure(v):
        if v in memo:
            return memo[v]
        if v in visiting:
            raise ValueError("cycle in same-period precedence graph")
        visiting.add(v)
        result = {v}
        for nxt in successors[v]:
            result.update(closure(nxt))
        visiting.remove(v)
        memo[v] = frozenset(result)
        return memo[v]

    for node in nodes:
        closure(node)
    return nodes, memo


def violated_pair_conflicts(model, period: int, x_value, limit: int, candidate_limit: int):
    nodes, closures = same_period_closures(model, period)
    row0 = model.side_columns[f"tcap_c0_t{period}"]
    row1 = model.side_columns[f"tcap_c1_t{period}"]
    weight0 = {v: row0[v] for v in nodes}
    weight1 = {v: row1[v] for v in nodes}
    capacity0 = sum(model.side_rhs[f"tcap_c0_t{k}"] for k in range(period + 1))
    capacity1 = sum(model.side_rhs[f"tcap_c1_t{k}"] for k in range(period + 1))
    positive = [v for v in nodes if x_value[v] > 1e-8]
    all_closure_weight = {
        v: (
            sum((weight0[u] for u in closures[v]), Fraction(0)),
            sum((weight1[u] for u in closures[v]), Fraction(0)),
        )
        for v in positive
    }
    fractional = [v for v in positive if x_value[v] < 1.0 - 1e-8]
    integral_one = [v for v in positive if x_value[v] >= 1.0 - 1e-8]
    # A bounded, deterministic screening set keeps this a short experiment.
    # Include high-x fractionals and high closure-weight anchors fixed at one.
    screened = set(sorted(fractional, key=lambda v: x_value[v], reverse=True)[:candidate_limit])
    screened.update(sorted(
        fractional,
        key=lambda v: max(float(all_closure_weight[v][0] / capacity0),
                          float(all_closure_weight[v][1] / capacity1)),
        reverse=True,
    )[:candidate_limit])
    screened.update(sorted(
        integral_one,
        key=lambda v: max(float(all_closure_weight[v][0] / capacity0),
                          float(all_closure_weight[v][1] / capacity1)),
        reverse=True,
    )[:candidate_limit])
    candidates = sorted(screened, key=lambda v: x_value[v], reverse=True)
    closure_weight = {v: all_closure_weight[v] for v in candidates}
    found = []
    for left_pos, left in enumerate(candidates):
        for right in candidates[left_pos + 1:]:
            violation = x_value[left] + x_value[right] - 1.0
            if violation <= 1e-7:
                break
            # Comparable variables cannot make a new pair conflict unless a
            # singleton was already impossible.
            if right in closures[left] or left in closures[right]:
                continue
            # The cheap sum bound avoids most weighted-intersection work.
            l0, l1 = closure_weight[left]
            r0, r1 = closure_weight[right]
            outside = closures[right] - closures[left]
            conflict0 = l0 + r0 > capacity0 and l0 + sum((weight0[u] for u in outside), Fraction(0)) > capacity0
            conflict1 = l1 + r1 > capacity1 and l1 + sum((weight1[u] for u in outside), Fraction(0)) > capacity1
            if conflict0 or conflict1:
                if conflict0:
                    union_weight, capacity, resource = (
                        l0 + sum((weight0[u] for u in outside), Fraction(0)), capacity0, "r0"
                    )
                else:
                    union_weight, capacity, resource = (
                        l1 + sum((weight1[u] for u in outside), Fraction(0)), capacity1, "r1"
                    )
                found.append((violation, left, right, resource, union_weight, capacity, len(closures[left] | closures[right])))
    found.sort(reverse=True)
    return found[:limit]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps")
    parser.add_argument("output")
    parser.add_argument("--rounds", type=int, default=2)
    parser.add_argument("--separation-seconds", type=float, default=3.0)
    parser.add_argument("--pair-limit", type=int, default=500)
    parser.add_argument("--pair-candidate-limit", type=int, default=150)
    parser.add_argument("--skip-pairs", action="store_true")
    parser.add_argument("--strengthened-mps", help="optional integer MPS with all generated valid cuts")
    args = parser.parse_args()
    started = time.perf_counter()
    exact = parse_mps(args.mps)
    mip = gp.read(args.mps)
    lp = mip.relax()
    lp.Params.OutputFlag = 0
    lp.optimize()
    if lp.Status != gp.GRB.OPTIMAL:
        raise RuntimeError("initial LP not optimal")
    baseline = lp.ObjVal
    lp_vars = {v.VarName: v for v in lp.getVars()}
    added_signatures = set()
    rounds = []
    all_records = []

    for round_index in range(1, args.rounds + 1):
        x_value = {name: var.X for name, var in lp_vars.items()}
        records = []
        for period in range(11):
            for (_period, label), (weights, capacity) in prefix_rows(exact, period).items():
                result = exact_cover(weights, capacity, x_value, args.separation_seconds)
                if result is None:
                    continue
                cover, violation = result
                signature = ("cover", tuple(sorted(cover)))
                if signature in added_signatures:
                    continue
                added_signatures.add(signature)
                lp.addConstr(gp.quicksum(lp_vars[v] for v in cover) <= len(cover) - 1,
                             name=f"prefix_cover_{round_index}_{period}_{label}_{len(records)}")
                records.append({"kind": "cover", "period": period, "row": label,
                                "size": len(cover), "violation": violation, "variables": cover,
                                "cover_weight": str(sum((weights[v] for v in cover), Fraction(0))),
                                "capacity": str(capacity)})
        # Pair conflicts exploit precedence closure rather than item weights alone.
        if not args.skip_pairs:
            for period in range(11):
                for violation, left, right, resource, union_weight, capacity, closure_size in violated_pair_conflicts(
                    exact, period, x_value, args.pair_limit, args.pair_candidate_limit
                ):
                    signature = ("pair", min(left, right), max(left, right))
                    if signature in added_signatures:
                        continue
                    added_signatures.add(signature)
                    lp.addConstr(lp_vars[left] + lp_vars[right] <= 1,
                                 name=f"prefix_pair_{round_index}_{period}_{len(records)}")
                    records.append({"kind": "precedence_pair", "period": period, "row": resource,
                                    "size": 2, "violation": violation, "variables": [left, right],
                                    "closure_union_weight": str(union_weight), "capacity": str(capacity),
                                    "closure_union_size": closure_size})
        if not records:
            rounds.append({"round": round_index, "cuts": 0, "objective": lp.ObjVal})
            break
        lp.optimize()
        if lp.Status != gp.GRB.OPTIMAL:
            raise RuntimeError("cut LP not optimal")
        rounds.append({
            "round": round_index,
            "cuts": len(records),
            "cover_cuts": sum(r["kind"] == "cover" for r in records),
            "precedence_pair_cuts": sum(r["kind"] == "precedence_pair" for r in records),
            "objective": lp.ObjVal,
            "improvement_from_baseline": lp.ObjVal - baseline,
            "records": records,
        })
        all_records.extend(records)
    if args.strengthened_mps:
        mip_vars = {v.VarName: v for v in mip.getVars()}
        for cut_index, record in enumerate(all_records):
            variables = record["variables"]
            mip.addConstr(gp.quicksum(mip_vars[v] for v in variables) <= len(variables) - 1,
                          name=f"certified_prefix_cut_{cut_index}")
        mip.write(args.strengthened_mps)
    payload = {
        "model_sha256": exact.sha256,
        "baseline_root_lp": baseline,
        "strengthened_root_lp": lp.ObjVal,
        "improvement": lp.ObjVal - baseline,
        "rounds": rounds,
        "elapsed_seconds": time.perf_counter() - started,
        "strengthened_mps": str(Path(args.strengthened_mps).resolve()) if args.strengthened_mps else None,
        "status": "heuristic finite cut search; every emitted inequality is globally valid",
    }
    Path(args.output).write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: payload[k] for k in ("baseline_root_lp", "strengthened_root_lp", "improvement", "elapsed_seconds")}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
