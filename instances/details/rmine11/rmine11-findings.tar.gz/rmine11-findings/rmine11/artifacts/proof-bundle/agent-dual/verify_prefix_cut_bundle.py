#!/usr/bin/env python3
"""Verify that a prefix-cut experiment is a valid strengthening of rmine."""

from __future__ import annotations

import argparse
import json
from fractions import Fraction

from exact_lagrangian_certificate import parse_mps
from prefix_cut_experiment import period_of, prefix_rows, same_period_closures


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("original_mps")
    parser.add_argument("result_json")
    parser.add_argument("strengthened_mps")
    args = parser.parse_args()
    original = parse_mps(args.original_mps)
    strengthened = parse_mps(args.strengthened_mps)
    result = json.load(open(args.result_json, "r", encoding="utf-8"))
    if result["model_sha256"] != original.sha256:
        raise ValueError("result JSON does not match original MPS")
    if (original.variables != strengthened.variables or original.objective != strengthened.objective
            or original.arcs != strengthened.arcs):
        raise ValueError("strengthened MPS changed variables, objective, or precedence arcs")
    records = [record for round_data in result["rounds"] for record in round_data.get("records", [])]
    expected_rows = set(original.side_rows) | {f"certified_prefix_cut_{i}" for i in range(len(records))}
    if set(strengthened.side_rows) != expected_rows:
        raise ValueError("strengthened MPS has missing or extra side rows")

    closure_cache = {}
    minimum_margin = None
    kinds = {}
    for index, record in enumerate(records):
        variables = record["variables"]
        row = f"certified_prefix_cut_{index}"
        expected_terms = {v: Fraction(1) for v in variables}
        if strengthened.side_columns[row] != expected_terms:
            raise ValueError(f"strengthened row {row} has wrong coefficients")
        if strengthened.side_rhs[row] != len(variables) - 1:
            raise ValueError(f"strengthened row {row} has wrong RHS")
        period = int(record["period"])
        if any(period_of(v) != period for v in variables):
            raise ValueError(f"cut {index} mixes periods")
        kind = record["kind"]
        kinds[kind] = kinds.get(kind, 0) + 1
        if kind == "cover":
            rows = prefix_rows(original, period)
            weights, capacity = rows[(period, record["row"])]
            total = sum((weights[v] for v in variables), Fraction(0))
        elif kind == "precedence_pair":
            if len(variables) != 2 or variables[0] == variables[1]:
                raise ValueError(f"bad pair cut {index}")
            if period not in closure_cache:
                closure_cache[period] = same_period_closures(original, period)[1]
            closures = closure_cache[period]
            union = closures[variables[0]] | closures[variables[1]]
            resource = int(record["row"][1:])
            weights = original.side_columns[f"tcap_c{resource}_t{period}"]
            total = sum((weights[v] for v in union), Fraction(0))
            capacity = sum(original.side_rhs[f"tcap_c{resource}_t{k}"] for k in range(period + 1))
        else:
            raise ValueError(f"unknown cut kind {kind}")
        margin = total - capacity
        if margin <= 0:
            raise ValueError(f"cut {index} has no exact capacity-overload proof")
        minimum_margin = margin if minimum_margin is None else min(minimum_margin, margin)
    print(json.dumps({
        "verified": True,
        "original_sha256": original.sha256,
        "strengthened_sha256": strengthened.sha256,
        "cuts": len(records),
        "cut_kinds": kinds,
        "minimum_exact_overload_margin": str(minimum_margin),
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
