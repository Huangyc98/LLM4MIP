#!/usr/bin/env python3
"""Build a compact integer-equivalent extraction-time formulation of rmine11.

The original binary x[b,t] says that block b has been extracted by the end of
period t.  This script uses y[b,t] = x[b,t] - x[b,t-1], which says that b is
extracted exactly in t.  A block may also remain unextracted, represented by
all of its y variables being zero.

For binary at-most-one y vectors, extraction precedence is encoded exactly by
one weighted time inequality per physical block arc.  This replaces the same
arc's many cumulative time rows.
"""

from collections import defaultdict
from decimal import Decimal, getcontext
import gzip
from pathlib import Path
import re
import sys


getcontext().prec = 60
HORIZON = 11
VAR_RE = re.compile(r"^x_B(\d+)_t(\d+)$")
GPREC_RE = re.compile(r"^gprec_B(\d+)_B(\d+)_t\d+$")


def dtext(value: Decimal) -> str:
    text = format(value, "f")
    if "." in text:
        text = text.rstrip("0").rstrip(".")
    return text if text not in {"", "-0"} else "0"


def parse_original(path: Path):
    section = None
    variables = set()
    objective = defaultdict(lambda: Decimal(0))
    resource_positive = {}
    spatial_pairs = set()
    resource_rhs = {}

    with gzip.open(path, "rt", encoding="utf-8") as handle:
        for raw in handle:
            parts = raw.split()
            if not parts:
                continue
            if parts[0] in {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}:
                section = parts[0]
                continue

            if section == "ROWS":
                match = GPREC_RE.match(parts[1])
                if match:
                    spatial_pairs.add((int(match.group(1)), int(match.group(2))))
            elif section == "COLUMNS":
                if len(parts) >= 3 and parts[1].strip("'") == "MARKER":
                    continue
                variable = parts[0]
                match = VAR_RE.match(variable)
                if not match:
                    raise ValueError(f"Unexpected column {variable}")
                block, period = map(int, match.groups())
                variables.add((block, period))
                for index in range(1, len(parts), 2):
                    row = parts[index]
                    coefficient = Decimal(parts[index + 1])
                    if row == "obj":
                        objective[(block, period)] += coefficient
                    elif row == f"tcap_c0_t{period}" and coefficient > 0:
                        resource_positive[(block, period, 0)] = coefficient
                    elif row == f"tcap_c1_t{period}" and coefficient > 0:
                        resource_positive[(block, period, 1)] = coefficient
            elif section == "RHS":
                for index in range(1, len(parts), 2):
                    if parts[index].startswith("tcap_"):
                        resource_rhs[parts[index]] = Decimal(parts[index + 1])

    times = defaultdict(list)
    for block, period in variables:
        times[block].append(period)
    for block in times:
        times[block].sort()

    if len(variables) != 12292 or len(times) != 1331 or len(spatial_pairs) != 9610:
        raise ValueError(
            f"Unexpected structure: {len(variables)} vars, {len(times)} blocks, "
            f"{len(spatial_pairs)} spatial arcs"
        )
    if len(resource_positive) != 2 * len(variables):
        raise ValueError(f"Missing direct resource weights: got {len(resource_positive)}")
    if len(resource_rhs) != 22:
        raise ValueError(f"Expected 22 resource RHS values, got {len(resource_rhs)}")

    return variables, times, objective, resource_positive, spatial_pairs, resource_rhs


def build_model(source: Path, target: Path):
    variables, times, objective, weights, spatial_pairs, resource_rhs = parse_original(source)
    outgoing = defaultdict(list)
    incoming = defaultdict(list)
    for child, parent in sorted(spatial_pairs):
        row = f"prec_B{child}_B{parent}"
        outgoing[child].append(row)
        incoming[parent].append(row)

    direct_objective = {}
    for block, block_times in times.items():
        running = Decimal(0)
        for period in reversed(block_times):
            running += objective[(block, period)]
            direct_objective[(block, period)] = running

    with target.open("w", encoding="utf-8") as output:
        output.write("NAME          rmine11-exact-time\n")
        output.write("ROWS\n")
        output.write(" N  obj\n")
        for block in sorted(times):
            output.write(f" L  choose_B{block}\n")
        for child, parent in sorted(spatial_pairs):
            output.write(f" L  prec_B{child}_B{parent}\n")
        for period in range(HORIZON):
            output.write(f" L  tcap_c0_t{period}\n")
            output.write(f" L  tcap_c1_t{period}\n")

        output.write("COLUMNS\n")
        output.write("    MARK0000  'MARKER'                 'INTORG'\n")
        for block in sorted(times):
            for period in times[block]:
                variable = f"y_B{block}_t{period}"
                score = HORIZON - period
                output.write(f"    {variable}  obj  {dtext(direct_objective[(block, period)])}\n")
                output.write(f"    {variable}  choose_B{block}  1\n")
                for row in outgoing[block]:
                    output.write(f"    {variable}  {row}  {score}\n")
                for row in incoming[block]:
                    output.write(f"    {variable}  {row}  {-score}\n")
                output.write(f"    {variable}  tcap_c0_t{period}  {dtext(weights[(block, period, 0)])}\n")
                output.write(f"    {variable}  tcap_c1_t{period}  {dtext(weights[(block, period, 1)])}\n")
        output.write("    MARK0001  'MARKER'                 'INTEND'\n")

        output.write("RHS\n")
        for block in sorted(times):
            output.write(f"    rhs  choose_B{block}  1\n")
        for period in range(HORIZON):
            for resource in range(2):
                row = f"tcap_c{resource}_t{period}"
                output.write(f"    rhs  {row}  {dtext(resource_rhs[row])}\n")

        output.write("BOUNDS\n")
        for block in sorted(times):
            for period in times[block]:
                output.write(f" BV bnd  y_B{block}_t{period}\n")
        output.write("ENDATA\n")

    return variables, times, direct_objective, spatial_pairs


def transform_solution(source: Path, target: Path, times, direct_objective):
    cumulative = defaultdict(lambda: Decimal(0))
    with gzip.open(source, "rt", encoding="utf-8") as handle:
        for raw in handle:
            parts = raw.split()
            if len(parts) >= 2 and VAR_RE.match(parts[0]):
                match = VAR_RE.match(parts[0])
                block, period = map(int, match.groups())
                cumulative[(block, period)] = Decimal(parts[1])

    objective = Decimal(0)
    selected = 0
    with target.open("w", encoding="utf-8") as output:
        output.write("# Exact-time transform of official MIPLIB solution ID 1\n")
        for block in sorted(times):
            previous = Decimal(0)
            for period in times[block]:
                value = cumulative[(block, period)] - previous
                if value not in {Decimal(0), Decimal(1)}:
                    raise ValueError(f"Non-step cumulative vector at block {block}, period {period}: {value}")
                output.write(f"y_B{block}_t{period} {dtext(value)}\n")
                objective += direct_objective[(block, period)] * value
                selected += int(value)
                previous = cumulative[(block, period)]
    return objective, selected


def main():
    if len(sys.argv) != 5:
        raise SystemExit(
            "usage: build_exact_time_model.py SOURCE.mps.gz TARGET.mps SOURCE.sol.gz TARGET.sol"
        )
    source_mps, target_mps, source_sol, target_sol = map(Path, sys.argv[1:])
    target_mps.parent.mkdir(parents=True, exist_ok=True)
    target_sol.parent.mkdir(parents=True, exist_ok=True)
    variables, times, direct_objective, spatial_pairs = build_model(source_mps, target_mps)
    solution_objective, selected = transform_solution(source_sol, target_sol, times, direct_objective)
    print(f"binary_variables={len(variables)}")
    print(f"block_choice_rows={len(times)}")
    print(f"spatial_precedence_rows={len(spatial_pairs)}")
    print("resource_rows=22")
    print(f"total_rows={len(times) + len(spatial_pairs) + 22}")
    print(f"selected_blocks={selected}")
    print(f"transformed_solution_objective={solution_objective}")


if __name__ == "__main__":
    main()
