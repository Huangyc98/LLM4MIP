"""Exact active-layer quotient of neos-4360552-sangro.

All 48 aggri label matrices are identical and wS profiles do not depend on n.
Every inactive layer has zero duration and is therefore an identity transition.
Consequently a solution with A active layers is equivalent to a length-A chain
of active local patterns; the 48 original layer positions can be deleted.
"""
import argparse
import json
import sys
import time
from pathlib import Path

from ortools.sat.python import cp_model

sys.path.insert(0, str(Path(__file__).resolve().parent))
from reduced_interval_cpsat import extract  # noqa: E402


def build(labels_by_n, profiles, active_layers, unique_partitions=True):
    fingerprints = {
        tuple(tuple(labels_by_n[n][i][ell] for ell in range(12)) for i in range(1, 7))
        for n in range(1, 49)
    }
    assert len(fingerprints) == 1
    labels = labels_by_n[1]

    model = cp_model.CpModel()
    machines, periods = range(1, 7), range(1, 13)
    layers, partitions = range(1, active_layers + 1), range(1, 59)
    s = {(i, t): model.NewIntVar(0, 12, f"s({i},{t})") for i in machines for t in layers}
    e = {(i, t): model.NewIntVar(0, 12, f"e({i},{t})") for i in machines for t in layers}
    d = {(i, t): model.NewIntVar(0, 12, f"d({i},{t})") for i in machines for t in layers}
    x = {(i, j, t): model.NewBoolVar(f"x({i},{j},{t})")
         for i in machines for j in periods for t in layers}
    y = {(i, t, j): model.NewBoolVar(f"y({i},{t},{j})")
         for i in machines for t in layers for j in periods}
    choose = {(t, k): model.NewBoolVar(f"choose({t},{k})") for t in layers for k in partitions}
    overlap = {(i, t): model.NewBoolVar(f"overlap({i},{t})")
               for i in machines for t in range(2, active_layers + 1)}

    for i in machines:
        model.Add(s[i, 1] == 0)
        model.Add(e[i, active_layers] == 12)
        for t in layers:
            model.Add(d[i, t] == e[i, t] - s[i, t])
            model.Add(sum(x[i, j, t] for j in periods) == d[i, t])
            for j in periods:
                model.Add(s[i, t] <= j - 1).OnlyEnforceIf(x[i, j, t])
                model.Add(e[i, t] >= j).OnlyEnforceIf(x[i, j, t])
                model.Add(d[i, t] >= j).OnlyEnforceIf(y[i, t, j])
                model.Add(d[i, t] <= j - 1).OnlyEnforceIf(y[i, t, j].Not())
            if t < active_layers:
                model.Add(e[i, t + 1] >= e[i, t])
                model.Add(s[i, t + 1] >= e[i, t] - 1)
                model.Add(s[i, t + 1] <= e[i, t])
                model.Add(overlap[i, t + 1] == e[i, t] - s[i, t + 1])
                model.Add(overlap[i, t + 1] <= y[i, t + 1, 1])

    for t in layers:
        for ell in range(12):
            model.Add(sum(x[i, labels[i][ell], t] for i in machines) == 1)
        model.Add(sum(choose[t, k] for k in partitions) == 1)
        for j in periods:
            model.Add(sum(y[i, t, j] for i in machines) ==
                      sum(profiles[k][j - 1] * choose[t, k] for k in partitions))
    if unique_partitions:
        for k in partitions:
            model.Add(sum(choose[t, k] for t in layers) <= 1)

    model.Add(sum(overlap.values()) == 12 * active_layers - 72)
    model.Add(sum(overlap.values()) <=
              sum(profiles[k][0] * choose[t, k] for t in layers for k in partitions) - 6)
    return model, (s, e, d, choose, overlap)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("--active-layers", type=int, required=True)
    parser.add_argument("--time-limit", type=float, default=3600)
    parser.add_argument("--workers", type=int, default=16)
    parser.add_argument("--allow-repeated-partitions", action="store_true")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    assert 6 <= args.active_layers <= 11

    started = time.time()
    labels, profiles, _ = extract(args.mps)
    model, variables = build(labels, profiles, args.active_layers,
                             unique_partitions=not args.allow_repeated_partitions)
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = args.time_limit
    solver.parameters.num_search_workers = args.workers
    solver.parameters.log_search_progress = True
    status = solver.Solve(model)
    s, e, d, choose, overlap = variables
    payload = {
        "method": "exact quotient by deleting 48-A inactive identity layers",
        "active_layers": args.active_layers,
        "all_48_label_matrices_identical": True,
        "unique_partitions_enforced": not args.allow_repeated_partitions,
        "status": solver.StatusName(status),
        "wall_time_seconds": solver.WallTime(),
        "elapsed_seconds": time.time() - started,
        "conflicts": solver.NumConflicts(),
        "branches": solver.NumBranches(),
    }
    if status in (cp_model.FEASIBLE, cp_model.OPTIMAL):
        payload["layers"] = [
            {"t": t,
             "partition_id": next(k for k in range(1, 59) if solver.Value(choose[t, k])),
             "durations": [solver.Value(d[i, t]) for i in range(1, 7)],
             "starts": [solver.Value(s[i, t]) for i in range(1, 7)],
             "ends": [solver.Value(e[i, t]) for i in range(1, 7)]}
            for t in range(1, args.active_layers + 1)
        ]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print("RESULT_JSON " + json.dumps(payload), flush=True)


if __name__ == "__main__":
    main()
