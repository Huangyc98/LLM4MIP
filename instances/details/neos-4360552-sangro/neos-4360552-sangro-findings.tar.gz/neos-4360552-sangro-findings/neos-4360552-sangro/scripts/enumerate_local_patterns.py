"""Solver-free enumeration of every locally feasible active-layer pattern."""
import argparse
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from independent_audit import family, read_mps  # noqa: E402


def extract(mps):
    _, _, order, matrix, _, _, _, _, _ = read_mps(mps)
    labels = {n: {i: {} for i in range(1, 7)} for n in range(1, 49)}
    profiles = {k: [0] * 12 for k in range(1, 59)}
    for row in order:
        row_family = family(row)
        if row_family == "aggri":
            _, n_text, ell_text = row.split("_")
            n, ell = int(n_text), int(ell_text)
            for variable in matrix[row]:
                if variable.startswith("x("):
                    i, j, n_again = map(int, variable[2:-1].split(","))
                    assert n_again == n
                    labels[n][i][ell] = j
        elif row_family == "wS":
            _, k_text, n_text, j_text = row.split("_")
            k, n, j = int(k_text), int(n_text), int(j_text)
            coefficient = int(matrix[row].get(f"w({n},{k})", 0))
            if n == 1:
                profiles[k][j - 1] = coefficient
            else:
                assert profiles[k][j - 1] == coefficient

    partition_to_k = {}
    for k, profile in profiles.items():
        parts = tuple(sorted((sum(c >= rank for c in profile)
                              for rank in range(1, 7)), reverse=True))
        assert sum(parts) == 12
        assert parts not in partition_to_k
        partition_to_k[parts] = k
    return labels, partition_to_k


def enumerate_layer(label_positions):
    options = {}
    for i in range(1, 7):
        # Convert position -> label; an interval is represented by its label mask.
        label_at = {position: label for label, position in label_positions[i].items()}
        row_options = [(0, 0)]  # one abstract empty interval; its endpoint is global-state dependent
        for start in range(0, 12):
            mask = 0
            for end in range(start + 1, 13):
                mask |= 1 << label_at[end]
                row_options.append((mask, end - start))
        assert len(row_options) == 79
        options[i] = row_options

    full = (1 << 12) - 1
    # Merge states having the same used-label mask and duration multiset after
    # every row.  This is exhaustive dynamic programming, not heuristic pruning.
    states = {(0, ()): 1}
    for i in range(1, 7):
        next_states = defaultdict(int)
        for (used, lengths), multiplicity in states.items():
            remaining = 12 - used.bit_count()
            for mask, length in options[i]:
                if mask & used or length > remaining:
                    continue
                new_lengths = tuple(sorted(lengths + (length,), reverse=True))
                next_states[used | mask, new_lengths] += multiplicity
        states = next_states
    counts = Counter({lengths: multiplicity
                      for (used, lengths), multiplicity in states.items() if used == full})
    return counts


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    labels, partition_to_k = extract(args.mps)

    layer_payload = {}
    degree_n = {}
    degree_k = Counter()
    total_patterns = 0
    for n in range(1, 49):
        counts = enumerate_layer(labels[n])
        assert all(partition in partition_to_k for partition in counts)
        by_k = {str(partition_to_k[partition]): count
                for partition, count in sorted(counts.items(), key=lambda item: partition_to_k[item[0]])}
        layer_payload[str(n)] = {"patterns": sum(counts.values()), "partition_counts": by_k}
        degree_n[n] = len(by_k)
        total_patterns += sum(counts.values())
        degree_k.update(map(int, by_k))

    payload = {
        "method": "solver-free exhaustive interval-label enumeration",
        "layers": 48,
        "partitions": 58,
        "total_local_patterns": total_patterns,
        "layer_partition_degree": {
            "minimum": min(degree_n.values()),
            "maximum": max(degree_n.values()),
            "histogram": dict(sorted(Counter(degree_n.values()).items())),
        },
        "partition_layer_degree": {
            "minimum": min(degree_k.values()),
            "maximum": max(degree_k.values()),
            "histogram": dict(sorted(Counter(degree_k.values()).items())),
            "unavailable_partitions": sorted(set(range(1, 59)) - set(degree_k)),
        },
        "layer_data": layer_payload,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in payload.items() if key != "layer_data"}), flush=True)


if __name__ == "__main__":
    main()
