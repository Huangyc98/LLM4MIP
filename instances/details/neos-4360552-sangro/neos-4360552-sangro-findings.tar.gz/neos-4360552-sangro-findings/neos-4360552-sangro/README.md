# neos-4360552-sangro — OPT = -8

This directory archives a structure-specific global optimum proof for the
MIPLIB open instance `neos-4360552-sangro`.  The original MPS is a minimization
model with 10,272 integer variables and 46,012 rows.  Its objective is
`-sum(w)`, so an objective of -A means that A layers are active.

## Result

**The global optimum is -8.**

- Upper bound: both the MIPLIB solution and the independently generated
  [`compressed-A8-expanded.sol`](solutions/compressed-A8-expanded.sol) have
  objective -8.  The standard-library Decimal auditor reports zero violation
  on all 46,012 original rows, all bounds, and integrality.
- Lower bound: a strictly weaker interval-chain model that permits reuse of
  the 58 partition types is infeasible for nine active layers.  Every original
  solution maps into this relaxation, so the original model has A <= 8.

## Exact reduction

The reduction follows directly from the original integer matrix.

1. `w_difn` and `w_difk` form the two sides of a 48 by 58 matching.
2. For each active layer, `twtone` and the twelve `aggri` rows select exactly
   twelve cells, one of every label, from six discrete intervals.
3. The twelve coefficients in each `wS(k,n,*)` family are nonincreasing and
   sum to twelve.  The 58 distinct profiles are exactly all integer partitions
   of twelve into at most six parts.  Summing the `wS` inequalities shows that
   every inequality is tight, so a selected `k` is precisely the unordered
   multiset of the six interval lengths.
4. All 48 `aggri` label matrices are byte-for-byte identical.  An inactive
   layer has zero length on all six tracks and the endpoint inequalities force
   it to be an identity transition.  Deleting all `48-A` inactive layers is
   therefore a bijective quotient between original solutions with A active
   layers and length-A active chains.
5. Dropping the global uniqueness of the 58 partitions is a relaxation.  The
   compressed A=9 relaxation is integer-infeasible, proving A <= 8.

The failed 1,200-second 48-layer A>=10 experiment is retained as a negative
result.  Deleting the identity layers reduced the same structural question to
about two thousand variables: A=10 was ruled out in 2.46 seconds, A=9 in 5.10
seconds, and the stronger repeat-partition relaxation in 5.52 seconds.

## Reproduction

The scripts use Python 3.11.  Structural and witness audits use only the
standard library.  The compressed infeasibility runs require OR-Tools 9.15.

```sh
python scripts/independent_audit.py input/neos-4360552-sangro.mps.gz \
  solutions/compressed-A8-expanded.sol artifacts/original.dec \
  --output expanded-audit.json

python scripts/compressed_active_layers_cpsat.py \
  input/neos-4360552-sangro.mps.gz --active-layers 9 \
  --allow-repeated-partitions --time-limit 1200 --workers 16 \
  --output compressed-A9-repeat-relax.json
```

The CP-SAT run is an exact integer exhaustive computation but does not emit a
standalone LRAT/DRAT proof trace.  The full Chinese derivation and provenance
are in [`report.zh.md`](report.zh.md).

## Key SHA-256 values

| File | SHA-256 |
|---|---|
| original MPS | `d0a8917d8b055e6ad2007d0081c41eb9b4101435820c800225930b66eeab76ba` |
| compressed-model script | `b544a61bbcb6a5c650b48e58d4ddef91de7632775402eb3e755db3553fc32052` |
| A=9 repeat-partition relaxation result | `34b4e512df4704e6c494f14fc91aea345fe1162eb8fc5526abcf6c4fed4343f5` |
| expanded A=8 solution | `df9d4fe96d1eeb6286a5054e3af4299baaf4801558f0c56c9f2f5faf3e1a4476` |
| exact expanded-solution audit | `2e002d7bb78b36ab420a2398cdfda9de40c67e3e319fb887db063ae4832327a8` |
