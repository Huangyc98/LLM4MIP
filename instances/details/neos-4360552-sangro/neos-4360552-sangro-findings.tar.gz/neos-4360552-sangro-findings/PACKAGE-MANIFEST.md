# Package manifest: neos-4360552-sangro

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 24
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/compressed-A10.result.json`
- `artifacts/compressed-A8-expanded-audit.json`
- `artifacts/compressed-A8-validation.result.json`
- `artifacts/compressed-A9-repeat-relax.result.json`
- `artifacts/compressed-A9.result.json`
- `artifacts/gurobi-structure.json`
- `artifacts/independent-audit.remote.json`
- `artifacts/local-patterns.json`
- `artifacts/original.dec`
- `artifacts/publication-replay-audit.json`
- `artifacts/reduced-target10-unknown.result.json`
- `artifacts/reduced-target11.result.json`
- `logs/reduced-target10-unknown.log`
- `logs/reduced-target11.log`
- `report.zh.md`
- `scripts/compressed_active_layers_cpsat.py`
- `scripts/enumerate_local_patterns.py`
- `scripts/expand_compressed_solution.py`
- `scripts/gurobi_structure_audit.py`
- `scripts/independent_audit.py`
- `scripts/reduced_interval_cpsat.py`
- `solutions/compressed-A8-expanded.sol`
- `solutions/official-best.sol.gz`

## Excluded files

- `input/neos-4360552-sangro.mps.gz (926982 bytes; raw benchmark input; sha256 d0a8917d8b055e6ad2007d0081c41eb9b4101435820c800225930b66eeab76ba)`
