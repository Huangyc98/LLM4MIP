# Package manifest: genus-sym-grafo5708-48

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 14
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/genus-sym-grafo5708-48.adjacency.txt`
- `artifacts/genus-sym-grafo5708-48.exact-rotation.txt`
- `artifacts/genus-sym-grafo5708-48.mc`
- `artifacts/genus-sym-grafo5708-48.official-rotation.txt`
- `artifacts/genus-sym-grafo5708-48.rome-to-mps.tsv`
- `artifacts/genus-sym-grafo5708-48.source-fingerprint.txt`
- `logs/genus-sym-grafo5708-48.multi-genus-decision-gt-3.log`
- `logs/genus-sym-grafo5708-48.multi-genus.log`
- `logs/genus-sym-grafo5708-48.official-solution-validation.log`
- `logs/genus-sym-grafo5708-48.rank14-audit.log`
- `reports/structural-investigation.md`
- `scripts/verify.py`
- `solutions/official-21.sol.gz`

## Excluded files

- `input/genus-sym-grafo5708-48.mps.gz (416329 bytes; raw benchmark input; sha256 7aa642a95aa5b792c1553f3383e0fb229a92653cf41ca6d62c9095715641c4bc)`
