# `fastxgemm-n3r22s4t6` continuation

Research date: **2026-09-09**.

## Strict result

```text
90 <= OPT <= 1150
```

Both sides improve the previous project record `[87,1171]`:

- **LB 90** is a new project theorem for the complete integer-feasible set of
  the official MPS.
- **UB 1150** is obtained by deleting either singleton fixed A term from the
  audited `K=51` BILR rank-23 decomposition. Its provenance is
  **external-derived** and counts as a project primal improvement based on
  external work (counting policy updated 2026-09-16). It strictly improves Laurent Sorber's 2017 author prior 1171.

The two R22 patterns both have `E=1`, `K=50`, and `1000E+3K=1150`.
Gurobi 13.0.2 completed each on the unmodified official R22 MPS; floating,
exact-decimal, exact-integer, and exact tensor audits all pass with zero
violations.

## Global lower bound

The proof strengthens the exact branch from `K>=29` to `K>=30` by closing the
sole remaining `K=29` degree pattern. It yields the integer-valid inequality

```text
sum(ABS_ALT_U,V,W) + 6*sum(RESIDUAL) >= 90.
```

Gurobi confirms that the original LP bound is 84, the augmented LP bound is
90, and the augmented root bound is 90. The mathematical proof—not the
numerical root probe—establishes global validity.

## Scoped search around the two 1150 cores

No strict improvement was found for either core in complete finite scans of:

- all 396 coefficient-Hamming-radius-one moves and all 78,012
  distinct-coordinate radius-two moves;
- all `22*3^9=433,026` single-complete-vector replacements;
- all `50*148*2=14,800` one-for-one support exchanges.

On the official MPS, both fixed-support objective-cap-1149 problems are
`INFEASIBLE`: within each core's 50 locations, arbitrary deletions and sign
changes cannot improve 1150. These are neighborhood certificates only.

The broader models allowing arbitrary old-support edits plus at most one new
location reached `TIME_LIMIT` at 600 seconds with no incumbent. Their bounds
were 1096.009 and 1096.021. This is negative evidence, not a proof.

## Exact-R22 boundary

The LB proof rules out exact `K<=29`; it does **not** rule out exact rank 22.
It additionally proves that an exact `K=30` point, if one exists, must have
row-degree multiset

```text
(4,4,4,3,3,3,3,3,3).
```

A 180-second Gurobi probe of this full exact-`K=30` branch ended at
`TIME_LIMIT`, at the root, with zero solutions. It is not an infeasibility
proof. Globally unresolved strict-improvement branches are exact `E=0` with
`K>=30` and inexact `E=1,K<=49` outside the certified local neighborhoods.

## Main evidence

- `artifacts/EXTERNAL_BILR_UB1150.md`: attribution, deletion proof, official
  MPS completions, checksums, and scoped searches;
- `artifacts/external-bilr-deletion-audit.json`: exact five-way deletion audit;
- `artifacts/external-bilr-delete-a{0,1}-strict-1150.sol` and matching JSON:
  strict official-MPS solutions and complete audits;
- `artifacts/LB90_PROOF.md`: complete lower-bound proof and scope;
- `scripts/verify_lb90_combinatorics.py` and
  `artifacts/lb90_combinatorial_audit.json`: finite K=29 proof-case audit;
- `scripts/build_and_probe_lb90.py`, `artifacts/lb90_probe.json`, and the
  augmented MPS: cut construction and Gurobi verification;
- `scripts/probe_exact_k30.py` and archived JSON/log: explicitly unresolved
  exact-K30 probe;
- `REPRODUCE.md`, `result_summary.json`, and `SHA256SUMS.txt`.
