# `fastxgemm-n3r22s4t6` 续研报告

日期：2026-09-09

## 严格结论

本轮同时严格改进上下界：

```text
原项目区间：[87,1171]
新严格区间：[90,1150]
```

下界 90 是针对官方整数 MIP 全可行域的新项目证明。上界 1150 来自外部
BILR 2018 的 `S_Lader-Z3` rank-23 分解：从其两个 singleton 固定 A 项中删去
任意一个，即得到 R22、S4T6 的 `E=1,K=50` 构造。它必须标记为
**external-derived**，计入本项目基于外部成果的 primal 改进（2026-09-16 更新口径）；它把 Laurent Sorber 2017
年的作者 prior 1171 严格降低了 21。

## external-derived UB 1150

输入 parent 是已经在官方 R23 MPS 上严格补全的 BILR 构造。重新只读取其
POS/NEG 整数并做精确张量展开，得到

```text
R=23, E=0, K=51, full support=153, objective=153.
```

parent 有五个固定对称项和六个三循环 orbit。删除支撑为 `q` 的固定 A 向量后，
误差恰是被删掉的 cube，因此

```text
E=q^3,  K=51-q,  objective=1000*q^3+3*(51-q).
```

五种删除的精确枚举为：

| 原 A 列 | q | E | K | objective |
|---:|---:|---:|---:|---:|
| 0 | 1 | 1 | 50 | **1150** |
| 1 | 1 | 1 | 50 | **1150** |
| 2 | 3 | 27 | 48 | 27144 |
| 3 | 2 | 8 | 49 | 8147 |
| 4 | 2 | 8 | 49 | 8147 |

两个 1150 候选分别只漏掉 `(4,4,4)` 与 `(8,8,8)`。二者均在未修改的官方
R22 MPS（19,539 variables、229,742 rows、752,274 nonzeros）上固定全部 396 个
POS/NEG 整数后由 Gurobi 返回 `OPTIMAL`、objective 1150。随后 floating、
exact-decimal、exact-integer 与精确 tensor audit 均为零违约，全部补全变量距整数
的最大距离为零。

## global LB 90

对 exact 分解，九个 factor row 对应的 target slice 都是秩 3，因此每个 row
degree 至少为 3。degree 恰为 3 的 tight rows 在同一 mode 中不能共享 rank
position。旧证明用 `8*3>22` 排除了 `K<=28`；本轮进一步排除 `K=29` 唯一剩余的
`(4,4,3^7)` 型。

七个 tight rows 每模占 21 个位置，三模 tight-row 坐标集相同，因此三模唯一
未覆盖 occurrence 必来自同一个 underlying vector。

- 若它是 A，另外 21 项都是 coordinate-singleton；剩余 A 支撑至少 8，其 cube
  有至少 512 个非零，其中至少 485 个在目标的 27 坐标之外，而 21 个 singleton
  至多取消 21 个坐标，矛盾。
- 若它在 B/C/D orbit，orbit 外 19 项三模都 covered，故均为 singleton；tight
  row/column 交结构给出该 orbit 三个向量支撑至多 `1,3,3`，于是
  `K<=19+1+3+3=26`，矛盾。

所以 exact 必有 `K>=30`。对任意整数可行点，ABS_ALT linking 只保证
`sum(ABS_ALT)>=3K`（不假定连续辅助变量取最小）；对 inexact 点，实际整数误差
至少 1，RESIDUAL linking 保证辅助 residual sum 至少 1，再结合官方已有
`sum(ABS_ALT)>=84`。由此得到全局整数有效 cut

```text
sum(ABS_ALT) + 6*sum(RESIDUAL) >= 90.
```

Gurobi 13.0.2 的数值核验：原 LP 为 84，加 cut 后 LP 为 90，加 cut 后 root
bound 为 90。cut 有 1,323 个非零（594 个系数 1、729 个系数 6），原 MPS 中
`_C229556` 经逐项核对正是 `sum(ABS_ALT)>=84`。

## 围绕两个新 core 的继续搜索

以下有限邻域对两个 core 都做了完整精确穷举且无改进：

- coefficient Hamming radius 1/2：每个 core 分别 396 与 78,012 个候选；
- 单完整向量替换：全部 22 个 underlying vector，每个枚举 `3^9`，共
  433,026 个候选；
- 一换一 support exchange：`50*148*2=14,800` 个候选。

更强的官方 MPS fixed-support 模型允许原 50 个位置任意删除/改符号，禁止激活
148 个原零位置，并加 `objective<=1149`。两个模型都完整返回 `INFEASIBLE`
（275 与 2,084 nodes）。这只是各自固定支撑邻域的证书，不能外推。

允许“原支撑任意改 + 最多激活一个新位置”的两个模型运行 600 秒均无解，但
状态为 `TIME_LIMIT`；node 数分别 16,186 与 14,328，best bound 分别
1096.009 与 1096.021。它们只是范围明确的负搜索证据，不是不可行证明。

## exact K=30 边界

证明还推出：若 exact `K=30` 存在，其 row-degree multiset 只能为

```text
(4,4,4,3,3,3,3,3,3).
```

相应完整分支探针在 183.167 秒后 `TIME_LIMIT`、root 1、solution 0。因此不能
声称 exact rank 22 不存在，也不能把 exact support 下界提高到 31。

## 可以与不可以声称的内容

可以声称：官方整数 MIP 的严格区间是 `[90,1150]`；exact 必有 `K>=30`；
1150 的两个 external-derived solution 已通过官方 MPS 全套严格审计；两个固定
support 邻域均不含 objective≤1149 的点。

不能声称：1150 的外部母构造由项目/GPT 原创；不存在 exact rank-22；exact K=30 不可行；
全局不存在 `E=1,K<=49`；或 at-most-one-new-support 的 TIME_LIMIT 是证明。
