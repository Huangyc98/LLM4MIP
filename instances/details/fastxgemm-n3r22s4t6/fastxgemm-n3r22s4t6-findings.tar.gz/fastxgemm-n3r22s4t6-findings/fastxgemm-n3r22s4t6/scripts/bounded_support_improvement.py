#!/usr/bin/env python3
"""Official-MPS search below a supplied incumbent in a bounded support neighborhood.

All locations that are zero in the supplied core are either fixed to zero
(``--max-new 0``) or at most ``--max-new`` of them may be activated.  Old
support locations may be deleted or have their signs changed arbitrarily.

For the cyclic R22 model, objective <= 1149 implies actual tensor L1 error at
most one.  A cyclic-invariant error of L1 one must be on the diagonal, so the
additional residual restriction used here is valid for that objective cap.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import math
import time
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def load_semantic():
    path = Path(__file__).resolve().parents[3] / "MIPLIB_openproblem-fastxgemm-publish-20260909" / "instances" / "fastxgemm-n3r22s4t6" / "scripts" / "r22_semantic_audit.py"
    spec = importlib.util.spec_from_file_location("r22_semantic", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


sem = load_semantic()


def status_name(status: int) -> str:
    return {
        GRB.OPTIMAL: "OPTIMAL",
        GRB.INFEASIBLE: "INFEASIBLE",
        GRB.TIME_LIMIT: "TIME_LIMIT",
        GRB.INTERRUPTED: "INTERRUPTED",
        GRB.INF_OR_UNBD: "INF_OR_UNBD",
    }.get(status, str(status))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model", type=Path)
    parser.add_argument("start", type=Path)
    parser.add_argument("--max-new", type=int, default=0)
    parser.add_argument("--objective-cap", type=float, default=1149.0)
    parser.add_argument("--time-limit", type=float, default=600.0)
    parser.add_argument("--threads", type=int, default=8)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--write-model", type=Path)
    args = parser.parse_args()
    if args.max_new < 0:
        raise ValueError("--max-new must be nonnegative")
    for path in (args.json, args.log, args.write_model):
        if path is not None:
            path.parent.mkdir(parents=True, exist_ok=True)

    started = time.perf_counter()
    start, _ = sem.read_solution_with_implicit_zero(args.start)
    model = gp.read(str(args.model))

    outside_location_pairs = []
    old_support_locations = []
    for letter, width in sem.semantic.BLOCK_WIDTHS.items():
        for row in range(9):
            for column in range(width):
                pos = model.getVarByName(f"POS_{letter}_{row}_{column}")
                neg = model.getVarByName(f"NEG_{letter}_{row}_{column}")
                if round(start[pos.VarName]) == 0 and round(start[neg.VarName]) == 0:
                    outside_location_pairs.append((pos, neg))
                else:
                    old_support_locations.append((pos, neg))

    if args.max_new == 0:
        for pos, neg in outside_location_pairs:
            pos.UB = 0
            neg.UB = 0
    else:
        model.addConstr(
            gp.quicksum(pos + neg for pos, neg in outside_location_pairs) <= args.max_new,
            name="MAX_NEW_UNDERLYING_SUPPORT_LOCATIONS",
        )

    diagonal = []
    off_diagonal_fixed_zero = 0
    for i in range(9):
        for j in range(9):
            for k in range(9):
                residual = model.getVarByName(f"RESIDUAL_{i}_{j}_{k}")
                if i == j == k:
                    diagonal.append(residual)
                else:
                    residual.UB = 0
                    off_diagonal_fixed_zero += 1
    model.addConstr(gp.quicksum(diagonal) <= 1, name="E_LE_ONE_DIAGONAL")
    model.addConstr(model.getObjective() <= args.objective_cap, name="OBJECTIVE_CAP")
    model.update()
    if args.write_model:
        model.write(str(args.write_model))

    model.read(str(args.start))
    model.Params.LogFile = str(args.log)
    model.Params.Threads = args.threads
    model.Params.TimeLimit = args.time_limit
    model.Params.FeasibilityTol = 1e-9
    model.Params.IntFeasTol = 1e-9
    model.Params.OptimalityTol = 1e-9
    model.Params.NumericFocus = 3
    model.Params.Presolve = 2
    model.Params.MIPFocus = 2
    model.optimize()

    result = {
        "instance": "fastxgemm-n3r22s4t6",
        "center": str(args.start),
        "scope": {
            "old_support_locations": len(old_support_locations),
            "outside_support_locations": len(outside_location_pairs),
            "max_new_support_locations": args.max_new,
            "allowed_old_support_edits": "arbitrary deletion and sign changes",
            "objective_cap": args.objective_cap,
            "off_diagonal_residuals_fixed_zero": off_diagonal_fixed_zero,
            "diagonal_residual_sum_cap": 1,
        },
        "validity": (
            "For objective <=1149, integer ternary factors imply actual E<=1; "
            "cyclic invariance forces any single error coordinate to be diagonal."
        ),
        "gurobi_version": ".".join(map(str, gp.gurobi.version())),
        "model_after_neighborhood_constraints": {
            "variables": model.NumVars,
            "constraints": model.NumConstrs,
            "nonzeros": model.NumNZs,
            "fingerprint": "0x%08x" % (model.Fingerprint & 0xFFFFFFFF),
        },
        "solve": {
            "status_code": int(model.Status),
            "status": status_name(model.Status),
            "solution_count": int(model.SolCount),
            "runtime_seconds": float(model.Runtime),
            "wall_seconds": time.perf_counter() - started,
            "node_count": float(model.NodeCount),
            "best_bound": float(model.ObjBound) if model.IsMIP and math.isfinite(float(model.ObjBound)) else None,
            "best_objective": float(model.ObjVal) if model.SolCount else None,
        },
        "interpretation": (
            "INFEASIBLE is a complete certificate only for the explicitly stated bounded-support neighborhood. "
            "TIME_LIMIT is not a nonexistence proof."
        ),
    }
    args.json.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
