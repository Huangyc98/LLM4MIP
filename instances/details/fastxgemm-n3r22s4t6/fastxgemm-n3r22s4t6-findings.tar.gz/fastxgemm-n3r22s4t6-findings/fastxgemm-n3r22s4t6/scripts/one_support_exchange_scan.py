#!/usr/bin/env python3
"""Exhaust every one-for-one underlying support exchange around an R22 core."""

from __future__ import annotations

import argparse
import importlib.util
import itertools
import json
import time
from pathlib import Path

import numpy as np


def load_semantic():
    path = Path(__file__).resolve().parents[3] / "MIPLIB_openproblem-fastxgemm-publish-20260909" / "instances" / "fastxgemm-n3r22s4t6" / "scripts" / "r22_semantic_audit.py"
    spec = importlib.util.spec_from_file_location("r22_semantic", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


sem = load_semantic()


def target_tensor() -> np.ndarray:
    target = np.zeros((9, 9, 9), dtype=np.int16)
    for i, j, k in itertools.product(range(9), repeat=3):
        target[i, j, k] = sem.semantic.target_value(i, j, k)
    return target


def cyclic_group(b: np.ndarray, c: np.ndarray, d: np.ndarray) -> np.ndarray:
    return (
        np.einsum("i,j,k->ijk", b, d, c, dtype=np.int16)
        + np.einsum("i,j,k->ijk", c, b, d, dtype=np.int16)
        + np.einsum("i,j,k->ijk", d, c, b, dtype=np.int16)
    )


def key(letter: str, column: int):
    return ("A", column) if letter == "A" else ("G", column)


def component(blocks, component):
    kind, column = component
    if kind == "A":
        a = blocks["A"][:, column]
        return np.einsum("i,j,k->ijk", a, a, a, dtype=np.int16)
    return cyclic_group(*(blocks[letter][:, column] for letter in "BCD"))


def full_tensor(blocks):
    result = np.zeros((9, 9, 9), dtype=np.int16)
    for column in range(4):
        result += component(blocks, ("A", column))
    for column in range(6):
        result += component(blocks, ("G", column))
    return result


def structurally_valid(blocks) -> bool:
    if any(np.any(np.count_nonzero(blocks[letter], axis=0) < 1) for letter in "ABCD"):
        return False
    return not np.any(sum(np.count_nonzero(blocks[letter], axis=1) for letter in "ABCD") < 1)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    args = parser.parse_args()
    started = time.perf_counter()

    values, _ = sem.read_solution_with_implicit_zero(args.solution)
    raw = sem.semantic.reconstruct_blocks(values, tolerance=0)
    blocks = {letter: np.asarray(raw[letter], dtype=np.int8) for letter in "ABCD"}
    target = target_tensor()
    incumbent_tensor = full_tensor(blocks)
    incumbent_k = int(sum(np.count_nonzero(blocks[letter]) for letter in "ABCD"))
    incumbent_e = int(np.abs(target - incumbent_tensor).sum())
    incumbent_objective = 1000 * incumbent_e + 3 * incumbent_k
    old_components = {
        component_key: component(blocks, component_key)
        for component_key in ([('A', column) for column in range(4)] + [('G', column) for column in range(6)])
    }

    active = []
    inactive = []
    for letter in "ABCD":
        for column in range(sem.semantic.BLOCK_WIDTHS[letter]):
            for row in range(9):
                location = (letter, row, column)
                (active if blocks[letter][row, column] else inactive).append(location)

    nominal = len(active) * len(inactive) * 2
    structurally_valid_count = 0
    model_feasible_count = 0
    best = {"E": incumbent_e, "K": incumbent_k, "objective": incumbent_objective, "move": None}
    improving = []

    for removed in active:
        for added in inactive:
            for added_value in (-1, 1):
                modified = {letter: blocks[letter].copy() for letter in "ABCD"}
                modified[removed[0]][removed[1], removed[2]] = 0
                modified[added[0]][added[1], added[2]] = added_value
                if not structurally_valid(modified):
                    continue
                structurally_valid_count += 1
                touched = {key(removed[0], removed[2]), key(added[0], added[2])}
                tensor = incumbent_tensor.copy()
                for component_key in touched:
                    tensor += component(modified, component_key) - old_components[component_key]
                difference = target - tensor
                if int(np.max(np.abs(difference))) > 1:
                    continue
                model_feasible_count += 1
                e_value = int(np.abs(difference).sum())
                objective = 1000 * e_value + 3 * incumbent_k
                move = {
                    "remove": {"letter": removed[0], "row": removed[1], "column": removed[2]},
                    "add": {"letter": added[0], "row": added[1], "column": added[2], "value": added_value},
                }
                candidate = {"E": e_value, "K": incumbent_k, "objective": objective, "move": move}
                if objective < best["objective"]:
                    best = candidate
                if objective < incumbent_objective and len(improving) < 100:
                    improving.append(candidate)

    result = {
        "instance": "fastxgemm-n3r22s4t6",
        "method": "exact exhaustive one-for-one underlying support exchange",
        "center": str(args.solution),
        "incumbent": {"E": incumbent_e, "K": incumbent_k, "objective": incumbent_objective},
        "active_locations": len(active),
        "inactive_locations": len(inactive),
        "nominal_candidates": nominal,
        "structurally_valid_candidates": structurally_valid_count,
        "model_feasible_candidates": model_feasible_count,
        "best": best,
        "strict_improvement_found": bool(improving),
        "strict_improvements": improving,
        "elapsed_seconds": time.perf_counter() - started,
    }
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
