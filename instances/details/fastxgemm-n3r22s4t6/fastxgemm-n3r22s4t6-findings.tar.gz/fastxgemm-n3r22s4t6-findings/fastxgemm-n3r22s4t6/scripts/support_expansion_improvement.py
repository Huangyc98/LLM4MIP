#!/usr/bin/env python3
"""Search for a strict improvement using at most a small number of new support positions."""

from __future__ import annotations

import argparse
import importlib.util
import json
import math
import time
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def load_semantic():
    path = Path(__file__).with_name("r22_semantic_audit.py")
    spec = importlib.util.spec_from_file_location("r22_semantic", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


sem = load_semantic()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model", type=Path)
    parser.add_argument("start", type=Path)
    parser.add_argument("--max-new", type=int, default=1)
    parser.add_argument("--time-limit", type=float, default=300)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    args = parser.parse_args()
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.log.parent.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()

    start, _ = sem.read_solution_with_implicit_zero(args.start)
    model = gp.read(str(args.model))
    outside = []
    for letter, width in sem.semantic.BLOCK_WIDTHS.items():
        for row in range(9):
            for column in range(width):
                pos = model.getVarByName(f"POS_{letter}_{row}_{column}")
                neg = model.getVarByName(f"NEG_{letter}_{row}_{column}")
                if round(start[pos.VarName]) == 0 and round(start[neg.VarName]) == 0:
                    outside.extend((pos, neg))
    model.addConstr(gp.quicksum(outside) <= args.max_new, name="MAX_NEW_SUPPORT_LOCATIONS")

    diagonal = []
    for i in range(9):
        for j in range(9):
            for k in range(9):
                residual = model.getVarByName(f"RESIDUAL_{i}_{j}_{k}")
                if i == j == k:
                    diagonal.append(residual)
                else:
                    residual.UB = 0
    model.addConstr(gp.quicksum(diagonal) <= 1, name="IMPROVE_E_LE_ONE_DIAGONAL")
    model.addConstr(model.getObjective() <= 1168, name="STRICT_IMPROVEMENT_LATTICE_CAP")
    model.update()
    model.read(str(args.start))
    model.Params.LogFile = str(args.log)
    model.Params.Threads = 4
    model.Params.TimeLimit = args.time_limit
    model.Params.FeasibilityTol = 1e-9
    model.Params.IntFeasTol = 1e-9
    model.Params.OptimalityTol = 1e-9
    model.Params.NumericFocus = 3
    model.Params.Presolve = 2
    model.Params.MIPFocus = 1
    model.optimize()

    names = {
        GRB.OPTIMAL: "OPTIMAL",
        GRB.INFEASIBLE: "INFEASIBLE",
        GRB.TIME_LIMIT: "TIME_LIMIT",
        GRB.INTERRUPTED: "INTERRUPTED",
    }
    result = {
        "instance": "fastxgemm-n3r22s4t6",
        "scope": f"arbitrary old-support edits and at most {args.max_new} activation(s) outside the author's 57 positions",
        "outside_binary_variable_count": len(outside),
        "outside_underlying_location_count": len(outside) // 2,
        "max_new_support_locations": args.max_new,
        "objective_cap": 1168,
        "status": names.get(model.Status, str(model.Status)),
        "status_code": int(model.Status),
        "solution_count": int(model.SolCount),
        "runtime_seconds": float(model.Runtime),
        "wall_seconds": time.perf_counter() - started,
        "node_count": float(model.NodeCount),
        "best_bound": float(model.ObjBound) if model.IsMIP and math.isfinite(float(model.ObjBound)) else None,
        "best_objective": float(model.ObjVal) if model.SolCount else None,
        "interpretation": (
            "INFEASIBLE is a scoped proof. TIME_LIMIT with no incumbent is only negative search evidence and does not prove nonexistence."
        ),
    }
    args.json.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
