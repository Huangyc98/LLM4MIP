#!/usr/bin/env python3
"""Delete each fixed A column of the audited external R23 construction.

The input is the strict official-MPS completion of the Ballard--Ikenmeyer--
Landsberg--Ryder (BILR) S_Lader-Z3 rank-23 decomposition.  This script reads
only its POS/NEG variables, checks the parent tensor identity exactly over the
integers, deletes each of the five fixed A columns in turn, and writes the five
resulting R22 integer patterns plus a complete exact audit.

The construction is external-derived.  It is not a project/GPT-discovered
primal solution.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


N = 3
PARENT_WIDTHS = {"A": 5, "B": 6, "C": 6, "D": 6}
CHILD_WIDTHS = {"A": 4, "B": 6, "C": 6, "D": 6}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_solution(path: Path) -> dict[str, int]:
    values: dict[str, int] = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or line.startswith("=obj="):
            continue
        fields = line.split()
        if len(fields) < 2:
            continue
        value = float(fields[1])
        rounded = round(value)
        if abs(value - rounded) > 1e-9:
            raise ValueError(f"nonintegral value in strict parent: {line}")
        values[fields[0]] = int(rounded)
    return values


def reconstruct(values: dict[str, int], widths: dict[str, int]):
    blocks: dict[str, list[list[int]]] = {}
    for letter, width in widths.items():
        matrix = [[0 for _ in range(width)] for _ in range(N * N)]
        for row in range(N * N):
            for column in range(width):
                pos_name = f"POS_{letter}_{row}_{column}"
                neg_name = f"NEG_{letter}_{row}_{column}"
                if pos_name not in values or neg_name not in values:
                    raise KeyError(f"missing {pos_name} or {neg_name}")
                pos, neg = values[pos_name], values[neg_name]
                if pos not in (0, 1) or neg not in (0, 1) or pos + neg > 1:
                    raise ValueError(f"bad ternary encoding at {letter}[{row},{column}]")
                matrix[row][column] = pos - neg
        blocks[letter] = matrix
    return blocks


def hstack(matrices: list[list[list[int]]]) -> list[list[int]]:
    return [[value for matrix in matrices for value in matrix[row]] for row in range(N * N)]


def factors(blocks: dict[str, list[list[int]]]):
    a, b, c, d = (blocks[letter] for letter in "ABCD")
    return hstack([a, b, c, d]), hstack([a, d, b, c]), hstack([a, c, d, b])


def target(i: int, j: int, k: int) -> int:
    return int(any(i == n * N + q and j == q * N + m and k == m * N + n
                   for n in range(N) for m in range(N) for q in range(N)))


def exact_audit(blocks: dict[str, list[list[int]]]) -> dict:
    u, v, w = factors(blocks)
    width = sum(CHILD_WIDTHS.values()) if len(blocks["A"][0]) == 4 else sum(PARENT_WIDTHS.values())
    if any(len(row) != width for matrix in (u, v, w) for row in matrix):
        raise AssertionError("unexpected factor width")
    errors = []
    expansion_histogram: dict[int, int] = {}
    for i in range(N * N):
        for j in range(N * N):
            for k in range(N * N):
                expansion = sum(u[i][r] * v[j][r] * w[k][r] for r in range(width))
                difference = target(i, j, k) - expansion
                expansion_histogram[expansion] = expansion_histogram.get(expansion, 0) + 1
                if difference:
                    errors.append({
                        "coordinate": [i, j, k],
                        "target": target(i, j, k),
                        "expansion": expansion,
                        "target_minus_expansion": difference,
                    })
    support = sum(value != 0 for matrix in blocks.values() for row in matrix for value in row)
    residual_l1 = sum(abs(error["target_minus_expansion"]) for error in errors)
    return {
        "R": width,
        "K": support,
        "full_factor_support": 3 * support,
        "E": residual_l1,
        "objective": 1000 * residual_l1 + 3 * support,
        "nonzero_error_coordinates": len(errors),
        "max_abs_error": max((abs(error["target_minus_expansion"]) for error in errors), default=0),
        "errors": errors,
        "expansion_histogram": {str(key): value for key, value in sorted(expansion_histogram.items())},
        "column_support": {
            letter: [sum(blocks[letter][row][column] != 0 for row in range(N * N))
                     for column in range(len(blocks[letter][0]))]
            for letter in "ABCD"
        },
    }


def delete_a_column(parent: dict[str, list[list[int]]], deleted: int):
    return {
        "A": [[value for column, value in enumerate(row) if column != deleted] for row in parent["A"]],
        "B": [row[:] for row in parent["B"]],
        "C": [row[:] for row in parent["C"]],
        "D": [row[:] for row in parent["D"]],
    }


def write_sparse_pattern(path: Path, blocks: dict[str, list[list[int]]], objective: int, deleted: int) -> None:
    lines = [
        f"=obj= {objective}",
        "# EXTERNAL-DERIVED candidate; not a project/GPT primal contribution.",
        "# Derived by deleting one fixed A term from the audited BILR S_Lader-Z3 R23 decomposition.",
        f"# Deleted original A column {deleted}.",
    ]
    for letter, width in CHILD_WIDTHS.items():
        for row in range(N * N):
            for column in range(width):
                value = blocks[letter][row][column]
                lines.append(f"POS_{letter}_{row}_{column} {int(value == 1)}")
                lines.append(f"NEG_{letter}_{row}_{column} {int(value == -1)}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("parent_solution", type=Path)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    args.report.parent.mkdir(parents=True, exist_ok=True)

    parent_values = read_solution(args.parent_solution)
    parent = reconstruct(parent_values, PARENT_WIDTHS)
    parent_audit = exact_audit(parent)
    if parent_audit["R"] != 23 or parent_audit["E"] != 0 or parent_audit["K"] != 51:
        raise AssertionError(f"unexpected parent semantics: {parent_audit}")

    deletions = []
    for deleted in range(PARENT_WIDTHS["A"]):
        child = delete_a_column(parent, deleted)
        child_audit = exact_audit(child)
        deleted_vector = [parent["A"][row][deleted] for row in range(N * N)]
        deleted_support = sum(value != 0 for value in deleted_vector)
        if child_audit["E"] != deleted_support ** 3:
            raise AssertionError("child residual is not the deleted symmetric cube")
        output = args.output_dir / f"external-bilr-delete-a{deleted}-core.sol"
        write_sparse_pattern(output, child, child_audit["objective"], deleted)
        deletions.append({
            "deleted_a_column": deleted,
            "deleted_vector": deleted_vector,
            "deleted_vector_support": deleted_support,
            "deleted_cube_l1": deleted_support ** 3,
            "child": child_audit,
            "candidate_core_solution": str(output),
            "candidate_sha256": sha256(output),
            "qualifies_strict_improvement_over_author_1171": child_audit["objective"] < 1171,
        })

    report = {
        "provenance_classification": "external-derived",
        "counts_as_project_or_gpt_primal_contribution": False,
        "source": {
            "authors": ["Grey Ballard", "Christian Ikenmeyer", "J. M. Landsberg", "Nick Ryder"],
            "paper": "The geometry of rank decompositions of matrix multiplication II: 3x3 matrices",
            "decomposition": "S_Lader-Z3",
            "location": "Appendix B, equations (77)-(84), PDF page 29",
            "parent_strict_solution": str(args.parent_solution),
            "parent_sha256": sha256(args.parent_solution),
        },
        "parent_exact_audit": parent_audit,
        "method": "delete each of the five fixed A columns and reindex the four survivors",
        "deletions": deletions,
        "improving_deletion_indices": [
            item["deleted_a_column"] for item in deletions
            if item["qualifies_strict_improvement_over_author_1171"]
        ],
        "all_checks_pass": True,
    }
    args.report.write_text(json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({
        "parent": {key: parent_audit[key] for key in ("R", "E", "K", "objective")},
        "deletions": [
            {"deleted": item["deleted_a_column"], "support": item["deleted_vector_support"],
             "E": item["child"]["E"], "K": item["child"]["K"], "objective": item["child"]["objective"]}
            for item in deletions
        ],
    }, indent=2))


if __name__ == "__main__":
    main()
