#!/usr/bin/env python3
"""Probe the unresolved exact R22, K=30 branch with proved valid structure."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


S = 4
T = 6
R = 22


def finite(value: float) -> float | None:
    return float(value) if math.isfinite(float(value)) else None


def source_for_rank(mode: str, row: int, rank: int) -> tuple[str, int, int]:
    if rank < S:
        return ("A", row, rank)
    offset = rank - S
    group, column = divmod(offset, T)
    orders = {"U": "BCD", "V": "DBC", "W": "CDB"}
    return (orders[mode][group], row, column)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--output-model", type=Path, required=True)
    parser.add_argument("--solution", type=Path)
    parser.add_argument("--time-limit", type=float, default=180.0)
    parser.add_argument("--threads", type=int, default=8)
    args = parser.parse_args()
    for path in (args.json, args.log, args.output_model):
        path.parent.mkdir(parents=True, exist_ok=True)
    if args.solution:
        args.solution.parent.mkdir(parents=True, exist_ok=True)

    model = gp.read(str(args.mps))
    residuals = [v for v in model.getVars() if v.VarName.startswith("RESIDUAL_")]
    if len(residuals) != 729:
        raise RuntimeError(f"unexpected residual count: {len(residuals)}")
    for variable in residuals:
        variable.UB = 0.0

    z: dict[tuple[str, int, int], gp.LinExpr] = {}
    x: dict[tuple[str, int, int], gp.LinExpr] = {}
    widths = {"A": S, "B": T, "C": T, "D": T}
    for letter, width in widths.items():
        for row in range(9):
            for column in range(width):
                pos = model.getVarByName(f"POS_{letter}_{row}_{column}")
                neg = model.getVarByName(f"NEG_{letter}_{row}_{column}")
                z[letter, row, column] = pos + neg
                x[letter, row, column] = pos - neg
    model.addConstr(gp.quicksum(z.values()) == 30, name="EXACT_K30_CORE_SUPPORT")

    # The accompanying proof eliminates the other K=30 degree patterns.
    # Therefore an exact K=30 point must have six degree-3 rows and three
    # degree-4 rows.  HIGH_i=1 denotes the latter.
    high = [model.addVar(vtype=GRB.BINARY, name=f"PROVED_K30_HIGH_ROW_{row}") for row in range(9)]
    for row in range(9):
        degree = gp.quicksum(
            z[letter, row, column]
            for letter, width in widths.items()
            for column in range(width)
        )
        model.addConstr(degree == 3 + high[row], name=f"PROVED_K30_ROW_DEGREE_{row}")
    model.addConstr(gp.quicksum(high) == 3, name="PROVED_K30_THREE_HIGH_ROWS")

    # Two degree-3 (tight) rows cannot share a rank position, independently
    # in each factor mode.  If either row is high the inequality is inactive.
    disjoint_constraints = 0
    for mode in "UVW":
        for rank in range(R):
            for left in range(9):
                for right in range(left + 1, 9):
                    left_key = source_for_rank(mode, left, rank)
                    right_key = source_for_rank(mode, right, rank)
                    model.addConstr(
                        z[left_key] + z[right_key]
                        <= 1 + high[left] + high[right],
                        name=f"TIGHT_DISJOINT_{mode}_{rank}_{left}_{right}",
                    )
                    disjoint_constraints += 1

    symmetry_names = []
    # Four A cubes are freely permutable.  Balanced ternary encoding is
    # injective on nine-entry ternary vectors; non-strict order keeps ties.
    weights = [3 ** (8 - row) for row in range(9)]
    for column in range(S - 1):
        name = f"SYM_SORT_A_{column}_{column + 1}"
        model.addConstr(
            gp.quicksum(weights[row] * x["A", row, column] for row in range(9))
            <= gp.quicksum(weights[row] * x["A", row, column + 1] for row in range(9)),
            name=name,
        )
        symmetry_names.append(name)

    # Within each cyclic orbit, product-one sign gauges independently choose
    # the signs of B and C, with D absorbing their product.
    for column in range(T):
        for letter in "BC":
            for row in range(9):
                name = f"SYM_FIRST_NONZERO_POS_{letter}_{column}_{row}"
                model.addConstr(
                    model.getVarByName(f"NEG_{letter}_{row}_{column}")
                    <= gp.quicksum(
                        z[letter, earlier, column] for earlier in range(row)
                    ),
                    name=name,
                )
                symmetry_names.append(name)

    # The six complete B/C/D orbit groups are freely permutable.  Sorting by
    # total support is non-strict and therefore valid even for tied groups.
    for column in range(T - 1):
        name = f"SYM_SORT_BCD_GROUP_SUPPORT_{column}_{column + 1}"
        model.addConstr(
            gp.quicksum(z[letter, row, column] for letter in "BCD" for row in range(9))
            <= gp.quicksum(
                z[letter, row, column + 1] for letter in "BCD" for row in range(9)
            ),
            name=name,
        )
        symmetry_names.append(name)

    model.setObjective(0.0)
    model.update()
    model.write(str(args.output_model))
    model.Params.LogFile = str(args.log)
    model.Params.TimeLimit = args.time_limit
    model.Params.Threads = args.threads
    model.Params.Seed = 0
    model.Params.Presolve = 2
    model.Params.DualReductions = 0
    model.Params.FeasibilityTol = 1e-9
    model.Params.IntFeasTol = 1e-9
    model.Params.OptimalityTol = 1e-9
    model.Params.NumericFocus = 2
    model.Params.MIPFocus = 1
    model.Params.Cuts = 2
    model.Params.Symmetry = 2
    model.Params.Heuristics = 0.5
    model.Params.SolutionLimit = 1
    model.optimize()

    status_names = {
        GRB.OPTIMAL: "FEASIBLE_FOUND",
        GRB.SOLUTION_LIMIT: "FEASIBLE_FOUND",
        GRB.INFEASIBLE: "INFEASIBLE",
        GRB.TIME_LIMIT: "TIME_LIMIT",
        GRB.INTERRUPTED: "INTERRUPTED",
    }
    if args.solution and model.SolCount:
        model.write(str(args.solution))
    result = {
        "instance": "fastxgemm-n3r22s4t6",
        "scope": "exact E=0 and underlying core support K=30",
        "dependency": (
            "Uses the separately proved K=30 degree reduction: only six "
            "degree-3 rows and three degree-4 rows need be retained."
        ),
        "completeness": (
            "INFEASIBLE would exclude the complete exact K=30 branch when "
            "combined with LB90_PROOF.md; TIME_LIMIT is not a proof."
        ),
        "valid_structure": {
            "residuals_fixed_zero": len(residuals),
            "core_support": 30,
            "high_rows": 3,
            "tight_rows": 6,
            "tight_disjointness_constraints": disjoint_constraints,
            "symmetry_constraints": len(symmetry_names),
            "symmetry_detail": (
                "non-strict A-column order; first-nonzero-positive B/C sign "
                "gauges; non-strict BCD-orbit support order"
            ),
        },
        "gurobi_version": ".".join(map(str, gp.gurobi.version())),
        "parameters": {
            "time_limit": args.time_limit,
            "threads": args.threads,
            "seed": 0,
            "dual_reductions": 0,
            "solution_limit": 1,
        },
        "dimensions": {
            "variables": model.NumVars,
            "constraints": model.NumConstrs,
            "nonzeros": model.NumNZs,
            "integer_variables": sum(
                v.VType in {GRB.BINARY, GRB.INTEGER} for v in model.getVars()
            ),
        },
        "solve": {
            "status_code": int(model.Status),
            "status": status_names.get(model.Status, str(model.Status)),
            "solution_count": int(model.SolCount),
            "runtime_seconds": float(model.Runtime),
            "node_count": float(model.NodeCount),
            "simplex_iterations": float(model.IterCount),
            "objective": finite(model.ObjVal) if model.SolCount else None,
            "objective_bound": finite(model.ObjBound),
        },
        "output_model": str(args.output_model),
        "output_solution": str(args.solution) if args.solution and model.SolCount else None,
    }
    args.json.write_text(
        json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(result, indent=2, sort_keys=True, allow_nan=False))


if __name__ == "__main__":
    main()
