# `fastxgemm-n3r22s4t6` 的全局下界 87 与有效割

> **历史有效但已被加强。** 本文的 LB87 证明仍然成立，但已由同目录
> `LB90_PROOF.md` 的全局下界 90 严格支配。当前严格区间为 `[90,1150]`；本文
> 仅作为早期证明链保留。

本文只讨论 MIPLIB 实例 `fastxgemm-n3r22s4t6` 的特定模型：因子取值属于
`{-1,0,1}`，秩为 `R=22`，并采用 `S=4,T=6` 的循环参数化。它不是对一般
`3×3` 矩阵乘法 tensor rank 的 22 阶下界证明。

## 1. 记号

模型令

```text
U = [A B C D],  V = [A D B C],  W = [A C D B],
```

其中 `A` 有 4 列，`B,C,D` 各有 6 列。令 `K` 为 `[A B C D]` 中非零元素数。
块置换保证 `U,V,W` 各自都恰有 `K` 个非零元素，所以目标中的完整 factor
support 等于 `3K`。

将 factor matrix 的一行记作 `(n,q)∈{0,1,2}²`。矩阵乘法 tensor 的 1 位于

```text
((n,q),(q,m),(m,n)),  m,n,q∈{0,1,2}.
```

## 2. 每一行至少使用三个 rank column

固定 `U` 的行 `i=(n,q)`。目标 tensor 的对应 `9×9` slice 在
`((q,m),(m,n))` 上有三个 1，因此矩阵秩为 3。

一个精确分解将该 slice 写成

```text
sum_{r: U[i,r] != 0} U[i,r] V[:,r] W[:,r]^T.
```

每一项的矩阵秩至多为 1。因此，若 `d_i` 是 `U` 第 `i` 行的非零数，则
`d_i≥3`。九行相加得到 `K=sum_i d_i≥27`。

## 3. 两个恰好三项的行不能共享 rank column

称 `d_i=3` 的行为 tight row。一个秩为 3 的 slice 若恰由三个秩一矩阵相加，
其三个 `V` 向量必须张成该 slice 的列空间，三个 `W` 向量必须张成其行空间。
所以，对 tight row `i=(n,q)` 使用的每个 column `r`，都有

```text
V[:,r] 的支撑只可能位于 {(q,m):m=0,1,2},
W[:,r] 的支撑只可能位于 {(m,n):m=0,1,2}.
```

若两个不同的 tight row `(n,q)` 与 `(n',q')` 共享 column：

- 当 `q!=q'` 时，两个允许的 `V` 坐标子空间不相交，迫使 `V[:,r]=0`；
- 当 `q=q'` 时必有 `n!=n'`，两个允许的 `W` 坐标子空间不相交，迫使
  `W[:,r]=0`。

两种情形都会使共享 column 的 rank-one 项为零；这样 tight slice 实际至多只剩
两个非零 rank-one 项，不可能得到秩 3。因此，不同 tight row 各自使用的三个
rank column 两两不交。这个结论不需要额外援引“每列非零”约束。

## 4. 精确重构必有 `K≥29`

假设 `K≤28`。九个行度数均至少为 3，而总和至多为 28，所以至少八行为
tight row。上一节表明它们需要至少 `8×3=24` 个不同 rank column，但模型
只有 22 个，矛盾。因此精确重构必有

```text
K >= 29,
full factor support = 3K >= 87.
```

## 5. 对整个整数模型有效的割

原模型已有 `sum(ABS_ALT)≥84`。在整数 factor pattern 上，product gadget 重构
出的每个 tensor 坐标是整数。因此：

- 若重构精确，则上一节给出 `sum(ABS_ALT)≥87`；
- 若重构不精确，则至少一个整数坐标的误差绝对值不小于 1，即
  `sum(RESIDUAL)≥1`，与原有 support 下界合并也达到 87。

故所有整数可行点满足

```text
sum(ABS_ALT) + 3 sum(RESIDUAL) >= 87.                 (CUT-87)
```

这是 mixed-integer-valid cut；证明使用了 factor pattern 的整数性，并不声称
它对删去整数条件后的原始 LP polytope 自动成立。模型目标为

```text
1000 sum(RESIDUAL) + sum(ABS_ALT) + 0.001 sum(ABS_DIFF),
```

各项非负，所以 `(CUT-87)` 同时证明全局整数目标下界为 87。

## 6. 计算核验

`scripts/build_and_probe_lb87.py` 将 `(CUT-87)` 加入官方 MPS，并分别求解原模型
和增强模型的连续松弛：

```text
原 LP relaxation:   84.00000000000045
加 CUT-87 后:       87.00000000000045
```

结果保存在 `artifacts/lb87_probe.json`；增强模型为
`artifacts/fastxgemm-n3r22s4t6-lb87.mps.gz`。
