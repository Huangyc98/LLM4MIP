# Package manifest: fastxgemm-n3r22s4t6

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 85
Excluded source files: 1

## Included files

- `README.md`
- `REPORT.md`
- `REPRODUCE.md`
- `SHA256SUMS.txt`
- `artifacts/EXTERNAL_BILR_UB1150.md`
- `artifacts/LB87_PROOF.md`
- `artifacts/LB90_PROOF.md`
- `artifacts/author_mst_semantic_audit.json`
- `artifacts/coefficient_radius2_scan.json`
- `artifacts/exact_k30_probe.json`
- `artifacts/external-bilr-delete-a0-fixed-support-cap1149.json`
- `artifacts/external-bilr-delete-a0-fixed-support-cap1149.mps.gz`
- `artifacts/external-bilr-delete-a0-maxnew1-cap1149.json`
- `artifacts/external-bilr-delete-a0-maxnew1-cap1149.mps.gz`
- `artifacts/external-bilr-delete-a0-one-support-exchange.json`
- `artifacts/external-bilr-delete-a0-one-vector.json`
- `artifacts/external-bilr-delete-a0-radius2.json`
- `artifacts/external-bilr-delete-a0-semantic-audit.json`
- `artifacts/external-bilr-delete-a0-strict-1150.json`
- `artifacts/external-bilr-delete-a0-strict-1150.sol`
- `artifacts/external-bilr-delete-a1-fixed-support-cap1149.json`
- `artifacts/external-bilr-delete-a1-fixed-support-cap1149.mps.gz`
- `artifacts/external-bilr-delete-a1-maxnew1-cap1149.json`
- `artifacts/external-bilr-delete-a1-maxnew1-cap1149.mps.gz`
- `artifacts/external-bilr-delete-a1-one-support-exchange.json`
- `artifacts/external-bilr-delete-a1-one-vector.json`
- `artifacts/external-bilr-delete-a1-radius2.json`
- `artifacts/external-bilr-delete-a1-semantic-audit.json`
- `artifacts/external-bilr-delete-a1-strict-1150.json`
- `artifacts/external-bilr-delete-a1-strict-1150.sol`
- `artifacts/external-bilr-deletion-audit.json`
- `artifacts/external-bilr-deletions/external-bilr-delete-a0-core.sol`
- `artifacts/external-bilr-deletions/external-bilr-delete-a1-core.sol`
- `artifacts/external-bilr-deletions/external-bilr-delete-a2-core.sol`
- `artifacts/external-bilr-deletions/external-bilr-delete-a3-core.sol`
- `artifacts/external-bilr-deletions/external-bilr-delete-a4-core.sol`
- `artifacts/fastxgemm-n3r22s4t6-exact-k30.mps.gz`
- `artifacts/fastxgemm-n3r22s4t6-lb87.mps.gz`
- `artifacts/fastxgemm-n3r22s4t6-lb90.mps.gz`
- `artifacts/fixed_support_improvement.json`
- `artifacts/gurobi_structure_audit.json`
- `artifacts/lb87_probe.json`
- `artifacts/lb90_combinatorial-audit-root-rerun.json`
- `artifacts/lb90_combinatorial_audit.json`
- `artifacts/lb90_probe.json`
- `artifacts/lp_mps_equivalence.json`
- `artifacts/official_best_semantic_audit.json`
- `artifacts/one_vector_scan.json`
- `artifacts/r21_r22_r23_lineage.json`
- `artifacts/strict_author_1171_audit.json`
- `artifacts/strict_official_3102_audit.json`
- `artifacts/support_expansion_1_improvement.json`
- `input/fastxgemm-n3r22s4t6-best.sol.gz`
- `logs/augmented_lb90_lp.log`
- `logs/augmented_lb90_root.log`
- `logs/exact_k30_probe.log`
- `logs/external-bilr-delete-a0-fixed-support-cap1149.log`
- `logs/external-bilr-delete-a0-maxnew1-cap1149.log`
- `logs/external-bilr-delete-a0-strict-1150.log`
- `logs/external-bilr-delete-a1-fixed-support-cap1149.log`
- `logs/external-bilr-delete-a1-maxnew1-cap1149.log`
- `logs/external-bilr-delete-a1-strict-1150.log`
- `logs/fixed_support_improvement.log`
- `logs/original_lp.log`
- `logs/strict_author_1171.log`
- `logs/strict_official_3102.log`
- `logs/support_expansion_1_improvement.log`
- `result_summary.json`
- `scripts/audit_lp_mps_equivalence.py`
- `scripts/bounded_support_improvement.py`
- `scripts/build_and_probe_lb87.py`
- `scripts/build_and_probe_lb90.py`
- `scripts/coefficient_radius2_scan.py`
- `scripts/enumerate_external_r23_deletions.py`
- `scripts/fixed_support_improvement.py`
- `scripts/one_support_exchange_scan.py`
- `scripts/one_vector_scan.py`
- `scripts/probe_exact_k30.py`
- `scripts/r22_semantic_audit.py`
- `scripts/strict_pattern_completion.py`
- `scripts/support_expansion_improvement.py`
- `scripts/verify_lb90_combinatorics.py`
- `solutions/author-2017-strict-1171.sol`
- `solutions/external-bilr-derived-a0-strict-1150.sol`
- `solutions/external-bilr-derived-a1-strict-1150.sol`

## Excluded files

- `input/fastxgemm-n3r22s4t6.mps.gz (4009558 bytes; raw benchmark input; sha256 7c633dce6256d236d1887fa8b7b719a49e1777db6c79c09111a1e56051ce4162)`
