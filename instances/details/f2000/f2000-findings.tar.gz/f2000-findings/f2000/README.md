# `f2000`

## Result

The model asks for a minimum-size consistent partial assignment that selects a
true literal in every clause, equivalently a minimum prime implicant. The
official objective **1810** solution is exactly checked: it assigns 1,810 of
2,000 Boolean variables, leaves 190 unassigned, and covers all 8,500 clauses.

Exact preprocessing fixes six literals and produces a 3,994-variable kernel.
A root diagnostic reports a rounded lower bound of **1332**; the subsequent
600-second search found no improvement and did not close the gap. The instance
remains open.

## Provenance

- Compressed MPS SHA-256: `56125EEDEA2317D23DF9715FA39AC86EF7E9BFD572893662DABFAC83690567F4`
- Official compressed solution SHA-256: `0B8B2C3CDBF51AE26CE99EB9B0F40F8C00693FA4924AE506A74E559827A44BFD`
- [MIPLIB instance page](https://miplib.zib.de/instance_details_f2000.html)

## Reproduction

[`scripts/preprocess.py`](scripts/preprocess.py) verifies the source-to-MPS
semantics and generates the proof-oriented OPB/WCNF and three-state models in
[`artifacts/`](artifacts/). Solver output is preserved under [`logs/`](logs/).

See the [full structural report](reports/structural-investigation.md). The
bounded run is negative search evidence, not an optimality proof.
