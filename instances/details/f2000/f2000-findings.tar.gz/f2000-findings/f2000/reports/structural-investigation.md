# f2000: exact minimum-prime-implicant audit

Date: 2026-09-04
Disposition: **open. The 1810 incumbent is exact, but no matching lower bound or independently checkable optimality certificate was found.**

## 1. Canonical source and exact MPS correspondence

The canonical compressed DIMACS file was obtained from the
[DIMACS challenge archive](https://archive.dimacs.rutgers.edu/pub/challenge/sat/benchmarks/cnf/f2000.cnf.Z).
It declares 2,000 Boolean variables and 8,500 clauses, each containing three
distinct variables. Its SHA-256 is
`841f935fe24c49d93b6b8d9e23cb2158179ec7a63deee1ba79be5a70463dc1b0`.
The archive header attributes it to Bart Selman, calls it a large randomly
generated satisfiable instance, and contains the apparently stale comment
`FILE: f1000.cnf`; the numeric DIMACS header is unambiguously `2000 8500`.

`preprocess_f2000.py` compares all 8,500 clauses, in order, against the MPS.
For SAT variable `i`, the exact translation is

```text
DIMACS literal +i  ->  MPS x(2*i-1)
DIMACS literal -i  ->  MPS x(2*i)
```

MPS rows `c0` through `c8499` are exactly the translated DIMACS clauses.
Rows `c8500` through `c10499` are, in order,

\[
 x_{2i-1}+x_{2i}\leq1 \qquad (i=1,\ldots,2000).
\]

Every MPS variable is binary and every objective coefficient is one. The MPS
therefore has 4,000 variables, 10,500 rows, and 29,500 nonzeros exactly. Its
SHA-256 is
`56125eedea2317d23df9715fa39ac86ef7e9bfd572893662dabfac83690567f4`.

## 2. What is optimized: not ordinary SAT

Write `p_i=x(2i-1)` and `n_i=x(2i)`. The model is

\[
\begin{aligned}
 \min &\quad \sum_{i=1}^{2000}(p_i+n_i),\\
 \text{s.t.}&\quad \sum_{\ell\in C}x_\ell\geq1 &&\text{for every CNF clause }C,\\
 &\quad p_i+n_i\leq1 &&i=1,\ldots,2000,\\
 &\quad p_i,n_i\in\{0,1\}.&
\end{aligned}
\]

Selecting `p_i` assigns Boolean variable `i` true; selecting `n_i` assigns it
false; selecting neither leaves it unassigned. Every clause must contain a
selected true literal. Thus a feasible point is a consistent partial
assignment whose conjunction implies the whole CNF—an implicant. A
minimum-cardinality implicant is automatically prime. This agrees with the
official PB archive category **Min-Prime: Minimum-Size Prime Implicant**.

Ordinary SAT only asks for some complete assignment and would select exactly
one sign for all 2,000 variables. It neither represents nor proves the
minimum-1810 claim. Equivalently, introducing binary

\[
 u_i=1-p_i-n_i
\]

gives the exact three-state formulation `positive / negative / unassigned`,
with objective to maximize `sum u_i`; cost 1810 is the same as 190 unassigned
variables. The incumbent therefore defines a 190-dimensional Boolean subcube
on which every completion satisfies the CNF.

## 3. Exact validation of the 1810 incumbent

The official solution has SHA-256
`0b8b2c3cdbf51ae26ce99eb9b0f40f8c00693fa4924ae506a74e559827a44bfd`.
Exact integer evaluation verifies:

- 1,810 selected literal variables: 929 positive and 881 negative;
- 1,810 assigned Boolean variables and 190 unassigned variables;
- no pair has both signs selected;
- all 8,500 clauses are covered: 4,620 by one selected literal, 3,050 by two,
  and 830 by all three;
- objective exactly 1810 and minimum MPS slack zero.

Every one of the 1,810 selected literals uniquely covers at least one clause.
The histogram of unique-clause witnesses per selected literal is
`1:389, 2:620, 3:427, 4:229, 5:99, 6:30, 7:11, 8:3, 9:2`.
Consequently the incumbent is itself a prime implicant: no literal can simply
be deleted. An exhaustive check of all 1,637,145 selected-literal pairs found
no feasible two-for-one replacement by a compatible unselected literal. This
is local-search evidence, not a global lower bound.

The 600-second run's output was also evaluated exactly. Its 2,000 state
equalities and all 8,500 clauses hold, and its literal vector is identical to
the official incumbent.

## 4. Objective-safe preprocessing

There are no duplicate clauses, tautologies, repeated Boolean variables
inside a clause, or proper clause subsumptions. Five literal variables never
occur in a clause and can be fixed to zero because their cost is positive:

```text
x704  x1317  x1820  x3462  x3757
```

After `x3462=0`, its mate `x3461` is conflict-free. The sole clause containing
`x2667` is `c3858`, and that clause also contains `x3461`; indeed the nine-row
support of `x3461` strictly contains `support(x2667)={c3858}`. Any solution
using `x2667` can therefore replace it by `x3461` at no greater cost and with
no new complement conflict. Hence `x2667=0` is safe without changing the
optimum.

Dropping these six variables and their now-tautological mutex rows leaves:

| item | count |
|---|---:|
| retained literal variables | 3,994 |
| cover rows | 8,500 |
| retained mutex rows | 1,994 |
| total rows | 10,494 |
| nonzeros | 29,487 |

There are 8,499 ternary cover rows and one binary row,
`c3858: x2673+x3461>=1`. At the fixed point there is no zero-support literal,
duplicate literal support, further conflict-free support dominance, duplicate
or subsumed cover row, or singleton clause. The literal/clause/mutex graph is
one connected component of 3,994 literals. These dimensions independently
match Gurobi's presolved model.

Ordinary set-cover column dominance is unsafe because the mutex constraints
matter. There are 58 tempting strict support inclusions in the raw cover
matrix. For example, `support(x311)` is a strict subset of `support(x1227)`,
but the incumbent simultaneously selects `x311` and the complement `x1228`;
the usual direct replacement by `x1227` violates the mutex. Likewise,
ordinary SAT pure-literal assignment need not preserve the objective: pure
Boolean variables 659 and 1879 are deliberately unassigned in the incumbent.

## 5. Proof-ready formulations

The artifact directory contains:

- `f2000-original-lb1810.opb`, a direct translation of all original MPS rows
  plus `sum x <= 1809`; its UNSAT is exactly the missing lower-bound proof;
- reduced optimization and `<=1809` decision OPBs;
- a reduced WCNF with 8,500 hard cover clauses, 1,994 hard mutex clauses, and
  3,994 unit soft clauses `not x` of weight one;
- the literal/pair/reduced-variable map;
- the exact three-state LP and incumbent start.

The original decision OPB is the cleanest certificate target because it does
not require trusting external preprocessing. A proof-logging PB solver such
as Exact, RoundingSat, or Sat4j should refute `sum x<=1809`, and VeriPB must
then accept the proof. Solver UNSAT without a checked proof, or a timed-out
partial proof, is insufficient.

No compatible proof-producing PB/MaxSAT solver and VeriPB checker are
installed locally, so the certificate attempt could not be executed here.

## 6. Bounded Gurobi experiment

A one-thread root diagnostic on the three-state formulation gave LP upper
bound 669 unassigned variables; cuts reduced the raw bound to 668.69829, which
rounds down to 668 and corresponds to selected-literal lower bound **1332**.
It took 63.8 seconds including shutdown and processed only the root.

Because this was far below 1810, the sole long run was primal-focused and
warm-started at 190 unassigned variables:

```text
Threads=2 TimeLimit=600 MIPFocus=1 Heuristics=0.5
NoRelHeurTime=300 PumpPasses=50 RINS=10 Presolve=2 Cuts=1
```

NoRel and the feasibility pump found no improvement. The run processed one
node and 53,858 simplex iterations in exactly 600 seconds, retained objective
190 / original cost 1810, and ended with upper bound 669 / original lower
bound 1331. The separate root diagnostic's 1332 is therefore the stronger
solver bound. Neither log is an independently checkable integer certificate,
and the large 1332--1810 interval makes additional short generic MIP runs
unattractive.

The exact bytes loaded by both runs are preserved as
`f2000-three-state-run-input.lp` (SHA-256
`2710f0c86aa83440882485236b0bb0a90154c1efd475a68398555efc54b7584a`).
The finalized six-variable-reduced LP is stored separately.

## 7. Provenance and current proof status

The [current MIPLIB page](https://miplib.zib.de/instance_details_f2000.html)
still marks `f2000` open and records the 1810 solution as a Gurobi 9.1 NoRel
result submitted on 2020-11-25.

The [official PB06 archive](https://www.cril.univ-artois.fr/PB06/results/benchinfo.php?idev=1)
identifies the instance as the PB05 submission
`manquinho/primes-dimacs-cnf/normalized-f2000.opb`, category Handmade /
Min-Prime, MD5 `fad56081e554a0467e4020315c4dfc76`; its best-result field is
blank. The [PB05 report](https://www.cril.univ-artois.fr/PB05/resultb/report/report-PB05-JSAT-submission.pdf)
defines the minimum-size prime-implicant family.

Directly traceable runs timed out at roughly 1,800 seconds in
[PB12](https://www.cril.univ-artois.fr/PB12/results/solver.php?idev=67&idsolver=2308)
and [PB16](https://www.cril.univ-artois.fr/PB16/results/solver.php?idev=81&idsolver=2549).
Every listed complete solver also timed out without an answer on the f2000
WCNF in the [2018](https://maxsat-evaluations.github.io/2018/results/complete/unweighted/table-all.html)
and [2019](https://maxsat-evaluations.github.io/2019/results/complete/unweighted/table-all.html)
MaxSAT Evaluations.

`f2000` is absent from the selected-instance tables for the recent PB24,
PB25, and PB26 PBO/certified tracks, so those competitions did not generate a
new certificate for it. [PB26](https://www.cril.univ-artois.fr/PB26/) requires
VeriPB acceptance in its certificate tracks. No primary official source
examined reports optimum 1810 or a matching certified lower bound.

## 8. Reproduction and integrity

```sh
python3 instances/f2000/scripts/preprocess.py \
  instances/f2000/input/f2000.mps.gz \
  instances/f2000/solutions/official-1810.sol.gz \
  <path-to-downloaded-f2000.cnf.Z> \
  --solver-solution instances/f2000/solutions/three-state-600s.sol \
  --out-dir instances/f2000/artifacts
```

Key SHA-256 values:

```text
original DIMACS archive          841f935fe24c49d93b6b8d9e23cb2158179ec7a63deee1ba79be5a70463dc1b0
MIPLIB MPS                       56125eedea2317d23df9715fa39ac86ef7e9bfd572893662dabfac83690567f4
official solution                0b8b2c3cdbf51ae26ce99eb9b0f40f8c00693fa4924ae506a74e559827a44bfd
direct original decision OPB     e32191840d5a19fbcf07582305d2f67c38549766fb6647d33b99eb868f08ee2e
reduced decision OPB             e2a1174b6fe9e7d0610b39e1bcb69ad5d1fce5f75e677142058c984e78ee114d
reduced WCNF                     d7996bbbf7d68c25ec7fd6ca43cb02fb0c06b89bfb49e99ba894997b85912f19
long-run input LP                2710f0c86aa83440882485236b0bb0a90154c1efd475a68398555efc54b7584a
600-second result                040b25548e4561559e500ac643e5e38c95867ea886f52a0019dca453c4067d0e
600-second log                   e507ac3eab73314a633295041fcc34a9a70d403c2d8f59804197b1c999c468c5
root diagnostic log              434a04dc0bc570414826b0a3248201201019abd06061ac17e82c69583cd1fe0b
```

## Final gate

**Unsolved.** Exact source recovery, incumbent validation, objective-safe
preprocessing, local minimality checks, and proof-ready encodings are
complete. The remaining closure obligation is a checkable UNSAT proof for
the original formula with at most 1,809 selected literals. Current competition
history and the weak LP bound indicate that this is a genuine proof-search
problem, not an ordinary SAT or quick MIP presolve task.
