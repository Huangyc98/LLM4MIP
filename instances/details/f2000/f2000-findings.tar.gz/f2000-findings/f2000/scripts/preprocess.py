#!/usr/bin/env python3
"""Exact semantic audit and proof encodings for MIPLIB f2000.

The script verifies the MPS against the original DIMACS instance, validates
the official incumbent exactly, applies only the safe deletion of literals
that occur in no clause, and writes proof-oriented OPB/WCNF encodings plus an
equivalent three-state MILP (positive/negative/unassigned for each SAT
variable).
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import subprocess
import sys
from collections import Counter, deque
from decimal import Decimal
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "common"))
from audit_pb_instances import (
    parse_mps,
    parse_solution,
    sha256,
    validate_solution,
)


def number(name: str) -> int:
    assert name.startswith("x") and name[1:].isdigit(), name
    return int(name[1:])


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def read_dimacs_z(path: Path) -> tuple[int, list[tuple[int, ...]]]:
    completed = subprocess.run(
        ["gzip", "-cd", str(path)], check=True, capture_output=True, text=True
    )
    variables = None
    declared_clauses = None
    clauses: list[tuple[int, ...]] = []
    for raw in completed.stdout.splitlines():
        line = raw.strip()
        if not line or line.startswith("c"):
            continue
        if line.startswith("p "):
            tag, kind, nvars, nclauses = line.split()
            assert tag == "p" and kind == "cnf"
            variables, declared_clauses = int(nvars), int(nclauses)
            continue
        literals = tuple(map(int, line.split()))
        assert literals and literals[-1] == 0
        clauses.append(literals[:-1])
    assert variables is not None and declared_clauses == len(clauses)
    return variables, clauses


def wrapped_sum(prefix: str, names: list[str], suffix: str, width: int = 20) -> str:
    assert names
    chunks = [names[start:start + width] for start in range(0, len(names), width)]
    return prefix + "\n  + ".join(" + ".join(chunk) for chunk in chunks) + suffix


def audit(model: Path, solution: Path, dimacs: Path):
    name, variables, senses, rows, objective, rhs, bounds = parse_mps(model)
    assert name == "f2000"
    assert variables == [f"x{i}" for i in range(1, 4001)]
    assert set(rows) == {f"c{i}" for i in range(10500)}
    assert objective == {variable: Decimal(1) for variable in variables}
    assert all(bounds[variable] == (Decimal(0), Decimal(1)) for variable in variables)

    clauses: list[tuple[str, ...]] = []
    for row_id in range(8500):
        row = f"c{row_id}"
        coefficients = rows[row]
        assert senses[row] == "G" and rhs[row] == 1
        assert len(coefficients) == 3
        assert all(value == 1 for value in coefficients.values())
        clause = tuple(sorted(coefficients, key=number))
        assert len({(number(variable) + 1) // 2 for variable in clause}) == 3
        clauses.append(clause)

    pairs: list[tuple[str, str]] = []
    for pair_id in range(2000):
        row = f"c{8500 + pair_id}"
        positive, negative = f"x{2 * pair_id + 1}", f"x{2 * pair_id + 2}"
        assert senses[row] == "G" and rhs[row] == -1
        assert rows[row] == {positive: Decimal(-1), negative: Decimal(-1)}
        pairs.append((positive, negative))

    dimacs_variables, dimacs_clauses = read_dimacs_z(dimacs)
    assert dimacs_variables == 2000 and len(dimacs_clauses) == 8500
    for row_id, signed_clause in enumerate(dimacs_clauses):
        assert len(signed_clause) == 3 and len({abs(x) for x in signed_clause}) == 3
        translated = {
            f"x{2 * literal - 1}" if literal > 0 else f"x{2 * (-literal)}"
            for literal in signed_clause
        }
        assert translated == set(clauses[row_id]), (row_id, signed_clause)

    clause_support = {variable: set() for variable in variables}
    for row_id, clause in enumerate(clauses):
        for variable in clause:
            clause_support[variable].add(row_id)
    unused = [variable for variable in variables if not clause_support[variable]]
    assert unused == ["x704", "x1317", "x1820", "x3462", "x3757"]

    # An unused positive-cost literal is zero in some optimum. Once its mate
    # is fixed zero, the other literal in that SAT-variable pair is conflict
    # free. Such a literal b safely dominates any literal a whose clause
    # support is contained in b's: replace a by b without creating a mutex
    # conflict. Iterate this objective-preserving rule to a fixed point.
    fixed_zero = set(unused)
    dominance_steps = []
    while True:
        active = [variable for variable in variables if variable not in fixed_zero]
        conflict_free = [
            variable for variable in active
            if (f"x{number(variable) + 1}" if number(variable) % 2
                else f"x{number(variable) - 1}") in fixed_zero
        ]
        witness = None
        for variable in active:
            for dominating in conflict_free:
                if (variable != dominating
                        and clause_support[variable] <= clause_support[dominating]):
                    witness = (variable, dominating)
                    break
            if witness:
                break
        if witness is None:
            break
        variable, dominating = witness
        fixed_zero.add(variable)
        dominance_steps.append({
            "fixed_zero_literal": variable,
            "conflict_free_dominator": dominating,
            "literal_support_rows": sorted(clause_support[variable]),
            "dominator_clause_degree": len(clause_support[dominating]),
        })
    assert dominance_steps == [{
        "fixed_zero_literal": "x2667",
        "conflict_free_dominator": "x3461",
        "literal_support_rows": [3858],
        "dominator_clause_degree": 9,
    }]

    retained = [variable for variable in variables if variable not in fixed_zero]
    retained_set = set(retained)
    assert all(clause_support[variable] for variable in retained)
    assert len({frozenset(clause_support[v]) for v in retained}) == len(retained)
    retained_pairs = [
        (positive, negative)
        for positive, negative in pairs
        if positive in retained_set and negative in retained_set
    ]
    assert len(retained_pairs) == 1994
    reduced_clauses = [
        tuple(variable for variable in clause if variable in retained_set)
        for clause in clauses
    ]
    assert Counter(map(len, reduced_clauses)) == Counter({3: 8499, 2: 1})
    reduced_signatures = [frozenset(clause) for clause in reduced_clauses]
    assert len(set(reduced_signatures)) == len(reduced_signatures)
    assert not any(
        left < right
        for row, left in enumerate(reduced_signatures)
        for other, right in enumerate(reduced_signatures)
        if row != other
    )

    clause_signatures = Counter(frozenset(clause) for clause in clauses)
    assert all(count == 1 for count in clause_signatures.values())
    # Since every clause has cardinality three, distinct clauses cannot strictly
    # subsume one another.
    duplicate_or_subsumed_clauses = len(clauses) - len(clause_signatures)
    assert duplicate_or_subsumed_clauses == 0

    # Count tempting set-cover column inclusions. They are deliberately NOT
    # reductions here: another pair's complement can already be selected.
    # Keep the numeric order deterministic so that the stored counterexample
    # witness is reproducible across Python hash seeds.
    clause_members = clauses
    naive_dominated: list[tuple[str, str]] = []
    for variable in variables:
        support = clause_support[variable]
        if not support:
            continue
        witness_row = min(support)
        for other in clause_members[witness_row]:
            if other != variable and support < clause_support[other]:
                naive_dominated.append((variable, other))
                break
    assert len(naive_dominated) == 58

    claimed, sparse = parse_solution(solution)
    values = {variable: sparse.get(variable, Decimal(0)) for variable in variables}
    solution_audit = validate_solution(
        variables, senses, rows, objective, rhs, bounds, solution
    )
    assert claimed == 1810 and all(values[variable] == 0 for variable in fixed_zero)
    selected_pairs = sum(values[a] + values[b] == 1 for a, b in pairs)
    unassigned_pairs = sum(values[a] + values[b] == 0 for a, b in pairs)
    assert selected_pairs == 1810 and unassigned_pairs == 190
    clause_activity = Counter(
        sum((values[variable] for variable in clause), Decimal(0))
        for clause in clauses
    )
    assert clause_activity == Counter({Decimal(1): 4620, Decimal(2): 3050, Decimal(3): 830})

    # Local minimality diagnostics for the incumbent. Every selected literal
    # has a clause that it alone covers, and no pair of selected literals can
    # be replaced by one compatible unselected literal.
    selected = [variable for variable in variables if values[variable] == 1]
    selected_by_clause = [
        tuple(variable for variable in clause if values[variable] == 1)
        for clause in clauses
    ]
    unique_masks = {variable: 0 for variable in selected}
    double_masks: dict[frozenset[str], int] = {}
    support_masks = {
        variable: sum(1 << row for row in support)
        for variable, support in clause_support.items()
    }
    for row, members in enumerate(selected_by_clause):
        if len(members) == 1:
            unique_masks[members[0]] |= 1 << row
        elif len(members) == 2:
            key = frozenset(members)
            double_masks[key] = double_masks.get(key, 0) | (1 << row)
    unique_witness_counts = Counter(
        bin(mask).count("1") for mask in unique_masks.values()
    )
    assert unique_witness_counts == Counter({
        1: 389, 2: 620, 3: 427, 4: 229, 5: 99,
        6: 30, 7: 11, 8: 3, 9: 2,
    })
    two_for_one_checked = 0
    improving_exchange = None
    for left_index, left in enumerate(selected):
        for right in selected[left_index + 1:]:
            two_for_one_checked += 1
            uncovered = (
                unique_masks[left] | unique_masks[right]
                | double_masks.get(frozenset((left, right)), 0)
            )
            assert uncovered
            witness_row = (uncovered & -uncovered).bit_length() - 1
            for replacement in clauses[witness_row]:
                if values[replacement] != 0:
                    continue
                mate = (
                    f"x{number(replacement) + 1}" if number(replacement) % 2
                    else f"x{number(replacement) - 1}"
                )
                if values[mate] == 1 and mate not in (left, right):
                    continue
                if uncovered & ~support_masks[replacement] == 0:
                    improving_exchange = (left, right, replacement)
                    break
            if improving_exchange:
                break
        if improving_exchange:
            break
    assert two_for_one_checked == 1637145 and improving_exchange is None

    # Concrete evidence that naive set-cover dominance has no valid direct
    # replacement argument in the presence of complement-pair conflicts.
    unsafe_witness = None
    for variable, dominating in naive_dominated:
        mate = f"x{number(dominating) + 1}" if number(dominating) % 2 else f"x{number(dominating) - 1}"
        if values[variable] == 1 and values[mate] == 1:
            unsafe_witness = {
                "literal": variable,
                "literal_clause_degree": len(clause_support[variable]),
                "apparent_dominator": dominating,
                "dominator_clause_degree": len(clause_support[dominating]),
                "selected_conflicting_complement": mate,
            }
            break
    assert unsafe_witness == {
        "literal": "x311",
        "literal_clause_degree": 1,
        "apparent_dominator": "x1227",
        "dominator_clause_degree": 8,
        "selected_conflicting_complement": "x1228",
    }

    # Connected components in the retained literal graph, including both
    # clause co-occurrence edges and complement-pair edges.
    adjacency = {variable: set() for variable in retained}
    for clause in reduced_clauses:
        for variable in clause:
            adjacency[variable].update(set(clause) - {variable})
    for positive, negative in retained_pairs:
        adjacency[positive].add(negative)
        adjacency[negative].add(positive)
    unseen = set(retained)
    components = []
    while unseen:
        start = min(unseen, key=number)
        queue = deque([start])
        unseen.remove(start)
        component = []
        while queue:
            variable = queue.popleft()
            component.append(variable)
            for neighbor in adjacency[variable]:
                if neighbor in unseen:
                    unseen.remove(neighbor)
                    queue.append(neighbor)
        components.append(component)
    assert list(map(len, components)) == [3994]

    summary = {
        "instance": "f2000",
        "model_sha256": sha256(model),
        "solution_sha256": sha256(solution),
        "original_dimacs_sha256": sha256(dimacs),
        "original": {
            "sat_variables": 2000,
            "literal_variables": 4000,
            "three_literal_clauses": 8500,
            "complement_at_most_one_rows": 2000,
            "rows": 10500,
            "nonzeros": 29500,
        },
        "dimacs_to_mps_exact_row_match": True,
        "positive_literal_rule": "DIMACS +i maps to x(2*i-1)",
        "negative_literal_rule": "DIMACS -i maps to x(2*i)",
        "duplicate_or_subsumed_clause_rows": duplicate_or_subsumed_clauses,
        "tautological_or_repeated_variable_clauses": 0,
        "literal_clause_degree_histogram": dict(sorted(Counter(
            len(clause_support[variable]) for variable in variables
        ).items())),
        "safe_preprocessing": {
            "fixed_zero_unused_literals": unused,
            "conflict_free_literal_dominance_steps": dominance_steps,
            "all_fixed_zero_literals": sorted(fixed_zero, key=number),
            "removed_tautological_pair_rows": len(fixed_zero),
            "retained_literal_variables": len(retained),
            "retained_rows": len(clauses) + len(retained_pairs),
            "retained_nonzeros": sum(map(len, reduced_clauses)) + 2 * len(retained_pairs),
            "retained_clause_degree_histogram": dict(sorted(Counter(
                map(len, reduced_clauses)
            ).items())),
            "connected_components": [len(component) for component in components],
            "remaining_singleton_clauses": 0,
            "remaining_duplicate_literal_supports": 0,
        },
        "unsafe_naive_set_cover_dominance": {
            "literals_with_a_strict_clause_support_superset": len(naive_dominated),
            "direct_replacement_failure_in_incumbent": unsafe_witness,
        },
        "official_incumbent": {
            **solution_audit,
            "selected_literal_pairs": selected_pairs,
            "unassigned_sat_variables": unassigned_pairs,
            "selected_positive_literals": sum(
                values[f"x{2 * pair_id - 1}"] == 1
                for pair_id in range(1, 2001)
            ),
            "selected_negative_literals": sum(
                values[f"x{2 * pair_id}"] == 1
                for pair_id in range(1, 2001)
            ),
            "clause_activity_histogram": {
                str(key): value for key, value in sorted(clause_activity.items())
            },
            "unique_clause_witnesses_per_selected_literal": dict(sorted(
                unique_witness_counts.items()
            )),
            "two_for_one_selected_pairs_checked": two_for_one_checked,
            "two_for_one_improving_exchange": improving_exchange,
        },
    }
    data = {
        "variables": variables,
        "clauses": clauses,
        "reduced_clauses": reduced_clauses,
        "pairs": pairs,
        "retained": retained,
        "retained_pairs": retained_pairs,
        "clause_support": clause_support,
        "values": values,
        "dimacs_clauses": dimacs_clauses,
    }
    return summary, data


def write_artifacts(out_dir: Path, summary, data) -> dict[str, str]:
    out_dir.mkdir(parents=True, exist_ok=True)
    retained = data["retained"]
    retained_id = {variable: index for index, variable in enumerate(retained, start=1)}
    clauses = data["clauses"]
    pairs = data["pairs"]
    retained_pairs = data["retained_pairs"]
    values = data["values"]

    mapping_path = out_dir / "f2000-literal-pairs.tsv"
    fixed_zero = set(summary["safe_preprocessing"]["all_fixed_zero_literals"])
    with mapping_path.open("w", encoding="ascii", newline="") as stream:
        writer = csv.writer(stream, delimiter="\t", lineterminator="\n")
        writer.writerow([
            "sat_variable", "positive_literal", "negative_literal",
            "positive_clause_degree", "negative_clause_degree",
            "positive_reduced_variable", "negative_reduced_variable",
            "incumbent_state",
        ])
        for pair_id, (positive, negative) in enumerate(pairs, start=1):
            state = (
                "positive" if values[positive] == 1 else
                "negative" if values[negative] == 1 else "unassigned"
            )
            writer.writerow([
                pair_id, positive, negative,
                len(data["clause_support"][positive]),
                len(data["clause_support"][negative]),
                "" if positive in fixed_zero else f"y{retained_id[positive]}",
                "" if negative in fixed_zero else f"y{retained_id[negative]}",
                state,
            ])

    def opb_cover_lines(original: bool) -> str:
        result = []
        use_clauses = clauses if original else data["reduced_clauses"]
        for clause in use_clauses:
            names = list(clause) if original else [f"y{retained_id[v]}" for v in clause]
            result.append(" ".join(f"+1 {v}" for v in names) + " >= 1 ;\n")
        use_pairs = pairs if original else retained_pairs
        for positive, negative in use_pairs:
            names = (positive, negative) if original else (
                f"y{retained_id[positive]}", f"y{retained_id[negative]}"
            )
            result.append(f"-1 {names[0]} -1 {names[1]} >= -1 ;\n")
        return "".join(result)

    reduced_names = [f"y{i}" for i in range(1, len(retained) + 1)]
    reduced_opb = out_dir / "f2000-reduced.opb"
    reduced_opb.write_text(
        f"* #variable= {len(retained)} #constraint= 10494\n"
        + "min: " + " ".join(f"+1 {name}" for name in reduced_names) + " ;\n"
        + opb_cover_lines(original=False),
        encoding="ascii",
    )
    reduced_decision = out_dir / "f2000-reduced-lb1810.opb"
    reduced_decision.write_text(
        f"* #variable= {len(retained)} #constraint= 10495\n"
        "* UNSAT proves lower bound 1810 for MIPLIB f2000.\n"
        + opb_cover_lines(original=False)
        + " ".join(f"-1 {name}" for name in reduced_names) + " >= -1809 ;\n",
        encoding="ascii",
    )
    original_decision = out_dir / "f2000-original-lb1810.opb"
    original_names = [f"x{i}" for i in range(1, 4001)]
    original_decision.write_text(
        "* #variable= 4000 #constraint= 10501\n"
        "* Direct MPS translation: UNSAT proves lower bound 1810.\n"
        + opb_cover_lines(original=True)
        + " ".join(f"-1 {name}" for name in original_names) + " >= -1809 ;\n",
        encoding="ascii",
    )

    wcnf_path = out_dir / "f2000-reduced.wcnf"
    top = len(retained) + 1
    wcnf_lines = [
        f"p wcnf {len(retained)} {len(data['reduced_clauses']) + len(retained_pairs) + len(retained)} {top}\n"
    ]
    wcnf_lines.extend(
        f"{top} " + " ".join(str(retained_id[v]) for v in clause) + " 0\n"
        for clause in data["reduced_clauses"]
    )
    wcnf_lines.extend(
        f"{top} -{retained_id[a]} -{retained_id[b]} 0\n"
        for a, b in retained_pairs
    )
    wcnf_lines.extend(
        f"1 -{index} 0\n" for index in range(1, len(retained) + 1)
    )
    wcnf_path.write_text("".join(wcnf_lines), encoding="ascii")

    # Equivalent formulation: exactly one of positive, negative, unassigned
    # for each original SAT variable; maximize the 2000 unassigned indicators.
    def three_state_text(active_literals, cover_clauses) -> str:
        active_set = set(active_literals)
        lines = [
            "Maximize\n",
            wrapped_sum(" obj: ", [f"u{i}" for i in range(1, 2001)], "\n"),
            "Subject To\n",
        ]
        for row_id, clause in enumerate(cover_clauses):
            lines.append(wrapped_sum(f" c{row_id}: ", list(clause), " >= 1\n"))
        for pair_id, (positive, negative) in enumerate(pairs, start=1):
            names = [v for v in (positive, negative) if v in active_set] + [f"u{pair_id}"]
            lines.append(wrapped_sum(f" pair{pair_id}: ", names, " = 1\n"))
        binary_names = list(active_literals) + [f"u{i}" for i in range(1, 2001)]
        lines.append("Binary\n")
        for start in range(0, len(binary_names), 20):
            lines.append(" " + " ".join(binary_names[start:start + 20]) + "\n")
        lines.append("End\n")
        return "".join(lines)

    three_state_path = out_dir / "f2000-three-state.lp"
    three_state_path.write_text(
        three_state_text(retained, data["reduced_clauses"]), encoding="ascii"
    )
    # The bounded Gurobi runs were launched after only the five zero-support
    # deletions. Preserve that exact deterministic input as well; Gurobi's own
    # presolve then discovers the sixth x2667 reduction.
    initial_fixed = set(summary["safe_preprocessing"]["fixed_zero_unused_literals"])
    initial_retained = [v for v in data["variables"] if v not in initial_fixed]
    run_input_path = out_dir / "f2000-three-state-run-input.lp"
    run_input_path.write_text(
        three_state_text(initial_retained, clauses), encoding="ascii"
    )

    start_path = out_dir / "f2000-three-state-190.sol"
    selected = [variable for variable in retained if values[variable] == 1]
    unassigned = [
        f"u{pair_id}" for pair_id, (a, b) in enumerate(pairs, start=1)
        if values[a] == 0 and values[b] == 0
    ]
    assert len(selected) == 1810 and len(unassigned) == 190
    start_path.write_text(
        "=obj= 190\n"
        + "".join(f"{variable} 1\n" for variable in selected + unassigned),
        encoding="ascii",
    )

    summary_path = out_dir / "f2000-preprocess-summary.json"
    paths = [
        mapping_path, reduced_opb, reduced_decision, original_decision,
        wcnf_path, three_state_path, run_input_path, start_path,
    ]
    hashes = {path.name: file_sha256(path) for path in paths}
    summary["generated_sha256"] = hashes
    summary_path.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    return hashes


def validate_three_state_solution(path: Path, data) -> dict:
    values = {}
    claimed = None
    for raw in path.read_text(encoding="ascii").splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("# Objective value ="):
            claimed = Decimal(line.split("=", 1)[1])
        elif not line.startswith("#"):
            variable, value = line.split()
            assert variable not in values
            values[variable] = Decimal(value)
    assert claimed == 190
    x_values = {
        variable: values.get(variable, Decimal(0))
        for variable in data["variables"]
    }
    u_values = [values.get(f"u{i}", Decimal(0)) for i in range(1, 2001)]
    assert all(value in (0, 1) for value in x_values.values())
    assert all(value in (0, 1) for value in u_values)
    assert sum(u_values) == claimed
    assert sum(x_values.values()) == 1810
    assert all(
        sum(x_values[variable] for variable in clause) >= 1
        for clause in data["clauses"]
    )
    assert all(
        x_values[positive] + x_values[negative] + u_values[pair_id] == 1
        for pair_id, (positive, negative) in enumerate(data["pairs"])
    )
    difference = sum(
        x_values[variable] != data["values"][variable]
        for variable in data["variables"]
    )
    assert difference == 0
    return {
        "sha256": file_sha256(path),
        "max_unassigned_objective": int(claimed),
        "selected_literal_objective": int(sum(x_values.values())),
        "pair_equalities_satisfied": 2000,
        "covered_clauses": 8500,
        "x_vector_differences_from_official_incumbent": difference,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("dimacs", type=Path)
    parser.add_argument("--out-dir", type=Path)
    parser.add_argument("--solver-solution", type=Path)
    args = parser.parse_args()
    summary, data = audit(args.model, args.solution, args.dimacs)
    if args.solver_solution:
        summary["bounded_run_solution_validation"] = validate_three_state_solution(
            args.solver_solution, data
        )
    if args.out_dir:
        write_artifacts(args.out_dir, summary, data)
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
