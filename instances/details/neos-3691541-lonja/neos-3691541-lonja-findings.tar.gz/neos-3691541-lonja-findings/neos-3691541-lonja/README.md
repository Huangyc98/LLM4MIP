# neos-3691541-lonja：精确子集结构与严格可行解

## 当前结论

截至 2026-09-08，[MIPLIB 实例页](https://miplib.zib.de/instance_details_neos-3691541-lonja.html)
仍将本实例标为 `open`，页面 headline 为带星号的容差解
`-0.00744145058*`。

本目录得到的最好零容差严格可行解为：

```text
0.0918239856 = 57389991 / 625000000
```

解在 [`solutions/lonja-0.0918239856-strict.sol`](solutions/lonja-0.0918239856-strict.sol)。
精确投影求解器的内部 Fraction 重放、第二套独立重解析和仓库公共 checker 均确认：
10,300 个变量的界、10,200 个整数变量及 10,320 条原始 MPS 约束零违约，最大精确行违约为零。
证据见
[`analysis/cpsat-seed79-independent-validation.json`](analysis/cpsat-seed79-independent-validation.json)
与
[`solutions/lonja-0.0918239856-strict.validation.log`](solutions/lonja-0.0918239856-strict.validation.log)。

这是严格可行上界，但比 MIPLIB headline 差 `0.09926543618`，所以**没有改善 MIPLIB
的数值上界**。本目录也没有全局最优性证明或严格全局下界。

## 背景与 Gurobi 只读结构

MIPLIB 将它归入 `neos-pseudoapplication-13`，没有提供 bibliography。与其猜测未知
业务来源，本研究直接从原始系数恢复模型。

原始 MPS 先在 `euler4` 上由 Gurobi 13.0.1 只读加载，未调用 `presolve()` 或
`optimize()`。记录见
[`analysis/gurobi-13.0.1-structure.json`](analysis/gurobi-13.0.1-structure.json)
和 [`logs/gurobi-13.0.1-structure.log`](logs/gurobi-13.0.1-structure.log)。

| 属性 | 数值 |
|---|---:|
| 变量 | 10,300 |
| 约束 | 10,320 |
| 非零元 | 40,568 |
| 二元变量 | 10,200 |
| 自由连续变量 | 100 |
| 目标非零列 | 10,000 |
| 目标方向 | 最小化 |

原始 MPS SHA-256 为
`25a0730056fd49caac2d95064aeebb7627e889ec9c1e25165eac94e59d6f5f5c`；
MPS、DEC 与 official revision 2 保存于 [`input/`](input/) 中。

## 从系数恢复的精确模型

[`analysis/exact-master-structure.json`](analysis/exact-master-structure.json) 记录了完整
块结构。模型由 100 个 item、100 个 group 构成：

- `10,000 = 100 × 100` 个 assignment 二元变量 `x[i,j]`；
- 每个 item 恰分配到一个 group，且 `x[i,j] <= y[j]`；
- 100 个 group 激活变量 `y[j]`，满足 `sum(y) <= 15`，另有 3 条 `y` 侧约束；
- 100 个自由连续量 `c[j]` 被等式唯一确定为加权 assignment 和，因此可精确消去；
- 100 个放松变量 `z[j]` 控制 `c[j]` 对目标值的上下偏差，且 `sum(z) <= 6`；
- 只有 15 个 group 具有正目标值，其余 85 个为零目标组。

所以至少 9 个正目标组必须满足精确 subset-sum。该结构不是 100×100 permutation
模型；group 可接收多个 item。精确 subset 审计见
[`analysis/exact-subset-audit.json`](analysis/exact-subset-audit.json)：15 个正目标中有
14 个单独可达，group 75 单独不可达。

## 官方解严格审计

official revision 2 的字面目标为 `-0.00744145058`，整数性与变量界通过，但原始
MPS 有 73 条精确行违约，最大值为 `9.3153731313792e-6`。完整记录见
[`analysis/official-2-strict-validation.json`](analysis/official-2-strict-validation.json)
和 [`logs/official-2-common-checker.log`](logs/official-2-common-checker.log)。

仅精确回填 100 个连续变量仍留下 9 条行违约，最大值
`1747/125000000 = 0.000013976`；见
[`analysis/official-2-singleton-exactify.json`](analysis/official-2-singleton-exactify.json)。
因此不能把页面 headline 当作零容差严格解。

## 关键求解实验

### bitset witness 与 catalogue master

对 100 个 item 权重使用 Python 整数 bitset 做精确 subset-sum，多组随机 item 顺序
共产生 1,288 个 witness，覆盖 14 个可达正目标组。候选集合上的 set-packing 找到
10 个两两不相交 witness；汇总见
[`analysis/bitset-witness-catalogue-merged.json`](analysis/bitset-witness-catalogue-merged.json)，
各 shard 在 [`experiments/bitset-witnesses/`](experiments/bitset-witnesses/) 中。

先选择 9 个 exact group 并把其余 item 放入 6 个 relaxed group，得到严格点
`0.10642427138`。随后在 1,288 个 witness 与 1,500 个 relaxed-assignment 变量上
求目标 master，74.12 秒内以 CP-SAT `OPTIMAL` 得到严格点 `0.1046509635`。
这里的 `OPTIMAL` **只针对有限 witness catalogue master**，不是原 MPS 全局最优。
结果见 [`experiments/catalogue-objective/result.json`](experiments/catalogue-objective/result.json)。

### 全投影 CP-SAT

100 个连续变量由其定义等式精确消去，所有十进制系数整数化；以 catalogue 严格点
对全部 10,200 个二元变量显式 hint（包括缺失即零的变量），各跑 600 秒、12 线程：

| seed | 状态 | 严格 incumbent | 数值投影 bound | 结论 |
|---:|---|---:|---:|---|
| 73 | `FEASIBLE` | `0.1036652288` | `-0.0179290875427` | 超时，严格通过 |
| 79 | `FEASIBLE` | `0.0918239856` | `-0.0158844787159` | 超时，严格通过；当前最好 |

结果与日志在 `experiments/cpsat-completehint-seed*/` 和
`logs/cpsat-completehint-seed*/`；两份中间解也保存在 [`solutions/`](solutions/)。
这些 bound 是求解器在整数化投影模型上的数值输出，没有被转换为可移植证明文件。

### 阴性实验

- 稀疏 official hint 的全投影 CP-SAT：1,200 秒，`UNKNOWN`，无 incumbent；
- 仅保留 15 个正目标组的对称性缩减 CP-SAT：600 秒，`UNKNOWN`，无 incumbent；
- 从 `0.1046509635` 做全模型 COPT warm start：600 秒、5,366 节点，无改善，
  浮点 bound `-0.029989431010705035`；
- 原空间 10,200 二元变量 Hamming 半径 40：600 秒、16,569 节点，无改善，
  受限邻域浮点 bound `0.044313566906055`。

对应结果在
[`experiments/cpsat-seed17-no-incumbent/`](experiments/cpsat-seed17-no-incumbent/)、
[`experiments/positive15-no-incumbent/`](experiments/positive15-no-incumbent/)、
[`experiments/full-warm-copt8/`](experiments/full-warm-copt8/) 和
[`experiments/hamming40-copt8/`](experiments/hamming40-copt8/)。

## 证据边界

- `0.0918239856` 是原始 MPS 上的严格可行上界，不是 MIPLIB headline 改善。
- CP-SAT `FEASIBLE` 与 COPT status 8 均表示时限终止，不能解释为最优。
- catalogue `OPTIMAL` 只闭合已生成的 1,288-witness 有限主问题。
- Hamming bound 只属于受限邻域；其他 solver bound 也只是浮点数值。
- 本目录没有 DRAT、VIPR 或其他可移植全局 lower-bound/optimality certificate。
- 因而实例仍应标为 `open`，不得写成 `optimal`。

## 复现

从仓库根目录验证最终解与 official 解：

```bash
python common/exact_mps_solution_check.py \
  instances/neos-3691541-lonja/input/neos-3691541-lonja.mps.gz \
  instances/neos-3691541-lonja/solutions/lonja-0.0918239856-strict.sol \
  --tolerance 0

python common/exact_mps_solution_check.py \
  instances/neos-3691541-lonja/input/neos-3691541-lonja.mps.gz \
  instances/neos-3691541-lonja/input/neos-3691541-lonja-official-2.sol.gz \
  --tolerance 0
```

OR-Tools 环境下可重放 witness 合并与完整 hint 搜索：

```bash
python instances/neos-3691541-lonja/experiments/merge_witness_catalogue.py \
  --glob 'instances/neos-3691541-lonja/experiments/bitset-witnesses/seed-*.json' \
  --audit instances/neos-3691541-lonja/analysis/exact-subset-audit.json \
  --output /tmp/lonja-witness-merged.json --seconds 120 --workers 8

python instances/neos-3691541-lonja/experiments/solve_lonja_exact_cpsat_completehint.py \
  --model instances/neos-3691541-lonja/input/neos-3691541-lonja.mps.gz \
  --hint instances/neos-3691541-lonja/solutions/lonja-0.1046509635-catalogue-strict.sol \
  --complete-hint --output-dir /tmp/lonja-seed79 \
  --time-limit 600 --threads 12 --seed 79
```

哈希检查：

```bash
(cd instances/neos-3691541-lonja && sha256sum -c SHA256SUMS)
```

`SHA256SUMS` 覆盖本目录除清单自身以外的全部归档文件。
