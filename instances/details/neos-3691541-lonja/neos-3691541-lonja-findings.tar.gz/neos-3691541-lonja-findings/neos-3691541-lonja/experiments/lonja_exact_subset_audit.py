#!/usr/bin/env python3
"""Exact structural/subset-sum audit for neos-3691541-lonja.

The original MPS has 100 item-assignment rows and 100 column blocks.  Each
column's continuous variable is an exact weighted sum of assigned items.  A
binary slack relaxes an equality to a positive target.  This script proves
which target equalities are individually attainable by exact subset sums.
"""

from __future__ import annotations

import argparse
import collections
import gzip
import hashlib
import json
import math
from fractions import Fraction
from pathlib import Path

from helper_route_logic import parse


def sol_lines(path: Path) -> list[str]:
    if path.suffix == ".gz":
        with gzip.open(path, "rt", encoding="ascii") as stream:
            return stream.read().splitlines()
    return path.read_text(encoding="ascii").splitlines()


def solution(path: Path) -> dict[str, Fraction]:
    values: dict[str, Fraction] = {}
    for raw in sol_lines(path):
        fields = raw.split()
        if len(fields) == 2 and not fields[0].startswith(("#", "=obj=")):
            values[fields[0]] = Fraction(fields[1])
    return values


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--model", type=Path, required=True)
    ap.add_argument("--solution", type=Path, required=True)
    ap.add_argument("--output", type=Path, required=True)
    args = ap.parse_args()
    senses, row_order, variables, columns, rows, rhs, lb, ub, integer = parse(args.model)
    values = solution(args.solution)

    name = lambda index: f"C{index:04d}"
    x = [[name(100 * i + j) for j in range(1, 101)] for i in range(1, 101)]
    c = [name(j) for j in range(1, 101)]
    y = [name(10100 + j) for j in range(1, 101)]
    z = [name(10200 + j) for j in range(1, 101)]
    expected = set(sum(x, [])) | set(c) | set(y) | set(z)
    assert expected == set(variables), (len(expected), len(variables), list(set(variables) - expected)[:10])

    weights: list[Fraction] | None = None
    targets: list[Fraction] = []
    target_rows = []
    block_details = []
    for j in range(100):
        equality_rows = [
            row for row in row_order
            if senses[row] == "E" and any(v == c[j] for v, _ in rows[row])
        ]
        assert len(equality_rows) == 1
        erow = equality_rows[0]
        coefficients = dict(rows[erow])
        assert coefficients[c[j]] == 1
        block_weights = [-coefficients[x[i][j]] for i in range(100)]
        if weights is None:
            weights = block_weights
        else:
            assert block_weights == weights
        side_rows = []
        for row in row_order:
            terms = dict(rows[row])
            if c[j] in terms and row != erow:
                side_rows.append((row, terms, rhs.get(row, Fraction(0))))
        upper = [r for r in side_rows if r[1].get(c[j]) == 1 and r[1].get(z[j]) == -1]
        lower_side = [r for r in side_rows if r[1].get(c[j]) == -1 and r[1].get(z[j]) == -1]
        assert len(upper) == 1 and len(lower_side) in (0, 1)
        target = upper[0][2]
        assert not lower_side or lower_side[0][2] == -target
        assert (target == 0) == (len(lower_side) == 0)
        targets.append(target)
        target_rows.append([upper[0][0], *(r[0] for r in lower_side)])

        chosen = [i + 1 for i in range(100) if values.get(x[i][j], Fraction(0)) > Fraction(1, 2)]
        exact_sum = sum((weights[i - 1] for i in chosen), Fraction(0))
        block_details.append({
            "block": j + 1,
            "target": str(target),
            "target_rows": target_rows[-1],
            "official_y": str(values.get(y[j], Fraction(0))),
            "official_z": str(values.get(z[j], Fraction(0))),
            "official_items": chosen,
            "official_exact_weight": str(exact_sum),
            "official_exact_deviation": str(exact_sum - target),
        })

    assert weights is not None
    denominators = [v.denominator for v in weights + targets]
    scale = math.lcm(*denominators)
    integer_weights = [int(v * scale) for v in weights]
    integer_targets = [int(v * scale) for v in targets]
    reduction_gcd = math.gcd(*integer_weights, *integer_targets)
    integer_weights = [v // reduction_gcd for v in integer_weights]
    integer_targets = [v // reduction_gcd for v in integer_targets]
    positive_targets = sorted(set(v for v in integer_targets if v > 0))
    maximum_target = max(positive_targets)
    mask = (1 << (maximum_target + 1)) - 1
    reachable = 1
    for weight in integer_weights:
        reachable = (reachable | (reachable << weight)) & mask

    target_attainable = []
    for j, target in enumerate(integer_targets):
        attainable = bool((reachable >> target) & 1)
        block_details[j]["individual_exact_subset_sum_attainable"] = attainable
        target_attainable.append(attainable)

    positive_ids = [j for j, target in enumerate(integer_targets) if target > 0]
    attainable_positive_ids = [j + 1 for j in positive_ids if target_attainable[j]]
    unattainable_positive_ids = [j + 1 for j in positive_ids if not target_attainable[j]]
    result = {
        "schema": "lonja-exact-subset-audit-v1",
        "model_sha256": sha(args.model),
        "solution_sha256": sha(args.solution),
        "items": 100,
        "blocks": 100,
        "positive_target_blocks": len(positive_ids),
        "zero_target_blocks": 100 - len(positive_ids),
        "integer_scale_lcm": scale,
        "integer_gcd_reduction": reduction_gcd,
        "reduced_maximum_target": maximum_target,
        "positive_targets_individually_attainable": len(attainable_positive_ids),
        "positive_target_blocks_attainable": attainable_positive_ids,
        "positive_target_blocks_unattainable": unattainable_positive_ids,
        "strict_infeasibility_implication": (
            "If fewer than 9 positive targets are individually attainable, then sum(z)<=6 "
            "cannot relax enough of the 15 positive-target equalities."
        ),
        "strict_infeasibility_proved_by_individual_subsets": len(attainable_positive_ids) < 9,
        "official_active_y_count": sum(values.get(v, Fraction(0)) > Fraction(1, 2) for v in y),
        "official_active_z_count": sum(values.get(v, Fraction(0)) > Fraction(1, 2) for v in z),
        "weight_fractions": [str(v) for v in weights],
        "target_fractions": [str(v) for v in targets],
        "blocks_detail": block_details,
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: result[key] for key in (
        "positive_target_blocks", "positive_targets_individually_attainable",
        "positive_target_blocks_attainable", "positive_target_blocks_unattainable",
        "strict_infeasibility_proved_by_individual_subsets",
        "official_active_y_count", "official_active_z_count",
        "integer_scale_lcm", "integer_gcd_reduction", "reduced_maximum_target",
    )}, indent=2))


if __name__ == "__main__":
    main()
