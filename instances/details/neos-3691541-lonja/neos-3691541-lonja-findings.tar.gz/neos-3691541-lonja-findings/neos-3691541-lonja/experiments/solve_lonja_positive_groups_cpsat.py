#!/usr/bin/env python3
"""Exact feasibility model for lonja restricted to its 15 positive-target groups."""

from __future__ import annotations

import argparse
import collections
import gzip
import hashlib
import json
import math
import time
from fractions import Fraction
from pathlib import Path

from ortools.sat.python import cp_model

from helper_route_logic import parse


def var_name(index: int) -> str:
    return f"C{index:04d}"


def read_solution(path: Path) -> dict[str, Fraction]:
    opener = gzip.open if path.suffix == ".gz" else open
    answer: dict[str, Fraction] = {}
    with opener(path, "rt", encoding="ascii") as stream:
        for raw in stream:
            fields = raw.split()
            if len(fields) == 2 and not fields[0].startswith(("#", "=")):
                answer[fields[0]] = Fraction(fields[1])
    return answer


def terminating(value: Fraction) -> str:
    if value == 0:
        return "0"
    sign = "-" if value < 0 else ""
    numerator, denominator = abs(value.numerator), value.denominator
    twos = fives = 0
    while denominator % 2 == 0:
        denominator //= 2
        twos += 1
    while denominator % 5 == 0:
        denominator //= 5
        fives += 1
    if denominator != 1:
        raise ValueError(value)
    places = max(twos, fives)
    scaled = numerator * 2 ** (places - twos) * 5 ** (places - fives)
    digits = str(scaled).rjust(places + 1, "0")
    if places == 0:
        return sign + digits
    return (sign + digits[:-places] + "." + digits[-places:]).rstrip("0").rstrip(".")


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--model", type=Path, required=True)
    ap.add_argument("--hint", type=Path)
    ap.add_argument("--output-dir", type=Path, required=True)
    ap.add_argument("--time-limit", type=float, default=600)
    ap.add_argument("--threads", type=int, default=12)
    ap.add_argument("--seed", type=int, default=29)
    args = ap.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    senses, row_order, variables, columns, rows, rhs, lb, ub, integer = parse(args.model)
    x_names = [[var_name(100 * i + j) for j in range(1, 101)] for i in range(1, 101)]
    c_names = [var_name(j) for j in range(1, 101)]
    y_names = [var_name(10100 + j) for j in range(1, 101)]
    z_names = [var_name(10200 + j) for j in range(1, 101)]
    assert set(sum(x_names, [])) | set(c_names) | set(y_names) | set(z_names) == set(variables)

    weights: list[Fraction] | None = None
    targets: list[Fraction] = []
    for j in range(100):
        erows = [
            row for row in row_order
            if senses[row] == "E" and any(variable == c_names[j] for variable, _ in rows[row])
        ]
        assert len(erows) == 1
        terms = dict(rows[erows[0]])
        candidate = [-terms[x_names[i][j]] / terms[c_names[j]] for i in range(100)]
        if weights is None:
            weights = candidate
        else:
            assert candidate == weights
        upper_rows = []
        for row in row_order:
            terms = dict(rows[row])
            if terms.get(c_names[j]) == 1 and terms.get(z_names[j]) == -1:
                upper_rows.append(row)
        assert len(upper_rows) == 1
        targets.append(rhs.get(upper_rows[0], Fraction(0)))
    assert weights is not None
    positive = [j for j, target in enumerate(targets) if target > 0]
    assert len(positive) == 15

    scale = math.lcm(*(value.denominator for value in weights + targets))
    iweights = [int(value * scale) for value in weights]
    itargets = [int(value * scale) for value in targets]
    model = cp_model.CpModel()
    xx = {(i, j): model.new_bool_var(f"x_{i + 1}_{j + 1}") for i in range(100) for j in positive}
    zz = {j: model.new_bool_var(f"z_{j + 1}") for j in positive}
    for i in range(100):
        model.add(sum(xx[i, j] for j in positive) == 1)
    for j in positive:
        load = sum(iweights[i] * xx[i, j] for i in range(100))
        model.add(load - scale * zz[j] <= itargets[j])
        model.add(-load - scale * zz[j] <= -itargets[j])
    model.add(sum(zz.values()) <= 6)

    hint = read_solution(args.hint) if args.hint else {}
    hint_count = 0
    for i in range(100):
        for j in positive:
            if x_names[i][j] in hint:
                model.add_hint(xx[i, j], int(hint[x_names[i][j]] >= Fraction(1, 2)))
                hint_count += 1
    for j in positive:
        if z_names[j] in hint:
            model.add_hint(zz[j], int(hint[z_names[j]] >= Fraction(1, 2)))
            hint_count += 1
    # Block 75's target has an independently proven unreachable subset sum.
    if 74 in positive:
        model.add(zz[74] == 1)

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = args.time_limit
    solver.parameters.num_search_workers = args.threads
    solver.parameters.random_seed = args.seed
    solver.parameters.log_search_progress = True
    solver.parameters.log_to_stdout = True
    solver.parameters.stop_after_first_solution = True
    started = time.monotonic()
    status = solver.solve(model)
    elapsed = time.monotonic() - started
    result = {
        "schema": "lonja-positive-groups-exact-cpsat-v1",
        "status": int(status),
        "status_name": solver.status_name(status),
        "elapsed_seconds": elapsed,
        "time_limit": args.time_limit,
        "threads": args.threads,
        "seed": args.seed,
        "positive_groups_one_based": [j + 1 for j in positive],
        "boolean_assignment_variables": len(xx),
        "boolean_slack_variables": len(zz),
        "hint_count": hint_count,
        "branches": solver.num_branches,
        "conflicts": solver.num_conflicts,
        "wall_time": solver.wall_time,
        "model_sha256": sha(args.model),
        "script_sha256": sha(Path(__file__)),
    }
    if status in (cp_model.FEASIBLE, cp_model.OPTIMAL):
        values = {variable: Fraction(0) for variable in variables}
        for i in range(100):
            for j in positive:
                values[x_names[i][j]] = Fraction(solver.value(xx[i, j]))
        # Activating exactly all 15 positive groups satisfies all four original
        # y master constraints: total 15, required-group count 6, caps 2 and 1.
        for j in positive:
            values[y_names[j]] = Fraction(1)
            values[z_names[j]] = Fraction(solver.value(zz[j]))
        for j in range(100):
            values[c_names[j]] = sum(weights[i] * values[x_names[i][j]] for i in range(100))

        bound_count = integrality_count = row_count = 0
        maximum = Fraction(0)
        samples = []
        for variable in variables:
            value = values[variable]
            if ((lb[variable] is not None and value < lb[variable])
                    or (ub[variable] is not None and value > ub[variable])):
                bound_count += 1
            if variable in integer and value.denominator != 1:
                integrality_count += 1
        for row in row_order:
            activity = sum(coefficient * values[variable] for variable, coefficient in rows[row])
            target = rhs.get(row, Fraction(0))
            violation = (
                abs(activity - target) if senses[row] == "E"
                else max(Fraction(0), activity - target) if senses[row] == "L"
                else max(Fraction(0), target - activity)
            )
            if violation:
                row_count += 1
                if len(samples) < 20:
                    samples.append([row, str(activity), senses[row], str(target), str(violation)])
            maximum = max(maximum, violation)
        objective_rows = {row for terms in columns.values() for row in terms if row not in senses}
        assert len(objective_rows) == 1
        objective_row = next(iter(objective_rows))
        objective = sum(columns[v].get(objective_row, Fraction(0)) * values[v] for v in variables)
        solution_path = args.output_dir / "solution.sol"
        with solution_path.open("w", encoding="ascii", newline="\n") as stream:
            stream.write(f"=obj= {terminating(objective)}\n")
            for variable in variables:
                if values[variable]:
                    stream.write(f"{variable} {terminating(values[variable])}\n")
        result.update({
            "slack_groups_one_based": [j + 1 for j in positive if solver.value(zz[j])],
            "objective_fraction": str(objective),
            "objective_decimal": terminating(objective),
            "bound_violation_count": bound_count,
            "integrality_violation_count": integrality_count,
            "row_violation_count": row_count,
            "maximum_exact_row_violation": str(maximum),
            "violation_samples": samples,
            "valid_at_zero_tolerance_before_reparse": (
                bound_count == 0 and integrality_count == 0 and row_count == 0
            ),
            "solution_sha256": sha(solution_path),
        })
    (args.output_dir / "result.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print("FINAL_RESULT " + json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
