#!/usr/bin/env python3
"""Optimize lonja exactly over a catalogue of exact-target subset witnesses."""

from __future__ import annotations

import argparse
import collections
import hashlib
import json
import math
import time
from fractions import Fraction
from pathlib import Path

from ortools.sat.python import cp_model

from helper_route_logic import parse


def name(index: int) -> str:
    return f"C{index:04d}"


def terminating(value: Fraction) -> str:
    if value == 0:
        return "0"
    sign = "-" if value < 0 else ""
    numerator, denominator = abs(value.numerator), value.denominator
    twos = fives = 0
    while denominator % 2 == 0:
        denominator //= 2
        twos += 1
    while denominator % 5 == 0:
        denominator //= 5
        fives += 1
    if denominator != 1:
        raise ValueError(value)
    places = max(twos, fives)
    scaled = numerator * 2 ** (places - twos) * 5 ** (places - fives)
    digits = str(scaled).rjust(places + 1, "0")
    if places == 0:
        return sign + digits
    return (sign + digits[:-places] + "." + digits[-places:]).rstrip("0").rstrip(".")


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--model", type=Path, required=True)
    ap.add_argument("--merged-pack", type=Path, required=True)
    ap.add_argument("--output-dir", type=Path, required=True)
    ap.add_argument("--time-limit", type=float, default=600)
    ap.add_argument("--threads", type=int, default=12)
    ap.add_argument("--seed", type=int, default=71)
    args = ap.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    senses, row_order, variables, columns, rows, rhs, lb, ub, integer = parse(args.model)
    xname = [[name(100 * i + j) for j in range(1, 101)] for i in range(1, 101)]
    cname = [name(j) for j in range(1, 101)]
    yname = [name(10100 + j) for j in range(1, 101)]
    zname = [name(10200 + j) for j in range(1, 101)]

    weights: list[Fraction] | None = None
    targets: list[Fraction] = []
    for j in range(100):
        erows = [row for row in row_order if senses[row] == "E" and dict(rows[row]).get(cname[j])]
        erows = [row for row in erows if sum(variable in cname for variable, _ in rows[row]) == 1]
        assert len(erows) == 1
        terms = dict(rows[erows[0]])
        candidate = [-terms[xname[i][j]] / terms[cname[j]] for i in range(100)]
        if weights is None:
            weights = candidate
        else:
            assert candidate == weights
        upper = [
            row for row in row_order
            if dict(rows[row]).get(cname[j]) == 1 and dict(rows[row]).get(zname[j]) == -1
        ]
        assert len(upper) == 1
        targets.append(rhs.get(upper[0], Fraction(0)))
    assert weights is not None
    positive = [j for j, target in enumerate(targets) if target > 0]
    assert len(positive) == 15

    merged = json.loads(args.merged_pack.read_text(encoding="utf-8"))
    experiment_root = args.merged_pack.parent.parent
    source_paths = [experiment_root / relative for relative in merged["input_files"]]
    catalog_sets: dict[int, set[tuple[int, ...]]] = collections.defaultdict(set)
    for path in source_paths:
        source = json.loads(path.read_text(encoding="utf-8"))
        for raw_block, witnesses in source.get("witnesses", {}).items():
            block = int(raw_block) - 1
            for witness in witnesses:
                items = tuple(sorted(int(item) - 1 for item in witness))
                catalog_sets[block].add(items)
    catalog = {block: sorted(catalog_sets[block]) for block in positive}
    assert sum(len(items) for items in catalog.values()) == merged["candidate_count"]
    for block, witnesses in catalog.items():
        for witness in witnesses:
            assert sum((weights[item] for item in witness), Fraction(0)) == targets[block]

    row_scale = math.lcm(*(value.denominator for value in weights + targets))
    iw = [int(value * row_scale) for value in weights]
    it = [int(value * row_scale) for value in targets]
    objective_rows = {row for terms in columns.values() for row in terms if row not in senses}
    assert len(objective_rows) == 1
    objective_row = next(iter(objective_rows))
    costs = [[columns[xname[i][j]].get(objective_row, Fraction(0)) for j in range(100)] for i in range(100)]
    objective_scale = math.lcm(*(value.denominator for row in costs for value in row))
    icost = [[int(value * objective_scale) for value in row] for row in costs]

    model = cp_model.CpModel()
    exact = {block: model.new_bool_var(f"exact_{block + 1}") for block in positive}
    q = {
        (block, witness_id): model.new_bool_var(f"q_{block + 1}_{witness_id}")
        for block in positive for witness_id in range(len(catalog[block]))
    }
    r = {
        (item, block): model.new_bool_var(f"r_{item + 1}_{block + 1}")
        for item in range(100) for block in positive
    }
    for block in positive:
        model.add(sum(q[block, witness_id] for witness_id in range(len(catalog[block]))) == exact[block])
    model.add(sum(exact.values()) >= 9)
    for item in range(100):
        witness_cover = [
            q[block, witness_id]
            for block in positive
            for witness_id, witness in enumerate(catalog[block])
            if item in witness
        ]
        model.add(sum(witness_cover) + sum(r[item, block] for block in positive) == 1)
        for block in positive:
            model.add(r[item, block] + exact[block] <= 1)
    for block in positive:
        # This is the only nonredundant side of |load-target|<=1 for a relaxed group.
        model.add(sum(iw[item] * r[item, block] for item in range(100)) <= it[block] + row_scale)

    objective_terms = []
    for block in positive:
        for witness_id, witness in enumerate(catalog[block]):
            cost = sum(icost[item][block] for item in witness)
            objective_terms.append(cost * q[block, witness_id])
    for item in range(100):
        for block in positive:
            objective_terms.append(icost[item][block] * r[item, block])
    model.minimize(sum(objective_terms))

    # Hint the known ten-witness disjoint packing; unmentioned leftover r values
    # intentionally remain free for the objective solver.
    known = {
        int(record["target_block"]) - 1: tuple(sorted(int(item) - 1 for item in record["items"]))
        for record in merged["chosen"]
    }
    for block in positive:
        model.add_hint(exact[block], int(block in known))
        if block in known and known[block] in catalog[block]:
            model.add_hint(q[block, catalog[block].index(known[block])], 1)

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = args.time_limit
    solver.parameters.num_search_workers = args.threads
    solver.parameters.random_seed = args.seed
    solver.parameters.log_search_progress = True
    solver.parameters.log_to_stdout = True
    started = time.monotonic()
    status = solver.solve(model)
    elapsed = time.monotonic() - started
    result = {
        "schema": "lonja-witness-catalogue-objective-master-v1",
        "status": int(status),
        "status_name": solver.status_name(status),
        "elapsed_seconds": elapsed,
        "time_limit": args.time_limit,
        "threads": args.threads,
        "seed": args.seed,
        "catalogue_witnesses": sum(len(items) for items in catalog.values()),
        "relaxed_assignment_variables": len(r),
        "objective_scale": objective_scale,
        "solver_objective_scaled": solver.objective_value,
        "solver_best_bound_scaled": solver.best_objective_bound,
        "branches": solver.num_branches,
        "conflicts": solver.num_conflicts,
        "wall_time": solver.wall_time,
        "model_sha256": sha(args.model),
        "merged_pack_sha256": sha(args.merged_pack),
        "source_files": [{"path": path.as_posix(), "sha256": sha(path)} for path in source_paths],
        "script_sha256": sha(Path(__file__)),
    }
    if status in (cp_model.FEASIBLE, cp_model.OPTIMAL):
        values = {variable: Fraction(0) for variable in variables}
        chosen_records = []
        for block in positive:
            if solver.value(exact[block]):
                chosen_ids = [
                    witness_id for witness_id in range(len(catalog[block]))
                    if solver.value(q[block, witness_id])
                ]
                assert len(chosen_ids) == 1
                witness = catalog[block][chosen_ids[0]]
                chosen_records.append({"block": block + 1, "witness_id": chosen_ids[0], "items": [i + 1 for i in witness]})
                for item in witness:
                    values[xname[item][block]] = Fraction(1)
            else:
                for item in range(100):
                    if solver.value(r[item, block]):
                        values[xname[item][block]] = Fraction(1)
        for block in positive:
            values[yname[block]] = Fraction(1)
            values[zname[block]] = Fraction(not solver.value(exact[block]))
        for block in range(100):
            values[cname[block]] = sum(weights[item] * values[xname[item][block]] for item in range(100))

        bound_count = integrality_count = row_count = 0
        maximum = Fraction(0)
        samples = []
        for variable in variables:
            value = values[variable]
            if ((lb[variable] is not None and value < lb[variable])
                    or (ub[variable] is not None and value > ub[variable])):
                bound_count += 1
            if variable in integer and value.denominator != 1:
                integrality_count += 1
        for row in row_order:
            activity = sum(coefficient * values[variable] for variable, coefficient in rows[row])
            target = rhs.get(row, Fraction(0))
            violation = (
                abs(activity - target) if senses[row] == "E"
                else max(Fraction(0), activity - target) if senses[row] == "L"
                else max(Fraction(0), target - activity)
            )
            if violation:
                row_count += 1
                if len(samples) < 20:
                    samples.append([row, str(activity), senses[row], str(target), str(violation)])
            maximum = max(maximum, violation)
        objective = sum(columns[v].get(objective_row, Fraction(0)) * values[v] for v in variables)
        solution_path = args.output_dir / "solution.sol"
        with solution_path.open("w", encoding="ascii", newline="\n") as stream:
            stream.write(f"=obj= {terminating(objective)}\n")
            for variable in variables:
                if values[variable]:
                    stream.write(f"{variable} {terminating(values[variable])}\n")
        result.update({
            "exact_blocks": chosen_records,
            "exact_block_count": len(chosen_records),
            "relaxed_blocks_one_based": [block + 1 for block in positive if not solver.value(exact[block])],
            "objective_fraction": str(objective),
            "objective_decimal": terminating(objective),
            "objective_scaled_integer": int(objective * objective_scale),
            "bound_violation_count": bound_count,
            "integrality_violation_count": integrality_count,
            "row_violation_count": row_count,
            "maximum_exact_row_violation": str(maximum),
            "violation_samples": samples,
            "valid_at_zero_tolerance_before_reparse": (
                bound_count == 0 and integrality_count == 0 and row_count == 0
            ),
            "solution_sha256": sha(solution_path),
        })
    result_path = args.output_dir / "result.json"
    result_path.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print("FINAL_RESULT " + json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
