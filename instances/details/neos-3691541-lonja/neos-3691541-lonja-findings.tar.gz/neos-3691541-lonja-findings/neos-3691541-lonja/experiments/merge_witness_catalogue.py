#!/usr/bin/env python3
"""Merge lonja witness shards, validate them, and pack disjoint targets.

Target and item labels in shard JSON files are one-based.  With ``--audit``,
every recovered subset is checked using exact integer weights before it enters
the set-packing model.
"""

from __future__ import annotations

import argparse
import glob
import hashlib
import json
from collections import defaultdict
from fractions import Fraction
from pathlib import Path

from ortools.sat.python import cp_model


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--glob", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--audit", type=Path)
    parser.add_argument("--seconds", type=float, default=120)
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--seed", type=int, default=20260908)
    args = parser.parse_args()

    paths = sorted(glob.glob(args.glob))
    if not paths:
        raise SystemExit(f"no files matched {args.glob!r}")
    exact_weights = exact_targets = None
    if args.audit:
        audit = json.loads(args.audit.read_text(encoding="utf-8"))
        scale = int(audit["integer_scale_lcm"])
        divisor = int(audit["integer_gcd_reduction"])
        exact_weights = [int(Fraction(value) * scale) // divisor for value in audit["weight_fractions"]]
        exact_targets = [int(Fraction(value) * scale) // divisor for value in audit["target_fractions"]]
    witnesses: dict[int, set[tuple[int, ...]]] = defaultdict(set)
    for path in paths:
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        for target, records in payload.get("witnesses", {}).items():
            for record in records:
                target_number = int(target)
                witness = tuple(sorted(map(int, record)))
                if not 1 <= target_number <= 100:
                    raise ValueError((path, target_number))
                if len(witness) != len(set(witness)) or any(not 1 <= item <= 100 for item in witness):
                    raise ValueError((path, target_number, witness))
                if exact_weights is not None:
                    total = sum(exact_weights[item - 1] for item in witness)
                    if total != exact_targets[target_number - 1]:
                        raise ValueError((path, target_number, total, exact_targets[target_number - 1]))
                witnesses[target_number].add(witness)

    model = cp_model.CpModel()
    candidates = []
    for target in sorted(witnesses):
        for index, witness in enumerate(sorted(witnesses[target])):
            candidates.append((target, witness, model.new_bool_var(f"t{target}_c{index}")))
    for target in witnesses:
        model.add(sum(variable for group, _, variable in candidates if group == target) <= 1)
    for item in range(1, 101):
        model.add(sum(variable for _, witness, variable in candidates if item in witness) <= 1)
    model.maximize(sum(variable for _, _, variable in candidates))

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = args.seconds
    solver.parameters.num_search_workers = args.workers
    solver.parameters.random_seed = args.seed
    status = solver.solve(model)
    chosen = [
        {"target_block": target, "items": list(witness)}
        for target, witness, variable in candidates
        if status in (cp_model.FEASIBLE, cp_model.OPTIMAL) and solver.value(variable)
    ]
    result = {
        "schema": "lonja-merged-witness-packing-v1",
        "input_files": paths,
        "input_sha256": {path: sha256(Path(path)) for path in paths},
        "audit_sha256": sha256(args.audit) if args.audit else None,
        "script_sha256": sha256(Path(__file__)),
        "seed": args.seed,
        "target_witness_counts": {str(target): len(records) for target, records in sorted(witnesses.items())},
        "candidate_count": len(candidates),
        "status": int(status),
        "status_name": solver.status_name(status),
        "chosen_count": len(chosen),
        "chosen": chosen,
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
