#!/usr/bin/env python3
"""Recover diverse exact subset witnesses for lonja and maximize disjoint targets.

The input is the JSON emitted by ``lonja_exact_subset_audit.py``.  A Python
integer is used as an exact subset-sum bitset.  Keeping every prefix bitset
allows one witness for every attainable target to be reconstructed for a
given item order.  Random item orders expose different witnesses; a tiny
CP-SAT set-packing model then maximizes the number of target witnesses whose
item sets are pairwise disjoint.
"""

from __future__ import annotations

import argparse
import gc
import hashlib
import json
import random
import time
from collections import defaultdict
from fractions import Fraction
from pathlib import Path

from ortools.sat.python import cp_model


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def reconstruct(prefix: list[int], order: list[int], weights: list[int], target: int) -> tuple[int, ...]:
    if not ((prefix[-1] >> target) & 1):
        raise ValueError("target is unreachable")
    remaining = target
    chosen: list[int] = []
    for position in range(len(order) - 1, -1, -1):
        if (prefix[position] >> remaining) & 1:
            continue
        item = order[position]
        weight = weights[item]
        if remaining < weight or not ((prefix[position] >> (remaining - weight)) & 1):
            raise AssertionError((position, item, remaining, weight))
        chosen.append(item)
        remaining -= weight
    if remaining != 0:
        raise AssertionError(remaining)
    return tuple(sorted(chosen))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--audit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--orders", type=int, default=24)
    parser.add_argument("--seed", type=int, default=20260908)
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--packing-seconds", type=float, default=120)
    args = parser.parse_args()

    source = json.loads(args.audit.read_text(encoding="utf-8"))
    scale = int(source["integer_scale_lcm"])
    divisor = int(source["integer_gcd_reduction"])
    weights = [int(Fraction(value) * scale) // divisor for value in source["weight_fractions"]]
    targets = [int(Fraction(value) * scale) // divisor for value in source["target_fractions"]]
    positive = [index for index, target in enumerate(targets) if target > 0]
    attainable = [index for index in positive if index + 1 not in source["positive_target_blocks_unattainable"]]
    maximum_target = max(targets[index] for index in attainable)
    mask = (1 << (maximum_target + 1)) - 1
    witnesses: dict[int, set[tuple[int, ...]]] = defaultdict(set)
    order_records = []
    started = time.monotonic()

    for repetition in range(args.orders):
        order = list(range(len(weights)))
        random.Random(args.seed + repetition).shuffle(order)
        reachable = 1
        prefix = [reachable]
        build_started = time.monotonic()
        for item in order:
            reachable = (reachable | (reachable << weights[item])) & mask
            prefix.append(reachable)
        counts_before = {target: len(witnesses[target]) for target in attainable}
        for target in attainable:
            witness = reconstruct(prefix, order, weights, targets[target])
            if sum(weights[item] for item in witness) != targets[target]:
                raise AssertionError((target, witness))
            witnesses[target].add(witness)
        order_records.append({
            "repetition": repetition,
            "seed": args.seed + repetition,
            "seconds": time.monotonic() - build_started,
            "new_witnesses": sum(len(witnesses[target]) - counts_before[target] for target in attainable),
            "witness_counts": {str(target + 1): len(witnesses[target]) for target in attainable},
        })
        del prefix, reachable
        gc.collect()
        print(json.dumps(order_records[-1], sort_keys=True), flush=True)

    model = cp_model.CpModel()
    candidates: list[tuple[int, tuple[int, ...], cp_model.IntVar]] = []
    for target in attainable:
        for candidate_index, witness in enumerate(sorted(witnesses[target])):
            variable = model.new_bool_var(f"take_t{target + 1}_c{candidate_index}")
            candidates.append((target, witness, variable))
    for target in attainable:
        model.add(sum(variable for group, _, variable in candidates if group == target) <= 1)
    for item in range(len(weights)):
        model.add(sum(variable for _, witness, variable in candidates if item in witness) <= 1)
    model.maximize(sum(variable for _, _, variable in candidates))
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = args.packing_seconds
    solver.parameters.num_search_workers = args.workers
    solver.parameters.random_seed = args.seed
    packing_status = solver.solve(model)
    chosen = []
    if packing_status in (cp_model.FEASIBLE, cp_model.OPTIMAL):
        for target, witness, variable in candidates:
            if solver.value(variable):
                chosen.append({"target_block": target + 1, "items": [item + 1 for item in witness]})

    result = {
        "schema": "lonja-random-prefix-bitset-witness-packing-v1",
        "audit_sha256": sha256(args.audit),
        "script_sha256": sha256(Path(__file__)),
        "seed": args.seed,
        "orders": args.orders,
        "elapsed_seconds": time.monotonic() - started,
        "scale": scale,
        "gcd_divisor": divisor,
        "attainable_target_blocks": [target + 1 for target in attainable],
        "witness_counts": {str(target + 1): len(witnesses[target]) for target in attainable},
        "candidate_count": len(candidates),
        "packing_status": int(packing_status),
        "packing_status_name": solver.status_name(packing_status),
        "chosen_count": len(chosen),
        "chosen": chosen,
        "witnesses": {
            str(target + 1): [
                [item + 1 for item in witness]
                for witness in sorted(witnesses[target])
            ]
            for target in attainable
        },
        "order_records": order_records,
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print("FINAL_RESULT " + json.dumps(result, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
