# lr1dr02vc05v8a-t360

Official MIPLIB status: open. The public solution was strictly reconstructed at
objective `123046.81611861245`, with zero row, bound, and integrality violation.
No better verified upper bound or new lower bound was obtained.

## Structure and validation

This is a three-port, five-vessel-class, 360-period maritime
inventory-routing model with 20,810 variables, 7,560 rows, and 58,950 nonzeros.
The incumbent decomposes into eight vessel routes.

The historical MIRPLib integer pattern associated with table value `122598`
does not reproduce that number on this MPS: exact integer fixing and continuous
completion gives a feasible objective `123336.00281376469`, worse than the
current public incumbent.

## Solver-free heuristic study

A direct-API-designed RVND/ILS rebuilt every time-expanded route, reconstructed
inventory and slack variables analytically, and audited all original MPS rows.
A deterministic validation generated 783 complete candidates; 190 were fully
feasible, with no improvement. A capacity-preserving three-trip exchange
(`300 = 150 + 150`) checked 45 trip selections and 5,625 local timing repairs;
3,750 complete paths were rebuilt, but none passed the hard inventory sides.

Recorded successful API usage was 186,248 of 200,000 tokens. Gurobi was used
only for MPS reading; commercial-solver optimization time was zero.

## Evidence boundary

This is a sufficient-effort heuristic result and strict incumbent audit, not an
optimality proof. A 2025 beam-search/ILS paper reports lower numerical values,
but no public solution certificate was available here, so those values are not
claimed as verified bounds.

Sources: [MIPLIB instance page](https://miplib.zib.de/instance_details_lr1dr02vc05v8a-t360.html),
[MIRPLib formulation](https://mirplib.scl.gatech.edu/sites/default/files/Group2_MIP_Model.pdf),
[beam-search and ILS paper](https://arxiv.org/abs/2505.13522).

