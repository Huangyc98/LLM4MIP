# Package manifest: lr1dr02vc05v8a-t360

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 2
Excluded source files: 0

## Included files

- `README.md`
- `result-summary.json`

## Excluded files

- None
