# Package manifest: ex1010-pi

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 30
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/ex1010-pi-original-to-reduced.tsv`
- `artifacts/ex1010-pi-preprocess-summary.json`
- `artifacts/ex1010-pi-reduced-233.sol`
- `artifacts/ex1010-pi-reduced-columns.tsv`
- `artifacts/ex1010-pi-reduced-lb233.opb`
- `artifacts/ex1010-pi-reduced-relax.lp`
- `artifacts/ex1010-pi-reduced-relax.sol`
- `artifacts/ex1010-pi-reduced.lp`
- `artifacts/ex1010-pi-reduced.opb`
- `artifacts/ex1010-pi-reduced.wcnf`
- `artifacts/private-exchange-positive-gain.opb`
- `artifacts/private-exchange-search.json`
- `logs/disjoint-row-packing.log`
- `logs/ex1010-pi-kernel-600s.log`
- `logs/ex1010-pi-reduced-relax.log`
- `logs/private-exchange-30s.log`
- `logs/roundingsat-lb233-600s.log`
- `logs/roundingsat-private-exchange-120s.log`
- `reports/structural-investigation.md`
- `scripts/analyze_incumbent_core.py`
- `scripts/independent_reduce.py`
- `scripts/max_disjoint_row_packing.py`
- `scripts/preprocess.py`
- `scripts/private_exchange_core.py`
- `scripts/roundingsat-gcc10.patch`
- `scripts/run_exact_python.py`
- `solutions/kernel-run-233.sol`
- `solutions/kernel-start-233.sol`
- `solutions/official-233.sol.gz`

## Excluded files

- `input/ex1010-pi.mps.gz (469170 bytes; raw benchmark input; sha256 05e2a67ffff4e28912ce90ef60b9dd855257c1e36fca2a8b87981983d9edbdf8)`
