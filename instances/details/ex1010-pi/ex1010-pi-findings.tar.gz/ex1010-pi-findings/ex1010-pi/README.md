# `ex1010-pi`

## Result

This is an unweighted set-cover instance with 25,200 binary columns and 1,468
cover rows. The official objective **233** solution is checked directly.
Exact duplicate and dominance reductions produce an equivalent kernel with
11,568 columns, 1,466 rows, and 63,965 nonzeros.

A 600-second dual-focused Gurobi run retained incumbent 233 and ended with
integral solver bound **224**. The global optimum remains open; the remaining
proof target is infeasibility of the generated decision problem
`sum(x) <= 232`.

The proof route has now been executed with proof-logging RoundingSat rather
than left as a recommendation. The complete reduced decision OPB reached
97,308 conflicts in 600 CPU seconds but returned `TIMELIMIT`; its partial
6.6 GiB trace ends with `conclusion NONE` and is retained outside Git. A new
incumbent-private-row exchange core has 24,627 variables and 1,200 constraints.
It found no positive-gain exchange, but a separate 120-second RoundingSat run
also timed out, so this promising subproblem is not yet an optimality proof.

Two other proof families have explicit stop results. Ordinary disjoint-row
packing cannot reach 233 because even its continuous upper bound is below 216.
Standard reduced-cost fixing cannot close a 12.329913-unit LP gap because
unit-cost set-cover reduced costs are at most one. These are mathematical route
diagnostics, not additional solver tuning.

## Provenance

- Compressed MPS SHA-256: `05E2A67FFFF4E28912CE90EF60B9DD855257C1E36FCA2A8B87981983D9EDBDF8`
- Official compressed solution SHA-256: `E28E8D79D484418EA0EF821151855F13633907ED4E4B466AC6B71DA1E923FDC6`
- [MIPLIB instance page](https://miplib.zib.de/instance_details_ex1010-pi.html)

## Reproduction

[`scripts/preprocess.py`](scripts/preprocess.py) builds the reduced
LP/OPB/WCNF artifacts, while
[`scripts/independent_reduce.py`](scripts/independent_reduce.py) provides an
independent reduction path. Proof-ready decision files and maps are under
[`artifacts/`](artifacts/); the bounded solver transcripts are under
[`logs/`](logs/).

[`scripts/private_exchange_core.py`](scripts/private_exchange_core.py) emits
the private-row decision OPB,
[`scripts/max_disjoint_row_packing.py`](scripts/max_disjoint_row_packing.py)
tests the packing-certificate family, and
[`scripts/roundingsat-gcc10.patch`](scripts/roundingsat-gcc10.patch) records the
small source-compatibility patch needed to build the PB24 proof logger on
Euler4. No incomplete multi-gigabyte proof trace is checked into Git.

See the [full structural report](reports/structural-investigation.md). The
solver bound is recorded separately from exact preprocessing and witness
validation.
