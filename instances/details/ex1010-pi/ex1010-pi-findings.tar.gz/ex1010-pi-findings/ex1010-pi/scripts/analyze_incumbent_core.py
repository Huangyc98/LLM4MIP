#!/usr/bin/env python3
"""Incumbent-critical-row relaxation for ex1010-pi.

The script uses Gurobi only to parse the MPS.  It extracts rows covered exactly
once by the known 233-cover, projects all columns onto those rows, and performs
exact unit-cost duplicate/dominance reduction using Python integer bitsets.
If this relaxation needs at least 233 columns, that is a valid lower bound for
the original set-cover instance.
"""

import argparse
import gzip
from collections import Counter, defaultdict

import gurobipy as gp


def read_solution(path, names):
    opener = gzip.open if path.endswith(".gz") else open
    selected = set()
    with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
        for raw in handle:
            fields = raw.strip().split()
            if len(fields) >= 2 and fields[0] in names and float(fields[1]) > 0.5:
                selected.add(names[fields[0]])
    return selected


def compact(counter, limit=25):
    items = sorted(counter.items(), key=lambda kv: (-kv[1], str(kv[0])))
    text = ", ".join(f"{key}:{count}" for key, count in items[:limit])
    if len(items) > limit:
        text += f", ... ({len(items)} distinct)"
    return "{" + text + "}"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mps")
    parser.add_argument("solution")
    args = parser.parse_args()

    model = gp.read(args.mps)
    variables = model.getVars()
    constraints = model.getConstrs()
    names = {v.VarName: v.index for v in variables}
    selected = read_solution(args.solution, names)
    if len(selected) != 233:
        raise RuntimeError(f"expected 233 selected columns, found {len(selected)}")

    row_columns = []
    activities = []
    for con in constraints:
        expr = model.getRow(con)
        columns = [expr.getVar(k).index for k in range(expr.size())]
        row_columns.append(columns)
        activities.append(sum(j in selected for j in columns))
    critical_rows = [r for r, activity in enumerate(activities) if activity == 1]
    critical_index = {r: k for k, r in enumerate(critical_rows)}
    owner = {}
    private_count = Counter()
    for r in critical_rows:
        chosen = [j for j in row_columns[r] if j in selected]
        if len(chosen) != 1:
            raise RuntimeError("critical row does not have one incumbent owner")
        owner[r] = chosen[0]
        private_count[chosen[0]] += 1

    supports = [0] * len(variables)
    owner_sets = [set() for _ in variables]
    for r in critical_rows:
        bit = 1 << critical_index[r]
        incumbent = owner[r]
        for j in row_columns[r]:
            supports[j] |= bit
            owner_sets[j].add(incumbent)

    nonzero = [j for j, support in enumerate(supports) if support]
    print("selected columns", len(selected))
    print("critical rows", len(critical_rows), "owners represented", len(private_count))
    print("private rows per incumbent", compact(Counter(private_count.values())))
    print("columns touching critical rows", len(nonzero))
    print("critical support size", compact(Counter(supports[j].bit_count() for j in nonzero)))
    print("incumbent-owner span", compact(Counter(len(owner_sets[j]) for j in nonzero)))
    print("maximum owner span", max(len(owner_sets[j]) for j in nonzero))

    by_support = defaultdict(list)
    for j in nonzero:
        by_support[supports[j]].append(j)
    unique = list(by_support)
    print("unique projected supports", len(unique), "duplicates removed", len(nonzero) - len(unique))

    # Keep inclusion-wise maximal supports. Process large supports first and
    # index retained supports by every critical bit they contain.
    retained = []
    containing = [[] for _ in critical_rows]
    dominated = 0
    for support in sorted(unique, key=lambda value: (-value.bit_count(), value)):
        bits = [b for b in range(len(critical_rows)) if (support >> b) & 1]
        pivot = min(bits, key=lambda b: len(containing[b]))
        if any(support & ~retained[idx] == 0 for idx in containing[pivot]):
            dominated += 1
            continue
        idx = len(retained)
        retained.append(support)
        for b in bits:
            containing[b].append(idx)

    coverage = 0
    for support in retained:
        coverage |= support
    print("maximal projected supports", len(retained), "strictly dominated unique supports", dominated)
    print("all critical rows retained", coverage.bit_count() == len(critical_rows))
    print("retained support size", compact(Counter(s.bit_count() for s in retained)))

    # Recompute row degrees and owner spans after exact projection reduction.
    row_degree = [0] * len(critical_rows)
    retained_owner_span = Counter()
    for support in retained:
        owners_here = set()
        bits = support
        while bits:
            lsb = bits & -bits
            b = lsb.bit_length() - 1
            row_degree[b] += 1
            owners_here.add(owner[critical_rows[b]])
            bits ^= lsb
        retained_owner_span[len(owners_here)] += 1
    print("critical row degree after reduction", compact(Counter(row_degree)))
    print("retained owner-span histogram", compact(retained_owner_span))

    # A simple valid packing lower bound: greedily choose critical rows whose
    # retained-column neighborhoods are disjoint. It is only a diagnostic;
    # the selected rows themselves form the checkable certificate.
    neighborhoods = []
    for b in range(len(critical_rows)):
        mask = 0
        for j, support in enumerate(retained):
            if (support >> b) & 1:
                mask |= 1 << j
        neighborhoods.append(mask)
    order = sorted(range(len(critical_rows)), key=lambda b: (row_degree[b], b))
    used_columns = 0
    packing = []
    for b in order:
        if neighborhoods[b] & used_columns == 0:
            packing.append(b)
            used_columns |= neighborhoods[b]
    print("greedy disjoint-neighborhood packing", len(packing))
    print("packing original row ids", [critical_rows[b] for b in packing[:100]])


if __name__ == "__main__":
    main()
