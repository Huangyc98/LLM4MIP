#!/usr/bin/env python3
"""Test whether incumbent-private rows alone can certify ex1010-pi >= 233."""

from __future__ import annotations

import argparse
import gzip
import json
from collections import defaultdict
from decimal import Decimal
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def read_values(path: Path):
    opener = gzip.open if path.suffix == ".gz" else open
    values = defaultdict(int)
    with opener(path, "rt", encoding="latin-1") as fh:
        for line in fh:
            fields = line.split()
            if len(fields) == 2 and fields[0].startswith("x"):
                values[fields[0]] = int(Decimal(fields[1]))
    return values


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mps", type=Path)
    ap.add_argument("solution", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--log", type=Path)
    ap.add_argument("--opb", type=Path)
    ap.add_argument("--time-limit", type=float, default=30)
    args = ap.parse_args()

    source = gp.read(str(args.mps))
    values = read_values(args.solution)
    selected = {v.VarName for v in source.getVars() if values[v.VarName] == 1}
    row_to_cols = defaultdict(list)
    for var in source.getVars():
        col = source.getCol(var)
        for k in range(col.size()):
            if col.getCoeff(k) != 0:
                row_to_cols[col.getConstr(k).ConstrName].append(var.VarName)
    private = {}
    for row, columns in row_to_cols.items():
        owners = [v for v in columns if v in selected]
        if len(owners) == 1:
            private[row] = owners[0]

    outside = sorted({v for row in private for v in row_to_cols[row] if v not in selected})
    test = gp.Model("ex1010_private_exchange")
    z = test.addVars(sorted(selected), vtype=GRB.BINARY, name="omit")
    y = test.addVars(outside, vtype=GRB.BINARY, name="add")
    for row, owner in private.items():
        test.addConstr(gp.quicksum(y[v] for v in row_to_cols[row] if v not in selected) >= z[owner], name=row)
    test.setObjective(z.sum() - y.sum(), GRB.MAXIMIZE)

    if args.opb:
        ordered_selected = sorted(selected)
        opb_names = {
            **{("z", v): f"x{i + 1}" for i, v in enumerate(ordered_selected)},
            **{("y", v): f"x{i + 1 + len(ordered_selected)}" for i, v in enumerate(outside)},
        }
        lines = [
            f"* #variable= {len(ordered_selected) + len(outside)} "
            f"#constraint= {len(private) + 1} #equal= 0 intsize= 15",
            "* UNSAT proves that the 1199 incumbent-private rows admit no improving exchange.",
        ]
        for row, owner in private.items():
            terms = [f"-1 {opb_names[('z', owner)]}"]
            terms.extend(
                f"+1 {opb_names[('y', v)]}"
                for v in row_to_cols[row]
                if v not in selected
            )
            lines.append(" ".join(terms) + " >= 0 ;")
        gain = [f"+1 {opb_names[('z', v)]}" for v in ordered_selected]
        gain.extend(f"-1 {opb_names[('y', v)]}" for v in outside)
        lines.append(" ".join(gain) + " >= 1 ;")
        args.opb.parent.mkdir(parents=True, exist_ok=True)
        args.opb.write_text("\n".join(lines) + "\n", encoding="ascii", newline="\n")
    test.Params.Threads = 1
    test.Params.TimeLimit = args.time_limit
    if args.log:
        args.log.parent.mkdir(parents=True, exist_ok=True)
        test.Params.LogFile = str(args.log)
    test.optimize()

    omitted = sorted(v for v in selected if z[v].X > 0.5)
    added = sorted(v for v in outside if y[v].X > 0.5)
    uncovered = []
    added_set = set(added)
    for row, owner in private.items():
        if owner in omitted and not any(v in added_set for v in row_to_cols[row]):
            uncovered.append(row)
    payload = {
        "private_rows": len(private),
        "incumbent_columns": len(selected),
        "outside_columns_in_private_core": len(outside),
        "maximum_gain": int(round(test.ObjVal)),
        "omitted_count": len(omitted),
        "added_count": len(added),
        "omitted_incumbent_columns": omitted,
        "added_outside_columns": added,
        "uncovered_private_rows": uncovered,
        "interpretation": (
            "positive gain proves that incumbent-private rows alone cannot certify 233; "
            "it does not assert feasibility for all cover rows"
        ),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in payload.items() if not isinstance(v, list)}, indent=2))


if __name__ == "__main__":
    main()
