#!/usr/bin/env python3
"""Run the Exact PB solver Python interface on a decision OPB file.

The PyPI build exposes Exact's native C++ solver but not its command-line OPB
parser, so this small loader accepts the simple integral OPB subset used by
ex1010-pi and enables Exact's native proof logger before adding constraints.
"""

import argparse
import re
import time

import exact


TERM = re.compile(r"([+-]?\d+)\s+([A-Za-z][A-Za-z0-9_\[\]{}^]*)")


def parse_opb(path):
    variable_count = None
    constraints = []
    variables = set()
    with open(path, "rt", encoding="utf-8", errors="strict") as handle:
        for line_number, raw in enumerate(handle, 1):
            line = raw.strip()
            if not line:
                continue
            if line.startswith("*"):
                match = re.search(r"#variable=\s*(\d+)", line)
                if match:
                    variable_count = int(match.group(1))
                continue
            if not line.endswith(";"):
                raise ValueError(f"line {line_number}: missing semicolon")
            body = line[:-1].strip()
            comparator = None
            for candidate in (">=", "<=", "="):
                if candidate in body:
                    comparator = candidate
                    lhs, rhs_text = body.rsplit(candidate, 1)
                    break
            if comparator is None:
                raise ValueError(f"line {line_number}: no comparator")
            rhs = int(rhs_text.strip())
            terms = TERM.findall(lhs)
            remainder = TERM.sub("", lhs).strip()
            if remainder:
                raise ValueError(f"line {line_number}: unparsed text {remainder!r}")
            coefficients = [int(coefficient) for coefficient, name in terms]
            names = [name for coefficient, name in terms]
            variables.update(names)
            constraints.append((coefficients, names, comparator, rhs))
    if variable_count is not None and len(variables) != variable_count:
        raise ValueError(f"header says {variable_count} variables; parsed {len(variables)}")
    return sorted(variables, key=lambda name: (int(name[1:]) if name[1:].isdigit() else name)), constraints


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("opb")
    parser.add_argument("--proof")
    parser.add_argument("--verbosity", type=int, default=1)
    args = parser.parse_args()

    names, constraints = parse_opb(args.opb)
    print(f"parsed variables={len(names)} constraints={len(constraints)}", flush=True)
    solver = exact.Exact()
    solver.setVerbosity(args.verbosity)
    if args.proof:
        solver.setOption("proof-log", args.proof)
    for name in names:
        solver.addVariable(name, 0, 1)
    for coefficients, variables, comparator, rhs in constraints:
        solver.addConstraint(
            coefficients,
            variables,
            comparator in (">=", "="),
            rhs if comparator in (">=", "=") else 0,
            comparator in ("<=", "="),
            rhs if comparator in ("<=", "=") else 0,
        )
    solver.init([], [])
    started = time.time()
    state = solver.runFull()
    elapsed = time.time() - started
    print(f"state={int(state)} elapsed_seconds={elapsed:.6f}", flush=True)
    print(f"has_solution={bool(solver.hasSolution())}", flush=True)
    solver.printStats()


if __name__ == "__main__":
    main()
