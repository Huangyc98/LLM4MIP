# Package manifest: graph40-40-1rand

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 41
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/graph40-40-1rand_clique_weights.tsv`
- `artifacts/graph40-40-1rand_decoded_incumbent.json`
- `artifacts/graph40-40-1rand_edges.tsv`
- `artifacts/graph40-40-1rand_fractional_clique_c5_certificate.json`
- `artifacts/graph40-40-1rand_fractional_clique_c5_exact_audit.json`
- `artifacts/graph40-40-1rand_fractional_clique_c5_odd_certificate.json`
- `artifacts/graph40-40-1rand_fractional_clique_c5_odd_exact_audit.json`
- `artifacts/graph40-40-1rand_fractional_clique_numeric.json`
- `artifacts/graph40-40-1rand_k9_independent_validation.json`
- `artifacts/graph40-40-1rand_randgraph_seed1_audit.json`
- `artifacts/graph40-40-1rand_separated_cuts.tsv`
- `artifacts/graph40-40-1rand_structural_audit.json`
- `experiments/sat-k10-20260907/10-cuts-encoding.json`
- `experiments/sat-k10-20260907/10-cuts.cnf`
- `experiments/sat-k10-20260907/10-cuts.drat`
- `experiments/sat-k10-20260907/10-cuts.lrat`
- `experiments/sat-k10-20260907/README.md`
- `experiments/sat-k10-20260907/cadical.log`
- `experiments/sat-k10-20260907/drat-trim.log`
- `experiments/sat-k10-20260907/lrat-independent-check.json`
- `experiments/sat-k10-20260907/optimality-certificate.json`
- `experiments/sat-k10-20260907/original-mps-audit.json`
- `experiments/sat-k10-20260907/run-cadical.sh`
- `logs/graph40-40-1rand_clique_certificate.log`
- `logs/graph40-40-1rand_k10_exact_corrected.log`
- `logs/graph40-40-1rand_k9_fixed_validation_corrected.log`
- `reports/graph40-40-1rand_fractional_clique_c5_report.md`
- `reports/graph40-40-1rand_investigation.md`
- `scripts/audit_graph40_40_original.py`
- `scripts/build_graph40_40_k10.py`
- `scripts/check_lrat_rup.py`
- `scripts/graph40-40-1rand_fractional_clique.py`
- `scripts/graph40_40_clique_certificate.cpp`
- `scripts/graph40_40_sat.py`
- `scripts/reconstruct_graph40_40.py`
- `scripts/regenerate_graph40_40_randgraph.py`
- `scripts/validate_graph40_40_incumbent.py`
- `scripts/verify_graph40_40_fractional_clique_c5.py`
- `scripts/verify_graph40_40_optimality.py`
- `solutions/official-9.sol.gz`

## Excluded files

- `input/graph40-40-1rand.mps.gz (10013987 bytes; raw benchmark input; sha256 faf688f36bc47c807167d167dfb9e744a8afeb7d2aeec1d75eec6bb0ea9eea6e)`
