# `graph40-40-1rand`: fractional clique and odd-cycle certificate audit

## Outcome

This route gives a rigorous upper bound of **10**, but it does **not** certify the
incumbent value 9.  The exact optimum of each of the following cut-cover
relaxations is

\[
    551/52 = 10.596153846\ldots:
\]

1. all 219 maximal-clique inequalities;
2. those clique inequalities plus all 5,205 induced-C5 inequalities with
   coefficient 1 when a cut splits the C5 and right-hand side 2; and
3. the stronger odd-cycle form from Bergner--Luebbecke--Witt, in which a cut's
   C5 coefficient is half the number of C5 edges it crosses (1 or 2), again
   with right-hand side 2.

The optimal weight vector uses 38 maximal cliques and no C5.  Consequently,
the C5 rows do not improve the clique bound on this graph.

## Why the bound is valid

A clique is split by at most one member of a pairwise edge-disjoint cut
packing: any two nontrivial bipartitions of a complete graph have a common
crossing edge.  A C5 is split by at most two packed cuts because every cut
crosses a cycle in a positive even number of edges, hence at least two of its
five edges.  The stronger published odd-cycle row keeps track of whether a cut
uses two or four of those edges.

Thus, if nonnegative object weights cover every nontrivial graph cut to weight
at least 1, the weighted sum of the object capacities upper-bounds the number
of packed cuts.

## Exact certificates

The generated rational primal has objective 551/52.  Its global minimum split
weight is exactly 1.  This was checked without an optimizer by converting the
38 weighted cliques to a directed hypergraph-cut network and computing 39
integer max flows (root 0 against every other terminal); every minimum cut has
scaled value 52 with scale 52.

The rational dual has 39 positive cut weights, also summing to 551/52.  Direct
`Fraction` arithmetic verifies every one of the 219 clique constraints and all
5,205 C5 constraints.  For the stronger odd-cycle form, the largest C5 dual
load is 25/13 < 2.  Primal and dual equality proves the relaxation optimum
exactly.

Even before separation, the 40 singleton-cut rows have an exact dual value
180/17 = 10.588235...; hence no weighting of maximal cliques alone can have
cost at most 9.

The graph used here has 40 vertices and 275 unique edges, with canonical edge
list SHA-256
`bedbdab73007779c9212578fc4e3ad0091a8c21f1226f0afffcd1d733eefdabb`.

## Lovasz-theta assessment

Applying Lovasz theta to the **original** 40-vertex graph would only upper-bound
its independence number.  It would not upper-bound the cut-packing number:
the published general relationship is
\(\alpha(G) \leq \gamma(G) \leq 2\alpha(G)-1\).  Therefore even a proof that
\(\vartheta(G)<10\) would only recover \(\alpha(G)=9\), not \(\gamma(G)=9\).

A formally valid theta route exists only after constructing the conflict graph
whose vertices are all nonempty cuts and whose edges join intersecting cuts;
then \(\gamma(G)\) is the stability number of that conflict graph.  Here that
graph can have up to \(2^{39}-1\) vertices, and no compact theta formulation or
separation oracle was identified.  Treating theta of the original graph as a
certificate would therefore be an invalid inference.

Primary formulation/source: M. Bergner, M. E. Luebbecke, and J. T. Witt,
"A Branch-Price-and-Cut Algorithm for Packing Cuts in Undirected Graphs,"
ACM JEA 21 (2016), https://or.rwth-aachen.de/files/research/publications/jea2016-cutpacking.pdf.

## Reproduction artifacts

- `graph40-40-1rand_fractional_clique.py`: one-thread row generation; each
  optimizer call has a 30-second limit (the complete C5 runs took under one
  second each).
- `graph40-40-1rand_fractional_clique_c5_odd_certificate.json`: rational
  primal/dual certificate for the stronger odd-cycle version.
- `verify_graph40_40_fractional_clique_c5.py --strong`: optimizer-free exact
  verifier.
- `graph40-40-1rand_fractional_clique_c5_odd_exact_audit.json`: verifier output.

Epistemic status: exact rejection of these relaxation families as a proof of
9; not an exact solution of the original cut-packing instance.
