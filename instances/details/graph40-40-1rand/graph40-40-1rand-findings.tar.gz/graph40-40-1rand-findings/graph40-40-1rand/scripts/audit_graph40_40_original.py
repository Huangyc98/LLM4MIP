#!/usr/bin/env python3
"""Audit the complete original MPS-to-cut-packing reduction.

Gurobi is used only as an MPS reader.  Every variable and every row is matched
against the expected binary cut-packing template; no optimization is called.
"""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path

import gurobipy as gp


N = 40
BLOCKS = 300
RECORDS = 300


def parse_y(name):
    head, c, a, b = name.split("#")
    assert head == "y"
    return int(c), int(a), int(b)


def parse_u(name):
    head, c, v = name.split("#")
    assert head == "u"
    return int(c), int(v)


def row_terms(matrix, variables, row):
    lo, hi = matrix.indptr[row : row + 2]
    result = {variables[j].VarName: int(value) for j, value in zip(matrix.indices[lo:hi], matrix.data[lo:hi])}
    assert len(result) == hi - lo
    assert all(float(value).is_integer() for value in matrix.data[lo:hi])
    return result


def audit(model_path):
    model = gp.read(str(model_path))
    variables = model.getVars()
    constraints = model.getConstrs()
    matrix = model.getA().tocsr()
    assert model.ModelSense == 1 and model.ObjCon == 0
    assert len(variables) == 102600 and len(constraints) == 360900 and model.NumNZs == 1260900
    assert all(v.VType in (gp.GRB.BINARY, gp.GRB.INTEGER) and v.LB == 0 and v.UB == 1 for v in variables)

    x_names = {v.VarName for v in variables if v.VarName.startswith("x#")}
    u_names = {v.VarName for v in variables if v.VarName.startswith("u#")}
    y_names = {v.VarName for v in variables if v.VarName.startswith("y#")}
    slack_names = {v.VarName for v in variables if v.VarName.startswith("slack#")}
    assert len(x_names) == BLOCKS
    assert len(u_names) == BLOCKS * N
    assert len(y_names) == BLOCKS * RECORDS
    assert len(slack_names) == RECORDS
    assert len(x_names | u_names | y_names | slack_names) == len(variables)
    assert x_names == {f"x#{c}" for c in range(BLOCKS)}
    assert u_names == {f"u#{c}#{v}" for c in range(BLOCKS) for v in range(N)}
    for variable in variables:
        assert variable.Obj == (-1 if variable.VarName in x_names else 0)

    # Recover the 300 oriented edge records from the exact packing rows.
    oriented_records = []
    once_rows = []
    for row, constraint in enumerate(constraints):
        if not constraint.ConstrName.startswith("m_once_"):
            continue
        terms = row_terms(matrix, variables, row)
        y = [name for name in terms if name.startswith("y#")]
        slack = [name for name in terms if name.startswith("slack#")]
        assert constraint.Sense == "=" and constraint.RHS == 1
        assert len(y) == BLOCKS and len(slack) == 1 and set(terms.values()) == {1}
        triples = [parse_y(name) for name in y]
        endpoints = {(a, b) for _, a, b in triples}
        assert len(endpoints) == 1 and {c for c, _, _ in triples} == set(range(BLOCKS))
        a, b = next(iter(endpoints))
        assert slack[0] == f"slack#{a}#{b}"
        oriented_records.append((a, b))
        once_rows.append(row)
    assert len(oriented_records) == RECORDS and len(set(oriented_records)) == RECORDS
    oriented_set = set(oriented_records)
    assert y_names == {f"y#{c}#{a}#{b}" for c in range(BLOCKS) for a, b in oriented_records}
    assert slack_names == {f"slack#{a}#{b}" for a, b in oriented_records}

    counts = Counter()
    xor_masks = defaultdict(int)
    for row, constraint in enumerate(constraints):
        terms = row_terms(matrix, variables, row)
        names = set(terms)
        if row in once_rows:
            counts["edge_capacity"] += 1
            continue
        if len(terms) == 1:
            name = next(iter(terms))
            c, v = parse_u(name)
            assert v == 0 and terms[name] == 1 and constraint.Sense == "=" and constraint.RHS == 0
            counts["root_fixed"] += 1
            continue
        selected_x = [name for name in names if name.startswith("x#")]
        if selected_x:
            assert len(selected_x) == 1 and len(terms) == RECORDS + 1
            x = selected_x[0]
            c = int(x.split("#")[1])
            assert terms[x] == 1 and constraint.Sense == "<" and constraint.RHS == 0
            other = names - {x}
            assert other == {f"y#{c}#{a}#{b}" for a, b in oriented_records}
            assert all(terms[name] == -1 for name in other)
            counts["active_implies_nonempty"] += 1
            continue

        selected_y = [name for name in names if name.startswith("y#")]
        assert len(selected_y) == 1 and len(terms) == 3
        y = selected_y[0]
        c, a, b = parse_y(y)
        assert (a, b) in oriented_set and terms[y] == 1
        assert names - {y} == {f"u#{c}#{a}", f"u#{c}#{b}"}
        ca, cb = terms[f"u#{c}#{a}"], terms[f"u#{c}#{b}"]
        if constraint.Sense == ">" and constraint.RHS == 0 and (ca, cb) == (1, -1):
            bit = 1
        elif constraint.Sense == ">" and constraint.RHS == 0 and (ca, cb) == (-1, 1):
            bit = 2
        elif constraint.Sense == "<" and constraint.RHS == 0 and (ca, cb) == (-1, -1):
            bit = 4
        elif constraint.Sense == "<" and constraint.RHS == 2 and (ca, cb) == (1, 1):
            bit = 8
        else:
            raise AssertionError((constraint.ConstrName, terms, constraint.Sense, constraint.RHS))
        assert not (xor_masks[y] & bit)
        xor_masks[y] |= bit
        counts["xor_rows"] += 1

    assert counts == {
        "xor_rows": 4 * BLOCKS * RECORDS,
        "root_fixed": BLOCKS,
        "active_implies_nonempty": BLOCKS,
        "edge_capacity": RECORDS,
    }
    assert set(xor_masks) == y_names and set(xor_masks.values()) == {15}
    unique_edges = sorted({tuple(sorted(edge)) for edge in oriented_records})
    multiplicity = Counter(tuple(sorted(edge)) for edge in oriented_records)
    assert len(unique_edges) == 275 and sorted(multiplicity.values()).count(2) == 25
    edge_text = "".join(f"{a}\t{b}\n" for a, b in unique_edges).encode("ascii")
    return {
        "verified": True,
        "solver_calls": 0,
        "gurobi_role": "MPS reader only",
        "variables_checked": len(variables),
        "rows_checked": len(constraints),
        "nonzeros_checked": model.NumNZs,
        "candidate_cut_blocks": BLOCKS,
        "oriented_edge_records": len(oriented_records),
        "unique_undirected_edges": len(unique_edges),
        "reversed_duplicate_pairs": 25,
        "row_types": dict(counts),
        "canonical_edge_list_sha256": hashlib.sha256(edge_text).hexdigest(),
        "reduction_necessity": (
            "Any original objective at most -10 activates at least ten x blocks. Their XOR rows make ten "
            "nonempty cuts and the edge-capacity rows make them pairwise edge-disjoint."
        ),
        "reduction_sufficiency": (
            "Any ten pairwise edge-disjoint nonempty cuts can populate ten original blocks; inactive blocks "
            "are zero and each slack is one exactly when its edge record is unused, giving objective -10."
        ),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = audit(args.model)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
