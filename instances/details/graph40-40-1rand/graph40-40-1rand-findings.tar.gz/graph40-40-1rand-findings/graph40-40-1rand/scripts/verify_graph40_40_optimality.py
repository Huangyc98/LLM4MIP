#!/usr/bin/env python3
"""Verify the original-MPS -> CNF -> LRAT -> optimum -9 chain."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path

import gurobipy as gp


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_incumbent(model_path, solution_path):
    values = {}
    opener = gzip.open if solution_path.suffix == ".gz" else open
    with opener(solution_path, "rt", encoding="latin-1") as stream:
        for line in stream:
            fields = line.split()
            if len(fields) != 2 or fields[0].startswith(("#", "=")):
                continue
            try:
                values[fields[0]] = float(fields[1])
            except ValueError:
                pass
    model = gp.read(str(model_path))
    variables = model.getVars()
    constraints = model.getConstrs()
    by_name = {v.VarName: i for i, v in enumerate(variables)}
    assert set(values) <= set(by_name)
    vector = [values.get(v.VarName, 0.0) for v in variables]
    assert all(value in (0.0, 1.0) for value in vector)
    assert all(v.LB <= vector[i] <= v.UB for i, v in enumerate(variables))
    activity = model.getA().dot(vector)
    violations = []
    for i, row in enumerate(constraints):
        lhs = float(activity[i])
        if row.Sense == "=":
            violation = abs(lhs - row.RHS)
        elif row.Sense == "<":
            violation = max(0.0, lhs - row.RHS)
        else:
            violation = max(0.0, row.RHS - lhs)
        violations.append(violation)
    objective = sum(v.Obj * vector[i] for i, v in enumerate(variables)) + model.ObjCon
    assert objective == -9 and max(violations) == 0
    return {
        "verified": True,
        "objective": objective,
        "variables_checked": len(variables),
        "rows_checked": len(constraints),
        "maximum_row_violation": max(violations),
        "maximum_bound_or_integrality_violation": 0,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--proof-dir", type=Path, default=ROOT / "experiments" / "sat-k10-20260907")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    audit_module = load("graph40_40_audit", HERE / "audit_graph40_40_original.py")
    sat_module = load("graph40_40_sat", HERE / "graph40_40_sat.py")
    lrat_module = load("graph40_40_lrat", HERE / "check_lrat_rup.py")
    model_path = ROOT / "input" / "graph40-40-1rand.mps.gz"
    solution_path = ROOT / "solutions" / "official-9.sol.gz"
    cnf_path = args.proof_dir / "10-cuts.cnf"
    lrat_path = args.proof_dir / "10-cuts.lrat"
    drat_path = args.proof_dir / "10-cuts.drat"

    original_audit = audit_module.audit(model_path)
    incumbent = verify_incumbent(model_path, solution_path)
    edges = sat_module.read_edges()
    fixture = sat_module.validate_nine_cut_fixture(edges)
    pool, clauses, _, _, _ = sat_module.encode(10, edges)
    rebuilt = (
        f"p cnf {pool.top} {len(clauses)}\n"
        + "".join(" ".join(map(str, clause)) + " 0\n" for clause in clauses)
    ).encode("ascii")
    assert rebuilt == cnf_path.read_bytes()
    proof = lrat_module.check(cnf_path, lrat_path)
    metadata = json.loads((args.proof_dir / "10-cuts-encoding.json").read_text(encoding="utf-8"))
    assert metadata["variables"] == pool.top and metadata["clauses"] == len(clauses)
    assert metadata["cnf_sha256"] == sha256(cnf_path)
    assert metadata["canonical_edge_list_sha256"] == original_audit["canonical_edge_list_sha256"]

    result = {
        "instance": "graph40-40-1rand",
        "certified_optimum": -9,
        "strict_upper_bound_from_incumbent": -9,
        "strict_lower_bound_from_unsat_ten_cut_decision": -9,
        "original_mps_audit": original_audit,
        "incumbent_validation": incumbent,
        "known_nine_cut_cnf_fixture": fixture,
        "ten_cut_cnf_rebuilt_byte_for_byte": True,
        "lrat_certificate": proof,
        "solver_calls_in_verification": 0,
        "proof_arithmetic": "integer and Boolean; Gurobi is used only to read the original MPS",
        "sha256": {
            "input_mps_gz": sha256(model_path),
            "official_solution_gz": sha256(solution_path),
            "ten_cut_cnf": sha256(cnf_path),
            "ten_cut_drat": sha256(drat_path),
            "ten_cut_lrat": sha256(lrat_path),
        },
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
