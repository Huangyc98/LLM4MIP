#!/usr/bin/env python3
"""Independent combinatorial validation of the official nine-cut witness."""

from __future__ import annotations

import importlib.util
import itertools
import json
from collections import Counter
from pathlib import Path


HERE = Path(__file__).resolve().parent
OUTPUT_DIR = HERE.parent / "artifacts"
RECONSTRUCT = HERE / "reconstruct_graph40_40.py"
EDGES = OUTPUT_DIR / "graph40-40-1rand_edges.tsv"
OUTPUT = OUTPUT_DIR / "graph40-40-1rand_k9_independent_validation.json"
N = 40


def load_reconstruction():
    spec = importlib.util.spec_from_file_location("reconstruct", RECONSTRUCT)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def main():
    reconstruction = load_reconstruction()
    edges = []
    with EDGES.open() as stream:
        next(stream)
        edges.extend(tuple(map(int, line.split())) for line in stream)
    adjacency = [0] * N
    edge_index = {edge: index for index, edge in enumerate(edges)}
    for u, v in edges:
        adjacency[u] |= 1 << v
        adjacency[v] |= 1 << u

    objective, _, active, shores, _, _ = reconstruction.parse_solution()
    cuts = [set(shores[block]) for block in active]
    crossing = [
        [index for index, (u, v) in enumerate(edges) if (u in shore) != (v in shore)]
        for shore in cuts
    ]
    anchors = [min(indices) for indices in crossing]
    ordered = sorted(range(len(cuts)), key=lambda index: anchors[index])
    edge_use = Counter(edge for indices in crossing for edge in indices)

    cliques = reconstruction.maximal_cliques(adjacency)
    clique_split_counts = []
    full = (1 << N) - 1
    masks = [sum(1 << v for v in shore) for shore in cuts]
    for clique in cliques:
        clique_split_counts.append(
            sum(bool(clique & shore and clique & (full ^ shore)) for shore in masks)
        )

    induced_c5_count = 0
    maximum_c5_crossings = 0
    c5_histogram = Counter()
    for subset in itertools.combinations(range(N), 5):
        induced_edges = [
            edge_index[(u, v)]
            for u, v in itertools.combinations(subset, 2)
            if (u, v) in edge_index
        ]
        if len(induced_edges) != 5:
            continue
        degree = Counter()
        for index in induced_edges:
            u, v = edges[index]
            degree[u] += 1
            degree[v] += 1
        if any(degree[v] != 2 for v in subset):
            continue
        induced_c5_count += 1
        total_crossings = sum(edge_use[index] for index in induced_edges)
        maximum_c5_crossings = max(maximum_c5_crossings, total_crossings)
        c5_histogram[total_crossings] += 1

    selected_singletons = []
    all_singleton_cuts = True
    for shore in cuts:
        if len(shore) == 1:
            selected_singletons.append(next(iter(shore)))
        elif len(shore) == N - 1:
            selected_singletons.append(next(iter(set(range(N)) - shore)))
        else:
            all_singleton_cuts = False
    internal_selected_edges = [
        [u, v] for u, v in edges if u in selected_singletons and v in selected_singletons
    ]

    report = {
        "instance": "graph40-40-1rand",
        "official_objective": objective,
        "active_blocks": active,
        "cut_count": len(cuts),
        "all_cuts_are_singleton_or_complement_singleton": all_singleton_cuts,
        "selected_vertices": sorted(selected_singletons),
        "selected_vertices_independent": not internal_selected_edges,
        "internal_selected_edges": internal_selected_edges,
        "unique_edge_capacity_maximum_use": max(edge_use.values()),
        "unique_edge_capacities_valid": all(value <= 1 for value in edge_use.values()),
        "cut_edge_counts": [len(indices) for indices in crossing],
        "original_anchor_indices": anchors,
        "anchor_sorted_block_order": [active[index] for index in ordered],
        "sorted_anchor_indices": [anchors[index] for index in ordered],
        "strict_anchor_order_valid": all(
            anchors[ordered[i]] < anchors[ordered[i + 1]] for i in range(len(ordered) - 1)
        ),
        "maximal_cliques": len(cliques),
        "maximum_cuts_splitting_one_maximal_clique": max(clique_split_counts),
        "all_maximal_clique_inequalities_valid": max(clique_split_counts) <= 1,
        "induced_c5_count": induced_c5_count,
        "maximum_total_used_edges_on_an_induced_c5": maximum_c5_crossings,
        "c5_total_used_edge_histogram": dict(sorted(c5_histogram.items())),
        "all_induced_c5_inequalities_valid": maximum_c5_crossings <= 4,
    }
    OUTPUT.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
