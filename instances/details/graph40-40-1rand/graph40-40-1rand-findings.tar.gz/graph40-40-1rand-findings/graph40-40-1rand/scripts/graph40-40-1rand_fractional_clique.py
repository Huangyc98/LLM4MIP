#!/usr/bin/env python3
"""Cutting-plane test for a fractional clique cut certificate on graph40-40-1rand.

We seek nonnegative weights w_C on maximal cliques such that every nontrivial
vertex cut splits cliques of total weight at least one.  Their minimum total
weight is computed by row generation.  Separation is an exact 0/1 model (up
to the floating-point optimizer), with vertex 0 fixed on one shore.

The script intentionally talks to gurobi_cl through temporary LP/SOL files so
it does not depend on gurobipy.  Every optimizer call uses one thread and a
30-second time limit.
"""

from __future__ import annotations

import json
import itertools
import subprocess
import sys
import tempfile
from fractions import Fraction
from pathlib import Path


HERE = Path(__file__).resolve().parent
OUTPUT_DIR = HERE.parent / "artifacts"
EDGE_FILE = OUTPUT_DIR / "graph40-40-1rand_edges.tsv"
BASE_PREFIX = "graph40-40-1rand_fractional_clique"
N = 40
GUROBI = "/usr/local/bin/gurobi_cl"


def bits(mask: int):
    while mask:
        bit = mask & -mask
        yield bit.bit_length() - 1
        mask ^= bit


def popcount(mask: int) -> int:
    return bin(mask).count("1")


def read_graph():
    adjacency = [0] * N
    with EDGE_FILE.open() as stream:
        next(stream)
        for line in stream:
            u, v = map(int, line.split())
            adjacency[u] |= 1 << v
            adjacency[v] |= 1 << u
    return adjacency


def maximal_cliques(adjacency):
    answer = []

    def bron_kerbosch(r, p, x):
        if not p and not x:
            answer.append(r)
            return
        union = p | x
        pivot = max(bits(union), key=lambda v: popcount(p & adjacency[v])) if union else 0
        candidates = p & ~adjacency[pivot]
        while candidates:
            bit = candidates & -candidates
            v = bit.bit_length() - 1
            bron_kerbosch(r | bit, p & adjacency[v], x & adjacency[v])
            p ^= bit
            x |= bit
            candidates ^= bit

    bron_kerbosch(0, (1 << N) - 1, 0)
    return sorted(answer, key=lambda c: (tuple(bits(c))))


def induced_five_cycles(adjacency):
    answer = []
    for vertices in itertools.combinations(range(N), 5):
        vertex_mask = sum(1 << v for v in vertices)
        if all(popcount(adjacency[v] & vertex_mask) == 2 for v in vertices):
            answer.append(vertex_mask)
    return answer


def cycle_edges(cycles, adjacency):
    answer = []
    for cycle in cycles:
        vertices = list(bits(cycle))
        edges = []
        for index, u in enumerate(vertices):
            for v in vertices[index + 1:]:
                if adjacency[u] & (1 << v):
                    edges.append((u, v))
        assert len(edges) == 5
        answer.append(edges)
    return answer


def split_indices(mask, objects):
    full = (1 << N) - 1
    other = full ^ mask
    return [i for i, obj in enumerate(objects) if obj & mask and obj & other]


def cut_coefficients(mask, objects, clique_count, c5_edges, strong_odd_cycle):
    full = (1 << N) - 1
    other = full ^ mask
    coefficients = []
    for i, obj in enumerate(objects):
        if not (obj & mask and obj & other):
            coefficients.append(0)
        elif i < clique_count or not strong_odd_cycle:
            coefficients.append(1)
        else:
            crossing = sum(((mask >> u) & 1) != ((mask >> v) & 1) for u, v in c5_edges[i - clique_count])
            assert crossing in (2, 4)
            coefficients.append(crossing // 2)
    return coefficients


def linear_sum(terms):
    return " + ".join(terms) if terms else "0"


def write_master(path, cuts, objects, capacities, clique_count, c5_edges, strong_odd_cycle):
    terms = [f"w{i}" if capacity == 1 else f"{capacity} w{i}" for i, capacity in enumerate(capacities)]
    lines = ["Minimize", " obj: " + linear_sum(terms), "Subject To"]
    for k, mask in enumerate(cuts):
        coefficients = cut_coefficients(mask, objects, clique_count, c5_edges, strong_odd_cycle)
        row_terms = [
            f"w{i}" if coefficient == 1 else f"{coefficient} w{i}"
            for i, coefficient in enumerate(coefficients)
            if coefficient
        ]
        lines.append(f" cut{k}: " + linear_sum(row_terms) + " >= 1")
    lines.extend(["Bounds"])
    lines.extend(f" w{i} >= 0" for i in range(len(objects)))
    lines.append("End")
    path.write_text("\n".join(lines) + "\n")


def write_separation(path, weights, objects, clique_count, c5_edges, graph_edges, strong_odd_cycle):
    if strong_odd_cycle:
        return write_strong_odd_separation(
            path, weights, objects, clique_count, c5_edges, graph_edges
        )
    objective = [f"{weight:.17g} z{i}" for i, weight in enumerate(weights) if weight > 1e-12]
    lines = ["Minimize", " obj: " + linear_sum(objective), "Subject To"]
    # x0 is fixed to zero, and at least one other vertex is on the other shore.
    lines.append(" nonempty: " + linear_sum([f"x{v}" for v in range(1, N)]) + " >= 1")
    lines.append(" root: x0 = 0")
    row = 0
    for i, obj in enumerate(objects):
        vertices = list(bits(obj))
        first = vertices[0]
        for v in vertices[1:]:
            lines.append(f" a{row}: z{i} - x{v} + x{first} >= 0")
            row += 1
            lines.append(f" a{row}: z{i} + x{v} - x{first} >= 0")
            row += 1
    lines.append("Binary")
    lines.extend(" " + " ".join(f"x{v}" for v in range(start, min(start + 20, N))) for start in range(0, N, 20))
    lines.extend(" " + " ".join(f"z{i}" for i in range(start, min(start + 20, len(objects)))) for start in range(0, len(objects), 20))
    lines.append("End")
    path.write_text("\n".join(lines) + "\n")


def write_strong_odd_separation(path, weights, objects, clique_count, c5_edges, graph_edges):
    edge_index = {edge: i for i, edge in enumerate(graph_edges)}
    edge_weights = [0.0] * len(graph_edges)
    for cycle_index, edges in enumerate(c5_edges):
        weight = weights[clique_count + cycle_index] / 2
        for edge in edges:
            edge_weights[edge_index[edge]] += weight
    objective = [f"{weights[i]:.17g} z{i}" for i in range(clique_count) if weights[i] > 1e-12]
    objective.extend(
        f"{weight:.17g} q{i}" for i, weight in enumerate(edge_weights) if weight > 1e-12
    )
    lines = ["Minimize", " obj: " + linear_sum(objective), "Subject To"]
    lines.append(" nonempty: " + linear_sum([f"x{v}" for v in range(1, N)]) + " >= 1")
    lines.append(" root: x0 = 0")
    row = 0
    for i, clique in enumerate(objects[:clique_count]):
        vertices = list(bits(clique))
        first = vertices[0]
        for v in vertices[1:]:
            lines.append(f" a{row}: z{i} - x{v} + x{first} >= 0")
            row += 1
            lines.append(f" a{row}: z{i} + x{v} - x{first} >= 0")
            row += 1
    for edge_index_value, (u, v) in enumerate(graph_edges):
        lines.append(f" a{row}: q{edge_index_value} - x{v} + x{u} >= 0")
        row += 1
        lines.append(f" a{row}: q{edge_index_value} + x{v} - x{u} >= 0")
        row += 1
    lines.append("Binary")
    lines.extend(" " + " ".join(f"x{v}" for v in range(start, min(start + 20, N))) for start in range(0, N, 20))
    lines.extend(" " + " ".join(f"z{i}" for i in range(start, min(start + 20, clique_count))) for start in range(0, clique_count, 20))
    lines.extend(" " + " ".join(f"q{i}" for i in range(start, min(start + 20, len(graph_edges)))) for start in range(0, len(graph_edges), 20))
    lines.append("End")
    path.write_text("\n".join(lines) + "\n")


def write_singleton_dual(path, objects, capacities):
    """Dual of the master containing only the 40 singleton-cut rows."""
    lines = ["Maximize", " obj: " + linear_sum([f"y{v}" for v in range(N)]), "Subject To"]
    for i, (obj, capacity) in enumerate(zip(objects, capacities)):
        lines.append(f" object{i}: " + linear_sum([f"y{v}" for v in bits(obj)]) + f" <= {capacity}")
    lines.append("Bounds")
    lines.extend(f" y{v} >= 0" for v in range(N))
    lines.append("End")
    path.write_text("\n".join(lines) + "\n")


def write_cut_dual(path, cuts, objects, capacities, clique_count, c5_edges, strong_odd_cycle):
    """Explicit dual of a finite restricted cut master."""
    lines = ["Maximize", " obj: " + linear_sum([f"d{k}" for k in range(len(cuts))]), "Subject To"]
    for i, (obj, capacity) in enumerate(zip(objects, capacities)):
        row_terms = []
        for k, cut in enumerate(cuts):
            coefficient = cut_coefficients(
                cut, [obj], 1 if i < clique_count else 0,
                [] if i < clique_count else [c5_edges[i - clique_count]],
                strong_odd_cycle,
            )[0]
            if coefficient:
                row_terms.append(f"d{k}" if coefficient == 1 else f"{coefficient} d{k}")
        lines.append(f" object{i}: " + linear_sum(row_terms) + f" <= {capacity}")
    lines.append("Bounds")
    lines.extend(f" d{k} >= 0" for k in range(len(cuts)))
    lines.append("End")
    path.write_text("\n".join(lines) + "\n")


def solve(lp, sol, log, *, timelimit=30):
    command = [
        GUROBI,
        "Threads=1",
        f"TimeLimit={timelimit}",
        "MIPGap=0",
        "IntFeasTol=1e-9",
        "FeasibilityTol=1e-9",
        f"LogFile={log}",
        f"ResultFile={sol}",
        str(lp),
    ]
    result = subprocess.run(command, text=True, capture_output=True, check=False)
    if result.returncode:
        raise RuntimeError(result.stdout + "\n" + result.stderr)
    text = result.stdout
    if "Time limit reached" in text:
        raise RuntimeError("separation/master hit the 30-second limit\n" + text[-2000:])
    return text


def read_solution(path, prefix, count):
    values = [0.0] * count
    objective = None
    for line in path.read_text().splitlines():
        if line.startswith("# Objective value ="):
            objective = float(line.split("=", 1)[1])
        elif line and not line.startswith("#"):
            name, value = line.split()
            if name.startswith(prefix):
                values[int(name[len(prefix):])] = float(value)
    return objective, values


def main():
    adjacency = read_graph()
    cliques = maximal_cliques(adjacency)
    strong_odd_cycle = "--c5-odd" in sys.argv[1:]
    use_c5 = "--c5" in sys.argv[1:] or strong_odd_cycle
    cycles = induced_five_cycles(adjacency) if use_c5 else []
    c5_edge_lists = cycle_edges(cycles, adjacency)
    graph_edges = [
        (u, v)
        for u in range(N)
        for v in range(u + 1, N)
        if adjacency[u] & (1 << v)
    ]
    objects = cliques + cycles
    capacities = [1] * len(cliques) + [2] * len(cycles)
    prefix = BASE_PREFIX + ("_c5_odd" if strong_odd_cycle else "_c5" if use_c5 else "")
    # Singleton cuts are strong, deterministic seed rows.
    cuts = [1 << v for v in range(N)]
    cut_set = set(cuts)
    trace = []
    final_weights = None

    singleton_dual_objective = None
    singleton_dual_weights = None
    final_dual_objective = None
    final_dual_weights = None
    with tempfile.TemporaryDirectory(prefix=prefix + "_") as temp_name:
        temp = Path(temp_name)
        dual_lp = temp / "singleton-dual.lp"
        dual_sol = temp / "singleton-dual.sol"
        dual_log = temp / "singleton-dual.log"
        write_singleton_dual(dual_lp, objects, capacities)
        solve(dual_lp, dual_sol, dual_log)
        singleton_dual_objective, singleton_dual_weights = read_solution(dual_sol, "y", N)
        for iteration in range(1000):
            master_lp = temp / "master.lp"
            master_sol = temp / "master.sol"
            master_log = temp / "master.log"
            write_master(
                master_lp, cuts, objects, capacities, len(cliques), c5_edge_lists,
                strong_odd_cycle,
            )
            solve(master_lp, master_sol, master_log)
            master_obj, weights = read_solution(master_sol, "w", len(objects))

            sep_lp = temp / "separation.lp"
            sep_sol = temp / "separation.sol"
            sep_log = temp / "separation.log"
            write_separation(
                sep_lp, weights, objects, len(cliques), c5_edge_lists, graph_edges,
                strong_odd_cycle,
            )
            solve(sep_lp, sep_sol, sep_log)
            sep_obj, x_values = read_solution(sep_sol, "x", N)
            mask = sum((1 << v) for v, value in enumerate(x_values) if value > 0.5)
            coefficients = cut_coefficients(
                mask, objects, len(cliques), c5_edge_lists, strong_odd_cycle
            )
            actual = sum(weight * coefficient for weight, coefficient in zip(weights, coefficients))
            row = {
                "iteration": iteration,
                "master_objective": master_obj,
                "minimum_cut": sep_obj,
                "recomputed_cut": actual,
                "shore": list(bits(mask)),
                "rows": len(cuts),
                "nonzero_weights": sum(weight > 1e-10 for weight in weights),
            }
            trace.append(row)
            print(json.dumps(row), flush=True)
            if actual >= 1 - 1e-8:
                final_weights = weights
                break
            if mask in cut_set:
                raise RuntimeError("separator returned an already present violated cut")
            cuts.append(mask)
            cut_set.add(mask)
        else:
            raise RuntimeError("row generation exceeded 1000 iterations")

        final_dual_lp = temp / "final-dual.lp"
        final_dual_sol = temp / "final-dual.sol"
        final_dual_log = temp / "final-dual.log"
        write_cut_dual(
            final_dual_lp, cuts, objects, capacities, len(cliques), c5_edge_lists,
            strong_odd_cycle,
        )
        solve(final_dual_lp, final_dual_sol, final_dual_log)
        final_dual_objective, final_dual_weights = read_solution(final_dual_sol, "d", len(cuts))

    payload = {
        "vertices": N,
        "maximal_cliques": len(cliques),
        "induced_five_cycles": len(cycles),
        "strong_odd_cycle_coefficients": strong_odd_cycle,
        "cliques": [list(bits(clique)) for clique in cliques],
        "objects": [list(bits(obj)) for obj in objects],
        "capacities": capacities,
        "cut_rows": [list(bits(mask)) for mask in cuts],
        "trace": trace,
        "objective": sum(capacity * weight for capacity, weight in zip(capacities, final_weights)),
        "weights": final_weights,
        "singleton_dual_objective": singleton_dual_objective,
        "singleton_dual_weights": singleton_dual_weights,
        "final_dual_objective": final_dual_objective,
        "final_dual_weights": final_dual_weights,
        "nonzero_weights": [
            {
                "index": i,
                "kind": "clique" if i < len(cliques) else "induced_C5",
                "vertices": list(bits(objects[i])),
                "capacity": capacities[i],
                "weight": weight,
            }
            for i, weight in enumerate(final_weights)
            if weight > 1e-10
        ],
    }
    output = OUTPUT_DIR / f"{prefix}_numeric.json"
    output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    print(f"wrote {output}")

    if use_c5:
        rational_weights = [Fraction(value).limit_denominator(1_000_000) for value in final_weights]
        rational_dual = [Fraction(value).limit_denominator(1_000_000) for value in final_dual_weights]
        rational_objective = sum(
            capacity * weight for capacity, weight in zip(capacities, rational_weights)
        )
        rational_dual_objective = sum(rational_dual)
        if rational_objective != rational_dual_objective:
            raise RuntimeError(
                f"rationalized primal/dual mismatch: {rational_objective} != {rational_dual_objective}"
            )
        certificate = {
            "claim": "exact optimum of maximal-clique plus induced-C5 cut-cover LP",
            "vertices": N,
            "maximal_cliques": len(cliques),
            "induced_five_cycles": len(cycles),
            "objective": {
                "numerator": rational_objective.numerator,
                "denominator": rational_objective.denominator,
            },
            "nonzero_primal_objects": [
                {
                    "index": i,
                    "kind": "maximal_clique" if i < len(cliques) else "induced_C5",
                    "vertices": list(bits(objects[i])),
                    "capacity": capacities[i],
                    "numerator": weight.numerator,
                    "denominator": weight.denominator,
                }
                for i, weight in enumerate(rational_weights)
                if weight
            ],
            "nonzero_dual_cuts": [
                {
                    "shore": list(bits(cuts[k])),
                    "numerator": weight.numerator,
                    "denominator": weight.denominator,
                }
                for k, weight in enumerate(rational_dual)
                if weight
            ],
        }
        certificate_output = OUTPUT_DIR / f"{prefix}_certificate.json"
        certificate_output.write_text(json.dumps(certificate, indent=2, sort_keys=True) + "\n")
        print(f"wrote {certificate_output}")


if __name__ == "__main__":
    main()
