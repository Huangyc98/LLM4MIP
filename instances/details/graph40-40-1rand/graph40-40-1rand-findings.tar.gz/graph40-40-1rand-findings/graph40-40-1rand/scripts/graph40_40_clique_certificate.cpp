#include "gurobi_c++.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <tuple>
#include <vector>

namespace {
constexpr int N = 40;
constexpr double TOTAL_LIMIT_SECONDS = 590.0;
using Mask = std::uint64_t;

int pc(Mask x) { return __builtin_popcountll(x); }

std::vector<int> vertices(Mask x) {
  std::vector<int> out;
  for (int v = 0; v < N; ++v)
    if (x & (Mask{1} << v)) out.push_back(v);
  return out;
}

std::string vertex_string(Mask x) {
  std::ostringstream out;
  bool first = true;
  for (int v : vertices(x)) {
    if (!first) out << ',';
    out << v;
    first = false;
  }
  return out.str();
}

void bron_kerbosch(Mask r, Mask p, Mask x, const std::vector<Mask>& adjacency,
                   std::vector<Mask>& maximal) {
  if (p == 0 && x == 0) {
    maximal.push_back(r);
    return;
  }
  Mask px = p | x;
  int pivot = -1;
  int best = -1;
  while (px) {
    const int u = __builtin_ctzll(px);
    const int score = pc(p & adjacency[u]);
    if (score > best) {
      best = score;
      pivot = u;
    }
    px &= px - 1;
  }
  Mask candidates = pivot >= 0 ? (p & ~adjacency[pivot]) : p;
  while (candidates) {
    const Mask bit = candidates & -candidates;
    const int v = __builtin_ctzll(bit);
    bron_kerbosch(r | bit, p & adjacency[v], x & adjacency[v], adjacency, maximal);
    p ^= bit;
    x |= bit;
    candidates ^= bit;
  }
}

bool split(Mask clique, Mask shore) {
  constexpr Mask full = (Mask{1} << N) - 1;
  return (clique & shore) != 0 && (clique & (full ^ shore)) != 0;
}

double elapsed(const std::chrono::steady_clock::time_point& start) {
  return std::chrono::duration<double>(std::chrono::steady_clock::now() - start).count();
}

void set_remaining_time(GRBModel& model,
                        const std::chrono::steady_clock::time_point& start) {
  const double remaining = std::max(1.0, TOTAL_LIMIT_SECONDS - elapsed(start));
  model.set(GRB_DoubleParam_TimeLimit, remaining);
}
}  // namespace

int main(int argc, char** argv) {
  if (argc != 4) {
    std::cerr << "usage: graph40_40_clique_certificate EDGES_TSV WEIGHTS_TSV CUTS_TSV\n";
    return 2;
  }
  const std::string edge_path = argv[1];
  const std::string weight_path = argv[2];
  const std::string cut_path = argv[3];
  const auto start = std::chrono::steady_clock::now();

  try {
    std::ifstream edge_file(edge_path);
    if (!edge_file) throw std::runtime_error("cannot open edge list");
    std::string line;
    std::getline(edge_file, line);  // header
    std::vector<Mask> adjacency(N, 0);
    int u, v;
    int edge_count = 0;
    while (edge_file >> u >> v) {
      if (u < 0 || u >= N || v < 0 || v >= N || u == v)
        throw std::runtime_error("invalid edge");
      adjacency[u] |= Mask{1} << v;
      adjacency[v] |= Mask{1} << u;
      ++edge_count;
    }

    std::vector<Mask> cliques;
    bron_kerbosch(0, (Mask{1} << N) - 1, 0, adjacency, cliques);
    std::sort(cliques.begin(), cliques.end(), [](Mask a, Mask b) {
      return std::make_pair(-pc(a), a) < std::make_pair(-pc(b), b);
    });
    std::cout << "graph vertices=" << N << " unique_edges=" << edge_count
              << " maximal_cliques=" << cliques.size() << '\n';

    GRBEnv env(true);
    env.set(GRB_IntParam_OutputFlag, 0);
    env.set(GRB_IntParam_Threads, 1);
    env.start();

    GRBModel master(env);
    master.set(GRB_IntParam_OutputFlag, 0);
    master.set(GRB_IntParam_Threads, 1);
    master.set(GRB_DoubleParam_FeasibilityTol, 1e-9);
    master.set(GRB_DoubleParam_OptimalityTol, 1e-9);
    std::vector<GRBVar> weight;
    weight.reserve(cliques.size());
    for (std::size_t i = 0; i < cliques.size(); ++i)
      weight.push_back(master.addVar(0.0, GRB_INFINITY, 1.0, GRB_CONTINUOUS,
                                     "w_" + std::to_string(i)));
    master.set(GRB_IntAttr_ModelSense, GRB_MINIMIZE);

    std::set<Mask> cut_pool;
    auto add_cut = [&](Mask shore) {
      constexpr Mask full = (Mask{1} << N) - 1;
      if (shore & 1) shore ^= full;  // canonical orientation: vertex 0 outside
      if (shore == 0 || shore == full || cut_pool.count(shore)) return false;
      GRBLinExpr lhs = 0.0;
      for (std::size_t i = 0; i < cliques.size(); ++i)
        if (split(cliques[i], shore)) lhs += weight[i];
      master.addConstr(lhs >= 1.0, "cut_" + std::to_string(cut_pool.size()));
      cut_pool.insert(shore);
      return true;
    };
    constexpr Mask full = (Mask{1} << N) - 1;
    add_cut(full ^ 1);  // singleton 0, represented by its complement
    for (int vertex = 1; vertex < N; ++vertex) add_cut(Mask{1} << vertex);

    GRBModel separator(env);
    separator.set(GRB_IntParam_OutputFlag, 0);
    separator.set(GRB_IntParam_Threads, 1);
    separator.set(GRB_IntParam_MIPFocus, 2);
    separator.set(GRB_DoubleParam_MIPGap, 0.0);
    separator.set(GRB_DoubleParam_FeasibilityTol, 1e-9);
    separator.set(GRB_DoubleParam_IntFeasTol, 1e-9);
    std::vector<GRBVar> side;
    for (int vertex = 0; vertex < N; ++vertex)
      side.push_back(separator.addVar(0.0, 1.0, 0.0, GRB_BINARY,
                                      "u_" + std::to_string(vertex)));
    side[0].set(GRB_DoubleAttr_UB, 0.0);
    GRBLinExpr nontrivial = 0.0;
    for (int vertex = 1; vertex < N; ++vertex) nontrivial += side[vertex];
    separator.addConstr(nontrivial >= 1.0, "nontrivial");
    std::vector<GRBVar> crossed;
    crossed.reserve(cliques.size());
    for (std::size_t i = 0; i < cliques.size(); ++i) {
      GRBVar z = separator.addVar(0.0, 1.0, 0.0, GRB_CONTINUOUS,
                                  "z_" + std::to_string(i));
      crossed.push_back(z);
      const std::vector<int> cv = vertices(cliques[i]);
      const int anchor = cv.front();
      for (std::size_t j = 1; j < cv.size(); ++j) {
        separator.addConstr(z >= side[cv[j]] - side[anchor]);
        separator.addConstr(z >= side[anchor] - side[cv[j]]);
      }
    }
    separator.set(GRB_IntAttr_ModelSense, GRB_MINIMIZE);

    std::ofstream cut_file(cut_path);
    cut_file << "iteration\tmaster_objective\tseparator_minimum\tshore\n";
    std::vector<double> final_weight;
    double final_master = GRB_INFINITY;
    double final_separation = -GRB_INFINITY;
    bool certified = false;
    int iterations = 0;
    for (; iterations < 10000 && elapsed(start) < TOTAL_LIMIT_SECONDS; ++iterations) {
      set_remaining_time(master, start);
      master.optimize();
      if (master.get(GRB_IntAttr_Status) != GRB_OPTIMAL)
        throw std::runtime_error("master did not solve to optimality");
      final_master = master.get(GRB_DoubleAttr_ObjVal);
      final_weight.resize(cliques.size());
      for (std::size_t i = 0; i < cliques.size(); ++i) {
        final_weight[i] = weight[i].get(GRB_DoubleAttr_X);
        crossed[i].set(GRB_DoubleAttr_Obj, final_weight[i]);
      }
      set_remaining_time(separator, start);
      separator.optimize();
      if (separator.get(GRB_IntAttr_Status) != GRB_OPTIMAL)
        throw std::runtime_error("separator did not solve to optimality");
      final_separation = separator.get(GRB_DoubleAttr_ObjVal);
      Mask shore = 0;
      for (int vertex = 1; vertex < N; ++vertex)
        if (side[vertex].get(GRB_DoubleAttr_X) > 0.5) shore |= Mask{1} << vertex;
      cut_file << iterations << '\t' << std::setprecision(17) << final_master << '\t'
               << final_separation << '\t' << vertex_string(shore) << '\n';
      if (iterations < 20 || iterations % 25 == 0)
        std::cout << "iteration=" << iterations << " cuts=" << cut_pool.size()
                  << " master=" << std::setprecision(12) << final_master
                  << " separation=" << final_separation
                  << " elapsed=" << elapsed(start) << '\n';
      if (final_separation >= 1.0 - 2e-8) {
        certified = true;
        break;
      }
      if (!add_cut(shore))
        throw std::runtime_error("separator returned a repeated violated cut");
    }

    std::ofstream weight_file(weight_path);
    weight_file << "clique_id\tweight\tvertices\n";
    int support = 0;
    for (std::size_t i = 0; i < cliques.size(); ++i) {
      if (final_weight[i] > 1e-10) {
        ++support;
        weight_file << i << '\t' << std::setprecision(17) << final_weight[i] << '\t'
                    << vertex_string(cliques[i]) << '\n';
      }
    }
    std::cout << "FINAL certified_floating=" << (certified ? 1 : 0)
              << " master_objective=" << std::setprecision(17) << final_master
              << " minimum_split_weight=" << final_separation
              << " support=" << support << " generated_cuts=" << cut_pool.size()
              << " iterations=" << iterations + (certified ? 1 : 0)
              << " elapsed_seconds=" << elapsed(start) << '\n';
    return certified ? 0 : 3;
  } catch (const GRBException& error) {
    std::cerr << "Gurobi error " << error.getErrorCode() << ": " << error.getMessage() << '\n';
    return 4;
  } catch (const std::exception& error) {
    std::cerr << "error: " << error.what() << '\n';
    return 5;
  }
}
