#!/usr/bin/env bash
set -u

run_dir=/home/wyc/miplib-research/graph40-40-1rand/sat-k10-20260907
cadical=/home/wyc/.miplib-tools/cadical/build/cadical
cd "$run_dir"

start_epoch=$(date +%s)
"$cadical" --unsat --no-binary -t 3600 10-cuts.cnf 10-cuts.drat > cadical.log 2>&1
exit_code=$?
end_epoch=$(date +%s)

printf '%s\n' "$exit_code" > exit.code
printf '%s\n' "$((end_epoch-start_epoch))" > elapsed.seconds
sha256sum 10-cuts.cnf 10-cuts.drat > output.sha256
date -u +%Y-%m-%dT%H:%M:%SZ > finished.utc
