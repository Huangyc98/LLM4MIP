#!/usr/bin/env python3
"""Exact, solver-independent infeasibility certificate for fhnw-binpack4-58.

The checker parses the original MPS (plain or gzip-compressed), verifies every
coefficient used by the proof, and then checks a projected-area contradiction
involving only items 0,...,29.
"""

from __future__ import annotations

import argparse
import gzip
import math
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import TextIO


N_ITEMS = 50
N_LARGE = 30


@dataclass
class MPS:
    row_sense: dict[str, str]
    row_rhs: dict[str, float]
    row_terms: dict[str, dict[str, float]]
    lower: dict[str, float]
    upper: dict[str, float]
    integer: set[str]


def open_text(path: Path) -> TextIO:
    if path.suffix.lower() == ".gz":
        return gzip.open(path, "rt", encoding="ascii")
    return path.open("rt", encoding="ascii")


def parse_mps(path: Path) -> MPS:
    section = ""
    row_sense: dict[str, str] = {}
    row_rhs: dict[str, float] = defaultdict(float)
    columns: dict[str, dict[str, float]] = defaultdict(dict)
    order: list[str] = []
    seen: set[str] = set()
    integer: set[str] = set()
    lower: dict[str, float] = {}
    upper: dict[str, float] = {}
    integer_mode = False
    section_names = {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}

    with open_text(path) as stream:
        for line_number, raw in enumerate(stream, start=1):
            tokens = raw.split()
            if not tokens or tokens[0].startswith("*"):
                continue
            if tokens[0] in section_names:
                section = tokens[0]
                if section == "ENDATA":
                    break
                continue

            if section == "ROWS":
                if len(tokens) != 2:
                    raise ValueError(f"Malformed ROWS line {line_number}: {raw.rstrip()}")
                row_sense[tokens[1]] = tokens[0]
            elif section == "COLUMNS":
                if len(tokens) >= 3 and tokens[1].strip("'") == "MARKER":
                    marker = tokens[2].strip("'")
                    if marker == "INTORG":
                        integer_mode = True
                    elif marker == "INTEND":
                        integer_mode = False
                    else:
                        raise ValueError(f"Unknown integer marker {marker}")
                    continue
                variable = tokens[0]
                if variable not in seen:
                    seen.add(variable)
                    order.append(variable)
                if integer_mode:
                    integer.add(variable)
                if (len(tokens) - 1) % 2:
                    raise ValueError(f"Malformed COLUMNS line {line_number}: {raw.rstrip()}")
                for index in range(1, len(tokens), 2):
                    row = tokens[index]
                    value = float(tokens[index + 1])
                    columns[variable][row] = columns[variable].get(row, 0.0) + value
            elif section == "RHS":
                if (len(tokens) - 1) % 2:
                    raise ValueError(f"Malformed RHS line {line_number}: {raw.rstrip()}")
                for index in range(1, len(tokens), 2):
                    row_rhs[tokens[index]] = float(tokens[index + 1])
            elif section == "RANGES":
                raise ValueError("This certificate expects no RANGES section")
            elif section == "BOUNDS":
                if len(tokens) < 3:
                    raise ValueError(f"Malformed BOUNDS line {line_number}: {raw.rstrip()}")
                bound_type, variable = tokens[0], tokens[2]
                value = float(tokens[3]) if len(tokens) == 4 else None
                if bound_type == "BV":
                    lower[variable], upper[variable] = 0.0, 1.0
                    integer.add(variable)
                elif bound_type in {"LO", "LI"}:
                    assert value is not None
                    lower[variable] = value
                    if bound_type == "LI":
                        integer.add(variable)
                elif bound_type in {"UP", "UI"}:
                    assert value is not None
                    upper[variable] = value
                    if bound_type == "UI":
                        integer.add(variable)
                elif bound_type == "FX":
                    assert value is not None
                    lower[variable] = upper[variable] = value
                elif bound_type == "FR":
                    lower[variable], upper[variable] = -math.inf, math.inf
                elif bound_type == "MI":
                    lower[variable] = -math.inf
                elif bound_type == "PL":
                    upper[variable] = math.inf
                else:
                    raise ValueError(f"Unsupported bound type {bound_type}")

    for variable in order:
        lower.setdefault(variable, 0.0)
        upper.setdefault(variable, math.inf)

    row_terms: dict[str, dict[str, float]] = defaultdict(dict)
    for variable, entries in columns.items():
        for row, value in entries.items():
            if value:
                row_terms[row][variable] = value

    return MPS(
        row_sense=row_sense,
        row_rhs=dict(row_rhs),
        row_terms=dict(row_terms),
        lower=lower,
        upper=upper,
        integer=integer,
    )


def pair_index(i: int, j: int) -> int:
    if not 0 <= i < j < N_ITEMS:
        raise ValueError((i, j))
    return i * (2 * N_ITEMS - i - 1) // 2 + (j - i - 1)


def assert_close(actual: float, expected: float, label: str) -> None:
    if not math.isclose(actual, expected, rel_tol=0.0, abs_tol=1e-12):
        raise AssertionError(f"{label}: expected {expected}, found {actual}")


def assert_row(
    mps: MPS,
    name: str,
    sense: str,
    rhs: float,
    expected_terms: dict[str, float],
) -> None:
    if mps.row_sense.get(name) != sense:
        raise AssertionError(f"{name}: expected sense {sense}, found {mps.row_sense.get(name)}")
    assert_close(mps.row_rhs.get(name, 0.0), rhs, f"{name} RHS")
    if mps.row_terms.get(name, {}) != expected_terms:
        raise AssertionError(
            f"{name}: expected terms {expected_terms}, found {mps.row_terms.get(name, {})}"
        )


def c(index: int) -> str:
    return f"C{index}"


def verify_certificate(mps: MPS) -> None:
    # Variables for large item i: orientation b_i, and lower-left coordinates
    # x_i, z_i, y_i.  The unusual order is inherited from the MPS file.
    for i in range(N_LARGE):
        b, x, z, y = c(i), c(50 + i), c(100 + i), c(150 + i)
        if b not in mps.integer or (mps.lower[b], mps.upper[b]) != (0.0, 1.0):
            raise AssertionError(f"{b} is not binary")
        for variable in (x, y, z):
            assert_close(mps.lower[variable], 0.0, f"{variable} lower bound")
        assert_close(mps.upper[x], 150.0, f"{x} upper bound")
        assert_close(mps.upper[y], 350.0, f"{y} upper bound")
        assert_close(mps.upper[z], 90.0, f"{z} upper bound")
        assert_row(mps, f"R{2*i}", "L", 130.0, {b: -20.0, x: 1.0})
        assert_row(mps, f"R{2*i+1}", "L", 350.0, {b: 20.0, y: 1.0})

    checked_pairs = 0
    for i in range(N_LARGE):
        for j in range(i + 1, N_LARGE):
            p = pair_index(i, j)
            row = 100 + 8 * p
            rel = [c(200 + 6 * p + k) for k in range(6)]
            for variable in rel:
                if variable not in mps.integer or (mps.lower[variable], mps.upper[variable]) != (0.0, 1.0):
                    raise AssertionError(f"{variable} is not binary")

            bi, bj = c(i), c(j)
            xi, xj = c(50 + i), c(50 + j)
            zi, zj = c(100 + i), c(100 + j)
            yi, yj = c(150 + i), c(150 + j)
            assert_row(mps, f"R{row}", "L", 5.0, {variable: 1.0 for variable in rel})
            assert_row(
                mps,
                f"R{row+1}",
                "G",
                230.0,
                {bi: 20.0, xi: -1.0, xj: 1.0, rel[1]: 360.0},
            )
            assert_row(
                mps,
                f"R{row+2}",
                "G",
                210.0,
                {bj: -20.0, yi: 1.0, yj: -1.0, rel[4]: 560.0},
            )
            assert_row(
                mps,
                f"R{row+3}",
                "G",
                210.0,
                {bi: -20.0, yi: -1.0, yj: 1.0, rel[5]: 560.0},
            )
            assert_row(
                mps,
                f"R{row+4}",
                "G",
                10.0,
                {zi: 1.0, zj: -1.0, rel[2]: 100.0},
            )
            assert_row(
                mps,
                f"R{row+5}",
                "G",
                10.0,
                {zi: -1.0, zj: 1.0, rel[3]: 100.0},
            )
            assert_row(
                mps,
                f"R{row+7}",
                "G",
                230.0,
                {bj: 20.0, xi: 1.0, xj: -1.0, rel[0]: 360.0},
            )
            checked_pairs += 1

    # Each large item occupies a yz rectangle of height 10 and width
    # 210+20*b_i.  Its two x-separation disjuncts cannot be active: setting
    # either associated relation variable to zero would require an x-coordinate
    # difference >= 230-20*b >= 210, while every x is in [0,150].  Therefore
    # the six-way disjunction makes every pair disjoint in y or z.  Their yz
    # projections are consequently pairwise interior-disjoint.
    max_x_difference = 150
    min_x_size = 210
    minimum_projection_area = N_LARGE * 210 * 10
    container_projection_area = 560 * 100
    contradiction = minimum_projection_area - container_projection_area

    if max_x_difference >= min_x_size:
        raise AssertionError("x-separation impossibility was not established")
    if contradiction <= 0:
        raise AssertionError("projected-area contradiction was not established")

    print(f"verified_large_items={N_LARGE}")
    print(f"verified_large_item_pairs={checked_pairs}")
    print(
        "x_separation_impossible: "
        f"max_coordinate_difference={max_x_difference} < min_item_length={min_x_size}"
    )
    print(
        "yz_projection: pairwise_disjoint=true "
        f"minimum_required_area={minimum_projection_area} "
        f"container_area={container_projection_area} excess={contradiction}"
    )
    print("CERTIFICATE VERIFIED: fhnw-binpack4-58 is infeasible")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    args = parser.parse_args()
    verify_certificate(parse_mps(args.mps))


if __name__ == "__main__":
    main()
