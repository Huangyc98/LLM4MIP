#!/usr/bin/env python3
"""Decode the indexed 3-D bin-packing formulation in fhnw-binpack4-58."""

from __future__ import annotations

import argparse
from collections import Counter
from pathlib import Path

import gurobipy as gp


N_ITEMS = 50
N_DIMS = 3
N_RELATIONS = 6


def terms(model: gp.Model, row: gp.Constr) -> list[tuple[str, float]]:
    expression = model.getRow(row)
    return [
        (expression.getVar(index).VarName, expression.getCoeff(index))
        for index in range(expression.size())
    ]


def pair_index(i: int, j: int) -> int:
    """Lexicographic index of pair (i,j), 0 <= i < j < N_ITEMS."""
    return i * (2 * N_ITEMS - i - 1) // 2 + (j - i - 1)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("--all-items", action="store_true")
    args = parser.parse_args()

    model = gp.read(str(args.mps))
    model.update()
    variables = model.getVars()
    rows = model.getConstrs()

    expected_pairs = N_ITEMS * (N_ITEMS - 1) // 2
    assert len(variables) == N_ITEMS + N_ITEMS * N_DIMS + expected_pairs * N_RELATIONS
    assert len(rows) == N_ITEMS * 2 + expected_pairs * 8

    print(
        f"model={model.ModelName} rows={model.NumConstrs} cols={model.NumVars} "
        f"nonzeros={model.NumNZs}"
    )
    print(f"variable_types={Counter(v.VType for v in variables)}")
    print(f"bounds={Counter((v.LB, v.UB) for v in variables)}")
    print(f"row_senses={Counter(row.Sense for row in rows)}")
    print(f"rhs={Counter(row.RHS for row in rows)}")

    print("item_row_examples")
    item_ids = range(N_ITEMS) if args.all_items else range(3)
    for i in item_ids:
        for row in rows[2 * i : 2 * i + 2]:
            print(row.ConstrName, row.Sense, row.RHS, terms(model, row))

    print("pair_row_examples")
    for i, j in [(0, 1), (0, 2), (1, 2), (29, 30), (30, 31), (48, 49)]:
        offset = N_ITEMS * 2 + pair_index(i, j) * 8
        print(f"pair=({i},{j}) pair_index={pair_index(i,j)} rows={offset}:{offset+8}")
        for row in rows[offset : offset + 8]:
            print(row.ConstrName, row.Sense, row.RHS, terms(model, row))


if __name__ == "__main__":
    main()
