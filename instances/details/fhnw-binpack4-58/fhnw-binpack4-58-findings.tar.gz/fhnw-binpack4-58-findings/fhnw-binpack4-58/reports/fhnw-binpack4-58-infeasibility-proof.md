# `fhnw-binpack4-58` 不可行性证明

## 结论

原始文件 `fhnw-binpack4-58.mps.gz` **不可行**。证明只使用前 30 件大物体及其 435 对两两不重叠约束，不依赖后 20 件物体，也不依赖浮点求解器的搜索结论。

证书检查器对原始 MPS 中证明所用的每个变量类型、界、行方向、右端项和系数进行核对，然后验证一个严格的二维投影面积矛盾：

```text
verified_large_items=30
verified_large_item_pairs=435
x_separation_impossible: max_coordinate_difference=150 < min_item_length=210
yz_projection: pairwise_disjoint=true minimum_required_area=63000 container_area=56000 excess=7000
CERTIFICATE VERIFIED: fhnw-binpack4-58 is infeasible
```

原始压缩文件的 SHA-256 为：

```text
8A6F2581D61E56C38DDAA2FE625E2DF1A67871E6D39DC661A148D07994BBEAE3
```

## 模型结构

Gurobi 13.0.1 读取的原始模型规模为：

- 9900 行、7550 列、35750 个非零元；
- 7400 个二元变量、150 个连续变量；
- 目标函数恒为 0，因此这是纯可行性问题；
- 50 个长方体、每件 3 个连续坐标、每对物体 6 个方向二元变量；
- `50 choose 2 = 1225` 对物体，每对有 8 行约束。

MIPLIB 的公开页面仍将该实例列为 `open`、`no_solution`，给出的描述是“带附加约束的 3D 装箱可行性问题”：<https://miplib.zib.de/instance_details_fhnw-binpack4-58.html>。

前 30 件物体的变量映射如下，其中 `i=0,...,29`：

| 含义 | MPS 变量 |
|---|---|
| 朝向 `b_i` | `C_i` |
| x 坐标 `x_i` | `C_(50+i)` |
| z 坐标 `z_i` | `C_(100+i)` |
| y 坐标 `y_i` | `C_(150+i)` |

`b_i` 是二元变量。MPS 的界和第 `2i,2i+1` 行给出

```text
0 <= x_i <= 150,   x_i - 20 b_i <= 130,
0 <= y_i <= 350,   y_i + 20 b_i <= 350,
0 <= z_i <= 90.
```

因此第 `i` 件大物体可解释为放在 `360 × 560 × 100` 容器内、左下角为 `(x_i,y_i,z_i)` 的长方体，尺寸为

```text
w_i = 230 - 20 b_i,
d_i = 210 + 20 b_i,
h_i = 10.
```

即平面尺寸在 `230×210` 与 `210×230` 之间旋转。

## 不可行性证明

### 1. 任意两件大物体都不可能沿 x 方向分开

对任意 `0 <= i < j < 30`，MPS 的六方向析取包含两个 x 方向：

```text
x_j - x_i >= 230 - 20 b_i = w_i,
```

或

```text
x_i - x_j >= 230 - 20 b_j = w_j.
```

但 `b_i,b_j` 为二元变量，所以 `w_i,w_j >= 210`；另一方面 `x_i,x_j` 均在 `[0,150]` 中，任意坐标差最多为 150。故两个 x 方向都不可能成立，严格余量至少为 `210-150=60`。

### 2. 所有大物体的 yz 投影两两不重叠

每对物体的六个方向二元变量均为 0/1，且 MPS 约束它们之和不超过 5，所以至少有一个方向必须被激活。两个 x 方向已经证明不可能，故每对大物体必定沿 y 或 z 分开。

于是每件大物体在 yz 平面上的投影

```text
[y_i, y_i + d_i] × [z_i, z_i + 10]
```

都位于 `560×100` 的容器截面中，并且这些投影两两内部不相交。

### 3. 投影面积矛盾

每个投影的面积至少为

```text
d_i × 10 >= 210 × 10 = 2100.
```

30 个两两不重叠投影需要的总面积至少为

```text
30 × 2100 = 63000.
```

容器 yz 截面的面积只有

```text
560 × 100 = 56000.
```

所以必须有 `63000 <= 56000`，矛盾为 7000。原模型不可行。

## 求解器交叉检查

通用 MIP 搜索本身没有在短时间内识别上述全局投影面积矛盾：

| 求解器/机器 | 限时 | presolve 后规模 | 搜索结果 |
|---|---:|---:|---|
| Gurobi 13.0.1 / euler4 | 60 秒 | 7253 行、6080 列、27846 非零元 | 96552 节点，无可行解，超时 |
| COPT 8.0.4 / altman | 60 秒 | 7253 行、6080 列、27846 非零元 | 无可行解，超时 |

这两个运行只用于独立核对模型读取、presolve 结构和通用搜索表现；最终不可行结论来自上面的精确几何证明。

## 复核命令

检查压缩的原始输入：

```powershell
python .\test\fhnw_binpack_infeasibility_certificate.py .\test\fhnw-binpack4-58.mps.gz
```

检查解压后的输入：

```powershell
python .\test\fhnw_binpack_infeasibility_certificate.py .\test\fhnw-binpack4-58.mps
```

证书检查器只使用 Python 标准库，不需要 Gurobi 或 COPT。
