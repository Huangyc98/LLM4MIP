# `cvrpp-n16k8vrpi`

## Result

The exact optimum is **450**.

The MPS encodes the CVRP instance `P-n16-k8`. An independent dynamic program enumerates all capacity-feasible customer subsets, computes the exact shortest depot tour for each subset, and partitions all 15 customers into exactly eight routes. It visits 996 partition states and proves a lower and upper bound of 450.

The stored certificate contains the eight optimal routes, their demands and costs. This proof does not rely on the weak lower bound of the generic MPS formulation.

## Input

- SHA-256: `D07CA11A223231562842334A053EA4D891C33D74C7245CCCB4FCC0FAB3216B86`
- Customers: 15; vehicles: 8; vehicle capacity: 35; total demand: 246.

## Reproduce the certificate

```powershell
python .\instances\cvrpp-n16k8vrpi\scripts\cvrpp_n16k8_exact_dp.py `
  --vrp .\instances\cvrpp-n16k8vrpi\artifacts\P-n16-k8.vrp `
  --json cvrpp-certificate.json
```

Compare the output with [the checked-in certificate](artifacts/cvrpp-n16k8-exact-certificate.json). The MPS solution is available as [verified450.sol](solutions/cvrpp-n16k8vrpi-verified450.sol).
