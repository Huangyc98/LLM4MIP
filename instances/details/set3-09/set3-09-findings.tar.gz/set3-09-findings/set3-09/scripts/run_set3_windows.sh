#!/usr/bin/env bash
set -u
base=/home/huangyicheng/miplib-rmine13-set3-09-20260908-agent-rmine_set3
export PYTHONPATH=/home/huangyicheng/copt80/lib/python/310
export LD_LIBRARY_PATH=/home/huangyicheng/copt80/lib:/home/huangyicheng/copt80/lib/python/deps
cd "$base" || exit 2
for window in 1-4 3-6 5-8 7-10 9-12 11-14 13-16; do
  python3 analysis/copt_structured_search.py \
    --model instances/set3-09.mps.gz \
    --start instances/set3-09-public.sol.gz \
    --outdir "analysis/set3-period-window-$window" \
    --mode set3-period-window --window "$window" \
    --seconds 120 --threads 6 --aggressive || exit $?
done
