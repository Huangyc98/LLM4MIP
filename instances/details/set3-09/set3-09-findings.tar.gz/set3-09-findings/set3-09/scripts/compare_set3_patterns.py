#!/usr/bin/env python3
"""Compare every set3 incumbent's 1,424 setup bits with a strict seed."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
from pathlib import Path


def read_solution(path: Path):
    opener = gzip.open if path.suffix == ".gz" else open
    values = {}
    header = None
    with opener(path, "rt", encoding="utf-8", errors="replace") as stream:
        for raw in stream:
            fields = raw.split()
            if len(fields) >= 2 and fields[0] == "=obj=":
                try:
                    header = float(fields[1])
                except ValueError:
                    pass
            elif len(fields) >= 2 and not fields[0].startswith("#"):
                try:
                    values[fields[0]] = float(fields[1])
                except ValueError:
                    pass
    return values, header


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--strict", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    binary_names = [f"y({t},{i})" for t in range(1, 17) for i in range(1, 79)]
    binary_names += [f"w({t},{i})" for t in range(1, 17) for i in range(1, 12)]
    assert len(binary_names) == 1424
    strict, strict_header = read_solution(args.strict)
    strict_pattern = {name: int(strict.get(name, 0.0) > 0.5) for name in binary_names}
    records = []
    paths = sorted(args.root.glob("set3-*/incumbent.sol"))
    for path in paths:
        values, header = read_solution(path)
        pattern = {name: int(values.get(name, 0.0) > 0.5) for name in binary_names}
        signature = "".join(str(pattern[name]) for name in binary_names)
        differences = [name for name in binary_names if pattern[name] != strict_pattern[name]]
        records.append({
            "path": str(path),
            "header_objective": header,
            "cost_value": values.get("cost"),
            "setup_ones": sum(pattern.values()),
            "signature_sha256": hashlib.sha256(signature.encode("ascii")).hexdigest(),
            "hamming_from_strict": len(differences),
            "first_differences": differences[:30],
        })
    payload = {
        "strict": str(args.strict),
        "strict_header_objective": strict_header,
        "strict_setup_ones": sum(strict_pattern.values()),
        "binary_count": len(binary_names),
        "records": records,
    }
    args.out.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
