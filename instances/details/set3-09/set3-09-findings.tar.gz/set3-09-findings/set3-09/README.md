# set3-09：多层批量计划结构、严格解重构与邻域实验

研究日期：2026-09-08。

官方 MIPLIB 页面：<https://miplib.zib.de/instance_details_set3-09.html>

## 结论

本轮没有改善 MIPLIB 的已知容差可行目标，也没有证明最优。

- MIPLIB ID3 的目标为 `176497.15242401615`；它在通常 MIP 容差下可行，但直接 Decimal 回放有
  163 个非零残差，最大为 `1.42985145e-11`。
- 固定官方 1,424 位 setup 模式并精确重构连续变量后，得到 Decimal-zero 目标
  `176497.15242568319286826271237029052439100`。
- item group `1--6` 给出了一个 Hamming 距离为 2 的退化 setup 模式；严格重构后的目标
  `176497.15242568249996140149385244688396511988701605000` 是本轮最好的 Decimal-zero 候选，
  但仍比 MIPLIB ID3 差约 `1.66635e-6`。
- 全模型、分期窗口、BOM 分组、Hamming local branching 和 sibling 模式迁移均未发现相对 MIPLIB 的新解。

求解器输出中若目标只相差约 `1e-6`，必须结合 1,424-bit 整数签名和原 MPS Decimal 审计判断；
本目录不把浮点重优化结果当成严格改进，也不把局部邻域闭合当成全局最优证明。

## 背景与结构

该实例属于 Akartunali--Miller 的多层 big-bucket lot-sizing 测试族，包含 backlogging、
物料清单依赖和 joint family setups。相关背景可参见：

- [MIPLIB set3-09 页面](https://miplib.zib.de/instance_details_set3-09.html)
- [Akartunali--Miller lower-bound 论文页面](https://optimization-online.org/2007/05/1668/)
- [论文 PDF](https://optimization-online.org/wp-content/uploads/2007/05/1668.pdf)
- [早期 heuristic 论文 PDF](https://optimization-online.org/wp-content/uploads/2006/10/1482.pdf)

Gurobi 13.0.1 在 euler4 上对原始 MPS 做了只读审计，未调用优化器。证据在
[`analysis/gurobi-13.0.1-structure.json`](analysis/gurobi-13.0.1-structure.json)。

| 项目 | 数值 |
| --- | ---: |
| 变量总数 | 4,019 |
| binary setup | 1,424 |
| continuous | 2,595 |
| 线性约束 | 3,747 |
| 非零元 | 13,747 |
| items | 78 |
| periods | 16 |

变量按命名完整分解为：

- production `x`：1,248 = 78 × 16；
- inventory `s`：1,248；
- item setup `y`：1,248；
- joint-family setup `w`：176 = 11 × 16；
- finished-product backlog `b`：96 = 6 × 16；
- `cost`、`costinv`、`costb`：3。

约束中有 1,248 条 BOM/inventory balance、1,248 条 production--setup link、576 条 `y <= w`、
96 条容量行（6 个资源组 × 16 期）和 3 条 cost identity。自然的 BOM/item 分组为
`1--6`、`7--12`、`13--18`、`19--30`、`31--54`、`55--78`。

## 官方解与严格重构

官方 ID3 解保存在 [`input/set3-09-public.sol.gz`](input/set3-09-public.sol.gz)。
[`logs/public-solution-exact.log`](logs/public-solution-exact.log) 给出：

```text
objective                         176497.15242401615
exact nonzero row residuals       163 / 3747
maximum residual                  1.42985145e-11
bound violations                  0
integrality violations            0
```

原 MPS 的 RHS 向量名是合法的 `*RHS*`。只有 `*` 位于第一列时才是 MPS 注释；若把所有首 token
以 `*` 开头的行都跳过，会错误地把 RHS 当作 0。本目录的复现命令通过
[`scripts/fixed_rhs_exact_wrapper.py`](scripts/fixed_rhs_exact_wrapper.py) 修正这一解析细节。

严格重构步骤为：

1. 固定并取整官方 1,424 个 setup binaries；
2. 沿三角 BOM 顺序，对上层 production 做有限小数梯度收缩；
3. 按 16 期 balance 精确递推 inventory/backlog；
4. 精确重算三个 cost auxiliary；
5. 对原始 MPS 做 tolerance 0 审计。

官方模式严格解为
[`solutions/set3-09-strict-official-pattern.sol`](solutions/set3-09-strict-official-pattern.sol)：

```text
objective                         176497.15242568319286826271237029052439100
exact row violations             0 / 3747
exact bound violations           0
exact integrality violations     0
SHA256                            df1a05b7b14f297c8346aa92df23f3fdc9d2639f3761a975160867d96824ac27
```

重构报告和独立审计分别为
[`analysis/strict-reconstruction.json`](analysis/strict-reconstruction.json) 与
[`logs/strict-official-pattern-exact.log`](logs/strict-official-pattern-exact.log)。

## 求解实验

正式求解使用 altman 上的 COPT 8.0.4。euler4 的 Gurobi 13.0.1 当前许可证为 size-limited，
可读模和分析，但不能优化该规模实例。

### 全模型

| 运行 | 时限 | 状态 | incumbent | numerical bound | nodes |
| --- | ---: | --- | ---: | ---: | ---: |
| 无 start 的协调冷启动 | 600 s | TIME_LIMIT | `415953.5421` | `100003.1907` | 23,453 |
| 官方 ID3 start | 600 s | TIME_LIMIT | `176497.15242401595` | `96465.19511549911` | 3,262 |
| Decimal-zero start | 600 s | TIME_LIMIT | `176497.15242401432` | `95928.04286978129` | 3,582 |

后两项归档在 [`experiments/full-official-start`](experiments/full-official-start) 和
[`experiments/full-strict-start`](experiments/full-strict-start)。第一项为同轮协调实验摘要，原始运行目录不在本实例归档。
这些浮点 incumbent 的 setup 签名没有变化，不能据末位数值声称新解。

### 连续四期窗口

窗口 `[1,4]`、`[3,6]`、`[5,8]`、`[7,10]`、`[9,12]`、`[11,14]`、`[13,16]`
全部由 COPT 数值闭合，运行时间约 6.2--29.9 秒。七个输出都保持官方 setup 签名，严格目标无改善。
完整结果在 `experiments/period-window-*`。

### BOM/item groups

| 可自由变化的 items | 状态 | 求解器目标 | 与官方签名的 Hamming 距离 |
| --- | --- | ---: | ---: |
| `1--6` | 数值局部最优 | `176497.15242401572` | 2 |
| `7--12` | 数值局部最优 | `176497.15242401612` | 0 |
| `13--18` | 数值局部最优 | `176497.15242401604` | 4 |
| `19--30` | 数值局部最优 | `176497.15242401604` | 8 |
| `31--54` | 120 s TIME_LIMIT | `176497.1524240095` | 0 |
| `55--78` | 数值局部最优 | `176497.15242401604` | 0 |

`31--54` 看似最低的浮点目标仍是同一整数模式的连续变量容差重优化。全部原始结果在
`experiments/item-group-*`。

### Hamming local branching

| 半径 | 状态 | 时间 | setup 模式 | 结论 |
| ---: | --- | ---: | --- | --- |
| 5 | COPT 数值局部最优 | 130.7 s | 官方签名 | 无改善 |
| 15 | TIME_LIMIT | 240 s | 官方签名 | 无改善 |
| 40 | TIME_LIMIT | 240 s | 官方签名 | 无改善 |
| 100 | TIME_LIMIT | 240 s | 官方签名 | 无改善 |

半径 5 的结果只是当前浮点模型中的局部闭合，不是可移植证明，更不是原 MIP 的全局证明。
结果在 `experiments/lb-r*`。

### sibling 模式迁移

将 `set3-10`、`set3-16`、`set3-20` 的 setup 模式固定或作为 start 迁移到 `set3-09`，所得目标均明显更差：

| 模式来源 | fixed 模式目标 | 180 s start 搜索最好目标 |
| --- | ---: | ---: |
| set3-10 | `178276.65493374655` | `178276.65493374612` |
| set3-16 | `196095.5079224431` | `196095.50792244283` |
| set3-20 | `194987.9730363245` | `189649.07909143745` |

输入 sibling 解在 [`input`](input)，运行证据在 `experiments/sibling*`。

## 整数签名与不同模式的严格化

官方模式的 1,424-bit 签名 SHA256 为：

```text
3f836016368c554d0af1d0cc988756ab91c72fa9058c6e39e397ea0812445216
```

它覆盖官方/严格 full start、七个 period window、四个 local-branching 输出，以及 item groups
`7--12`、`31--54`、`55--78`。因此这些输出之间约 `1e-6` 的目标差异不是整数解改进。
完整比较见 [`analysis/pattern-comparison.json`](analysis/pattern-comparison.json)。

每个真正不同的模式都单独 exactify，并在原始 MPS 上 tolerance 0 通过：

| 来源模式 | Hamming 距离 | Decimal-zero 目标 | solution SHA256 |
| --- | ---: | ---: | --- |
| item `1--6` | 2 | `176497.15242568249996140149385244688396511988701605000` | `f2b6dc7b8ae238d7bdf29bc9f856fc935ec7e277bb892f0e813d43006caea0c9` |
| item `13--18` | 4 | `176497.15242568344943845549562497735873075` | `9eb1110be9d6a487556d5e806b8aa3ff3c0eb633641ab1f1e7ec63e98c57fa5d` |
| item `19--30` | 8 | `176497.15242568344943845549562497735873075` | `4844655316ac23105aa88bf1bc674a5bf1ba4b60f8646f006520da6ae79fe74a` |
| sibling10 fixed | 44 | `178276.6549354508895314841973938144357950` | `f3a955711cc628678642f61020bcec94151436040022b52cbe01fdd612f01a89` |
| sibling16 fixed | 127 | `196095.50792401337005126464600578471897125` | `2e573533bad261f8167d4ef4add3b1fc4de8b35fd59452548d875badc113c0f3` |
| sibling20 fixed | 283 | `194987.9730379513897137943030283800542600` | `76d7408e7e360b72d44ae0059401f4d292c51dc54047b2139716da513aee47b9` |
| sibling20 start | 333 | `189649.0790931343978391824269366201746865846409577400` | `1bbccc92ca6441af4627629e070abe41161e62055eb84bb46287ebf3f3af45b4` |

对应解位于 [`solutions`](solutions)，重构报告位于 `analysis/exactified-patterns`，逐行审计位于
`logs/exactified-patterns`。`sibling20 start` 原输出在 `y=0` 时残留约 `2.2e-12` production；
严格重构先将该 production 置 0，再递推所有 balance。

## 复现

检查输入和关键证据哈希：

```sh
sha256sum -c SHA256SUMS
```

复核官方模式严格解：

```sh
python scripts/fixed_rhs_exact_wrapper.py \
  scripts/exact_mps_solution_check.py \
  input/set3-09.mps.gz \
  solutions/set3-09-strict-official-pattern.sol \
  --tolerance 0
```

从 item group `1--6` 的求解器点重构本轮最佳 Decimal-zero 候选：

```sh
python scripts/set3_exactify.py \
  --mps input/set3-09.mps.gz \
  --source experiments/item-group-1_6/incumbent.sol \
  --out reproduced-item-group-1_6.sol \
  --report reproduced-item-group-1_6.json \
  --alphas 0.99999999999999

python scripts/fixed_rhs_exact_wrapper.py \
  scripts/exact_mps_solution_check.py \
  input/set3-09.mps.gz \
  reproduced-item-group-1_6.sol \
  --tolerance 0
```

预期目标为 `176497.15242568249996140149385244688396511988701605000`，所有行、界和整数性违规为 0。
