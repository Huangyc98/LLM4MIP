# Package manifest: ger50-17-ptp-pop-3t

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 11
Excluded source files: 0

## Included files

- `README.md`
- `artifacts/result.json`
- `input/README.md`
- `input/SHA256SUMS`
- `logs/rejected-gurobi13-counterexample.log`
- `logs/scaled-gurobi12-60s.log`
- `solutions/strict-5224.5144.sol`
- `structural/README.md`
- `structural/add_better_than_incumbent_cutoff.py`
- `structural/audit_solution.py`
- `structural/make_flow_scaled_model.py`

## Excluded files

- None
