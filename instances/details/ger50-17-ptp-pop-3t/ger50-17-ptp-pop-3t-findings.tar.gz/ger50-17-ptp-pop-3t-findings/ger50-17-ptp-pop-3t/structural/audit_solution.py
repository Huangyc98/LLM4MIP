#!/usr/bin/env python3
"""Decimal audit for a MIPLIB free-MPS solution.

The script deliberately does not use a solver API.  It parses the finite
decimal data in the MPS and .sol files and reports objective, row, bound, and
integrality residuals for the displayed solution vector.
"""

from collections import defaultdict
from decimal import Decimal, getcontext
import gzip
from pathlib import Path
import sys


getcontext().prec = 60
ZERO = Decimal(0)


def open_text(path: Path):
    if path.suffix == ".gz":
        return gzip.open(path, "rt", encoding="utf-8")
    return path.open("r", encoding="utf-8")


def parse_mps(path: Path):
    section = None
    row_sense = {}
    matrix = defaultdict(dict)
    rhs = defaultdict(lambda: ZERO)
    objective_row = None
    variables = set()
    integer_variables = set()
    lower = defaultdict(lambda: ZERO)
    upper = {}
    in_integer_marker = False

    with open_text(path) as handle:
        for raw in handle:
            line = raw.strip()
            if not line or line.startswith("*"):
                continue
            parts = line.split()
            if parts[0] in {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}:
                section = parts[0]
                continue

            if section == "ROWS":
                sense, name = parts[:2]
                row_sense[name] = sense
                if sense == "N":
                    objective_row = name
            elif section == "COLUMNS":
                if len(parts) >= 3 and parts[1].strip("'") == "MARKER":
                    marker = parts[2].strip("'")
                    in_integer_marker = marker == "INTORG"
                    continue
                variable = parts[0]
                variables.add(variable)
                if in_integer_marker:
                    integer_variables.add(variable)
                for index in range(1, len(parts), 2):
                    matrix[parts[index]][variable] = Decimal(parts[index + 1])
            elif section == "RHS":
                for index in range(1, len(parts), 2):
                    rhs[parts[index]] = Decimal(parts[index + 1])
            elif section == "BOUNDS":
                kind, _, variable = parts[:3]
                variables.add(variable)
                value = Decimal(parts[3]) if len(parts) == 4 else ZERO
                if kind in {"LO", "LI"}:
                    lower[variable] = value
                elif kind in {"UP", "UI"}:
                    upper[variable] = value
                elif kind == "FX":
                    lower[variable] = value
                    upper[variable] = value
                elif kind == "FR":
                    lower.pop(variable, None)
                elif kind == "MI":
                    lower.pop(variable, None)
                elif kind == "PL":
                    upper.pop(variable, None)
                elif kind == "BV":
                    integer_variables.add(variable)
                    lower[variable] = ZERO
                    upper[variable] = Decimal(1)
                else:
                    raise ValueError(f"Unsupported bound type {kind}")

    return row_sense, matrix, rhs, objective_row, variables, integer_variables, lower, upper


def parse_solution(path: Path):
    values = defaultdict(lambda: ZERO)
    declared_objective = None
    with open_text(path) as handle:
        for raw in handle:
            line = raw.strip()
            if not line:
                continue
            if line.startswith("# Objective value ="):
                declared_objective = Decimal(line.split("=", 1)[1].strip())
            elif not line.startswith("#") and not line.startswith("=obj="):
                name, value = line.split()[:2]
                values[name] = Decimal(value)
    return values, declared_objective


def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: audit_solution.py MODEL.mps[.gz] SOLUTION.sol[.gz]")
    model = Path(sys.argv[1])
    solution = Path(sys.argv[2])
    row_sense, matrix, rhs, objective_row, variables, integers, lower, upper = parse_mps(model)
    values, declared_objective = parse_solution(solution)

    unknown = sorted(set(values) - variables)
    objective = sum((coefficient * values[variable] for variable, coefficient in matrix[objective_row].items()), ZERO)

    row_violations = []
    equality_residuals = []
    for row, sense in row_sense.items():
        if sense == "N":
            continue
        activity = sum((coefficient * values[variable] for variable, coefficient in matrix[row].items()), ZERO)
        residual = activity - rhs[row]
        if sense == "E":
            violation = abs(residual)
            equality_residuals.append((violation, row, residual))
        elif sense == "L":
            violation = max(residual, ZERO)
        elif sense == "G":
            violation = max(-residual, ZERO)
        else:
            raise ValueError(f"Unsupported row sense {sense}")
        row_violations.append((violation, row, residual))

    bound_violations = []
    for variable in variables:
        value = values[variable]
        violation = ZERO
        if variable in lower:
            violation = max(violation, lower[variable] - value)
        if variable in upper:
            violation = max(violation, value - upper[variable])
        bound_violations.append((violation, variable, value))

    integer_violations = []
    for variable in integers:
        value = values[variable]
        violation = abs(value - value.to_integral_value())
        integer_violations.append((violation, variable, value))

    row_violations.sort(reverse=True)
    equality_residuals.sort(reverse=True)
    bound_violations.sort(reverse=True)
    integer_violations.sort(reverse=True)

    print(f"variables={len(variables)} rows={len(row_violations)} integer_variables={len(integers)}")
    print(f"unknown_solution_names={len(unknown)}")
    print(f"objective_recomputed={objective}")
    print(f"objective_declared={declared_objective}")
    print(f"objective_residual={objective - declared_objective if declared_objective is not None else 'n/a'}")
    print(f"max_row_violation={row_violations[0][0]} row={row_violations[0][1]} signed_residual={row_violations[0][2]}")
    if equality_residuals:
        print(f"max_equality_residual={equality_residuals[0][0]} row={equality_residuals[0][1]} signed_residual={equality_residuals[0][2]}")
    else:
        print("max_equality_residual=n/a (no equality rows)")
    print(f"max_bound_violation={bound_violations[0][0]} variable={bound_violations[0][1]} value={bound_violations[0][2]}")
    print(f"max_integrality_violation={integer_violations[0][0]} variable={integer_violations[0][1]} value={integer_violations[0][2]}")
    print("largest_row_violations:")
    for violation, row, residual in row_violations[:10]:
        print(f"  {row}: violation={violation} signed_residual={residual}")


if __name__ == "__main__":
    main()
