# Input provenance

The original MPS is intentionally not stored in this repository.

- MIPLIB page: <https://miplib.zib.de/instance_details_ger50-17-ptp-pop-3t.html>
- Official MPS: <https://miplib.zib.de/WebData/instances/ger50-17-ptp-pop-3t.mps.gz>
- Expected SHA-256: `8dcb784e3145ac52d395cded5aaefc977e7837139ddec24f428fb2904dfcb744`

Download it as `input/ger50-17-ptp-pop-3t.mps.gz` before replaying the
structural generators or the independent solution audit.
