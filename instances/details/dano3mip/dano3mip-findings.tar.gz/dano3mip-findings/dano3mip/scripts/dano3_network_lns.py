#!/usr/bin/env python3
"""Node/arc large-neighborhood search for the 24-node dano3mip network."""

from __future__ import annotations

import argparse
import random
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


NODES = 24


def read_solution(path: Path) -> dict[str, float]:
    values: dict[str, float] = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        tokens = raw.split()
        if len(tokens) == 2 and tokens[0] != "=obj=" and not tokens[0].startswith("#"):
            values[tokens[0]] = float(tokens[1])
    return values


def endpoints(variable_index: int) -> tuple[int, int]:
    """Map x2,...,x553 to a directed arc in row-major order without loops."""
    offset = variable_index - 2
    source, rank = divmod(offset, NODES - 1)
    destination = rank if rank < source else rank + 1
    return source, destination


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--iterations", type=int, default=5)
    parser.add_argument("--seconds", type=float, default=30.0)
    parser.add_argument("--threads", type=int, default=32)
    parser.add_argument("--seed", type=int, default=20260831)
    parser.add_argument("--result", type=Path, required=True)
    parser.add_argument("--log", type=Path)
    args = parser.parse_args()

    rng = random.Random(args.seed)
    model = gp.read(str(args.mps))
    model.update()
    variables = model.getVars()
    initial = read_solution(args.solution)
    incumbent = {variable.VarName: initial.get(variable.VarName, 0.0) for variable in variables}
    incumbent_objective = sum(variable.Obj * incumbent[variable.VarName] for variable in variables)
    arcs = [model.getVarByName(f"x{index}") for index in range(2, 554)]
    if any(variable is None for variable in arcs):
        raise ValueError("Expected arc variables x2,...,x553")
    original_bounds = {variable.VarName: (variable.LB, variable.UB) for variable in arcs}
    selected_arc_count = sum(round(incumbent[variable.VarName]) for variable in arcs)
    if selected_arc_count != 48:
        raise ValueError(f"Expected 48 selected arcs, found {selected_arc_count}")

    print(
        f"nodes={NODES} directed_arcs={len(arcs)} selected_arcs={selected_arc_count} "
        f"initial_objective={incumbent_objective:.15g}"
    )
    if args.log:
        model.Params.LogFile = str(args.log)
    model.Params.Threads = args.threads
    model.Params.MIPFocus = 1
    model.Params.NoRelHeurTime = min(3.0, args.seconds / 5)

    sizes = [4, 6, 8, 10, 12]
    for iteration in range(args.iterations):
        for variable in arcs:
            variable.LB, variable.UB = original_bounds[variable.VarName]
        size = sizes[iteration % len(sizes)]
        selected_nodes = set(rng.sample(range(NODES), size))
        free_arcs = 0
        fixed_arcs = 0
        for index, variable in enumerate(arcs, start=2):
            source, destination = endpoints(index)
            if source in selected_nodes or destination in selected_nodes:
                free_arcs += 1
            else:
                value = round(incumbent[variable.VarName])
                variable.LB = variable.UB = value
                fixed_arcs += 1

        model.Params.TimeLimit = args.seconds
        model.Params.BestObjStop = incumbent_objective - 1e-7
        model.reset(0)
        for variable in variables:
            variable.Start = incumbent[variable.VarName]
        print(
            f"iteration={iteration+1} selected_nodes={sorted(selected_nodes)} "
            f"free_arcs={free_arcs} fixed_arcs={fixed_arcs}"
        )
        model.optimize()
        if model.SolCount and model.ObjVal < incumbent_objective - 1e-7:
            incumbent_objective = model.ObjVal
            incumbent = {variable.VarName: variable.X for variable in variables}
            model.write(str(args.result))
            print(f"IMPROVED objective={incumbent_objective:.15g}")
        else:
            print(
                f"no_improvement status={model.Status} sol_count={model.SolCount} "
                f"best={(model.ObjVal if model.SolCount else float('inf')):.15g}"
            )

    if not args.result.exists():
        for variable in arcs:
            variable.LB, variable.UB = original_bounds[variable.VarName]
        model.Params.TimeLimit = 1
        model.Params.BestObjStop = -GRB.INFINITY
        model.reset(0)
        for variable in variables:
            variable.Start = incumbent[variable.VarName]
        model.optimize()
        if model.SolCount:
            model.write(str(args.result))
    print(f"final_objective={incumbent_objective:.15g} result={args.result}")


if __name__ == "__main__":
    main()
