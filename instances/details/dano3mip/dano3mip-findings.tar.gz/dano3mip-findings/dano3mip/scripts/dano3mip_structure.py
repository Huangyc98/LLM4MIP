#!/usr/bin/env python3
"""Recover the 24-node network-design structure of dano3mip."""

from __future__ import annotations

import argparse
from collections import Counter
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def row_terms(model: gp.Model, row: gp.Constr) -> list[tuple[str, float]]:
    expression = model.getRow(row)
    return [
        (expression.getVar(index).VarName, expression.getCoeff(index))
        for index in range(expression.size())
    ]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    args = parser.parse_args()
    model = gp.read(str(args.mps))
    model.update()
    variables = model.getVars()
    rows = model.getConstrs()
    binaries = [
        variable
        for variable in variables
        if variable.VType in {GRB.BINARY, GRB.INTEGER}
        and variable.LB == 0
        and variable.UB == 1
    ]
    binary_names = {variable.VarName for variable in binaries}

    print(
        f"model={model.ModelName} rows={model.NumConstrs} cols={model.NumVars} "
        f"nonzeros={model.NumNZs}"
    )
    print(f"types={Counter(variable.VType for variable in variables)}")
    print(f"senses={Counter(row.Sense for row in rows)}")
    print(f"rhs={Counter(row.RHS for row in rows).most_common(20)}")
    print(f"binary_first={binaries[0].VarName} binary_last={binaries[-1].VarName} count={len(binaries)}")

    pure_binary: list[gp.Constr] = []
    for row in rows:
        terms = row_terms(model, row)
        if terms and all(name in binary_names for name, _ in terms):
            pure_binary.append(row)
    print(f"pure_binary_rows={len(pure_binary)}")
    for row in pure_binary[:55]:
        print(row.ConstrName, row.Sense, row.RHS, row_terms(model, row))

    print("rows_touching_first_binaries")
    for variable in binaries[:5]:
        touched = []
        column = model.getCol(variable)
        for index in range(column.size()):
            row = column.getConstr(index)
            touched.append((row.ConstrName, row.Sense, row.RHS, column.getCoeff(index)))
        print(variable.VarName, touched)


if __name__ == "__main__":
    main()
