# `neos-3355323-arnon`

## Result

Status: **unresolved feasibility instance**.

No feasible original-MPS assignment and no independently checkable
infeasibility certificate were obtained. The objective is identically zero,
so either kind of certificate would settle the instance; neither is claimed.

[MIPLIB instance page](https://miplib.zib.de/instance_details_neos-3355323-arnon.html)

## Exact structural reduction

Read-only Gurobi parsing recovered 10,248 variables and 21,216 constraints.
The model contains 144 rank variables in `{1,...,11}`, grouped into 24
six-element chains, together with 9,624 exact comparison atoms and 468
six-comparison pattern indicators. Exact truth-table extraction accounts for
all 1,248 forbidden six-bit assignments and 36 final pattern families.

The custom DPLL(T) search explored 12,024 nodes in 60 seconds without a
witness or proof. A subsequent exact threshold-SAT encoding had 11,544
variables and 210,720 clauses; CaDiCaL was externally stopped after 1,184.843
seconds and is recorded as `UNKNOWN`. No model and no proof trace were created.

No generic MIP optimization was used.

## Evidence

- [`structure/deep_structure.json`](structure/deep_structure.json) records the
  recovered row templates and incidence structure.
- [`scripts/solve_order_csp.py`](scripts/solve_order_csp.py) implements the
  custom difference-constraint DPLL(T) route.
- [`scripts/solve_order_sat.py`](scripts/solve_order_sat.py) regenerates the
  exact SAT encoding.
- [`artifacts/order_csp_60s.json`](artifacts/order_csp_60s.json) and
  [`artifacts/order_sat_result.json`](artifacts/order_sat_result.json) record
  the two inconclusive outcomes.
- [`scripts/audit_original.py`](scripts/audit_original.py) is the independent
  original-MPS witness checker required for any future feasible claim.
- [`reports/final_report.md`](reports/final_report.md) contains the complete
  evidence boundary.

The regenerable normalized CSP, DIMACS CNF, variable map, API prompts,
responses, and session state are intentionally omitted. Their absence does not
remove a certificate because no certificate was produced.

SHA-256:

- MPS: `79C32F6DFC7A1784ECE68D4024EAE739784B9C69ADFC94EF7222A35CDACDA5D7`
