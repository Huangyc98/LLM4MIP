# Structural investigation of `neos-3355323-arnon`

## Result

`neos-3355323-arnon` was **not resolved** in this research window. No feasible assignment and no independently checkable infeasibility certificate were obtained. The strongest concrete advance is an exact, compact structural reduction from the original MIP to a finite-domain order CSP and then to an 11,544-variable, 210,720-clause CNF. A bounded CDCL run ended with `UNKNOWN` after 1,184.843 seconds: it produced neither a SAT model nor an UNSAT result/proof.

This is a pure feasibility instance (the objective is identically zero), so an original-MPS-feasible witness would immediately settle it. None is claimed here.

## Reproducibility and provenance

- Original file: `input/neos-3355323-arnon.mps.gz`
- Original SHA-256: `79c32f6dfc7a1784ece68d4024eae739784b9c69adfc94ef7222a35cdacda5d7`
- Source: official MIPLIB 2017 instance page and its MPS link
- Structure parser: Gurobi 13.0.2 through `gurobipy`, read-only; `optimize()` was not called
- Exact structural extractor: `scripts/inspect_arnon.py`
- Exact custom DPLL(T): `scripts/solve_order_csp.py`
- Exact SAT encoder: `scripts/solve_order_sat.py`
- Original-model witness auditor: `scripts/audit_original.py`

The official page records 10,248 variables, 21,216 constraints, 69,912 nonzeros, 10,104 binaries, 144 general integers, open status, and no public solution. It assigns the instance to `neos-pseudoapplication-38`, submitted by Jeff Linderoth, but supplies no bibliography or application description. Therefore the discussion of an order/configuration problem below is an inference from the algebra, not an externally sourced fact.

## Exact structure recovered

All 144 general integer variables are `C10105` through `C10248`, each with domain `{1,...,11}`. The remaining 10,104 variables have binary bounds. The objective contains no nonzero coefficients.

The 144 integer variables split into 24 consecutive six-element chains. The first 120 rows impose five nondecreasing inequalities per chain. Another 60 rows fix selected adjacent pairs equal. Twelve binaries (`C0001` through `C0012`) each choose between one equality in one branch and two equalities in the other branch, expressed in the MPS through 36 one-sided big-M rows.

The central block consists of 9,624 comparison binaries (`C0481` through `C10104`). Exhaustive truth-table checking of every associated two-row big-M gadget found exactly one feasible bit for every pair of integer values. The census is:

- 4,872 atoms of the form `b = 1 iff x >= y`;
- 4,752 atoms of the form `b = 1 iff x <= y`;
- zero truth-table eyeballing failures.

The remaining 468 binaries (`C0013` through `C0480`) are exact indicators for signed six-comparison patterns. Across the model there are 858 distinct six-comparison supports:

- 468 have a pattern indicator: one extreme bit assignment makes the indicator one; its opposite extreme is forbidden;
- 390 have no indicator: both extreme assignments are forbidden;
- hence there are exactly `468 + 2*390 = 1,248` forbidden six-bit assignments, matching the MIPLIB presolved invariant-knapsack count;
- the last 36 rows require at least one of 13 pattern indicators, and all 468 indicators appear exactly once.

The row-variable incidence graph is connected. The repeated anonymous motifs and order-only semantics suggest a discrete order/configuration or geometric-order problem. No source was found that justifies a more specific application label.

## API-guided reasoning

Two successful stateful calls were made to `gpt-5.6-sol`, totaling 22,354 tokens:

1. The first call received the official facts and decoded row templates. It ranked finite-domain order/configuration, geometric ordering, and scheduling-like interpretations; it recommended eliminating the 9,624 big-M atoms through exact order semantics and explicitly propagating the 36 pattern families.
2. The second call received measured behavior from the custom search. It correctly diagnosed a broad tree with weak global family propagation and recommended a simultaneous finite-domain SAT/CDCL encoding. Its concern that a lazy witness branch might be globally unsound does not apply to the implementation: the custom solver branches exhaustively over the six complements without learning that branch as a global clause. It is sound but inefficient.

Raw prompts, responses, and session state are deliberately omitted from the
publication copy; accepted implementations and measured outcomes are retained.

## Algorithms tried

### Exact custom DPLL(T)

`solve_order_csp.py` removes the comparison binaries conceptually. Its theory state is a directed difference-constraint graph with edges `x_v >= x_u + w`, where `w` is zero or one. It detects a positive strict cycle or a longest-path requirement exceeding the 11 available levels. It propagates the 1,248 six-bit nogoods, the 36 pattern families, and the twelve conditional equality choices.

A 60-second run explored 12,024 nodes to depth 53. It recorded 7,183 explicit nogood conflicts, 1,576 unit-nogood propagations, and 4,801 rejected rank completions, but no family conflict, theory conflict, witness, or proof. This showed that a custom depth-first traversal did not learn enough across the many symmetric locally orderable branches.

### Exact order-encoding SAT reduction

The locally generated normalized intermediate stored every order edge for each
comparison-bit value, each pattern truth assignment, all forbidden assignments,
every family, every gap alternative, and the base order edges. It is omitted as
a large regenerable artifact.

The SAT encoding uses ten threshold atoms per rank:

`T(i,k) <=> x_i >= k`, for `k = 2,...,11`.

Monotonicity represents a value in `{1,...,11}`. Each non-strict edge `x_v >= x_u` becomes ten threshold implications. Each strict edge `x_v >= x_u + 1` becomes the corresponding shifted implications plus its two boundary conditions. A comparison Boolean selects one of two complementary relations, so its truth value is exact without a big-M coefficient. Gap alternatives are encoded conditionally in the same way.

Each pattern indicator is Tseitin-equivalent to its six signed comparison atoms. The 1,248 forbidden assignments are ordinary six-literal clauses, and each final family is one 13-literal clause. The generated CNF has:

- 1,440 rank threshold atoms;
- 9,624 comparison atoms;
- 468 pattern atoms;
- 12 gap atoms;
- 11,544 total variables;
- 210,720 clauses.

The generated DIMACS and variable map are regenerable with
`scripts/solve_order_sat.py` and are omitted from the publication copy. A
bounded CaDiCaL 1.9.5 run via PySAT remained `UNKNOWN`; no result beyond that
status is claimed. The orchestrator ended it at the bound after 1,184.843
seconds. `artifacts/order_sat_result.json` records this external termination
explicitly and confirms that neither a model nor proof exists.

## Verification standard

`scripts/audit_original.py` is deliberately separate from the SAT encoder. Given a candidate JSON assignment, it reparses the untouched compressed MPS and checks:

- exact variable-name coverage;
- every bound;
- integrality;
- every one of the 21,216 original linear rows;
- the original objective.

Because no SAT witness was obtained, this audit was not invoked on a candidate. Any future feasible claim must include its generated audit JSON with zero bound, integrality, and row violations. An UNSAT result would also require a proof-producing SAT run plus a checked CNF proof and an independently reviewed equivalence map; a bare solver status is not enough.

## Resource accounting

- Successful API tokens: 22,354 total (`8,651 + 13,703`)
- Generic MIP optimizer runtime: **0 seconds**
- Gurobi use: parser/row inspection only
- Custom DPLL(T) runtime: 60 seconds
- Structural CDCL runtime: 1,184.843 seconds
- Wall-clock research window: `03:29:31` to `05:07:41.843` Asia/Shanghai (1 h 38 min 10.843 s; 5,890.843 s)

The generic-solver allowance was not consumed. The work focused on exact semantic extraction and a non-MIP reformulation.

## Best next steps

1. Validate the CNF equivalence by exhaustive small-gadget tests and by translating any future SAT model back through `audit_original.py`.
2. Run several proof-capable CDCL configurations with phase hints from rank-based local search. If UNSAT is found, retain and check DRAT/LRAT; if SAT is found, the original-MPS audit settles the instance immediately.
3. Compute automorphisms of the six-comparison pattern hypergraph and add only mechanically verified symmetry breakers. The current search likely repeats equivalent total preorders.
4. Identify recurring graph motifs of the 858 six-comparison supports. That may reveal the hidden application and permit a much smaller application-specific construction or contradiction.

These are concrete continuations, but none is presented as already proving feasibility or infeasibility.
