"""Exact DPLL over order relations, eliminating 9,624 big-M binaries.

The theory state is an all-pairs closure of constraints x_v >= x_u + w,
where w is 0 for non-strict order and 1 for strict order.  Boolean pattern
clauses and forbidden configurations propagate into this difference logic.
"""
from __future__ import annotations

from collections import defaultdict
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import re
import time

import gurobipy as gp
import numpy as np


NEG = -1000


def number(name: str) -> int:
    match = re.search(r"(\d+)$", name)
    assert match
    return int(match.group(1))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--time-limit", type=float, default=600.0)
    parser.add_argument("--normalized", type=Path)
    parser.add_argument("--extract-only", action="store_true")
    args = parser.parse_args()

    env = gp.Env(empty=True)
    env.setParam("OutputFlag", 0)
    env.start()
    model = gp.read(str(args.mps), env)
    variables = model.getVars()
    constraints = model.getConstrs()
    name_to_var = {v.VarName: v for v in variables}
    row_terms: list[list[tuple[str, int]]] = []
    rows_by_variable: dict[str, list[int]] = defaultdict(list)
    for r, constraint in enumerate(constraints):
        expression = model.getRow(constraint)
        terms = []
        for p in range(expression.size()):
            name = expression.getVar(p).VarName
            coefficient = int(round(expression.getCoeff(p)))
            terms.append((name, coefficient))
            rows_by_variable[name].append(r)
        row_terms.append(terms)

    integer_names = [v.VarName for v in variables if v.LB == 1 and v.UB == 11]
    integer_index = {name: i for i, name in enumerate(integer_names)}
    comparison_names = [f"C{k:04d}" for k in range(481, 10105)]
    gap_names = [f"C{k:04d}" for k in range(1, 13)]
    pattern_names = {f"C{k:04d}" for k in range(13, 481)}
    assert len(integer_names) == 144 and all(name in name_to_var for name in comparison_names)

    def row_feasible(r: int, assignment: dict[str, int]) -> bool:
        lhs = sum(coefficient * assignment[name] for name, coefficient in row_terms[r])
        constraint = constraints[r]
        rhs = int(round(constraint.RHS))
        if constraint.Sense == "<":
            return lhs <= rhs
        if constraint.Sense == ">":
            return lhs >= rhs
        return lhs == rhs

    # Each comparison is normalized to an edge required by bit 0 and bit 1.
    # An edge (u,v,w) means x[v] >= x[u] + w.
    bit_edges: dict[str, dict[int, tuple[int, int, int]]] = {}
    relation_census = defaultdict(int)
    truth_failures = []
    for b in comparison_names:
        rr = [r for r in rows_by_variable[b] if r < 19464]
        int_support = sorted({name for r in rr for name, _ in row_terms[r] if name in integer_index})
        if len(rr) != 2 or len(int_support) != 2:
            truth_failures.append({"binary": b, "rows": rr, "integer_support": int_support})
            continue
        a_name, c_name = int_support
        truth = {}
        for a_value in range(1, 12):
            for c_value in range(1, 12):
                allowed = [
                    bit for bit in (0, 1)
                    if all(row_feasible(r, {b: bit, a_name: a_value, c_name: c_value}) for r in rr)
                ]
                if len(allowed) != 1:
                    truth_failures.append({"binary": b, "values": [a_value, c_value], "allowed": allowed})
                    break
                truth[a_value, c_value] = allowed[0]
        relations = {
            "GE": lambda x, y: x >= y,
            "LE": lambda x, y: x <= y,
            "GT": lambda x, y: x > y,
            "LT": lambda x, y: x < y,
        }
        matched = [
            label for label, predicate in relations.items()
            if all(bit == int(predicate(x, y)) for (x, y), bit in truth.items())
        ]
        if len(matched) != 1:
            truth_failures.append({"binary": b, "matched": matched})
            continue
        relation = matched[0]
        relation_census[relation] += 1
        a = integer_index[a_name]
        c = integer_index[c_name]
        if relation == "GE":
            bit_edges[b] = {1: (c, a, 0), 0: (a, c, 1)}
        elif relation == "LE":
            bit_edges[b] = {1: (a, c, 0), 0: (c, a, 1)}
        elif relation == "GT":
            bit_edges[b] = {1: (c, a, 1), 0: (a, c, 0)}
        else:  # LT
            bit_edges[b] = {1: (a, c, 1), 0: (c, a, 0)}
    assert not truth_failures and len(bit_edges) == 9624

    # Pair the 1,716 pattern rows by their identical comparison support.
    pattern_rows_by_support: dict[tuple[str, ...], list[int]] = defaultdict(list)
    for r in range(19464, 21180):
        support = tuple(sorted(name for name, _ in row_terms[r] if name in bit_edges))
        pattern_rows_by_support[support].append(r)
    assert len(pattern_rows_by_support) == 858
    assert all(len(rr) == 2 for rr in pattern_rows_by_support.values())

    allowed_patterns: dict[str, tuple[tuple[str, int], ...]] = {}
    nogoods: list[tuple[tuple[str, int], ...]] = []
    pattern_source = {}
    extraction_failures = []
    for support, rr in pattern_rows_by_support.items():
        first = next((r for r in rr if int(round(constraints[r].RHS)) == 3), None)
        second = next((r for r in rr if int(round(constraints[r].RHS)) == 1), None)
        if first is None or second is None or len(support) != 6:
            extraction_failures.append({"support": support, "rows": rr})
            continue
        first_coeff = dict(row_terms[first])
        second_coeff = dict(row_terms[second])
        z_names = sorted((set(first_coeff) | set(second_coeff)) & pattern_names)
        if len(z_names) > 1 or any(second_coeff[b] != -first_coeff[b] for b in support):
            extraction_failures.append({"support": support, "rows": rr, "z": z_names})
            continue
        desired = tuple(sorted((b, 0 if first_coeff[b] == 1 else 1) for b in support))
        opposite = tuple(sorted((b, 1 - bit) for b, bit in desired))
        if z_names:
            z = z_names[0]
            if first_coeff.get(z) != 5 or second_coeff.get(z) != -1:
                extraction_fail.append({"z": z, "rows": rr})
                continue
            allowed_patterns[z] = desired
            nogoods.append(opposite)
            pattern_source[z] = [constraints[r].ConstrName for r in rr]
        else:
            nogoods.extend((desired, opposite))
    assert not extraction_failures
    assert len(allowed_patterns) == 468 and len(nogoods) == 1248

    clauses = []
    for r in range(21180, 21216):
        family = tuple(name for name, coefficient in row_terms[r] if name in allowed_patterns and coefficient == -1)
        assert len(family) == 13 and constraints[r].Sense == "<" and constraints[r].RHS == -1
        clauses.append(family)
    assert len(clauses) == 36 and len({z for family in clauses for z in family}) == 468

    def close_base(edges: list[tuple[int, int, int]]) -> np.ndarray | None:
        distance = np.full((144, 144), NEG, dtype=np.int16)
        np.fill_diagonal(distance, 0)
        for u, v, weight in edges:
            distance[u, v] = max(int(distance[u, v]), weight)
        for k in range(144):
            via = distance[:, k, None].astype(np.int32) + distance[k, None, :].astype(np.int32)
            via[(distance[:, k, None] <= NEG // 2) | (distance[k, None, :] <= NEG // 2)] = NEG
            distance = np.maximum(distance, via).astype(np.int16)
        if np.any(np.diag(distance) > 0) or int(distance.max()) > 10:
            return None
        return distance

    def add_edge(distance: np.ndarray, edge: tuple[int, int, int]) -> np.ndarray | None:
        u, v, weight = edge
        if int(distance[u, v]) >= weight:
            return distance
        if int(distance[v, u]) > NEG // 2 and int(distance[v, u]) + weight > 0:
            return None
        left = distance[:, u].astype(np.int32)
        right = distance[v, :].astype(np.int32)
        candidate = left[:, None] + weight + right[None, :]
        candidate[(left[:, None] <= NEG // 2) | (right[None, :] <= NEG // 2)] = NEG
        result = np.maximum(distance, candidate).astype(np.int16)
        if np.any(np.diag(result) > 0) or int(result.max()) > 10:
            return None
        return result

    def add_assignments(distance: np.ndarray, assignments: tuple[tuple[str, int], ...]) -> np.ndarray | None:
        result = distance
        for b, bit in assignments:
            result = add_edge(result, bit_edges[b][bit])
            if result is None:
                return None
        return result

    base_edges = []
    for r in range(180):
        terms = row_terms[r]
        assert len(terms) == 2 and all(name in integer_index for name, _ in terms)
        positive = next(name for name, coefficient in terms if coefficient == 1)
        negative = next(name for name, coefficient in terms if coefficient == -1)
        # positive - negative <= 0, or equality.
        base_edges.append((integer_index[positive], integer_index[negative], 0))
        if constraints[r].Sense == "=":
            base_edges.append((integer_index[negative], integer_index[positive], 0))
    initial = close_base(base_edges)
    assert initial is not None

    gap_options: dict[str, dict[int, list[tuple[int, int, int]]]] = {}
    for gap in gap_names:
        gap_options[gap] = {0: [], 1: []}
        for bit in (0, 1):
            for r in rows_by_variable[gap]:
                if not 180 <= r < 216:
                    continue
                terms = dict(row_terms[r])
                integer_terms = [(name, coefficient) for name, coefficient in terms.items() if name in integer_index]
                positive = next(name for name, coefficient in integer_terms if coefficient == 1)
                negative = next(name for name, coefficient in integer_terms if coefficient == -1)
                effective_rhs = int(round(constraints[r].RHS)) - terms[gap] * bit
                # positive - negative <= effective_rhs. Values are in [1,11],
                # so RHS >=10 is redundant; RHS 0 is the conditional order.
                if effective_rhs < 10:
                    gap_options[gap][bit].append((integer_index[positive], integer_index[negative], -effective_rhs))

    if args.normalized is not None:
        normalized = {
            "input_sha256": hashlib.sha256(args.mps.read_bytes()).hexdigest(),
            "integer_names": integer_names,
            "comparison_bit_edges": {
                name: {str(bit): list(edge) for bit, edge in edges.items()}
                for name, edges in bit_edges.items()
            },
            "comparison_relation_census": dict(relation_census),
            "allowed_patterns": {
                name: [[b, bit] for b, bit in assignments]
                for name, assignments in allowed_patterns.items()
            },
            "pattern_source_rows": pattern_source,
            "nogoods": [[[b, bit] for b, bit in assignments] for assignments in nogoods],
            "families": [list(family) for family in clauses],
            "gap_names": gap_names,
            "gap_options": {
                name: {str(bit): [list(edge) for edge in edges] for bit, edges in options.items()}
                for name, options in gap_options.items()
            },
            "base_edges": [list(edge) for edge in base_edges],
            "counts": {
                "integer_variables": len(integer_names),
                "comparison_binaries": len(bit_edges),
                "pattern_indicators": len(allowed_patterns),
                "nogoods": len(nogoods),
                "families": len(clauses),
                "gap_binaries": len(gap_names),
            },
        }
        args.normalized.parent.mkdir(parents=True, exist_ok=True)
        args.normalized.write_text(json.dumps(normalized, indent=2) + "\n", encoding="utf-8")
        if args.extract_only:
            print(json.dumps(normalized["counts"]))
            return

    def bit_status(distance: np.ndarray, b: str, bit: int) -> int:
        """Return 1 if implied, -1 if contradicted, and 0 if undecided."""
        u, v, weight = bit_edges[b][bit]
        if int(distance[u, v]) >= weight:
            return 1
        cu, cv, cweight = bit_edges[b][1 - bit]
        if int(distance[cu, cv]) >= cweight:
            return -1
        return 0

    stats = {
        "nodes": 0,
        "propagation_rounds": 0,
        "theory_conflicts": 0,
        "nogood_conflicts": 0,
        "clause_conflicts": 0,
        "unit_nogoods": 0,
        "unit_clauses": 0,
        "lazy_witness_nogoods": 0,
        "cache_hits": 0,
        "max_depth": 0,
    }
    deadline = time.perf_counter() + args.time_limit
    seen = set()
    found = None

    def propagate(distance: np.ndarray) -> tuple[np.ndarray | None, list[tuple[int, list[str]]]]:
        result = distance
        while True:
            stats["propagation_rounds"] += 1
            changed = False
            for nogood in nogoods:
                statuses = [bit_status(result, b, bit) for b, bit in nogood]
                if -1 in statuses:
                    continue
                unknown = [k for k, status in enumerate(statuses) if status == 0]
                if not unknown:
                    stats["nogood_conflicts"] += 1
                    return None, []
                if len(unknown) == 1:
                    b, bit = nogood[unknown[0]]
                    updated = add_assignments(result, ((b, 1 - bit),))
                    if updated is None:
                        stats["theory_conflicts"] += 1
                        return None, []
                    if updated is not result:
                        result = updated
                        stats["unit_nogoods"] += 1
                        changed = True
                        break
            if changed:
                continue

            open_clauses = []
            for clause_index, family in enumerate(clauses):
                possible = []
                satisfied = False
                for z in family:
                    statuses = [bit_status(result, b, bit) for b, bit in allowed_patterns[z]]
                    if -1 in statuses:
                        continue
                    possible.append(z)
                    if all(status == 1 for status in statuses):
                        satisfied = True
                        break
                if satisfied:
                    continue
                if not possible:
                    stats["clause_conflicts"] += 1
                    return None, []
                if len(possible) == 1:
                    updated = add_assignments(result, allowed_patterns[possible[0]])
                    if updated is None:
                        stats["theory_conflicts"] += 1
                        return None, []
                    result = updated
                    stats["unit_clauses"] += 1
                    changed = True
                    break
                open_clauses.append((clause_index, possible))
            if not changed:
                return result, open_clauses

    def witness_values(distance: np.ndarray) -> list[int]:
        return [1 + max(0, int(distance[:, j].max())) for j in range(144)]

    def bit_from_values(b: str, values: list[int]) -> int:
        edge = bit_edges[b][1]
        u, v, weight = edge
        return int(values[v] >= values[u] + weight)

    def violated_nogood(values: list[int]):
        for nogood in nogoods:
            if all(bit_from_values(b, values) == bit for b, bit in nogood):
                return nogood
        return None

    def search(distance: np.ndarray, gap_decisions: dict[str, int], depth: int = 0):
        nonlocal found
        if found is not None or time.perf_counter() >= deadline:
            return
        stats["nodes"] += 1
        stats["max_depth"] = max(stats["max_depth"], depth)
        propagated, open_clauses = propagate(distance)
        if propagated is None:
            return
        key = (propagated.tobytes(), tuple(sorted(gap_decisions.items())))
        if key in seen:
            stats["cache_hits"] += 1
            return
        seen.add(key)

        undecided_gaps = [gap for gap in gap_names if gap not in gap_decisions]
        if undecided_gaps:
            # Fail-first gap selection; value 0 adds fewer equality edges and is
            # tried first for constructive search.
            best_gap = None
            viable = None
            for gap in undecided_gaps:
                options = []
                for bit in (0, 1):
                    candidate = propagated
                    for edge in gap_options[gap][bit]:
                        candidate = add_edge(candidate, edge)
                        if candidate is None:
                            break
                    if candidate is not None:
                        options.append((bit, candidate))
                if not options:
                    stats["theory_conflicts"] += 1
                    return
                if viable is None or len(options) < len(viable):
                    best_gap, viable = gap, options
            assert best_gap is not None and viable is not None
            for bit, candidate in viable:
                decisions = dict(gap_decisions)
                decisions[best_gap] = bit
                search(candidate, decisions, depth + 1)
                if found is not None or time.perf_counter() >= deadline:
                    return
            return

        if open_clauses:
            clause_index, possible = min(open_clauses, key=lambda item: len(item[1]))
            # Prefer patterns imposing the fewest previously unknown bits.
            possible = sorted(
                possible,
                key=lambda z: sum(bit_status(propagated, b, bit) == 0 for b, bit in allowed_patterns[z]),
            )
            for z in possible:
                candidate = add_assignments(propagated, allowed_patterns[z])
                if candidate is None:
                    stats["theory_conflicts"] += 1
                    continue
                search(candidate, gap_decisions, depth + 1)
                if found is not None or time.perf_counter() >= deadline:
                    return
            return

        values = witness_values(propagated)
        violation = violated_nogood(values)
        if violation is not None:
            stats["lazy_witness_nogoods"] += 1
            for b, bit in violation:
                candidate = add_assignments(propagated, ((b, 1 - bit),))
                if candidate is None:
                    continue
                search(candidate, gap_decisions, depth + 1)
                if found is not None or time.perf_counter() >= deadline:
                    return
            return
        found = {"integer_values": values, "gap_values": dict(gap_decisions), "closure": propagated}

    started = time.perf_counter()
    search(initial, {})
    wall = time.perf_counter() - started

    result = {
        "input_sha256": hashlib.sha256(args.mps.read_bytes()).hexdigest(),
        "exact_extraction": {
            "integer_variables": len(integer_names),
            "comparison_binaries_eliminated": len(bit_edges),
            "comparison_relation_census": dict(relation_census),
            "allowed_pattern_indicators": len(allowed_patterns),
            "forbidden_six_bit_assignments": len(nogoods),
            "thirteen_way_clauses": len(clauses),
            "gap_binaries": len(gap_names),
            "truth_table_failures": truth_failures,
            "pattern_extraction_failures": extraction_failures,
        },
        "algorithm": "custom DPLL with incremental exact order/difference closure",
        "time_limit_seconds": args.time_limit,
        "wall_seconds": wall,
        "timed_out": found is None and time.perf_counter() >= deadline,
        "stats": stats,
        "feasible": found is not None,
    }

    if found is not None:
        values_by_name = {name: found["integer_values"][i] for i, name in enumerate(integer_names)}
        values_by_name.update(found["gap_values"])
        for b in comparison_names:
            values_by_name[b] = bit_from_values(b, found["integer_values"])
        for z, desired in allowed_patterns.items():
            values_by_name[z] = int(all(values_by_name[b] == bit for b, bit in desired))
        assert len(values_by_name) == len(variables)

        violations = []
        for r, constraint in enumerate(constraints):
            lhs = sum(coefficient * values_by_name[name] for name, coefficient in row_terms[r])
            rhs = int(round(constraint.RHS))
            ok = lhs <= rhs if constraint.Sense == "<" else lhs >= rhs if constraint.Sense == ">" else lhs == rhs
            if not ok:
                violations.append({"row": constraint.ConstrName, "lhs": lhs, "sense": constraint.Sense, "rhs": rhs})
        bounds_ok = all(v.LB <= values_by_name[v.VarName] <= v.UB for v in variables)
        integrality_ok = all(values_by_name[v.VarName] == round(values_by_name[v.VarName]) for v in variables)
        result["original_mps_audit"] = {
            "row_violations": len(violations),
            "violation_examples": violations[:20],
            "bounds_ok": bounds_ok,
            "integrality_ok": integrality_ok,
            "assigned_variables": len(values_by_name),
        }
        if not violations and bounds_ok and integrality_ok:
            args.solution.parent.mkdir(parents=True, exist_ok=True)
            with gzip.open(args.solution, "wt", encoding="utf-8", newline="\n") as handle:
                handle.write("=obj= 0\n")
                for name in sorted(values_by_name):
                    value = values_by_name[name]
                    if value != 0:
                        handle.write(f"{name} {value}\n")
        else:
            result["feasible"] = False

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
