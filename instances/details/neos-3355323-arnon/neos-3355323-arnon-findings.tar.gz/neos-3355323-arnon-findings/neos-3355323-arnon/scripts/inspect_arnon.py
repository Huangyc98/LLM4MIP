"""Read-only structural decoder for the anonymized feasibility instance."""
from __future__ import annotations

from collections import Counter, defaultdict
import argparse
import hashlib
import json
from pathlib import Path
import re

import gurobipy as gp


def numeric(name: str) -> int:
    match = re.search(r"(\d+)$", name)
    assert match
    return int(match.group(1))


def key_for(model: gp.Model, constraint: gp.Constr) -> tuple:
    expression = model.getRow(constraint)
    coefficients = tuple(sorted(Counter(round(expression.getCoeff(p), 12) for p in range(expression.size())).items()))
    return constraint.Sense, round(constraint.RHS, 12), expression.size(), coefficients


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    env = gp.Env(empty=True)
    env.setParam("OutputFlag", 0)
    env.start()
    model = gp.read(str(args.mps), env)
    variables = model.getVars()
    constraints = model.getConstrs()
    incidence = [[] for _ in variables]
    row_terms = []
    for r, constraint in enumerate(constraints):
        expression = model.getRow(constraint)
        terms = []
        for p in range(expression.size()):
            variable = expression.getVar(p)
            coefficient = expression.getCoeff(p)
            incidence[variable.index].append(r)
            terms.append((variable.index, coefficient))
        row_terms.append(terms)

    # Consecutive exact-template blocks expose the generator's construction.
    blocks = []
    start = 0
    current = key_for(model, constraints[0])
    for r in range(1, len(constraints) + 1):
        nxt = key_for(model, constraints[r]) if r < len(constraints) else None
        if nxt != current:
            sense, rhs, degree, signature = current
            blocks.append({
                "first_index": start,
                "last_index": r - 1,
                "first_name": constraints[start].ConstrName,
                "last_name": constraints[r - 1].ConstrName,
                "count": r - start,
                "sense": sense,
                "rhs": rhs,
                "degree": degree,
                "coefficient_multiset": [[value, count] for value, count in signature],
            })
            start = r
            current = nxt

    bound_degree_groups = defaultdict(list)
    for variable in variables:
        bound_degree_groups[(variable.VType, variable.LB, variable.UB, len(incidence[variable.index]))].append(variable.index)

    variable_profiles = []
    for profile, indices in sorted(bound_degree_groups.items(), key=lambda item: item[1][0]):
        variable_profiles.append({
            "type": profile[0], "lb": profile[1], "ub": profile[2], "degree": profile[3],
            "count": len(indices),
            "first_name": variables[min(indices)].VarName,
            "last_name": variables[max(indices)].VarName,
            "indices_consecutive": indices == list(range(min(indices), max(indices) + 1)),
        })

    general_integer = [v for v in variables if v.UB > 1.0]
    binary = [v for v in variables if v.UB <= 1.0]
    assert len(general_integer) == 144 and len(binary) == 10104

    comparator_records = defaultdict(list)
    for r, terms in enumerate(row_terms):
        big = [(j, value) for j, value in terms if abs(value) == 11]
        ints = [(j, value) for j, value in terms if variables[j].UB > 1]
        if len(terms) == 3 and len(big) == 1 and len(ints) == 2:
            b, big_coefficient = big[0]
            comparator_records[(b, tuple(sorted(j for j, _ in ints)))].append({
                "row": constraints[r].ConstrName,
                "sense": constraints[r].Sense,
                "rhs": constraints[r].RHS,
                "big_coefficient": big_coefficient,
                "integer_terms": [[variables[j].VarName, value] for j, value in ints],
            })

    comparison_by_binary = defaultdict(list)
    for (b, int_pair), records in comparator_records.items():
        comparison_by_binary[b].append((int_pair, records))

    comparison_summary = {
        "three_term_big_M_rows": sum(len(records) for records in comparator_records.values()),
        "unique_binary_integer_pair_triples": len(comparator_records),
        "binary_variables_in_comparators": len(comparison_by_binary),
        "records_per_triple": dict(Counter(len(records) for records in comparator_records.values())),
        "triples_per_binary": dict(Counter(len(records) for records in comparison_by_binary.values())),
        "integer_pair_multiplicity": dict(Counter(
            len(items) for items in defaultdict(list, {
                pair: [key for key in comparator_records if key[1] == pair]
                for pair in {key[1] for key in comparator_records}
            }).values()
        )),
        "examples": [
            {
                "binary": variables[b].VarName,
                "integer_pair": [variables[j].VarName for j in pair],
                "rows": records,
            }
            for (b, pair), records in list(comparator_records.items())[:12]
        ],
    }

    # Examine the 36 final >=1 clauses over the first 480 design binaries.
    final_cover_rows = []
    cover_variable_frequency = Counter()
    for r, terms in enumerate(row_terms):
        constraint = constraints[r]
        if constraint.Sense == "<" and constraint.RHS == -1 and all(value == -1 for _, value in terms):
            names = [variables[j].VarName for j, _ in terms]
            final_cover_rows.append({"row": constraint.ConstrName, "variables": names})
            cover_variable_frequency.update(names)

    # Constraint graph components, using variables as hyperedge connectors.
    adjacency = [[] for _ in constraints]
    for incident_rows in incidence:
        if not incident_rows:
            continue
        root = incident_rows[0]
        for r in incident_rows[1:]:
            adjacency[root].append(r)
            adjacency[r].append(root)
    visited = [False] * len(constraints)
    component_sizes = []
    for seed in range(len(constraints)):
        if visited[seed]:
            continue
        stack = [seed]
        visited[seed] = True
        row_count = 0
        vars_seen = set()
        while stack:
            r = stack.pop()
            row_count += 1
            vars_seen.update(j for j, _ in row_terms[r])
            for neighbor in adjacency[r]:
                if not visited[neighbor]:
                    visited[neighbor] = True
                    stack.append(neighbor)
        component_sizes.append({"rows": row_count, "variables": len(vars_seen)})

    def row_record(r: int) -> dict:
        constraint = constraints[r]
        return {
            "row": constraint.ConstrName,
            "sense": constraint.Sense,
            "rhs": constraint.RHS,
            "terms": [[variables[j].VarName, value] for j, value in row_terms[r]],
        }

    payload = {
        "input": str(args.mps),
        "sha256": hashlib.sha256(args.mps.read_bytes()).hexdigest(),
        "gurobi_version": list(gp.gurobi.version()),
        "parser_only": True,
        "optimize_called": False,
        "counts": {"variables": model.NumVars, "constraints": model.NumConstrs, "nonzeros": model.NumNZs},
        "objective_nonzeros": sum(v.Obj != 0 for v in variables),
        "variable_domains": {
            "binary_bounds": len(binary),
            "general_integer": len(general_integer),
            "general_integer_bounds": {
                f"[{lb},{ub}]": count
                for (lb, ub), count in Counter((v.LB, v.UB) for v in general_integer).items()
            },
        },
        "variable_profiles": variable_profiles,
        "consecutive_row_template_blocks": blocks,
        "comparators": comparison_summary,
        "final_cover_rows": {
            "count": len(final_cover_rows),
            "rows": final_cover_rows,
            "distinct_variables": len(cover_variable_frequency),
            "variable_frequency_histogram": dict(Counter(cover_variable_frequency.values())),
        },
        "constraint_graph_components": sorted(component_sizes, key=lambda item: -item["rows"]),
        "detailed_prefix_rows": [row_record(r) for r in range(216)],
        "detailed_structural_samples": [
            row_record(r)
            for r in list(range(19464, 19484))
            + list(range(20058, 20078))
            + list(range(21176, 21216))
        ],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "domains": payload["variable_domains"],
        "row_blocks": len(blocks),
        "comparators": comparison_summary,
        "cover_rows": payload["final_cover_rows"],
        "components": payload["constraint_graph_components"],
    }))


if __name__ == "__main__":
    main()
