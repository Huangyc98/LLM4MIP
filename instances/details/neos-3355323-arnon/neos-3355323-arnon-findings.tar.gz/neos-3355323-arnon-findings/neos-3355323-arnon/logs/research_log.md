# Research log

## Environment

- Time zone: Asia/Shanghai
- Structure/audit environment: Python 3 with Gurobi available
- SAT environment: Python 3 with PySAT and CaDiCaL available
- API model: `gpt-5.6-sol`
- API key source: external secret file; the key was never printed or copied into an artifact

## Acquisition and structure

PowerShell's initial HTTPS path encountered a local TLS/proxy failure. The official MIPLIB MPS was then downloaded with `httpx.Client(trust_env=False)`. Its SHA-256 was checked before analysis.

The original model was parsed read-only with:

```powershell
python '.\scripts\inspect_arnon.py' `
  '.\input\neos-3355323-arnon.mps.gz' `
  '.\structure\deep_structure.recheck.json'
```

No `optimize()` call was made. Deeper template extraction used `scripts/inspect_arnon.py`, which also records `optimize_called: false`.

## API calls

Both calls used `direct-api-research/call_direct.py` and loaded the API key from
an external secret file. Prompts, raw JSON responses, and session state are
omitted from the publication copy. The second request supplied the first
experiment's measured observations so the model could revise its plan.

| Call | Prompt | Response | Total tokens | Outcome |
|---|---|---|---:|---|
| 1 | `prompts/01_structure_decode.md` | `responses/01_structure_decode.json` | 8,651 | Proposed exact order reduction and structural classifiers |
| 2 | `prompts/02_csp_feedback.md` | `responses/02_csp_feedback.json` | 13,703 | Diagnosed weak global propagation; proposed full SAT/CDCL |

## Structural experiments

The exact custom CSP run was launched for 60 seconds and wrote `artifacts/order_csp_60s.json`. It terminated normally without a witness or proof.

The normalized exact export was produced with:

```powershell
python '.\scripts\solve_order_csp.py' `
  '.\input\neos-3355323-arnon.mps.gz' `
  '.\artifacts\unused.json' `
  '.\solutions\unused.sol.gz' `
  --normalized '.\artifacts\order_csp_normalized.json' `
  --extract-only
```

`scripts/solve_order_sat.py` converted that normalized representation to `artifacts/order_csp.cnf` and `artifacts/order_sat_mapping.json` and launched CaDiCaL 1.9.5 through PySAT. The bounded attempt was stopped by the orchestrator at 05:07:41.843 after 1,184.843 seconds of observed solve wall time. It had produced neither a SAT model nor an UNSAT result/proof, so its status is conservatively recorded as `UNKNOWN` in `artifacts/order_sat_result.json` and the final report.

## Verification discipline

- The untouched MPS is the only authority for a feasible claim.
- A SAT model must be translated to all 10,248 original variables and checked by `scripts/audit_original.py` against every original row.
- A bare UNSAT status is not treated as a portable proof; a proof trace and checker are required.
- No generic MIP optimization was run for this instance.
