#!/usr/bin/env python3
"""Exact, single-thread optimality certificate for neos-2629914-sudost.

The original MPS is parsed by :mod:`sudost_qap_search`.  Its 16-location
distance matrix is exactly ``10 + Manhattan distance`` on a small integer
grid.  Manhattan distance is a sum of cut metrics, so every assignment is
described by two nested subset chains.  This verifier computes exact
independent chain lower bounds and exhaustively checks every X/Y chain pair
that could possibly improve the incumbent.

All arithmetic is integer arithmetic.  No solver, tolerance, or floating
point comparison is used for the lower bound.
"""

from __future__ import annotations

import argparse
import itertools
import time
from collections import defaultdict
from decimal import Decimal
from pathlib import Path

from sudost_qap_search import (
    N,
    extract_qap,
    open_text,
    permutation_from_solution,
    read_solution,
    ordered_pairs,
    score,
    validate_solution,
)


FULL_MASK = (1 << N) - 1
TARGET_OBJECTIVE = 48_180

# Location p in the MPS maps to GRID_POINTS[p].  The script verifies this
# embedding against every off-diagonal entry of the parsed distance matrix.
GRID_POINTS = (
    (0, 0),
    (1, 0),
    (2, 0),
    (1, 1),
    (2, 1),
    (3, 1),
    (2, 2),
    (2, 3),
    (2, -1),
    (3, 2),
    (3, 3),
    (4, 3),
    (4, 4),
    (4, 5),
    (3, 4),
    (3, 5),
)

X_LEVELS = tuple(sorted({x for x, _ in GRID_POINTS}))
Y_LEVELS = tuple(sorted({y for _, y in GRID_POINTS}))
X_GROUP_SIZES = tuple(sum(x == level for x, _ in GRID_POINTS) for level in X_LEVELS)
Y_GROUP_SIZES = tuple(sum(y == level for _, y in GRID_POINTS) for level in Y_LEVELS)
X_CHAIN_SIZES = tuple(itertools.accumulate(X_GROUP_SIZES))[:-1]
Y_CHAIN_SIZES = tuple(itertools.accumulate(Y_GROUP_SIZES))[:-1]


def popcount(mask: int) -> int:
    return bin(mask).count("1")


def combination_masks(mask: int, size: int):
    bits = [i for i in range(N) if mask & (1 << i)]
    for combination in itertools.combinations(bits, size):
        result = 0
        for bit in combination:
            result |= 1 << bit
        yield result


def masks_by_size() -> list[list[int]]:
    grouped = [[] for _ in range(N + 1)]
    for mask in range(1 << N):
        grouped[popcount(mask)].append(mask)
    return grouped


def cut_values(flow: list[list[int]]) -> list[int]:
    """cut[mask] = sum F[i,j] over unordered pairs separated by mask."""
    values = [0] * (1 << N)
    for mask in range(1 << N):
        value = 0
        for i in range(N):
            in_i = bool(mask & (1 << i))
            for j in range(i + 1, N):
                if in_i != bool(mask & (1 << j)):
                    value += flow[i][j]
        values[mask] = value
    return values


def mps_integer(text: str) -> int:
    return int(Decimal(text.replace("D", "E").replace("d", "e")))


def verify_original_qap_bridge(
    path: Path,
    flow: list[list[int]],
    distance: list[list[int]],
    permutation: list[int],
) -> tuple[int, int]:
    """Mechanically verify the lower-bound bridge from the full original MPS.

    In particular, this checks all 32 permutation equations, all 48,000
    pairwise product lower-bound rows, objective coefficients, variable types,
    and bounds.  It also evaluates every one of the 51,872 original rows at
    the incumbent, including the redundant strengthening family.
    """
    pairs = ordered_pairs()
    values: dict[str, int] = {}
    for k, (i, j) in enumerate(pairs, start=1):
        values[f"C{k:04d}"] = distance[permutation[i]][permutation[j]]
    for i in range(N):
        for p in range(N):
            values[f"C{241 + N * i + p:04d}"] = int(permutation[i] == p)

    section = ""
    objective_row = ""
    row_types: dict[str, str] = {}
    rhs: dict[str, int] = defaultdict(int)
    objective: dict[str, int] = defaultdict(int)
    activity: dict[str, int] = defaultdict(int)
    structural_rows: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
    variables: set[str] = set()
    integer_variables: set[str] = set()
    bound_records: list[list[str]] = []
    integer_mode = False
    with open_text(path, "latin-1") as handle:
        for raw in handle:
            tokens = raw.split()
            if not tokens or tokens[0].startswith("*"):
                continue
            if tokens[0] in {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}:
                section = tokens[0]
                continue
            if section == "ROWS":
                row_types[tokens[1]] = tokens[0]
                if tokens[0] == "N":
                    objective_row = tokens[1]
            elif section == "COLUMNS":
                if "'MARKER'" in tokens:
                    if "'INTORG'" in tokens:
                        integer_mode = True
                    elif "'INTEND'" in tokens:
                        integer_mode = False
                    continue
                variable = tokens[0]
                variables.add(variable)
                if integer_mode:
                    integer_variables.add(variable)
                for row, coefficient_text in zip(tokens[1::2], tokens[2::2]):
                    coefficient = mps_integer(coefficient_text)
                    if row == objective_row:
                        objective[variable] += coefficient
                    else:
                        activity[row] += coefficient * values[variable]
                        if int(row[1:]) <= 48_032:
                            structural_rows[row][variable] += coefficient
            elif section == "RHS":
                for row, value_text in zip(tokens[1::2], tokens[2::2]):
                    rhs[row] += mps_integer(value_text)
            elif section == "RANGES":
                raise AssertionError("unexpected RANGES record")
            elif section == "BOUNDS":
                bound_records.append(tokens)

    assert len(variables) == 496
    assert len(row_types) == 51_873
    assert sum(kind == "E" for kind in row_types.values()) == 32
    assert sum(kind == "G" for kind in row_types.values()) == 51_840
    assert sum(kind == "N" for kind in row_types.values()) == 1
    assert integer_variables == {f"C{k:04d}" for k in range(241, 497)}

    for i in range(N):
        expected = {f"C{241 + N * i + p:04d}": 1 for p in range(N)}
        row = f"R{i + 1:04d}"
        assert row_types[row] == "E" and rhs[row] == 1
        assert dict(structural_rows[row]) == expected
    for p in range(N):
        expected = {f"C{241 + N * i + p:04d}": 1 for i in range(N)}
        row = f"R{17 + p:04d}"
        assert row_types[row] == "E" and rhs[row] == 1
        assert dict(structural_rows[row]) == expected

    required_location_pairs = {
        (p, q)
        for p in range(N)
        for q in range(N)
        if p != q and distance[p][q] > 11
    }
    assert len(required_location_pairs) == 200
    for k, (i, j) in enumerate(pairs, start=1):
        auxiliary = f"C{k:04d}"
        seen: set[tuple[int, int]] = set()
        first_row = 33 + (k - 1) * 200
        for rid in range(first_row, first_row + 200):
            row = f"R{rid:04d}"
            entries = dict(structural_rows[row])
            assert row_types[row] == "G"
            assert entries.pop(auxiliary) == 1 and len(entries) == 2
            locations: dict[int, int] = {}
            d = -rhs[row]
            for variable, coefficient in entries.items():
                assignment_row, location = divmod(int(variable[1:]) - 241, N)
                assert assignment_row in (i, j) and coefficient == -d
                locations[assignment_row] = location
            assert set(locations) == {i, j}
            p, q = locations[i], locations[j]
            assert d == distance[p][q] and d > 11
            seen.add((p, q))
        assert seen == required_location_pairs

    assert set(objective) == {f"C{k:04d}" for k in range(1, 241)}
    for k, (i, j) in enumerate(pairs, start=1):
        assert objective[f"C{k:04d}"] == flow[i][j] > 0
    lower = {variable: 0 for variable in variables}
    upper: dict[str, int | None] = {variable: None for variable in variables}
    for tokens in bound_records:
        kind, variable = tokens[0], tokens[2]
        value = mps_integer(tokens[3]) if len(tokens) > 3 else 0
        if kind == "LO":
            lower[variable] = value
        elif kind == "UP":
            upper[variable] = value
        else:
            raise AssertionError(f"unexpected bound type {kind}")
    assert all(lower[f"C{k:04d}"] == 11 and upper[f"C{k:04d}"] is None for k in range(1, 241))
    assert all(lower[f"C{k:04d}"] == 0 and upper[f"C{k:04d}"] == 1 for k in range(241, 497))

    violations = 0
    for row, kind in row_types.items():
        if kind == "N":
            continue
        lhs, row_rhs = activity[row], rhs[row]
        if (
            (kind == "E" and lhs != row_rhs)
            or (kind == "G" and lhs < row_rhs)
            or (kind == "L" and lhs > row_rhs)
        ):
            violations += 1
    assert violations == 0
    assert all(lower[v] <= values[v] and (upper[v] is None or values[v] <= upper[v]) for v in variables)
    assert all(values[v] == int(values[v]) for v in integer_variables)
    objective_value = sum(objective[v] * values[v] for v in variables)
    assert objective_value == TARGET_OBJECTIVE
    return objective_value, violations


def prefix_minima(
    chain_sizes: tuple[int, ...],
    cuts: list[int],
    grouped_masks: list[list[int]],
) -> list[dict[int, int]]:
    """Minimum chain cost ending at each mask at each threshold."""
    stages: list[dict[int, int]] = [
        {mask: cuts[mask] for mask in grouped_masks[chain_sizes[0]]}
    ]
    for stage in range(1, len(chain_sizes)):
        previous_size = chain_sizes[stage - 1]
        current: dict[int, int] = {}
        previous = stages[-1]
        for mask in grouped_masks[chain_sizes[stage]]:
            best_prefix = min(previous[submask] for submask in combination_masks(mask, previous_size))
            current[mask] = cuts[mask] + best_prefix
        stages.append(current)
    return stages


def enumerate_chains_below(
    chain_sizes: tuple[int, ...],
    cuts: list[int],
    grouped_masks: list[list[int]],
    prefixes: list[dict[int, int]],
    cap: int,
) -> dict[tuple[int, ...], int]:
    """Enumerate every nested chain with total cut value at most ``cap``."""
    chains: dict[tuple[int, ...], int] = {}
    last_stage = len(chain_sizes) - 1

    def visit(stage: int, mask: int, later_cost: int, backward: list[int]) -> None:
        if prefixes[stage][mask] + later_cost > cap:
            return
        if stage == 0:
            total = cuts[mask] + later_cost
            if total <= cap:
                chain = tuple(reversed(backward))
                chains[chain] = total
            return
        new_later_cost = later_cost + cuts[mask]
        previous_size = chain_sizes[stage - 1]
        for previous in combination_masks(mask, previous_size):
            if prefixes[stage - 1][previous] + new_later_cost <= cap:
                backward.append(previous)
                visit(stage - 1, previous, new_later_cost, backward)
                backward.pop()

    for outer in grouped_masks[chain_sizes[-1]]:
        if prefixes[last_stage][outer] <= cap:
            visit(last_stage, outer, 0, [outer])
    return chains


def chain_groups(chain: tuple[int, ...]) -> tuple[int, ...]:
    groups = [chain[0]]
    for previous, current in zip(chain, chain[1:]):
        groups.append(current ^ previous)
    groups.append(FULL_MASK ^ chain[-1])
    return tuple(groups)


def pack_chain(chain: tuple[int, ...]) -> int:
    packed = 0
    for stage, mask in enumerate(chain):
        packed |= mask << (N * stage)
    return packed


def x_contribution_variants(group_mask: int, allowed_x_levels: tuple[int, ...]) -> list[int]:
    """Packed X-chain contributions for all bijections within one Y level."""
    facilities = [i for i in range(N) if group_mask & (1 << i)]
    if len(facilities) != len(allowed_x_levels):
        raise ValueError("Y group has the wrong cardinality")
    variants: list[int] = []
    for assignment in itertools.permutations(facilities):
        cumulative = [0] * len(X_CHAIN_SIZES)
        for x_level, facility in zip(allowed_x_levels, assignment):
            bit = 1 << facility
            for threshold in range(x_level, len(X_CHAIN_SIZES)):
                cumulative[threshold] |= bit
        packed = 0
        for threshold, mask in enumerate(cumulative):
            packed |= mask << (N * threshold)
        variants.append(packed)
    return variants


def compatible_minimum(
    x_chains: dict[tuple[int, ...], int],
    y_chains: dict[tuple[int, ...], int],
) -> tuple[int | None, int, int]:
    """Exhaustively test all grid-compatible X labelings for every Y chain."""
    packed_x_cost = {pack_chain(chain): cost for chain, cost in x_chains.items()}
    allowed_x_by_y = tuple(
        tuple(X_LEVELS.index(x) for x, y0 in GRID_POINTS if y0 == y)
        for y in Y_LEVELS
    )
    tested = 0
    matches = 0
    best: int | None = None
    for y_chain, y_cost in y_chains.items():
        y_groups = chain_groups(y_chain)
        variants = [
            x_contribution_variants(group, allowed)
            for group, allowed in zip(y_groups, allowed_x_by_y)
        ]
        for contributions in itertools.product(*variants):
            tested += 1
            packed_x_chain = 0
            for contribution in contributions:
                packed_x_chain |= contribution
            x_cost = packed_x_cost.get(packed_x_chain)
            if x_cost is None:
                continue
            matches += 1
            total = x_cost + y_cost
            if best is None or total < best:
                best = total
    return best, tested, matches


def assignment_chain_costs(
    permutation: list[int], cuts: list[int]
) -> tuple[int, int, tuple[int, ...], tuple[int, ...]]:
    x_chain = tuple(
        sum(
            1 << facility
            for facility, location in enumerate(permutation)
            if GRID_POINTS[location][0] <= threshold
        )
        for threshold in X_LEVELS[:-1]
    )
    y_chain = tuple(
        sum(
            1 << facility
            for facility, location in enumerate(permutation)
            if GRID_POINTS[location][1] <= threshold
        )
        for threshold in Y_LEVELS[:-1]
    )
    return (
        sum(cuts[mask] for mask in x_chain),
        sum(cuts[mask] for mask in y_chain),
        x_chain,
        y_chain,
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "mps",
        nargs="?",
        type=Path,
        default=Path("input/neos-2629914-sudost.mps.gz"),
    )
    parser.add_argument(
        "--solution", type=Path, default=Path("solutions/sudost_48180.sol")
    )
    args = parser.parse_args()
    started = time.monotonic()

    flow, distance = extract_qap(args.mps)
    if len(GRID_POINTS) != N:
        raise SystemExit("Grid embedding has the wrong size")
    for p in range(N):
        for q in range(N):
            if p == q:
                continue
            manhattan = abs(GRID_POINTS[p][0] - GRID_POINTS[q][0]) + abs(
                GRID_POINTS[p][1] - GRID_POINTS[q][1]
            )
            if distance[p][q] != 10 + manhattan:
                raise SystemExit(f"Distance embedding mismatch at ({p}, {q})")

    grouped_masks = masks_by_size()
    cuts = cut_values(flow)
    x_prefixes = prefix_minima(X_CHAIN_SIZES, cuts, grouped_masks)
    y_prefixes = prefix_minima(Y_CHAIN_SIZES, cuts, grouped_masks)
    min_x = min(x_prefixes[-1].values())
    min_y = min(y_prefixes[-1].values())

    undirected_flow_sum = sum(flow[i][j] for i in range(N) for j in range(i + 1, N))
    constant = 20 * undirected_flow_sum
    target_grid_cost = (TARGET_OBJECTIVE - constant) // 2
    if constant + 2 * target_grid_cost != TARGET_OBJECTIVE:
        raise SystemExit("Target objective has the wrong parity")

    # If a solution were strictly better, its integer grid cost would be at most
    # target_grid_cost-1.  Independent axis minima then impose these two caps.
    improving_cap = target_grid_cost - 1
    x_cap = improving_cap - min_y
    y_cap = improving_cap - min_x
    x_chains = enumerate_chains_below(
        X_CHAIN_SIZES, cuts, grouped_masks, x_prefixes, x_cap
    )
    y_chains = enumerate_chains_below(
        Y_CHAIN_SIZES, cuts, grouped_masks, y_prefixes, y_cap
    )
    best_near_target, tested, matches = compatible_minimum(x_chains, y_chains)

    permutation = permutation_from_solution(args.solution)
    incumbent_objective = score(permutation, flow, distance)
    bridge_objective, bridge_violations = verify_original_qap_bridge(
        args.mps, flow, distance, permutation
    )
    incumbent_x, incumbent_y, incumbent_x_chain, incumbent_y_chain = assignment_chain_costs(
        permutation, cuts
    )
    exact_report = validate_solution(args.mps, read_solution(args.solution))

    expected_tests_per_y = 1
    for size in Y_GROUP_SIZES:
        factorial = 1
        for value in range(2, size + 1):
            factorial *= value
        expected_tests_per_y *= factorial

    print(f"grid points={GRID_POINTS}")
    print(f"X group sizes={X_GROUP_SIZES}, chain sizes={X_CHAIN_SIZES}")
    print(f"Y group sizes={Y_GROUP_SIZES}, chain sizes={Y_CHAIN_SIZES}")
    print(f"undirected flow sum={undirected_flow_sum}, constant={constant}")
    print(f"independent chain minima: X={min_x}, Y={min_y}")
    print(f"strict-improvement caps: X<={x_cap}, Y<={y_cap}")
    print(f"enumerated chains: X={len(x_chains)}, Y={len(y_chains)}")
    print(
        f"compatibility assignments={tested} "
        f"({expected_tests_per_y} per Y chain), matches={matches}, "
        f"minimum matched sum={best_near_target}"
    )
    print(
        f"incumbent grid costs: X={incumbent_x}, Y={incumbent_y}, "
        f"sum={incumbent_x + incumbent_y}"
    )
    print(f"incumbent X chain={incumbent_x_chain}")
    print(f"incumbent Y chain={incumbent_y_chain}")
    print(
        f"original-QAP bridge: objective={bridge_objective}, "
        f"full-row violations={bridge_violations}, "
        "assignment rows=32, product lower-bound rows=48000"
    )
    print(f"original-MPS validation={exact_report}")

    if min_x != 2_254 or min_y != 3_793:
        raise SystemExit("Independent chain minima do not match the certificate")
    if len(x_chains) != 32_367 or len(y_chains) != 8_147:
        raise SystemExit("Near-bound chain counts do not match the certificate")
    if tested != len(y_chains) * expected_tests_per_y or tested != 14_078_016:
        raise SystemExit("Compatibility enumeration count is incomplete")
    if best_near_target is not None and best_near_target < target_grid_cost:
        raise SystemExit("Found a grid assignment better than the claimed optimum")
    if incumbent_x + incumbent_y != target_grid_cost or incumbent_objective != TARGET_OBJECTIVE:
        raise SystemExit("Incumbent does not attain the lower bound")
    if bridge_objective != TARGET_OBJECTIVE or bridge_violations:
        raise SystemExit("Original MPS does not match the certified QAP bridge")
    if exact_report["objective"] != TARGET_OBJECTIVE or any(
        exact_report[key]
        for key in ("constraint_violations", "bound_violations", "integrality_violations")
    ):
        raise SystemExit("Incumbent is not an exact feasible solution of the original MPS")

    print(
        f"CERTIFIED OPTIMUM: {TARGET_OBJECTIVE} "
        f"(lower bound {constant} + 2*{target_grid_cost}); "
        f"elapsed={time.monotonic() - started:.2f}s"
    )


if __name__ == "__main__":
    main()
