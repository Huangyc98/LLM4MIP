# Formal Solving Strategy

## Objective and comparison rule

This is a minimization instance. Every experiment must state whether it targets the primal bound, dual bound, gap, or proof. Smaller verified feasible objectives improve the primal bound; larger globally valid lower bounds improve the dual bound. The pre-experiment public primal and dual targets are currently unknown because no trustworthy numeric targets survived Background. The cumulative controller ledger is the current internal comparison source.

## Phase 1: deterministic representation audit

Run `methods/domain_structure_audit.py` with a fixed seed. It will parse the supplied MPS without an optimization solver, reconstruct objective and bound endpoints, compute the domain-implied lower bound, detect assignment-like equality components, and summarize inequality support signatures. Acceptance requires successful parsing, positive measured work units, a finite or explicitly diagnosed objective-domain bound, and machine-readable artifacts. The pivot condition is whether the equality graph and row signatures support the hypothesized assignment decomposition.

## Phase 2: primal construction

If the audit confirms an assignment master, build a feasible permutation and eliminate or minimize each continuous variable from its associated inequality block. Validate feasibility against every original row before writing `best.sol`. Search swap and ejection-chain neighborhoods with incremental block evaluation, deterministic seeded restarts, and strict-improvement acceptance. If repair repeatedly fails, diagnose sign handling, row orientation, and continuous reconstruction before enlarging the neighborhood.

## Phase 3: globally valid lower bound

Derive a Lagrangian relaxation retaining the assignment equations. Aggregate coupling rows only when their coefficient patterns justify it. Solve assignment subproblems with a custom matching algorithm and update nonnegative multipliers. Record the best mathematically valid lower bound, multiplier state, iterations, and termination reason. If the relaxation does not improve the domain bound, revise the relaxed partition or use a stronger matching-based envelope.

## Phase 4: proof-oriented method

Attempt exact threshold feasibility only after a candidate incumbent exists and the audit establishes a sound finite reduction. Prefer conflict generation over all 51,840 rows rather than materializing an unnecessarily large initial encoding. If using CaDiCaL, preserve the generated CNF and DRAT certificate and verify it independently with `drat-trim`. Otherwise use exact propagated branch-and-bound with a reproducible search certificate, recognizing that custom claims alone do not establish formal optimality.

## Runtime gates

Each new method receives a small deterministic dry run before scaling. At least four materially distinct structure-specific custom methods must be launched, at least three must complete successfully, successful runtime must total at least 3,600 seconds, and at least one scaled run must execute for 1,800 seconds. Runs must perform positive numeric work and may not idle to meet a gate. Methods that exhaust a small neighborhood will be enlarged, revised, or replaced.

## Required run records

Every custom run must write `method_result.json` with status, algorithm family, algorithm role, hypothesis, positive work units, termination reason, target bound, seed, runtime, acceptance criterion, and pivot condition. Candidate solutions and certificates are preserved separately and must be controller-verified before they affect reported bounds.

## Solver policy

The automatic Gurobi and COPT baselines failed to launch and produced no evidence. No duplicate baseline is requested. Any later direct solver run is deferred until all custom gates are met, is limited to at most 600 seconds, and must fit within the controller-reported global remaining solver allowance. Such a run must have a narrow incumbent-validation or proof hypothesis rather than serve as generic parameter tuning.

## Stop conditions

Stop immediately with `optimal` only if trusted evidence gives matching verified primal and dual bounds within tolerance or an independently checked exact proof. Stop with `infeasible` only after a strict solver status or independently verified reproducible certificate. A time limit, missing incumbent, or custom assertion is never a proof.