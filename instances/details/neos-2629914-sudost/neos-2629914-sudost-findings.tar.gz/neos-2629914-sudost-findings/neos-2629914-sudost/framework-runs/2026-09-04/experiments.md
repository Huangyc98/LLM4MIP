# Experiment ledger

This file is generated from `runs/*/result.json` by the controller.

| Run | Solver | Status | Primal | Dual | Gap | Verified | Runtime (s) |
|---|---|---|---:|---:|---:|---|---:|
| `custom-20260904-232141-664bb9fd` | custom-python | success | — | — | — | not checked | 1.43669652938843 |
| `custom-20260904-232323-148ad30a` | custom-python | failed | — | — | — | not checked | 0.730625629425049 |
| `custom-20260904-232439-aa4d53c6` | custom-python | success | — | — | — | not checked | 0.831063032150269 |
| `custom-20260904-232622-a41f4c5c` | custom-python | success | — | 39621.99960377 | — | not checked | 106.001661062241 |
| `custom-20260904-233001-f15114db` | custom-python | ERROR | — | — | — | not checked | 0.730222463607788 |
| `custom-20260904-233504-8f8ac766` | custom-python | success | — | 39621.99960377 | — | not checked | 100.103341341019 |
| `custom-20260904-233734-a82777f0` | custom-python | ERROR | — | — | — | not checked | 0.730217933654785 |
| `custom-20260904-233904-f695e493` | custom-python | ERROR | — | — | — | not checked | 0.680137157440186 |
| `custom-20260904-234040-cca275d4` | custom-python | success | — | — | — | not checked | 105.103804349899 |
