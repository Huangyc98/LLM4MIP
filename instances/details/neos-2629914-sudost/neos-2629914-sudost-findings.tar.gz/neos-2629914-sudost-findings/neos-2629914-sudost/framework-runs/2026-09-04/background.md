# Background

## Instance identity

- Instance: `neos-2629914-sudost`
- Objective sense: minimization.
- Model fingerprint: `-1863754863`.
- Uncompressed model SHA-256: `9ecc76582a0fd3e28bd5c0064ec91edc9daa00ae13b3a92130cfeaa1575cf8d9`.
- Trusted structural source: controller-generated `structure.json` from the supplied MPS model.

## Measured formulation structure

The model has 496 variables: 256 integer variables and 240 continuous variables. All 256 integer variables have bounds 0 and 1, although the structural reader labels them as general integers rather than binary variables. All 240 continuous variables have finite positive lower bounds; the reported nonzero lower bound is 11. The integer variables have finite upper bound 1.

There are 51,872 linear constraints: 32 equalities and 51,840 greater-than inequalities, with 209,792 matrix nonzeros. There are no quadratic, SOS, or general constraints. Objective coefficients are nonzero on 240 variables and range from 11 to 19; the 256 bounded integer variables have zero objective coefficients. Matrix coefficients are integral and range from -224 to 213.

The combination of 256 bounded integer variables, exactly 32 equalities, and a large family of inequalities coupled to 240 objective-bearing continuous variables suggests an assignment or permutation master with an extended continuous cost formulation. A 16 by 16 assignment representation would naturally contain 256 decisions and 32 row/column equations, while 240 equals twice `C(16,2)`. This is a testable structural hypothesis, not yet an established interpretation of the named variables or constraints.

## Public targets and baseline evidence

The recovered prompt contains no trustworthy numeric public primal bound, public dual bound, or relative gap. Those targets are therefore **unknown** and must not be guessed. Any later claim of a public improvement requires a sourced public bound. Internally, every verified feasible objective and valid lower bound will still be compared against the cumulative controller ledger.

At Formal Solving entry, the mandatory 120-second Gurobi/euler4 and COPT/altman diagnostic baselines both failed to launch because remote launcher PID files were missing. They produced no mathematical evidence and must not be duplicated or extended as if they had run. The controller-generated `experiments.json` remains the authority for any later recovered run state.

## Research interpretation

For minimization, a smaller verified feasible objective improves the primal bound, while a larger globally valid lower bound improves the dual bound. The immediate need is to verify the coefficient pattern and identify whether the 32 equations really define an assignment polytope. The large inequality family may then admit delayed constraint evaluation, Lagrangian relaxation, threshold feasibility testing, or exact separation.

## Evidence limitations

Background terminated before sourced MIPLIB pages and research notes were preserved in artifacts. No unsupported bibliographic or public-bound claim is introduced during recovery. The initial custom audit relies only on the supplied mathematical model and emits reproducible aggregate evidence. Exact interpretation, public targets, and any official incumbent must be added only after trustworthy evidence becomes available.