import argparse, json, math, os, sys, time
from collections import defaultdict, deque


def popcount(x):
    # Compatibility-safe replacement for int.bit_count().
    return bin(int(x)).count('1')


def parse_num(s):
    s = s.strip().replace('D', 'E').replace('d', 'e')
    return float(s)


def parse_mps(path):
    section = None
    sense = 'min'
    rowsense = {}
    objrow = None
    cols = defaultdict(dict)
    obj = defaultdict(float)
    rhs = defaultdict(float)
    lb = defaultdict(lambda: 0.0)
    ub = defaultdict(lambda: math.inf)
    integer = set()
    allvars = set()
    in_integer = False
    with open(path, 'r', errors='replace') as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith('*'):
                continue
            tok = line.split()
            head = tok[0].upper()
            if head in ('NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA','OBJSENSE','OBJNAME'):
                section = head
                if head == 'ENDATA':
                    break
                continue
            if section == 'OBJSENSE':
                if head.startswith('MAX'):
                    sense = 'max'
                elif head.startswith('MIN'):
                    sense = 'min'
                continue
            if section == 'ROWS':
                if len(tok) >= 2:
                    typ, name = tok[0].upper(), tok[1]
                    rowsense[name] = typ
                    if typ == 'N' and objrow is None:
                        objrow = name
                continue
            if section == 'COLUMNS':
                if len(tok) >= 3 and tok[1].strip("'").upper() == 'MARKER':
                    marker = tok[2].strip("'").upper()
                    in_integer = marker == 'INTORG'
                    continue
                var = tok[0]
                allvars.add(var)
                if in_integer:
                    integer.add(var)
                pairs = tok[1:]
                for k in range(0, len(pairs)-1, 2):
                    row, valtxt = pairs[k], pairs[k+1]
                    val = parse_num(valtxt)
                    if row == objrow:
                        obj[var] += val
                    else:
                        cols[var][row] = cols[var].get(row, 0.0) + val
                continue
            if section == 'RHS':
                pairs = tok[1:]
                for k in range(0, len(pairs)-1, 2):
                    rhs[pairs[k]] = parse_num(pairs[k+1])
                continue
            if section == 'RANGES':
                # Ranged rows are not used for the assignment signature.
                continue
            if section == 'BOUNDS':
                typ = tok[0].upper()
                if len(tok) < 3:
                    continue
                var = tok[2]
                allvars.add(var)
                val = parse_num(tok[3]) if len(tok) >= 4 else None
                if typ == 'LO': lb[var] = val
                elif typ == 'UP': ub[var] = val
                elif typ == 'FX': lb[var] = val; ub[var] = val
                elif typ == 'FR': lb[var] = -math.inf; ub[var] = math.inf
                elif typ == 'MI': lb[var] = -math.inf
                elif typ == 'PL': ub[var] = math.inf
                elif typ == 'BV': lb[var] = 0.0; ub[var] = 1.0; integer.add(var)
                elif typ == 'LI': lb[var] = val; integer.add(var)
                elif typ == 'UI': ub[var] = val; integer.add(var)
    return sense, rowsense, objrow, dict(cols), dict(obj), dict(rhs), dict(lb), dict(ub), integer, allvars


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--seed', type=int, default=0)
    args = ap.parse_args()
    t0 = time.time()
    requested = int(os.environ.get('CUSTOM_TIME_LIMIT', '120'))
    result = {
        'status':'failed',
        'algorithm_family':'exact projected assignment-master relaxation by subset dynamic programming',
        'algorithm_role':'dual_bound',
        'hypothesis':'The audited 32 equations contain an exact 16-by-16 bipartite assignment master whose optimized objective plus independent variable-domain contributions gives a globally valid bound.',
        'seed':args.seed,
        'requested_runtime_seconds':requested,
        'acceptance_criterion':'Accept only a complete balanced bipartite assignment component with unit equalities, one binary edge for every pair, finite residual domain bound, and exact certificate recomputation.',
        'pivot_condition':'If the signature is valid but the bound is flat, pivot to a constraint-aware Lagrangian relaxation; if rejected, diagnose the precise signature mismatch before revising representation.',
        'target_bound':'Improve or independently substantiate the experiment candidate dual bound 39622.0 and compare it with the public dual target in background.md.',
        'work_unit_name':'validated incidences and subset-DP transitions',
        'work_units':1,
        'artifacts':['assignment_bound.json']
    }
    cert = {'accepted':False}
    work = 1
    try:
        sense, rs, objrow, cols, obj, rhs, lb, ub, integer, allvars = parse_mps(args.model)
        rowvars = defaultdict(list)
        for v, entries in cols.items():
            for r, a in entries.items():
                if abs(a) > 1e-12:
                    rowvars[r].append((v,a))
                    work += 1
        candidates = []
        for r, va in rowvars.items():
            if rs.get(r) != 'E' or abs(rhs.get(r,0.0)-1.0) > 1e-9 or len(va) != 16:
                continue
            good = True
            for v,a in va:
                if abs(a-1.0) > 1e-9 or v not in integer or abs(lb.get(v,0.0)) > 1e-9 or abs(ub.get(v,math.inf)-1.0) > 1e-9:
                    good = False; break
            if good:
                candidates.append(r)
        cset = set(candidates)
        edge_rows = defaultdict(list)
        for r in candidates:
            for v,a in rowvars[r]:
                edge_rows[v].append(r)
        adj = defaultdict(list)
        pairvar = {}
        for v, rr in edge_rows.items():
            if len(rr) == 2 and rr[0] != rr[1]:
                a,b = rr
                adj[a].append(b); adj[b].append(a)
                pairvar.setdefault((a,b),[]).append(v)
                pairvar.setdefault((b,a),[]).append(v)
        # Find a balanced connected bipartite component with 16 rows on each side.
        chosen = None
        seen = set()
        for root in sorted(candidates):
            if root in seen: continue
            color = {root:0}; q = deque([root]); ok = True
            while q:
                u=q.popleft(); seen.add(u)
                for v in adj[u]:
                    if v not in color:
                        color[v]=1-color[u]; q.append(v)
                    elif color[v] == color[u]:
                        ok=False
            left=sorted([r for r,c in color.items() if c==0])
            right=sorted([r for r,c in color.items() if c==1])
            if ok and len(left)==16 and len(right)==16:
                full=True; matrix=[]; used=[]
                for a in left:
                    row=[]
                    for b in right:
                        vv=pairvar.get((a,b),[])
                        if len(vv)!=1:
                            full=False; break
                        row.append(vv[0]); used.append(vv[0])
                    if not full: break
                    matrix.append(row)
                if full and len(set(used))==256:
                    chosen=(left,right,matrix); break
        if chosen is None:
            raise ValueError('No validated complete 16-by-16 bipartite assignment component was found; candidate equality rows=%d' % len(candidates))
        left,right,matrix=chosen
        aset=set(v for row in matrix for v in row)
        # Compute a safe domain-only contribution for variables outside the assignment component.
        residual=0.0
        for v in allvars:
            if v in aset: continue
            c=obj.get(v,0.0)
            if abs(c) <= 1e-18: continue
            if sense=='min':
                x=lb.get(v,0.0) if c>0 else ub.get(v,math.inf)
                if not math.isfinite(x): raise ValueError('Residual objective is unbounded below at variable '+v)
            else:
                x=ub.get(v,math.inf) if c>0 else lb.get(v,0.0)
                if not math.isfinite(x): raise ValueError('Residual objective is unbounded above at variable '+v)
            residual += c*x
            work += 1
        n=16; size=1<<n
        bad=math.inf if sense=='min' else -math.inf
        dp=[bad]*size; dp[0]=0.0
        parent=[None]*size
        transitions=0
        for mask in range(size):
            i=popcount(mask)
            if i>=n or not math.isfinite(dp[mask]): continue
            for j in range(n):
                if mask & (1<<j): continue
                nm=mask|(1<<j); val=dp[mask]+obj.get(matrix[i][j],0.0)
                transitions += 1
                improve = val < dp[nm]-1e-12 if sense=='min' else val > dp[nm]+1e-12
                if improve:
                    dp[nm]=val; parent[nm]=(mask,j)
        work += transitions
        if not math.isfinite(dp[-1]): raise ValueError('Subset DP did not produce a complete matching')
        selected=[]; mask=size-1
        while mask:
            prev,j=parent[mask]
            i=popcount(prev)
            selected.append(matrix[i][j]); mask=prev
        selected.reverse()
        recomputed=sum(obj.get(v,0.0) for v in selected)
        if abs(recomputed-dp[-1]) > 1e-7*max(1.0,abs(dp[-1])):
            raise ValueError('Matching objective recomputation failed')
        bound=residual+recomputed
        cert={
            'accepted':True,'objective_sense':sense,'objective_row':objrow,
            'left_rows':left,'right_rows':right,'assignment_variable_count':len(aset),
            'selected_variables':selected,'matching_objective':recomputed,
            'residual_domain_contribution':residual,'candidate_dual_bound':bound,
            'dp_states':size,'dp_transitions':transitions,
            'validity':'All original constraints except the selected assignment equalities are relaxed. Variables outside the assignment component are optimized independently over their original bounds. Therefore the value is a global lower bound for minimization or global upper bound for maximization.'
        }
        result.update({'status':'success','accepted':True,'candidate_dual_bound':bound,
                       'objective_sense':sense,'work_units':work,
                       'termination_reason':'Validated the complete assignment signature and exhausted all 2^16 subset-DP states with exact objective recomputation.'})
    except Exception as e:
        result.update({'accepted':False,'work_units':max(1,work),'termination_reason':'Validation rejected: '+str(e)})
        cert.update({'error':str(e)})
    result['runtime_seconds']=time.time()-t0
    with open('assignment_bound.json','w') as f: json.dump(cert,f,indent=2,sort_keys=True)
    with open('method_result.json','w') as f: json.dump(result,f,indent=2,sort_keys=True)
    return 0 if result['status']=='success' else 2

if __name__=='__main__':
    sys.exit(main())
