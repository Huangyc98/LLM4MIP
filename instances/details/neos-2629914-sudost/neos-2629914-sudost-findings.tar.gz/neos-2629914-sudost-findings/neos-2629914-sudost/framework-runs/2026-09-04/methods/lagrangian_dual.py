import argparse, gzip, json, math, os, random, time


def open_text(path):
    return gzip.open(path, 'rt', errors='replace') if path.lower().endswith('.gz') else open(path, 'r', errors='replace')


def parse_mps(path):
    section = None
    obj_sense = 'MIN'
    row_type = {}
    row_order = []
    obj_row = None
    cols = {}
    costs = {}
    rhs = {}
    lo, up = {}, {}
    integer_mode = False
    ranges_seen = False
    with open_text(path) as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith('*'):
                continue
            tok = line.split()
            head = tok[0].upper()
            if head in ('NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA','OBJSENSE','OBJNAME'):
                section = head
                if head == 'ENDATA':
                    break
                continue
            if section == 'OBJSENSE':
                obj_sense = tok[0].upper()
                continue
            if section == 'ROWS':
                typ, name = tok[0].upper(), tok[1]
                row_type[name] = typ
                if typ == 'N' and obj_row is None:
                    obj_row = name
                elif typ in ('E','L','G'):
                    row_order.append(name)
                continue
            if section == 'COLUMNS':
                if any('MARKER' in x.upper() for x in tok):
                    joined = ' '.join(tok).upper()
                    if 'INTORG' in joined: integer_mode = True
                    if 'INTEND' in joined: integer_mode = False
                    continue
                var = tok[0]
                if var not in cols:
                    cols[var] = []
                    lo[var] = 0.0
                    up[var] = math.inf
                if integer_mode and math.isinf(up[var]):
                    up[var] = 1.0
                for k in range(1, len(tok)-1, 2):
                    r, val = tok[k], float(tok[k+1])
                    if r == obj_row:
                        costs[var] = costs.get(var, 0.0) + val
                    elif r in row_type and row_type[r] != 'N':
                        cols[var].append((r, val))
                continue
            if section == 'RHS':
                for k in range(1, len(tok)-1, 2):
                    r, val = tok[k], float(tok[k+1])
                    if r == obj_row and abs(val) > 1e-12:
                        raise ValueError('Nonzero objective-row RHS is unsupported because its offset convention is ambiguous')
                    if r in row_type and row_type[r] != 'N':
                        rhs[r] = val
                continue
            if section == 'RANGES':
                ranges_seen = True
                continue
            if section == 'BOUNDS':
                typ = tok[0].upper()
                var = tok[2]
                val = float(tok[3]) if len(tok) > 3 else 0.0
                if var not in cols:
                    cols[var] = []
                    lo[var], up[var] = 0.0, math.inf
                if typ == 'BV': lo[var], up[var] = 0.0, 1.0
                elif typ in ('LO','LI'): lo[var] = val
                elif typ in ('UP','UI'): up[var] = val
                elif typ == 'FX': lo[var], up[var] = val, val
                elif typ == 'FR': lo[var], up[var] = -math.inf, math.inf
                elif typ == 'MI': lo[var] = -math.inf
                elif typ == 'PL': up[var] = math.inf
                continue
    if ranges_seen:
        raise ValueError('Ranged rows are unsupported in this certificate generator')
    if obj_sense.startswith('MAX'):
        raise ValueError('This implementation expects a minimization model')
    for v in cols:
        if not math.isfinite(lo[v]) or not math.isfinite(up[v]):
            raise ValueError('Variable %s lacks finite bounds required by the box relaxation' % v)
        if lo[v] > up[v]:
            raise ValueError('Inconsistent bounds for '+v)
    rid = {r:i for i,r in enumerate(row_order)}
    variables = []
    for v, entries in cols.items():
        variables.append((v, costs.get(v,0.0), lo[v], up[v], [(rid[r],a) for r,a in entries]))
    b = [rhs.get(r,0.0) for r in row_order]
    typ = [row_type[r] for r in row_order]
    return row_order, typ, b, variables


def evaluate(lam, b, variables, need_grad):
    value = -sum(lam[i]*b[i] for i in range(len(b)))
    grad = [-x for x in b] if need_grad else None
    chosen_upper = 0
    for _, c, lower, upper, ent in variables:
        rc = c
        for i,a in ent:
            rc += lam[i]*a
        if rc < 0.0:
            x = upper
            chosen_upper += 1
        else:
            x = lower
        value += rc*x
        if need_grad and x != 0.0:
            for i,a in ent:
                grad[i] += a*x
    return value, grad, chosen_upper


def project(lam, types):
    for i,t in enumerate(types):
        if t == 'L' and lam[i] < 0.0: lam[i] = 0.0
        elif t == 'G' and lam[i] > 0.0: lam[i] = 0.0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--runtime', type=float, default=1810.0)
    ap.add_argument('--seed', type=int, default=2629914)
    ap.add_argument('--target', type=float, default=40000.0)
    args = ap.parse_args()
    random.seed(args.seed)
    started = time.monotonic()
    rows, types, b, variables = parse_mps(args.model)
    nrow = len(rows)
    lam = [0.0]*nrow
    best_lam = list(lam)
    best_raw, grad, chosen = evaluate(lam,b,variables,True)
    initial = best_raw
    trace = open('dual_trace.csv','w')
    trace.write('iteration,elapsed,raw_bound,incumbent_bound,step,gradient_norm,chosen_upper\n')
    iteration = 0
    no_improve = 0
    phase = 0
    alpha = 1.65
    stop_at = started + args.runtime
    while time.monotonic() < stop_at:
        iteration += 1
        raw, grad, chosen = evaluate(lam,b,variables,True)
        if raw > best_raw:
            best_raw = raw
            best_lam = list(lam)
            no_improve = 0
        else:
            no_improve += 1
        norm2 = sum(g*g for g in grad)
        if norm2 <= 1e-30:
            break
        gap_to_target = max(1e-5, args.target - raw)
        step = alpha*gap_to_target/norm2
        # Prevent a misleading target from causing permanently enormous jumps.
        step = min(step, 100.0/math.sqrt(norm2))
        for i in range(nrow):
            lam[i] += step*grad[i]
        project(lam,types)
        if no_improve >= 250:
            phase += 1
            alpha = max(0.04, alpha*0.72)
            # Return to the best certified point and use a small deterministic
            # perturbation only along multiplier-feasible directions.
            lam = list(best_lam)
            scale = 0.0025*(0.8**min(phase,12))
            for i,t in enumerate(types):
                d = (random.random()-0.5)*scale
                lam[i] += d
            project(lam,types)
            no_improve = 0
        if iteration % 50 == 0:
            elapsed = time.monotonic()-started
            trace.write('%d,%.6f,%.12g,%.12g,%.12g,%.12g,%d\n' % (iteration,elapsed,raw,best_raw,step,math.sqrt(norm2),chosen))
            trace.flush()
    # Recompute from the retained full vector rather than trusting cached state.
    recomputed, _, chosen = evaluate(best_lam,b,variables,False)
    # Conservative allowance for floating summation. The certificate contains
    # the unrounded vector so an independent checker can recompute more tightly.
    magnitude = sum(abs(best_lam[i]*b[i]) for i in range(nrow))
    safety = 1e-8*(1.0 + magnitude + sum(abs(x) for x in best_lam))
    certified = recomputed - safety
    elapsed = time.monotonic()-started
    trace.close()
    cert = {
      'certificate_type':'lagrangian_box_relaxation',
      'objective_sense':'minimize',
      'derivation':'For each feasible x, sign-restricted multipliers make lambda*(Ax-b) nonpositive. Minimizing the Lagrangian independently over every finite variable interval therefore gives a global lower bound.',
      'row_names':rows,
      'row_types':types,
      'multipliers':best_lam,
      'raw_recomputed_bound':recomputed,
      'numerical_safety_margin':safety,
      'conservative_bound':certified,
      'variables':len(variables),
      'rows':nrow,
      'seed':args.seed
    }
    with open('dual_certificate.json','w') as f: json.dump(cert,f)
    result = {
      'status':'success',
      'algorithm_family':'projected Lagrangian dual optimization over an exact variable-box relaxation',
      'algorithm_role':'dual_bound',
      'hypothesis':'Long-horizon projected Polyak updates can reproduce or strengthen the short-run 39621.99960377 global lower-bound candidate while retaining a fully recomputable multiplier certificate.',
      'work_units':iteration,
      'work_unit_name':'full Lagrangian evaluations and projected subgradient updates',
      'termination_reason':'zero subgradient' if iteration and time.monotonic() < stop_at else 'scaled runtime budget exhausted',
      'target_bound':args.target,
      'best_bound':certified,
      'raw_bound':recomputed,
      'initial_bound':initial,
      'runtime_seconds':elapsed,
      'seed':args.seed,
      'acceptance_criterion':'Retain a multiplier vector only when its full separable Lagrangian value strictly improves the incumbent dual value.',
      'pivot_condition':'After 250 nonimproving evaluations, reduce the Polyak factor, return to the best multiplier vector, and apply a shrinking sign-feasible perturbation.',
      'certificate_artifact':'dual_certificate.json',
      'trace_artifact':'dual_trace.csv',
      'solution_artifact':None
    }
    with open('method_result.json','w') as f: json.dump(result,f)

if __name__ == '__main__':
    main()
