# Package manifest: neos-2629914-sudost

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 97
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/certificate-run.txt`
- `artifacts/exact-solution-audit.json`
- `artifacts/sudost_qap.lp`
- `framework-runs/2026-09-04/background.md`
- `framework-runs/2026-09-04/experiments.json`
- `framework-runs/2026-09-04/experiments.md`
- `framework-runs/2026-09-04/final_report.md`
- `framework-runs/2026-09-04/method_selection.md`
- `framework-runs/2026-09-04/methods/assignment_bound_v2.py`
- `framework-runs/2026-09-04/methods/assignment_master_dp.py`
- `framework-runs/2026-09-04/methods/branch_propagate_v2.py`
- `framework-runs/2026-09-04/methods/domain_safe_lagrangian.py`
- `framework-runs/2026-09-04/methods/domain_structure_audit.py`
- `framework-runs/2026-09-04/methods/lagrangian_all_rows.py`
- `framework-runs/2026-09-04/methods/lagrangian_domain_safe.py`
- `framework-runs/2026-09-04/methods/lagrangian_dual.py`
- `framework-runs/2026-09-04/methods/propagated_lagrangian.py`
- `framework-runs/2026-09-04/reporting_bundle.json`
- `framework-runs/2026-09-04/result.json`
- `framework-runs/2026-09-04/runs/custom-20260904-232141-664bb9fd/algorithm.stderr`
- `framework-runs/2026-09-04/runs/custom-20260904-232141-664bb9fd/algorithm.stdout`
- `framework-runs/2026-09-04/runs/custom-20260904-232141-664bb9fd/bound_certificate.json`
- `framework-runs/2026-09-04/runs/custom-20260904-232141-664bb9fd/driver.stderr`
- `framework-runs/2026-09-04/runs/custom-20260904-232141-664bb9fd/driver.stdout`
- `framework-runs/2026-09-04/runs/custom-20260904-232141-664bb9fd/method_result.json`
- `framework-runs/2026-09-04/runs/custom-20260904-232141-664bb9fd/result.json`
- `framework-runs/2026-09-04/runs/custom-20260904-232141-664bb9fd/structural_profile.json`
- `framework-runs/2026-09-04/runs/custom-20260904-232323-148ad30a/algorithm.stderr`
- `framework-runs/2026-09-04/runs/custom-20260904-232323-148ad30a/algorithm.stdout`
- `framework-runs/2026-09-04/runs/custom-20260904-232323-148ad30a/assignment_bound.json`
- `framework-runs/2026-09-04/runs/custom-20260904-232323-148ad30a/driver.stderr`
- `framework-runs/2026-09-04/runs/custom-20260904-232323-148ad30a/driver.stdout`
- `framework-runs/2026-09-04/runs/custom-20260904-232323-148ad30a/method_result.json`
- `framework-runs/2026-09-04/runs/custom-20260904-232323-148ad30a/result.json`
- `framework-runs/2026-09-04/runs/custom-20260904-232439-aa4d53c6/algorithm.stderr`
- `framework-runs/2026-09-04/runs/custom-20260904-232439-aa4d53c6/algorithm.stdout`
- `framework-runs/2026-09-04/runs/custom-20260904-232439-aa4d53c6/assignment_bound.json`
- `framework-runs/2026-09-04/runs/custom-20260904-232439-aa4d53c6/driver.stderr`
- `framework-runs/2026-09-04/runs/custom-20260904-232439-aa4d53c6/driver.stdout`
- `framework-runs/2026-09-04/runs/custom-20260904-232439-aa4d53c6/method_result.json`
- `framework-runs/2026-09-04/runs/custom-20260904-232439-aa4d53c6/result.json`
- `framework-runs/2026-09-04/runs/custom-20260904-232622-a41f4c5c/algorithm.stderr`
- `framework-runs/2026-09-04/runs/custom-20260904-232622-a41f4c5c/algorithm.stdout`
- `framework-runs/2026-09-04/runs/custom-20260904-232622-a41f4c5c/driver.stderr`
- `framework-runs/2026-09-04/runs/custom-20260904-232622-a41f4c5c/driver.stdout`
- `framework-runs/2026-09-04/runs/custom-20260904-232622-a41f4c5c/lagrangian_certificate.json`
- `framework-runs/2026-09-04/runs/custom-20260904-232622-a41f4c5c/method_result.json`
- `framework-runs/2026-09-04/runs/custom-20260904-232622-a41f4c5c/result.json`
- `framework-runs/2026-09-04/runs/custom-20260904-233001-f15114db/algorithm.stderr`
- `framework-runs/2026-09-04/runs/custom-20260904-233001-f15114db/algorithm.stdout`
- `framework-runs/2026-09-04/runs/custom-20260904-233001-f15114db/driver.stderr`
- `framework-runs/2026-09-04/runs/custom-20260904-233001-f15114db/driver.stdout`
- `framework-runs/2026-09-04/runs/custom-20260904-233001-f15114db/result.json`
- `framework-runs/2026-09-04/runs/custom-20260904-233504-8f8ac766/algorithm.stderr`
- `framework-runs/2026-09-04/runs/custom-20260904-233504-8f8ac766/algorithm.stdout`
- `framework-runs/2026-09-04/runs/custom-20260904-233504-8f8ac766/driver.stderr`
- `framework-runs/2026-09-04/runs/custom-20260904-233504-8f8ac766/driver.stdout`
- `framework-runs/2026-09-04/runs/custom-20260904-233504-8f8ac766/lagrangian_trace.json`
- `framework-runs/2026-09-04/runs/custom-20260904-233504-8f8ac766/method_result.json`
- `framework-runs/2026-09-04/runs/custom-20260904-233504-8f8ac766/result.json`
- `framework-runs/2026-09-04/runs/custom-20260904-233734-a82777f0/algorithm.stderr`
- `framework-runs/2026-09-04/runs/custom-20260904-233734-a82777f0/algorithm.stdout`
- `framework-runs/2026-09-04/runs/custom-20260904-233734-a82777f0/driver.stderr`
- `framework-runs/2026-09-04/runs/custom-20260904-233734-a82777f0/driver.stdout`
- `framework-runs/2026-09-04/runs/custom-20260904-233734-a82777f0/result.json`
- `framework-runs/2026-09-04/runs/custom-20260904-233904-f695e493/algorithm.stderr`
- `framework-runs/2026-09-04/runs/custom-20260904-233904-f695e493/algorithm.stdout`
- `framework-runs/2026-09-04/runs/custom-20260904-233904-f695e493/driver.stderr`
- `framework-runs/2026-09-04/runs/custom-20260904-233904-f695e493/driver.stdout`
- `framework-runs/2026-09-04/runs/custom-20260904-233904-f695e493/result.json`
- `framework-runs/2026-09-04/runs/custom-20260904-234040-cca275d4/algorithm.stderr`
- `framework-runs/2026-09-04/runs/custom-20260904-234040-cca275d4/algorithm.stdout`
- `framework-runs/2026-09-04/runs/custom-20260904-234040-cca275d4/driver.stderr`
- `framework-runs/2026-09-04/runs/custom-20260904-234040-cca275d4/driver.stdout`
- `framework-runs/2026-09-04/runs/custom-20260904-234040-cca275d4/method_result.json`
- `framework-runs/2026-09-04/runs/custom-20260904-234040-cca275d4/propagation_certificate.json`
- `framework-runs/2026-09-04/runs/custom-20260904-234040-cca275d4/result.json`
- `framework-runs/2026-09-04/solutions/public/neos-2629914-sudost-v1.sol.gz`
- `framework-runs/2026-09-04/solutions/public/neos-2629914-sudost-v2.sol.gz`
- `framework-runs/2026-09-04/solutions/public/neos-2629914-sudost.sol`
- `framework-runs/2026-09-04/solutions/public/neos-2629914-sudost.sol.gz`
- `framework-runs/2026-09-04/strategy.md`
- `framework-runs/2026-09-04/structure-gurobi.log`
- `framework-runs/2026-09-04/structure.json`
- `framework-runs/2026-09-04/verification/public-solution.exact-check.txt`
- `logs/sudost_48180_verify.log`
- `logs/sudost_probe.log`
- `logs/sudost_qap_3min.log`
- `logs/sudost_qap_smoke.log`
- `reports/sudost-optimality-proof.md`
- `scripts/sudost_optimality_certificate.py`
- `scripts/sudost_qap_search.py`
- `solutions/sudost_48180.sol`
- `solutions/sudost_probe.sol`
- `solutions/sudost_qap_3min.sol`
- `solutions/sudost_qap_48180.mst`

## Excluded files

- `input/neos-2629914-sudost.mps.gz (838470 bytes; raw benchmark input; sha256 d13e000b9cbff6ebc6c6426cdfaea2e44501714a5be294c669e9e8e9d57d60e5)`
