# `supportcase30` 实验报告

实验日期：2026-09-01（Asia/Shanghai）

## 结论

本轮**没有找到原问题的可行解，也没有证明整个实例不可行**。

目前最好的精确验算结果覆盖 1,024 条覆盖约束中的 987 条，只剩 37 条为空。该解恰好选择 114 个二元变量，四组选择数为 `(30,30,24,30)`，与原模型的四条基数等式完全一致；但 37 条覆盖违反意味着它只是 near-feasible partial solution，不能作为 MIPLIB 可行解提交。

MIPLIB 官方页面仍将 `supportcase30` 标为 `open / no_solution`。它是纯可行性模型，因此实验的两个真正终点只能是：找到覆盖全部 1,024 行的选择，或者给出全局不可行证明。现有结果均未达到其中任何一个终点。

## 模型结构

原模型有 1,024 个二元变量、1,024 条覆盖约束、4 条基数等式和 12,288 个非零元。四组变量各有 256 个，必须分别选择 30、30、24、30 个，总计 114 个。

逐项解析 MPS 得到：

```text
cover row degree = 11（全部 1,024 行）
cover column degree = 11（全部 1,024 列）
group sizes = [256, 256, 256, 256]
quotas = [30, 30, 24, 30]
row group profiles:
  (0,1,9,1), (1,0,1,9), (1,9,1,0), (9,1,0,1)
  每类各出现 256 次
```

任意两覆盖行的公共变量数、以及任意两变量覆盖的公共行数，都具有同一个分布：495,616 对交集为 0，28,160 对交集为 2。这与十维超立方体 Q10 中半径 1 邻域的交集计数一致。仓库脚本验证的是这个**交集 signature**，并未单独给出完整的图同构证书，因此报告不把它夸大为已证明的同构。

## 最大覆盖等价松弛

为每条覆盖行引入二元变量 `y_r`，保留原来的四组选择配额，并加入：

```text
y_r <= sum(x_j : j covers row r)
maximize sum_r y_r
```

该模型始终可以构造整数解；目标 1,024 当且仅当原 MPS 可行。因此它既能产生满足全部基数等式的近可行解，又能把进展准确表示为“还剩多少覆盖行为空”。但只找到 987 是最大化问题的一个 incumbent，不是证明原问题不可行的上界。

## 求解器与启发式结果

| 方法 / 主机 | 线程 | 时限 | incumbent | 全局或邻域界 | 备注 |
|---|---:|---:|---:|---:|---|
| Gurobi 13.0.1 原模型 / `euler4` | 32 | 900 s | 无可行解 | — | 29,032 nodes |
| COPT 8.0.4 原模型 / `altman` | 32 | 900 s | 无可行解 | — | 19,027 nodes |
| Gurobi max-cover / `euler4` | 32 | 900 s | 984 | 1,024 | 40 行未覆盖 |
| Gurobi NoRel max-cover / `euler4` | 32 | 900 s | 985 | 1,024 | 39 行未覆盖 |
| COPT max-cover default / `altman` | 32 | 900 s | 969 | 1,024 | 55 行未覆盖 |
| COPT max-cover aggressive heuristics / `altman` | 32 | 900 s | 979 | 1,024 | 45 行未覆盖 |
| local branch radius 20 around 984 / `euler4` | 24 | 600 s | 985 | 992 | 仅对该 Hamming 球有效 |
| local branch radius 40 around 984 / `euler4` | 24 | 600 s | 986 | 1,002 | 仅对该 Hamming 球有效 |
| local branch radius 30 around 986 / `euler4` | 32 | 600 s | **987** | 991 | 仅对该 Hamming 球有效；609,593 nodes |
| quota-preserving tabu from 985 | 1 | 180 s | 985 | — | 未进一步改善 |
| quota-preserving tabu from 986 | 1 | 180 s | 986 | — | 未进一步改善 |

COPT aggressive 配置使用 `HeurLevel=3`、`PreRoot=3`、`Rounding=3`、`Diving=3`、`SubMip=3`、`FAP=4`。Gurobi NoRel 配置使用 `Heuristics=1` 和 `NoRelHeurTime=300`。`altman` 上的所有实验都是 CPU-only，**没有使用 GPU0**。

## 最好 partial solution 的独立验算

对 `supportcase30_best_partial.sol` 只读取 `x` 变量，再从原始 MPS 重算全部覆盖与配额：

```text
selected = 114
group_counts = [30, 30, 24, 30]
uncovered = 37
minimum_cover = 0
maximum_cover = 4
overlap_pairs = 302
```

这里 `minimum_cover=0` 正是它不能作为原问题可行解的原因。验算器不依赖 Gurobi 或 COPT，只用 Python 标准库解析 MPS 和 solution。

## 结论边界

- direct solver 的“时限内无可行解”不能解释为 infeasible。
- max-cover 的目标 987 是一个可行下界；未加局部分支的求解器全局上界仍为 1,024，没有排除完整覆盖。
- 半径 20/40/30 的运行也在时限终止；其界只属于对应 Hamming 球，不能推广到整个模型。
- 当前最可靠的成果是结构恢复、可复现搜索流程和一个严格验算的 987/1,024 partial solution。

## 可复现文件

- `input/supportcase30.mps.gz`：原始压缩 MPS。
- `scripts/analyze_structure.py`：精确统计度数、组 profile 与交集 signature。
- `scripts/supportcase30_search.py`：生成 max-cover 模型、读取 solver solution、保持配额的 tabu 搜索及独立验算。
- `scripts/make_local_branch_lp.py`：在 max-cover LP 上加入相对指定 incumbent 的 Hamming 球。
- `artifacts/supportcase30_best_partial.sol`：只含原模型变量的当前最好 987/1,024 partial solution。
- `artifacts/gurobi_lb30_from986_10m.sol`：产生当前最好解的完整 max-cover solver solution。
- `artifacts/supportcase30_maxcover.lp`：最大覆盖模型。
- `logs/`：Gurobi 与 COPT 原始日志。

## 资料

- [MIPLIB：supportcase30 instance details](https://miplib.zib.de/instance_details_supportcase30.html)
- [MIPLIB：open tag](https://miplib.zib.de/tag_open.html)
