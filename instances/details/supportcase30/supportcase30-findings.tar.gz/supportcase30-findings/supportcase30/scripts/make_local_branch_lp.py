#!/usr/bin/env python3
"""Add a local-branching Hamming ball around a supportcase30 solution."""

from __future__ import annotations

import argparse
from decimal import Decimal
from pathlib import Path


def read_selected(path: Path) -> set[str]:
    selected: set[str] = set()
    with path.open(encoding="utf-8") as handle:
        for raw in handle:
            tokens = raw.split()
            if len(tokens) < 2 or tokens[0].startswith("#"):
                continue
            name = tokens[0]
            if name.startswith("x") and name[1:].isdigit() and Decimal(tokens[1]) > Decimal("0.5"):
                selected.add(name)
    if len(selected) != 114:
        raise ValueError(f"expected 114 selected x variables, found {len(selected)}")
    return selected


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("base_lp", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("radius", type=int)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    if args.radius < 2 or args.radius % 2:
        raise ValueError("quota-preserving Hamming radii should be positive even numbers")

    selected = read_selected(args.solution)
    source = args.base_lp.read_text(encoding="utf-8")
    marker = "Bounds\n"
    if marker not in source:
        raise ValueError("could not find the Bounds section in the base LP")

    variables = [f"x{index}" for index in range(1, 1025)]
    terms = [f"- {name}" if name in selected else f"+ {name}" for name in variables]
    lines = [" local_branch:"]
    for start in range(0, len(terms), 16):
        lines.append("  " + " ".join(terms[start : start + 16]))
    lines[-1] += f" <= {args.radius - len(selected)}"
    constraint = "\n".join(lines) + "\n"
    args.output.write_text(source.replace(marker, constraint + marker, 1), encoding="utf-8")
    print(
        f"wrote {args.output} with radius={args.radius} "
        f"selected={len(selected)} rhs={args.radius - len(selected)}"
    )


if __name__ == "__main__":
    main()
