#!/usr/bin/env python3
"""Report the exact regularity and hypercube signature of supportcase30."""

from __future__ import annotations

import argparse
from collections import Counter
from pathlib import Path

from supportcase30_search import extract_cover_problem, parse_mps


def pair_intersections(sets: list[set[int]]) -> Counter[int]:
    counts: Counter[int] = Counter()
    for left in range(len(sets)):
        for right in range(left + 1, len(sets)):
            counts[len(sets[left] & sets[right])] += 1
    return counts


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    args = parser.parse_args()

    problem = extract_cover_problem(parse_mps(args.mps))
    row_sets = [set(members) for members in problem.row_vars]
    column_sets = [set(rows) for rows in problem.var_rows]
    row_intersections = pair_intersections(row_sets)
    column_intersections = pair_intersections(column_sets)
    group_profiles = Counter(
        tuple(sum(problem.group_of[var] == group for var in members) for group in range(4))
        for members in problem.row_vars
    )

    print(f"variables={len(problem.variables)}")
    print(f"cover_rows={len(problem.cover_rows)}")
    print(f"row_degrees={Counter(map(len, problem.row_vars))}")
    print(f"column_degrees={Counter(map(len, problem.var_rows))}")
    print(f"group_sizes={[len(group) for group in problem.group_vars]}")
    print(f"quotas={problem.quotas} total_selected={sum(problem.quotas)}")
    print(f"row_group_profiles={group_profiles}")
    print(f"row_pair_intersections={row_intersections}")
    print(f"column_pair_intersections={column_intersections}")

    expected = Counter({0: 495_616, 2: 28_160})
    if row_intersections != expected or column_intersections != expected:
        raise SystemExit("The incidence matrix does not have the expected Q_10 radius-one signature")
    print("q10_radius_one_intersection_signature=verified")


if __name__ == "__main__":
    main()
