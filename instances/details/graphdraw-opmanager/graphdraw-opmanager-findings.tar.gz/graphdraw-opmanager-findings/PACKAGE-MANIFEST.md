# Package manifest: graphdraw-opmanager

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 12
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/local-k1.json`
- `artifacts/local-k2.json`
- `artifacts/local-k3-remote.json`
- `artifacts/local-k4-remote.json`
- `artifacts/solver-environments.json`
- `artifacts/structure-audit.json`
- `input/SHA256SUMS`
- `requirements.txt`
- `scripts/analyze_structure.py`
- `scripts/solve_compact_cpsat.py`
- `solutions/graphdraw-opmanager-public-6.sol.gz`

## Excluded files

- `input/graphdraw-opmanager.mps.gz (1537776 bytes; raw benchmark input; sha256 55aa55b4da411f483714de187f2c9a7700a8da53ec8b00809f3b98a692185fc3)`
