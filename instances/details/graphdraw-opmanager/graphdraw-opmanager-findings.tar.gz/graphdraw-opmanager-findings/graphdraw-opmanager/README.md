# graphdraw-opmanager — exact global lower bound and local certificates

Official MIPLIB page: <https://miplib.zib.de/instance_details_graphdraw-opmanager.html>

## Current result

The new exact global lower bound is **58,950**, improving the historical
58,625.5 bound by **324.5**. Together with the verified public layout:

```text
58,950 <= OPT <= 99,445.5.
```

See the [2026-09-14 geometric proof and portable rational certificates](../../docs/dual-bound-audit-2026-09-14/README.md). The global optimum remains open.

The public layout has verified objective **99,445.5**. An exact compact model
and completed CP-SAT searches show that no strict improvement can be obtained
by moving at most four rectangles while all other rectangles remain at their
public coordinates.

This is a complete **local-neighborhood** conclusion, not a global optimality
proof. The instance remains open.

## Recovered geometry

The 75,395-row extended MPS represents a much smaller layout problem:

- 48 rectangles on an 82 by 82 grid;
- 1,128 unordered rectangle pairs and four order variables per pair;
- 54 relationship edges;
- one relationship component of size 45 and three isolated rectangles;
- total rectangle area 3,372, or 50.1487% of the grid.

The compact formulation replaces the pair-order variables and 69,184 triangle
inequalities by one exact `NoOverlap2D` constraint and 96 integer coordinates.
All half-integral quantities are multiplied by two.

The public objective is independently reconstructed as

```text
166 * edge Manhattan distance + center deviation
= 166 * 591 + 1339.5
= 99445.5.
```

Individual edge minima plus the center-deviation minimum give the direct global
lower bound 54,717. A 180-second unrestricted compact search remained
`UNKNOWN` with CP-SAT bound 58,625.5.

## Completed neighborhoods

The strict-improvement cutoff is objective at most 99,445.0.

| Changed rectangles | CP-SAT result | Runtime |
|---:|---|---:|
| at most 1 | `INFEASIBLE` | 0.49 s |
| at most 2 | `INFEASIBLE` | 6.92 s |
| at most 3 | `INFEASIBLE` | 47.36 s |
| exactly 4 | `INFEASIBLE` | 419.26 s |

Combining the final two rows proves solver-certified local optimality for the
entire radius-four rectangle-coordinate neighborhood. The four-rectangle run
used OR-Tools 9.15.6755 with 64 workers and explored 2,558,587 branches.

CP-SAT did not export a DRAT/LRAT proof trace. Consequently these statuses are
archived as reproducible solver certificates and are not described as
independently checked mathematical proofs.

## Reproduction

Install the pinned dependency in [`requirements.txt`](requirements.txt), then
run from the repository root:

```sh
python instances/graphdraw-opmanager/scripts/analyze_structure.py \
  instances/graphdraw-opmanager/input/graphdraw-opmanager.mps.gz \
  instances/graphdraw-opmanager/solutions/graphdraw-opmanager-public-6.sol.gz \
  --json structure-audit.json

python instances/graphdraw-opmanager/scripts/solve_compact_cpsat.py \
  instances/graphdraw-opmanager/input/graphdraw-opmanager.mps.gz \
  --hint instances/graphdraw-opmanager/solutions/graphdraw-opmanager-public-6.sol.gz \
  --objective-upper-bound 99445 --min-moved-entities 4 \
  --max-moved-entities 4 --time-limit 900 --workers 64 \
  --summary local-k4.json
```

Input hashes are recorded in [`input/SHA256SUMS`](input/SHA256SUMS).
