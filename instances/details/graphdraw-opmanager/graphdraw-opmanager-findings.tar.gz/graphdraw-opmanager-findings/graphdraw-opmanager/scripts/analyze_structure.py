#!/usr/bin/env python3
"""Recover graph/rectangle structure and audit the official layout."""

from __future__ import annotations

import argparse
import collections
import json
import math
import re
from pathlib import Path

from solve_compact_cpsat import parse_mps, read_solution


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()

    row_type, rhs, rows, objective, lower, upper, variables = parse_mps(args.mps)
    values = read_solution(args.solution)
    row_families = collections.Counter(row.split("[")[0] for row in rows)
    variable_families = collections.Counter(variable.split("[")[0] for variable in variables)

    entities = sorted(
        match.group(1)
        for variable in variables
        if (match := re.fullmatch(r"x\[r,([^]]+)\]", variable))
    )
    pairs = sorted(
        match.groups()
        for row in rows
        if (match := re.fullmatch(r"choose1\[([^,]+),([^]]+)\]", row))
    )
    edges = sorted(
        (match.group(1), match.group(2), rhs[row])
        for row in rows
        if (match := re.fullmatch(r"DistSumLB\[([^,]+),([^]]+)\]", row))
    )

    sizes = {}
    for axis in "rc":
        for first, second in pairs:
            for prefix, direction, entity in (("axisVdifLB", "lb", first), ("axisVdifRT", "rt", second)):
                row = f"{prefix}[{axis},{first},{second}]"
                z = f"zV[{axis},{direction},{first},{second}]"
                size = round(rhs[row] - rows[row][z])
                old = sizes.setdefault((axis, entity), size)
                if old != size:
                    raise RuntimeError(f"inconsistent rectangle size for {(axis, entity)}")

    grid_ends = {
        round(upper[f"x[{axis},{entity}]"] + sizes[axis, entity])
        for axis in "rc"
        for entity in entities
    }
    adjacency = {entity: set() for entity in entities}
    for first, second, _ in edges:
        adjacency[first].add(second)
        adjacency[second].add(first)
    seen = set()
    component_sizes = []
    for root in entities:
        if root in seen:
            continue
        stack, component = [root], []
        seen.add(root)
        while stack:
            node = stack.pop()
            component.append(node)
            for neighbor in adjacency[node]:
                if neighbor not in seen:
                    seen.add(neighbor)
                    stack.append(neighbor)
        component_sizes.append(len(component))

    edge_details = []
    for first, second, minimum in edges:
        actual = sum(values.get(f"dist[{axis},{first},{second}]", 0.0) for axis in "rc")
        edge_details.append((actual - minimum, first, second, actual, minimum))
    edge_details.sort(reverse=True)

    edge_distance_sum = sum(item[3] for item in edge_details)
    edge_minimum_sum = sum(item[4] for item in edge_details)
    center_sum = sum(value for name, value in values.items() if name.startswith("center_dist["))
    computed_objective = sum(coefficient * values.get(variable, 0.0) for variable, coefficient in objective.items())
    selected_z = sum(value > 0.5 for name, value in values.items() if name.startswith("zV["))
    rectangle_area = sum(sizes["r", entity] * sizes["c", entity] for entity in entities)
    distance_weights = {
        coefficient
        for variable, coefficient in objective.items()
        if variable.startswith("dist[")
    }
    center_weights = {
        coefficient
        for variable, coefficient in objective.items()
        if variable.startswith("center_dist[")
    }
    if len(distance_weights) != 1 or center_weights != {1.0}:
        raise RuntimeError("unexpected objective weights")
    distance_weight = distance_weights.pop()
    grid_side = round(next(iter(grid_ends)) - min(lower[f"x[{axis},{entity}]"] for axis in "rc" for entity in entities))
    direct_lower_bound = distance_weight * edge_minimum_sum + rhs["CenterDistSumLB"]

    result = {
        "instance": "graphdraw-opmanager",
        "variables": len(variables),
        "constraints": len(rows),
        "nonzeros": sum(len(row) for row in rows.values()),
        "variable_families": dict(sorted(variable_families.items())),
        "row_families": dict(sorted(row_families.items())),
        "entities": len(entities),
        "rectangle_pairs": len(pairs),
        "grid_coordinate_end": sorted(grid_ends),
        "rectangle_row_size_range": [min(sizes["r", e] for e in entities), max(sizes["r", e] for e in entities)],
        "rectangle_column_size_range": [min(sizes["c", e] for e in entities), max(sizes["c", e] for e in entities)],
        "total_rectangle_area": rectangle_area,
        "grid_area": grid_side * grid_side,
        "area_density": rectangle_area / (grid_side * grid_side),
        "relationship_edges": len(edges),
        "relationship_graph_component_sizes": sorted(component_sizes, reverse=True),
        "relationship_graph_cycle_rank": len(edges) - len(entities) + len(component_sizes),
        "relationship_degree_histogram": dict(sorted(collections.Counter(len(adjacency[e]) for e in entities).items())),
        "isolated_entities": [entity for entity in entities if not adjacency[entity]],
        "official_selected_pair_orders": selected_z,
        "official_edge_distance_sum": edge_distance_sum,
        "sum_of_individual_edge_minima": edge_minimum_sum,
        "official_edge_distance_excess": edge_distance_sum - edge_minimum_sum,
        "edges_at_individual_minimum": sum(abs(item[0]) < 1e-8 for item in edge_details),
        "largest_edge_excesses": [
            {"edge": [first, second], "excess": excess, "actual": actual, "minimum": minimum}
            for excess, first, second, actual, minimum in edge_details[:10]
        ],
        "official_center_deviation_sum": center_sum,
        "center_deviation_sum_lower_bound": rhs["CenterDistSumLB"],
        "edge_distance_objective_weight": distance_weight,
        "official_objective_recomputed": computed_objective,
        "direct_independent_lower_bound": direct_lower_bound,
        "objective_lattice_step": 0.5,
        "next_strict_improvement_target": math.floor(2 * computed_objective - 0.5) / 2,
        "checks": {
            "pair_count_matches_entity_count": len(pairs) == math.comb(len(entities), 2),
            "four_orders_per_pair": variable_families["zV"] == 4 * len(pairs),
            "two_integer_coordinates_per_entity": variable_families["x"] == 2 * len(entities),
            "triangle_rows_match_four_choose_n_3": row_families["triangle1"] + row_families["triangle2"] == 4 * math.comb(len(entities), 3),
            "single_common_grid_end": len(grid_ends) == 1,
            "one_selected_order_per_pair": selected_z == len(pairs),
            "objective_decomposition_matches": abs(computed_objective - (distance_weight * edge_distance_sum + center_sum)) < 1e-7,
        },
    }
    rendered = json.dumps(result, indent=2, ensure_ascii=False)
    print(rendered)
    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(rendered + "\n", encoding="utf-8")
    if not all(result["checks"].values()):
        raise SystemExit("one or more structural checks failed")


if __name__ == "__main__":
    main()
