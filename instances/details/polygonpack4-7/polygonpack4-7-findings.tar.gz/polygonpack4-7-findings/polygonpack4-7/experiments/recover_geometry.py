#!/usr/bin/env python3
"""Recover polygonpack4-7's geometric row/column roles from the raw MPS.

All arithmetic used for the optional solution audit is Decimal arithmetic over
the literal coefficients in the MPS.  This script does not assert that the MPS
itself is an exact representation of the submitter's pre-rounding geometry.
"""

from __future__ import annotations

import argparse
import collections
import gzip
import hashlib
import json
import re
from decimal import Decimal, getcontext
from pathlib import Path


getcontext().prec = 80
ZERO = Decimal(0)

NONOVERLAP_RE = re.compile(
    r"^i(?P<i>\d+),r1(?P<ri>[0-3]),j(?P<j>\d+),r2(?P<rj>[0-3]),"
    r"s(?P<s>\d+),k(?P<k>\d+)vincoli_di_non_sovrapposizione$"
)
CHOICE_RE = re.compile(
    r"^i(?P<i>\d+),r1(?P<ri>[0-3]),j(?P<j>\d+),r2(?P<rj>[0-3])"
    r"vincoli_di_scelta_della_slice$"
)
CONTAINMENT_RE = re.compile(r"^(?P<axis>[xy])(?P<i>\d+)_contenimento(?P<low>_low)?$")
ROTATION_RE = re.compile(r"^n(?P<i>\d+)_only_one_rotation(?P<low>_low)?$")


def dec(text: str) -> Decimal:
    return Decimal(text.replace("D", "E").replace("d", "e"))


def open_text(path: Path):
    return gzip.open(path, "rt", encoding="latin-1") if path.suffix == ".gz" else path.open(encoding="latin-1")


def read_mps(path: Path) -> dict:
    row_types: dict[str, str] = {}
    rhs: dict[str, Decimal] = collections.defaultdict(Decimal)
    ranges: dict[str, Decimal] = collections.defaultdict(Decimal)
    rows: dict[str, list[tuple[str, Decimal]]] = collections.defaultdict(list)
    objective: dict[str, Decimal] = collections.defaultdict(Decimal)
    variables: list[str] = []
    seen: set[str] = set()
    integer_variables: set[str] = set()
    bound_records: list[list[str]] = []
    integer_mode = False
    section = ""
    with open_text(path) as handle:
        for raw in handle:
            tokens = raw.split()
            if not tokens or tokens[0].startswith("*"):
                continue
            if not raw[0].isspace() and tokens[0] in {
                "NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"
            }:
                section = tokens[0]
                continue
            if section == "ROWS":
                row_types[tokens[1]] = tokens[0]
            elif section == "COLUMNS":
                if "'MARKER'" in tokens:
                    integer_mode = "'INTORG'" in tokens
                    continue
                variable = tokens[0]
                if variable not in seen:
                    seen.add(variable)
                    variables.append(variable)
                if integer_mode:
                    integer_variables.add(variable)
                for row, coefficient in zip(tokens[1::2], tokens[2::2]):
                    value = dec(coefficient)
                    if row_types[row] == "N":
                        objective[variable] += value
                    else:
                        rows[row].append((variable, value))
            elif section == "RHS":
                for row, value in zip(tokens[1::2], tokens[2::2]):
                    rhs[row] += dec(value)
            elif section == "RANGES":
                for row, value in zip(tokens[1::2], tokens[2::2]):
                    ranges[row] += dec(value)
            elif section == "BOUNDS":
                bound_records.append(tokens)

    lower = {variable: ZERO for variable in variables}
    upper: dict[str, Decimal | None] = {variable: None for variable in variables}
    for tokens in bound_records:
        kind, variable = tokens[0], tokens[2]
        value = dec(tokens[3]) if len(tokens) > 3 else ZERO
        if kind == "LO":
            lower[variable] = value
        elif kind == "UP":
            upper[variable] = value
        elif kind == "FX":
            lower[variable] = upper[variable] = value
        elif kind == "FR":
            lower[variable], upper[variable] = Decimal("-Infinity"), None
        elif kind == "MI":
            lower[variable] = Decimal("-Infinity")
        elif kind == "PL":
            upper[variable] = None
        elif kind == "BV":
            lower[variable], upper[variable] = ZERO, Decimal(1)
            integer_variables.add(variable)
        elif kind == "LI":
            lower[variable] = value
            integer_variables.add(variable)
        elif kind == "UI":
            upper[variable] = value
            integer_variables.add(variable)
        else:
            raise ValueError(f"unsupported bound type {kind}")
    return {
        "row_types": row_types,
        "rhs": rhs,
        "ranges": ranges,
        "rows": rows,
        "objective": objective,
        "variables": variables,
        "integer_variables": integer_variables,
        "lower": lower,
        "upper": upper,
    }


def read_solution(path: Path) -> dict[str, Decimal]:
    values: dict[str, Decimal] = {}
    with open_text(path) as handle:
        for raw in handle:
            tokens = raw.split()
            if len(tokens) >= 2 and not tokens[0].startswith(("#", "=")):
                try:
                    values[tokens[0]] = dec(tokens[1])
                except Exception:
                    pass
    return values


def exact_slack(kind: str, lhs: Decimal, rhs: Decimal) -> tuple[Decimal, Decimal]:
    """Return (nonnegative slack when feasible, violation)."""
    if kind == "L":
        return rhs - lhs, max(ZERO, lhs - rhs)
    if kind == "G":
        return lhs - rhs, max(ZERO, rhs - lhs)
    if kind == "E":
        return -abs(lhs - rhs), abs(lhs - rhs)
    raise ValueError(kind)


def solution_audit(
    model: dict,
    values: dict[str, Decimal],
    active_limit: Decimal,
    orientation_groups: dict[int, list[str]],
    slice_var_by_key: dict[tuple[int, int, int, int, int], str],
) -> dict:
    objective = sum(model["objective"].get(v, ZERO) * values.get(v, ZERO) for v in model["variables"])
    violations = []
    near_active = []
    for row, kind in model["row_types"].items():
        if kind == "N":
            continue
        lhs = sum(coefficient * values.get(variable, ZERO) for variable, coefficient in model["rows"][row])
        row_rhs = model["rhs"].get(row, ZERO)
        slack, violation = exact_slack(kind, lhs, row_rhs)
        record = {
            "row": row,
            "sense": kind,
            "lhs": str(lhs),
            "rhs": str(row_rhs),
            "slack": str(slack),
            "violation": str(violation),
        }
        if violation:
            violations.append(record)
        if abs(slack) <= active_limit:
            record["continuous_terms"] = [
                [variable, str(coefficient), str(values.get(variable, ZERO))]
                for variable, coefficient in model["rows"][row]
                if variable not in model["integer_variables"]
            ]
            near_active.append(record)
    bound_violations = []
    integrality_violations = []
    for variable in model["variables"]:
        value = values.get(variable, ZERO)
        lower = model["lower"][variable]
        upper = model["upper"][variable]
        violation = max(ZERO, lower - value)
        if upper is not None:
            violation = max(violation, value - upper)
        if violation:
            bound_violations.append([variable, str(violation)])
        if variable in model["integer_variables"]:
            violation = abs(value - value.to_integral_value())
            if violation:
                integrality_violations.append([variable, str(violation)])
    violations.sort(key=lambda x: Decimal(x["violation"]), reverse=True)
    near_active.sort(key=lambda x: abs(Decimal(x["slack"])))
    selected_rotation = {}
    for object_index, group in orientation_groups.items():
        chosen = [rotation for rotation, variable in enumerate(group) if values.get(variable, ZERO) == 1]
        if len(chosen) == 1:
            selected_rotation[object_index] = chosen[0]

    pair_slice_certificate = []
    for i in sorted(selected_rotation):
        for j in sorted(x for x in selected_rotation if x < i):
            ri, rj = selected_rotation[i], selected_rotation[j]
            candidates = sorted(
                (key, variable)
                for key, variable in slice_var_by_key.items()
                if key[:4] == (i, ri, j, rj)
            )
            active = [(key, variable) for key, variable in candidates if values.get(variable, ZERO) == 1]
            active_records = []
            for key, variable in active:
                prefix = f"i{i},r1{ri},j{j},r2{rj},s{key[4]},"
                relevant = [
                    row for row in model["rows"]
                    if row.startswith(prefix) and row.endswith("vincoli_di_non_sovrapposizione")
                ]
                slacks = []
                for row in relevant:
                    lhs = sum(c * values.get(v, ZERO) for v, c in model["rows"][row])
                    slack, violation = exact_slack(model["row_types"][row], lhs, model["rhs"].get(row, ZERO))
                    slacks.append((slack, violation, row))
                slacks.sort(key=lambda item: item[0])
                active_records.append({
                    "slice": key[4],
                    "variable": variable,
                    "halfspace_rows": len(relevant),
                    "minimum_exact_slack": str(slacks[0][0]) if slacks else None,
                    "violation_count": sum(item[1] > 0 for item in slacks),
                    "tightest_row": slacks[0][2] if slacks else None,
                })
            pair_slice_certificate.append({
                "objects": [i, j],
                "rotations": [ri, rj],
                "available_slices": len(candidates),
                "active_slice_count": len(active),
                "active_slices": active_records,
            })

    return {
        "objective": str(objective),
        "exact_row_violation_count": len(violations),
        "max_row_violation": violations[0]["violation"] if violations else "0",
        "violations": violations[:50],
        "near_active_threshold": str(active_limit),
        "near_active_count": len(near_active),
        "near_active_rows": near_active[:200],
        "bound_violations": bound_violations,
        "integrality_violations": integrality_violations,
        "selected_pair_slice_certificate": pair_slice_certificate,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--solution", type=Path)
    parser.add_argument("--active-limit", type=Decimal, default=Decimal("1e-7"))
    args = parser.parse_args()

    model = read_mps(args.mps)
    coordinate_map: dict[str, dict] = {}
    orientation_groups: dict[int, list[str]] = {}
    slice_var_by_key: dict[tuple[int, int, int, int, int], str] = {}
    row_family_counts = collections.Counter()
    pair_orientation_rows = collections.Counter()
    pair_orientation_slice_counts = collections.Counter()
    representative_rows: dict[str, dict] = {}
    for row, kind in model["row_types"].items():
        if kind == "N":
            continue
        containment = CONTAINMENT_RE.match(row)
        rotation = ROTATION_RE.match(row)
        nonoverlap = NONOVERLAP_RE.match(row)
        choice = CHOICE_RE.match(row)
        if containment:
            family = "containment"
            if not containment.group("low"):
                continuous_terms = [
                    variable for variable, _ in model["rows"][row]
                    if variable not in model["integer_variables"]
                ]
                if len(continuous_terms) == 1:
                    coordinate_map[continuous_terms[0]] = {
                        "object": int(containment.group("i")),
                        "axis": containment.group("axis"),
                    }
        elif rotation:
            family = "orientation_cardinality"
            if not rotation.group("low"):
                orientation_groups[int(rotation.group("i"))] = [
                    variable for variable, coefficient in model["rows"][row]
                    if variable in model["integer_variables"] and coefficient != 0
                ]
        elif nonoverlap:
            family = "nonoverlap_halfspace"
            key = tuple(int(nonoverlap.group(x)) for x in ("i", "ri", "j", "rj"))
            pair_orientation_rows[key] += 1
            pair_orientation_slice_counts[key + (int(nonoverlap.group("s")),)] += 1
            slice_variables = [
                variable for variable, _ in model["rows"][row]
                if variable in model["integer_variables"]
            ]
            if len(slice_variables) == 1:
                slice_var_by_key[key + (int(nonoverlap.group("s")),)] = slice_variables[0]
        elif choice:
            family = "slice_choice"
        else:
            family = "other"
        row_family_counts[family] += 1
        if family not in representative_rows:
            representative_rows[family] = {
                "row": row,
                "sense": kind,
                "rhs": str(model["rhs"].get(row, ZERO)),
                "terms": [[v, str(c)] for v, c in model["rows"][row]],
            }

    orientation_records = []
    for object_index, variables in sorted(orientation_groups.items()):
        orientation_records.append(
            {
                "object": object_index,
                "variables_by_rotation_0_1_2_3": variables,
                "objective_coefficients": [str(model["objective"].get(v, ZERO)) for v in variables],
            }
        )

    object_geometry = []
    for object_index, orientation_variables_for_object in sorted(orientation_groups.items()):
        coord_by_axis = {
            detail["axis"]: variable
            for variable, detail in coordinate_map.items()
            if detail["object"] == object_index
        }
        rotations = []
        for rotation, orientation_variable in enumerate(orientation_variables_for_object):
            bounds = {}
            for axis, coordinate_variable in coord_by_axis.items():
                upper_row = f"{axis}{object_index}_contenimento"
                lower_row = f"{axis}{object_index}_contenimento_low"
                upper_coeff = next(
                    coefficient for variable, coefficient in model["rows"][upper_row]
                    if variable == orientation_variable
                )
                lower_coeff = next(
                    coefficient for variable, coefficient in model["rows"][lower_row]
                    if variable == orientation_variable
                )
                # Together with the variables' default lower bound 0, the
                # upper containment row is x_i + extent*z_ir <= container.
                # The submitted low row repeats the same positive extent and
                # is redundant for a selected orientation; retain that fact
                # rather than inventing unobserved source-polygon minima.
                bounds[f"{axis}_bbox_extent"] = str(upper_coeff)
                bounds[f"{axis}_low_row_orientation_coefficient"] = str(lower_coeff)
            rotations.append({
                "rotation": rotation,
                "orientation_variable": orientation_variable,
                **bounds,
                "orientation_objective": str(model["objective"].get(orientation_variable, ZERO)),
                "coordinate_objective_at_zero": "0",
                "objective_lower_bound_from_nonnegative_coordinates": str(
                    model["objective"].get(orientation_variable, ZERO)
                ),
            })
        object_geometry.append({
            "object": object_index,
            "coordinate_variables": coord_by_axis,
            "coordinate_objective_coefficients": {
                axis: str(model["objective"].get(variable, ZERO))
                for axis, variable in coord_by_axis.items()
            },
            "rotations": rotations,
        })

    roles = collections.Counter()
    orientation_variables = {v for vs in orientation_groups.values() for v in vs}
    for variable in model["variables"]:
        if variable in coordinate_map:
            roles["coordinate"] += 1
        elif variable in orientation_variables:
            roles["orientation_selection"] += 1
        elif variable in model["integer_variables"]:
            roles["slice_disjunction"] += 1
        else:
            roles["unclassified_continuous"] += 1

    output = {
        "input": str(args.mps),
        "input_sha256": hashlib.sha256(args.mps.read_bytes()).hexdigest(),
        "exact_decimal_from_mps_literals": True,
        "dimensions": {
            "rows_excluding_objective": sum(k != "N" for k in model["row_types"].values()),
            "columns": len(model["variables"]),
            "integer_columns": len(model["integer_variables"]),
            "continuous_columns": len(model["variables"]) - len(model["integer_variables"]),
            "nonzeros_excluding_objective": sum(len(x) for x in model["rows"].values()),
        },
        "row_family_counts": dict(row_family_counts),
        "column_role_counts": dict(roles),
        "coordinate_map": coordinate_map,
        "orientation_groups": orientation_records,
        "object_bounding_geometry": object_geometry,
        "nonoverlap_pair_orientation_combinations": len(pair_orientation_rows),
        "nonoverlap_rows_per_pair_orientation_histogram": dict(
            collections.Counter(pair_orientation_rows.values())
        ),
        "slices_per_pair_orientation_histogram": dict(
            collections.Counter(
                len({key[-1] for key in pair_orientation_slice_counts if key[:4] == base})
                for base in pair_orientation_rows
            )
        ),
        "representative_rows": representative_rows,
        "evidence_boundary": [
            "Row names expose the submitted LP semantics and are not inferred from numerical similarity alone.",
            "MPS coefficients are finite decimals; exact replay certifies the MPS, not unknown pre-rounding polygon coordinates.",
            "A floating solver point is not called strict unless the Decimal replay has zero violations.",
        ],
    }
    if args.solution:
        values = read_solution(args.solution)
        output["solution"] = str(args.solution)
        output["selected_orientations"] = {
            str(record["object"]): [
                rotation
                for rotation, variable in enumerate(record["variables_by_rotation_0_1_2_3"])
                if values.get(variable, ZERO) == 1
            ]
            for record in orientation_records
        }
        output["solution_audit"] = solution_audit(
            model,
            values,
            args.active_limit,
            orientation_groups,
            slice_var_by_key,
        )
    with args.output.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(output, indent=2, sort_keys=True) + "\n")
    print(json.dumps({
        "dimensions": output["dimensions"],
        "row_family_counts": output["row_family_counts"],
        "column_role_counts": output["column_role_counts"],
        "selected_orientations": output.get("selected_orientations"),
        "solution_audit": {
            key: output.get("solution_audit", {}).get(key)
            for key in ("objective", "exact_row_violation_count", "max_row_violation", "near_active_count")
        },
    }, indent=2))


if __name__ == "__main__":
    main()
