#!/usr/bin/env python3
"""Read-only structural and incumbent audit for MIPLIB polygonpack4-7."""

import argparse
import gzip
import json
import math
import re
import tempfile
from collections import defaultdict
from decimal import Decimal, getcontext
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB

getcontext().prec = 50

ORI_ROW = re.compile(r"^n(\d+)_only_one_rotation(?:_low)?$")
CONT_ROW = re.compile(r"^([xy])(\d+)_contenimento(?:_low)?$")
CHOICE_ROW = re.compile(
    r"^i(\d+),r1([0-3]),j(\d+),r2([0-3])"
    r"vincoli_di_scelta_della_slice$"
)
NONOVER_ROW = re.compile(
    r"^i(\d+),r1([0-3]),j(\d+),r2([0-3]),s(\d+),k(\d+)"
    r"vincoli_di_non_sovrapposizione$"
)


def D(x):
    """Exact decimal representation of a loaded IEEE-754 double."""
    return Decimal.from_float(float(x))


def ds(x):
    if isinstance(x, Decimal):
        return format(x, "f")
    return str(x)


def finite(x):
    return abs(float(x)) < GRB.INFINITY / 2


def row_terms(model, constr):
    row = model.getRow(constr)
    return [(row.getVar(k), row.getCoeff(k)) for k in range(row.size())]


def fingerprint(constr, terms):
    """Fingerprint using exact loaded-double bit values via float.hex()."""
    return {
        "sense": constr.Sense,
        "rhs_hex": float(constr.RHS).hex(),
        "degree": len(terms),
        "terms": [
            [v.VarName, float(a).hex(), v.VType]
            for v, a in sorted(terms, key=lambda z: z[0].VarName)
        ],
    }


def normalized_sum_interval(constr, terms, names):
    """Recognize a row a*sum(names) sense rhs and return its bound."""
    chosen = [(v, a) for v, a in terms if v.VarName in names]
    if len(chosen) != len(names) or len(terms) != len(names):
        return None
    a = chosen[0][1]
    if a == 0 or any(x != a for _, x in chosen):
        return None

    rhs = constr.RHS / a
    sense = constr.Sense
    if a < 0:
        sense = {GRB.LESS_EQUAL: GRB.GREATER_EQUAL,
                 GRB.GREATER_EQUAL: GRB.LESS_EQUAL,
                 GRB.EQUAL: GRB.EQUAL}[sense]
    return sense, rhs


def infer_structure(model):
    variables = model.getVars()
    constraints = model.getConstrs()
    by_name = {v.VarName: v for v in variables}
    continuous = [v for v in variables if v.VType == GRB.CONTINUOUS]
    binaries = [
        v for v in variables
        if v.VType == GRB.BINARY
        or (v.VType in (GRB.INTEGER, GRB.SEMIINT)
            and v.LB == 0 and v.UB == 1)
    ]
    binary_names = {v.VarName for v in binaries}

    ori_rows = defaultdict(list)
    containment = defaultdict(list)
    choice_rows = {}
    nonoverlap = defaultdict(list)
    classified = set()

    for c in constraints:
        terms = row_terms(model, c)
        m = ORI_ROW.match(c.ConstrName)
        if m:
            ori_rows[int(m.group(1))].append((c, terms))
            classified.add(c.ConstrName)
            continue
        m = CONT_ROW.match(c.ConstrName)
        if m:
            containment[int(m.group(2))].append((m.group(1), c, terms))
            classified.add(c.ConstrName)
            continue
        m = CHOICE_ROW.match(c.ConstrName)
        if m:
            key = tuple(map(int, m.groups()))
            choice_rows[key] = (c, terms)
            classified.add(c.ConstrName)
            continue
        m = NONOVER_ROW.match(c.ConstrName)
        if m:
            i, ri, j, rj, s, k = map(int, m.groups())
            nonoverlap[(i, ri, j, rj, s)].append((k, c, terms))
            classified.add(c.ConstrName)

    errors = []
    orientations = {}
    orientation_rows_json = {}

    # Infer each group solely from its named rows and exact matrix support.
    for i in range(7):
        rows = ori_rows.get(i, [])
        supports = []
        for c, terms in rows:
            support = {
                v.VarName for v, a in terms
                if a != 0 and v.VarName in binary_names
            }
            if support:
                supports.append(support)

        common = set.intersection(*supports) if supports else set()
        union = set.union(*supports) if supports else set()
        group = common if len(common) == 4 else union
        orientations[i] = sorted(group)

        upper_one = False
        lower_zero = False
        details = []
        for c, terms in rows:
            norm = normalized_sum_interval(c, terms, group)
            if norm:
                sense, rhs = norm
                upper_one |= sense == GRB.LESS_EQUAL and rhs == 1
                lower_zero |= sense == GRB.GREATER_EQUAL and rhs == 0
            details.append({
                "name": c.ConstrName,
                "normalized": None if norm is None else [norm[0], norm[1]],
                "fingerprint": fingerprint(c, terms),
            })

        if len(group) != 4:
            errors.append(
                f"polygon {i}: orientation rows imply {len(group)} variables: "
                f"{sorted(group)}"
            )
        if not upper_one:
            errors.append(f"polygon {i}: no exact sum(orientations) <= 1 row")
        orientation_rows_json[str(i)] = {
            "variables": sorted(group),
            "has_upper_one": upper_one,
            "has_lower_zero": lower_zero,
            "rows": details,
        }

    orientation_set = {
        name for group in orientations.values() for name in group
    }

    # Recover rotation labels from the two +1 orientation terms in choice rows.
    rotation_map = defaultdict(dict)
    slice_groups = {}
    slice_owner = {}
    choice_errors = []

    for key, (c, terms) in sorted(choice_rows.items()):
        i, ri, j, rj = key
        pos = [v.VarName for v, a in terms if a == 1 and v.VarName in orientation_set]
        neg = [v.VarName for v, a in terms if a == -1 and v.VarName not in orientation_set]
        other = [
            (v.VarName, a) for v, a in terms
            if not ((a == 1 and v.VarName in orientation_set)
                    or (a == -1 and v.VarName not in orientation_set))
        ]

        oi = [v for v in pos if v in orientations.get(i, [])]
        oj = [v for v in pos if v in orientations.get(j, [])]
        valid = (
            c.Sense == GRB.LESS_EQUAL and c.RHS == 1
            and len(pos) == 2 and len(oi) == 1 and len(oj) == 1
            and not other and bool(neg)
        )
        if not valid:
            choice_errors.append(c.ConstrName)
            continue

        for p, r, name in ((i, ri, oi[0]), (j, rj, oj[0])):
            old = rotation_map[p].get(r)
            if old is not None and old != name:
                errors.append(f"rotation-map conflict polygon {p}, rotation {r}")
            rotation_map[p][r] = name

        slice_groups[key] = neg
        for z in neg:
            old = slice_owner.get(z)
            if old is not None and old != key:
                errors.append(f"slice {z} belongs to multiple choice groups")
            slice_owner[z] = key

    if choice_errors:
        errors.append(
            f"{len(choice_errors)} choice rows fail the expected "
            "+orientation +orientation -slices <= 1 fingerprint"
        )

    for i in range(7):
        if set(rotation_map[i]) != {0, 1, 2, 3}:
            errors.append(
                f"polygon {i}: recovered rotation labels "
                f"{sorted(rotation_map[i])}, expected [0,1,2,3]"
            )
        elif set(rotation_map[i].values()) != set(orientations[i]):
            errors.append(
                f"polygon {i}: choice rows and orientation rows disagree"
            )

    slice_set = set(slice_owner)

    # Coordinates are all continuous columns, then verified by row incidence.
    coordinate_names = {v.VarName for v in continuous}
    coordinate_pairs = defaultdict(dict)
    containment_json = []

    for i, rows in containment.items():
        for axis, c, terms in rows:
            coords = [v.VarName for v, a in terms if a and v.VarName in coordinate_names]
            if len(coords) != 1:
                errors.append(
                    f"{c.ConstrName}: expected one continuous coordinate, got {coords}"
                )
            else:
                old = coordinate_pairs[i].get(axis)
                if old is not None and old != coords[0]:
                    errors.append(
                        f"polygon {i}: inconsistent {axis} coordinate columns"
                    )
                coordinate_pairs[i][axis] = coords[0]
            containment_json.append({
                "polygon": i,
                "axis": axis,
                "name": c.ConstrName,
                "fingerprint": fingerprint(c, terms),
            })

    if len(continuous) != 14:
        errors.append(f"expected 14 continuous coordinates, found {len(continuous)}")
    for i in range(7):
        if set(coordinate_pairs[i]) != {"x", "y"}:
            errors.append(f"polygon {i}: incomplete x/y containment identification")
    paired = {
        name for pair in coordinate_pairs.values() for name in pair.values()
    }
    if paired != coordinate_names:
        errors.append(
            "continuous columns are not exactly the coordinates identified "
            "from containment rows"
        )

    # Verify every named nonoverlap row has coordinate terms plus one slice.
    disjunctions = {}
    bad_nonoverlap = []
    slice_incidence = defaultdict(list)

    for skey, rows in sorted(nonoverlap.items()):
        i, ri, j, rj, s = skey
        entries = []
        found_slice = None
        for k, c, terms in sorted(rows):
            zs = [(v.VarName, a) for v, a in terms if v.VarName in slice_set]
            unexpected = [
                v.VarName for v, a in terms
                if v.VarName not in slice_set
                and v.VarName not in coordinate_names
            ]
            valid = (
                c.Sense == GRB.LESS_EQUAL and len(zs) == 1
                and zs[0][1] > 0 and not unexpected
            )
            if not valid:
                bad_nonoverlap.append(c.ConstrName)
            else:
                z, big_m = zs[0]
                if found_slice is not None and found_slice != z:
                    bad_nonoverlap.append(c.ConstrName)
                found_slice = z
                active_rhs = c.RHS - big_m
                entries.append({
                    "k": k,
                    "row": c.ConstrName,
                    "slice": z,
                    "M_hex": float(big_m).hex(),
                    "inactive_rhs_hex": float(c.RHS).hex(),
                    "active_rhs_hex": float(active_rhs).hex(),
                    "coordinate_terms": [
                        [v.VarName, float(a).hex()]
                        for v, a in terms if v.VarName in coordinate_names
                    ],
                })
                slice_incidence[z].append(c.ConstrName)

        disjunctions[",".join(map(str, skey))] = {
            "pair_orientation_slice": list(skey),
            "slice_variable": found_slice,
            "halfspaces": entries,
        }

    if bad_nonoverlap:
        errors.append(
            f"{len(bad_nonoverlap)} named nonoverlap rows fail the "
            "coordinate-plus-one-positive-big-M fingerprint"
        )

    # Each slice should occur in one choice row and its own nonoverlap rows only.
    column_rows = defaultdict(set)
    for c in constraints:
        for v, a in row_terms(model, c):
            if a:
                column_rows[v.VarName].add(c.ConstrName)

    bad_slice_incidence = []
    for z, owner in slice_owner.items():
        choice_name = choice_rows[owner][0].ConstrName
        expected = {choice_name} | set(slice_incidence[z])
        if column_rows[z] != expected:
            bad_slice_incidence.append({
                "slice": z,
                "extra": sorted(column_rows[z] - expected),
                "missing": sorted(expected - column_rows[z]),
            })
    if bad_slice_incidence:
        errors.append(
            f"{len(bad_slice_incidence)} slice columns have unexpected incidence"
        )

    integer_names = {
        v.VarName for v in variables if v.VType != GRB.CONTINUOUS
    }
    unexplained_integer = integer_names - orientation_set - slice_set
    if unexplained_integer:
        errors.append(
            f"{len(unexplained_integer)} integer columns are neither orientations "
            "nor recovered slices"
        )

    return {
        "errors": errors,
        "counts": {
            "coordinates": len(coordinate_names),
            "orientation_variables": len(orientation_set),
            "slice_variables": len(slice_set),
            "choice_groups": len(slice_groups),
            "named_nonoverlap_slice_groups": len(nonoverlap),
            "containment_rows": len(containment_json),
            "unclassified_rows": model.NumConstrs - len(classified),
        },
        "orientation_rows": orientation_rows_json,
        "rotation_map": {
            str(i): {str(r): rotation_map[i].get(r) for r in range(4)}
            for i in range(7)
        },
        "coordinates": {
            str(i): coordinate_pairs.get(i, {}) for i in range(7)
        },
        "containment": containment_json,
        "choice_groups": {
            ",".join(map(str, key)): {
                "key": list(key),
                "row": choice_rows[key][0].ConstrName,
                "orientation_i": rotation_map[key[0]].get(key[1]),
                "orientation_j": rotation_map[key[2]].get(key[3]),
                "slices": slices,
            }
            for key, slices in sorted(slice_groups.items())
        },
        "disjunctions": disjunctions,
        "bad_slice_incidence": bad_slice_incidence[:50],
        "_orientation_set": orientation_set,
        "_slice_set": slice_set,
        "_rotation_map": rotation_map,
        "_slice_owner": slice_owner,
        "_slice_groups": slice_groups,
        "_coordinate_names": coordinate_names,
    }


def solution_filename(path, tempdir):
    path = Path(path)
    if path.suffix != ".gz":
        return str(path)
    target = Path(tempdir) / path.name[:-3]
    with gzip.open(path, "rb") as src, open(target, "wb") as dst:
        dst.write(src.read())
    return str(target)


def load_solution_as_start(model, path, tempdir):
    for v in model.getVars():
        v.Start = GRB.UNDEFINED
    model.update()
    model.read(solution_filename(path, tempdir))
    model.update()

    values = {}
    omitted = []
    for v in model.getVars():
        x = v.Start
        if x >= GRB.UNDEFINED / 2 or math.isnan(x):
            values[v.VarName] = 0.0  # sparse SOL convention
            omitted.append(v.VarName)
        else:
            values[v.VarName] = float(x)
    return values, omitted


def violation_for_row(constr, lhs):
    rhs = D(constr.RHS)
    if constr.Sense == GRB.LESS_EQUAL:
        return max(Decimal(0), lhs - rhs)
    if constr.Sense == GRB.GREATER_EQUAL:
        return max(Decimal(0), rhs - lhs)
    return abs(lhs - rhs)


def audit_solution(model, structure, path, tempdir):
    values, omitted = load_solution_as_start(model, path, tempdir)
    variables = model.getVars()

    objective = D(model.ObjCon)
    bound_violations = []
    integrality = []
    for v in variables:
        x = D(values[v.VarName])
        objective += D(v.Obj) * x
        if finite(v.LB) and x < D(v.LB):
            bound_violations.append((v.VarName, D(v.LB) - x))
        if finite(v.UB) and x > D(v.UB):
            bound_violations.append((v.VarName, x - D(v.UB)))
        if v.VType != GRB.CONTINUOUS:
            iv = abs(x - Decimal(round(float(x))))
            if iv:
                integrality.append((v.VarName, iv))

    row_violations = []
    exact_nonzero_row_violations = 0
    for c in model.getConstrs():
        lhs = sum(
            (D(a) * D(values[v.VarName]) for v, a in row_terms(model, c)),
            Decimal(0),
        )
        vio = violation_for_row(c, lhs)
        if vio:
            exact_nonzero_row_violations += 1
            row_violations.append((c.ConstrName, vio))
    row_violations.sort(key=lambda x: x[1], reverse=True)
    integrality.sort(key=lambda x: x[1], reverse=True)
    bound_violations.sort(key=lambda x: x[1], reverse=True)

    max_row = row_violations[0][1] if row_violations else Decimal(0)
    max_int = integrality[0][1] if integrality else Decimal(0)
    max_bound = bound_violations[0][1] if bound_violations else Decimal(0)
    feastol = Decimal(str(model.Params.FeasibilityTol))
    inttol = Decimal(str(model.Params.IntFeasTol))

    active_orientations = []
    selected_state = {}
    for i in range(7):
        active = []
        for r in range(4):
            name = structure["_rotation_map"][i].get(r)
            if name is not None and values[name] > 0.5:
                active.append({
                    "rotation": r,
                    "degrees": 90 * r,
                    "variable": name,
                    "value": values[name],
                })
        active_orientations.extend(
            [{"polygon": i, **entry} for entry in active]
        )
        selected_state[str(i)] = (
            "absent" if not active else
            active[0]["rotation"] if len(active) == 1 else
            {"invalid_multiple": [x["rotation"] for x in active]}
        )

    active_slices = []
    for z in sorted(structure["_slice_set"]):
        if values[z] > 0.5:
            owner = structure["_slice_owner"].get(z)
            active_slices.append({
                "variable": z,
                "value": values[z],
                "choice_group": None if owner is None else list(owner),
            })

    active_choice_groups = []
    for key, slices in sorted(structure["_slice_groups"].items()):
        chosen = [
            {"variable": z, "value": values[z]}
            for z in slices if values[z] > 0.5
        ]
        oi = structure["_rotation_map"][key[0]].get(key[1])
        oj = structure["_rotation_map"][key[2]].get(key[3])
        orientations_active = (
            oi is not None and oj is not None
            and values[oi] > 0.5 and values[oj] > 0.5
        )
        if orientations_active or chosen:
            active_choice_groups.append({
                "key": list(key),
                "orientation_pair_active": orientations_active,
                "active_slices": chosen,
            })

    return {
        "file": str(path),
        "omitted_variables_treated_as_zero": len(omitted),
        "objective_from_loaded_coefficients": ds(objective),
        "exact_feasible_loaded_double_system": (
            max_row == 0 and max_int == 0 and max_bound == 0
        ),
        "tolerance_feasible": (
            max_row <= feastol and max_int <= inttol and max_bound <= feastol
        ),
        "tolerances": {
            "FeasibilityTol": ds(feastol),
            "IntFeasTol": ds(inttol),
        },
        "maximum_row_violation": ds(max_row),
        "maximum_integrality_violation": ds(max_int),
        "maximum_bound_violation": ds(max_bound),
        "nonzero_exact_row_violation_count": exact_nonzero_row_violations,
        "largest_row_violations": [
            {"row": n, "violation": ds(v)}
            for n, v in row_violations[:20]
        ],
        "largest_integrality_violations": [
            {"variable": n, "violation": ds(v)}
            for n, v in integrality[:20]
        ],
        "selected_outer_state": selected_state,
        "active_orientations": active_orientations,
        "active_slice_variables": active_slices,
        "relevant_choice_groups": active_choice_groups,
        "qualification": (
            "Exact means zero violation under exact Decimal arithmetic applied "
            "to the IEEE-754 coefficients and Start values returned by Gurobi. "
            "Tolerance feasibility uses the model's FeasibilityTol and "
            "IntFeasTol. It is not exact rational feasibility of unrounded geometry."
        ),
    }


def interval_redundancies(model):
    """Prove rows redundant only by exact interval arithmetic over column bounds."""
    redundant = []
    for c in model.getConstrs():
        lo = Decimal(0)
        hi = Decimal(0)
        bounded_lo = bounded_hi = True
        for v, a0 in row_terms(model, c):
            a = D(a0)
            vl = D(v.LB) if finite(v.LB) else None
            vu = D(v.UB) if finite(v.UB) else None
            if a >= 0:
                if vl is None:
                    bounded_lo = False
                else:
                    lo += a * vl
                if vu is None:
                    bounded_hi = False
                else:
                    hi += a * vu
            else:
                if vu is None:
                    bounded_lo = False
                else:
                    lo += a * vu
                if vl is None:
                    bounded_hi = False
                else:
                    hi += a * vl

        rhs = D(c.RHS)
        proven = (
            (c.Sense == GRB.LESS_EQUAL and bounded_hi and hi <= rhs)
            or (c.Sense == GRB.GREATER_EQUAL and bounded_lo and lo >= rhs)
            or (c.Sense == GRB.EQUAL and bounded_lo and bounded_hi
                and lo == rhs and hi == rhs)
        )
        if proven:
            redundant.append(c.ConstrName)
    return redundant


def safe_objective_state_exclusions(model, structure, incumbent_upper):
    """
    Algebraic lower bounds using variable bounds and verified at-most-one
    orientation groups. Pairwise and containment constraints are ignored,
    making these valid but generally weak minimization lower bounds.
    """
    upper = Decimal(str(incumbent_upper))
    orientation_names = structure["_orientation_set"]
    base = D(model.ObjCon)

    # Independent minimum contribution of non-orientation objective columns.
    for v in model.getVars():
        if v.VarName in orientation_names or v.Obj == 0:
            continue
        endpoint = v.LB if v.Obj > 0 else v.UB
        if not finite(endpoint):
            return {
                "tested": False,
                "reason": f"objective column {v.VarName} has no finite minimizing bound",
                "exclusions": [],
            }
        base += D(v.Obj) * D(endpoint)

    state_costs = {}
    for i in range(7):
        mapping = structure["_rotation_map"][i]
        if set(mapping) != {0, 1, 2, 3}:
            return {
                "tested": False,
                "reason": f"polygon {i} has incomplete orientation recovery",
                "exclusions": [],
            }
        state_costs[i] = {"absent": Decimal(0)}
        for r in range(4):
            state_costs[i][str(r)] = D(model.getVarByName(mapping[r]).Obj)

    minima = {i: min(state_costs[i].values()) for i in range(7)}
    exclusions = []
    for i in range(7):
        others = sum((minima[j] for j in range(7) if j != i), Decimal(0))
        for state, cost in state_costs[i].items():
            lower_bound = base + others + cost
            if lower_bound > upper:
                exclusions.append({
                    "polygon": i,
                    "state": state,
                    "lower_bound": ds(lower_bound),
                    "incumbent_upper_bound": ds(upper),
                })

    return {
        "tested": True,
        "base_nonorientation_bound": ds(base),
        "exclusions": exclusions,
        "qualification": (
            "Each exclusion follows only if its objective lower bound is strictly "
            "greater than the incumbent upper bound. No unlisted fixing is implied."
        ),
    }


def public_structure(structure):
    return {
        k: v for k, v in structure.items() if not k.startswith("_")
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", required=True, type=Path)
    parser.add_argument("--sol", action="append", default=[], type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--incumbent-upper", default="-51837708")
    args = parser.parse_args()

    args.out.mkdir(parents=True, exist_ok=True)
    env = gp.Env(empty=True)
    env.setParam("OutputFlag", 0)
    env.start()

    # Reader only: no optimize(), presolve(), relax(), fixed(), or model changes.
    model = gp.read(str(args.mps), env=env)
    model.update()

    structure = infer_structure(model)
    with tempfile.TemporaryDirectory(prefix="polygonpack-sol-") as tempdir:
        audits = [
            audit_solution(model, structure, path, tempdir)
            for path in args.sol
        ]

    redundant = interval_redundancies(model)
    safe_fixings = safe_objective_state_exclusions(
        model, structure, Decimal(args.incumbent_upper)
    )

    report = {
        "reader": {
            "gurobi_version": list(gp.gurobi.version()),
            "operations": ["read MPS", "read SOL as Start", "inspect matrix"],
            "optimize_called": False,
            "presolve_called": False,
        },
        "model": {
            "name": model.ModelName,
            "sense": "min" if model.ModelSense == GRB.MINIMIZE else "max",
            "variables": model.NumVars,
            "continuous": sum(
                v.VType == GRB.CONTINUOUS for v in model.getVars()
            ),
            "integer_or_binary": sum(
                v.VType != GRB.CONTINUOUS for v in model.getVars()
            ),
            "constraints": model.NumConstrs,
            "nonzeros": model.NumNZs,
            "objective_nonzeros": sum(v.Obj != 0 for v in model.getVars()),
        },
        "structure": public_structure(structure),
        "solution_audits": audits,
        "safe_algebraic_tests": {
            "bound_implied_redundant_row_count": len(redundant),
            "bound_implied_redundant_row_samples": redundant[:100],
            "objective_state_exclusions": safe_fixings,
            "incumbent_upper_bound": args.incumbent_upper,
            "no_proof_claim": (
                "These are only interval-bound redundancies and objective lower-"
                "bound exclusions. They are algebraically valid for the loaded "
                "model but do not establish global optimality."
            ),
        },
        "next_step_plan": [
            "Use the recovered 5^7 absent/orientation states as the outer search.",
            "For each selected polygon pair and orientation, replace its slice "
            "binaries by the recovered finite OR of active halfspace conjunctions.",
            "Retain loaded IEEE-754 coefficients exactly as binary rationals, or "
            "extract the textual LP decimals through a trusted Gurobi writer and "
            "state explicitly which coefficient system is certified.",
            "Solve each objective layer with SAT/SMT(LRA) or logic-based Benders: "
            "Boolean choices select no-fit slices; exact LRA checks translations.",
            "Treat equality on nonoverlap and container rows as feasible because "
            "the saved model uses non-strict inequalities; separately document "
            "whether intended polygon geometry permits boundary contact.",
            "A strict optimality claim requires a checkable UNSAT certificate for "
            "every objective layer better than the incumbent under the actual "
            "saved coefficient system.",
        ],
    }

    output = args.out / "polygonpack4-7-diagnostic.json"
    output.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps({
        "output": str(output),
        "structural_errors": structure["errors"],
        "solutions": [
            {
                "file": a["file"],
                "objective": a["objective_from_loaded_coefficients"],
                "exact_feasible": a["exact_feasible_loaded_double_system"],
                "tolerance_feasible": a["tolerance_feasible"],
                "selected_outer_state": a["selected_outer_state"],
                "active_slice_count": len(a["active_slice_variables"]),
            }
            for a in audits
        ],
    }, indent=2))

    model.dispose()
    env.dispose()
    return 0 if not structure["errors"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
