#!/usr/bin/env python3
"""Exact repair of one tolerance-feasible polygonpack incumbent.

Gurobi is used only to read the MPS matrix. No optimization, presolve, model
copy, or other solving operation is performed.
"""

import argparse
import gzip
import json
import re
import tempfile
import xml.etree.ElementTree as ET
from decimal import Decimal, getcontext
from fractions import Fraction
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB
import numpy as np
from scipy.optimize import linprog

getcontext().prec = 80


def exact_float(x):
    return Fraction.from_float(float(x))


def fraction_decimal(x):
    return format(
        Decimal(x.numerator) / Decimal(x.denominator),
        "f",
    )


def read_sparse_solution(path):
    raw = path.read_bytes()
    if raw[:2] == b"\x1f\x8b" or path.suffix == ".gz":
        raw = gzip.decompress(raw)
    text = raw.decode("utf-8", errors="replace")
    values = {}

    try:
        root = ET.fromstring(text)
        for node in root.iter():
            name = node.attrib.get("name")
            value = node.attrib.get("value")
            if name is not None and value is not None:
                values[name] = exact_float(float(value))
        if values:
            return values
    except ET.ParseError:
        pass

    objective_re = re.compile(
        r"objective(?:\s+value)?\s*[:=]\s*"
        r"([-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?)",
        re.I,
    )
    number_re = re.compile(
        r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?"
    )

    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith(("#", "*")):
            continue
        if objective_re.search(line):
            continue
        fields = line.split()
        if len(fields) >= 2:
            match = number_re.fullmatch(fields[1])
            if match:
                values[fields[0]] = exact_float(float(match.group(0)))
    return values


def row_terms(model, constr):
    row = model.getRow(constr)
    return [
        (row.getVar(k), exact_float(row.getCoeff(k)))
        for k in range(row.size())
    ]


def fixed_solution(model, sparse):
    values = {}
    integer_errors = []

    for var in model.getVars():
        raw = sparse.get(var.VarName, Fraction(0))
        if var.VType == GRB.CONTINUOUS:
            values[var.VarName] = raw
        else:
            rounded = int(round(float(raw)))
            values[var.VarName] = Fraction(rounded)
            if raw != rounded:
                integer_errors.append({
                    "variable": var.VarName,
                    "listed_value": str(raw),
                    "rounded_value": rounded,
                    "distance": str(abs(raw - rounded)),
                })
    return values, integer_errors


def substituted_rows(model, values, coordinates):
    result = []
    coordinate_set = set(coordinates)

    for constr in model.getConstrs():
        cont = {}
        fixed = Fraction(0)

        for var, coef in row_terms(model, constr):
            if var.VarName in coordinate_set:
                cont[var.VarName] = cont.get(var.VarName, Fraction(0)) + coef
            else:
                fixed += coef * values[var.VarName]

        rhs = exact_float(constr.RHS) - fixed
        sense = constr.Sense

        if sense == GRB.LESS_EQUAL:
            result.append({
                "name": constr.ConstrName,
                "sense": "<=",
                "terms": cont,
                "rhs": rhs,
            })
        elif sense == GRB.GREATER_EQUAL:
            result.append({
                "name": constr.ConstrName,
                "sense": ">=",
                "terms": cont,
                "rhs": rhs,
            })
        elif sense == GRB.EQUAL:
            result.append({
                "name": constr.ConstrName,
                "sense": "=",
                "terms": cont,
                "rhs": rhs,
            })
        else:
            raise RuntimeError(f"unsupported row sense {sense!r}")

    for var in model.getVars():
        if var.VarName not in coordinate_set:
            continue
        x = var.VarName
        if var.LB > -GRB.INFINITY:
            result.append({
                "name": f"BOUND_LO_{x}",
                "sense": ">=",
                "terms": {x: Fraction(1)},
                "rhs": exact_float(var.LB),
            })
        if var.UB < GRB.INFINITY:
            result.append({
                "name": f"BOUND_UP_{x}",
                "sense": "<=",
                "terms": {x: Fraction(1)},
                "rhs": exact_float(var.UB),
            })

    return result


def scipy_system(rows, coordinates, model):
    index = {name: i for i, name in enumerate(coordinates)}
    aub, bub, aeq, beq = [], [], [], []

    for row in rows:
        a = np.zeros(len(coordinates), dtype=float)
        for name, coef in row["terms"].items():
            a[index[name]] = float(coef)

        if row["sense"] == "<=":
            aub.append(a)
            bub.append(float(row["rhs"]))
        elif row["sense"] == ">=":
            aub.append(-a)
            bub.append(float(-row["rhs"]))
        else:
            aeq.append(a)
            beq.append(float(row["rhs"]))

    bounds = []
    for name in coordinates:
        var = model.getVarByName(name)
        lo = None if var.LB <= -GRB.INFINITY else float(var.LB)
        hi = None if var.UB >= GRB.INFINITY else float(var.UB)
        bounds.append((lo, hi))

    return (
        np.asarray(aub, dtype=float) if aub else None,
        np.asarray(bub, dtype=float) if bub else None,
        np.asarray(aeq, dtype=float) if aeq else None,
        np.asarray(beq, dtype=float) if beq else None,
        bounds,
    )


def robust_point(rows, coordinates, model):
    index = {name: i for i, name in enumerate(coordinates)}
    aub, bub, aeq, beq, bounds = scipy_system(rows, coordinates, model)

    # Maximize t, where every non-equality row has slack at least t.
    if aub is not None:
        m = len(aub)
        augmented = np.zeros((m, len(coordinates) + 1))
        augmented[:, :-1] = aub
        augmented[:, -1] = 1.0
        rhs = bub
    else:
        augmented = None
        rhs = None

    objective = np.zeros(len(coordinates) + 1)
    objective[-1] = -1.0

    result = linprog(
        objective,
        A_ub=augmented,
        b_ub=rhs,
        A_eq=(
            np.pad(aeq, ((0, 0), (0, 1)))
            if aeq is not None else None
        ),
        b_eq=beq,
        bounds=bounds + [(None, None)],
        method="highs",
    )

    if not result.success:
        return {
            "success": False,
            "status": result.status,
            "message": result.message,
            "point": None,
            "minimum_inequality_slack": None,
        }

    point = {
        name: float(result.x[i])
        for name, i in index.items()
    }
    return {
        "success": True,
        "status": result.status,
        "message": result.message,
        "point": point,
        "minimum_inequality_slack": float(result.x[-1]),
    }


def rationalize_point(point, max_denominator):
    return {
        name: Fraction(value).limit_denominator(max_denominator)
        for name, value in point.items()
    }


def evaluate_row(row, point):
    lhs = sum(
        (coef * point[name] for name, coef in row["terms"].items()),
        Fraction(0),
    )
    if row["sense"] == "<=":
        violation = max(Fraction(0), lhs - row["rhs"])
        slack = row["rhs"] - lhs
    elif row["sense"] == ">=":
        violation = max(Fraction(0), row["rhs"] - lhs)
        slack = lhs - row["rhs"]
    else:
        violation = abs(lhs - row["rhs"])
        slack = -violation

    return lhs, slack, violation


def exact_audit(rows, point):
    audited = []
    failures = []

    for row in rows:
        lhs, slack, violation = evaluate_row(row, point)
        item = {
            "row": row["name"],
            "sense": row["sense"],
            "lhs": str(lhs),
            "rhs": str(row["rhs"]),
            "slack": str(slack),
            "violation": str(violation),
        }
        audited.append(item)
        if violation:
            failures.append(item)

    return audited, failures


def objective_value(model, values):
    result = exact_float(model.ObjCon)
    for var in model.getVars():
        result += exact_float(var.Obj) * values[var.VarName]
    return result


def write_sparse_sol(path, model, values):
    root = ET.Element("GurobiData")
    variables = ET.SubElement(root, "variables")

    for var in model.getVars():
        value = values[var.VarName]
        if value == 0:
            continue
        ET.SubElement(
            variables,
            "variable",
            name=var.VarName,
            value=fraction_decimal(value),
        )

    tree = ET.ElementTree(root)
    tree.write(path, encoding="utf-8", xml_declaration=True)


def compact_row(item):
    return {
        "row": item["row"],
        "sense": item["sense"],
        "slack": item["slack"],
        "violation": item["violation"],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", required=True, type=Path)
    parser.add_argument("--sol", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--max-denominator", required=True, type=int)
    args = parser.parse_args()

    if args.max_denominator < 1:
        raise ValueError("--max-denominator must be positive")

    args.out.mkdir(parents=True, exist_ok=True)

    env = gp.Env(empty=True)
    env.setParam("OutputFlag", 0)
    env.start()

    # Strictly read-only matrix access.
    model = gp.read(str(args.mps), env=env)
    model.update()

    variables = model.getVars()
    coordinates = [
        var.VarName
        for var in variables
        if var.VType == GRB.CONTINUOUS
    ]
    if len(coordinates) != 14:
        raise RuntimeError(
            f"expected 14 continuous variables, found {len(coordinates)}"
        )

    sparse = read_sparse_solution(args.sol)
    fixed, integer_errors = fixed_solution(model, sparse)
    rows = substituted_rows(model, fixed, coordinates)

    scipy = robust_point(rows, coordinates, model)
    report = {
        "model": {
            "name": model.ModelName,
            "variables": model.NumVars,
            "constraints": model.NumConstrs,
            "nonzeros": model.NumNZs,
            "continuous_variables": coordinates,
            "objective_nonzeros": sum(
                var.Obj != 0 for var in variables
            ),
        },
        "reader": {
            "gurobi_version": list(gp.gurobi.version()),
            "optimize_called": False,
            "presolve_called": False,
            "coefficient_convention":
                "Fraction.from_float(loaded IEEE-754 coefficient)",
            "solution_value_convention":
                "Fraction.from_float(float(listed sparse SOL value)); "
                "every integer value rounded to nearest exact integer",
        },
        "integer_rounding": {
            "changed_count": len(integer_errors),
            "changed": integer_errors,
        },
        "scipy_robust_point": {
            key: value for key, value in scipy.items()
            if key != "point"
        },
        "exact_repair": {
            "status": "not_attempted",
            "max_denominator": args.max_denominator,
        },
    }

    if not scipy["success"]:
        report["exact_repair"] = {
            "status": "no_scipy_feasible_point",
            "proof": False,
            "message": scipy["message"],
            "tight_rows": [],
            "nonproof":
                "SciPy failure is not an exact infeasibility proof.",
        }
        (args.out / "repair-report.json").write_text(
            json.dumps(report, indent=2),
            encoding="utf-8",
        )
        print(json.dumps(report, indent=2))
        model.dispose()
        env.dispose()
        return 2

    rational_point = rationalize_point(
        scipy["point"],
        args.max_denominator,
    )
    audited, failures = exact_audit(rows, rational_point)

    if not failures:
        repaired_values = dict(fixed)
        repaired_values.update(rational_point)
        objective = objective_value(model, repaired_values)

        sol_path = args.out / "repaired.sol"
        coord_path = args.out / "exact-coordinates.json"
        audit_path = args.out / "exact-row-audit.json"

        write_sparse_sol(sol_path, model, repaired_values)
        coord_path.write_text(
            json.dumps(
                {name: str(rational_point[name]) for name in coordinates},
                indent=2,
            ),
            encoding="utf-8",
        )
        audit_path.write_text(
            json.dumps(audited, indent=2),
            encoding="utf-8",
        )

        report["exact_repair"] = {
            "status": "exactly_feasible",
            "proof": True,
            "objective": str(objective),
            "objective_decimal": fraction_decimal(objective),
            "coordinates": {
                name: str(rational_point[name])
                for name in coordinates
            },
            "files": {
                "sparse_solution": str(sol_path),
                "exact_coordinates": str(coord_path),
                "exact_row_audit": str(audit_path),
            },
            "row_count": len(audited),
            "maximum_exact_violation": "0",
            "outer_state_preserved":
                "All noncontinuous values are the rounded values from the "
                "input incumbent; no orientation state was changed except "
                "integer rounding.",
        }
        report["next_step"] = (
            "Independently re-read repaired.sol and verify all original rows. "
            "Then use its exact objective as the incumbent for the six active "
            "pair-disjunction search and strict objective infeasibility test."
        )
    else:
        tight = sorted(
            audited,
            # Exact audit values are serialized Fractions (for example
            # "-1/1000000"), which Decimal cannot parse.  Fraction accepts
            # both integer and numerator/denominator spellings.
            key=lambda x: abs(float(Fraction(x["slack"]))),
        )[:40]
        report["exact_repair"] = {
            "status": "bounded_denominator_rationalization_failed",
            "proof": False,
            "coordinates": {
                name: str(rational_point[name])
                for name in coordinates
            },
            "failed_row_count": len(failures),
            "failed_rows": [compact_row(x) for x in failures[:100]],
            "irreducible_tight_rows": [
                compact_row(x) for x in tight
            ],
            "nonproof":
                "The bounded-denominator candidate is not exact-feasible. "
                "This is neither a proof of infeasibility nor a proof that "
                "the rounded outer state cannot be repaired. Increase the "
                "denominator or solve the same fixed rational system with "
                "an exact LP/Farkas engine.",
        }
        report["next_step"] = (
            "Use the listed tight rows as the initial exact conflict set. "
            "Perform exact rational repair in the affine face defined by "
            "near-zero rows, then verify every original substituted row."
        )

    (args.out / "repair-report.json").write_text(
        json.dumps(report, indent=2),
        encoding="utf-8",
    )
    print(json.dumps(report, indent=2))

    model.dispose()
    env.dispose()
    return 0 if not failures else 3


if __name__ == "__main__":
    raise SystemExit(main())
