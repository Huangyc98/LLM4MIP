#!/usr/bin/env python3
"""Create an exact auxiliary-integrality relaxation of the Tokyo model.

The relaxed families are epigraph or definition variables whose integrality is
implied at an optimum by the retained integer variables:

* dirF/dirB are fixed by integer alpha choices through equalities;
* RPos and bend are absolute-value epigraphs of integer direction expressions;
* lambda is an absolute-value epigraph of integer coordinate differences;
* diff and lambda form a graph total-variation epigraph with integer lower
  breakpoints, whose continuous polyhedron has integral extreme points.

Coordinates x/y and combinatorial alpha/V/delta variables remain integral.
"""

from __future__ import annotations

import gzip
import sys


RELAXED_PREFIXES = ("bend-", "diff_", "lambda-", "dirF-", "dirB-", "RPos-")


def main(input_path: str, output_path: str) -> None:
    current_integer = False
    marker_index = 0
    section = ""
    previous_var = None
    counts = {"integer": set(), "continuous": set()}

    with gzip.open(input_path, "rt", encoding="iso-8859-1") as source, open(output_path, "w", encoding="iso-8859-1") as out:
        for line in source:
            fields = line.split()
            if fields == ["COLUMNS"]:
                section = "COLUMNS"
                out.write(line)
                continue
            if fields == ["RHS"]:
                if current_integer:
                    marker_index += 1
                    out.write(f"    M{marker_index:07d}  'MARKER'                 'INTEND'\n")
                    current_integer = False
                section = "RHS"
                out.write(line)
                continue
            if fields == ["BOUNDS"]:
                section = "BOUNDS"
                out.write(line)
                continue
            if section == "COLUMNS":
                if len(fields) >= 3 and fields[1] == "'MARKER'":
                    # Replace the original all-integer marker block.
                    continue
                var = fields[0]
                if var != previous_var:
                    should_be_integer = not var.startswith(RELAXED_PREFIXES)
                    if should_be_integer != current_integer:
                        marker_index += 1
                        kind = "INTORG" if should_be_integer else "INTEND"
                        out.write(f"    M{marker_index:07d}  'MARKER'                 '{kind}'\n")
                        current_integer = should_be_integer
                    previous_var = var
                counts["integer" if current_integer else "continuous"].add(var)
            elif section == "BOUNDS" and len(fields) >= 3:
                bound_type, bound_name, var = fields[:3]
                if bound_type == "LI" and var.startswith(RELAXED_PREFIXES):
                    # LI/UI cards declare integrality independently of marker
                    # blocks.  lambda/diff use LI lower bounds in the source.
                    value = fields[3] if len(fields) > 3 else "0"
                    out.write(f" LO {bound_name:<18} {var:<40} {value}\n")
                    continue
            out.write(line)

    print(f"integer_variables={len(counts['integer'])}")
    print(f"continuous_auxiliaries={len(counts['continuous'])}")
    print(f"output={output_path}")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
