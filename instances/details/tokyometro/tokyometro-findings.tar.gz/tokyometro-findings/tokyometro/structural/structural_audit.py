#!/usr/bin/env python3
"""Structural audit for the MIPLIB tokyometro MPS."""

from __future__ import annotations

import argparse
import collections
import gzip
import hashlib
import json
import math
from pathlib import Path


def parse_mps(path):
    senses, rhs = {}, {}
    cols, rows = collections.defaultdict(dict), collections.defaultdict(dict)
    bounds, integer = {}, set()
    section, int_mode = None, False
    headers = {"NAME", "OBJSENSE", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "SOS", "INDICATORS", "ENDATA"}
    with gzip.open(path, "rt", encoding="latin-1") as fh:
        for raw in fh:
            line = raw.strip()
            if not line or line.startswith("*"):
                continue
            p = line.split()
            is_header = p[0] in headers and (p[0] not in {"RHS", "RANGES"} or len(p) == 1)
            if is_header:
                section = p[0]
                continue
            if section == "ROWS":
                senses[p[1]] = p[0]
            elif section == "COLUMNS":
                if len(p) >= 3 and p[1].strip("'") == "MARKER":
                    int_mode = p[2].strip("'") == "INTORG"
                    continue
                v = p[0]
                if int_mode:
                    integer.add(v)
                for k in range(1, len(p), 2):
                    r, a = p[k], float(p[k + 1])
                    cols[v][r] = cols[v].get(r, 0.0) + a
                    rows[r][v] = rows[r].get(v, 0.0) + a
            elif section == "RHS":
                for k in range(1, len(p), 2):
                    rhs[p[k]] = float(p[k + 1])
            elif section == "BOUNDS":
                typ, v = p[0], p[2]
                val = float(p[3]) if len(p) > 3 else None
                lo, up = bounds.get(v, (0.0, math.inf))
                if typ in {"UP", "UI"}: up = val
                elif typ in {"LO", "LI"}: lo = val
                elif typ == "FX": lo = up = val
                elif typ == "BV": lo, up = 0.0, 1.0
                elif typ == "FR": lo, up = -math.inf, math.inf
                elif typ == "MI": lo = -math.inf
                elif typ == "PL": up = math.inf
                else: raise ValueError(typ)
                if typ in {"UI", "LI", "BV"}: integer.add(v)
                bounds[v] = lo, up
    return senses, cols, rows, rhs, bounds, integer


def prefix(name):
    # Model names use hyphens almost everywhere, except diff_### and
    # EqEqual_###-plus/minus.  Normalize both conventions to semantic blocks.
    if name.startswith("EqEqual_"):
        return "EqEqual"
    return name.split("-", 1)[0].split("_", 1)[0]


def sig(d):
    return tuple(sorted((k, round(v, 12)) for k, v in d.items()))


def q(a):
    a = sorted(a)
    return {str(p): a[round(p * (len(a) - 1))] for p in (0, .25, .5, .75, .9, .99, 1)}


def read_solution(path):
    values = {}
    declared = None
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8") as fh:
        for raw in fh:
            p = raw.split()
            if not p: continue
            if p[0] == "=obj=": declared = float(p[-1])
            elif raw.startswith("# Objective value ="): declared = float(raw.split("=", 1)[1])
            elif not raw.startswith("#") and len(p) >= 2: values[p[0]] = float(p[1])
    return values, declared


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mps", type=Path)
    ap.add_argument("--solution", type=Path)
    args = ap.parse_args()
    senses, cols, rows, rhs, bounds, integer = parse_mps(args.mps)
    obj = next(r for r, t in senses.items() if t == "N")
    conrows = [r for r, t in senses.items() if t != "N"]

    full = collections.defaultdict(list)
    matrix = collections.defaultdict(list)
    for v in cols:
        full[sig(cols[v])].append(v)
        matrix[sig({r: a for r, a in cols[v].items() if r != obj})].append(v)
    full_dups = [x for x in full.values() if len(x) > 1]
    matrix_dups = [x for x in matrix.values() if len(x) > 1]
    rowdups = collections.defaultdict(list)
    for r in conrows:
        rowdups[(senses[r], rhs.get(r, 0.0), sig(rows[r]))].append(r)
    row_dups = [x for x in rowdups.values() if len(x) > 1]

    singleton = []
    for r in conrows:
        if len(rows[r]) == 1:
            v, a = next(iter(rows[r].items()))
            singleton.append({"row": r, "sense": senses[r], "rhs": rhs.get(r, 0.0),
                              "variable": v, "coefficient": a, "bounds": bounds.get(v, (0, math.inf))})

    row_family = {}
    for fam, famrows in collections.defaultdict(list).items():
        pass
    grouped_rows = collections.defaultdict(list)
    for r in conrows: grouped_rows[prefix(r)].append(r)
    for fam, rr in sorted(grouped_rows.items()):
        row_family[fam] = {
            "rows": len(rr),
            "sense_histogram": dict(collections.Counter(senses[r] for r in rr)),
            "degree_quantiles": q([len(rows[r]) for r in rr]),
            "nonzeros": sum(len(rows[r]) for r in rr),
        }

    var_family = {}
    grouped_vars = collections.defaultdict(list)
    for v in cols: grouped_vars[prefix(v)].append(v)
    for fam, vv in sorted(grouped_vars.items()):
        var_family[fam] = {
            "variables": len(vv),
            "binary": sum(bounds.get(v, (0, math.inf)) == (0.0, 1.0) for v in vv),
            "objective_nonzero": sum(obj in cols[v] and cols[v][obj] != 0 for v in vv),
            "objective_sum": sum(cols[v].get(obj, 0.0) for v in vv),
            "bound_histogram": {str(k): n for k, n in collections.Counter(bounds.get(v, (0, math.inf)) for v in vv).items()},
        }

    # Exact connected components in the constraint-variable graph.
    unseen = set(conrows)
    comps = []
    while unseen:
        seed = min(unseen); unseen.remove(seed)
        rs, vs, queue = {seed}, set(), [seed]
        while queue:
            r = queue.pop()
            for v in rows[r]:
                if v in vs: continue
                vs.add(v)
                for rr in cols[v]:
                    if rr != obj and rr in unseen:
                        unseen.remove(rr); rs.add(rr); queue.append(rr)
        comps.append({"rows": sorted(rs), "variables": sorted(vs)})

    out = {
        "sha256": hashlib.sha256(args.mps.read_bytes()).hexdigest(),
        "variables": len(cols), "constraints": len(conrows),
        "binary": sum(bounds.get(v, (0, math.inf)) == (0.0, 1.0) for v in cols),
        "general_integer": sum(v in integer and bounds.get(v, (0, math.inf)) != (0.0, 1.0) for v in cols),
        "nonzeros": sum(len(rows[r]) for r in conrows),
        "sense_histogram": dict(collections.Counter(senses[r] for r in conrows)),
        "row_degree_quantiles": q([len(rows[r]) for r in conrows]),
        "objective_nonzeros": len(rows[obj]),
        "variable_families": var_family,
        "row_families": row_family,
        "singleton_rows": singleton,
        "identical_full_columns": {"groups": len(full_dups), "variables": sum(map(len, full_dups)), "samples": full_dups[:20]},
        "identical_matrix_columns": {"groups": len(matrix_dups), "variables": sum(map(len, matrix_dups)), "samples": matrix_dups[:20]},
        "identical_rows": {"groups": len(row_dups), "rows": sum(map(len, row_dups)), "samples": row_dups[:20]},
        "connected_components": {
            "count": len(comps),
            "sizes": sorted(((len(c["rows"]), len(c["variables"])) for c in comps), reverse=True),
            "small": [c for c in comps if len(c["rows"]) <= 10 and len(c["variables"]) <= 10],
        },
    }
    if args.solution:
        values, declared = read_solution(args.solution)
        objval = sum(cols[v].get(obj, 0.0) * values.get(v, 0.0) for v in cols)
        violations = []
        for r in conrows:
            act = sum(a * values.get(v, 0.0) for v, a in rows[r].items())
            b = rhs.get(r, 0.0); typ = senses[r]
            if (typ == "G" and act < b - 1e-6) or (typ == "L" and act > b + 1e-6) or (typ == "E" and abs(act-b) > 1e-6):
                violations.append((r, typ, act, b))
        bound_violations = []
        integer_violations = []
        for v in cols:
            x = values.get(v, 0.0)
            lo, up = bounds.get(v, (0.0, math.inf))
            if x < lo - 1e-6 or x > up + 1e-6:
                bound_violations.append((v, x, lo, up))
            if v in integer and abs(x - round(x)) > 1e-6:
                integer_violations.append((v, x))
        out["solution"] = {
            "declared": declared, "recomputed": objval, "violations": len(violations),
            "bound_violations": len(bound_violations),
            "integer_violations": len(integer_violations),
            "listed_values": len(values),
            "violation_samples": violations[:10],
            "bound_violation_samples": bound_violations[:10],
            "integer_violation_samples": integer_violations[:10],
            "nonzero_by_family": dict(collections.Counter(prefix(v) for v, x in values.items() if abs(x) > 1e-9)),
            "objective_by_family": {fam: sum(cols[v].get(obj, 0.0)*values.get(v,0.0) for v in vv)
                                    for fam, vv in grouped_vars.items()},
        }
    print(json.dumps(out, indent=2, sort_keys=True))


if __name__ == "__main__": main()
