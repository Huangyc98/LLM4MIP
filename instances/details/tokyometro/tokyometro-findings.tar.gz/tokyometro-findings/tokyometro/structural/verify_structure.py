#!/usr/bin/env python3
"""Independent exact checks behind the Tokyo Metro structural report.

This does not call an optimizer.  All constraint coefficients used in the
checks are integral; Fraction is used for the two-dimensional polyhedra.
"""

from __future__ import annotations

import argparse
import collections
import itertools
import json
import math
from fractions import Fraction
from pathlib import Path

from structural_audit import parse_mps, read_solution


DIRECTION = {
    0: (1, 0), 1: (1, 1), 2: (0, 1), 3: (-1, 1),
    4: (-1, 0), 5: (-1, -1), 6: (0, -1), 7: (1, -1),
}


def edge_nodes(i, rows):
    names = set()
    for r, terms in rows.items():
        if r.startswith(f"Eq03-{i:03d}-"):
            names.update(v for v, a in terms.items() if v.startswith("x-") and a)
    assert len(names) == 2
    return sorted(names)


def inequalities_for_choice(i, k, senses, rows, rhs):
    """Return a*dx+b*dy <= c after fixing alpha[i,k]=1."""
    xs = edge_nodes(i, rows)
    ys = [v.replace("x-", "y-") for v in xs]
    ans = []
    for r in sorted(r for r in senses if r.startswith(f"Eq03-{i:03d}-")):
        a = int(rows[r].get(xs[1], 0))
        b = int(rows[r].get(ys[1], 0))
        ca = int(rows[r].get(f"alpha-{i:03d}-{k}", 0))
        br = int(rhs.get(r, 0))
        if senses[r] == "L":
            ans.append((a, b, br - ca))
        elif senses[r] == "G":
            ans.append((-a, -b, ca - br))
        else:
            raise AssertionError((r, senses[r]))
    return ans


def vertices_and_rays(cons):
    vertices = set()
    for (a, b, c), (p, q, r) in itertools.combinations(cons, 2):
        det = a * q - b * p
        if not det:
            continue
        x = Fraction(c * q - b * r, det)
        y = Fraction(a * r - c * p, det)
        if all(aa * x + bb * y <= cc for aa, bb, cc in cons):
            vertices.add((x, y))
    rays = set()
    # In two dimensions, an extreme recession ray is parallel to a boundary.
    for a, b, _ in cons:
        for u, v in ((b, -a), (-b, a)):
            if (u or v) and all(aa * u + bb * v <= 0 for aa, bb, _ in cons):
                rays.add((u, v))
    return vertices, rays


def canonical_abs_expression(terms):
    t = tuple(sorted(terms))
    neg = tuple(sorted((v, -a) for v, a in t))
    return min(t, neg)


def main():
    here = Path(__file__).resolve().parent
    ap = argparse.ArgumentParser()
    ap.add_argument("--mps", type=Path, default=here.parent / "input" / "tokyometro.mps.gz")
    ap.add_argument("--solution", type=Path, default=here.parent / "solutions" / "strict-8263.1.sol")
    args = ap.parse_args()

    senses, cols, rows, rhs, bounds, integer = parse_mps(args.mps)
    values, declared = read_solution(args.solution)
    obj = next(r for r, typ in senses.items() if typ == "N")
    conrows = [r for r, typ in senses.items() if typ != "N"]

    assert (len(cols), len(conrows)) == (4537, 7719)
    assert sum(len(rows[r]) for r in conrows) == 26958

    # Exact feasibility of the sparse official solution (unlisted values are 0).
    for v in cols:
        x = values.get(v, 0.0)
        lo, up = bounds.get(v, (0.0, math.inf))
        assert lo <= x <= up
        assert v not in integer or x == round(x)
    for r in conrows:
        activity = sum(a * values.get(v, 0.0) for v, a in rows[r].items())
        b = rhs.get(r, 0.0)
        assert ((senses[r] == "L" and activity <= b) or
                (senses[r] == "G" and activity >= b) or
                (senses[r] == "E" and activity == b)), (r, activity, b)
    objective_tenths = round(10 * sum(cols[v].get(obj, 0.0) * values.get(v, 0.0) for v in cols))
    assert objective_tenths == 82631 and round(10 * declared) == 82631

    # Every Eq03 block is exactly one of three bounded octilinear segments.
    # There are 8 target directions x 3 alternatives = 24 distinct polyhedra.
    unique_polyhedra = set()
    upper_histogram = collections.Counter()
    impossible_alphas = []
    for i in range(311):
        forward = rows[f"Eq02-{i:03d}-F"]
        target = int(rhs.get(f"Eq12-{i:03d}-L", 0))
        for k in range(3):
            alpha = f"alpha-{i:03d}-{k}"
            direction = int(forward.get(alpha, 0))
            if abs(direction - target) > 1:
                impossible_alphas.append(alpha)
            cons = inequalities_for_choice(i, k, senses, rows, rhs)
            signature = (tuple(cons), direction)
            if signature in unique_polyhedra:
                continue
            unique_polyhedra.add(signature)
            vertices, rays = vertices_and_rays(cons)
            dx, dy = DIRECTION[direction]
            parameters = [x / dx if dx else y / dy for x, y in vertices]
            assert not rays and min(parameters) == 1
            upper = max(parameters)
            assert vertices == {
                (Fraction(dx), Fraction(dy)),
                (upper * dx, upper * dy),
            }
            assert upper in (128, 256)
            upper_histogram[int(upper)] += 1
    assert len(unique_polyhedra) == 24
    assert len(impossible_alphas) == 110

    # The 14 degree-one station ordering gadgets are isolated and fixed to 1.
    leaf_v = []
    for i in range(239):
        vv = list(rows[f"Eq04-{i:03d}"])
        if len(vv) == 1:
            leaf_v.extend(vv)
    assert len(leaf_v) == 14
    assert all(values.get(v, 0.0) == 1 for v in leaf_v)

    # Coordinate translation is a two-dimensional exact symmetry.
    for r in conrows:
        assert sum(a for v, a in rows[r].items() if v.startswith("x-")) == 0
        assert sum(a for v, a in rows[r].items() if v.startswith("y-")) == 0

    # Identify repeated bend and length-smoothing factors.
    bend_groups = collections.defaultdict(list)
    diff_groups = collections.defaultdict(list)
    lambda_incidence = collections.Counter()
    for j in range(315):
        bend_terms = [(v, int(a)) for v, a in rows[f"Eq10-{j:03d}-L"].items()
                      if v.startswith(("dirF-", "dirB-")) and a]
        bend_groups[canonical_abs_expression(bend_terms)].append(j)
        pair = tuple(sorted(v for v, a in rows[f"EqEqual_{j:03d}-plus"].items()
                            if v.startswith("lambda-") and a))
        assert len(pair) == 2
        diff_groups[pair].append(j)
        lambda_incidence.update(pair)
    duplicate_bends = [g for g in bend_groups.values() if len(g) > 1]
    duplicate_diffs = [g for g in diff_groups.values() if len(g) > 1]
    assert len(bend_groups) == 302 and sorted(duplicate_bends) == sorted(duplicate_diffs)
    assert len(duplicate_bends) == 13 and all(len(g) == 2 for g in duplicate_bends)
    assert max(lambda_incidence.values()) == 6

    # At the official incumbent all positive-cost epigraphs are at their exact
    # lower envelopes.  This also checks the proposed projection/lift route.
    normalized_delta_changes = 0
    for i in range(311):
        a = [values.get(f"alpha-{i:03d}-{k}", 0.0) for k in range(3)]
        assert values.get(f"RPos-{i:03d}", 0.0) == a[0] + a[2]
        xs = edge_nodes(i, rows)
        dx = values.get(xs[1], 0.0) - values.get(xs[0], 0.0)
        ys = [v.replace("x-", "y-") for v in xs]
        dy = values.get(ys[1], 0.0) - values.get(ys[0], 0.0)
        assert values.get(f"lambda-{i:03d}", 0.0) == max(abs(dx), abs(dy))
    for j in range(315):
        pair = next(k for k, group in diff_groups.items() if j in group)
        assert values.get(f"diff_{j:03d}", 0.0) == abs(values.get(pair[0], 0.0) - values.get(pair[1], 0.0))
        q = sum(a * values.get(v, 0.0) for v, a in rows[f"Eq10-{j:03d}-L"].items()
                if v.startswith(("dirF-", "dirB-")))
        d1 = values.get(f"delta1-{j:03d}", 0.0)
        d2 = values.get(f"delta2-{j:03d}", 0.0)
        assert values.get(f"bend-{j:03d}", 0.0) == abs(q + 8 * (d2 - d1))
        normalized_delta_changes += int(d1 == d2 == 1)

    out = {
        "status": "PASS",
        "official_objective_exact": "82631/10",
        "official_solution_assignments": len(values),
        "official_solution_nonzeros": sum(value != 0 for value in values.values()),
        "eq03_distinct_polyhedra": len(unique_polyhedra),
        "eq03_upper_endpoint_histogram_over_distinct_blocks": dict(upper_histogram),
        "impossible_alpha_fixings": len(impossible_alphas),
        "impossible_alpha_names": impossible_alphas,
        "isolated_leaf_V_fixings": leaf_v,
        "duplicate_bend_groups": sorted(duplicate_bends),
        "duplicate_diff_groups": sorted(duplicate_diffs),
        "max_lambda_smoothing_incidence": max(lambda_incidence.values()),
        "incumbent_delta_11_pairs_normalizable_to_00": normalized_delta_changes,
    }
    print(json.dumps(out, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
