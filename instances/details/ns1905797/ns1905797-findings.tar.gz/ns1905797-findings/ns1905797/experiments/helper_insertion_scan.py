#!/usr/bin/env python3
"""Scan insertion positions into a known feasible task order using decoded logic."""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

from helper_construct_routes import Data, schedule_order


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=Path, required=True)
    ap.add_argument("--base", required=True, help="comma-separated ordinary-task order")
    ap.add_argument("--tasks", nargs="+", type=int, required=True)
    ap.add_argument("--output", type=Path, required=True)
    args = ap.parse_args()
    started = time.time()
    data = Data(args.model)
    base = tuple(int(value) for value in args.base.split(","))
    scans = []
    for added in args.tasks:
        found = None
        attempts = []
        for position in range(len(base) + 1):
            order = base[:position] + (added,) + base[position:]
            attempt_started = time.time()
            schedule = schedule_order(data, order)
            attempts.append({
                "position": position,
                "seconds": time.time() - attempt_started,
                "feasible": schedule is not None,
            })
            if schedule is not None:
                found = {
                    "position": position,
                    "task_order": list(order),
                    "full_sequence": list(schedule.sequence),
                    "time_scaled": schedule.time,
                    "cost_scaled": schedule.cost,
                    "used_reset_mask": schedule.used_mask,
                    "node_times_scaled": dict(schedule.node_times),
                    "node_loads_x5": dict(schedule.node_loads),
                }
                break
        scans.append({"added_task": added, "found": found, "attempts": attempts})
    result = {
        "schema": "ns1905797-fixed-order-insertion-scan-v1",
        "base_order": list(base),
        "scans": scans,
        "wall_seconds": time.time() - started,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(result, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
