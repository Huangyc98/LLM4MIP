#!/usr/bin/env python3
"""Create an auditable assignment-hint variant by applying TASK:BLOCK moves."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def work_units(task: int) -> int:
    return 5 if task <= 10 else 1 if task <= 40 else 10


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", type=Path, required=True)
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--moves", nargs="+", required=True, metavar="TASK:BLOCK")
    args = ap.parse_args()

    source = json.loads(args.input.read_text(encoding="utf-8"))
    selected = list(source["selected_blocks"])
    moves = []
    for specification in args.moves:
        task_text, block_text = specification.split(":", 1)
        task, block = int(task_text), int(block_text)
        if not 1 <= task <= 60 or not 1 <= block <= 4:
            raise ValueError(specification)
        old = selected[task - 1]
        selected[task - 1] = block
        moves.append({"task": task, "from": old, "to": block})

    counts = [selected.count(block) for block in range(1, 5)]
    work = [
        sum(work_units(task) for task, block in enumerate(selected, 1) if block == target)
        for target in range(1, 5)
    ]
    output = dict(source)
    output.update({
        "schema": "ns1905797-mutated-lp-assignment-hint-v1",
        "source": str(args.input),
        "selected_blocks": selected,
        "manual_moves": moves,
        "counts": counts,
        "work_units_x5": work,
    })
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"moves": moves, "counts": counts, "work_units_x5": work}, sort_keys=True))


if __name__ == "__main__":
    main()
