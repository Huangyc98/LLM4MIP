#!/usr/bin/env python3
"""Zero-tolerance Fraction validator for a serialized ns1905797 solution file.

This verifier deliberately depends only on the Python standard library and the
independent MPS parser in ``helper_route_logic.py``.  It validates the values
reparsed from disk, not an in-memory solver vector.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from fractions import Fraction
from pathlib import Path

from helper_route_logic import parse


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=Path, required=True)
    ap.add_argument("--solution", type=Path, required=True)
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--assignment", type=Path)
    ap.add_argument("--partials", type=Path, nargs=4)
    args = ap.parse_args()

    senses, row_order, variables, columns, rows, rhs, lower, upper, integer = parse(args.model)
    variable_set = set(variables)
    sparse = {}
    header_objective = None
    for line_number, line in enumerate(args.solution.read_text(encoding="ascii").splitlines(), 1):
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.startswith("#"):
            marker = "Objective value ="
            if marker in stripped:
                header_objective = Fraction(stripped.split(marker, 1)[1].strip())
            continue
        pieces = stripped.split()
        if len(pieces) != 2:
            raise ValueError(f"{args.solution}:{line_number}: expected NAME VALUE")
        variable, raw = pieces
        if variable not in variable_set:
            raise ValueError(f"{args.solution}:{line_number}: unknown variable {variable}")
        if variable in sparse:
            raise ValueError(f"{args.solution}:{line_number}: duplicate variable {variable}")
        sparse[variable] = Fraction(raw)
    values = {variable: sparse.get(variable, Fraction(0)) for variable in variables}

    bound_violations = []
    integrality_violations = []
    for variable in variables:
        value = values[variable]
        if value < lower[variable] or value > upper[variable]:
            bound_violations.append([variable, str(value), str(lower[variable]), str(upper[variable])])
        if variable in integer and value.denominator != 1:
            integrality_violations.append([variable, str(value)])

    row_violations = []
    maximum_violation = Fraction(0)
    for row in row_order:
        activity = sum(coefficient * values[variable] for variable, coefficient in rows[row])
        target = rhs.get(row, Fraction(0))
        if senses[row] == "E":
            violation = abs(activity - target)
        elif senses[row] == "L":
            violation = max(Fraction(0), activity - target)
        else:
            violation = max(Fraction(0), target - activity)
        maximum_violation = max(maximum_violation, violation)
        if violation:
            row_violations.append([row, str(activity), senses[row], str(target), str(violation)])

    candidate_objective_rows = {
        row for terms in columns.values() for row, coefficient in terms.items()
        if row not in senses and coefficient
    }
    if len(candidate_objective_rows) != 1:
        raise ValueError(f"could not identify unique objective row: {candidate_objective_rows}")
    objective_row = next(iter(candidate_objective_rows))
    objective = sum(columns[variable].get(objective_row, 0) * values[variable] for variable in variables)
    header_matches = header_objective is None or header_objective == objective
    result = {
        "schema": "ns1905797-serialized-solution-fraction-validation-v1",
        "solution_file_reparsed": True,
        "solution": str(args.solution),
        "solution_sha256": hashlib.sha256(args.solution.read_bytes()).hexdigest(),
        "validator_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "mps_parser_sha256": hashlib.sha256(
            Path(__file__).with_name("helper_route_logic.py").read_bytes()
        ).hexdigest(),
        "model": str(args.model),
        "model_sha256": hashlib.sha256(args.model.read_bytes()).hexdigest(),
        "variables_materialized": len(variables),
        "explicit_nonzero_values": len(sparse),
        "rows_checked": len(row_order),
        "objective_fraction": str(objective),
        "objective_decimal": float(objective),
        "header_objective": str(header_objective) if header_objective is not None else None,
        "header_objective_matches": header_matches,
        "bound_violation_count": len(bound_violations),
        "integrality_violation_count": len(integrality_violations),
        "row_violation_count": len(row_violations),
        "maximum_exact_row_violation": str(maximum_violation),
        "bound_violations": bound_violations[:20],
        "integrality_violations": integrality_violations[:20],
        "row_violations": row_violations[:20],
    }
    component_assignment_compatible = True
    if args.assignment:
        assignment = json.loads(args.assignment.read_text(encoding="utf-8"))
        selected_blocks = assignment["selected_blocks"]
        if len(selected_blocks) != 60:
            raise ValueError("assignment must contain exactly 60 selected blocks")
        result["assignment"] = {
            "path": str(args.assignment),
            "sha256": hashlib.sha256(args.assignment.read_bytes()).hexdigest(),
            "selected_blocks": selected_blocks,
            "task_counts": [selected_blocks.count(block) for block in range(1, 5)],
        }
        if args.partials:
            components = []
            for block, partial in enumerate(args.partials, 1):
                result_path = partial.with_name("result.json")
                component_result = json.loads(result_path.read_text(encoding="utf-8"))
                expected_tasks = [
                    task for task, selected in enumerate(selected_blocks, 1) if selected == block
                ]
                matches = component_result.get("assigned_tasks") == expected_tasks
                component_assignment_compatible &= matches
                components.append({
                    "block": block,
                    "partial": str(partial),
                    "partial_sha256": hashlib.sha256(partial.read_bytes()).hexdigest(),
                    "result": str(result_path),
                    "result_sha256": hashlib.sha256(result_path.read_bytes()).hexdigest(),
                    "status": component_result.get("status"),
                    "assigned_tasks": component_result.get("assigned_tasks"),
                    "expected_tasks": expected_tasks,
                    "assignment_matches_block": matches,
                })
            result["components"] = components
    elif args.partials:
        raise ValueError("--partials requires --assignment")
    result["component_assignment_compatible"] = component_assignment_compatible
    result["valid"] = (
        not bound_violations
        and not integrality_violations
        and not row_violations
        and header_matches
        and component_assignment_compatible
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(result, sort_keys=True), flush=True)
    if not result["valid"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
