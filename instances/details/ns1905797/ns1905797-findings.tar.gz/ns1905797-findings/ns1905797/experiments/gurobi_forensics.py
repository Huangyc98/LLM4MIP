#!/usr/bin/env python3
"""Recover anonymous ns1905797 structure after a read-only Gurobi import.

The script deliberately does not call optimize().  It combines Gurobi's parsed
matrix with the official MIPLIB decomposition and emits deterministic JSON that
can be checked into the repository.
"""

from __future__ import annotations

import argparse
import collections
import json
import re
from pathlib import Path

import gurobipy as gp


def clean_number(value: float) -> str:
    if abs(value) < 1e-12:
        value = 0.0
    return format(value, ".12g")


def natural_index(name: str) -> int:
    match = re.search(r"(\d+)$", name)
    return int(match.group(1)) if match else -1


def read_decomposition(path: Path) -> tuple[dict[str, int], list[str]]:
    row_block: dict[str, int] = {}
    master: list[str] = []
    section: tuple[str, int | None] | None = None
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("\\"):
            continue
        if line.startswith("BLOCK "):
            section = ("block", int(line.split()[1]))
            continue
        if line == "MASTERCONSS":
            section = ("master", None)
            continue
        if line in {"PRESOLVED", "NBLOCKS"} or line.isdigit():
            continue
        if section is None:
            continue
        if section[0] == "master":
            master.append(line)
        else:
            row_block[line] = int(section[1])
    return row_block, master


def counts(values) -> list[list[object]]:
    counter = collections.Counter(values)
    return [[key, counter[key]] for key in sorted(counter, key=str)]


def compress_indices(indices: list[int]) -> list[dict[str, int]]:
    """Compress sorted integers into maximal constant-stride runs."""
    if not indices:
        return []
    indices = sorted(indices)
    result: list[dict[str, int]] = []
    start = indices[0]
    previous = indices[0]
    stride = None
    count = 1
    for current in indices[1:]:
        delta = current - previous
        if stride is None:
            stride = delta
        if delta != stride:
            result.append(
                {"start": start, "end": previous, "stride": stride or 1, "count": count}
            )
            start = current
            stride = None
            count = 1
        else:
            count += 1
        previous = current
    result.append({"start": start, "end": previous, "stride": stride or 1, "count": count})
    return result


def bound_key(variable: gp.Var) -> tuple[str, str, str]:
    return variable.VType, clean_number(variable.LB), clean_number(variable.UB)


def variable_record(variable: gp.Var, index: int) -> dict[str, object]:
    return {
        "index": index + 1,
        "name": variable.VarName,
        "type": variable.VType,
        "lb": clean_number(variable.LB),
        "ub": clean_number(variable.UB),
        "objective": clean_number(variable.Obj),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("model")
    parser.add_argument("decomposition")
    parser.add_argument("--output", required=True)
    parser.add_argument("--sample-terms", type=int, default=16)
    args = parser.parse_args()

    gp.setParam("OutputFlag", 0)
    model = gp.read(args.model)
    model.update()
    variables = model.getVars()
    constraints = model.getConstrs()
    var_index = {variable.VarName: i for i, variable in enumerate(variables)}
    row_block, master_names = read_decomposition(Path(args.decomposition))
    master_set = set(master_names)

    block_variables: dict[int, set[int]] = collections.defaultdict(set)
    master_variables: set[int] = set()
    row_cache: dict[str, list[tuple[int, float]]] = {}
    for constraint in constraints:
        expression = model.getRow(constraint)
        terms = [
            (var_index[expression.getVar(i).VarName], expression.getCoeff(i))
            for i in range(expression.size())
        ]
        row_cache[constraint.ConstrName] = terms
        if constraint.ConstrName in master_set:
            master_variables.update(index for index, _ in terms)
        else:
            block = row_block[constraint.ConstrName]
            block_variables[block].update(index for index, _ in terms)

    variable_blocks: dict[int, list[int]] = {}
    for index in range(len(variables)):
        variable_blocks[index] = [
            block for block in sorted(block_variables) if index in block_variables[block]
        ]

    block_summary = []
    for block in sorted(block_variables):
        rows = sorted(natural_index(name) for name, value in row_block.items() if value == block)
        indices = sorted(block_variables[block])
        block_summary.append(
            {
                "block": block,
                "rows": len(rows),
                "row_index_runs": compress_indices(rows),
                "variables": len(indices),
                "variable_index_runs": compress_indices([i + 1 for i in indices]),
                "variable_bound_patterns": counts(bound_key(variables[i]) for i in indices),
            }
        )

    # Aggregate rows by algebraic shape while retaining exact RHS distributions.
    shape_groups: dict[tuple, dict[str, object]] = {}
    equality_rows: list[dict[str, object]] = []
    for constraint in constraints:
        terms = row_cache[constraint.ConstrName]
        coefficient_counts = tuple(
            sorted(collections.Counter(clean_number(value) for _, value in terms).items())
        )
        type_counts = tuple(
            sorted(collections.Counter(variables[index].VType for index, _ in terms).items())
        )
        bound_counts = tuple(
            sorted(collections.Counter(bound_key(variables[index]) for index, _ in terms).items())
        )
        zone: object = "master" if constraint.ConstrName in master_set else row_block[constraint.ConstrName]
        shape = (constraint.Sense, len(terms), coefficient_counts, type_counts, bound_counts)
        group = shape_groups.setdefault(
            shape,
            {
                "sense": constraint.Sense,
                "nnz": len(terms),
                "coefficient_counts": [[key, value] for key, value in coefficient_counts],
                "variable_type_counts": [[key, value] for key, value in type_counts],
                "variable_bound_counts": [
                    [[*key], value] for key, value in bound_counts
                ],
                "rows": [],
                "rhs": [],
                "zones": [],
                "sample": constraint.ConstrName,
            },
        )
        group["rows"].append(natural_index(constraint.ConstrName))
        group["rhs"].append(constraint.RHS)
        group["zones"].append(zone)
        if constraint.Sense == "=":
            equality_rows.append(
                {
                    "row": constraint.ConstrName,
                    "zone": zone,
                    "rhs": clean_number(constraint.RHS),
                    "nnz": len(terms),
                    "coefficient_counts": counts(clean_number(value) for _, value in terms),
                }
            )

    row_shapes = []
    for group in shape_groups.values():
        rhs = group.pop("rhs")
        zones = group.pop("zones")
        row_indices = group.pop("rows")
        group["count"] = len(row_indices)
        group["row_index_runs"] = compress_indices(row_indices)
        group["rhs_min"] = clean_number(min(rhs))
        group["rhs_max"] = clean_number(max(rhs))
        group["rhs_distinct"] = len(set(clean_number(value) for value in rhs))
        group["zone_counts"] = counts(zones)
        row_shapes.append(group)
    row_shapes.sort(key=lambda item: (-int(item["count"]), natural_index(str(item["sample"]))))

    def detailed_row(name: str, limit: int | None = None) -> dict[str, object]:
        constraint = model.getConstrByName(name)
        terms = row_cache[name]
        ordered = sorted(terms)
        if limit is not None and len(ordered) > limit:
            selected = ordered[: limit // 2] + ordered[-(limit - limit // 2) :]
        else:
            selected = ordered
        return {
            "row": name,
            "zone": "master" if name in master_set else row_block[name],
            "sense": constraint.Sense,
            "rhs": clean_number(constraint.RHS),
            "nnz": len(terms),
            "coefficient_counts": counts(clean_number(value) for _, value in terms),
            "terms_truncated": len(selected) != len(ordered),
            "terms": [
                {
                    **variable_record(variables[index], index),
                    "coefficient": clean_number(value),
                    "blocks": variable_blocks[index],
                }
                for index, value in selected
            ],
        }

    # All master rows are small enough to characterize through summaries; retain
    # full terms only for boundary representatives.
    master_rows = []
    for name in sorted(master_names, key=natural_index):
        constraint = model.getConstrByName(name)
        terms = row_cache[name]
        master_rows.append(
            {
                "row": name,
                "sense": constraint.Sense,
                "rhs": clean_number(constraint.RHS),
                "nnz": len(terms),
                "coefficient_counts": counts(clean_number(value) for _, value in terms),
                "block_counts": counts(
                    block
                    for index, _ in terms
                    for block in variable_blocks[index]
                ),
                "variable_indices_by_block": {
                    str(block): [
                        index + 1
                        for index, _ in terms
                        if block in variable_blocks[index]
                    ]
                    for block in sorted(block_variables)
                },
            }
        )

    sample_names = set(master_names[:2] + master_names[-2:])
    sample_names.update(str(group["sample"]) for group in row_shapes[:40])
    # Include every equality shape and both ends of each major index quartile.
    sample_names.update(item["row"] for item in equality_rows[:8])
    for index in [64, 65, 68, 69, 16404, 16405, 16412, 16413, 33580, 33581, 51884]:
        if 1 <= index <= len(constraints):
            sample_names.add(f"R{index:04d}")

    variable_bound_runs = []
    run_start = 0
    last_key = bound_key(variables[0])
    for index in range(1, len(variables) + 1):
        current_key = bound_key(variables[index]) if index < len(variables) else None
        if current_key != last_key:
            variable_bound_runs.append(
                {
                    "start": run_start + 1,
                    "end": index,
                    "count": index - run_start,
                    "type": last_key[0],
                    "lb": last_key[1],
                    "ub": last_key[2],
                    "block_counts": counts(
                        block
                        for variable_index in range(run_start, index)
                        for block in variable_blocks[variable_index]
                    ),
                }
            )
            run_start = index
            last_key = current_key

    # Detect which equalities can serve as directed flow-conservation rows.
    flow_candidates = [
        item
        for item in equality_rows
        if item["rhs"] == "0"
        and item["coefficient_counts"] == [["-1", item["nnz"] // 2], ["1", item["nnz"] // 2]]
        and item["nnz"] % 2 == 0
    ]
    flow_names = {item["row"] for item in flow_candidates}
    binary_flow_profiles: collections.Counter[tuple[int, int]] = collections.Counter()
    for index, variable in enumerate(variables):
        if variable.VType not in {gp.GRB.BINARY, gp.GRB.INTEGER} or variable.UB > 1 + 1e-9:
            continue
        negative = 0
        positive = 0
        column = model.getCol(variable)
        for column_position in range(column.size()):
            constraint = column.getConstr(column_position)
            if constraint.ConstrName not in flow_names:
                continue
            coefficient = column.getCoeff(column_position)
            negative += coefficient < -0.5
            positive += coefficient > 0.5
        binary_flow_profiles[(negative, positive)] += 1

    result = {
        "schema": "ns1905797-gurobi-forensics-v1",
        "gurobi_version": list(gp.gurobi.version()),
        "read_only": True,
        "optimization_attempted": False,
        "dimensions": {
            "variables": model.NumVars,
            "rows": model.NumConstrs,
            "nonzeros": model.NumNZs,
        },
        "decomposition": {
            "blocks": block_summary,
            "master_rows": len(master_names),
            "master_row_index_runs": compress_indices([natural_index(name) for name in master_names]),
            "master_variables": len(master_variables),
            "variables_in_multiple_blocks": sum(
                len(blocks) > 1 for blocks in variable_blocks.values()
            ),
            "variables_in_no_block": sum(
                not blocks for blocks in variable_blocks.values()
            ),
        },
        "variable_bound_runs": variable_bound_runs,
        "row_shapes": row_shapes,
        "equality_rows": equality_rows,
        "flow_candidate_rows": len(flow_candidates),
        "binary_flow_incidence_profiles": [
            {"negative_rows": key[0], "positive_rows": key[1], "count": value}
            for key, value in sorted(binary_flow_profiles.items())
        ],
        "master_rows": master_rows,
        "row_samples": [
            detailed_row(name, args.sample_terms)
            for name in sorted(sample_names, key=natural_index)
            if model.getConstrByName(name) is not None
        ],
    }
    Path(args.output).write_text(
        json.dumps(result, indent=2, sort_keys=False) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
