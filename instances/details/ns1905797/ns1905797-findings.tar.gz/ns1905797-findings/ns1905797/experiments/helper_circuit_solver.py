#!/usr/bin/env python3
"""Exact CP-SAT strengthening of ns1905797 with four native circuits.

The original arc-flow formulation permits high degree syntactically.  Its
strictly positive time/work increments nevertheless imply that every feasible
block is one simple depot cycle.  Adding a native Circuit constraint is thus
redundant for the original rational model, but gives CP-SAT global routing
propagation and routing-specific LNS neighborhoods.

Proof sketch checked by helper_route_logic.py:
  * all selected arcs not entering node 0 impose a positive time increment,
    except 0->66, which is forced off by the exact indegree of node 66;
  * every selected task has positive work, while task->0 implies work <= 0,
    hence all task->0 arcs are off;
  * 66->0 participates in positive time precedence and cannot close a cycle;
  * exactly one of 62->0 and 65->0 is selected.  Therefore all other cycles
    are impossible and flow balance leaves exactly one simple circuit.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import time
from fractions import Fraction
from pathlib import Path

import ortools
from ortools.sat.python import cp_model

from solve_exact_cpsat import (
    build_cp_model,
    exact_validation,
    lcm,
    parse_mps,
    scaled_integer,
    transpose_rows,
    validate_structure,
    write_solution,
)


def recover_arcs(parsed, rows):
    position = {v: i for i, v in enumerate(parsed.variable_order)}
    binaries = {
        v for v in parsed.integer_variables
        if parsed.lower[v] == 0 and parsed.upper[v] == 1
    }
    incidence = {v: [] for v in binaries}
    for node in range(67):
        for block in range(4):
            row = f"R{16413 + 4 * node + block:04d}"
            for variable, coefficient in rows[row]:
                if variable in binaries:
                    incidence[variable].append((node, coefficient))
    arcs = {}
    for variable, entries in incidence.items():
        tail = [node for node, coefficient in entries if coefficient == -1]
        head = [node for node, coefficient in entries if coefficient == 1]
        if len(tail) == len(head) == 1:
            arcs[variable] = (tail[0], head[0], position[variable] % 4)
    if len(arcs) != 17676:
        raise ValueError(f"expected 17676 arcs, recovered {len(arcs)}")
    return arcs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=Path, required=True)
    ap.add_argument("--outdir", type=Path, required=True)
    ap.add_argument("--time-limit", type=float, default=1200)
    ap.add_argument("--workers", type=int, default=16)
    ap.add_argument("--random-seed", type=int, default=31)
    ap.add_argument("--assignment-hint", type=Path)
    ap.add_argument("--original-objective", action="store_true")
    ap.add_argument("--log-search", action="store_true")
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)

    started = time.time()
    parsed = parse_mps(args.model)
    rows = transpose_rows(parsed)
    structure = validate_structure(parsed, rows)
    model, cpvars, assignment, scale, translation = build_cp_model(
        parsed, rows,
        symmetry_break=True,
        strengthen_big_m=True,
        replace_proven_big_m=True,
        native_boolean_rows=True,
        native_assignment_channeling=True,
    )
    arcs = recover_arcs(parsed, rows)

    arc_by_block = [[] for _ in range(4)]
    for variable, (tail, head, block) in arcs.items():
        arc_by_block[block].append((tail, head, cpvars[variable]))
    optional_special = []
    for block in range(4):
        circuit_arcs = list(arc_by_block[block])
        # Ordinary task i is absent from a block iff its assignment literal is false.
        for task in range(1, 61):
            circuit_arcs.append((task, task, assignment[task - 1][block].Not()))
        # Nodes 61..65 may be skipped independently.  Nodes 0 and 66 are mandatory.
        for node in range(61, 66):
            used = model.new_bool_var(f"circuit_used_{node}_{block + 1}")
            optional_special.append(used)
            circuit_arcs.append((node, node, used.Not()))
        model.add_circuit(circuit_arcs)

    hinted_blocks = None
    if args.assignment_hint:
        hint = json.loads(args.assignment_hint.read_text(encoding="utf-8"))
        hinted_blocks = hint["selected_blocks"]
        if len(hinted_blocks) != 60:
            raise ValueError("assignment hint must have 60 entries")
        for task, selected in enumerate(hinted_blocks):
            for block, variable in enumerate(assignment[task], start=1):
                model.add_hint(variable, int(block == selected))

    objective_scale = None
    if args.original_objective:
        terms = []
        for variable in parsed.variable_order:
            coefficient = parsed.columns[variable].get(parsed.objective_row, Fraction(0))
            if coefficient:
                if variable not in parsed.integer_variables:
                    coefficient /= scale
                terms.append((cpvars[variable], coefficient))
        objective_scale = lcm(coefficient.denominator for _, coefficient in terms)
        model.minimize(sum(scaled_integer(c, objective_scale) * v for v, c in terms))

    build_seconds = time.time() - started
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = args.time_limit
    solver.parameters.num_search_workers = args.workers
    solver.parameters.random_seed = args.random_seed
    solver.parameters.randomize_search = True
    solver.parameters.symmetry_level = 3
    solver.parameters.cp_model_presolve = True
    solver.parameters.linearization_level = 2
    solver.parameters.log_search_progress = args.log_search
    solve_started = time.time()
    status = solver.solve(model)
    solve_seconds = time.time() - solve_started
    result = {
        "schema": "ns1905797-exact-circuit-cpsat-v1",
        "input": str(args.model),
        "input_sha256": hashlib.sha256(args.model.read_bytes()).hexdigest(),
        "host": platform.node(),
        "ortools_version": ortools.__version__,
        "cpu_only": True,
        "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES", ""),
        "model": {"variables": len(parsed.variable_order), "rows": len(parsed.row_order), **structure},
        "translation": {**translation, "native_circuit_constraints": 4, "circuit_optional_special_literals": 20},
        "parameters": {
            "time_limit": args.time_limit,
            "workers": args.workers,
            "random_seed": args.random_seed,
            "assignment_hint": str(args.assignment_hint) if args.assignment_hint else None,
            "hinted_blocks": hinted_blocks,
            "original_objective": args.original_objective,
            "objective_scale": objective_scale,
        },
        "build_seconds": build_seconds,
        "solve_wall_seconds": solve_seconds,
        "status": solver.status_name(status),
        "num_conflicts": solver.num_conflicts,
        "num_branches": solver.num_branches,
        "response_stats": solver.response_stats(),
    }
    if status in {cp_model.FEASIBLE, cp_model.OPTIMAL}:
        values = {}
        for variable in parsed.variable_order:
            raw = solver.value(cpvars[variable])
            values[variable] = Fraction(raw, scale) if variable not in parsed.integer_variables else Fraction(raw)
        validation = exact_validation(parsed, rows, values)
        result["validation"] = validation
        if validation["valid"]:
            write_solution(args.outdir / "candidate.sol", values, Fraction(validation["objective_fraction"]))
    (args.outdir / "result.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print("RESULT_JSON=" + json.dumps(result, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
