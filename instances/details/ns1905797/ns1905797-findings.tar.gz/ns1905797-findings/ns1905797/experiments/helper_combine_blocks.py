#!/usr/bin/env python3
"""Combine four independently solved route blocks and validate the full MPS.

The four block files partition the original variables by MPS column position.
Missing entries in each sparse ``partial.sol`` are zero.  Continuous values are
normalized back to the exact 1/100000 lattice before validation, avoiding any
round-trip noise from decimal solution files.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from fractions import Fraction
from pathlib import Path

from solve_exact_cpsat import exact_validation, parse_mps, transpose_rows


SCALE = 100000


def nearest_scaled(value: Fraction) -> Fraction:
    scaled = value * SCALE
    if scaled >= 0:
        numerator = (scaled.numerator * 2 + scaled.denominator) // (2 * scaled.denominator)
    else:
        positive = -scaled
        numerator = -(
            (positive.numerator * 2 + positive.denominator) // (2 * positive.denominator)
        )
    candidate = Fraction(numerator, SCALE)
    if abs(candidate - value) > Fraction(1, 10**10):
        raise ValueError(f"continuous value {value} is not a rounded 1/{SCALE} value")
    return candidate


def read_sparse(path: Path) -> dict[str, Fraction]:
    values = {}
    for line_number, line in enumerate(path.read_text(encoding="ascii").splitlines(), 1):
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        pieces = stripped.split()
        if len(pieces) != 2:
            raise ValueError(f"{path}:{line_number}: expected NAME VALUE")
        variable, raw = pieces
        if variable in values:
            raise ValueError(f"{path}:{line_number}: duplicate {variable}")
        values[variable] = Fraction(raw)
    return values


def exact_decimal(value: Fraction) -> str:
    scaled_value = value * SCALE
    if scaled_value.denominator != 1:
        raise ValueError(f"{value} is not on the exact 1/{SCALE} output lattice")
    raw = scaled_value.numerator
    sign = "-" if raw < 0 else ""
    whole, remainder = divmod(abs(raw), SCALE)
    if remainder == 0:
        return f"{sign}{whole}"
    fraction = f"{remainder:05d}".rstrip("0")
    return f"{sign}{whole}.{fraction}"


def write_exact_solution(path: Path, values: dict[str, Fraction], objective: Fraction) -> None:
    with path.open("w", encoding="ascii", newline="\n") as stream:
        stream.write(f"# Objective value = {exact_decimal(objective)}\n")
        for variable, value in values.items():
            if value:
                stream.write(f"{variable} {exact_decimal(value)}\n")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=Path, required=True)
    ap.add_argument("--partials", type=Path, nargs=4, required=True)
    ap.add_argument("--outdir", type=Path, required=True)
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)

    parsed = parse_mps(args.model)
    rows = transpose_rows(parsed)
    position = {variable: index for index, variable in enumerate(parsed.variable_order)}
    continuous = set(parsed.variable_order) - parsed.integer_variables
    values = {variable: Fraction(0) for variable in parsed.variable_order}
    seen = set()
    nonzeros_by_block = []
    for block, path in enumerate(args.partials):
        sparse = read_sparse(path)
        nonzeros_by_block.append(len(sparse))
        for variable, value in sparse.items():
            if variable not in position:
                raise ValueError(f"unknown variable {variable} in {path}")
            if position[variable] % 4 != block:
                raise ValueError(f"{variable} in {path} belongs to block {position[variable] % 4 + 1}")
            if variable in seen:
                raise ValueError(f"duplicate variable across partials: {variable}")
            if variable in continuous:
                value = nearest_scaled(value)
            elif value.denominator != 1:
                raise ValueError(f"nonintegral integer value {variable}={value}")
            values[variable] = value
            seen.add(variable)

    in_memory_validation = exact_validation(parsed, rows, values)
    report = {
        "schema": "ns1905797-combined-block-validation-v1",
        "partials": [str(path) for path in args.partials],
        "nonzeros_by_block": nonzeros_by_block,
        "all_original_variables_materialized": len(values) == len(parsed.variable_order),
        "in_memory_validation": in_memory_validation,
    }
    candidate_path = args.outdir / "candidate.sol"
    if in_memory_validation["valid"]:
        write_exact_solution(
            candidate_path,
            values,
            Fraction(in_memory_validation["objective_fraction"]),
        )
        reparsed_sparse = read_sparse(candidate_path)
        reparsed_values = {
            variable: reparsed_sparse.get(variable, Fraction(0))
            for variable in parsed.variable_order
        }
        validation = exact_validation(parsed, rows, reparsed_values)
        report.update({
            "solution_file_reparsed": True,
            "solution_sha256": hashlib.sha256(candidate_path.read_bytes()).hexdigest(),
            "validation": validation,
        })
    else:
        validation = in_memory_validation
        report.update({"solution_file_reparsed": False, "validation": validation})
    (args.outdir / "validation.json").write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print("RESULT_JSON=" + json.dumps(report, sort_keys=True), flush=True)
    if not validation["valid"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
