#!/usr/bin/env python3
"""Solve ns1905797 feasibility exactly by integerizing its network variables.

The MPS has 512 continuous variables, but every row containing a continuous
variable is a one- or two-node difference constraint with an integral
coefficient (+1 or -1) on those variables.  Scaling the rational bounds and
right-hand sides therefore yields an equivalent integer-potential system (the
continuous submatrix is a directed-network matrix and is totally unimodular).
All original rows, including route-count and work-limit rows omitted by the
earlier separated master, are sent to CP-SAT at once.
"""

from __future__ import annotations

import argparse
import collections
import gzip
import hashlib
import json
import math
import os
import platform
import time
from dataclasses import dataclass, field
from fractions import Fraction
from pathlib import Path
from typing import TextIO

from ortools.sat.python import cp_model


def rational(text: str) -> Fraction:
    return Fraction(text.replace("D", "E").replace("d", "e"))


def lcm(values) -> int:
    result = 1
    for value in values:
        result = math.lcm(result, int(value))
    return result


def scaled_integer(value: Fraction, scale: int) -> int:
    product = value * scale
    if product.denominator != 1:
        raise ValueError(f"{value} is not integral at scale {scale}")
    return product.numerator


@dataclass
class ParsedMps:
    name: str = ""
    objective_row: str = ""
    row_sense: dict[str, str] = field(default_factory=dict)
    row_order: list[str] = field(default_factory=list)
    variable_order: list[str] = field(default_factory=list)
    integer_variables: set[str] = field(default_factory=set)
    columns: dict[str, dict[str, Fraction]] = field(default_factory=dict)
    rhs: dict[str, Fraction] = field(default_factory=dict)
    lower: dict[str, Fraction] = field(default_factory=dict)
    upper: dict[str, Fraction | None] = field(default_factory=dict)


def open_text(path: Path) -> TextIO:
    if path.suffix == ".gz":
        return gzip.open(path, "rt", encoding="ascii")
    return path.open("r", encoding="ascii")


def parse_mps(path: Path) -> ParsedMps:
    parsed = ParsedMps()
    section = ""
    integer_mode = False
    with open_text(path) as stream:
        for raw in stream:
            stripped = raw.strip()
            if not stripped or stripped.startswith("*"):
                continue
            tokens = stripped.split()
            keyword = tokens[0].upper()
            if keyword == "NAME":
                parsed.name = tokens[1] if len(tokens) > 1 else ""
                section = "NAME"
                continue
            if keyword in {"ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}:
                section = keyword
                if keyword == "ENDATA":
                    break
                continue
            if section == "ROWS":
                sense, name = tokens[:2]
                if sense.upper() == "N":
                    parsed.objective_row = name
                else:
                    parsed.row_sense[name] = sense.upper()
                    parsed.row_order.append(name)
            elif section == "COLUMNS":
                if len(tokens) >= 3 and tokens[1].strip("'").upper() == "MARKER":
                    marker = tokens[2].strip("'").upper()
                    if marker == "INTORG":
                        integer_mode = True
                    elif marker == "INTEND":
                        integer_mode = False
                    continue
                variable = tokens[0]
                if variable not in parsed.columns:
                    parsed.variable_order.append(variable)
                    parsed.columns[variable] = {}
                    parsed.lower[variable] = Fraction(0)
                    parsed.upper[variable] = None
                if integer_mode:
                    parsed.integer_variables.add(variable)
                if (len(tokens) - 1) % 2:
                    raise ValueError(f"bad COLUMNS line: {stripped}")
                for position in range(1, len(tokens), 2):
                    row = tokens[position]
                    value = rational(tokens[position + 1])
                    parsed.columns[variable][row] = (
                        parsed.columns[variable].get(row, Fraction(0)) + value
                    )
            elif section == "RHS":
                if (len(tokens) - 1) % 2:
                    raise ValueError(f"bad RHS line: {stripped}")
                for position in range(1, len(tokens), 2):
                    parsed.rhs[tokens[position]] = rational(tokens[position + 1])
            elif section == "RANGES":
                raise ValueError("RANGES are not supported (and are absent in ns1905797)")
            elif section == "BOUNDS":
                kind = tokens[0].upper()
                variable = tokens[2]
                value = rational(tokens[3]) if len(tokens) > 3 else None
                if kind == "LO":
                    parsed.lower[variable] = value
                elif kind == "UP":
                    parsed.upper[variable] = value
                elif kind == "FX":
                    parsed.lower[variable] = value
                    parsed.upper[variable] = value
                elif kind == "FR":
                    parsed.lower[variable] = None
                    parsed.upper[variable] = None
                elif kind == "MI":
                    parsed.lower[variable] = None
                elif kind == "PL":
                    parsed.upper[variable] = None
                elif kind == "BV":
                    parsed.integer_variables.add(variable)
                    parsed.lower[variable] = Fraction(0)
                    parsed.upper[variable] = Fraction(1)
                elif kind == "LI":
                    parsed.integer_variables.add(variable)
                    parsed.lower[variable] = value
                elif kind == "UI":
                    parsed.integer_variables.add(variable)
                    parsed.upper[variable] = value
                else:
                    raise ValueError(f"unsupported bound type {kind}")
    return parsed


def transpose_rows(parsed: ParsedMps) -> dict[str, list[tuple[str, Fraction]]]:
    rows: dict[str, list[tuple[str, Fraction]]] = {
        name: [] for name in parsed.row_order
    }
    for variable in parsed.variable_order:
        for row, coefficient in parsed.columns[variable].items():
            if row in rows and coefficient:
                rows[row].append((variable, coefficient))
    return rows


def validate_structure(
    parsed: ParsedMps, rows: dict[str, list[tuple[str, Fraction]]]
) -> dict[str, object]:
    continuous = [
        variable
        for variable in parsed.variable_order
        if variable not in parsed.integer_variables
    ]
    mixed_rows = 0
    max_continuous_per_row = 0
    bad_continuous_coefficients = []
    bad_network_rows = []
    for row, terms in rows.items():
        continuous_terms = [
            (variable, coefficient)
            for variable, coefficient in terms
            if variable not in parsed.integer_variables
        ]
        if continuous_terms:
            mixed_rows += 1
            max_continuous_per_row = max(max_continuous_per_row, len(continuous_terms))
            if len(continuous_terms) > 2:
                bad_network_rows.append(row)
            if len(continuous_terms) == 2 and {
                coefficient for _, coefficient in continuous_terms
            } != {Fraction(-1), Fraction(1)}:
                bad_network_rows.append(row)
            for variable, coefficient in continuous_terms:
                if coefficient not in {Fraction(-1), Fraction(1)}:
                    bad_continuous_coefficients.append(
                        [row, variable, str(coefficient)]
                    )
    if bad_continuous_coefficients or bad_network_rows:
        raise ValueError(
            "continuous submatrix is not a signed node-arc matrix: "
            f"coefficients={bad_continuous_coefficients[:5]}, rows={bad_network_rows[:5]}"
        )
    finite_bounds = all(
        parsed.lower[variable] is not None and parsed.upper[variable] is not None
        for variable in parsed.variable_order
    )
    if not finite_bounds:
        raise ValueError("CP-SAT translation requires finite variable bounds")
    return {
        "continuous_variables": len(continuous),
        "integer_variables": len(parsed.integer_variables),
        "mixed_or_continuous_rows": mixed_rows,
        "max_continuous_variables_per_row": max_continuous_per_row,
        "continuous_coefficients": [-1, 1],
        "all_bounds_finite": finite_bounds,
        "network_matrix_integerization_exact": True,
    }


def build_cp_model(
    parsed: ParsedMps,
    rows: dict[str, list[tuple[str, Fraction]]],
    symmetry_break: bool,
    strengthen_big_m: bool,
    replace_proven_big_m: bool,
    native_boolean_rows: bool,
    native_assignment_channeling: bool,
) -> tuple[
    cp_model.CpModel,
    dict[str, cp_model.IntVar],
    list[list[cp_model.IntVar]] | None,
    int,
    dict[str, object],
]:
    continuous = {
        variable
        for variable in parsed.variable_order
        if variable not in parsed.integer_variables
    }
    scale_denominators = []
    for variable in continuous:
        scale_denominators.extend(
            [parsed.lower[variable].denominator, parsed.upper[variable].denominator]
        )
    for row, terms in rows.items():
        if any(variable in continuous for variable, _ in terms):
            scale_denominators.append(parsed.rhs.get(row, Fraction(0)).denominator)
            scale_denominators.extend(
                coefficient.denominator
                for variable, coefficient in terms
                if variable not in continuous
            )
    continuous_scale = lcm(scale_denominators)

    model = cp_model.CpModel()
    cp_variables: dict[str, cp_model.IntVar] = {}
    for variable in parsed.variable_order:
        lower = parsed.lower[variable]
        upper = parsed.upper[variable]
        if variable in continuous:
            cp_lower = scaled_integer(lower, continuous_scale)
            cp_upper = scaled_integer(upper, continuous_scale)
        else:
            if lower.denominator != 1 or upper.denominator != 1:
                raise ValueError(f"nonintegral bound on integer variable {variable}")
            cp_lower = lower.numerator
            cp_upper = upper.numerator
        cp_variables[variable] = model.new_int_var(cp_lower, cp_upper, variable)

    variable_position = {
        variable: position for position, variable in enumerate(parsed.variable_order)
    }
    assignment_variables: list[list[cp_model.IntVar]] | None = None
    channel_replaced_rows: set[str] = set()
    if native_assignment_channeling:
        assignment_variables = []
        for task in range(1, 61):
            master_row = f"R{task:04d}"
            task_assignment = []
            for block in range(4):
                assignment = model.new_bool_var(f"assign_{task}_{block + 1}")
                task_assignment.append(assignment)
                outgoing = [
                    variable
                    for variable, coefficient in rows[master_row]
                    if coefficient == 1 and variable_position[variable] % 4 == block
                ]
                flow_row = f"R{16413 + 4 * task + block:04d}"
                incoming = [
                    variable
                    for variable, coefficient in rows[flow_row]
                    if coefficient == 1
                ]
                flow_outgoing = [
                    variable
                    for variable, coefficient in rows[flow_row]
                    if coefficient == -1
                ]
                if len(outgoing) != 66 or len(incoming) != 66:
                    raise ValueError(
                        f"bad task incidence task={task} block={block + 1}: "
                        f"out={len(outgoing)} in={len(incoming)}"
                    )
                if set(outgoing) != set(flow_outgoing):
                    raise ValueError(
                        f"master/flow outgoing mismatch task={task} block={block + 1}"
                    )
                model.add(sum(cp_variables[name] for name in outgoing) == assignment)
                model.add(sum(cp_variables[name] for name in incoming) == assignment)
                channel_replaced_rows.add(flow_row)
            model.add_exactly_one(task_assignment)
            assignment_variables.append(task_assignment)
            channel_replaced_rows.add(master_row)

    largest_coefficient = 0
    largest_activity_bound = 0
    row_scales: collections.Counter[int] = collections.Counter()
    reified_big_m_rows = 0
    replaced_big_m_rows = 0
    native_exactly_one_rows = 0
    native_at_most_one_rows = 0
    for row in parsed.row_order:
        if row in channel_replaced_rows:
            continue
        terms = rows[row]
        has_continuous = any(variable in continuous for variable, _ in terms)
        if has_continuous:
            row_scale = continuous_scale
            integer_terms = []
            for variable, coefficient in terms:
                if variable in continuous:
                    if coefficient.denominator != 1:
                        raise ValueError(f"nonintegral continuous coefficient in {row}")
                    cp_coefficient = coefficient.numerator
                else:
                    cp_coefficient = scaled_integer(coefficient, row_scale)
                integer_terms.append((cp_variables[variable], cp_coefficient))
            cp_rhs = scaled_integer(parsed.rhs.get(row, Fraction(0)), row_scale)
        else:
            row_scale = lcm(
                [parsed.rhs.get(row, Fraction(0)).denominator]
                + [coefficient.denominator for _, coefficient in terms]
            )
            integer_terms = [
                (cp_variables[variable], scaled_integer(coefficient, row_scale))
                for variable, coefficient in terms
            ]
            cp_rhs = scaled_integer(parsed.rhs.get(row, Fraction(0)), row_scale)
        row_scales[row_scale] += 1
        expression = sum(coefficient * variable for variable, coefficient in integer_terms)
        sense = parsed.row_sense[row]
        all_binary = all(
            variable in parsed.integer_variables
            and parsed.lower[variable] == 0
            and parsed.upper[variable] == 1
            for variable, _ in terms
        )
        native_replacement = False
        if (
            native_boolean_rows
            and sense == "E"
            and parsed.rhs.get(row, Fraction(0)) == 1
            and all_binary
            and all(coefficient == 1 for _, coefficient in terms)
        ):
            model.add_exactly_one(cp_variables[variable] for variable, _ in terms)
            native_exactly_one_rows += 1
            native_replacement = True
        elif (
            native_boolean_rows
            and sense == "L"
            and len(terms) == 2
            and all_binary
            and all(coefficient == 50 for _, coefficient in terms)
            and 50 <= parsed.rhs.get(row, Fraction(0)) < 100
        ):
            model.add_at_most_one(cp_variables[variable] for variable, _ in terms)
            native_at_most_one_rows += 1
            native_replacement = True
        replacement_is_exact = False
        reified_constraint = None

        # The 50/100 big-M time rows encode x => difference and
        # (x AND y) => difference.  When interval arithmetic proves every
        # non-triggered assignment makes the original row redundant, its
        # enforcement form is exactly equivalent, not merely a strengthening.
        if strengthen_big_m and sense == "L":
            continuous_terms = [
                (variable, coefficient)
                for variable, coefficient in terms
                if variable in continuous
            ]
            discrete_terms = [
                (variable, coefficient)
                for variable, coefficient in terms
                if variable not in continuous
            ]
            triggers = [
                variable
                for variable, coefficient in discrete_terms
                if coefficient == 50
                and parsed.lower[variable] == 0
                and parsed.upper[variable] == 1
            ]
            if (
                continuous_terms
                and len(triggers) in {1, 2}
                and len(triggers) == len(discrete_terms)
            ):
                active_rhs = parsed.rhs.get(row, Fraction(0)) - 50 * len(triggers)
                enforced_expression = sum(
                    coefficient.numerator * cp_variables[variable]
                    for variable, coefficient in continuous_terms
                )
                reified_constraint = model.add(
                    enforced_expression
                    <= scaled_integer(active_rhs, continuous_scale)
                )
                reified_constraint.only_enforce_if(
                    [cp_variables[variable] for variable in triggers]
                )
                reified_big_m_rows += 1

                maximum_continuous_activity = sum(
                    max(
                        coefficient * parsed.lower[variable],
                        coefficient * parsed.upper[variable],
                    )
                    for variable, coefficient in continuous_terms
                )
                # Positive and identical M coefficients mean the hardest
                # inactive case has exactly len(triggers)-1 triggers enabled.
                replacement_is_exact = (
                    maximum_continuous_activity + 50 * (len(triggers) - 1)
                    <= parsed.rhs.get(row, Fraction(0))
                )

        if native_replacement:
            pass
        elif replace_proven_big_m and replacement_is_exact:
            replaced_big_m_rows += 1
        else:
            if sense == "E":
                model.add(expression == cp_rhs)
            elif sense == "L":
                model.add(expression <= cp_rhs)
            elif sense == "G":
                model.add(expression >= cp_rhs)
            else:
                raise ValueError(f"unsupported row sense {sense}")
        if integer_terms:
            largest_coefficient = max(
                largest_coefficient, max(abs(value) for _, value in integer_terms)
            )
            activity_bound = 0
            for variable, coefficient in terms:
                lower = parsed.lower[variable]
                upper = parsed.upper[variable]
                activity_bound += max(abs(coefficient * lower), abs(coefficient * upper))
            largest_activity_bound = max(
                largest_activity_bound,
                math.ceil(float(activity_bound * row_scale)),
            )

    symmetry_constraints = []
    if symmetry_break:
        # The published symmetry supplement identifies an S_4 action, and the
        # parsed matrix independently confirms the four blocks are exchangeable.
        # Canonicalize them by order of first assigned ordinary task.  If task i
        # first uses block k, an earlier task must already use block k-1.  This
        # is a compact partitioning-orbitope leader and removes all 4! labels.
        if assignment_variables is not None:
            assignment = assignment_variables
        else:
            assignment = []
            for task in range(1, 61):
                master_terms = rows[f"R{task:04d}"]
                per_block = []
                for block in range(4):
                    block_terms = [
                        cp_variables[variable]
                        for variable, _ in master_terms
                        if variable_position[variable] % 4 == block
                    ]
                    if len(block_terms) != 66:
                        raise ValueError(
                            f"expected 66 terms for task {task}, block {block + 1}; "
                            f"got {len(block_terms)}"
                        )
                    per_block.append(sum(block_terms))
                assignment.append(per_block)
        for task in range(60):
            for block in range(1, 4):
                model.add(
                    assignment[task][block]
                    <= sum(assignment[earlier][block - 1] for earlier in range(task))
                )
        symmetry_constraints.append(
            "180 first-use partitioning-orbitope inequalities for exact S4 breaking"
        )

    metadata = {
        "continuous_scale": continuous_scale,
        "row_scale_counts": dict(sorted(row_scales.items())),
        "largest_absolute_integer_coefficient": largest_coefficient,
        "largest_row_activity_bound": largest_activity_bound,
        "symmetry_constraints": symmetry_constraints,
        "reified_big_m_rows": reified_big_m_rows,
        "exactly_replaced_big_m_rows": replaced_big_m_rows,
        "native_exactly_one_rows": native_exactly_one_rows,
        "native_at_most_one_rows": native_at_most_one_rows,
        "assignment_channel_variables": 240 if assignment_variables is not None else 0,
        "assignment_channel_replaced_rows": len(channel_replaced_rows),
    }
    return model, cp_variables, assignment_variables, continuous_scale, metadata


def exact_validation(
    parsed: ParsedMps,
    rows: dict[str, list[tuple[str, Fraction]]],
    values: dict[str, Fraction],
) -> dict[str, object]:
    bound_violations = []
    integrality_violations = []
    for variable in parsed.variable_order:
        value = values[variable]
        if value < parsed.lower[variable] or value > parsed.upper[variable]:
            bound_violations.append(variable)
        if variable in parsed.integer_variables and value.denominator != 1:
            integrality_violations.append(variable)
    row_violations = []
    worst = Fraction(0)
    for row in parsed.row_order:
        activity = sum(coefficient * values[variable] for variable, coefficient in rows[row])
        rhs = parsed.rhs.get(row, Fraction(0))
        sense = parsed.row_sense[row]
        if sense == "E":
            violation = abs(activity - rhs)
        elif sense == "L":
            violation = max(Fraction(0), activity - rhs)
        else:
            violation = max(Fraction(0), rhs - activity)
        worst = max(worst, violation)
        if violation:
            row_violations.append([row, str(activity), sense, str(rhs), str(violation)])
    objective = sum(
        parsed.columns[variable].get(parsed.objective_row, Fraction(0)) * values[variable]
        for variable in parsed.variable_order
    )
    return {
        "valid": not bound_violations and not integrality_violations and not row_violations,
        "objective_fraction": str(objective),
        "objective_decimal": float(objective),
        "bound_violations": bound_violations[:20],
        "integrality_violations": integrality_violations[:20],
        "row_violation_count": len(row_violations),
        "row_violations": row_violations[:20],
        "maximum_exact_row_violation": str(worst),
    }


def write_solution(path: Path, values: dict[str, Fraction], objective: Fraction) -> None:
    with path.open("w", encoding="ascii") as stream:
        stream.write(f"# Objective value = {float(objective):.17g}\n")
        for variable, value in values.items():
            if value:
                stream.write(f"{variable} {float(value):.17g}\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--outdir", type=Path, required=True)
    parser.add_argument("--time-limit", type=float, default=1200.0)
    parser.add_argument("--workers", type=int, default=32)
    parser.add_argument("--random-seed", type=int, default=1)
    parser.add_argument("--no-symmetry-break", action="store_true")
    parser.add_argument("--no-big-m-reification", action="store_true")
    parser.add_argument("--keep-original-big-m", action="store_true")
    parser.add_argument("--no-native-boolean-rows", action="store_true")
    parser.add_argument("--no-assignment-channeling", action="store_true")
    parser.add_argument(
        "--assignment-hint",
        type=Path,
        help="JSON produced by make_copt_lp_hint.py; hints the 60 block assignments",
    )
    parser.add_argument(
        "--fix-assignment-hint",
        action="store_true",
        help="fix, rather than merely hint, every assignment in --assignment-hint",
    )
    parser.add_argument(
        "--fix-assignment-confidence",
        type=float,
        help="fix only hinted tasks whose maximum LP assignment score reaches this threshold",
    )
    parser.add_argument(
        "--original-objective",
        action="store_true",
        help="minimize the original rational arc-cost objective while seeking feasibility",
    )
    parser.add_argument("--log-search", action="store_true")
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)

    input_sha256 = hashlib.sha256(args.model.read_bytes()).hexdigest()
    parse_started = time.time()
    parsed = parse_mps(args.model)
    rows = transpose_rows(parsed)
    structure = validate_structure(parsed, rows)
    model, cp_variables, assignment_variables, continuous_scale, translation = build_cp_model(
        parsed,
        rows,
        not args.no_symmetry_break,
        not args.no_big_m_reification,
        not args.keep_original_big_m,
        not args.no_native_boolean_rows,
        not args.no_assignment_channeling,
    )
    hinted_blocks = None
    fixed_hint_tasks = 0
    if args.assignment_hint:
        if assignment_variables is None:
            raise ValueError("assignment hints require native assignment channeling")
        hint_payload = json.loads(args.assignment_hint.read_text(encoding="utf-8"))
        hinted_blocks = hint_payload["selected_blocks"]
        assignment_scores = hint_payload.get("assignment_scores")
        if len(hinted_blocks) != 60 or any(block not in {1, 2, 3, 4} for block in hinted_blocks):
            raise ValueError("assignment hint must contain 60 block values in 1..4")
        if args.fix_assignment_confidence is not None and (
            assignment_scores is None or len(assignment_scores) != 60
        ):
            raise ValueError("confidence fixing requires 60 assignment_scores")
        for task, selected in enumerate(hinted_blocks):
            high_confidence = (
                args.fix_assignment_confidence is not None
                and max(assignment_scores[task]) >= args.fix_assignment_confidence
            )
            if args.fix_assignment_hint or high_confidence:
                fixed_hint_tasks += 1
            for block, variable in enumerate(assignment_variables[task], start=1):
                selected_value = int(block == selected)
                model.add_hint(variable, selected_value)
                if args.fix_assignment_hint or high_confidence:
                    model.add(variable == selected_value)

    objective_scale = None
    if args.original_objective:
        objective_terms: list[tuple[cp_model.IntVar, Fraction]] = []
        for variable in parsed.variable_order:
            coefficient = parsed.columns[variable].get(parsed.objective_row, Fraction(0))
            if coefficient:
                if variable not in parsed.integer_variables:
                    coefficient /= continuous_scale
                objective_terms.append((cp_variables[variable], coefficient))
        objective_scale = lcm(coefficient.denominator for _, coefficient in objective_terms)
        model.minimize(
            sum(
                scaled_integer(coefficient, objective_scale) * variable
                for variable, coefficient in objective_terms
            )
        )
    parse_seconds = time.time() - parse_started

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = args.time_limit
    solver.parameters.num_search_workers = args.workers
    solver.parameters.random_seed = args.random_seed
    solver.parameters.randomize_search = True
    solver.parameters.symmetry_level = 3
    solver.parameters.cp_model_presolve = True
    solver.parameters.linearization_level = 2
    solver.parameters.log_search_progress = args.log_search

    solve_started = time.time()
    status = solver.solve(model)
    solve_seconds = time.time() - solve_started
    status_name = solver.status_name(status)
    result: dict[str, object] = {
        "schema": "ns1905797-exact-cpsat-v1",
        "input": str(args.model),
        "input_sha256": input_sha256,
        "host": platform.node(),
        "ortools_version": getattr(__import__("ortools"), "__version__", "unknown"),
        "cpu_only": True,
        "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES", ""),
        "model": {
            "name": parsed.name,
            "variables": len(parsed.variable_order),
            "rows": len(parsed.row_order),
            "objective_row": parsed.objective_row,
            **structure,
        },
        "translation": translation,
        "parameters": {
            "time_limit": args.time_limit,
            "workers": args.workers,
            "random_seed": args.random_seed,
            "symmetry_break": not args.no_symmetry_break,
            "big_m_reification": not args.no_big_m_reification,
            "replace_proven_big_m": not args.keep_original_big_m,
            "native_boolean_rows": not args.no_native_boolean_rows,
            "native_assignment_channeling": not args.no_assignment_channeling,
            "assignment_hint": str(args.assignment_hint) if args.assignment_hint else None,
            "fix_assignment_hint": args.fix_assignment_hint,
            "fix_assignment_confidence": args.fix_assignment_confidence,
            "fixed_hint_tasks": fixed_hint_tasks,
            "hinted_blocks": hinted_blocks,
            "original_objective": args.original_objective,
            "objective_scale": objective_scale,
        },
        "parse_and_build_seconds": parse_seconds,
        "solve_wall_seconds": solve_seconds,
        "status": status_name,
        "num_conflicts": solver.num_conflicts,
        "num_branches": solver.num_branches,
        "response_stats": solver.response_stats(),
    }
    if status in {cp_model.FEASIBLE, cp_model.OPTIMAL}:
        values: dict[str, Fraction] = {}
        for variable in parsed.variable_order:
            raw_value = solver.value(cp_variables[variable])
            values[variable] = (
                Fraction(raw_value, continuous_scale)
                if variable not in parsed.integer_variables
                else Fraction(raw_value)
            )
        validation = exact_validation(parsed, rows, values)
        result["validation"] = validation
        objective = Fraction(validation["objective_fraction"])
        write_solution(args.outdir / "candidate.sol", values, objective)
    (args.outdir / "result.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print("RESULT_JSON=" + json.dumps(result, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
