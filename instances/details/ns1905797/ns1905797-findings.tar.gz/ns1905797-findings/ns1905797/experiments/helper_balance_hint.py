#!/usr/bin/env python3
"""Rebalance the LP-derived task assignment while retaining maximum LP score."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from ortools.sat.python import cp_model


def task_work_units(task: int) -> int:
    """Return five times the task's decoded work demand."""
    if task <= 10:
        return 5
    if task <= 40:
        return 1
    return 10


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", type=Path, required=True)
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--count-min", type=int, default=15)
    ap.add_argument("--count-max", type=int, default=15)
    ap.add_argument("--work-min", type=int, default=0,
                    help="minimum decoded work per block, multiplied by five")
    ap.add_argument("--work-max", type=int, default=280,
                    help="maximum decoded work per block, multiplied by five")
    ap.add_argument(
        "--class-balance",
        action="store_true",
        help="per block require 2--3 tasks from 1--10, 7--8 from 11--40, and 5 from 41--60",
    )
    args = ap.parse_args()

    source = json.loads(args.input.read_text(encoding="utf-8"))
    raw_scores = source["assignment_scores"]
    relabel = {int(raw): int(canonical) for raw, canonical in source[
        "canonical_block_relabeling"
    ].items()}
    scores = [[0.0] * 4 for _ in range(60)]
    for task in range(60):
        for raw_block in range(1, 5):
            scores[task][relabel[raw_block] - 1] = raw_scores[task][raw_block - 1]

    model = cp_model.CpModel()
    choose = [[model.new_bool_var(f"a_{task + 1}_{block + 1}") for block in range(4)]
              for task in range(60)]
    for task in range(60):
        model.add_exactly_one(choose[task])
    for block in range(4):
        count = sum(choose[task][block] for task in range(60))
        work = sum(task_work_units(task + 1) * choose[task][block] for task in range(60))
        model.add(count >= args.count_min)
        model.add(count <= args.count_max)
        model.add(work >= args.work_min)
        model.add(work <= args.work_max)
        if args.class_balance:
            early = sum(choose[task][block] for task in range(0, 10))
            middle = sum(choose[task][block] for task in range(10, 40))
            late = sum(choose[task][block] for task in range(40, 60))
            model.add(early >= 2)
            model.add(early <= 3)
            model.add(middle >= 7)
            model.add(middle <= 8)
            model.add(late == 5)
    score_scale = 1_000_000
    model.maximize(sum(
        round(scores[task][block] * score_scale) * choose[task][block]
        for task in range(60) for block in range(4)
    ))
    solver = cp_model.CpSolver()
    solver.parameters.num_search_workers = 1
    solver.parameters.random_seed = 1
    status = solver.solve(model)
    if status != cp_model.OPTIMAL:
        raise RuntimeError(f"balanced assignment status {solver.status_name(status)}")

    selected = [
        next(block + 1 for block in range(4) if solver.value(choose[task][block]))
        for task in range(60)
    ]
    counts = [selected.count(block) for block in range(1, 5)]
    work_units = [
        sum(task_work_units(task) for task, assigned in enumerate(selected, 1) if assigned == block)
        for block in range(1, 5)
    ]
    output = {
        "schema": "ns1905797-balanced-lp-assignment-hint-v1",
        "source": str(args.input),
        "source_input_sha256": source.get("input_sha256"),
        "assignment_scores": scores,
        "selected_blocks": selected,
        "counts": counts,
        "work_units_x5": work_units,
        "constraints": {
            "count_min": args.count_min,
            "count_max": args.count_max,
            "work_min_x5": args.work_min,
            "work_max_x5": args.work_max,
            "class_balance": args.class_balance,
        },
        "retained_lp_score": sum(scores[task][selected[task] - 1] for task in range(60)),
        "maximum_scaled_score": int(round(solver.objective_value)),
        "status": solver.status_name(status),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({k: output[k] for k in (
        "status", "counts", "work_units_x5", "retained_lp_score", "selected_blocks"
    )}, sort_keys=True))


if __name__ == "__main__":
    main()
