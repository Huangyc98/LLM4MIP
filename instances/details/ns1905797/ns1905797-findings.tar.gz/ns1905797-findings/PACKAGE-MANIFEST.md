# Package manifest: ns1905797

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 101
Excluded source files: 2

## Included files

- `README.md`
- `analysis/gurobi-forensics.json`
- `analysis/gurobi-structure.json`
- `analysis/helper_assignment_hint.json`
- `analysis/helper_feasible_13.98258/copt-900s-result.json`
- `analysis/helper_feasible_13.98258/copt-900s-solver.log`
- `analysis/helper_feasible_13.98258/copt-900s-strict-validation.json`
- `analysis/helper_feasible_13.98258/copt-console.log`
- `analysis/helper_feasible_13.98258/copt-incumbent-numerical.sol`
- `analysis/helper_feasible_13.98258/copt-result.json`
- `analysis/helper_feasible_13.98258/copt-solver.log`
- `analysis/helper_feasible_13.98258/exactify.json`
- `analysis/helper_feasible_13.98258/strict-audit.json`
- `analysis/helper_feasible_13.98258/strict-validation-local.json`
- `analysis/helper_feasible_13.98258/strict-validation-remote.json`
- `analysis/helper_feasible_14.62129/copt-incumbent-numerical.sol`
- `analysis/helper_feasible_14.62129/copt-result.json`
- `analysis/helper_feasible_14.62129/copt-solver.log`
- `analysis/helper_feasible_14.62129/exactify.json`
- `analysis/helper_feasible_14.62129/strict-validation-local.json`
- `analysis/helper_feasible_14.62129/strict-validation.json`
- `analysis/helper_feasible_15.03429/assignment.json`
- `analysis/helper_feasible_15.03429/strict-audit.json`
- `analysis/helper_feasible_15.03429/validation.json`
- `analysis/helper_route_logic.json`
- `analysis/route-structure.json`
- `artifacts/cycle_ledger.json`
- `artifacts/report.json`
- `artifacts/structural.json`
- `artifacts/structure.compact.json`
- `experiments/decode_route_structure.py`
- `experiments/gurobi_forensics.py`
- `experiments/gurobi_structure_probe.py`
- `experiments/helper_balance_hint.py`
- `experiments/helper_block_solver.py`
- `experiments/helper_circuit_solver.py`
- `experiments/helper_combine_blocks.py`
- `experiments/helper_construct_routes.py`
- `experiments/helper_copt_warmstart.py`
- `experiments/helper_decode_partial.py`
- `experiments/helper_exactify_solution.py`
- `experiments/helper_insertion_scan.py`
- `experiments/helper_mutate_hint.py`
- `experiments/helper_resume_jobs.sh`
- `experiments/helper_route_logic.py`
- `experiments/helper_run_block4_multiseed.sh`
- `experiments/helper_run_blocks.sh`
- `experiments/helper_validate_solution.py`
- `experiments/helper_wait_combine.sh`
- `experiments/helper_wait_transfer_combine.sh`
- `experiments/make_copt_lp_hint.py`
- `experiments/run_copt_baseline.py`
- `experiments/run_copt_parallel.sh`
- `experiments/run_cpsat_parallel.sh`
- `experiments/solve_exact_cpsat.py`
- `input/ns1905797.orig.dec`
- `input/ns1905797.presolved.dec`
- `logs/diagnostic.log`
- `logs/gurobi-structure.log`
- `logs/helper_feasible_15.03429/block-insert-b1-56-b1-exact/partial.sol`
- `logs/helper_feasible_15.03429/block-insert-b1-56-b1-exact/result.json`
- `logs/helper_feasible_15.03429/block-insert-b1-56-b1-exact/run.log`
- `logs/helper_feasible_15.03429/block-transfer4-objective-b3-exact/partial.sol`
- `logs/helper_feasible_15.03429/block-transfer4-objective-b3-exact/result.json`
- `logs/helper_feasible_15.03429/block-transfer4-objective-b3-exact/run.log`
- `logs/helper_feasible_15.03429/block-transfer6-objective-b4-exact/partial.sol`
- `logs/helper_feasible_15.03429/block-transfer6-objective-b4-exact/result.json`
- `logs/helper_feasible_15.03429/block-transfer6-objective-b4-exact/run.log`
- `logs/helper_feasible_15.03429/block-transfer6splitA-b2-b2-exact/partial.sol`
- `logs/helper_feasible_15.03429/block-transfer6splitA-b2-b2-exact/result.json`
- `logs/helper_feasible_15.03429/block-transfer6splitA-b2-b2-exact/run.log`
- `logs/helper_feasible_15.03429/combine.log`
- `logs/helper_negative_block4/block-lphint-b4-exact/result.json`
- `logs/helper_negative_block4/block-lphint-b4-exact/run.log`
- `logs/helper_negative_block4/block-lphint-b4-seed101/result.json`
- `logs/helper_negative_block4/block-lphint-b4-seed101/run.log`
- `logs/helper_negative_block4/block-lphint-b4-seed102/result.json`
- `logs/helper_negative_block4/block-lphint-b4-seed102/run.log`
- `logs/helper_negative_block4/block-lphint-b4-seed103/result.json`
- `logs/helper_negative_block4/block-lphint-b4-seed103/run.log`
- `logs/helper_negative_block4/block-lphint-b4-seed104/result.json`
- `logs/helper_negative_block4/block-lphint-b4-seed104/run.log`
- `logs/helper_negative_block4/block-lphint-b4-seed105/result.json`
- `logs/helper_negative_block4/block-lphint-b4-seed105/run.log`
- `logs/helper_negative_block4/block-lphint-b4-seed106/result.json`
- `logs/helper_negative_block4/block-lphint-b4-seed106/run.log`
- `logs/helper_negative_full_runs/copt-lphint-confidence095-resume1/console.log`
- `logs/helper_negative_full_runs/copt-lphint-confidence095-resume1/result.json`
- `logs/helper_negative_full_runs/copt-lphint-confidence095-resume1/solver.log`
- `logs/helper_negative_full_runs/copt-lphint-fixed-resume1/console.log`
- `logs/helper_negative_full_runs/copt-lphint-fixed-resume1/result.json`
- `logs/helper_negative_full_runs/copt-lphint-fixed-resume1/solver.log`
- `logs/helper_negative_full_runs/cpsat-circuit-seed31-resume1/console.log`
- `logs/helper_negative_full_runs/cpsat-circuit-seed31-resume1/result.json`
- `logs/helper_negative_full_runs/cpsat-lphint-confidence095-seed11-resume1/console.log`
- `logs/helper_negative_full_runs/cpsat-lphint-confidence095-seed11-resume1/result.json`
- `scripts/investigate_ns1905797_v2.py`
- `scripts/investigate_ns1905797_v3.py`
- `solutions/ns1905797-feasible-13.98258.sol`
- `solutions/ns1905797-feasible-14.62129.sol`
- `solutions/ns1905797-feasible-15.03429.sol`

## Excluded files

- `input/helper_ns1905800.mps.gz (212882 bytes; raw benchmark input; sha256 b913bcf704d11cfa8a2391632eb64a8f6a5f576a93c4deb8a42221b858674ac7)`
- `input/ns1905797.mps.gz (1288597 bytes; raw benchmark input; sha256 510f8d4863756bbf931592a965e00e03a705455ad1cf28994226064d6f592021)`
