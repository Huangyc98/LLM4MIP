# scpl4 背景调查

## 实例来源

[`scpl4` 的 MIPLIB 官方页面](https://miplib.zib.de/instance_details_scpl4.html)
将它列为 Shunji Umetani 提交的 `binary set_covering` 开放实例。截至
2026-09-08，页面记录 2,000 行、200,000 列、2,000,000 个非零元，公开最好
目标为 259；解 4 由 Yuya Hattori 于 2023-06-12 提交，页面说明它来自利用
变量关联的 weighted local search，并且 exact/int/constraint/objective violation
均为零。

它不是某个真实调度案例的匿名模型，而是大规模随机 SCP 基准族的 `L.4`。
官方说明称成本 `c[j]` 从 `[1,100]` 随机取整，每列至少覆盖一行，每行至少
被两列覆盖。Class L 的参数为 2,000 行、200,000 列、密度 0.5%，每类共有
五个实例。因此这里的主要困难不是业务约束，而是巨大、稠密度低且高度
对称的随机覆盖矩阵。

## 原始方法脉络

- Balas 与 Ho 的随机 SCP 生成/算法框架结合 cutting planes、prime-cover
  heuristics、LP 对偶、subgradient lower bounds 与 implicit enumeration；见
  [Springer 原始章节，DOI 10.1007/BFb0120886](https://doi.org/10.1007/BFb0120886)。
- Umetani 与 Yagiura 系统总结了 LP/Lagrangian relaxation、subgradient 与
  pricing reduction 对大规模 SCP 启发式的作用；见
  [JORSJ 原文，DOI 10.15807/jorsj.50.350](https://doi.org/10.15807/jorsj.50.350)。
- 公开 259 的描述所指向的后续方法使用变量关联限制 2-flip/4-flip 邻域；见
  [Umetani 2017，DOI 10.1016/j.ejor.2017.05.025](https://doi.org/10.1016/j.ejor.2017.05.025)。

## 对本轮方法的影响

上述背景意味着直接在 200,000 个二进制变量上盲目 branch-and-cut 并不理想。
本轮采用与文献思路相符、但每一步可独立检查的证明链：

1. 利用大量 cost-one 列给出显式集合支配替换；
2. 对精确等价小模型求 LP，对浮点对偶向下整数化；
3. 用 reduced cost 安全固定与小型 branch/dual 树排除整数目标；
4. 所有支配、对偶和树叶均由不调用优化器的检查器重新回放。

这种方法把求解器仅用于寻找候选对偶和分支方向，最终下界不依赖求解器的
浮点状态。
