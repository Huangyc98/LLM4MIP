# scpl4 — portable strict interval [214, 259]

Official MIPLIB page: <https://miplib.zib.de/instance_details_scpl4.html>

## Current result

The independently checked interval is

```text
214 <= OPT <= 259.
```

The public objective-259 solution remains the best incumbent found in this
study. Global optimality is not proved. A complete 69-node exact branch/dual
tree excludes objective at most 213, so the portable strict lower bound is
**214**. A separate terminal COPT cutoff run reaches the same lower bound and
is retained as corroborating computational evidence.

## Gurobi-first structure audit

Gurobi 13.0.1 on `euler4` read the original compressed MPS without presolve or
optimization. [`gurobi-structure.json`](analysis/gurobi-structure.json) and the
[read log](logs/gurobi-read-euler4.log) record:

- 2,000 linear rows, 200,000 `[0,1]` integer variables and 2,000,000 nonzeros;
- all rows are `>= 1`, and every matrix coefficient is exactly 1;
- row degrees range from 871 to 1,104 (mean 1,000);
- column degrees range from 1 to 26 (mean 10);
- integer costs range from 1 to 100, with 1,959 cost-one columns.

The model is therefore exactly a weighted set cover, not merely a generic MIP
that happens to contain covering rows. See [`background.md`](background.md) for
the instance family and primary literature.

## Strict upper bound

The official solution 4 contains 259 nonzero binary variables, all of cost one.
[`verify_setcover_solution.py`](scripts/verify_setcover_solution.py) reparses the
original MPS with `Decimal` arithmetic. The archived
[`public-solution-verification.json`](analysis/public-solution-verification.json)
checks all 200,000 variables and 2,000 rows and reports exact objective 259,
minimum row activity 1, and zero row, bound, integrality, or unknown-variable
violations.

## Exact reduction and lower-bound proof

1. [`dominance_reduce.py`](scripts/dominance_reduce.py) finds 185,175 columns
   whose support is covered by an explicit collection of cost-one columns at
   no greater cost. The exact-equivalent model retains 14,825 columns.
2. [`verify_dominance.py`](scripts/verify_dominance.py) replays every listed
   replacement against the original MPS and checks that
   [`scpl4-dominance-reduced.mps.gz`](analysis/scpl4-dominance-reduced.mps.gz) is
   exactly the retained-column projection. The result is
   [`dominance-verification.json`](analysis/dominance-verification.json).
3. COPT 8.0.4 found the reduced root-LP value `211.74223174201288`. The row
   dual was rounded down to denominator `10^9`, producing the feasible exact
   value `211.742231169`. [`verify_lp_dual.py`](scripts/verify_lp_dual.py)
   checks all **original** 200,000 columns with integer arithmetic; the minimum
   scaled slack is 1. This first gives `OPT >= 212`. An independent SciPy/HiGHS
   solve returned `211.74223174200822` and a separately rounded feasible dual
   `211.742231143`; see
   [`reduced-structure-lp.json`](analysis/reduced-structure-lp.json).
4. [`proof-target212.json`](analysis/proof-target212.json) is a complete
   three-node branch/dual certificate excluding every cover of cost at most
   212. Root reduced costs safely fix 13,167 columns. The two leaves carry
   integer-scaled feasible duals.
5. The standard-library-only
   [`verify_setcover_bnb.py`](scripts/verify_setcover_bnb.py) independently
   replays the root fixing, both branches and both dual leaves without calling
   any optimizer. [`replay-target212.json`](analysis/replay-target212.json)
   therefore proves `OPT >= 213`.
6. A subsequent exact run closed the target-213 tree after 69 nodes and 102
   main LP solves. [`proof-target213.json`](analysis/proof-target213.json)
   contains 68 integer-scaled feasible dual certificates; the completed tree
   has 35 dual leaves, 11,236 root reduced-cost fixings and 17,662 checked
   dynamic reduced-cost fixings. The same optimizer-free checker produced
   [`replay-target213.json`](analysis/replay-target213.json), proving that no
   cover of cost at most 213 exists and hence `OPT >= 214`.

Key artifact hashes:

| Artifact | SHA-256 |
|---|---|
| original MPS | `5ee51ae9acd1e9f23490a7aee4fb9103e95253a9d41b98097a70a1fe4aa388a8` |
| public solution 4 | `4c492adfda278158815ba74cf073df94d937da9a46d5706e72bb8f5bd9da361e` |
| compressed reduced MPS | `5d101a0824006154fb2bb153ea7ec56630ff1ab8ba47203830ebf995c9f738f9` |
| domination certificate | `3be54b356c251a6728df065e99e30e430f33ab585002c1d3a64551f9eff203d8` |
| target-212 proof | `b5bfc98d220e76066230eecf179e2a826b2de1dbb6c9c8d73f85079aa9d6ec7c` |
| incomplete target-213 tree | `7d4e4e793d2ae78d5492c57bd1201eebda5b5e2cdaa0aa3e49ac8498c0db6239` |
| complete target-213 proof | `7e3a7b4463a2a8931a817d7819145358f8695c2f158e1ed907419a9619acdcda` |
| target-213 independent replay | `c1c7e50a8fe024a9ad061d38b8ac90c2bb19f06cbe8d3557faf4faf19e99ee88` |

## Solver experiments and evidence boundary

The first target-213 exact run reached its finite limit without closing the
tree. [`proof-target213-incomplete.json`](analysis/proof-target213-incomplete.json)
archives 17 processed nodes, 18 open nodes, 33 main LP solves and 272 strong-
branch LP solves after 1842.67 seconds, and remains explicitly non-evidence.
The lower-strong-branching follow-up then finished in 972.37 seconds: all open
nodes were discharged, and its complete proof passed the independent replay
above. The run log and frozen hashes are in
[`proof-target213.log`](logs/proof-target213.log) and
[`exact-target213-12h-archive.json`](analysis/exact-target213-12h-archive.json).

Three COPT 8.0.4 runs on `altman` had finished:

| Run | Time / nodes | Incumbent | Numerical bound | Outcome |
|---|---:|---:|---:|---|
| default reduced MIP | 1200.07 s / 3,710 | 259 | 213.488241212 | time limit |
| aggressive heuristics, `GPUMode=0` | 600.16 s / 127 | 259 | 213.077069255 | time limit |
| objective `<=213` feasibility cutoff | 770.88 s / 4,566 | none | n/a | terminal `INFEASIBLE` |

Both COPT solution files are identical and pass the original-MPS exact checker
at objective 259. The first two floating-point bounds do not alter the portable
strict interval. The third run retains the verified 14,825-column reduction,
adds only the original objective cutoff `<=213`, and replaces the solve
objective by zero. Its terminal status independently corroborates `OPT >= 214`.
The [run summary, complete logs](logs/copt-exclude213-3600/) and
[hash/provenance record](analysis/copt-exclude213-3600-archive.json) are
archived. Unlike the exact tree, this COPT run did not emit a portable proof
trace, so it is not needed for the strict lower-bound claim.

Gurobi optimization of the reduced model was not available to OS user
`yicheng`: the accessible Python environment had only a size-limited license,
while the named license for `wyc` rejected the user mismatch. This launch
failure is not evidence about the mathematical instance. It does not affect the
successful Gurobi 13 read-only structure audit.

## Reproduction

From the repository root, the decisive checks need only Python 3:

```sh
python instances/scpl4/scripts/verify_setcover_solution.py \
  instances/scpl4/input/scpl4.mps.gz \
  instances/scpl4/solutions/scpl4-public-4.sol.gz \
  --output public-solution-verification.json

python instances/scpl4/scripts/verify_dominance.py \
  instances/scpl4/input/scpl4.mps.gz \
  instances/scpl4/analysis/dominance-certificate.json.gz \
  instances/scpl4/analysis/scpl4-dominance-reduced.mps.gz \
  --output dominance-verification.json

python instances/scpl4/scripts/verify_lp_dual.py \
  instances/scpl4/input/scpl4.mps.gz \
  instances/scpl4/analysis/copt-root-dual.json \
  --output copt-root-dual-verification.json

python instances/scpl4/scripts/verify_setcover_bnb.py \
  instances/scpl4/analysis/scpl4-dominance-reduced.mps.gz \
  instances/scpl4/analysis/copt-root-dual.json \
  instances/scpl4/analysis/proof-target213.json \
  --output replay-target213.json
```

The terminal COPT cutoff can be rerun in an environment with COPT 8 as:

```sh
python instances/scpl4/scripts/run_copt_reduced.py \
  --model instances/scpl4/analysis/scpl4-dominance-reduced.mps.gz \
  --start instances/scpl4/solutions/scpl4-public-reduced.sol \
  --outdir runs/scpl4-copt-exclude213 \
  --mode exclude --target 213 --time-limit 3600 --threads 16
```

This command produces commercial-solver computational evidence, not the
optimizer-independent proof object produced by the exact tree generator and
checked by `verify_setcover_bnb.py`.

The proof generator entry point
[`exact_setcover_bnb.py`](scripts/exact_setcover_bnb.py) reuses the generic
SciPy implementation archived under `instances/scpk4/scripts`; its output is
not trusted until the optimizer-free checker above succeeds.
