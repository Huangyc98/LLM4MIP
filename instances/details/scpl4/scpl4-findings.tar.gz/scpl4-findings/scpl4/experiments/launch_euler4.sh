#!/usr/bin/env bash
set -euo pipefail

root=${1:-/home/yicheng/miplib-scpl4-20260908}
python_bin=${2:-/home/wyc/miniconda3/envs/milp-ps/bin/python}
cd "$root"
export GRB_LICENSE_FILE=${GRB_LICENSE_FILE:-/home/wyc/gurobi1301/gurobi.lic}

launch() {
    local name=$1
    shift
    if [[ -s "output/${name}.pid" ]] && kill -0 "$(<"output/${name}.pid")" 2>/dev/null; then
        echo "$name already running as $(<"output/${name}.pid")"
        return
    fi
    if [[ -s "output/${name}.json" ]]; then
        echo "$name already has a result"
        return
    fi
    nohup "$python_bin" scripts/run_gurobi_reduced.py \
        output/scpl4-dominance-reduced.mps "$@" \
        --log "output/${name}.log" \
        --summary "output/${name}.json" \
        --solution "output/${name}.sol" \
        > "output/${name}.stdout.log" 2>&1 < /dev/null &
    echo $! > "output/${name}.pid"
    echo "launched $name as $!"
}

# A proof-focused solve keeps the public 259 start and maximizes dual progress.
launch gurobi-proof-900s \
    --start output/scpl4-public-reduced.sol \
    --mode optimize --time-limit 900 --threads 16 --seed 1 \
    --mip-focus 3 --heuristics 0.02

# A materially different primal-focused run tests whether 259 can be improved.
launch gurobi-primal-600s \
    --start output/scpl4-public-reduced.sol \
    --mode optimize --time-limit 600 --threads 16 --seed 7 \
    --mip-focus 1 --heuristics 0.20 --no-rel-heur-time 120
