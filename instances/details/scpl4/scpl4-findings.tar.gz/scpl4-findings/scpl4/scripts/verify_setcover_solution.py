#!/usr/bin/env python3
"""Independently verify a scpl4 solution against the original compressed MPS."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
from collections import defaultdict
from decimal import Decimal, getcontext
from pathlib import Path

getcontext().prec = 80


def open_text(path: Path):
    if path.suffix == ".gz":
        return gzip.open(path, "rt", encoding="latin-1")
    return path.open("rt", encoding="latin-1")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def read_solution(path: Path) -> tuple[Decimal | None, dict[str, Decimal]]:
    declared = None
    values: dict[str, Decimal] = {}
    with open_text(path) as stream:
        for raw in stream:
            tokens = raw.split()
            if len(tokens) < 2 or tokens[0].startswith("#"):
                continue
            if tokens[0] == "=obj=":
                declared = Decimal(tokens[-1])
            else:
                values[tokens[0]] = Decimal(tokens[1])
    return declared, values


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    declared, values = read_solution(args.solution)
    section = ""
    objective_row = None
    senses: dict[str, str] = {}
    rhs: defaultdict[str, Decimal] = defaultdict(Decimal)
    costs: defaultdict[str, Decimal] = defaultdict(Decimal)
    coverage: defaultdict[str, Decimal] = defaultdict(Decimal)
    variables: set[str] = set()
    integer_variables: set[str] = set()
    bound_records: list[list[str]] = []
    integer_mode = False

    with open_text(args.mps) as stream:
        for raw in stream:
            tokens = raw.split()
            if not tokens or tokens[0].startswith("*"):
                continue
            if not raw[0].isspace() and tokens[0] in {
                "NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"
            }:
                section = tokens[0]
                continue
            if section == "ROWS":
                sense, name = tokens[:2]
                if sense == "N":
                    objective_row = name
                else:
                    senses[name] = sense
            elif section == "COLUMNS":
                if "'MARKER'" in tokens:
                    integer_mode = "'INTORG'" in tokens
                    continue
                variable = tokens[0]
                variables.add(variable)
                if integer_mode:
                    integer_variables.add(variable)
                value = values.get(variable, Decimal(0))
                for row, coefficient_text in zip(tokens[1::2], tokens[2::2]):
                    coefficient = Decimal(coefficient_text)
                    if row == objective_row:
                        costs[variable] += coefficient
                    else:
                        coverage[row] += coefficient * value
            elif section == "RHS":
                for row, value in zip(tokens[1::2], tokens[2::2]):
                    rhs[row] += Decimal(value)
            elif section == "BOUNDS":
                bound_records.append(tokens)

    lower = {variable: Decimal(0) for variable in variables}
    upper: dict[str, Decimal | None] = {variable: None for variable in variables}
    for tokens in bound_records:
        kind, variable = tokens[0], tokens[2]
        value = Decimal(tokens[3]) if len(tokens) > 3 else Decimal(0)
        if kind == "LO":
            lower[variable] = value
        elif kind == "UP":
            upper[variable] = value
        elif kind == "FX":
            lower[variable] = upper[variable] = value
        elif kind == "FR":
            lower[variable], upper[variable] = Decimal("-Infinity"), None
        elif kind == "MI":
            lower[variable] = Decimal("-Infinity")
        elif kind == "PL":
            upper[variable] = None
        elif kind == "BV":
            lower[variable], upper[variable] = Decimal(0), Decimal(1)
            integer_variables.add(variable)
        elif kind == "LI":
            lower[variable] = value
            integer_variables.add(variable)
        elif kind == "UI":
            upper[variable] = value
            integer_variables.add(variable)
        else:
            raise ValueError(f"unsupported MPS bound type {kind}")

    objective = sum(costs[v] * values.get(v, Decimal(0)) for v in variables)
    selected = sorted(v for v in variables if values.get(v, Decimal(0)) != 0)
    row_violations = []
    for row, sense in senses.items():
        activity = coverage[row]
        target = rhs[row]
        violated = (
            (sense == "G" and activity < target)
            or (sense == "L" and activity > target)
            or (sense == "E" and activity != target)
        )
        if violated:
            row_violations.append({"row": row, "sense": sense, "activity": str(activity), "rhs": str(target)})

    bound_violations = [
        variable for variable in variables
        if values.get(variable, Decimal(0)) < lower[variable]
        or (upper[variable] is not None and values.get(variable, Decimal(0)) > upper[variable])
    ]
    integrality_violations = [v for v in integer_variables if values.get(v, Decimal(0)) != values.get(v, Decimal(0)).to_integral_value()]
    unknown_variables = sorted(set(values) - variables)
    coverages = [coverage[row] for row in senses]
    report = {
        "verified": not row_violations and not bound_violations and not integrality_violations and not unknown_variables,
        "mps_sha256": sha256(args.mps),
        "solution_sha256": sha256(args.solution),
        "declared_objective": str(declared) if declared is not None else None,
        "computed_objective_exact_decimal": str(objective),
        "variables": len(variables),
        "integer_variables": len(integer_variables),
        "variables_with_finite_upper_bound": sum(value is not None for value in upper.values()),
        "rows": len(senses),
        "selected_nonzero_variables": len(selected),
        "minimum_row_activity": str(min(coverages)),
        "maximum_row_activity": str(max(coverages)),
        "row_violations": len(row_violations),
        "bound_violations": len(bound_violations),
        "integrality_violations": len(integrality_violations),
        "unknown_solution_variables": len(unknown_variables),
        "first_row_violations": row_violations[:20],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0 if report["verified"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
