#!/usr/bin/env python3
"""Solve the scpl4 LP with COPT and export an integer-scaled feasible dual."""

from __future__ import annotations

import argparse
import json
import math
import platform
from pathlib import Path

from coptpy import COPT, Envr

from setcover_io import parse_mps


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model", type=Path)
    parser.add_argument("--denominator", type=int, default=1_000_000_000)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    senses, rhs, cost_values, columns_by_name = parse_mps(args.model)
    assert all(sense == "G" and rhs[row] == 1 for row, sense in senses.items())
    rows = list(senses)
    row_index = {row: index for index, row in enumerate(rows)}
    names = list(columns_by_name)
    costs = [int(cost_values[name]) for name in names]
    column_rows = [tuple(row_index[row] for row in columns_by_name[name]) for name in names]

    environment = Envr()
    model = environment.createModel("scpl4_lp")
    model.setParam(COPT.Param.Logging, 0)
    model.readMps(str(args.model))
    model.solveLP()
    status = int(model.getAttr(COPT.Attr.LpStatus))
    objective = float(model.getAttr(COPT.Attr.LpObjVal))
    constraints = model.getConstrs()
    dual_values = list(map(float, model.getDuals()))
    dual_by_name = {constraint.getName(): dual_values[i] for i, constraint in enumerate(constraints)}
    raw = [max(0.0, dual_by_name[row]) for row in rows]

    denominator = args.denominator
    numerators = [max(0, math.floor(value * denominator - 1e-4)) for value in raw]
    repair_rounds = 0
    total_uniform_repair = 0
    while True:
        worst_excess = 0
        repair = 0
        for column, covered in enumerate(column_rows):
            positive = [row for row in covered if numerators[row] > 0]
            excess = sum(numerators[row] for row in positive) - costs[column] * denominator
            worst_excess = max(worst_excess, excess)
            if excess > 0:
                repair = max(repair, (excess + len(positive) - 1) // len(positive))
        if worst_excess <= 0:
            break
        assert repair > 0
        numerators = [max(0, value - repair) for value in numerators]
        repair_rounds += 1
        total_uniform_repair += repair

    exact_loads = [sum(numerators[row] for row in covered) for covered in column_rows]
    bound_numerator = sum(numerators)
    integer_lower_bound = (bound_numerator + denominator - 1) // denominator
    report = {
        "instance": "scpl4",
        "host": platform.node(),
        "solver": "COPT 8.0.4 LP",
        "source_model": str(args.model),
        "rows": len(rows),
        "columns": len(names),
        "lp_relaxation": {
            "status": status,
            "objective": objective,
            "negative_duals_clipped": sum(value < 0 for value in dual_by_name.values()),
            "exact_dual_certificate": {
                "denominator": denominator,
                "row_numerators": dict(zip(rows, numerators)),
                "bound_numerator": bound_numerator,
                "bound_decimal": f"{bound_numerator // denominator}.{bound_numerator % denominator:09d}",
                "integer_objective_lower_bound": integer_lower_bound,
                "maximum_integer_slack_violation": max(
                    exact_loads[column] - costs[column] * denominator for column in range(len(names))
                ),
                "repair_rounds": repair_rounds,
                "total_uniform_repair_per_row": total_uniform_repair,
            },
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "lp_status": status,
        "lp_objective": objective,
        "exact_bound": report["lp_relaxation"]["exact_dual_certificate"]["bound_decimal"],
        "integer_lower_bound": integer_lower_bound,
        "maximum_integer_slack_violation": report["lp_relaxation"]["exact_dual_certificate"]["maximum_integer_slack_violation"],
        "repair_rounds": repair_rounds,
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
