#!/usr/bin/env python3
"""Invoke the repository's shared exact set-cover branch/dual proof generator."""

from __future__ import annotations

import runpy
import sys
from pathlib import Path

shared = Path(__file__).resolve().parents[2] / "scpk4" / "scripts"
sys.path.insert(0, str(shared))
runpy.run_path(str(shared / "exact_setcover_bnb.py"), run_name="__main__")
