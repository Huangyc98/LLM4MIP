#!/usr/bin/env python3
"""Read the original scpl4 MPS with Gurobi without optimizing it."""

from __future__ import annotations

import argparse
import collections
import hashlib
import json
import math
import platform
import sys
from pathlib import Path

import gurobipy as gp


def quantiles(values: list[int]) -> dict[str, float | int]:
    ordered = sorted(values)
    if not ordered:
        return {}
    n = len(ordered)
    return {
        "min": ordered[0],
        "q25": ordered[(n - 1) // 4],
        "median": ordered[(n - 1) // 2],
        "q75": ordered[(3 * (n - 1)) // 4],
        "max": ordered[-1],
        "mean": sum(ordered) / n,
    }


def finite(value: float):
    if math.isinf(value):
        return "+inf" if value > 0 else "-inf"
    return value


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    model = gp.read(str(args.mps))
    model.update()
    variables = model.getVars()
    constraints = model.getConstrs()
    # Avoid a SciPy dependency: traverse Gurobi's sparse row objects directly.
    # This also makes the audit runnable in the minimal licensed environment on
    # euler4.  The loop is read-only and does not invoke presolve or optimize.
    row_nnz: list[int] = []
    column_nnz = [0] * len(variables)
    coefficient_counter: collections.Counter[str] = collections.Counter()
    for constraint in constraints:
        row = model.getRow(constraint)
        row_nnz.append(row.size())
        for offset in range(row.size()):
            column_nnz[row.getVar(offset).index] += 1
            coefficient_counter[str(float(row.getCoeff(offset)))] += 1
    objective = [variable.Obj for variable in variables]
    lower = [variable.LB for variable in variables]
    upper = [variable.UB for variable in variables]

    report = {
        "audit_kind": "gurobi_read_only_original_mps",
        "optimize_called": False,
        "source": str(args.mps),
        "source_sha256": hashlib.sha256(args.mps.read_bytes()).hexdigest(),
        "host": platform.node(),
        "python": sys.version,
        "gurobi_version": ".".join(map(str, gp.gurobi.version())),
        "model_name": model.ModelName,
        "objective_sense": "min" if model.ModelSense == gp.GRB.MINIMIZE else "max",
        "dimensions": {
            "variables": model.NumVars,
            "linear_constraints": model.NumConstrs,
            "quadratic_constraints": model.NumQConstrs,
            "sos": model.NumSOS,
            "general_constraints": model.NumGenConstrs,
            "nonzeros": model.NumNZs,
        },
        "variable_types": dict(sorted(collections.Counter(v.VType for v in variables).items())),
        "constraint_senses": dict(sorted(collections.Counter(c.Sense for c in constraints).items())),
        "objective": {
            "nonzero_count": sum(value != 0 for value in objective),
            "min_coefficient": min(objective),
            "max_coefficient": max(objective),
            "constant": model.ObjCon,
        },
        "bounds": {
            "fixed": sum(lb == ub for lb, ub in zip(lower, upper)),
            "finite_lower": sum(lb > -gp.GRB.INFINITY for lb in lower),
            "finite_upper": sum(ub < gp.GRB.INFINITY for ub in upper),
            "lower_min": finite(min(lower)),
            "lower_max": finite(max(lower)),
            "upper_min": finite(min(upper)),
            "upper_max": finite(max(upper)),
        },
        "row_nnz": quantiles(row_nnz),
        "column_nnz": quantiles(column_nnz),
        "coefficient_values": coefficient_counter.most_common(),
        "objective_values": collections.Counter(str(float(x)) for x in objective).most_common(),
        "rhs_values": collections.Counter(str(float(c.RHS)) for c in constraints).most_common(),
        "first_variables": [
            {"name": v.VarName, "type": v.VType, "lb": finite(v.LB), "ub": finite(v.UB), "obj": v.Obj}
            for v in variables[:20]
        ],
        "first_constraints": [
            {"name": c.ConstrName, "sense": c.Sense, "rhs": c.RHS, "nnz": row_nnz[i]}
            for i, c in enumerate(constraints[:20])
        ],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
