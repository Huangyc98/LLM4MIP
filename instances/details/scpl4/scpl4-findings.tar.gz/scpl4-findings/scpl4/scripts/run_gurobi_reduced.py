#!/usr/bin/env python3
"""Run documented Gurobi experiments on the certified scpl4 reduction."""

from __future__ import annotations

import argparse
import json
import platform
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


STATUS = {
    GRB.OPTIMAL: "OPTIMAL",
    GRB.INFEASIBLE: "INFEASIBLE",
    GRB.TIME_LIMIT: "TIME_LIMIT",
    GRB.INTERRUPTED: "INTERRUPTED",
    GRB.NODE_LIMIT: "NODE_LIMIT",
}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model", type=Path)
    parser.add_argument("--start", type=Path)
    parser.add_argument("--mode", choices=("optimize", "exclude"), default="optimize")
    parser.add_argument("--target", type=float, default=258.0)
    parser.add_argument("--time-limit", type=float, default=900.0)
    parser.add_argument("--threads", type=int, default=16)
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument("--mip-focus", type=int, default=3)
    parser.add_argument("--heuristics", type=float, default=0.05)
    parser.add_argument("--no-rel-heur-time", type=float, default=0.0)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--solution", type=Path)
    args = parser.parse_args()

    args.log.parent.mkdir(parents=True, exist_ok=True)
    model = gp.read(str(args.model))
    if args.start and args.mode == "optimize":
        model.read(str(args.start))
    original_objective = gp.LinExpr(model.getObjective())
    if args.mode == "exclude":
        model.addConstr(original_objective <= args.target, name="EXCLUDE_BUDGET")
        model.setObjective(0.0, GRB.MINIMIZE)

    model.Params.LogFile = str(args.log)
    model.Params.TimeLimit = args.time_limit
    model.Params.Threads = args.threads
    model.Params.Seed = args.seed
    model.Params.MIPFocus = args.mip_focus
    model.Params.Cuts = 3
    model.Params.Presolve = 2
    model.Params.Heuristics = args.heuristics
    model.Params.NoRelHeurTime = args.no_rel_heur_time
    model.Params.IntegralityFocus = 1
    model.optimize()

    objective = None
    if model.SolCount:
        objective = sum(variable.Obj * variable.X for variable in model.getVars())
        if args.mode == "exclude":
            objective = original_objective.getValue()

    report = {
        "instance": "scpl4",
        "host": platform.node(),
        "model": str(args.model),
        "gurobi_version": ".".join(map(str, gp.gurobi.version())),
        "mode": args.mode,
        "excluded_target": args.target if args.mode == "exclude" else None,
        "parameters": {
            "time_limit": args.time_limit,
            "threads": args.threads,
            "seed": args.seed,
            "mip_focus": args.mip_focus,
            "cuts": 3,
            "presolve": 2,
            "heuristics": args.heuristics,
            "no_rel_heur_time": args.no_rel_heur_time,
            "integrality_focus": 1,
        },
        "status": int(model.Status),
        "status_name": STATUS.get(model.Status, str(model.Status)),
        "runtime_seconds": model.Runtime,
        "work": model.Work,
        "node_count": model.NodeCount,
        "solution_count": model.SolCount,
        "objective_original": objective,
        "best_bound": model.ObjBound if args.mode == "optimize" else None,
        "relative_gap": model.MIPGap if args.mode == "optimize" and model.SolCount else None,
        "strict_claim": (
            "solver_terminal_infeasibility_for_original_objective_at_most_target"
            if args.mode == "exclude" and model.Status == GRB.INFEASIBLE
            else None
        ),
    }
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    if args.solution and model.SolCount:
        args.solution.parent.mkdir(parents=True, exist_ok=True)
        model.write(str(args.solution))
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
