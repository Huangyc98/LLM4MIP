#!/usr/bin/env python3
"""Verify an integer-scaled scpl4 LP dual against every original MPS column."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from setcover_io import parse_mps


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model", type=Path)
    parser.add_argument("certificate", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    senses, rhs, costs, columns = parse_mps(args.model)
    payload = json.loads(args.certificate.read_text(encoding="utf-8"))
    certificate = payload["lp_relaxation"]["exact_dual_certificate"]
    denominator = int(certificate["denominator"])
    y = {row: int(value) for row, value in certificate["row_numerators"].items()}
    assert set(y) == set(senses)
    assert all(value >= 0 for value in y.values())
    assert all(sense == "G" and rhs[row] == 1 for row, sense in senses.items())
    violations = []
    maximum_excess = None
    minimum_slack = None
    for variable, support in columns.items():
        load = sum(y[row] * coefficient for row, coefficient in support.items())
        capacity = costs[variable] * denominator
        slack = capacity - load
        minimum_slack = slack if minimum_slack is None else min(minimum_slack, slack)
        maximum_excess = -slack if maximum_excess is None else max(maximum_excess, -slack)
        if slack < 0:
            violations.append({"variable": variable, "load": str(load), "capacity": str(capacity)})

    bound_numerator = sum(y[row] * rhs[row] for row in senses)
    assert bound_numerator == int(certificate["bound_numerator"])
    bound_integer = int(bound_numerator)
    integer_lower_bound = (bound_integer + denominator - 1) // denominator
    report = {
        "verified": not violations,
        "model_sha256": hashlib.sha256(args.model.read_bytes()).hexdigest(),
        "original_rows_checked": len(senses),
        "original_columns_checked": len(columns),
        "dual_nonnegative": True,
        "dual_feasibility_violations": len(violations),
        "maximum_scaled_excess": str(maximum_excess),
        "minimum_scaled_slack": str(minimum_slack),
        "bound_numerator": str(bound_integer),
        "denominator": denominator,
        "bound_decimal": f"{bound_integer // denominator}.{bound_integer % denominator:09d}",
        "strict_integer_lower_bound": int(integer_lower_bound),
        "first_violations": violations[:20],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0 if report["verified"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
