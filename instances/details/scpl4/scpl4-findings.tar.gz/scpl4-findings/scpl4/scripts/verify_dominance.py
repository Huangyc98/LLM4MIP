#!/usr/bin/env python3
"""Replay every scpl4 domination replacement and compare the reduced MPS."""

from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path

from setcover_io import parse_mps


def read_json(path: Path):
    if path.suffix == ".gz":
        with gzip.open(path, "rt", encoding="utf-8") as stream:
            return json.load(stream)
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model", type=Path)
    parser.add_argument("certificate", type=Path)
    parser.add_argument("reduced_model", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    senses, rhs, costs, columns = parse_mps(args.model)
    reduced_senses, reduced_rhs, reduced_costs, reduced_columns = parse_mps(args.reduced_model)
    certificate = read_json(args.certificate)
    dominated = certificate["dominated"]
    assert all(sense == "G" and rhs[row] == 1 for row, sense in senses.items())

    for target, replacements in dominated.items():
        assert target in columns and replacements and len(replacements) == len(set(replacements))
        assert all(variable in columns for variable in replacements)
        replacement_cost = sum(costs[variable] for variable in replacements)
        replacement_cover = set().union(*(set(columns[variable]) for variable in replacements))
        assert replacement_cost <= costs[target]
        assert set(columns[target]) <= replacement_cover

    expected_retained = [variable for variable in columns if variable not in dominated]
    assert certificate["original_columns"] == len(columns)
    assert certificate["retained_columns"] == len(expected_retained)
    assert certificate["dominated_columns"] == len(dominated)
    assert reduced_senses == senses and reduced_rhs == rhs
    assert list(reduced_columns) == expected_retained
    for variable in expected_retained:
        assert reduced_costs[variable] == costs[variable]
        assert reduced_columns[variable] == columns[variable]

    report = {
        "verified": True,
        "original_columns": len(columns),
        "dominated_columns": len(dominated),
        "retained_columns": len(expected_retained),
        "all_replacements_cover_target_at_no_greater_cost": True,
        "reduced_model_matches_retained_original_columns": True,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
