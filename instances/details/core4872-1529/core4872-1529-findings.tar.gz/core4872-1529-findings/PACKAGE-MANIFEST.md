# Package manifest: core4872-1529

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 16
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/dual-certificate.json`
- `artifacts/packing-independent-audit.json`
- `artifacts/pb-v3-result.json`
- `artifacts/public-id3.audit.json`
- `logs/effort_ledger.json`
- `logs/run-summary.md`
- `reports/final_report.md`
- `scripts/core4872_dual.py`
- `scripts/core4872_pb_v3.py`
- `scripts/recover_structure.py`
- `scripts/verify_packing_certificate.py`
- `solutions/public-id3.sol.gz`
- `sources/background.md`
- `structure/compact_structure.json`
- `structure/gurobi_structure.json`

## Excluded files

- `input/core4872-1529.mps.gz (989054 bytes; raw benchmark input; sha256 20db8aa3bf0cc9619df3f08b5fcbb5ea51dfa25f3f2adad2ef2e5bcdd29f9c68)`
