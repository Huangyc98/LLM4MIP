# Background notes: core4872-1529

Retrieved 2026-09-09.

- Official MIPLIB page:
  https://miplib.zib.de/instance_details_core4872-1529.html
- Official MPS:
  https://miplib.zib.de/WebData/instances/core4872-1529.mps.gz
- MIPLIB status: open; displayed incumbent 1530; 24,656 variables, 4,875
  rows, 218,762 nonzeros. MIPLIB labels the formulation binary set covering
  with variable-bound and invariant-knapsack rows.
- Submitters: A. Caprara, M. Fischetti, P. Toth. Application: set covering from
  Italian railway models; imported from MIPLIB 2010.
- Reference: Caprara, Fischetti, Toth, “A heuristic method for the set covering
  problem,” Operations Research 47 (1999), 730-743,
  https://doi.org/10.1287/opre.47.5.730. The publisher abstract says the
  railway set-cover method combines dynamic pricing, subgradient optimization,
  greedy construction, systematic column fixing, and solution refinement.
- The MIPLIB page records objective 1530 as a strict integral feasible solution
  obtained with Gurobi 9.0's solution-improvement heuristic in 2020. The
  official ID 3 solution has been downloaded and independently evaluated on
  the untouched MPS: objective 1530, max bound/integrality/row violation 0.
- A PB competition result page confirms that a normalized OPB form of this MIP
  has circulated as a PB optimization benchmark:
  https://www.cril.univ-artois.fr/PB25/results/solverolines.php?idev=115&idsolver=3326
- A MIPLIB-2010 symmetry study reports that only about 2% of variables are in
  nontrivial permutation orbits, so global symmetry is not the main source of
  hardness.

## Read-only structural recovery

Gurobi 13.0.2 was used only to parse the original MPS; no optimization or
presolve was called.

- 24,645 integral variables with bounds [0,1]; costs are 6,781 columns of cost
  1 and 17,864 columns of cost 2.
- 11 nonnegative continuous variables have positive objective coefficients but
  occur only in a redundant objective upper-bound row, hence every optimum sets
  them to zero.
- 4,872 rows are pure unit-coefficient cover inequalities `sum x_j >= 1`.
- The remaining rows are:
  - `UB`: the objective expression <= 1e10, redundant;
  - `INERZIA`: sum of 1,022 nonnegative binaries >= -1022, redundant;
  - `R7002`: sum of the 17,864 cost-2 columns <= 9256, automatically implied
    by any objective cutoff <=1529.
- Therefore deciding whether the original objective can be <=1529 is exactly a
  4,872-row weighted set-cover PB feasibility problem with 24,645 binary
  columns and weights 1 or 2.
- There are 209 groups (419 variables) with identical full row-incidence
  signatures before cost-aware dominance filtering.

Files `structure/gurobi_structure.json` and
`structure/recovered_structure.json` preserve the complete audit.
