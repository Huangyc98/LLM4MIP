# `core4872-1529`

## Result

Status: **open**.

The public solution of objective **1,530** passes a complete audit of the
untouched MPS. A solver-independent packing certificate proves the valid lower
bound **932**, giving

```text
932 <= OPT <= 1530.
```

The bound 932 is a locally checkable bound from this study; it is not claimed
as an improvement over every published solver bound. The cutoff decision at
1,529 remains unresolved.

[MIPLIB instance page](https://miplib.zib.de/instance_details_core4872-1529.html)

## Structure and methods

Read-only Gurobi parsing recovered a weighted railway set-cover core: 24,645
binary columns, 4,872 unit covering rows, and costs one or two. No Gurobi
optimization or general-purpose MIP optimization was used.

An audited PB reduction forced 53 columns of total cost 82 and left 4,691
cover rows, 24,365 columns, and a residual cardinality budget of 1,447.
MiniCard returned `UNKNOWN` after 899.30 seconds, with no witness or proof.

The accepted certificate instead selects 692 covering rows whose complete
column supports are pairwise disjoint. Summing the cheapest column cost for
each selected row gives 932. The independent verifier reparses the original
MPS, calls no optimizer, and checks row identity, support disjointness,
nonnegative costs and bounds, and the exact sum.

## Evidence

- [`artifacts/packing-independent-audit.json`](artifacts/packing-independent-audit.json)
  is the independent replay of the lower-bound certificate.
- [`artifacts/dual-certificate.json`](artifacts/dual-certificate.json) retains
  the generated certificate data.
- [`artifacts/public-id3.audit.json`](artifacts/public-id3.audit.json) and
  [`solutions/public-id3.sol.gz`](solutions/public-id3.sol.gz) establish the
  upper bound.
- [`artifacts/pb-v3-result.json`](artifacts/pb-v3-result.json) records the PB
  run as `UNKNOWN`; it is not an infeasibility certificate.
- [`reports/final_report.md`](reports/final_report.md) and
  [`logs/run-summary.md`](logs/run-summary.md) document the full investigation.

The 5 MB regenerable recovered-incidence dump and raw API material are omitted;
[`scripts/recover_structure.py`](scripts/recover_structure.py) reconstructs
the former.

SHA-256:

- MPS: `20DB8AA3BF0CC9619DF3F08B5FCBB5EA51DFA25F3F2ADAD2EF2E5BCDD29F9C68`
- public solution: `B8E447686CA686AE8B6DAF0F60817DA4ECF38874E6EF332C7907D2FFA9D6F904`
