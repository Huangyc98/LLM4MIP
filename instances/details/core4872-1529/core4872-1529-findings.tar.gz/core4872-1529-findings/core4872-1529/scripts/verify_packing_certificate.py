#!/usr/bin/env python3
"""Independently audit the disjoint-row packing certificate on the original MPS.

This verifier deliberately does not import the code that generated the
certificate and never calls optimize().  A selected covering row contributes
the cheapest objective coefficient among its variables.  If all selected row
supports are pairwise disjoint and every objective coefficient is
nonnegative, summing those minima is a globally valid lower bound.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone

import gurobipy as gp


TOL = 1e-9


def sha256(path: str) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        while block := stream.read(1 << 20):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", required=True)
    parser.add_argument("--certificate", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    with open(args.certificate, encoding="utf-8") as stream:
        source_certificate = json.load(stream)
    packing = source_certificate["packing_certificate"]
    selected_names = list(packing["selected_row_names"])
    selected_ids = list(packing["selected_row_ids"])

    model = gp.read(args.mps)
    variables = model.getVars()
    constraints = model.getConstrs()

    # Reconstruct the full list/order of pure unit covering rows without using
    # the generator's MPS parser.
    cover_names = []
    row_by_name = {}
    for row_constraint in constraints:
        row = model.getRow(row_constraint)
        values = [row.getCoeff(k) for k in range(row.size())]
        if (
            row_constraint.Sense == ">"
            and abs(row_constraint.RHS - 1.0) <= TOL
            and values
            and all(abs(value - 1.0) <= TOL for value in values)
        ):
            cover_names.append(row_constraint.ConstrName)
            row_by_name[row_constraint.ConstrName] = row_constraint

    errors = []
    if len(selected_names) != len(selected_ids):
        errors.append("selected row name/id arrays have different lengths")
    if len(selected_names) != len(set(selected_names)):
        errors.append("selected row names are not unique")
    for row_id, row_name in zip(selected_ids, selected_names):
        if not isinstance(row_id, int) or not 0 <= row_id < len(cover_names):
            errors.append(f"invalid row id {row_id!r} for {row_name}")
        elif cover_names[row_id] != row_name:
            errors.append(
                f"row order mismatch at id {row_id}: "
                f"certificate={row_name}, independent={cover_names[row_id]}"
            )

    negative_objective_columns = [
        variable.VarName for variable in variables if variable.Obj < -TOL
    ]
    if negative_objective_columns:
        errors.append("the original model has negative objective coefficients")
    negative_lower_bound_columns = [
        variable.VarName for variable in variables if variable.LB < -TOL
    ]
    if negative_lower_bound_columns:
        errors.append("the original model has variables with negative lower bounds")

    owner = {}
    overlaps = []
    selected_details = []
    computed_bound = 0.0
    for row_name in selected_names:
        row_constraint = row_by_name.get(row_name)
        if row_constraint is None:
            errors.append(f"selected row is not a pure unit covering row: {row_name}")
            continue
        row = model.getRow(row_constraint)
        support = []
        costs = []
        for k in range(row.size()):
            variable = row.getVar(k)
            coefficient = row.getCoeff(k)
            if abs(coefficient - 1.0) > TOL:
                errors.append(f"non-unit coefficient in selected row {row_name}")
            support.append(variable.VarName)
            costs.append(variable.Obj)
            previous = owner.get(variable.VarName)
            if previous is not None:
                overlaps.append(
                    {"column": variable.VarName, "first_row": previous, "second_row": row_name}
                )
            else:
                owner[variable.VarName] = row_name
        if not support:
            errors.append(f"empty selected row: {row_name}")
            continue
        minimum_cost = min(costs)
        if minimum_cost < -TOL:
            errors.append(f"negative minimum cost in selected row {row_name}")
        computed_bound += minimum_cost * row_constraint.RHS
        selected_details.append(
            {
                "row": row_name,
                "support_size": len(support),
                "minimum_objective_coefficient": minimum_cost,
            }
        )

    if overlaps:
        errors.append(f"selected supports overlap in {len(overlaps)} column occurrences")
    claimed_bound = float(packing["bound"])
    if abs(computed_bound - claimed_bound) > TOL:
        errors.append(
            f"computed bound {computed_bound} differs from claimed bound {claimed_bound}"
        )

    output = {
        "verifier": "independent Gurobi row-matrix audit; optimize() not called",
        "verified_at_utc": datetime.now(timezone.utc).isoformat(),
        "source": args.mps,
        "source_sha256": sha256(args.mps),
        "model": {
            "rows": len(constraints),
            "columns": len(variables),
            "pure_unit_cover_rows": len(cover_names),
            "negative_objective_columns": len(negative_objective_columns),
            "negative_lower_bound_columns": len(negative_lower_bound_columns),
        },
        "certificate": {
            "selected_rows": len(selected_names),
            "distinct_supported_columns": len(owner),
            "overlap_count": len(overlaps),
            "claimed_lower_bound": claimed_bound,
            "recomputed_lower_bound": computed_bound,
            "valid": not errors,
        },
        "logic": (
            "Each selected row requires the sum of its variables to be at least one. "
            "Its objective contribution is therefore at least its cheapest coefficient. "
            "The selected supports are pairwise disjoint, and all other objective "
            "coefficients are nonnegative, so these row minima may be summed."
        ),
        "errors": errors,
        "overlaps_sample": overlaps[:20],
        "selected_row_details": selected_details,
    }
    with open(args.output, "w", encoding="utf-8") as stream:
        json.dump(output, stream, indent=2)
        stream.write("\n")

    print(
        json.dumps(
            {
                "valid": output["certificate"]["valid"],
                "selected_rows": len(selected_names),
                "overlap_count": len(overlaps),
                "recomputed_lower_bound": computed_bound,
                "errors": errors[:5],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
