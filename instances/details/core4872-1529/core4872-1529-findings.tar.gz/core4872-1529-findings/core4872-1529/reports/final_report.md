# `core4872-1529`: proof-oriented investigation

## Outcome

This run did **not** prove optimality. The strongest conclusions that survive
independent checking on the untouched official MPS are:

- a feasible solution of objective **1530** (the public MIPLIB ID 3 solution),
  with zero bound, integrality, or row violations;
- a globally valid, integer, disjoint-row-packing lower bound of **932**;
- therefore a verified interval of **[932, 1530]**.

The exact decision problem “is there a feasible solution of cost at most 1529?”
remains unresolved. In particular, the interrupted PB run is `UNKNOWN`; it is
not an infeasibility certificate. The lower bound 932 is reported as a locally
checkable bound, not as an improvement over every previously published bound.

## Provenance and background

- Official instance page:
  <https://miplib.zib.de/instance_details_core4872-1529.html>
- Official instance download:
  <https://miplib.zib.de/WebData/instances/core4872-1529.mps.gz>
- SHA-256 of the downloaded compressed MPS:
  `20db8aa3bf0cc9619df3f08b5fcbb5ea51dfa25f3f2adad2ef2e5bcdd29f9c68`
- Application: weighted set covering arising from Italian railway planning.
- Algorithmic background: Caprara, Fischetti, and Toth, “A Heuristic Method
  for the Set Covering Problem,” *Operations Research* 47(5), 730–743 (1999),
  <https://doi.org/10.1287/opre.47.5.730>. The publisher describes dynamic
  pricing, subgradient optimization, greedy construction, column fixing, and
  refinement for these large railway instances.

The full source notes are in `sources/background.md`.

## Read-only structure audit

Gurobi 13.0.2 read the original MPS only; `optimize()` and presolve were never
called. The original model has 24,656 variables, 4,875 rows, and 218,762
nonzeros. It contains:

- 24,645 integral `[0,1]` set columns: 6,781 of cost 1 and 17,864 of cost 2;
- 4,872 unit-coefficient covering rows `sum x_j >= 1`;
- 11 nonnegative continuous variables with positive costs that occur only in
  the redundant objective-upper-bound row;
- `UB`, an objective upper bound of `1e10`;
- `INERZIA`, a trivially satisfied lower bound;
- `R7002`, a limit of 9,256 on cost-2 columns, automatically satisfied by any
  candidate of total cost at most 1,529.

Thus the cutoff decision is exactly a weighted set-cover PB feasibility
problem with weights 1 and 2. There are 209 duplicate full-incidence groups
covering 419 variables in the unreduced model. Complete structural data are in
`structure/gurobi_structure.json` and `structure/recovered_structure.json`.

## Route 1: exact PB / native-cardinality search

The API first proposed a PB encoding and then revised it after execution
feedback. Two early drafts were not accepted as evidence:

1. the first draft contained an incidence-orientation error and potentially
   quadratic preprocessing;
2. the second draft misread the lowercase MPS RHS vector as a section header,
   counted 4,873 rather than 4,872 cover rows, and depended on unavailable
   `pypblib`. Its reductions and result were discarded.

The corrected program, `scripts/core4872_pb_v3.py`, was audited against the
known exact counts before searching. It uses:

- safe consolidation of 221 identical-incidence columns;
- singleton propagation, forcing 53 columns of total cost 82;
- 4,691 residual cover clauses on 24,365 residual columns;
- one equivalence alias per cost-2 variable, so the weighted cutoff becomes a
  native unweighted cardinality constraint in MiniCard.

The residual cardinality bound is 1,447. MiniCard searched for 899.30 wall
seconds and was interrupted at the 900-second route limit. It returned
`UNKNOWN`: no candidate witness and no replayable UNSAT proof were produced.
The machine-readable result is `artifacts/pb-v3-result.json`.

## Route 2: solver-independent dual and rare-row core

The fourth API round pivoted away from another SAT retry and generated
`scripts/core4872_dual.py`. It ran for 337.45 seconds without a MIP or SAT
solver. Two lower-bound mechanisms were exercised:

- a downward-rounded nonnegative LP-dual vector. Direct load checks certify a
  dual objective of 37.944899591401, hence the integer lower bound 38;
- a greedy rare-row packing selecting 692 covering rows whose complete column
  supports are pairwise disjoint. Summing each selected row's cheapest column
  cost gives 932.

The second number is stronger. It was independently replayed by
`scripts/verify_packing_certificate.py`, which imports none of the generator
code and calls no optimizer. On the untouched MPS it verified all of the
following:

- all 692 names and indices refer to pure unit covering rows;
- no column appears in two selected supports;
- all 24,656 objective coefficients and all variable lower bounds are
  nonnegative;
- the independently recomputed sum of row minima is exactly 932.

The audit found zero errors and is saved as
`artifacts/packing-independent-audit.json`. This proves the lower bound because
each selected row requires at least one unit of its nonnegative variables,
each such unit costs at least that row's minimum cost, and the selected column
sets are disjoint.

## Incumbent validation

`solutions/public-id3.sol.gz` was evaluated directly against every variable
bound, integrality requirement, objective coefficient, and original row. The
result is objective 1530 with maximum bound, integrality, and constraint
violation all equal to zero. The detailed audit is
`artifacts/public-id3.audit.json`.

## Resource accounting

- Auditable wall-clock window: 2026-09-09 03:00:42–05:02:00 CST, 7,278
  seconds (121.3 minutes).
- Successful stateful API calls: 4.
- API usage: 42,729 prompt tokens, 27,553 completion tokens, 70,282 total
  tokens (561 completion tokens were least-reported reasoning tokens).
- General-purpose MIP solver optimization: **0 seconds**.
- Gurobi use: file parsing, structure extraction, and certificate/witness
  auditing only.
- Exact SAT/PB search: 900.03 seconds total route wall time, including 899.30
  seconds in MiniCard.
- Solver-independent dual/packing computation: 337.45 seconds.

The complete accounting is in `effort_ledger.json` and the chronological
summary in `logs/run-summary.md`.

## What would be needed for a proof

Optimality at 1530 requires a verifiable proof that cutoff 1529 is infeasible.
The current disjoint core is far too weak to establish that. A defensible next
attempt would use a proof-producing PB/MaxSAT backend capable of a replayable
certificate, after retaining the audited exact reduction and the 53 forced
columns. Another meaningful route is a substantially stronger dual-ascent /
pricing implementation with reduced-cost fixing, as in the railway set-cover
literature. Repeating MiniCard without proof logging would not close the
verification gap.

