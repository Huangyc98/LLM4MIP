# `fhnw-binschedule1`: interval-order optimum certificate

## Disposition

The instance is solved at **55,158**. At the time of this investigation, the
official MIPLIB page listed it as open with incumbent 55,198. The new value
improves that incumbent by 40.

## Background and exact structural recovery

MIPLIB describes the instance as scheduling/assignment for an industrial
production pipeline. It has 1,141,653 variables, 772,872 rows, and 8,611,326
nonzeros. It belongs to the same `fhnw-bin` group as `fhnw-binschedule0` and
`fhnw-binschedule2`, so their endpoint arguments motivated the inspection, but
all facts used below were re-derived from this MPS.

The model is a six-machine makespan formulation with 2,152 set-partition
items. Machines 0 and 5 each have a chain of 387 unit-capacity endpoint slots.
Exactly 773 items are forced to use those two machines; all other items have
additional inner-machine options. Each selected endpoint assignment induces
an interval `[U_i,L_i]`. Every OR support is contained in one capacity slot,
and for every forced item its interval and assignment-plus-forced-OR cost are
invariant across all available endpoint positions and both endpoint machines.
Their fixed total cost is exactly 104,306.

For consecutive occupied endpoint positions, the relevant difference
indicator costs 10 precisely when `L_i > U_j`; it can be zero when
`L_i <= U_j`. All other endpoint-load coefficients are nonnegative. Both
endpoint load expressions contain only discrete variables and even integer
coefficients.

## Global lower-bound certificate

Zero-duration forced items at the same time point can be chained freely and
are contracted. The 773 items become 738 interval groups: 14 point groups and
724 positive-duration singleton groups. Add a compatibility arc `i -> j`
when `L_i <= U_j`. The contracted graph is a DAG and has no reciprocal arcs.

The archived bipartite matching has size 134. The certificate also contains a
Konig vertex cover of size 134 and the standard-library checker verifies that
it covers all 19,089 compatibility arcs. Thus the matching is maximum and the
minimum all-compatible path cover contains

```text
738 - 134 = 604 paths.
```

There are 774 endpoint positions for 773 forced items. The one remaining
position may be empty or occupied by a non-forced item; either way it can split
the forced items only once. Across the two endpoint chains, the forced items
therefore occupy at most three contiguous segments. Combining 604 compatible
paths into at most three segments requires at least

```text
604 - 3 = 601
```

incompatible forced-to-forced transitions. Ignoring the nonnegative
contributions of any non-forced endpoint item is safe. Hence every original
feasible solution satisfies

```text
load_0 + load_5 >= 104306 + 10*601 = 110316.
```

Consequently the maximum of the two endpoint loads, and therefore the global
makespan objective, is at least **55,158**. The even-load lattice is also
verified, although the endpoint-sum bound already has the integral half
55,158.

## Matching upper bound

A direct partition of whole paths first produced a fully feasible original
solution of 55,164, already improving the public 55,198 incumbent. To attain
the lower bound, equal-point items were expanded with an acyclic orientation,
giving 33,591 candidate compatible arcs. The colored compact decision model
has 3,097 rows and 67,955 binaries. It assigns 387 forced items to machine 0
and 386 to machine 5, realizes the maximum 169 compatible adjacencies, and
enforces both loads at most 55,158.

COPT 8.0.4 was used as a CPU-only witness oracle. It found a feasible point at
the root in 5.00 seconds. The selected split has 73 compatible arcs on machine
0 and 96 on machine 5. Machine 5 uses the single remaining endpoint position
as a separator between two occupied segments. The endpoint bad-transition
counts are

```text
machine 0: 386 - 73 = 313
machine 5: 384 - 96 = 288
total:                     601.
```

After lifting, the six original load expressions are

```text
55158, 17609, 23551, 23394, 17236, 55158.
```

The script independently checks all 3,097 compact rows and then all 772,872
original rows using rational arithmetic recovered from the serialized MPS.
It reports zero row, bound, and integrality violations. This establishes the
matching upper bound 55,158.

## Why this is not a solver-tuning result

The lower bound is the maximum-matching/minimum-path-cover theorem applied to
the recovered endpoint intervals. It does not use a branch-and-bound dual
bound. COPT only chooses a coloring and compatible arcs that attain the
already-proved lower bound; the resulting point is lifted and checked in the
original model. The full 1.14-million-variable MIP was never given a long
parameter sweep.

Euler4's available Gurobi installation had a size-limited license and rejected
the 67,955-variable compact oracle. This did not affect parsing, certificate
construction, or exact validation. The compact LP was transferred to Altman
and solved with COPT on CPU; GPU0 was not used.

## Reproducibility boundary

`derive_interval_core.py` parses the original MPS, tests every structural
invariance, emits the certificate, generates the compact target LP, lifts a
named compact solution, and validates the original rows. The separate
`verify_interval_certificate.py` uses only the Python standard library and
recomputes all compatibility arcs and certificate arithmetic. The regenerable
6.5 MB compact LP and compact COPT solution are omitted; the decisive compact
solver log, final lifted solution, certificate, and full validation transcript
are archived.

