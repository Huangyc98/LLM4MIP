#!/usr/bin/env python3
"""Eliminate coordinates from the fhnw-binschedule1 endpoint core.

Gurobi is used only to parse the MPS.  The script proves/checks when endpoint
OR cost is additive per assignment and when each transition indicator is
equivalent at optimum to an interval incompatibility between consecutive bins.
"""

import argparse
import gzip
import json
import re
from collections import Counter, defaultdict
from fractions import Fraction

import gurobipy as gp
from gurobipy import GRB


def F(value):
    if isinstance(value, Fraction):
        return value
    return Fraction(str(float(value))).limit_denominator(10**6)


def compact(counter, limit=20):
    values = sorted(counter.items(), key=lambda kv: (-kv[1], str(kv[0])))
    text = ", ".join(f"{key}:{count}" for key, count in values[:limit])
    if len(values) > limit:
        text += f", ... ({len(values)} distinct)"
    return "{" + text + "}"


def read_solution(path, names):
    opener = gzip.open if path.endswith(".gz") else open
    values = {}
    with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
        for raw in handle:
            fields = raw.strip().split()
            if len(fields) >= 2 and fields[0] in names:
                try:
                    values[names[fields[0]]] = Fraction(fields[1])
                except ValueError:
                    pass
    return values


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mps")
    parser.add_argument("solution")
    parser.add_argument("--certificate")
    parser.add_argument("--solution-out")
    parser.add_argument("--decision-target", type=int)
    parser.add_argument("--decision-log")
    parser.add_argument("--decision-lp")
    parser.add_argument(
        "--decision-export-only",
        action="store_true",
        help="write the compact decision LP and stop before invoking Gurobi",
    )
    parser.add_argument(
        "--decision-solution",
        help="read an externally produced solution of the compact decision LP",
    )
    args = parser.parse_args()

    model = gp.read(args.mps)
    variables = model.getVars()
    constraints = model.getConstrs()
    names = {v.VarName: v.index for v in variables}
    public = read_solution(args.solution, names)
    rows = []
    incidence = [[] for _ in variables]
    for ri, con in enumerate(constraints):
        expr = model.getRow(con)
        terms = []
        for k in range(expr.size()):
            j = expr.getVar(k).index
            a = F(expr.getCoeff(k))
            terms.append((j, a))
            incidence[j].append(ri)
        rows.append((con.Sense, F(con.RHS), terms))

    items = []
    item_rows = set()
    assignment = set()
    item_of = {}
    for ri, (sense, rhs, terms) in enumerate(rows):
        if sense == "=" and rhs == 1 and terms and all(a == 1 and variables[j].VType == GRB.BINARY for j, a in terms):
            item_rows.add(ri)
            item = len(items)
            opts = tuple(j for j, _ in terms)
            items.append(opts)
            for j in opts:
                assignment.add(j)
                item_of[j] = item

    objective_var = next(v.index for v in variables if F(v.Obj) != 0)
    loads = []
    for ri in incidence[objective_var]:
        sense, rhs, terms = rows[ri]
        ao = dict(terms)[objective_var]
        sign = Fraction(1) if sense == ">" else Fraction(-1)
        scale = sign * ao
        loads.append((ri, sign * rhs / scale, {j: -sign * a / scale for j, a in terms if j != objective_var and a != 0}))
    owner = {j: tuple(k for k, (_, _, c) in enumerate(loads) if c.get(j, 0)) for j in assignment}

    capacity_rows = []
    slot_of = {}
    slot_options = []
    for ri, (_, _, terms) in enumerate(rows):
        if ri not in item_rows and terms and all(j in assignment for j, _ in terms):
            slot = len(slot_options)
            capacity_rows.append(ri)
            opts = tuple(j for j, _ in terms)
            slot_options.append(opts)
            for j in opts:
                slot_of[j] = slot
    slot_machine = {}
    for slot, opts in enumerate(slot_options):
        machines = {owner[j] for j in opts}
        if len(machines) != 1 or len(next(iter(machines))) != 1:
            raise RuntimeError(f"ambiguous slot owner {slot}: {machines}")
        slot_machine[slot] = next(iter(machines))[0]

    or_support = {}
    ors_of = defaultdict(list)
    for sense, rhs, terms in rows:
        pos = [(j, a) for j, a in terms if a > 0]
        neg = [(j, a) for j, a in terms if a < 0]
        if sense == ">" and rhs == 0 and len(pos) == 1 and neg:
            z, az = pos[0]
            if z not in assignment and variables[z].VType == GRB.BINARY and az == len(neg) and all(j in assignment and a == -1 for j, a in neg):
                support = tuple(j for j, _ in neg)
                or_support[z] = support
                for j in support:
                    ors_of[j].append(z)

    horizon = int(max(F(v.UB) for v in variables if v.VType == GRB.INTEGER))
    integer = {v.index for v in variables if v.VType == GRB.INTEGER}
    selector_window = defaultdict(list)
    for ri in range(len(rows) - 1):
        s1, r1, t1 = rows[ri]
        s2, r2, t2 = rows[ri + 1]
        i1 = [(j, a) for j, a in t1 if j in integer]
        i2 = [(j, a) for j, a in t2 if j in integer]
        o1 = [(j, a) for j, a in t1 if j not in integer]
        o2 = [(j, a) for j, a in t2 if j not in integer]
        if s1 != "<" or r1 != horizon or s2 != ">" or r2 != 0 or len(i1) != 1 or len(i2) != 1 or i1[0][1] != 1 or i2[0][1] != 1 or len(o1) > 1 or len(o2) > 1:
            continue
        h1 = Fraction(horizon) if not o1 else Fraction(horizon) - o1[0][1]
        h2 = Fraction(0) if not o2 else -o2[0][1]
        selectors = {j for j, _ in o1 + o2}
        if h1 == h2 and len(selectors) == 1:
            selector = next(iter(selectors))
            if selector in assignment or selector in or_support:
                selector_window[selector].append((i1[0][0], i2[0][0], h1))

    # Each endpoint assignment induces a single bin interval and an additive
    # cost because every OR support must lie inside one unit-capacity slot.
    endpoint_assignments = [j for j in assignment if owner[j] in ((0,), (5,))]
    mixed_or_slots = []
    for z, support in or_support.items():
        slots = {slot_of[j] for j in support}
        if len(slots) != 1:
            mixed_or_slots.append((z, slots))
    print("OR supports crossing capacity slots", len(mixed_or_slots))

    record = {}
    missing_windows = []
    inconsistent_nodes = []
    for j in endpoint_assignments:
        selectors = ([j] if j in selector_window else []) + ors_of[j]
        windows = [window for s in selectors for window in selector_window[s]]
        if not windows:
            missing_windows.append(j)
            continue
        node_pairs = {(u, v) for u, v, h in windows}
        if len(node_pairs) != 1:
            inconsistent_nodes.append((j, node_pairs))
            continue
        u, v = next(iter(node_pairs))
        cuts = [h for _, _, h in windows]
        machine = owner[j][0]
        cost = loads[machine][2].get(j, 0) + sum(loads[machine][2].get(z, 0) for z in ors_of[j])
        record[j] = {
            "item": item_of[j],
            "slot": slot_of[j],
            "machine": machine,
            "u": u,
            "v": v,
            "U": min(cuts),
            "L": max(cuts),
            "cost": cost,
            "or_count": len(ors_of[j]),
        }
    print("endpoint assignments", len(endpoint_assignments), "decoded", len(record))
    print("missing windows", len(missing_windows), "inconsistent nodes", len(inconsistent_nodes))

    # Verify item-machine invariance across all positions.
    signatures = defaultdict(set)
    for data in record.values():
        signatures[(data["item"], data["machine"])].add((data["U"], data["L"], data["cost"], data["or_count"]))
    noninvariant = {key: vals for key, vals in signatures.items() if len(vals) != 1}
    print("item-machine signatures", len(signatures), "noninvariant", len(noninvariant))
    if noninvariant:
        print("first noninvariant", list(noninvariant.items())[:10])
    duration_hist = Counter()
    type_hist = Counter()
    for vals in signatures.values():
        if len(vals) == 1:
            U, L, cost, n_or = next(iter(vals))
            duration_hist[L - U] += 1
            type_hist[(U, L, cost)] += 1
    print("L-U histogram", compact(duration_hist, 50))
    print("item-machine (U,L,cost) types", len(type_hist), compact(type_hist, 30))

    # Recover chain edges and map integer endpoints back to slots.
    pair_to_slot = {}
    for data in record.values():
        pair_to_slot[(data["u"], data["v"])] = data["slot"]
    diff_edges = []
    seen_diff = set()
    for ri, (sense, rhs, terms) in enumerate(rows):
        ints = [(j, a) for j, a in terms if j in integer]
        bins = [(j, a) for j, a in terms if variables[j].VType == GRB.BINARY and j not in assignment]
        if rhs == 0 and len(ints) == 2 and len(bins) == 1 and sorted(a for _, a in ints) == [-1, 1] and abs(bins[0][1]) == horizon:
            z = bins[0][0]
            if z in seen_diff:
                continue
            seen_diff.add(z)
            a, b = [j for j, _ in ints]
            # Determine directed previous-v to next-u using recovered pairs.
            prev = next((slot for (u, v), slot in pair_to_slot.items() if v in (a, b)), None)
            nxt = next((slot for (u, v), slot in pair_to_slot.items() if u in (a, b)), None)
            coeff = sum(loads[k][2].get(z, 0) for k in (0, 5))
            diff_edges.append((z, prev, nxt, coeff))
    print("difference edges", len(diff_edges), "unmapped", sum(1 for _, a, b, _ in diff_edges if a is None or b is None))
    print("difference cost histogram", compact(Counter(c for _, _, _, c in diff_edges)))
    print("chain machine pairs", compact(Counter((slot_machine.get(a), slot_machine.get(b)) for _, a, b, _ in diff_edges)))

    # Public sequence validation: compare exact interval incompatibilities to d.
    selected_by_slot = {}
    for j, data in record.items():
        if public.get(j, 0) == 1:
            selected_by_slot[data["slot"]] = j
    bad = 0
    active = 0
    mismatch = []
    for z, prev, nxt, coeff in diff_edges:
        jp = selected_by_slot.get(prev)
        jn = selected_by_slot.get(nxt)
        forced = bool(jp is not None and jn is not None and record[jp]["L"] > record[jn]["U"])
        actual = public.get(z, 0) == 1
        bad += int(forced)
        active += int(actual)
        if forced != actual:
            mismatch.append((z, prev, nxt, forced, actual))
    print("public selected endpoint assignments", len(selected_by_slot))
    print("public forced bad transitions", bad, "active difference indicators", active, "mismatch", len(mismatch))
    if mismatch:
        print("first transition mismatch", mismatch[:20])

    # Exact root assignment minimum follows from position invariance. Report
    # the cost difference between machine choices and the count constraint.
    choice = {}
    for item in range(len(items)):
        if (item, 0) in signatures and (item, 5) in signatures and len(signatures[(item, 0)]) == len(signatures[(item, 5)]) == 1:
            choice[item] = (next(iter(signatures[(item, 0)])), next(iter(signatures[(item, 5)])))
    print("endpoint-only items with two invariant choices", len(choice))
    deltas = Counter(v5[2] - v0[2] for v0, v5 in choice.values())
    print("machine-5 minus machine-0 cost deltas", compact(deltas, 50))
    print("public endpoint counts", compact(Counter(data["machine"] for slot, j in selected_by_slot.items() for data in (record[j],))))

    # ------------------------------------------------------------------
    # Polynomial interval-order certificate for the forced endpoint items.
    # ------------------------------------------------------------------
    forced_items = [
        i for i, opts in enumerate(items)
        if {k for j in opts for k in owner[j]} == {0, 5}
    ]
    invariant = {}
    invariant_failures = {}
    for item in forced_items:
        values = {
            (data["U"], data["L"], data["cost"])
            for data in record.values() if data["item"] == item
        }
        if len(values) == 1:
            invariant[item] = next(iter(values))
        else:
            invariant_failures[item] = values
    print("\nINTERVAL-ORDER CERTIFICATE")
    print("forced endpoint items", len(forced_items), "invariance failures", len(invariant_failures))
    if invariant_failures:
        print("first failures", list(invariant_failures.items())[:10])
        return
    if any(U > L for U, L, _ in invariant.values()):
        raise RuntimeError("found an interval with U > L")

    base_cost = sum(cost for U, L, cost in invariant.values())
    point_members = defaultdict(list)
    positive = []
    for item, (U, L, cost) in invariant.items():
        if U == L:
            point_members[U].append(item)
        else:
            positive.append((item, U, L))
    groups = []
    for h, members in sorted(point_members.items()):
        groups.append({"U": h, "L": h, "members": sorted(members)})
    for item, U, L in positive:
        groups.append({"U": U, "L": L, "members": [item]})
    groups.sort(key=lambda g: (g["U"], g["L"], g["members"][0]))

    n_groups = len(groups)
    adjacency = []
    reverse_count = 0
    for a, ga in enumerate(groups):
        neighbors = []
        for b, gb in enumerate(groups):
            if a != b and ga["L"] <= gb["U"]:
                neighbors.append(b)
                if gb["L"] <= ga["U"]:
                    reverse_count += 1
        adjacency.append(neighbors)
    print("contracted groups", n_groups, "point groups", len(point_members), "positive-duration singletons", len(positive))
    print("reciprocal inter-group arcs", reverse_count)
    if reverse_count:
        raise RuntimeError("contracted compatibility graph is not antisymmetric")

    # Kahn test: the compatibility relation after contraction must be a DAG.
    indegree = [0] * n_groups
    for neighbors in adjacency:
        for b in neighbors:
            indegree[b] += 1
    queue = [g for g, d in enumerate(indegree) if d == 0]
    head = 0
    topo = []
    while head < len(queue):
        a = queue[head]
        head += 1
        topo.append(a)
        for b in adjacency[a]:
            indegree[b] -= 1
            if indegree[b] == 0:
                queue.append(b)
    print("DAG nodes reached", len(topo), "/", n_groups)
    if len(topo) != n_groups:
        raise RuntimeError("contracted compatibility graph contains a cycle")

    # Hopcroft-Karp maximum matching on the bipartite split of the DAG.
    pair_left = [-1] * n_groups
    pair_right = [-1] * n_groups
    distance = [0] * n_groups

    def bfs():
        qnodes = []
        for a in range(n_groups):
            if pair_left[a] == -1:
                distance[a] = 0
                qnodes.append(a)
            else:
                distance[a] = -1
        found = False
        qhead = 0
        while qhead < len(qnodes):
            a = qnodes[qhead]
            qhead += 1
            for b in adjacency[a]:
                mate = pair_right[b]
                if mate == -1:
                    found = True
                elif distance[mate] == -1:
                    distance[mate] = distance[a] + 1
                    qnodes.append(mate)
        return found

    def dfs(a):
        for b in adjacency[a]:
            mate = pair_right[b]
            if mate == -1 or (distance[mate] == distance[a] + 1 and dfs(mate)):
                pair_left[a] = b
                pair_right[b] = a
                return True
        distance[a] = -1
        return False

    matching_size = 0
    while bfs():
        for a in range(n_groups):
            if pair_left[a] == -1 and dfs(a):
                matching_size += 1

    # Konig minimum vertex cover, an independently checkable upper certificate
    # on the matching size: (Left \ Z_Left) union Z_Right.
    z_left = {a for a in range(n_groups) if pair_left[a] == -1}
    z_right = set()
    frontier = list(z_left)
    while frontier:
        a = frontier.pop()
        for b in adjacency[a]:
            if pair_left[a] == b or b in z_right:
                continue
            z_right.add(b)
            mate = pair_right[b]
            if mate != -1 and mate not in z_left:
                z_left.add(mate)
                frontier.append(mate)
    cover_left = sorted(set(range(n_groups)) - z_left)
    cover_right = sorted(z_right)
    cover_size = len(cover_left) + len(cover_right)
    uncovered_edges = sum(1 for a, neighbors in enumerate(adjacency) for b in neighbors if a not in cover_left and b not in cover_right)

    minimum_good_paths = n_groups - matching_size
    endpoint_machines = (0, 5)
    endpoint_slot_counts = Counter(
        machine for machine in slot_machine.values() if machine in endpoint_machines
    )
    if set(endpoint_slot_counts) != set(endpoint_machines):
        raise RuntimeError(f"missing endpoint chains: {endpoint_slot_counts}")
    if endpoint_slot_counts[0] != endpoint_slot_counts[5]:
        raise RuntimeError(f"unequal endpoint chain lengths: {endpoint_slot_counts}")
    endpoint_chain_length = endpoint_slot_counts[0]
    separator_cap = sum(endpoint_slot_counts.values()) - len(forced_items)
    if separator_cap != 1:
        raise RuntimeError(
            "this certificate expects exactly one endpoint position not occupied "
            f"by a forced item, found {separator_cap}"
        )
    # A non-forced or empty endpoint position can split one of the two chains,
    # so the forced items occupy at most three contiguous segments.
    occupied_segments = len(endpoint_machines) + separator_cap
    bad_transition_lb = max(0, minimum_good_paths - occupied_segments)
    endpoint_diff_costs = {c for _, a, b, c in diff_edges if a is not None and b is not None}
    if endpoint_diff_costs != {Fraction(10)}:
        raise RuntimeError(f"unexpected endpoint difference costs: {endpoint_diff_costs}")
    objective_lb = base_cost + 10 * bad_transition_lb

    # The proof ignores any non-forced item placed at an endpoint.  This is
    # safe only when every omitted endpoint contribution is nonnegative.
    endpoint_coefficients = [
        coefficient
        for machine in endpoint_machines
        for coefficient in loads[machine][2].values()
    ]
    if any(coefficient < 0 for coefficient in endpoint_coefficients):
        raise RuntimeError("negative endpoint load contribution cannot be ignored")

    endpoint_load_lattice = 2
    for machine in endpoint_machines:
        _, beta, cost = loads[machine]
        if beta.denominator != 1 or beta.numerator % endpoint_load_lattice:
            raise RuntimeError(f"endpoint {machine} load constant is not even")
        for j, coefficient in cost.items():
            if variables[j].VType not in (GRB.BINARY, GRB.INTEGER):
                raise RuntimeError(
                    f"endpoint {machine} load contains nondiscrete variable {variables[j].VarName}"
                )
            if (
                coefficient.denominator != 1
                or coefficient.numerator % endpoint_load_lattice
            ):
                raise RuntimeError(
                    f"endpoint {machine} coefficient is not even: "
                    f"{variables[j].VarName}={coefficient}"
                )
    half_endpoint_sum = objective_lb / 2
    half_ceiling = -(-half_endpoint_sum.numerator // half_endpoint_sum.denominator)
    objective_max_lb = (
        (half_ceiling + endpoint_load_lattice - 1) // endpoint_load_lattice
    ) * endpoint_load_lattice

    public_load_values = [
        beta + sum(coefficient * public.get(j, 0) for j, coefficient in cost.items())
        for _, beta, cost in loads
    ]
    public_endpoint_sum = sum(public_load_values[m] for m in endpoint_machines)

    print("fixed assignment+OR base cost", base_cost)
    print("maximum inter-group good matching", matching_size)
    print("Konig cover size", cover_size, "uncovered compatibility arcs", uncovered_edges)
    print("minimum all-good path count", minimum_good_paths)
    print("endpoint slot counts", dict(endpoint_slot_counts), "separator capacity", separator_cap)
    print("maximum occupied forced-item segments", occupied_segments)
    print("bad-transition lower bound", bad_transition_lb)
    print("certified endpoint-sum lower bound", objective_lb)
    print("endpoint load lattice", endpoint_load_lattice)
    print("certified maximum-load lower bound", objective_max_lb)
    print("public endpoint loads", [public_load_values[m] for m in endpoint_machines])
    print("public endpoint sum", public_endpoint_sum, "lower-bound gap", public_endpoint_sum - objective_lb)

    if args.certificate:
        certificate = {
            "instance": "fhnw-binschedule1",
            "forced_items": len(forced_items),
            "fixed_base_cost": str(base_cost),
            "groups": [
                {"id": i, "U": str(g["U"]), "L": str(g["L"]), "members": g["members"]}
                for i, g in enumerate(groups)
            ],
            "matching": [[a, b] for a, b in enumerate(pair_left) if b != -1],
            "minimum_vertex_cover": {
                "left": cover_left,
                "right": cover_right,
            },
            "matching_size": matching_size,
            "cover_size": cover_size,
            "uncovered_compatibility_arcs": uncovered_edges,
            "minimum_good_paths": minimum_good_paths,
            "endpoint_slot_counts": {str(k): endpoint_slot_counts[k] for k in endpoint_machines},
            "separator_cap": separator_cap,
            "occupied_segment_cap": occupied_segments,
            "bad_transition_lower_bound": bad_transition_lb,
            "difference_cost": "10",
            "endpoint_sum_lower_bound": str(objective_lb),
            "endpoint_load_lattice": endpoint_load_lattice,
            "objective_lower_bound": str(objective_max_lb),
        }
        with open(args.certificate, "w", encoding="utf-8") as handle:
            json.dump(certificate, handle, indent=2)
            handle.write("\n")
        print("certificate written", args.certificate)

    if not args.solution_out:
        return

    # Reconstruct the minimum-path-cover paths.
    group_paths = []
    starts = [g for g in range(n_groups) if pair_right[g] == -1]
    covered_groups = set()
    for start in starts:
        path = []
        current = start
        while current != -1:
            if current in covered_groups:
                raise RuntimeError("matching path reconstruction found a cycle")
            covered_groups.add(current)
            path.append(current)
            current = pair_left[current]
        group_paths.append(path)
    if len(covered_groups) != n_groups:
        raise RuntimeError("matching paths do not cover every group")
    item_paths = []
    for path in group_paths:
        item_path = []
        for group in path:
            item_path.extend(groups[group]["members"])
        item_paths.append(item_path)
    print("path length histogram", compact(Counter(len(path) for path in item_paths), 50))

    # Exact subset-sum bitset DP: assign whole compatible paths to machine 0
    # so it fills one endpoint chain, while balancing the two endpoint loads.
    # A path contributes base cost plus 10; subtract 10 once per nonempty
    # machine after selection to account for k-1 joins.
    path_base = [sum(invariant[item][2] for item in path) for path in item_paths]
    if any(cost.denominator != 1 for cost in path_base):
        raise RuntimeError("nonintegral path cost")
    path_adjusted = [int(cost) + 10 for cost in path_base]
    snapshots = []
    reachable = [0] * (endpoint_chain_length + 1)
    reachable[0] = 1  # bit zero
    snapshots.append(reachable[:])
    for path, adjusted in zip(item_paths, path_adjusted):
        weight = len(path)
        updated = reachable[:]
        for count in range(endpoint_chain_length - weight + 1):
            if reachable[count]:
                updated[count + weight] |= reachable[count] << adjusted
        reachable = updated
        snapshots.append(reachable[:])
    candidates = [
        s for s in range(sum(path_adjusted) + 1)
        if (reachable[endpoint_chain_length] >> s) & 1
    ]
    if not candidates:
        raise RuntimeError(
            f"no whole-path subset contains exactly {endpoint_chain_length} items"
        )
    total_adjusted = sum(path_adjusted)
    selected_sum = min(candidates, key=lambda s: (max(s - 10, total_adjusted - s - 10), abs(2 * s - total_adjusted)))
    selected_paths = set()
    remaining_count = endpoint_chain_length
    remaining_sum = selected_sum
    for i in range(len(item_paths), 0, -1):
        if (snapshots[i - 1][remaining_count] >> remaining_sum) & 1:
            continue
        weight = len(item_paths[i - 1])
        adjusted = path_adjusted[i - 1]
        if remaining_count < weight or remaining_sum < adjusted or not ((snapshots[i - 1][remaining_count - weight] >> (remaining_sum - adjusted)) & 1):
            raise RuntimeError("subset reconstruction failed")
        selected_paths.add(i - 1)
        remaining_count -= weight
        remaining_sum -= adjusted
    if remaining_count != 0 or remaining_sum != 0:
        raise RuntimeError("subset reconstruction ended at a nonzero state")

    machine_paths = {
        0: [item_paths[i] for i in range(len(item_paths)) if i in selected_paths],
        5: [item_paths[i] for i in range(len(item_paths)) if i not in selected_paths],
    }
    machine_items = {m: [item for path in machine_paths[m] for item in path] for m in (0, 5)}
    predicted = {
        0: sum(invariant[item][2] for item in machine_items[0]) + 10 * (len(machine_paths[0]) - 1),
        5: sum(invariant[item][2] for item in machine_items[5]) + 10 * (len(machine_paths[5]) - 1),
    }
    print("whole-path partition counts", {m: len(machine_items[m]) for m in (0, 5)})
    print("whole-path partition path counts", {m: len(machine_paths[m]) for m in (0, 5)})
    print("predicted endpoint load upper bounds", predicted)

    # Recover each endpoint machine's exact slot chain.
    endpoint_edges = [(z, a, b) for z, a, b, c in diff_edges if a is not None and b is not None]
    chain_slots = {}
    edge_var = {}
    for machine in (0, 5):
        edges = [(z, a, b) for z, a, b in endpoint_edges if slot_machine[a] == machine]
        successor = {a: b for z, a, b in edges}
        predecessor = {b: a for z, a, b in edges}
        edge_var.update({(a, b): z for z, a, b in edges})
        starts_here = [slot for slot, owner_machine in slot_machine.items() if owner_machine == machine and slot not in predecessor]
        if len(starts_here) != 1:
            raise RuntimeError(f"machine {machine} has {len(starts_here)} chain starts")
        chain = []
        slot = starts_here[0]
        while True:
            chain.append(slot)
            if slot not in successor:
                break
            slot = successor[slot]
        if len(chain) != endpoint_chain_length:
            raise RuntimeError(f"machine {machine} chain length is {len(chain)}")
        chain_slots[machine] = chain

    assignment_by_item_slot = {(data["item"], data["slot"]): j for j, data in record.items()}
    new_values = [public.get(j, Fraction(0)) for j in range(len(variables))]
    forced_set = set(forced_items)
    for j in assignment:
        if item_of[j] in forced_set:
            new_values[j] = Fraction(0)

    selected_item_at_slot = {}
    for machine in (0, 5):
        jobs = machine_items[machine]
        slots = chain_slots[machine]
        if len(jobs) > len(slots):
            raise RuntimeError("too many jobs for endpoint chain")
        for item, slot in zip(jobs, slots):
            j = assignment_by_item_slot[(item, slot)]
            new_values[j] = Fraction(1)
            selected_item_at_slot[slot] = item

    # Recompute every OR exactly from the new complete assignment.
    for z, support in or_support.items():
        new_values[z] = Fraction(int(any(new_values[j] == 1 for j in support)))

    # Map every endpoint slot to its two integer coordinates.
    slot_nodes = {}
    for data in record.values():
        slot_nodes[data["slot"]] = (data["u"], data["v"])

    # Assign endpoint coordinates and exact transition indicators. The one
    # unused slot is left at the end of machine 5's chain.
    for machine in (0, 5):
        chain = chain_slots[machine]
        for slot in chain:
            u, v = slot_nodes[slot]
            item = selected_item_at_slot.get(slot)
            if item is None:
                new_values[u] = Fraction(0)
                new_values[v] = Fraction(0)
            else:
                U, L, _ = invariant[item]
                new_values[u] = U
                new_values[v] = L
        for previous, following in zip(chain, chain[1:]):
            zp = edge_var[(previous, following)]
            item_previous = selected_item_at_slot.get(previous)
            item_following = selected_item_at_slot.get(following)
            _, v_previous = slot_nodes[previous]
            u_following, _ = slot_nodes[following]
            if item_previous is None:
                common = new_values[u_following]
                new_values[v_previous] = common
                new_values[zp] = Fraction(0)
            elif item_following is None:
                common = new_values[v_previous]
                new_values[u_following] = common
                new_values[zp] = Fraction(0)
            else:
                _, L_previous, _ = invariant[item_previous]
                U_following, _, _ = invariant[item_following]
                if L_previous <= U_following:
                    new_values[v_previous] = L_previous
                    new_values[u_following] = L_previous
                    new_values[zp] = Fraction(0)
                else:
                    new_values[v_previous] = L_previous
                    new_values[u_following] = U_following
                    new_values[zp] = Fraction(1)

    load_values = []
    for _, beta, cost in loads:
        load_values.append(beta + sum(coefficient * new_values[j] for j, coefficient in cost.items()))
    new_objective = max(load_values)
    new_values[objective_var] = new_objective

    def holds(sense, lhs, rhs):
        return lhs == rhs if sense == "=" else lhs <= rhs if sense == "<" else lhs >= rhs

    violations = []
    for ri, (sense, rhs, terms) in enumerate(rows):
        lhs = sum(a * new_values[j] for j, a in terms)
        if not holds(sense, lhs, rhs):
            violations.append((ri, constraints[ri].ConstrName, str(lhs), sense, str(rhs)))
    bound_violations = []
    integrality_violations = []
    for j, v in enumerate(variables):
        value = new_values[j]
        lower_ok = v.LB <= -GRB.INFINITY or value >= F(v.LB)
        upper_ok = v.UB >= GRB.INFINITY or value <= F(v.UB)
        if not lower_ok or not upper_ok:
            bound_violations.append((v.VarName, str(value), str(v.LB), str(v.UB)))
        if v.VType in (GRB.BINARY, GRB.INTEGER) and value.denominator != 1:
            integrality_violations.append((v.VarName, str(value)))
    print("constructed load values", [str(value) for value in load_values])
    print("constructed objective", new_objective)
    print("row violations", len(violations), "bound violations", len(bound_violations), "integrality violations", len(integrality_violations))
    if violations:
        print("first row violations", violations[:20])
        for ri, *_ in violations[:5]:
            print(
                "violation terms",
                ri,
                [
                    (variables[j].VarName, str(a), str(new_values[j]), "item=" + str(item_of.get(j)), "slot=" + str(slot_of.get(j)))
                    for j, a in rows[ri][2]
                ],
            )
    if bound_violations:
        print("first bound violations", bound_violations[:20])
    if integrality_violations:
        print("first integrality violations", integrality_violations[:20])
    if violations or bound_violations or integrality_violations:
        raise RuntimeError("constructed solution failed exact validation")

    with open(args.solution_out, "w", encoding="utf-8") as handle:
        handle.write(f"=obj= {new_objective}\n")
        for j, value in enumerate(new_values):
            if value:
                handle.write(f"{variables[j].VarName} {value}\n")
    print("validated solution written", args.solution_out)

    if args.decision_target is None:
        return

    # Exact target decision at the certified sum lower bound.  At equality the
    # two colors together must realize a maximum set of compatible adjacencies.
    # Equal-point items are kept separate; their mutual arcs are oriented by
    # item id. This removes artificial cycles without loss because they have
    # identical predecessor/successor neighborhoods within either machine.
    decision_items = sorted(forced_items)
    good_arcs = []
    for i in decision_items:
        Ui, Li, _ = invariant[i]
        for j in decision_items:
            if i == j:
                continue
            Uj, Lj, _ = invariant[j]
            if Li > Uj:
                continue
            if Ui == Li == Uj == Lj and i > j:
                continue
            good_arcs.append((i, j))

    # Verify acyclicity using the exact topological key discussed above.
    def topological_key(item):
        U, L, _ = invariant[item]
        return (U, 0 if U == L else 1, item)
    backward = [(i, j) for i, j in good_arcs if topological_key(i) >= topological_key(j)]
    print("decision compatibility arcs", len(good_arcs), "backward arcs", len(backward))
    if backward:
        raise RuntimeError(f"oriented item compatibility graph is not a DAG: {backward[:5]}")

    reduced = gp.Model("fhnw_binschedule1_interval_target")
    color = {i: reduced.addVar(vtype=GRB.BINARY, name=f"machine0_item_{i}") for i in decision_items}
    arc0 = {(i, j): reduced.addVar(vtype=GRB.BINARY, name=f"good0_{i}_{j}") for i, j in good_arcs}
    arc5 = {(i, j): reduced.addVar(vtype=GRB.BINARY, name=f"good5_{i}_{j}") for i, j in good_arcs}
    out_arcs = defaultdict(list)
    in_arcs = defaultdict(list)
    for i, j in good_arcs:
        out_arcs[i].append(j)
        in_arcs[j].append(i)
    for i in decision_items:
        reduced.addConstr(gp.quicksum(arc0[i, j] for j in out_arcs[i]) <= color[i], name=f"out0_{i}")
        reduced.addConstr(gp.quicksum(arc0[j, i] for j in in_arcs[i]) <= color[i], name=f"in0_{i}")
        reduced.addConstr(gp.quicksum(arc5[i, j] for j in out_arcs[i]) <= 1 - color[i], name=f"out5_{i}")
        reduced.addConstr(gp.quicksum(arc5[j, i] for j in in_arcs[i]) <= 1 - color[i], name=f"in5_{i}")
    reduced.addConstr(
        gp.quicksum(color.values()) == endpoint_chain_length,
        name="machine0_item_count",
    )
    match0 = gp.quicksum(arc0.values())
    match5 = gp.quicksum(arc5.values())
    total_good_target = len(forced_items) - minimum_good_paths
    reduced.addConstr(
        match0 + match5 == total_good_target,
        name="minimum_path_cover_equality",
    )
    reduced.addConstr(
        match5 <= endpoint_chain_length - 3,
        name="empty_slot_splits_two_nonempty_machine5_segments",
    )
    cost0 = gp.quicksum(float(invariant[i][2]) * color[i] for i in decision_items)
    total_cost = float(base_cost)
    load0 = cost0 + 10 * (endpoint_chain_length - 1 - match0)
    load5 = (total_cost - cost0) + 10 * (endpoint_chain_length - 3 - match5)
    reduced.addConstr(load0 <= args.decision_target, name="machine0_target")
    reduced.addConstr(load5 <= args.decision_target, name="machine5_target")
    reduced.setObjective(0, GRB.MINIMIZE)
    reduced.Params.TimeLimit = 300
    reduced.Params.Threads = 8
    if args.decision_log:
        reduced.Params.LogFile = args.decision_log
    reduced.update()
    if args.decision_lp:
        reduced.write(args.decision_lp)
    if args.decision_export_only:
        if not args.decision_lp:
            raise RuntimeError("--decision-export-only requires --decision-lp")
        print("compact decision LP exported", args.decision_lp)
        return

    external_values = None
    if args.decision_solution:
        external_values = {}
        with open(args.decision_solution, "rt", encoding="utf-8", errors="replace") as handle:
            for raw in handle:
                fields = raw.split()
                if len(fields) < 2 or fields[0].startswith("#"):
                    continue
                try:
                    external_values[fields[0]] = Fraction(fields[1])
                except ValueError:
                    continue

        compact_row_violations = []
        for con in reduced.getConstrs():
            expr = reduced.getRow(con)
            lhs = sum(
                F(expr.getCoeff(k))
                * external_values.get(expr.getVar(k).VarName, Fraction(0))
                for k in range(expr.size())
            )
            rhs = F(con.RHS)
            if not (
                lhs == rhs if con.Sense == "="
                else lhs <= rhs if con.Sense == "<"
                else lhs >= rhs
            ):
                compact_row_violations.append(
                    (con.ConstrName, str(lhs), con.Sense, str(rhs))
                )
        print(
            "external compact solution variables",
            len(external_values),
            "row violations",
            len(compact_row_violations),
        )
        if compact_row_violations:
            print("first compact violations", compact_row_violations[:20])
            raise RuntimeError("external compact solution violates decision model")

        def decision_value(variable):
            return external_values.get(variable.VarName, Fraction(0))

        decision_available = True
    else:
        reduced.optimize()
        print(
            "decision target", args.decision_target,
            "status", reduced.Status,
            "runtime", reduced.Runtime,
            "nodes", reduced.NodeCount,
        )

        def decision_value(variable):
            return variable.X

        decision_available = bool(reduced.SolCount)

    if decision_available:
        chosen0 = [i for i in decision_items if decision_value(color[i]) > Fraction(1, 2)]
        match0_value = sum(
            decision_value(variable) for variable in arc0.values()
        )
        match5_value = sum(
            decision_value(variable) for variable in arc5.values()
        )
        cost0_value = sum(invariant[i][2] for i in chosen0)
        load0_value = cost0_value + 10 * (
            endpoint_chain_length - 1 - match0_value
        )
        load5_value = base_cost - cost0_value + 10 * (
            endpoint_chain_length - 3 - match5_value
        )
        print(
            "decision feasible chosen0", len(chosen0),
            "match0", match0_value,
            "match5", match5_value,
        )
        print("decision loads", load0_value, load5_value)

        def selected_paths(items_here, arc_variables):
            item_set = set(items_here)
            successor = {}
            predecessor = {}
            for (i, j), variable in arc_variables.items():
                if decision_value(variable) > Fraction(1, 2):
                    if i not in item_set or j not in item_set:
                        raise RuntimeError("selected compatibility arc crosses colors")
                    successor[i] = j
                    predecessor[j] = i
            starts_here = sorted(item_set - set(predecessor))
            paths_here = []
            covered = set()
            for start in starts_here:
                path = []
                current = start
                while current in item_set:
                    if current in covered:
                        raise RuntimeError("selected compatibility arcs contain a cycle")
                    covered.add(current)
                    path.append(current)
                    if current not in successor:
                        break
                    current = successor[current]
                paths_here.append(path)
            if covered != item_set:
                raise RuntimeError("selected paths fail to cover their color")
            return paths_here

        chosen5 = sorted(set(decision_items) - set(chosen0))
        decision_paths = {
            0: selected_paths(chosen0, arc0),
            5: selected_paths(chosen5, arc5),
        }
        print("decision path counts", {m: len(decision_paths[m]) for m in (0, 5)})

        # Machine 0 is one full occupied segment. Machine 5 contains the sole
        # empty slot between its first path and its remaining paths, thereby
        # realizing two nonempty occupied segments.
        planned_items = {
            0: [item for path in decision_paths[0] for item in path],
            5: decision_paths[5][0] + [None] + [item for path in decision_paths[5][1:] for item in path],
        }
        if (
            len(planned_items[0]) != endpoint_chain_length
            or len(planned_items[5]) != endpoint_chain_length
        ):
            raise RuntimeError("decision paths do not fill the endpoint chains")

        decision_values = [public.get(j, Fraction(0)) for j in range(len(variables))]
        for j in assignment:
            if item_of[j] in forced_set:
                decision_values[j] = Fraction(0)
        decision_item_at_slot = {}
        for machine in (0, 5):
            for item, slot in zip(planned_items[machine], chain_slots[machine]):
                if item is None:
                    continue
                j = assignment_by_item_slot[(item, slot)]
                decision_values[j] = Fraction(1)
                decision_item_at_slot[slot] = item
        for z, support in or_support.items():
            decision_values[z] = Fraction(int(any(decision_values[j] == 1 for j in support)))

        for machine in (0, 5):
            chain = chain_slots[machine]
            for slot in chain:
                u, v = slot_nodes[slot]
                item = decision_item_at_slot.get(slot)
                if item is None:
                    decision_values[u] = Fraction(0)
                    decision_values[v] = Fraction(0)
                else:
                    U, L, _ = invariant[item]
                    decision_values[u] = U
                    decision_values[v] = L
            for previous, following in zip(chain, chain[1:]):
                z = edge_var[(previous, following)]
                previous_item = decision_item_at_slot.get(previous)
                following_item = decision_item_at_slot.get(following)
                _, previous_v = slot_nodes[previous]
                following_u, _ = slot_nodes[following]
                if previous_item is None:
                    common = decision_values[following_u]
                    decision_values[previous_v] = common
                    decision_values[z] = Fraction(0)
                elif following_item is None:
                    common = decision_values[previous_v]
                    decision_values[following_u] = common
                    decision_values[z] = Fraction(0)
                else:
                    _, previous_L, _ = invariant[previous_item]
                    following_U, _, _ = invariant[following_item]
                    if previous_L <= following_U:
                        decision_values[previous_v] = previous_L
                        decision_values[following_u] = previous_L
                        decision_values[z] = Fraction(0)
                    else:
                        decision_values[previous_v] = previous_L
                        decision_values[following_u] = following_U
                        decision_values[z] = Fraction(1)

        decision_loads = [
            beta + sum(coefficient * decision_values[j] for j, coefficient in cost.items())
            for _, beta, cost in loads
        ]
        decision_objective = max(decision_loads)
        decision_values[objective_var] = decision_objective
        decision_violations = []
        for ri, (sense, rhs, terms) in enumerate(rows):
            lhs = sum(a * decision_values[j] for j, a in terms)
            if not holds(sense, lhs, rhs):
                decision_violations.append((ri, constraints[ri].ConstrName, str(lhs), sense, str(rhs)))
        print("lifted decision loads", [str(value) for value in decision_loads])
        print("lifted decision objective", decision_objective, "row violations", len(decision_violations))
        if decision_violations:
            print("first lifted decision violations", decision_violations[:20])
            raise RuntimeError("lifted decision solution failed exact row validation")
        with open(args.solution_out, "w", encoding="utf-8") as handle:
            handle.write(f"=obj= {decision_objective}\n")
            for j, value in enumerate(decision_values):
                if value:
                    handle.write(f"{variables[j].VarName} {value}\n")
        print("lifted validated decision solution written", args.solution_out)


if __name__ == "__main__":
    main()
