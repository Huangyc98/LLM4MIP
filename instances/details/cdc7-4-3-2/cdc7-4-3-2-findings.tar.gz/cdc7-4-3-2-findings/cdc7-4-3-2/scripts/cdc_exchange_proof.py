#!/usr/bin/env python3
"""Prove small exchange-neighborhood optimality for cdc7-4-3-2."""

from __future__ import annotations

import argparse
import collections
from pathlib import Path

import gurobipy as gp


def read_solution(path: Path) -> dict[str, float]:
    values: dict[str, float] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        fields = line.split()
        if len(fields) == 2 and fields[0].startswith("x"):
            values[fields[0]] = float(fields[1])
    return values


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--max-remove", type=int, default=2)
    args = parser.parse_args()

    model = gp.read(str(args.mps))
    model.update()
    variables = model.getVars()
    index = {variable.VarName: position for position, variable in enumerate(variables)}
    values = read_solution(args.solution)
    selected = {index[name] for name, value in values.items() if value > 0.5}

    rows_of: list[set[int]] = [set() for _ in variables]
    selected_conflicts: list[set[int]] = [set() for _ in variables]
    for row_index, constraint in enumerate(model.getConstrs()):
        row = model.getRow(constraint)
        members = [index[row.getVar(term).VarName] for term in range(row.size())]
        chosen = [member for member in members if member in selected]
        if len(chosen) > 1:
            raise ValueError(f"Supplied solution violates clique row {constraint.ConstrName}")
        for member in members:
            rows_of[member].add(row_index)
            if chosen and member not in selected:
                selected_conflicts[member].add(chosen[0])

    unselected = [position for position in range(len(variables)) if position not in selected]
    distribution = collections.Counter(len(selected_conflicts[position]) for position in unselected)
    print(
        f"variables={len(variables)} selected={len(selected)} rows={model.NumConstrs} "
        f"conflict_count_distribution={dict(sorted(distribution.items()))}"
    )

    def compatible(left: int, right: int) -> bool:
        return rows_of[left].isdisjoint(rows_of[right])

    # Search an improving exchange: remove at most r selected codewords and add
    # r+1 mutually compatible unselected codewords whose conflicts are removed.
    for remove_limit in range(args.max_remove + 1):
        candidates = [
            position for position in unselected if len(selected_conflicts[position]) <= remove_limit
        ]
        target = remove_limit + 1
        witness: list[int] | None = None

        def search(chosen: list[int], possible: list[int], removed: set[int]) -> None:
            nonlocal witness
            if witness is not None:
                return
            if len(chosen) == target:
                witness = list(chosen)
                return
            if len(chosen) + len(possible) < target:
                return
            for offset, candidate in enumerate(possible):
                new_removed = removed | selected_conflicts[candidate]
                if len(new_removed) > remove_limit:
                    continue
                tail = [
                    other
                    for other in possible[offset + 1 :]
                    if compatible(candidate, other)
                ]
                search(chosen + [candidate], tail, new_removed)
                if witness is not None:
                    return

        search([], candidates, set())
        if witness is None:
            print(
                f"PROVED no improving exchange with removed<={remove_limit}, "
                f"added={target}, candidates={len(candidates)}"
            )
        else:
            removed = set().union(*(selected_conflicts[position] for position in witness))
            print(
                f"FOUND exchange removed={len(removed)} added={len(witness)} "
                f"remove_names={[variables[p].VarName for p in sorted(removed)]} "
                f"add_names={[variables[p].VarName for p in witness]}"
            )
            break


if __name__ == "__main__":
    main()
