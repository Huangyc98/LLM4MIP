# ivu06 effort ledger

- Research start: 2026-09-09 02:44:00 +08:00.
- 02:44-02:50: read-only Gurobi structural extraction from the original MPS.
- 02:47-02:53: official MIPLIB and related-method background research.
- 02:51-02:54: official incumbent download and independent original-MPS audit.
  The 114-column support covers all 1,177 rows exactly once and recomputes to
  142.864331576 with zero row, bound, and integrality violation.
- Correction: the sparse solution contains 113 selected columns; 114 was the
  parser's initial entry count including its objective header.
- 02:54-03:05: first API method-design request hit gateway 524; the failed
  response was not committed. A shorter stateful segment succeeded.
- 03:05-03:14: API-generated read-only duplicate and Lagrangian diagnostic.
  It found 15,320 duplicate columns beyond 771,919 distinct supports and a
  weak globally valid floating dual bound 98.6693190713.
- 03:14-03:17: exact incumbent-owner exchange search. All 113 singleton and
  6,328 pair subsets plus 11,404 observed triple subsets were completed with
  unrestricted replacement cardinality inside each repair; no improvement.
- 03:17-03:30: API chose a single LP-dual baseline over larger blind local
  neighborhoods and generated the experiment.
- 03:30: the LP relaxation closed at 135.90135263152175. Full-column dual
  repair gave floating lower bound 135.90024288020211; reduced-cost fixing
  removed only 1,177 additional columns.
- 03:31-03:42: API generated an exact rational checker. Static and execution
  audits rejected its first parser and then exposed scientific-notation
  handling. The corrected streaming checker parsed the original gzip without
  Gurobi, audited all 8,032,303 entries, and proved exact rational lower bound
  135.900242315.
- Research end: 2026-09-09 03:45:00 +08:00 (61 minutes).
- Generic solver optimization: one LP solve lasting seconds; below 30 minutes.
- Correction: the sparse solution contains 113 selected columns; 114 was the
  parser's initial entry count including its objective header.
- 02:54-03:05: first API method-design request hit gateway 524; the failed
  response was not committed. A shorter stateful segment succeeded.
- 03:05-03:14: API-generated read-only duplicate and Lagrangian diagnostic.
  It found 15,320 duplicate columns beyond 771,919 distinct supports and a
  weak globally valid floating dual bound 98.6693190713.
- 03:14-03:17: exact incumbent-owner exchange search. All 113 singleton and
  6,328 pair subsets plus 11,404 observed triple subsets were completed with
  unrestricted replacement cardinality inside each repair; no improvement.
- 03:17-03:30: API chose a single LP-dual baseline over larger blind local
  neighborhoods, generated the experiment, and incorporated failed/empty
  gateway segments without committing them.
- 03:30: the LP relaxation closed at 135.90135263152175. Full-column dual
  repair gave floating lower bound 135.90024288020211; reduced-cost fixing
  removed only 1,177 additional columns.
- 03:31-03:42: API generated an exact rational checker. Static and execution
  audits rejected its first parser (NAME/MARKER/RHS handling, excessive
  memory) and then exposed scientific-notation handling. The corrected
  streaming checker parsed the original gzip without Gurobi, audited all
  8,032,303 entries, and proved exact rational lower bound 135.900242315.
- Correction: the sparse solution contains 113 selected columns; 114 was the
  parser's initial entry count including its objective header.
- 02:54-03:05: first API method-design request hit gateway 524; the failed
  response was not committed. A shorter stateful segment succeeded.
- 03:05-03:14: API-generated read-only duplicate and Lagrangian diagnostic.
  It found 15,320 duplicate columns beyond 771,919 distinct supports and a
  weak globally valid floating dual bound 98.6693190713.
- 03:14-03:17: exact incumbent-owner exchange search. All 113 singleton and
  6,328 pair subsets plus 11,404 observed triple subsets were completed with
  unrestricted replacement cardinality inside each repair; no improvement.
- 03:17-03:30: API chose a single LP-dual baseline over larger blind local
  neighborhoods, generated the experiment, and incorporated failed/empty
  gateway segments without committing them.
- 03:30: the LP relaxation closed at 135.90135263152175. Full-column dual
  repair gave floating lower bound 135.90024288020211; reduced-cost fixing
  removed only 1,177 additional columns.
- 03:31-03:42: API generated an exact rational checker. Static and execution
  audits rejected its first parser (NAME/MARKER/RHS handling, excessive
  memory) and then exposed scientific-notation handling. The corrected
  streaming checker parsed the original gzip without Gurobi, audited all
  8,032,303 entries, and proved exact rational lower bound 135.900242315.
