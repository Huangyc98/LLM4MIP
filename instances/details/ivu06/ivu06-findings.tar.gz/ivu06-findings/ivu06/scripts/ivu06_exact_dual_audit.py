#!/usr/bin/env python3

import argparse
import gzip
import hashlib
import json
import math
import os
import re
import sys
from collections import OrderedDict
from decimal import Decimal, InvalidOperation, ROUND_FLOOR, localcontext


SCALE = 1_000_000_000
EXPECTED_ROWS = 1177
EXPECTED_COLUMNS = 787239
EXPECTED_MATRIX_ENTRIES = 8032303
DEFAULT_INCUMBENT = "142.864331576"

PLAIN_DECIMAL = re.compile(
    r"^[+-]?(?:(?:\d+(?:\.\d*)?)|(?:\.\d+))(?:[eE][+-]?\d+)?$"
)
SECTION_HEADERS = {
    "ROWS",
    "COLUMNS",
    "RHS",
    "RANGES",
    "BOUNDS",
    "SOS",
    "ENDATA",
    "OBJSENSE",
    "OBJNAME",
}


class AuditError(Exception):
    pass


def fail(message):
    raise AuditError(message)


def unquote(token):
    if len(token) >= 2 and token[0] == token[-1] and token[0] in "'\"":
        return token[1:-1]
    return token


def parse_decimal(token, label):
    if not PLAIN_DECIMAL.fullmatch(token):
        fail("%s is not a plain decimal: %r" % (label, token))
    try:
        value = Decimal(token)
    except InvalidOperation:
        fail("invalid decimal for %s: %r" % (label, token))
    if not value.is_finite():
        fail("non-finite decimal for %s" % label)
    return value


def scaled_exact(token, label, max_places=None):
    value = parse_decimal(token, label)
    if max_places is not None:
        places = max(0, -value.as_tuple().exponent)
        if places > max_places:
            fail("%s has more than %d decimal places" %
                 (label, max_places))
    scaled = value * Decimal(SCALE)
    integral = scaled.to_integral_value()
    if scaled != integral:
        fail("%s is not exactly representable with denominator 1e9" % label)
    return int(integral)


def scaled_floor(token, label):
    value = parse_decimal(token, label)
    with localcontext() as ctx:
        ctx.prec = max(100, len(token) + 50)
        scaled = value * Decimal(SCALE)
        return int(scaled.to_integral_value(rounding=ROUND_FLOOR))


def open_text(path):
    if path.endswith(".gz"):
        return gzip.open(path, "rt", encoding="utf-8", newline=None)
    return open(path, "r", encoding="utf-8", newline=None)


def read_dual(path):
    records = []
    with open(path, "r", encoding="utf-8", newline=None) as stream:
        for line_no, raw in enumerate(stream, 1):
            line = raw.rstrip("\r\n")
            if not line or line.startswith("#"):
                continue
            parts = line.split("\t")
            if len(parts) != 4:
                fail("dual line %d must have four tab-separated fields" %
                     line_no)
            try:
                index = int(parts[0])
            except ValueError:
                fail("dual line %d has an invalid row index" % line_no)
            if index < 0:
                fail("dual line %d has a negative row index" % line_no)
            if not parts[1]:
                fail("dual line %d has an empty row name" % line_no)
            repaired = scaled_floor(
                parts[3], "repaired dual on line %d" % line_no
            )
            records.append((index, parts[1], repaired))

    if len(records) != EXPECTED_ROWS:
        fail("dual row count is %d, expected %d" %
             (len(records), EXPECTED_ROWS))

    return records


def is_header(parts):
    return len(parts) == 1 and parts[0].upper() in SECTION_HEADERS


def audit_mps(path, dual_records, incumbent_token):
    row_names = []
    row_index = {}
    row_incidence = []
    objective_row = None

    section = None
    objective_sense = None
    rhs_set = None
    rhs_seen = set()
    saw_endata = False
    integer_mode = False

    current_name = None
    current_cost = None
    current_rows = []
    current_row_set = set()

    column_count = 0
    matrix_count = 0
    min_slack = None
    min_slack_column = None

    column_hash = hashlib.sha256()
    slack_hash = hashlib.sha256()

    def finalize_column():
        nonlocal current_name, current_cost, current_rows
        nonlocal current_row_set, column_count, matrix_count
        nonlocal min_slack, min_slack_column

        if current_name is None:
            return
        if not integer_mode:
            fail("column %s is outside INTORG/INTEND markers" %
                 current_name)
        if current_cost is None:
            fail("column %s has no objective cost" % current_name)
        if not current_rows:
            fail("column %s is empty" % current_name)
        if len(current_rows) > 20:
            fail("column %s has more than 20 row entries" % current_name)

        row_sum = sum(dual_records[i][2] for i in current_rows)
        slack = current_cost - row_sum

        if min_slack is None or slack < min_slack:
            min_slack = slack
            min_slack_column = current_name

        column_hash.update(
            ("%d\t%s\t%d\n" %
             (column_count, current_name, current_cost)).encode("utf-8")
        )
        slack_hash.update(
            ("%d\t%d\n" % (column_count, slack)).encode("utf-8")
        )

        column_count += 1
        matrix_count += len(current_rows)
        current_name = None
        current_cost = None
        current_rows = []
        current_row_set = set()

    def process_columns(parts, line_no):
        nonlocal current_name, current_cost, current_rows
        nonlocal current_row_set, matrix_count, integer_mode

        if len(parts) == 3 and unquote(parts[1]).upper() == "MARKER":
            finalize_column()
            marker = unquote(parts[2]).upper()
            if marker == "INTORG":
                if integer_mode:
                    fail("nested INTORG marker at line %d" % line_no)
                integer_mode = True
            elif marker == "INTEND":
                if not integer_mode:
                    fail("INTEND without INTORG at line %d" % line_no)
                integer_mode = False
            else:
                fail("unknown marker %r at line %d" % (marker, line_no))
            return

        if len(parts) not in (3, 5):
            fail("malformed COLUMNS record at line %d" % line_no)

        name = parts[0]
        if current_name is None:
            current_name = name
        elif name != current_name:
            finalize_column()
            current_name = name

        pairs = [(parts[1], parts[2])]
        if len(parts) == 5:
            pairs.append((parts[3], parts[4]))

        for referenced_row, value_token in pairs:
            value = parse_decimal(
                value_token,
                "COLUMNS value at line %d" % line_no
            )
            if referenced_row == objective_row:
                if current_cost is not None:
                    fail("duplicate objective entry for column %s" %
                         current_name)
                if value <= Decimal("0"):
                    fail("nonpositive objective cost for column %s" %
                         current_name)
                current_cost = scaled_exact(
                    value_token,
                    "objective cost for column %s" % current_name,
                    max_places=9,
                )
            else:
                if referenced_row not in row_index:
                    fail("unknown matrix row %s at line %d" %
                         (referenced_row, line_no))
                if value != Decimal("1"):
                    fail("matrix coefficient is not exactly +1 at line %d" %
                         line_no)
                if referenced_row in current_row_set:
                    fail("duplicate row %s in column %s" %
                         (referenced_row, current_name))
                if len(current_rows) >= 20:
                    fail("column %s has more than 20 entries" %
                         current_name)
                current_row_set.add(referenced_row)
                current_rows.append(row_index[referenced_row])
                row_incidence[row_index[referenced_row]] += 1

    with open_text(path) as stream:
        for line_no, raw in enumerate(stream, 1):
            stripped = raw.strip()
            if not stripped or stripped.startswith("*"):
                continue
            parts = stripped.split()
            upper_first = parts[0].upper()

            if saw_endata:
                fail("data appears after ENDATA at line %d" % line_no)

            if upper_first == "NAME":
                if section is not None and section != "NAME":
                    fail("NAME appears after data at line %d" % line_no)
                if len(parts) < 2:
                    fail("malformed NAME record at line %d" % line_no)
                section = "NAME"
                continue

            if is_header(parts):
                header = parts[0].upper()
                if header == "ENDATA":
                    if current_name is not None:
                        finalize_column()
                    if integer_mode:
                        fail("ENDATA reached before INTEND")
                    saw_endata = True
                    section = "ENDATA"
                else:
                    if header == "RANGES":
                        fail("RANGES section is unsupported")
                    if header == "BOUNDS":
                        if current_name is not None:
                            finalize_column()
                        if integer_mode:
                            fail("BOUNDS reached before INTEND")
                    section = header
                continue

            if section == "NAME":
                fail("unexpected record in NAME section at line %d" %
                     line_no)

            if section == "ROWS":
                if len(parts) != 2 or parts[0].upper() not in ("N", "E"):
                    fail("malformed or unsupported ROWS record at line %d" %
                         line_no)
                row_type = parts[0].upper()
                name = parts[1]
                if name in row_index or name == objective_row:
                    fail("duplicate row name %s" % name)
                if row_type == "N":
                    if objective_row is not None:
                        fail("multiple objective rows")
                    objective_row = name
                else:
                    row_index[name] = len(row_names)
                    row_names.append(name)
                    row_incidence.append(0)
                continue

            if section == "OBJSENSE":
                if len(parts) != 1 or parts[0].upper() != "MIN":
                    fail("objective sense is not MIN")
                objective_sense = "MIN"
                continue

            if section == "OBJNAME":
                if len(parts) != 2:
                    fail("malformed OBJNAME record at line %d" % line_no)
                continue

            if section == "COLUMNS":
                process_columns(parts, line_no)
                continue

            if section == "RHS":
                if len(parts) not in (3, 5):
                    fail("malformed RHS record at line %d" % line_no)
                set_name = parts[0]
                if rhs_set is None:
                    rhs_set = set_name
                elif rhs_set != set_name:
                    fail("multiple RHS sets")
                pairs = [(parts[1], parts[2])]
                if len(parts) == 5:
                    pairs.append((parts[3], parts[4]))
                for name, token in pairs:
                    if name not in row_index:
                        fail("RHS references non-equality row %s" % name)
                    if parse_decimal(token, "RHS at line %d" % line_no) != Decimal("1"):
                        fail("RHS for row %s is not exactly +1" % name)
                    if name in rhs_seen:
                        fail("duplicate RHS for row %s" % name)
                    rhs_seen.add(name)
                continue

            if section == "BOUNDS":
                fail("BOUNDS contains data at line %d" % line_no)

            fail("unexpected record at line %d in section %r" %
                 (line_no, section))

    if not saw_endata:
        fail("ENDATA was not reached")
    if current_name is not None:
        fail("internal column-finalization error")
    if objective_row is None:
        fail("no objective row")
    if objective_sense not in (None, "MIN"):
        fail("objective sense mismatch")
    if len(row_names) != EXPECTED_ROWS:
        fail("row count is %d, expected %d" %
             (len(row_names), EXPECTED_ROWS))
    if column_count != EXPECTED_COLUMNS:
        fail("column count is %d, expected %d" %
             (column_count, EXPECTED_COLUMNS))
    if matrix_count != EXPECTED_MATRIX_ENTRIES:
        fail("matrix entry count is %d, expected %d" %
             (matrix_count, EXPECTED_MATRIX_ENTRIES))
    if len(rhs_seen) != EXPECTED_ROWS or rhs_seen != set(row_names):
        fail("RHS rows do not exactly match equality rows")
    if any(x == 0 for x in row_incidence):
        missing = row_names[row_incidence.index(0)]
        fail("row %s never occurs in a column" % missing)
    if min_slack is None:
        fail("no columns were audited")

    incumbent_int = scaled_exact(
        incumbent_token, "incumbent", max_places=9
    )
    dual_numerator = sum(x[2] for x in dual_records)
    threshold_numerator = incumbent_int - dual_numerator
    gcd_value = math.gcd(abs(dual_numerator), SCALE)

    return OrderedDict([
        ("format", "exact-rational-dual-audit-v2"),
        ("mps", os.path.abspath(path)),
        ("rows", len(row_names)),
        ("columns", column_count),
        ("matrix_entries", matrix_count),
        ("objective_row", objective_row),
        ("objective_sense", "MIN"),
        ("rhs_exactly_plus_one", True),
        ("matrix_coefficients_exactly_plus_one", True),
        ("all_columns_inside_integer_markers", True),
        ("objective_costs_positive_and_at_most_nine_decimals", True),
        ("dual_denominator", SCALE),
        ("dual_numerator_unreduced", dual_numerator),
        ("lower_bound_numerator_reduced", dual_numerator // gcd_value),
        ("lower_bound_denominator_reduced", SCALE // gcd_value),
        ("minimum_integer_slack", min_slack),
        ("minimum_slack_column", min_slack_column),
        ("all_dual_inequalities_verified", True),
        ("incumbent_numerator", incumbent_int),
        ("incumbent_denominator", SCALE),
        ("exact_threshold_U_minus_L_numerator", threshold_numerator),
        ("exact_threshold_U_minus_L_denominator", SCALE),
        ("column_order_sha256", column_hash.hexdigest()),
        ("slack_vector_sha256", slack_hash.hexdigest()),
        ("global_bound_reason",
         "All original columns satisfy cost_int - sum(row_dual_int) >= 0; "
         "therefore the dual objective is a global lower bound for every "
         "nonnegative feasible solution, including every binary solution."),
        ("optimality_caveat",
         "The lower bound is not an optimality proof because it is below the "
         "supplied incumbent; floating-point provenance is not used here, but "
         "the MPS decimal representation and denominator-1e9 rounding define "
         "the audited rational dual."),
    ])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mps_gz")
    parser.add_argument("row_dual_text")
    parser.add_argument("--out", default=None)
    parser.add_argument("--incumbent", default=DEFAULT_INCUMBENT)
    args = parser.parse_args()

    try:
        dual = read_dual(args.row_dual_text)
        certificate = audit_mps(args.mps_gz, dual, args.incumbent)
        output = args.out or (
            os.path.splitext(args.row_dual_text)[0] + ".exact.json"
        )
        with open(output, "w", encoding="utf-8") as stream:
            json.dump(certificate, stream, separators=(",", ":"))
            stream.write("\n")
        print(json.dumps(certificate, separators=(",", ":")))
        return 0
    except (AuditError, OSError, ValueError) as exc:
        print(json.dumps({
            "status": "FAILED_CLOSED",
            "error": str(exc),
            "global_bound": "not established",
            "optimality": "not established",
        }, separators=(",", ":")))
        return 1


if __name__ == "__main__":
    sys.exit(main())
