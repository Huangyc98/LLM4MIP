#!/usr/bin/env python3
"""
ivu06 incumbent-centered exact-exchange diagnostic.

This program:

1. Reads the original MPS without calling any optimization routine.
2. Reads a public MIPLIB .sol or .sol.gz file.
3. Independently validates the incumbent support.
4. Audits every exact equal-support group, retaining its cheapest member.
5. Reports all incumbent changes implied by safe duplicate deletion.
6. Builds incumbent-owner masks for all non-incumbent columns.
7. Exhaustively searches relevant owner-pair repairs:
       - all singleton columns and exact owner-pair columns,
       - replacement covers of arbitrary cardinality,
       - strict objective improvement only.
8. Searches owner triples subject to --max-triples and --time-limit.
9. Revalidates every improving witness against the complete original model.
10. Writes the best witness as a sparse MIPLIB-style .sol file.

No generic LP or MIP optimizer is called.

Neighborhood semantics:

For an incumbent partition, each row has one incumbent owner column.
A non-incumbent column has an owner mask containing every incumbent owner
whose rows it touches.

For owner subset S, the repair neighborhood consists of every active
non-incumbent column whose owner mask is a nonempty subset of S. A repair is
accepted only when its columns cover every row owned by S exactly once and
touch no row owned outside S. Replacement cardinality is unrestricted.

Pair search is attempted for every owner pair for which at least one relevant
candidate column exists, subject to the global time limit.

Triple search is attempted for observed owner triples, up to --max-triples.
Therefore, if the time limit or triple cap is reached, absence of an
improvement is only absence within the completed neighborhood; it is not a
global optimality claim.

Example:
    python ivu06_exchange.py ivu06.mps public.sol.gz \
        --json ivu06_exchange.json \
        --witness ivu06_best.sol \
        --time-limit 1800 \
        --max-triples 50000
"""

import argparse
import array
import gzip
import hashlib
import itertools
import json
import math
import os
import sys
import time

import gurobipy as gp


def open_text(path):
    if path.endswith(".gz"):
        return gzip.open(path, "rt")
    return open(path, "r")


def popcount(x):
    return x.bit_count()


def load_solution(path, name_to_index, ncol):
    """
    Parse common sparse MIPLIB/Gurobi solution formats.

    Lines are expected to contain:
        variable_name value

    Header, comment, objective, and unrecognized lines are ignored.
    """
    values = {}
    unknown = 0
    malformed = 0

    with open_text(path) as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue

            parts = line.replace("=", " ").split()
            if len(parts) < 2:
                continue

            name = parts[0]
            try:
                value = float(parts[1])
            except ValueError:
                malformed += 1
                continue

            if name not in name_to_index:
                unknown += 1
                continue

            values[name_to_index[name]] = value

    support = [j for j, value in values.items() if value > 0.5]

    return {
        "support": support,
        "values_read": len(values),
        "unknown_names": unknown,
        "malformed_lines": malformed,
    }


def canonical_hash(rows):
    return hashlib.blake2b(
        array.array("I", rows).tobytes(),
        digest_size=16,
    ).digest()


def validate_support(
    support,
    col_offsets,
    col_rows,
    costs,
    nrow,
):
    selected = bytearray(len(costs))
    row_counts = array.array("H", [0]) * nrow
    objective = 0.0
    errors = []

    for j in support:
        if j < 0 or j >= len(costs):
            errors.append("column index out of range: %d" % j)
            continue

        if selected[j]:
            errors.append("duplicate selected column index: %d" % j)
            continue

        selected[j] = 1
        objective += costs[j]

        start = col_offsets[j]
        end = col_offsets[j + 1]
        for q in range(start, end):
            row_counts[col_rows[q]] += 1

    uncovered = []
    multiply_covered = []

    for i, count in enumerate(row_counts):
        if count == 0:
            uncovered.append(i)
        elif count != 1:
            multiply_covered.append((i, int(count)))

    return {
        "selected": selected,
        "row_counts": row_counts,
        "objective": objective,
        "support_size": len(support),
        "uncovered_rows": uncovered,
        "multiply_covered_rows": multiply_covered,
        "valid": (
            not errors
            and not uncovered
            and not multiply_covered
        ),
        "errors": errors,
    }


def full_validate(
    selected_indices,
    nrow,
    costs,
    col_offsets,
    col_rows,
):
    """
    Reconstruct a complete binary vector and evaluate every original row.

    This does not rely on incumbent-owner bookkeeping.
    """
    ncol = len(costs)
    vector = bytearray(ncol)
    row_counts = array.array("H", [0]) * nrow
    objective = 0.0
    errors = []

    for j in selected_indices:
        if j < 0 or j >= ncol:
            errors.append("candidate column index out of range: %d" % j)
            continue
        if vector[j]:
            errors.append("candidate column selected twice: %d" % j)
            continue

        vector[j] = 1
        objective += costs[j]

        start = col_offsets[j]
        end = col_offsets[j + 1]
        for q in range(start, end):
            row_counts[col_rows[q]] += 1

    bad_rows = []
    for i, count in enumerate(row_counts):
        if count != 1:
            bad_rows.append((i, int(count)))

    return {
        "vector": vector,
        "row_counts": row_counts,
        "objective": objective,
        "bad_rows": bad_rows,
        "errors": errors,
        "valid": not errors and not bad_rows,
    }


def write_solution(path, selected, names):
    with open(path, "w") as f:
        for j in selected:
            f.write("%s 1\n" % names[j])


def solve_exact_repair(
    owner_ids,
    candidate_indices,
    col_offsets,
    col_rows,
    costs,
    base_cost,
    incumbent_owner_cost,
    deadline,
    node_limit,
):
    """
    Solve one exact-cover repair by bounded exhaustive enumeration.

    owner_ids is a tuple of incumbent owners to remove.
    candidate_indices contains all non-incumbent candidates whose owner mask
    is a subset of the owner subset.

    Every candidate is required to have positive cost. A candidate costing at
    least the entire removed incumbent cost cannot participate in a strict
    improvement and is discarded.

    Returns:
        None if no improvement was found or the search was interrupted.
        (replacement_indices, objective) otherwise.
    """
    if time.monotonic() >= deadline:
        return None

    vacated = []
    owner_set = set(owner_ids)

    for owner in owner_ids:
        vacated.extend(owner_rows[owner])

    if not vacated:
        return None

    # Row-to-local-position mapping is per owner subset, not per MPS column.
    row_pos = {row: k for k, row in enumerate(vacated)}
    nlocal = len(vacated)

    cutoff = incumbent_owner_cost
    usable = []

    for j in candidate_indices:
        c = costs[j]
        if c >= cutoff - 1.0e-12:
            continue

        start = col_offsets[j]
        end = col_offsets[j + 1]
        local_rows = []

        valid = True
        for q in range(start, end):
            row = col_rows[q]
            pos = row_pos.get(row)
            if pos is None:
                valid = False
                break
            local_rows.append(pos)

        if valid and local_rows:
            usable.append((j, c, tuple(local_rows)))

    if not usable:
        return None

    row_candidates = [[] for _ in range(nlocal)]

    for k, item in enumerate(usable):
        _, _, local_rows = item
        for pos in local_rows:
            row_candidates[pos].append(k)

    # Low-cost candidates first tends to find an improving witness quickly,
    # while the recursion remains exhaustive until the deadline/node limit.
    for candidates in row_candidates:
        candidates.sort(key=lambda k: usable[k][1])

    covered = bytearray(nlocal)
    chosen = []
    best = None
    best_cost = cutoff
    nodes = 0
    interrupted = False

    def recurse(covered_count, current_cost):
        nonlocal best, best_cost, nodes, interrupted

        if interrupted:
            return

        nodes += 1
        if nodes > node_limit or time.monotonic() >= deadline:
            interrupted = True
            return

        if current_cost >= best_cost - 1.0e-12:
            return

        if covered_count == nlocal:
            if current_cost < best_cost - 1.0e-12:
                best_cost = current_cost
                best = list(chosen)
            return

        # Choose an uncovered row with the fewest currently feasible
        # candidates. This is standard exact-cover branching, implemented
        # directly without a generic optimizer.
        selected_pos = -1
        selected_options = None

        for pos in range(nlocal):
            if covered[pos]:
                continue

            options = []
            for k in row_candidates[pos]:
                j, c, local_rows = usable[k]

                if current_cost + c >= best_cost - 1.0e-12:
                    continue

                feasible = True
                for other_pos in local_rows:
                    if covered[other_pos]:
                        feasible = False
                        break

                if feasible:
                    options.append(k)

            if not options:
                return

            if selected_options is None or len(options) < len(selected_options):
                selected_pos = pos
                selected_options = options
                if len(options) == 1:
                    break

        for k in selected_options:
            j, c, local_rows = usable[k]

            for pos in local_rows:
                covered[pos] = 1
            chosen.append(j)

            recurse(
                covered_count + len(local_rows),
                current_cost + c,
            )

            chosen.pop()
            for pos in local_rows:
                covered[pos] = 0

            if interrupted:
                return

    recurse(0, 0.0)

    if best is None:
        return None

    return best, best_cost


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mps")
    ap.add_argument("solution")
    ap.add_argument("--json", default="ivu06_exchange.json")
    ap.add_argument("--witness", default="ivu06_best.sol")
    ap.add_argument("--time-limit", type=float, default=1800.0)
    ap.add_argument(
        "--max-triples",
        type=int,
        default=50000,
        help="maximum observed owner triples to search",
    )
    ap.add_argument(
        "--node-limit",
        type=int,
        default=250000,
        help="exact-cover recursion node limit per owner subset",
    )
    args = ap.parse_args()

    started = time.monotonic()
    deadline = started + args.time_limit

    model = gp.read(args.mps)
    variables = model.getVars()
    constraints = model.getConstrs()

    ncol = len(variables)
    nrow = len(constraints)

    names = [v.VarName for v in variables]
    name_to_index = {name: j for j, name in enumerate(names)}

    costs = array.array("d")
    col_offsets = array.array("i", [0])
    col_rows = array.array("i")

    bad_coefficients = 0
    bad_rhs = 0
    bad_senses = 0

    for row in constraints:
        if row.Sense != "=":
            bad_senses += 1
        if abs(float(row.RHS) - 1.0) > 1.0e-12:
            bad_rhs += 1

    # Exact-support audit structures.
    #
    # digest_rep contains one representative for every digest. duplicate_groups
    # is created only when an actual repeated support is observed, avoiding one
    # Python list per unique column.
    digest_rep = {}
    duplicate_groups = {}
    digest_collisions = 0

    for j, variable in enumerate(variables):
        costs.append(float(variable.Obj))

        col = model.getCol(variable)
        rows = []

        for k in range(col.size()):
            row = col.getConstr(k)
            coefficient = float(col.getCoeff(k))

            if abs(coefficient - 1.0) > 1.0e-12:
                bad_coefficients += 1

            rows.append(row.index)

        rows.sort()

        digest = canonical_hash(rows)

        if digest not in digest_rep:
            digest_rep[digest] = j
        else:
            representative = digest_rep[digest]
            rep_start = col_offsets[representative]
            rep_end = col_offsets[representative + 1]
            rep_rows = list(col_rows[rep_start:rep_end])

            if rep_rows == rows:
                if digest not in duplicate_groups:
                    duplicate_groups[digest] = [representative]
                duplicate_groups[digest].append(j)
            else:
                digest_collisions += 1
                digest_rep[(digest, j)] = j

        col_rows.extend(rows)
        col_offsets.append(len(col_rows))

    # Read and independently validate the public solution.
    loaded_solution = load_solution(
        args.solution,
        name_to_index,
        ncol,
    )
    public_support = loaded_solution["support"]

    public_check = validate_support(
        public_support,
        col_offsets,
        col_rows,
        costs,
        nrow,
    )

    if not public_check["valid"]:
        raise RuntimeError(
            "public solution is not a valid exact cover: %s"
            % json.dumps({
                "errors": public_check["errors"],
                "uncovered_rows": len(public_check["uncovered_rows"]),
                "multiply_covered_rows": len(
                    public_check["multiply_covered_rows"]
                ),
            })
        )

    # Fully audit duplicate groups and choose one cheapest representative.
    # Equal-cost ties retain the first member. Deleting all other members is
    # safe for finding an optimum because they have identical supports and no
    # lower objective.
    canonical = bytearray(ncol)
    duplicate_audit = []
    safe_deletions = 0
    incumbent_duplicate_changes = []

    for digest, members in duplicate_groups.items():
        cheapest = min(
            members,
            key=lambda j: (costs[j], j),
        )

        for j in members:
            if j == cheapest:
                canonical[j] = 1

        group_costs = [
            {
                "column": j,
                "cost": costs[j],
                "is_cheapest": j == cheapest,
            }
            for j in members
        ]

        deletions = len(members) - 1
        safe_deletions += deletions

        public_members = [j for j in members if public_check["selected"][j]]
        for old in public_members:
            if old != cheapest:
                incumbent_duplicate_changes.append({
                    "old_column": old,
                    "new_column": cheapest,
                    "old_cost": costs[old],
                    "new_cost": costs[cheapest],
                    "objective_change": costs[cheapest] - costs[old],
                    "support_size": col_offsets[old + 1] - col_offsets[old],
                })

        duplicate_audit.append({
            "digest": digest.hex(),
            "members": group_costs,
            "cheapest_column": cheapest,
            "safe_deletions": deletions,
            "incumbent_members": public_members,
        })

    # Unique supports are their own canonical representatives.
    for digest, representative in digest_rep.items():
        if isinstance(digest, tuple):
            continue
        if digest not in duplicate_groups:
            canonical[representative] = 1

    # Normalize the incumbent through exact duplicate representatives. This
    # preserves exact coverage and cannot increase objective.
    normalized_incumbent = []
    normalized_changes = []

    for j in public_support:
        replacement = j

        # Locate the repeated-support group containing j. The number of
        # duplicate groups is small, so this audit lookup is acceptable.
        for members in duplicate_groups.values():
            if j in members:
                replacement = min(members, key=lambda k: (costs[k], k))
                break

        normalized_incumbent.append(replacement)
        if replacement != j:
            normalized_changes.append({
                "old_column": j,
                "new_column": replacement,
                "old_cost": costs[j],
                "new_cost": costs[replacement],
                "objective_change": costs[replacement] - costs[j],
            })

    normalized_incumbent = sorted(set(normalized_incumbent))
    normalized_check = full_validate(
        normalized_incumbent,
        nrow,
        costs,
        col_offsets,
        col_rows,
    )

    if not normalized_check["valid"]:
        raise RuntimeError(
            "duplicate-normalized incumbent failed full validation"
        )

    # Establish the incumbent owner of every row.
    owner_of_row = array.array("i", [-1]) * nrow
    # solve_exact_repair is a module-level function and reads this compact
    # owner partition. Declare it explicitly rather than relying on an
    # accidental local name.
    global owner_rows
    owner_rows = []
    owner_costs = []
    incumbent_set = bytearray(ncol)

    for owner, j in enumerate(normalized_incumbent):
        incumbent_set[j] = 1
        owner_rows.append([])
        owner_costs.append(costs[j])

        start = col_offsets[j]
        end = col_offsets[j + 1]

        for q in range(start, end):
            row = col_rows[q]
            if owner_of_row[row] != -1:
                raise RuntimeError(
                    "normalized incumbent assigns row twice: %d" % row
                )
            owner_of_row[row] = owner
            owner_rows[owner].append(row)

    if any(owner < 0 for owner in owner_of_row):
        raise RuntimeError("normalized incumbent leaves a row uncovered")

    nowner = len(normalized_incumbent)

    # Map each active non-incumbent column to the incumbent owners it touches.
    #
    # Python sets are not used per column. The owner mask is a Python integer,
    # which is compact for 1,177 owners and supports fast subset tests.
    candidate_groups = {}
    candidate_masks = array.array("q") if nowner <= 62 else None

    singleton_owner_columns = {}
    pair_owner_columns = {}
    triple_owner_masks = set()

    considered_columns = 0
    skipped_large_masks = 0

    for j in range(ncol):
        if incumbent_set[j] or not canonical[j]:
            continue

        mask = 0
        start = col_offsets[j]
        end = col_offsets[j + 1]

        for q in range(start, end):
            mask |= 1 << owner_of_row[col_rows[q]]

        degree = popcount(mask)
        if degree == 0:
            continue

        considered_columns += 1

        if degree > 3:
            skipped_large_masks += 1
            continue

        candidate_groups.setdefault(mask, []).append(j)

        if degree == 1:
            owner = (mask & -mask).bit_length() - 1
            singleton_owner_columns.setdefault(owner, []).append(j)
        elif degree == 2:
            pair_owner_columns.setdefault(mask, []).append(j)
        else:
            triple_owner_masks.add(mask)

    # Candidate groups are sorted by increasing cost for deterministic search.
    for group in candidate_groups.values():
        group.sort(key=lambda j: (costs[j], j))

    for group in singleton_owner_columns.values():
        group.sort(key=lambda j: (costs[j], j))

    for group in pair_owner_columns.values():
        group.sort(key=lambda j: (costs[j], j))

    base_selected = set(normalized_incumbent)
    best_selected = list(normalized_incumbent)
    best_objective = normalized_check["objective"]
    best_source = "duplicate-normalized incumbent"

    exchange_log = []
    pair_subsets_attempted = 0
    pair_subsets_completed = 0
    triple_subsets_attempted = 0
    triple_subsets_completed = 0
    interrupted = False

    def mask_to_tuple(mask):
        result = []
        while mask:
            low = mask & -mask
            result.append(low.bit_length() - 1)
            mask ^= low
        return tuple(result)

    def candidates_for_subset(owners):
        """
        Return all active candidate columns whose owner mask is a nonempty
        subset of the requested owner subset.

        Groups are indexed by exact owner mask, so no per-column Python set is
        constructed.
        """
        requested = 0
        for owner in owners:
            requested |= 1 << owner

        result = []
        sub = requested
        while sub:
            if sub in candidate_groups:
                result.extend(candidate_groups[sub])
            sub = (sub - 1) & requested

        return result

    def consider_exchange(owners, replacement, replacement_cost, source):
        nonlocal best_objective, best_selected, best_source

        removed = [normalized_incumbent[o] for o in owners]
        removed_set = set(removed)
        # Every neighborhood is defined relative to the same normalized
        # incumbent/owner partition. Combining it with a prior, unrelated
        # exchange would invalidate the owner bookkeeping.
        selected = [
            j for j in normalized_incumbent
            if j not in removed_set
        ]
        selected.extend(replacement)

        checked = full_validate(
            selected,
            nrow,
            costs,
            col_offsets,
            col_rows,
        )

        if not checked["valid"]:
            return False

        if checked["objective"] >= best_objective - 1.0e-9:
            return False

        # The complete original-vector validation above is the acceptance
        # gate. The selected list is retained only after that validation.
        best_objective = checked["objective"]
        best_selected = sorted(selected)
        best_source = source

        exchange_log.append({
            "owners": list(owners),
            "removed_columns": removed,
            "replacement_columns": list(replacement),
            "removed_cost": sum(costs[j] for j in removed),
            "replacement_cost": replacement_cost,
            "objective": checked["objective"],
            "objective_improvement": (
                normalized_check["objective"] - checked["objective"]
            ),
            "source": source,
        })

        write_solution(args.witness, best_selected, names)
        return True

    # Search all owner pairs, including singleton repairs as a useful subset.
    for owner in range(nowner):
        if time.monotonic() >= deadline:
            interrupted = True
            break

        owners = (owner,)
        candidates = candidates_for_subset(owners)
        if not candidates:
            continue

        pair_subsets_attempted += 1
        removed_cost = owner_costs[owner]

        result = solve_exact_repair(
            owners,
            candidates,
            col_offsets,
            col_rows,
            costs,
            normalized_check["objective"],
            removed_cost,
            deadline,
            args.node_limit,
        )

        if result is None:
            if time.monotonic() >= deadline:
                interrupted = True
                break
            pair_subsets_completed += 1
            continue

        replacement, replacement_cost = result
        pair_subsets_completed += 1
        consider_exchange(
            owners,
            replacement,
            replacement_cost,
            "singleton-owner exact repair",
        )

    if not interrupted:
        for owner_a in range(nowner):
            for owner_b in range(owner_a + 1, nowner):
                if time.monotonic() >= deadline:
                    interrupted = True
                    break

                owners = (owner_a, owner_b)
                candidates = candidates_for_subset(owners)

                if not candidates:
                    continue

                pair_subsets_attempted += 1
                removed_cost = (
                    owner_costs[owner_a]
                    + owner_costs[owner_b]
                )

                result = solve_exact_repair(
                    owners,
                    candidates,
                    col_offsets,
                    col_rows,
                    costs,
                    normalized_check["objective"],
                    removed_cost,
                    deadline,
                    args.node_limit,
                )

                if result is None:
                    if time.monotonic() >= deadline:
                        interrupted = True
                        break
                    pair_subsets_completed += 1
                    continue

                replacement, replacement_cost = result
                pair_subsets_completed += 1
                consider_exchange(
                    owners,
                    replacement,
                    replacement_cost,
                    "owner-pair exact repair",
                )

            if interrupted:
                break

    # Triple search is limited to owner triples actually present in at least
    # one active <=3-owner column. Subsets with no candidate are skipped.
    triple_masks = sorted(
        triple_owner_masks,
        key=lambda mask: (
            min(costs[j] for j in candidate_groups[mask]),
            mask,
        ),
    )

    triples_truncated = len(triple_masks) > args.max_triples
    triple_masks = triple_masks[:args.max_triples]

    if not interrupted:
        for mask in triple_masks:
            if time.monotonic() >= deadline:
                interrupted = True
                break

            owners = mask_to_tuple(mask)
            candidates = candidates_for_subset(owners)
            if not candidates:
                continue

            triple_subsets_attempted += 1
            removed_cost = sum(owner_costs[o] for o in owners)

            result = solve_exact_repair(
                owners,
                candidates,
                col_offsets,
                col_rows,
                costs,
                normalized_check["objective"],
                removed_cost,
                deadline,
                args.node_limit,
            )

            if result is None:
                if time.monotonic() >= deadline:
                    interrupted = True
                    break
                triple_subsets_completed += 1
                continue

            replacement, replacement_cost = result
            triple_subsets_completed += 1
            consider_exchange(
                owners,
                replacement,
                replacement_cost,
                "owner-triple exact repair",
            )

    # Always independently validate the final best witness before reporting.
    final_check = full_validate(
        best_selected,
        nrow,
        costs,
        col_offsets,
        col_rows,
    )

    if not final_check["valid"]:
        raise RuntimeError("final witness failed complete original validation")

    if not os.path.exists(args.witness):
        write_solution(args.witness, best_selected, names)

    result = {
        "instance": os.path.basename(args.mps),
        "solution": os.path.basename(args.solution),
        "read_only_model_processing": True,
        "optimization_called": False,
        "n_rows": nrow,
        "n_columns": ncol,
        "nonzeros": len(col_rows),
        "model_checks": {
            "nonunit_coefficients": bad_coefficients,
            "nonunit_rhs": bad_rhs,
            "nonequality_rows": bad_senses,
        },
        "public_solution_parse": {
            "values_read": loaded_solution["values_read"],
            "unknown_names": loaded_solution["unknown_names"],
            "malformed_lines": loaded_solution["malformed_lines"],
        },
        "public_incumbent": {
            "support_size": public_check["support_size"],
            "objective": public_check["objective"],
            "valid_exact_cover": public_check["valid"],
        },
        "duplicate_support_audit": {
            "distinct_supports": len(digest_rep),
            "duplicate_groups": len(duplicate_groups),
            "duplicate_columns_beyond_representatives": (
                sum(len(members) - 1 for members in duplicate_groups.values())
            ),
            "safe_deletions": safe_deletions,
            "digest_collisions": digest_collisions,
            "groups": duplicate_audit,
            "incumbent_changes": incumbent_duplicate_changes,
            "normalized_incumbent_changes": normalized_changes,
            "safe_deletion_caveat": (
                "A duplicate is safe to delete because its row support is "
                "identical to the retained cheapest column. Equal-cost ties "
                "retain one arbitrary member. This reduction preserves the "
                "best objective but may remove alternative equal-cost "
                "witnesses."
            ),
        },
        "normalized_incumbent": {
            "support_size": len(normalized_incumbent),
            "objective": normalized_check["objective"],
            "valid_exact_cover": normalized_check["valid"],
        },
        "owner_mask_reduction": {
            "active_nonincumbent_columns_considered": considered_columns,
            "candidate_columns_with_owner_degree_1_to_3": (
                sum(len(group) for group in candidate_groups.values())
            ),
            "columns_skipped_for_owner_degree_over_3": skipped_large_masks,
            "distinct_owner_masks": len(candidate_groups),
            "distinct_owner_triples": len(triple_owner_masks),
            "caveat": (
                "Columns touching four or more incumbent owners were excluded "
                "from this exchange neighborhood. Their absence from a found "
                "improvement is not a global conclusion."
            ),
        },
        "search": {
            "time_limit_seconds": args.time_limit,
            "elapsed_seconds": time.monotonic() - started,
            "node_limit_per_owner_subset": args.node_limit,
            "pair_subsets_attempted": pair_subsets_attempted,
            "pair_subsets_completed": pair_subsets_completed,
            "triple_subsets_observed": len(triple_owner_masks),
            "triple_subsets_attempted": triple_subsets_attempted,
            "triple_subsets_completed": triple_subsets_completed,
            "triple_cap": args.max_triples,
            "triples_truncated_by_cap": triples_truncated,
            "interrupted_by_time_limit": interrupted,
            "exhaustion_statement": (
                "Pair search exhausts every attempted singleton or owner-pair "
                "exact-cover repair over active columns whose owner masks are "
                "nonempty subsets of that owner set, unless its recursion node "
                "limit or the global time limit interrupts it. Triple search "
                "covers only observed owner triples up to the configured cap. "
                "Replacement cardinality is unrestricted within each completed "
                "exact-cover search. No conclusion of global optimality follows."
            ),
        },
        "best_witness": {
            "path": args.witness,
            "support_size": len(best_selected),
            "objective": final_check["objective"],
            "valid_exact_cover": final_check["valid"],
            "source": best_source,
            "improvement_from_public": (
                public_check["objective"] - final_check["objective"]
            ),
            "improvement_from_normalized": (
                normalized_check["objective"] - final_check["objective"]
            ),
            "exchange_log": exchange_log,
        },
    }

    with open(args.json, "w") as f:
        json.dump(result, f, separators=(",", ":"), allow_nan=False)

    print(json.dumps({
        "json": args.json,
        "witness": args.witness,
        "public_objective": public_check["objective"],
        "normalized_objective": normalized_check["objective"],
        "best_objective": final_check["objective"],
        "improvement": public_check["objective"] - final_check["objective"],
        "best_support_size": len(best_selected),
        "pair_attempted": pair_subsets_attempted,
        "pair_completed": pair_subsets_completed,
        "triple_attempted": triple_subsets_attempted,
        "triple_completed": triple_subsets_completed,
        "interrupted": interrupted,
        "elapsed_seconds": time.monotonic() - started,
    }, indent=2))


if __name__ == "__main__":
    main()
