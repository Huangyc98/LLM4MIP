import argparse
import json
import math
import os
import sys
from collections import OrderedDict

import gurobipy as gp
from gurobipy import GRB


U = 142.864331576
TIME_LIMIT = 600.0


def status_name(code):
    names = {
        GRB.LOADED: "LOADED",
        GRB.OPTIMAL: "OPTIMAL",
        GRB.INFEASIBLE: "INFEASIBLE",
        GRB.INF_OR_UNBD: "INF_OR_UNBD",
        GRB.UNBOUNDED: "UNBOUNDED",
        GRB.CUTOFF: "CUTOFF",
        GRB.ITERATION_LIMIT: "ITERATION_LIMIT",
        GRB.NODE_LIMIT: "NODE_LIMIT",
        GRB.TIME_LIMIT: "TIME_LIMIT",
        GRB.SOLUTION_LIMIT: "SOLUTION_LIMIT",
        GRB.INTERRUPTED: "INTERRUPTED",
        GRB.NUMERIC: "NUMERIC",
        GRB.SUBOPTIMAL: "SUBOPTIMAL",
        GRB.INPROGRESS: "INPROGRESS",
        GRB.USER_OBJ_LIMIT: "USER_OBJ_LIMIT",
        GRB.WORK_LIMIT: "WORK_LIMIT",
        GRB.MEM_LIMIT: "MEM_LIMIT",
    }
    return names.get(code, "STATUS_%s" % code)


def finite_or_none(x):
    return x if math.isfinite(x) else None


def main():
    parser = argparse.ArgumentParser(
        description="Solve one continuous relaxation and independently validate its row dual."
    )
    parser.add_argument("mps", help="Original MPS file")
    parser.add_argument(
        "--out-prefix",
        default=None,
        help="Output prefix; default is the MPS path without its final suffix",
    )
    args = parser.parse_args()

    mps_path = os.path.abspath(args.mps)
    if args.out_prefix is None:
        out_prefix = os.path.splitext(mps_path)[0]
    else:
        out_prefix = args.out_prefix

    json_path = out_prefix + ".lp_dual.json"
    cert_path = out_prefix + ".row_dual.txt"
    retained_path = out_prefix + ".retained_columns.txt"

    result = OrderedDict()
    result["input_mps"] = mps_path
    result["incumbent_cost_U"] = U
    result["time_limit_seconds"] = TIME_LIMIT
    result["method"] = (
        "One Gurobi continuous relaxation; all original-column dual inequalities "
        "independently recomputed with model.getCol."
    )
    result["duplicate_deletion_cross_reference"] = (
        "Not performed: the 15,320 previously audited duplicate deletions were "
        "not assumed to be absent and were included in validation."
    )

    try:
        original = gp.read(mps_path)
        lp = original.relax()
        lp.Params.TimeLimit = TIME_LIMIT
        lp.Params.OutputFlag = 0
        lp.optimize()

        status_code = lp.Status
        result["solver_status_code"] = status_code
        result["solver_status"] = status_name(status_code)
        result["solution_count"] = lp.SolCount
        result["row_count"] = lp.NumConstrs
        result["column_count"] = lp.NumVars

        rows = lp.getConstrs()
        cols = lp.getVars()
        row_names = [r.ConstrName for r in rows]
        col_names = [v.VarName for v in cols]
        rhs = [float(r.RHS) for r in rows]
        senses = [r.Sense for r in rows]

        result["all_rows_equality"] = all(s == GRB.EQUAL for s in senses)
        result["all_rhs_plus_one"] = all(x == 1.0 for x in rhs)

        if lp.SolCount <= 0:
            result["validity_caveat"] = (
                "No primal solution was available, so row Pi values and dual "
                "validation could not be performed."
            )
            result["outputs_written"] = [json_path, cert_path, retained_path]
            with open(cert_path, "w", encoding="utf-8") as f:
                f.write("No LP solution was available; no dual certificate produced.\n")
            with open(retained_path, "w", encoding="utf-8") as f:
                pass
            with open(json_path, "w", encoding="utf-8") as f:
                json.dump(result, f, separators=(",", ":"), allow_nan=False)
            print(json.dumps(result, separators=(",", ":"), allow_nan=False))
            return 0

        try:
            pi_nominal = [float(r.Pi) for r in rows]
        except Exception as exc:
            result["validity_caveat"] = (
                "A solution exists, but row Pi values were unavailable: %s" % exc
            )
            with open(cert_path, "w", encoding="utf-8") as f:
                f.write("Row Pi values unavailable; no dual certificate produced.\n")
            with open(retained_path, "w", encoding="utf-8") as f:
                pass
            with open(json_path, "w", encoding="utf-8") as f:
                json.dump(result, f, separators=(",", ":"), allow_nan=False)
            print(json.dumps(result, separators=(",", ":"), allow_nan=False))
            return 0

        nominal_objective = sum(pi_nominal[i] * rhs[i] for i in range(len(rows)))
        result["nominal_dual_objective"] = nominal_objective
        result["solver_primal_objective"] = finite_or_none(float(lp.ObjVal))

        max_abs_pi = max([abs(x) for x in pi_nominal] or [0.0])
        max_abs_rhs = max([abs(x) for x in rhs] or [0.0])
        scale = max(1.0, max_abs_pi, max_abs_rhs, abs(U))
        margin = 1.0e-9 * scale
        validation_tolerance = 1.0e-12 * scale

        max_violation = -math.inf
        min_nominal_rc = math.inf
        nonempty_columns = 0
        coefficient_errors = 0
        coefficient_error_max = 0.0
        column_nan_count = 0

        for j, colvar in enumerate(cols):
            col = lp.getCol(colvar)
            aty = 0.0
            nnz = col.size()
            if nnz > 0:
                nonempty_columns += 1
            else:
                coefficient_errors += 1
            for k in range(nnz):
                i = col.getConstr(k).index
                a = float(col.getCoeff(k))
                if a != 1.0:
                    coefficient_errors += 1
                    coefficient_error_max = max(
                        coefficient_error_max, abs(a - 1.0)
                    )
                aty += a * pi_nominal[i]
            cost = float(colvar.Obj)
            rc = cost - aty
            if not math.isfinite(rc):
                column_nan_count += 1
            min_nominal_rc = min(min_nominal_rc, rc)
            max_violation = max(max_violation, aty - cost)

        if max_violation == -math.inf:
            max_violation = 0.0

        result["original_columns_nonempty"] = nonempty_columns
        result["coefficient_error_count"] = coefficient_errors
        result["maximum_coefficient_error"] = coefficient_error_max
        result["nonfinite_nominal_reduced_cost_count"] = column_nan_count
        result["nominal_min_reduced_cost"] = min_nominal_rc
        result["nominal_max_dual_violation"] = max_violation
        result["repair_margin"] = margin
        result["validation_tolerance"] = validation_tolerance

        # Every original column is nonempty by model assumptions.  Therefore,
        # lowering every row multiplier by delta lowers a_j^T y by at least delta.
        delta = max(0.0, max_violation) + margin
        pi_repaired = [p - delta for p in pi_nominal]

        repaired_max_violation = -math.inf
        repaired_min_rc = math.inf
        repaired_nonempty = 0

        for j, colvar in enumerate(cols):
            col = lp.getCol(colvar)
            aty = 0.0
            nnz = col.size()
            if nnz > 0:
                repaired_nonempty += 1
            for k in range(nnz):
                i = col.getConstr(k).index
                a = float(col.getCoeff(k))
                aty += a * pi_repaired[i]
            rc = float(colvar.Obj) - aty
            repaired_min_rc = min(repaired_min_rc, rc)
            repaired_max_violation = max(repaired_max_violation, aty - float(colvar.Obj))

        # If roundoff still exposes a positive violation, apply one additional
        # conservative downward correction and recheck every original column.
        extra_delta = 0.0
        if repaired_max_violation > validation_tolerance:
            extra_delta = repaired_max_violation + margin
            pi_repaired = [p - extra_delta for p in pi_repaired]
            repaired_max_violation = -math.inf
            repaired_min_rc = math.inf
            for j, colvar in enumerate(cols):
                col = lp.getCol(colvar)
                aty = 0.0
                for k in range(col.size()):
                    i = col.getConstr(k).index
                    aty += float(col.getCoeff(k)) * pi_repaired[i]
                rc = float(colvar.Obj) - aty
                repaired_min_rc = min(repaired_min_rc, rc)
                repaired_max_violation = max(
                    repaired_max_violation, aty - float(colvar.Obj)
                )

        total_shift = delta + extra_delta
        repaired_objective = sum(
            pi_repaired[i] * rhs[i] for i in range(len(rows))
        )
        threshold = U - repaired_objective

        result["uniform_repair_initial_shift"] = delta
        result["uniform_repair_additional_shift"] = extra_delta
        result["uniform_repair_total_shift"] = total_shift
        result["repaired_dual_objective"] = repaired_objective
        result["exact_threshold_U_minus_L"] = threshold
        result["repaired_min_reduced_cost"] = repaired_min_rc
        result["repaired_max_dual_violation"] = repaired_max_violation
        result["repaired_dual_feasible_within_tolerance"] = (
            repaired_max_violation <= validation_tolerance
        )

        histogram = OrderedDict(
            [
                ("negative", 0),
                ("zero_to_1e-9", 0),
                ("1e-9_to_1e-6", 0),
                ("1e-6_to_1e-3", 0),
                ("1e-3_to_1", 0),
                ("1_to_10", 0),
                ("10_or_more", 0),
                ("near_threshold_inclusive", 0),
            ]
        )
        retained_count = 0
        strict_improvement_candidate_count = 0
        retained_indices = []

        # Equality cases are retained conservatively.  The small tolerance is
        # only a floating-point safeguard around the exact threshold.
        threshold_tol = margin
        retain_limit = threshold + threshold_tol

        with open(retained_path, "w", encoding="utf-8") as retained_file:
            for j, colvar in enumerate(cols):
                col = lp.getCol(colvar)
                aty = 0.0
                for k in range(col.size()):
                    i = col.getConstr(k).index
                    aty += float(col.getCoeff(k)) * pi_repaired[i]
                rc = float(colvar.Obj) - aty

                if rc <= retain_limit:
                    retained_count += 1
                    retained_indices.append(j)
                    retained_file.write(
                        "%d\t%s\n" % (j, colvar.VarName)
                    )
                    if rc < threshold - threshold_tol:
                        strict_improvement_candidate_count += 1

                    if rc < 0.0:
                        histogram["negative"] += 1
                    elif rc <= 1.0e-9:
                        histogram["zero_to_1e-9"] += 1
                    elif rc <= 1.0e-6:
                        histogram["1e-9_to_1e-6"] += 1
                    elif rc <= 1.0e-3:
                        histogram["1e-6_to_1e-3"] += 1
                    elif rc <= 1.0:
                        histogram["1e-3_to_1"] += 1
                    elif rc <= 10.0:
                        histogram["1_to_10"] += 1
                    else:
                        histogram["10_or_more"] += 1

                    if abs(rc - threshold) <= threshold_tol:
                        histogram["near_threshold_inclusive"] += 1

        result["retained_for_strict_improvement_or_equality"] = retained_count
        result["strictly_below_threshold_count"] = strict_improvement_candidate_count
        result["retained_histogram"] = histogram
        result["retained_index_file"] = retained_path
        result["row_dual_certificate_file"] = cert_path
        result["validity_caveat"] = (
            "Floating-point only: the repaired dual was independently checked "
            "against every original column, but this is not a formal exact "
            "optimality certificate. Reduced-cost deletion is safe only relative "
            "to the validated conservative lower bound and the stated numerical "
            "margin. Equality-threshold columns were retained."
        )

        with open(cert_path, "w", encoding="utf-8") as f:
            f.write("# Floating-point row-dual audit; not an exact certificate.\n")
            f.write("# solver_status=%s code=%d solution_count=%d\n" %
                    (status_name(status_code), status_code, lp.SolCount))
            f.write("# nominal_objective=%.17g\n" % nominal_objective)
            f.write("# repaired_objective=%.17g\n" % repaired_objective)
            f.write("# nominal_max_violation=%.17g\n" % max_violation)
            f.write("# repaired_max_violation=%.17g\n" % repaired_max_violation)
            f.write("# threshold_U_minus_L=%.17g\n" % threshold)
            f.write("# columns retained with rc <= threshold + margin: %d\n" %
                    retained_count)
            f.write("# row_index\trow_name\tnominal_Pi\trepaired_Pi\n")
            for i in range(len(rows)):
                f.write(
                    "%d\t%s\t%.17g\t%.17g\n"
                    % (i, row_names[i], pi_nominal[i], pi_repaired[i])
                )

        result["outputs_written"] = [json_path, cert_path, retained_path]
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(result, f, separators=(",", ":"), allow_nan=False)

        print(json.dumps(result, separators=(",", ":"), allow_nan=False))
        return 0

    except Exception as exc:
        result["error"] = "%s: %s" % (type(exc).__name__, exc)
        result["validity_caveat"] = (
            "Experiment failed; no dual-based deletion or certificate is valid."
        )
        try:
            with open(json_path, "w", encoding="utf-8") as f:
                json.dump(result, f, separators=(",", ":"), allow_nan=False)
        except Exception:
            pass
        print(json.dumps(result, separators=(",", ":"), allow_nan=False))
        return 1


if __name__ == "__main__":
    sys.exit(main())
