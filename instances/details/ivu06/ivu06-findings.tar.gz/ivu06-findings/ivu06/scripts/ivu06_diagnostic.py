#!/usr/bin/env python3
"""
Read-only diagnostic for ivu06.

Usage:
    python ivu06_diagnostic.py ivu06.mps --out ivu06_diag.json

Optional incumbent support:
    python ivu06_diagnostic.py ivu06.mps \
        --support support.json \
        --out ivu06_diag.json

support.json may be either:
    [123, 456, ...]
or:
    {"indices": [123, 456, ...]}

Indices are zero-based variable indices in the original Gurobi model order.

This program never calls model.optimize(), model.presolve(), or any solver
optimization routine.
"""

import argparse
import array
import gzip
import hashlib
import json
import math
import os
import sys
import time

import gurobipy as gp


def compact_float(x):
    """JSON-friendly finite float representation."""
    x = float(x)
    if not math.isfinite(x):
        return None
    return x


def load_support(path, name_to_index):
    if path.endswith(".sol") or path.endswith(".sol.gz"):
        opener = gzip.open if path.endswith(".gz") else open
        support = []
        with opener(path, "rt", encoding="utf-8", errors="replace") as f:
            for raw in f:
                fields = raw.split()
                if len(fields) < 2 or fields[0].startswith(("#", "=")):
                    continue
                try:
                    value = float(fields[1])
                except ValueError:
                    continue
                if value > 0.5:
                    support.append(name_to_index[fields[0]])
        return support
    with open(path, "r") as f:
        z = json.load(f)
    if isinstance(z, dict):
        z = z["indices"]
    if not isinstance(z, list):
        raise ValueError("support JSON must be a list or {'indices': list}")
    return [int(v) for v in z]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mps")
    ap.add_argument("--out", default="ivu06_diagnostic.json")
    ap.add_argument("--support", default=None)
    ap.add_argument(
        "--dual-passes",
        type=int,
        default=5,
        help="number of row-coordinate ascent passes; default 5",
    )
    args = ap.parse_args()

    t0 = time.time()

    # Read only. No optimize or presolve.
    model = gp.read(args.mps)
    vars_ = model.getVars()
    rows_ = model.getConstrs()

    ncol = len(vars_)
    nrow = len(rows_)

    # Compact storage:
    #   col_offsets[j]: start of column j in col_rows
    #   col_rows: concatenated row indices
    #   row_cols[i]: array of columns containing row i
    #
    # Python lists are used only for the 1,177 row adjacency containers.
    # The 8m incidence indices are stored in array('i').
    col_offsets = array.array("i", [0])
    col_rows = array.array("i")
    row_cols = [array.array("i") for _ in range(nrow)]
    costs = array.array("d")

    # Hash digest -> representative column index.
    # A digest match is always checked by comparing actual row lists before
    # being counted as an exact duplicate.
    digest_rep = {}
    digest_count = {}
    digest_collision_count = 0
    duplicate_columns = 0
    duplicate_groups = 0

    min_cost = float("inf")
    max_cost = float("-inf")
    total_nnz = 0
    min_col_degree = 10**9
    max_col_degree = 0
    sum_col_degree = 0

    # Basic model checks.
    bad_vtypes = 0
    bad_bounds = 0
    bad_row_senses = 0
    bad_coefficients = 0
    bad_rhs = 0

    for i, r in enumerate(rows_):
        # Equality rows are required by the stated structure.
        if r.Sense != "=":
            bad_row_senses += 1
        if abs(float(r.RHS) - 1.0) > 1e-12:
            bad_rhs += 1

    for j, v in enumerate(vars_):
        # Gurobi reports the MPS columns as bounded general integers ("I"),
        # although their [0,1] domains make them binary for this model.
        if v.VType not in (gp.GRB.BINARY, gp.GRB.INTEGER):
            bad_vtypes += 1
        if float(v.LB) < -1e-12 or float(v.UB) > 1.0 + 1e-12:
            bad_bounds += 1

        c = float(v.Obj)
        costs.append(c)
        min_cost = min(min_cost, c)
        max_cost = max(max_cost, c)

        col = model.getCol(v)
        rs = []

        for k in range(col.size()):
            r = col.getConstr(k)
            a = float(col.getCoeff(k))
            ri = r.index

            if abs(a - 1.0) > 1e-12:
                bad_coefficients += 1

            rs.append(ri)

        # Canonicalize support. Duplicate row indices would indicate an
        # invalid/nonstandard column and are retained in diagnostics.
        if len(rs) > 1 and any(rs[k] >= rs[k + 1] for k in range(len(rs) - 1)):
            rs.sort()

        d = len(rs)
        total_nnz += d
        sum_col_degree += d
        min_col_degree = min(min_col_degree, d)
        max_col_degree = max(max_col_degree, d)

        # Canonical hash. The actual support is checked whenever a digest
        # collision or duplicate digest is encountered.
        packed = array.array("I", rs).tobytes()
        digest = hashlib.blake2b(packed, digest_size=16).digest()

        if digest not in digest_rep:
            digest_rep[digest] = j
            digest_count[digest] = 1
        else:
            rep = digest_rep[digest]
            rep_start = col_offsets[rep]
            rep_end = col_offsets[rep + 1]
            rep_rows = col_rows[rep_start:rep_end]

            if list(rep_rows) == rs:
                if digest_count[digest] == 1:
                    duplicate_groups += 1
                digest_count[digest] += 1
                duplicate_columns += 1
            else:
                # Cryptographic collisions are extraordinarily unlikely, but
                # do not silently classify one as a duplicate.
                digest_collision_count += 1
                # Make a distinct key for bookkeeping.
                digest_rep[(digest, j)] = j
                digest_count[(digest, j)] = 1

        start = len(col_rows)
        col_rows.extend(rs)
        col_offsets.append(len(col_rows))

        for ri in rs:
            if ri < 0 or ri >= nrow:
                raise RuntimeError("invalid row index")
            row_cols[ri].append(j)

    # Construct a globally feasible initial dual.
    #
    # If all c_j >= 0, pi=0 is feasible.
    # If some costs are negative, pi_i=min_cost for every row is conservative
    # because every nonempty column has at least one row and all coefficients
    # are +1. This is only a fallback for malformed/unusual objective data.
    if min_cost >= 0.0:
        dual = [0.0] * nrow
    else:
        dual = [min_cost] * nrow

    # Exact current column slacks in double precision:
    # slack[j] = c[j] - sum_{i in column j} dual[i].
    slack = array.array("d", costs)
    if min_cost < 0.0:
        for j in range(ncol):
            s = col_offsets[j]
            e = col_offsets[j + 1]
            slack[j] -= (e - s) * min_cost

    initial_dual_obj = sum(dual)

    # Coordinate ascent on the dual.
    #
    # Increasing one pi_i by the minimum current slack among columns
    # containing row i preserves all constraints. A tiny safety factor avoids
    # relying on equality at floating-point precision.
    updates = 0
    for p in range(max(0, args.dual_passes)):
        changed = 0
        for i in range(nrow):
            incident = row_cols[i]
            if not incident:
                continue

            mn = float("inf")
            for j in incident:
                sj = slack[j]
                if sj < mn:
                    mn = sj

            if mn > 0.0 and math.isfinite(mn):
                # Conservative floating-point margin. The final certificate
                # must still be independently checked using the original MPS
                # coefficients, preferably with decimal/rational arithmetic.
                delta = mn * (1.0 - 1.0e-12)
                if delta > 0.0:
                    dual[i] += delta
                    changed += 1
                    updates += 1
                    for j in incident:
                        slack[j] -= delta

        if changed == 0:
            break

    # Recompute all slacks from scratch, avoiding accumulated update error.
    min_slack = float("inf")
    max_violation = 0.0
    violating_columns = 0
    dual_obj = sum(dual)

    for j in range(ncol):
        s = col_offsets[j]
        e = col_offsets[j + 1]
        lhs = 0.0
        for q in range(s, e):
            lhs += dual[col_rows[q]]
        sj = costs[j] - lhs
        slack[j] = sj

        min_slack = min(min_slack, sj)
        if sj < 0.0:
            violating_columns += 1
            max_violation = max(max_violation, -sj)

    # If roundoff produced violations, scale the nonnegative dual toward zero.
    # This is a repair, not a proof by itself; the reported vector still needs
    # an independent exact/original-MPS validation.
    repair_scale = 1.0
    if violating_columns:
        alpha = 1.0
        for j in range(ncol):
            s = col_offsets[j]
            e = col_offsets[j + 1]
            lhs = 0.0
            for q in range(s, e):
                lhs += dual[col_rows[q]]
            if lhs > 0.0:
                alpha = min(alpha, costs[j] / lhs)

        if alpha < 1.0:
            repair_scale = max(0.0, alpha * (1.0 - 1.0e-10))
            for i in range(nrow):
                dual[i] *= repair_scale

            min_slack = float("inf")
            max_violation = 0.0
            violating_columns = 0
            dual_obj = sum(dual)

            for j in range(ncol):
                s = col_offsets[j]
                e = col_offsets[j + 1]
                lhs = 0.0
                for q in range(s, e):
                    lhs += dual[col_rows[q]]
                sj = costs[j] - lhs
                min_slack = min(min_slack, sj)
                if sj < 0.0:
                    violating_columns += 1
                    max_violation = max(max_violation, -sj)

    # Optional exact incumbent validation and exact one-column replacements.
    support_info = None
    if args.support is not None:
        support = load_support(
            args.support, {v.VarName: v.index for v in vars_}
        )
        owner = array.array("i", [-1]) * nrow
        support_errors = []

        for j in support:
            if j < 0 or j >= ncol:
                support_errors.append("support index out of range: %d" % j)
                continue
            s = col_offsets[j]
            e = col_offsets[j + 1]
            for q in range(s, e):
                ri = col_rows[q]
                if owner[ri] != -1:
                    support_errors.append(
                        "row %d covered more than once by %d and %d"
                        % (ri, owner[ri], j)
                    )
                else:
                    owner[ri] = j

        uncovered = [i for i in range(nrow) if owner[i] == -1]

        # Exact one-column replacement candidates are found by hashing the
        # support of each incumbent column and looking up all columns with the
        # same support. This does not find multi-column alternating cycles.
        support_replacements = []
        support_digest_map = {}

        for j in support:
            if j < 0 or j >= ncol:
                continue
            s = col_offsets[j]
            e = col_offsets[j + 1]
            rs = list(col_rows[s:e])
            digest = hashlib.blake2b(
                array.array("I", rs).tobytes(), digest_size=16
            ).digest()
            support_digest_map.setdefault(digest, []).append(j)

        # Scan digest representatives. Because digest_rep retains one
        # representative per digest, this reports only representative matches
        # unless the matching group can be recovered from a second pass.
        for digest, inc_cols in support_digest_map.items():
            if digest not in digest_rep:
                continue
            rep = digest_rep[digest]
            rs = list(col_rows[col_offsets[rep]:col_offsets[rep + 1]])

            for inc in inc_cols:
                if inc == rep:
                    continue
                # Verify the actual row support before reporting.
                irs = list(col_rows[col_offsets[inc]:col_offsets[inc + 1]])
                if irs == rs:
                    support_replacements.append(
                        {
                            "remove": inc,
                            "add_representative": rep,
                            "objective_change": costs[rep] - costs[inc],
                        }
                    )

        incumbent_cost = sum(costs[j] for j in support if 0 <= j < ncol)
        support_info = {
            "size": len(support),
            "recomputed_objective": incumbent_cost,
            "expected_set_partitioning_size": nrow,
            "uncovered_rows": len(uncovered),
            "support_errors": support_errors[:20],
            "exactly_one_cover": (
                len(uncovered) == 0 and len(support_errors) == 0
            ),
            "exact_one_column_replacements": support_replacements,
            "note": (
                "One-column replacement detection only finds another column "
                "with exactly the same row support. It is not a search for "
                "multi-column alternating cycles."
            ),
        }

    # Degree summaries.
    row_degrees = [len(x) for x in row_cols]
    col_degrees = [
        col_offsets[j + 1] - col_offsets[j] for j in range(ncol)
    ]

    def percentile(vals, p):
        if not vals:
            return None
        a = sorted(vals)
        k = int(round((len(a) - 1) * p))
        return a[k]

    result = {
        "instance": os.path.basename(args.mps),
        "read_only": True,
        "optimization_called": False,
        "n_rows": nrow,
        "n_columns": ncol,
        "total_nonzeros": total_nnz,
        "objective_min": min_cost,
        "objective_max": max_cost,
        "row_degree": {
            "min": min(row_degrees) if row_degrees else None,
            "median": percentile(row_degrees, 0.5),
            "mean": (sum(row_degrees) / len(row_degrees)) if row_degrees else None,
            "max": max(row_degrees) if row_degrees else None,
        },
        "column_degree": {
            "min": min(col_degrees) if col_degrees else None,
            "median": percentile(col_degrees, 0.5),
            "mean": (sum(col_degrees) / len(col_degrees)) if col_degrees else None,
            "max": max(col_degrees) if col_degrees else None,
        },
        "model_checks": {
            "nonbinary_variables": bad_vtypes,
            "non_[0,1]_bounds": bad_bounds,
            "non_equality_rows": bad_row_senses,
            "nonunit_matrix_coefficients": bad_coefficients,
            "nonunit_rhs": bad_rhs,
        },
        "duplicate_supports": {
            "digest_entries": len(digest_rep),
            "duplicate_groups": duplicate_groups,
            "duplicate_columns_beyond_representatives": duplicate_columns,
            "digest_collisions_detected": digest_collision_count,
            "caveat": (
                "Duplicate classification compares actual sorted row supports "
                "after digest matches. Equal support with different objective "
                "coefficients is not interchangeable and requires separate "
                "objective handling."
            ),
        },
        "dual_coordinate_ascent": {
            "passes_requested": args.dual_passes,
            "updates": updates,
            "initial_dual_objective": initial_dual_obj,
            "dual_objective": dual_obj,
            "minimum_column_slack_float": min_slack,
            "violating_columns_float": violating_columns,
            "maximum_violation_float": max_violation,
            "repair_scale": repair_scale,
            "dual_vector": [compact_float(x) for x in dual],
            "global_validity": (
                "The vector is intended to satisfy A^T pi <= c and therefore "
                "gives a global lower bound for the integer problem. The "
                "floating-point vector must be independently checked against "
                "the original MPS, preferably with directed rounding or exact "
                "decimal arithmetic, before treating dual_objective as a "
                "formal certificate."
            ),
        },
        "elapsed_seconds": time.time() - t0,
    }

    if support_info is not None:
        result["incumbent_support"] = support_info

    # Compact JSON: no incidence matrix is written.
    with open(args.out, "w") as f:
        json.dump(result, f, separators=(",", ":"), allow_nan=False)

    print(json.dumps({
        "output": args.out,
        "n_rows": nrow,
        "n_columns": ncol,
        "nonzeros": total_nnz,
        "duplicate_columns": duplicate_columns,
        "duplicate_groups": duplicate_groups,
        "dual_objective": dual_obj,
        "dual_min_slack": min_slack,
        "dual_violating_columns": violating_columns,
        "elapsed_seconds": time.time() - t0,
    }, indent=2))


if __name__ == "__main__":
    main()
