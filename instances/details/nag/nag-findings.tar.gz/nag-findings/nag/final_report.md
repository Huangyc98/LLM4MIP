# Final Report: nag

## Outcome

The experiment produced a feasible solution, but did not prove optimality or infeasibility. This is therefore a partial result.

- Objective sense: minimize
- Best tolerance-verified primal bound: `930.0`
- Best verified incumbent run: `copt-20260903-112858-40c812b1`
- Best dual bound: `550.5405405405405`
- Best dual-bound run: `gurobi-20260903-135908-06dcd3f6`
- Combined relative gap: `0.40802092414995644`
- Feasibility verification: the best incumbent was verified at tolerance `1e-9`
- Optimality proof: none
- Infeasibility proof: none

The combined gap is computed from the best verified incumbent and the best available dual bound. Solver-accepted feasibility and tolerance verification are recorded separately. The unverified Gurobi incumbent with objective approximately `959.9999997117` was not used as the best verified primal result.

## Termination Record

| Run | Solver | Termination status | Primal | Dual | Reported gap | Verified | Runtime (s) |
|---|---|---|---:|---:|---:|---|---:|
| `copt-20260903-111158-6e25f505` | COPT | `TIMEOUT` | 960 | 465 | 0.515625 | yes @ 1e-9 | 900.041334 |
| `copt-20260903-112858-40c812b1` | COPT | `TIMEOUT` | 930 | 465 | 0.5 | yes @ 1e-9 | 2700.078235 |
| `copt-20260903-121622-e1760a2a` | COPT | `TIMEOUT` | 930 | 465 | 0.5 | yes @ 1e-9 | 3600.011722 |
| `gurobi-20260903-110916-ae630e67` | Gurobi | `NODE_LIMIT` | 4960 | 465 | 0.90625 | yes @ 1e-9 | 0.260485 |
| `gurobi-20260903-111154-cfec0b79` | Gurobi | `TIME_LIMIT` | 1080 | 470 | 0.564814815 | yes @ 1e-9 | 900.027593 |
| `gurobi-20260903-112855-1f6a264b` | Gurobi | `TIME_LIMIT` | 990 | 465 | 0.530303030 | yes @ 1e-9 | 2700.029781 |
| `gurobi-20260903-121617-a3ec142b` | Gurobi | `TIME_LIMIT` | 930 | 510 | 0.451612903 | yes @ 1e-9 | 3600.103289 |
| `gurobi-20260903-131802-fc559cc6` | Gurobi | `TIME_LIMIT` | 2190 | 510 | 0.767123288 | yes @ 1e-9 | 2400.032390 |
| `gurobi-20260903-135908-06dcd3f6` | Gurobi | `TIME_LIMIT` | 959.9999997117 | 550.540540541 | 0.426520270 | no | 3600.068763 |
| `gurobi-20260903-150009-f288a77d` | Gurobi | `TIME_LIMIT` | 960 | 517.5 | 0.4609375 | yes @ 1e-9 | 680.129454 |

No `OPTIMAL` or `INFEASIBLE` termination status appears in the archival record. A time limit, timeout, or node limit is not an optimality or infeasibility proof.

## Reproducibility Metadata

- Instance: `nag`
- Solvers used: COPT and Gurobi
- Solver versions: not exposed in the supplied reporting summaries
- Machines: not exposed in the supplied reporting summaries
- Parameter dictionaries: not exposed in the supplied reporting summaries; controller-managed solver settings were used
- Random seeds: not exposed in the supplied reporting summaries
- Run time limits: 900, 2700, 3600, 2400, and 680 seconds as shown in the termination table
- Total run count: 10
- Reporting bundle generation timestamp: `2026-09-03T07:11:55.158589+00:00`

Unavailable metadata is explicitly marked rather than inferred.

## Recommended Next Experiment

The next optimization stage should retain the verified objective-930 incumbent as a warm start, then focus on improving the dual bound and closing the 40.8021% combined gap. Formulation or presolve strengthening and an incumbent-focused branch-and-bound configuration are reasonable priorities, followed by a longer controlled run. Any future conclusion must again distinguish verified feasibility from solver status and must claim optimality or infeasibility only after an explicit proof.
