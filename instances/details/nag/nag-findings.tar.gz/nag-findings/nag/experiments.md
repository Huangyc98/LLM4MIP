# Experiment ledger

This file is generated from `runs/*/result.json` by the controller.

| Run | Solver | Status | Primal | Dual | Gap | Verified | Runtime (s) |
|---|---|---|---:|---:|---:|---|---:|
| `copt-20260903-111158-6e25f505` | copt | TIMEOUT | 960 | 465 | 0.515625 | yes @ 1e-9 | 900.041334152222 |
| `copt-20260903-112858-40c812b1` | copt | TIMEOUT | 930 | 465 | 0.5 | yes @ 1e-9 | 2700.07823514938 |
| `copt-20260903-121622-e1760a2a` | copt | TIMEOUT | 930 | 465 | 0.5 | yes @ 1e-9 | 3600.01172184944 |
| `gurobi-20260903-110916-ae630e67` | gurobi | NODE_LIMIT | 4960 | 465 | 0.90625 | yes @ 1e-9 | 0.260484933853149 |
| `gurobi-20260903-111154-cfec0b79` | gurobi | TIME_LIMIT | 1080 | 470 | 0.564814814814815 | yes @ 1e-9 | 900.027592897415 |
| `gurobi-20260903-112855-1f6a264b` | gurobi | TIME_LIMIT | 990 | 465 | 0.53030303030303 | yes @ 1e-9 | 2700.02978086472 |
| `gurobi-20260903-121617-a3ec142b` | gurobi | TIME_LIMIT | 930 | 510 | 0.451612903225806 | yes @ 1e-9 | 3600.10328888893 |
| `gurobi-20260903-131802-fc559cc6` | gurobi | TIME_LIMIT | 2190 | 510 | 0.767123287671233 | yes @ 1e-9 | 2400.03239011765 |
| `gurobi-20260903-135908-06dcd3f6` | gurobi | TIME_LIMIT | 959.9999997117 | 550.540540540541 | 0.426520270098047 | no | 3600.06876301765 |
| `gurobi-20260903-150009-f288a77d` | gurobi | TIME_LIMIT | 960 | 517.5 | 0.4609375 | yes @ 1e-9 | 680.129453897476 |
