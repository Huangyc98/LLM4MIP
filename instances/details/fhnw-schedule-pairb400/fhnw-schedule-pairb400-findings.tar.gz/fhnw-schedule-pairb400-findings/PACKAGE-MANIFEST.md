# Package manifest: fhnw-schedule-pairb400

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 17
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/SAFE-DEADLINE-NOTE.md`
- `artifacts/common-deadline-master-safe-rerun-result.json`
- `artifacts/common-deadline-master-safe-rerun-semantic-audit.json`
- `artifacts/common-deadline-master-safe-result.json`
- `artifacts/common-deadline-master-safe-semantic-audit.json`
- `artifacts/common-deadline-master-safe.mps.gz`
- `artifacts/summary.json`
- `experiments/common-deadline-master-safe-rerun.log`
- `experiments/common-deadline-master-safe.log`
- `input/SHA256SUMS`
- `input/fhnw-schedule-pairb400-public.sol.gz`
- `reports/REJECTED-PROOF-NOTICE.md`
- `scripts/audit_common_deadline_master.py`
- `scripts/pairb_common_deadline_master.py`
- `scripts/reconstruct_pairb_from_master.py`
- `solutions/global-optimal.sol`

## Excluded files

- `input/fhnw-schedule-pairb400.mps.gz (6300199 bytes; raw benchmark input; sha256 9ea6b21a87cff5c74d1043b2d405b0e4493327ac89756b042b1fbf88ad4353db)`
