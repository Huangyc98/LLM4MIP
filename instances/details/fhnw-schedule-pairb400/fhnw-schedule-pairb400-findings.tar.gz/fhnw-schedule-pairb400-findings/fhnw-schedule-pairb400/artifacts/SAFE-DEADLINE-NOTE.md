# Safe completion-deadline note

This proof model uses

```text
D_safe = 1.000000000001
```

in every release-suffix capacity row. A separate Decimal reconstruction of the
official PairB400 MPS found the largest eligible completion deadline to be
`1.0000000000000002`. Thus `D_safe` exceeds that independently recovered value
by approximately `9.998e-13`; the suffix rows are conservative necessary
conditions and cannot exclude an original feasible selection because of the
last-bit `D=1` rounding issue.

The earlier PairB numerical cross-check that used exactly `D=1` is marked as
superseded. Both safe runs (Seed 101/1 thread and Seed 149/2 threads) return the
same zero-gap objective `-36.27696674236886`, matching the independently audited
official-MPS feasible solution.
