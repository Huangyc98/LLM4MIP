# Package manifest: core4284-1064

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 29
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/critical_exchange.json`
- `artifacts/critical_exchange_large.json`
- `artifacts/disjunctive_core.json`
- `artifacts/lp_dual_certificate.json`
- `artifacts/lp_dual_certificate_check.json`
- `artifacts/reduced_baseline.json`
- `artifacts/reduction/column_dominance_certificates.json`
- `artifacts/reduction/forced_certificates.json`
- `artifacts/reduction/mapping.json`
- `artifacts/reduction/reduction_report.json`
- `artifacts/reduction/row_dominance_certificates.json`
- `artifacts/reduction/strict_cutoff_1061.opb`
- `input/core4284-1064.public.sol.gz`
- `logs/reduced_gurobi_600s.log`
- `reports/effort_ledger.md`
- `reports/final_report.md`
- `scripts/check_lp_dual_certificate.py`
- `scripts/critical_exchange.py`
- `scripts/disjunctive_core.py`
- `scripts/export_lp_dual_certificate.py`
- `scripts/inspect_core.py`
- `scripts/reduce_core.py`
- `scripts/solve_reduced_baseline.py`
- `solutions/reduced_best.sol.gz`
- `sources/sources.md`
- `structure/deep_structure.json`
- `structure/structure.compact.json`
- `structure/structure.json`

## Excluded files

- `input/core4284-1064.mps.gz (1054855 bytes; raw benchmark input; sha256 16e642ebc5eb6b1d0cc4e4974e98d59043463237b5ec0daf625021173bd53f39)`
