# `core4284-1064`

## Result

The instance remains open. This study certifies the interval

```text
1055 <= OPT <= 1062.
```

The public objective-1062 solution was independently checked against the
original MPS. An exact reduction of the Italian-railway weighted set-cover
model fixes 20 columns of total cost 26 and leaves 3,384 rows and 15,272
columns. Rational row prices, rounded downward to denominator `10^9`, satisfy
all residual column inequalities in integer arithmetic and give the checked
full lower bound `1054.054387455`. Integrality of the objective yields the
certified integer bound 1055.

No feasible solution of value 1061 was found, but it was not excluded. The
986 local repair failures and the 32 bounded disjunctive leaves are local or
time-limited evidence, not an optimality proof.

## Evidence boundary

The lower bound 1055 is supported by a portable rational LP-dual certificate
and an independent checker that reparses the original MPS and reconstructs the
reduction. The upper bound 1062 is supported by a strict original-MPS witness
audit. The solver's time-limited bound also reached 1055, but the published
claim does not depend on preserving its branch-and-bound state.

The generated 4 MB reduced MPS was omitted as regenerable; `reduce_core.py`
recreates it. The reduction witnesses and strict-cutoff OPB were retained.

## Provenance

- [MIPLIB instance page](https://miplib.zib.de/instance_details_core4284-1064.html)
- Original MPS SHA-256:
  `16e642ebc5eb6b1d0cc4e4974e98d59043463237b5ec0daf625021173bd53f39`
- Research date: 2026-09-09
- Research effort: 67 minutes; generic solver optimization approximately 602 seconds

## Recheck the lower-bound certificate

From this instance directory:

```powershell
python .\scripts\check_lp_dual_certificate.py `
  .\input\core4284-1064.mps.gz `
  .\artifacts\reduction `
  .\artifacts\lp_dual_certificate.json `
  .\artifacts\lp_dual_certificate.recheck.json
```

The output must report `valid: true`, no violations, full dual value
`1054.054387455`, and integer lower bound `1055`.

## Contents

- [`reports/final_report.md`](reports/final_report.md): full structural analysis
- [`reports/effort_ledger.md`](reports/effort_ledger.md): experiment accounting
- [`sources/sources.md`](sources/sources.md): MIPLIB and railway SCP references
- [`artifacts/reduction/`](artifacts/reduction/): exact reduction maps and witnesses
- [`artifacts/reduction/strict_cutoff_1061.opb`](artifacts/reduction/strict_cutoff_1061.opb): unresolved strict-cutoff model
- [`artifacts/lp_dual_certificate.json`](artifacts/lp_dual_certificate.json): rational lower-bound witness
- [`artifacts/lp_dual_certificate_check.json`](artifacts/lp_dual_certificate_check.json): recorded independent check
- [`logs/reduced_gurobi_600s.log`](logs/reduced_gurobi_600s.log): bounded baseline, not a proof trace

