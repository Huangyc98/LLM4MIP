"""Read-only structural inspection for the CORE railway set-cover instance."""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import gzip
import json
import math
from pathlib import Path

import gurobipy as gp
import numpy as np


def num(value: float):
    if math.isinf(value):
        return "inf" if value > 0 else "-inf"
    return value


def quantiles(values: list[int]) -> dict:
    a = np.asarray(values, dtype=float)
    return {str(q): float(np.quantile(a, q)) for q in (0, .1, .25, .5, .75, .9, .99, 1)}


def read_solution(path: Path) -> tuple[float | None, dict[str, float]]:
    declared = None
    values = {}
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        for raw in handle:
            line = raw.strip()
            if not line:
                continue
            if line.startswith("=obj="):
                declared = float(line.split()[-1])
                continue
            pieces = line.split()
            if len(pieces) == 2:
                values[pieces[0]] = float(pieces[1])
    return declared, values


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    env = gp.Env(empty=True)
    env.setParam("OutputFlag", 0)
    env.start()
    model = gp.read(str(args.model), env)
    variables = model.getVars()
    constraints = model.getConstrs()
    row_terms: dict[int, list[tuple[int, float]]] = {}
    col_rows: dict[int, list[tuple[int, float]]] = defaultdict(list)
    for con in constraints:
        row = model.getRow(con)
        terms = []
        for p in range(row.size()):
            v = row.getVar(p).index
            c = float(row.getCoeff(p))
            terms.append((v, c))
            col_rows[v].append((con.index, c))
        row_terms[con.index] = terms

    r_rows = [con.index for con in constraints if con.ConstrName.startswith("R")]
    special_rows = [con.index for con in constraints if con.index not in set(r_rows)]
    r_position = {row: i for i, row in enumerate(r_rows)}
    integer_vars = [v.index for v in variables if v.VType != gp.GRB.CONTINUOUS]
    continuous_vars = [v.index for v in variables if v.VType == gp.GRB.CONTINUOUS]

    objective_hist = Counter(round(variables[v].Obj, 12) for v in integer_vars)
    coefficient_hist = Counter(round(c, 12) for row in r_rows for _, c in row_terms[row])
    rhs_hist = Counter(round(constraints[row].RHS, 12) for row in r_rows)
    sense_hist = Counter(constraints[row].Sense for row in r_rows)

    continuous_detail = []
    for v in continuous_vars:
        var = variables[v]
        continuous_detail.append({
            "name": var.VarName,
            "lb": num(var.LB),
            "ub": num(var.UB),
            "obj": var.Obj,
            "occurrences": [
                {
                    "row": constraints[row].ConstrName,
                    "sense": constraints[row].Sense,
                    "rhs": constraints[row].RHS,
                    "coefficient": coef,
                    "degree": len(row_terms[row]),
                }
                for row, coef in col_rows[v]
            ],
        })

    special_detail = []
    for row in special_rows:
        con = constraints[row]
        terms = row_terms[row]
        coeff_hist = Counter(round(c, 12) for _, c in terms)
        special_detail.append({
            "name": con.ConstrName,
            "sense": con.Sense,
            "rhs": con.RHS,
            "degree": len(terms),
            "coefficient_histogram": dict(coeff_hist),
            "first_terms": [
                {"variable": variables[v].VarName, "coefficient": c, "objective": variables[v].Obj}
                for v, c in terms[:30]
            ],
        })

    # Exact incidence duplicates and elementary dominance among integer columns,
    # considering the actual R-row coefficient pairs rather than names/order.
    signatures: dict[tuple, list[int]] = defaultdict(list)
    cover_sets: dict[int, frozenset[int]] = {}
    row_to_integer: dict[int, list[int]] = defaultdict(list)
    for v in integer_vars:
        signature = tuple(sorted((r_position[row], round(c, 12)) for row, c in col_rows[v] if row in r_position))
        signatures[signature].append(v)
        unit_rows = frozenset(r_position[row] for row, c in col_rows[v] if row in r_position and abs(c - 1.0) <= 1e-12)
        cover_sets[v] = unit_rows
        for row in unit_rows:
            row_to_integer[row].append(v)
    duplicate_groups = [members for members in signatures.values() if len(members) > 1]

    dominated = {}
    for v in integer_vars:
        covered = cover_sets[v]
        if not covered:
            continue
        rare_row = min(covered, key=lambda r: len(row_to_integer[r]))
        cost = variables[v].Obj
        for u in row_to_integer[rare_row]:
            if u == v or variables[u].Obj > cost + 1e-12:
                continue
            if covered.issubset(cover_sets[u]):
                dominated[variables[v].VarName] = {
                    "by": variables[u].VarName,
                    "cost": cost,
                    "dominator_cost": variables[u].Obj,
                    "covered_rows": len(covered),
                    "dominator_rows": len(cover_sets[u]),
                }
                break

    row_degrees_integer = []
    forced = []
    for row in r_rows:
        ivars = [v for v, c in row_terms[row] if v in cover_sets and abs(c - 1.0) <= 1e-12]
        row_degrees_integer.append(len(ivars))
        if len(ivars) == 1 and not any(v in continuous_vars for v, _ in row_terms[row]):
            forced.append({"row": constraints[row].ConstrName, "variable": variables[ivars[0]].VarName})

    declared, sparse = read_solution(args.solution)
    values = np.asarray([sparse.get(v.VarName, 0.0) for v in variables])
    objective = float(model.ObjCon + sum(v.Obj * values[v.index] for v in variables))
    max_row_violation = 0.0
    worst_row = None
    for con in constraints:
        activity = sum(c * values[v] for v, c in row_terms[con.index])
        if con.Sense == ">":
            violation = max(con.RHS - activity, 0.0)
        elif con.Sense == "<":
            violation = max(activity - con.RHS, 0.0)
        else:
            violation = abs(activity - con.RHS)
        if violation > max_row_violation:
            max_row_violation, worst_row = violation, con.ConstrName

    selected = [
        {"name": variables[v].VarName, "cost": variables[v].Obj, "rows": len(cover_sets[v])}
        for v in integer_vars if values[v] > .5
    ]
    active_continuous = [
        {"name": variables[v].VarName, "value": float(values[v]), "objective": variables[v].Obj}
        for v in continuous_vars if abs(values[v]) > 1e-12
    ]

    result = {
        "model": {
            "name": model.ModelName,
            "variables": model.NumVars,
            "constraints": model.NumConstrs,
            "nonzeros": model.NumNZs,
            "integer_01_variables": len(integer_vars),
            "continuous_variables": len(continuous_vars),
            "R_rows": len(r_rows),
            "special_rows": [constraints[r].ConstrName for r in special_rows],
        },
        "R_row_profile": {
            "sense_histogram": dict(sense_hist),
            "rhs_histogram": dict(rhs_hist),
            "coefficient_histogram": dict(coefficient_hist),
            "integer_degree_quantiles": quantiles(row_degrees_integer),
            "singleton_forced_columns": forced,
        },
        "integer_columns": {
            "objective_histogram": dict(objective_hist),
            "degree_quantiles": quantiles([len(cover_sets[v]) for v in integer_vars]),
            "exact_signature_duplicate_groups": len(duplicate_groups),
            "variables_in_duplicate_groups": sum(len(g) for g in duplicate_groups),
            "duplicate_examples": [
                [variables[v].VarName for v in group[:10]] for group in duplicate_groups[:20]
            ],
            "elementary_dominated_count": len(dominated),
            "dominated_examples": list(dominated.items())[:30],
        },
        "continuous_variables": continuous_detail,
        "special_rows": special_detail,
        "public_solution": {
            "declared_objective": declared,
            "recomputed_objective": objective,
            "objective_difference": None if declared is None else objective - declared,
            "max_row_violation": max_row_violation,
            "worst_row": worst_row,
            "selected_integer_count": len(selected),
            "selected_integer_cost": sum(v["cost"] for v in selected),
            "selected_integer_variables": selected,
            "active_continuous_variables": active_continuous,
        },
        "notes": [
            "Gurobi was used only as an MPS parser; optimize and presolve were not called.",
            "The dominance count is an elementary unit-cover test and is not used as a proof until special rows and non-unit coefficients are accounted for.",
        ],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "objective": objective,
        "max_row_violation": max_row_violation,
        "selected": len(selected),
        "duplicates": len(duplicate_groups),
        "dominated": len(dominated),
    }))


if __name__ == "__main__":
    main()
