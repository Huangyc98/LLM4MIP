"""Certificate-producing reductions for the core4284-1064 set cover.

Gurobi is used only to read the original MPS.  The output OPB is the strict
decision problem "does a cover of original cost at most 1061 exist?" after
forced-column, row-dominance, and column-dominance reductions.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict, deque
import gzip
import hashlib
import json
from pathlib import Path
import time

import gurobipy as gp


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def read_solution(path: Path) -> tuple[float, dict[str, float]]:
    declared = None
    values = {}
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        for raw in handle:
            line = raw.strip()
            if not line:
                continue
            if line.startswith("=obj="):
                declared = float(line.split()[-1])
            else:
                pieces = line.split()
                if len(pieces) == 2:
                    values[pieces[0]] = float(pieces[1])
    if declared is None:
        raise ValueError("solution has no =obj= line")
    return declared, values


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("--cutoff", type=int, default=1061)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()

    env = gp.Env(empty=True)
    env.setParam("OutputFlag", 0)
    env.start()
    model = gp.read(str(args.model), env)
    vars_ = model.getVars()
    cons = model.getConstrs()
    xvars = [v for v in vars_ if v.VarName.startswith("X")]
    svars = [v for v in vars_ if v.VarName.startswith("S")]
    cover_cons = [c for c in cons if c.ConstrName.startswith("R") and c.Sense == ">" and abs(c.RHS - 1) < 1e-12]
    assert len(xvars) == 21705 and len(svars) == 9 and len(cover_cons) == 4284
    assert all(v.VType != gp.GRB.CONTINUOUS and v.LB == 0 and v.UB == 1 and v.Obj in (1, 2) for v in xvars)
    assert all(v.VType == gp.GRB.CONTINUOUS and v.LB == 0 and v.Obj > 0 for v in svars)

    col_name = [v.VarName for v in xvars]
    col_cost = [int(v.Obj) for v in xvars]
    model_to_col = {v.index: j for j, v in enumerate(xvars)}
    row_name = [c.ConstrName for c in cover_cons]
    row_cols: list[set[int]] = []
    col_rows: list[set[int]] = [set() for _ in xvars]
    for r, con in enumerate(cover_cons):
        expr = model.getRow(con)
        members = set()
        for p in range(expr.size()):
            v = expr.getVar(p)
            coef = expr.getCoeff(p)
            assert abs(coef - 1.0) < 1e-12 and v.index in model_to_col
            j = model_to_col[v.index]
            members.add(j)
            col_rows[j].add(r)
        assert members
        row_cols.append(members)

    declared, sparse = read_solution(args.solution)
    incumbent = {j for j, v in enumerate(xvars) if sparse.get(v.VarName, 0.0) > 0.5}
    assert sum(col_cost[j] for j in incumbent) == 1062 and abs(declared - 1062) < 1e-9
    assert all(row_cols[r] & incumbent for r in range(len(row_cols)))

    active_rows = set(range(len(row_cols)))
    active_cols = set(range(len(col_rows)))
    forced: set[int] = set()
    forced_reasons = []
    col_replacement: dict[int, int | None] = {}
    row_certificates = []
    col_certificates = []
    iteration_summaries = []

    def residual_row_cols(r: int) -> set[int]:
        return row_cols[r] & active_cols

    def residual_col_rows(j: int) -> set[int]:
        return col_rows[j] & active_rows

    def force_singletons() -> int:
        count = 0
        queue = deque(sorted(active_rows))
        queued = set(active_rows)
        while queue:
            r = queue.popleft()
            queued.discard(r)
            if r not in active_rows:
                continue
            candidates = residual_row_cols(r)
            if not candidates:
                raise RuntimeError(f"empty residual row {row_name[r]}")
            if len(candidates) != 1:
                continue
            j = next(iter(candidates))
            newly_covered = sorted(residual_col_rows(j))
            forced.add(j)
            forced_reasons.append({
                "column": col_name[j],
                "cost": col_cost[j],
                "singleton_row": row_name[r],
                "rows_removed": [row_name[q] for q in newly_covered],
            })
            active_cols.remove(j)
            for q in newly_covered:
                active_rows.remove(q)
            count += 1
            affected = set()
            for q in newly_covered:
                for k in row_cols[q] & active_cols:
                    affected.update(col_rows[k] & active_rows)
            for q in sorted(affected):
                if q not in queued:
                    queue.append(q)
                    queued.add(q)
        return count

    def remove_empty_columns() -> int:
        empty = [j for j in active_cols if not residual_col_rows(j)]
        for j in empty:
            active_cols.remove(j)
            col_replacement[j] = None
            col_certificates.append({
                "kind": "empty_positive_cost",
                "removed": col_name[j],
                "cost": col_cost[j],
                "active_row_count": 0,
            })
        return len(empty)

    def remove_dominated_rows() -> int:
        removed = set()
        # A candidate superset row must share every column of the harder row;
        # start with the column incident to the fewest active rows.
        col_active_rows = {j: residual_col_rows(j) for j in active_cols}
        for r in sorted(active_rows):
            if r in removed:
                continue
            hard = residual_row_cols(r)
            if not hard:
                raise RuntimeError(f"empty residual row {row_name[r]}")
            pivot = min(hard, key=lambda j: len(col_active_rows[j]))
            for s in sorted(col_active_rows[pivot]):
                if s == r or s in removed or s not in active_rows:
                    continue
                easy = residual_row_cols(s)
                if hard.issubset(easy):
                    removed.add(s)
                    row_certificates.append({
                        "kind": "duplicate" if hard == easy else "dominance",
                        "retained_harder_row": row_name[r],
                        "removed_easier_row": row_name[s],
                        "retained_degree": len(hard),
                        "removed_degree": len(easy),
                        "retained_columns": [col_name[j] for j in sorted(hard)],
                    })
        active_rows.difference_update(removed)
        return len(removed)

    def remove_dominated_columns() -> int:
        removed = set()
        row_active_cols = {r: residual_row_cols(r) for r in active_rows}
        for j in sorted(active_cols):
            if j in removed:
                continue
            weak = residual_col_rows(j)
            if not weak:
                continue
            pivot = min(weak, key=lambda r: len(row_active_cols[r]))
            for k in sorted(row_active_cols[pivot]):
                if k == j or k in removed or k not in active_cols:
                    continue
                if col_cost[k] > col_cost[j]:
                    continue
                strong = residual_col_rows(k)
                if weak.issubset(strong):
                    # Deterministic equal-signature direction prevents cycles.
                    if weak == strong and col_cost[k] == col_cost[j] and k > j:
                        continue
                    removed.add(j)
                    col_replacement[j] = k
                    col_certificates.append({
                        "kind": "duplicate" if weak == strong else "dominance",
                        "removed": col_name[j],
                        "representative": col_name[k],
                        "removed_cost": col_cost[j],
                        "representative_cost": col_cost[k],
                        "removed_residual_rows": [row_name[r] for r in sorted(weak)],
                        "representative_residual_degree": len(strong),
                    })
                    break
        active_cols.difference_update(removed)
        return len(removed)

    iteration = 0
    while True:
        iteration += 1
        stats = {"iteration": iteration}
        stats["forced"] = force_singletons()
        stats["empty_columns"] = remove_empty_columns()
        stats["dominated_rows"] = remove_dominated_rows()
        stats["empty_after_rows"] = remove_empty_columns()
        stats["dominated_columns"] = remove_dominated_columns()
        stats["active_rows"] = len(active_rows)
        stats["active_columns"] = len(active_cols)
        stats["forced_total"] = len(forced)
        iteration_summaries.append(stats)
        changed = sum(stats[k] for k in ("forced", "empty_columns", "dominated_rows", "empty_after_rows", "dominated_columns"))
        if changed == 0:
            break
        if iteration > 50:
            raise RuntimeError("reduction fixed point did not converge")

    forced_cost = sum(col_cost[j] for j in forced)
    residual_cutoff = args.cutoff - forced_cost
    if residual_cutoff < 0:
        raise RuntimeError("forced cost exceeds cutoff")

    def terminal(j: int) -> int | None:
        seen = set()
        while j in col_replacement:
            if j in seen:
                raise RuntimeError("replacement cycle")
            seen.add(j)
            nxt = col_replacement[j]
            if nxt is None:
                return None
            j = nxt
        return j

    mapped_incumbent = set(forced)
    for j in incumbent:
        if j in forced:
            continue
        t = terminal(j)
        if t is not None:
            if t in forced or t in active_cols:
                mapped_incumbent.add(t)
            else:
                raise RuntimeError(f"incumbent map ended at inactive {col_name[t]}")
    assert all(row_cols[r] & mapped_incumbent for r in range(len(row_cols)))
    mapped_cost = sum(col_cost[j] for j in mapped_incumbent)

    active_rows_sorted = sorted(active_rows)
    active_cols_sorted = sorted(active_cols)
    residual_index = {j: p + 1 for p, j in enumerate(active_cols_sorted)}
    opb_lines = [
        f"* #variable= {len(active_cols_sorted)} #constraint= {len(active_rows_sorted) + 1}",
        f"* original cutoff {args.cutoff}; forced offset {forced_cost}; residual cutoff {residual_cutoff}",
    ]
    for r in active_rows_sorted:
        terms = " ".join(f"+1 x{residual_index[j]}" for j in sorted(residual_row_cols(r)))
        opb_lines.append(f"{terms} >= 1 ;")
    cost_terms = " ".join(f"+{col_cost[j]} x{residual_index[j]}" for j in active_cols_sorted)
    opb_lines.append(f"{cost_terms} <= {residual_cutoff} ;")
    opb_path = args.output_dir / "strict_cutoff_1061.opb"
    opb_path.write_text("\n".join(opb_lines) + "\n", encoding="ascii")

    # Critical-row profile of the mapped incumbent.
    coverage_counts = Counter(len(row_cols[r] & mapped_incumbent) for r in range(len(row_cols)))
    critical_rows = [row_name[r] for r in range(len(row_cols)) if len(row_cols[r] & mapped_incumbent) == 1]

    mapping = {
        "forced_columns": [col_name[j] for j in sorted(forced)],
        "forced_cost": forced_cost,
        "active_columns": [
            {"opb": f"x{residual_index[j]}", "original": col_name[j], "cost": col_cost[j]}
            for j in active_cols_sorted
        ],
        "active_rows": [row_name[r] for r in active_rows_sorted],
        "column_replacements": {
            col_name[j]: (None if terminal(j) is None else col_name[terminal(j)])
            for j in sorted(col_replacement)
        },
    }
    mapping_path = args.output_dir / "mapping.json"
    mapping_path.write_text(json.dumps(mapping, indent=2) + "\n", encoding="utf-8")
    (args.output_dir / "forced_certificates.json").write_text(json.dumps(forced_reasons, indent=2) + "\n", encoding="utf-8")
    (args.output_dir / "row_dominance_certificates.json").write_text(json.dumps(row_certificates, indent=2) + "\n", encoding="utf-8")
    (args.output_dir / "column_dominance_certificates.json").write_text(json.dumps(col_certificates, indent=2) + "\n", encoding="utf-8")

    report = {
        "input": {
            "mps": str(args.model),
            "mps_sha256": sha256(args.model),
            "solution": str(args.solution),
            "solution_sha256": sha256(args.solution),
        },
        "target": {"original_cutoff": args.cutoff, "known_feasible_objective": 1062},
        "original_core": {
            "rows": len(row_cols),
            "columns": len(col_rows),
            "cost_1": sum(c == 1 for c in col_cost),
            "cost_2": sum(c == 2 for c in col_cost),
        },
        "reductions": {
            "iterations": iteration_summaries,
            "forced_columns": len(forced),
            "forced_cost": forced_cost,
            "row_dominance_certificates": len(row_certificates),
            "column_removal_certificates": len(col_certificates),
            "residual_rows": len(active_rows),
            "residual_columns": len(active_cols),
            "residual_cost_1": sum(col_cost[j] == 1 for j in active_cols),
            "residual_cost_2": sum(col_cost[j] == 2 for j in active_cols),
            "residual_cutoff": residual_cutoff,
        },
        "incumbent": {
            "official_cost": 1062,
            "official_support": len(incumbent),
            "mapped_cost": mapped_cost,
            "mapped_support": len(mapped_incumbent),
            "coverage_count_histogram": dict(sorted(coverage_counts.items())),
            "critical_rows_covered_once": len(critical_rows),
            "critical_row_names": critical_rows,
            "mapped_original_columns": [col_name[j] for j in sorted(mapped_incumbent)],
        },
        "artifacts": {
            "opb": str(opb_path),
            "mapping": str(mapping_path),
            "opb_sha256": sha256(opb_path),
            "mapping_sha256": sha256(mapping_path),
        },
        "runtime_seconds": time.perf_counter() - started,
        "gurobi_used_as_parser_only": True,
        "optimize_called": False,
    }
    report_path = args.output_dir / "reduction_report.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "forced": len(forced),
        "forced_cost": forced_cost,
        "residual_rows": len(active_rows),
        "residual_columns": len(active_cols),
        "mapped_incumbent_cost": mapped_cost,
        "critical_rows": len(critical_rows),
        "seconds": report["runtime_seconds"],
    }))


if __name__ == "__main__":
    main()
