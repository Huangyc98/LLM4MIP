"""Short exact baseline on the certificate-reduced set-cover core."""
from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path
import time

import gurobipy as gp


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("original_mps", type=Path)
    parser.add_argument("reduction_dir", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("log", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--time-limit", type=float, default=600.0)
    args = parser.parse_args()

    reduction = json.loads((args.reduction_dir / "reduction_report.json").read_text(encoding="utf-8"))
    mapping = json.loads((args.reduction_dir / "mapping.json").read_text(encoding="utf-8"))
    active_records = mapping["active_columns"]
    active_names = [rec["original"] for rec in active_records]
    costs = [int(rec["cost"]) for rec in active_records]
    index = {name: j for j, name in enumerate(active_names)}
    active_row_names = mapping["active_rows"]
    active_row_index = {name: r for r, name in enumerate(active_row_names)}
    forced_names = set(mapping["forced_columns"])
    forced_cost = int(reduction["reductions"]["forced_cost"])
    incumbent_names = set(reduction["incumbent"]["mapped_original_columns"])
    incumbent_active = {index[name] for name in incumbent_names if name in index}

    parse_env = gp.Env(empty=True)
    parse_env.setParam("OutputFlag", 0)
    parse_env.start()
    original = gp.read(str(args.original_mps), parse_env)
    row_members = [set() for _ in active_row_names]
    for con in original.getConstrs():
        if con.ConstrName not in active_row_index:
            continue
        r = active_row_index[con.ConstrName]
        expr = original.getRow(con)
        for p in range(expr.size()):
            name = expr.getVar(p).VarName
            if name in index:
                assert abs(expr.getCoeff(p) - 1.0) <= 1e-12
                row_members[r].add(index[name])
        assert row_members[r]

    args.log.parent.mkdir(parents=True, exist_ok=True)
    solve_env = gp.Env(empty=True)
    solve_env.setParam("OutputFlag", 1)
    solve_env.setParam("LogFile", str(args.log))
    solve_env.start()
    reduced = gp.Model("core4284-certificate-reduced", env=solve_env)
    reduced.Params.TimeLimit = args.time_limit
    reduced.Params.Threads = 8
    reduced.Params.Seed = 1
    reduced.Params.MIPGap = 0.0
    x = reduced.addVars(len(active_names), vtype=gp.GRB.BINARY, name="x")
    reduced.setObjective(forced_cost + gp.quicksum(costs[j] * x[j] for j in range(len(active_names))), gp.GRB.MINIMIZE)
    for r, members in enumerate(row_members):
        reduced.addConstr(gp.quicksum(x[j] for j in members) >= 1, name=active_row_names[r])
    for j in incumbent_active:
        x[j].Start = 1.0
    reduced.update()
    reduced_model_path = args.output.with_name("reduced_exact_model.mps")
    reduced.write(str(reduced_model_path))

    relaxed = reduced.relax()
    relaxed.Params.OutputFlag = 0
    lp_started = time.perf_counter()
    relaxed.optimize()
    lp_wall = time.perf_counter() - lp_started
    lp_result = {
        "status": int(relaxed.Status),
        "objective": relaxed.ObjVal if relaxed.Status == gp.GRB.OPTIMAL else None,
        "runtime": relaxed.Runtime,
        "wall_seconds": lp_wall,
    }

    mip_started = time.perf_counter()
    reduced.optimize()
    mip_wall = time.perf_counter() - mip_started
    has_solution = reduced.SolCount > 0
    solver_result = {
        "status": int(reduced.Status),
        "status_name": {
            gp.GRB.OPTIMAL: "OPTIMAL",
            gp.GRB.TIME_LIMIT: "TIME_LIMIT",
            gp.GRB.INTERRUPTED: "INTERRUPTED",
            gp.GRB.INFEASIBLE: "INFEASIBLE",
        }.get(reduced.Status, str(reduced.Status)),
        "objective": reduced.ObjVal if has_solution else None,
        "bound": reduced.ObjBound,
        "gap": reduced.MIPGap if has_solution else None,
        "nodes": reduced.NodeCount,
        "runtime": reduced.Runtime,
        "wall_seconds": mip_wall,
        "solutions": reduced.SolCount,
    }

    lifted_audit = None
    if has_solution:
        selected_names = forced_names | {active_names[j] for j in range(len(active_names)) if x[j].X > 0.5}
        values = {name: 1.0 for name in selected_names}
        objective = sum(v.Obj * values.get(v.VarName, 0.0) for v in original.getVars()) + original.ObjCon
        max_row_violation = 0.0
        worst_row = None
        for con in original.getConstrs():
            expr = original.getRow(con)
            lhs = sum(expr.getCoeff(p) * values.get(expr.getVar(p).VarName, 0.0) for p in range(expr.size()))
            if con.Sense == ">":
                violation = max(con.RHS - lhs, 0.0)
            elif con.Sense == "<":
                violation = max(lhs - con.RHS, 0.0)
            else:
                violation = abs(lhs - con.RHS)
            if violation > max_row_violation:
                max_row_violation, worst_row = violation, con.ConstrName
        lifted_audit = {
            "objective": objective,
            "selected_columns": len(selected_names),
            "max_original_row_violation": max_row_violation,
            "worst_row": worst_row,
        }
        assert max_row_violation <= 1e-9
        args.solution.parent.mkdir(parents=True, exist_ok=True)
        with gzip.open(args.solution, "wt", encoding="utf-8", newline="\n") as handle:
            handle.write(f"=obj= {objective:.12g}\n")
            for name in sorted(selected_names):
                handle.write(f"{name} 1\n")

    result = {
        "reduced_model": str(reduced_model_path),
        "dimensions": {"rows": len(active_row_names), "columns": len(active_names), "forced_offset": forced_cost},
        "lp_relaxation": lp_result,
        "mip": solver_result,
        "lifted_original_audit": lifted_audit,
        "strict_optimality_claim": bool(
            reduced.Status == gp.GRB.OPTIMAL
            and lifted_audit is not None
            and lifted_audit["max_original_row_violation"] <= 1e-9
            and abs(reduced.ObjVal - reduced.ObjBound) <= 1e-7
        ),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"lp": lp_result, "mip": solver_result, "audit": lifted_audit}))


if __name__ == "__main__":
    main()
