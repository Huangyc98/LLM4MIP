# Final research report — `core4284-1064`

## Outcome

**Not solved.** The official objective-1062 solution is independently verified
on the original MPS, but objective 1061 has neither been found nor rigorously
excluded. The strongest portable certificate produced here proves

\[
1055 \le \operatorname{OPT} \le 1062.
\]

No primal or optimality improvement over the public 1062 incumbent is claimed.

## Original model and application

MIPLIB classifies the instance as an open Italian-railway set-covering model.
It has 21,714 variables, 4,287 constraints, and 245,121 nonzeros. Direct MPS
inspection recovers the effective problem as a weighted binary set cover:

- 4,284 unit covering rows;
- 21,705 binary columns;
- 5,945 columns of cost 1 and 15,760 of cost 2;
- one cardinality row that is redundant at incumbent-scale objectives;
- one globally redundant `INERZIA` row;
- one loose objective-copy row and nine nonnegative continuous variables that
  are optimally zero.

This classification agrees with the Caprara–Fischetti–Toth railway crew-
scheduling SCP literature. Full authoritative links and file hashes are in
`sources/sources.md`.

The official witness selects 703 binary columns: 344 cost-1 columns and 359
cost-2 columns. Re-evaluation against every original MPS row gives objective
1062 and maximum row, bound, and integrality violation zero.

## Exact structural reduction

`scripts/reduce_core.py` applies only transformations with recorded witnesses:

1. singleton-row forced-column propagation;
2. duplicate and dominated covering-row removal;
3. duplicate and no-more-expensive superset column removal;
4. repetition to a fixed point.

The resulting cutoff-equivalent core has:

- 20 forced columns of total cost 26;
- 3,384 residual rows and 15,272 residual columns;
- 826 row-removal certificates;
- 6,413 column-removal certificates.

Thus an original solution of cost at most 1061 exists if and only if the
residual core has a cover of cost at most 1035. The reduction directory contains
the maps, individual witnesses, hashes, and a strict-cutoff OPB model.

## Structural algorithms tried

### CFT-style pricing and critical-owner exchange

The mapped incumbent covers 2,781 residual rows exactly once. A sparse
Lagrangian/subgradient phase identified expensive rows and candidate columns.
It was followed by 986 critical-owner ruin/recreate neighborhoods, each using
an exact small repair model only after a combinatorial destroy/candidate step.
All 986 cutoff repairs were infeasible, using just 1.815 solver seconds total.

This establishes local rigidity only. It is not global evidence because the
outside incumbent decisions and candidate columns were fixed in each repair.

### Bounded exact baseline

A single 600-second run on the exact reduced core retained objective 1062 and
ended with integer dual bound 1055 after 4,826 nodes (0.6591% gap). The LP
relaxation was 1054.054491274844 including the forced cost. This was a
calibration run, not a parameter sweep.

### API proposal audit and disjunctive test

The API initially proposed an integer row-packing vector of residual value
1036. That cannot exist: every such vector is feasible for the ordinary LP
dual, whose residual optimum is only 1028.054491274844. This contradiction was
fed back; the API explicitly retracted the proposal.

Its replacement was a finite disjunction on high-impact incumbent columns.
The implemented experiment chose five cost-2 columns owning the most uniquely
covered rows and exhaustively tested all 32 binary assignments while retaining
all 15,272 residual columns at every leaf. Each leaf received 12 seconds. All
32 reached the time limit, none proved infeasible, and none found a cutoff
witness. This reinforces that the millisecond local-repair infeasibilities do
not translate into easy global leaf closure.

## Checkable lower-bound certificate

The final useful artifact is not the solver's branch-and-bound state. A pure
covering LP was solved and its nonnegative row prices were rounded downward to
rationals with denominator \(10^9\). For every residual column \(j\), the
checker verifies in integer arithmetic

\[
\sum_{r\in R_j} y_r \le c_j.
\]

The checked residual dual value is 1028.054387455. Adding the forced cost gives
1054.054387455. Since every original feasible solution has integral objective,

\[
\operatorname{OPT}\ge \lceil 1054.054387455\rceil=1055.
\]

`artifacts/lp_dual_certificate.json` stores all positive rational row prices,
the incidence hash, and the exact numerator. The independent checker reparses
the original MPS, reconstructs the reduced incidence matrix, matches its hash,
and verifies all 15,272 inequalities without optimizing. Its output is
`artifacts/lp_dual_certificate_check.json` with `valid: true` and no violations.

## Why optimality remains open

The certified interval still contains eight integer objective values. The
critical-row neighborhoods were too local, while the exhaustive five-variable
disjunction was too shallow: root processing alone consumed most leaf limits.
No proof-producing PB/SAT solver was available locally, so the emitted
`strict_cutoff_1061.opb` was not resolved into a portable unsatisfiability proof.

The best next route is a proof-producing PB/MaxSAT run on the reduced OPB, or a
larger externally checkable disjunctive proof guided by conflict/core data.
Merely repeating generic MIP parameter changes is not supported by these
observations.

## Reproduction pointers

- `structure/structure.json` and `structure/structure.compact.json`: read-only
  Gurobi structure extraction.
- `structure/deep_structure.json`: semantic audit and original witness check.
- `artifacts/reduction/`: exact reduction maps, certificates, and OPB cutoff.
- `artifacts/critical_exchange*.json`: pricing and 986 neighborhood outcomes.
- `logs/reduced_gurobi_600s.log`: bounded baseline log.
- `artifacts/disjunctive_core.json`: all 32 exhaustive leaf outcomes.
- `artifacts/lp_dual_certificate.json`: rational lower-bound witness.
- `artifacts/lp_dual_certificate_check.json`: exact independent audit.
- `reports/effort_ledger.md`: time, solver, and API accounting.
