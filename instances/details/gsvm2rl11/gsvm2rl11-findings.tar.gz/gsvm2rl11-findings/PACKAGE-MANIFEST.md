# Package manifest: gsvm2rl11

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 73
Excluded source files: 1

## Included files

- `README.md`
- `experiments.json`
- `experiments.md`
- `final_report.md`
- `method_selection.md`
- `methods/analyze_blocks.py`
- `methods/conflict_exchange.py`
- `methods/conflict_exchange_fresh.py`
- `methods/inspect_gsvm.py`
- `methods/mixed_incidence_search.py`
- `methods/private_binary_closure.py`
- `methods/repair_sparse_incumbent.py`
- `methods/self_contained_exchange.py`
- `methods/self_contained_incidence_search.py`
- `methods/singleton_elimination_search.py`
- `methods/sparse_binary_repair.py`
- `methods/sparse_exchange.py`
- `private_binary_closure_plan.md`
- `reporting_bundle.json`
- `result.json`
- `runs/copt-20260903-175003-45824498/best.sol`
- `runs/copt-20260903-175003-45824498/driver.stderr`
- `runs/copt-20260903-175003-45824498/driver.stdout`
- `runs/copt-20260903-175003-45824498/result.json`
- `runs/copt-20260903-175003-45824498/solver.log`
- `runs/custom-20260903-175815-cca15fb8/algorithm.stderr`
- `runs/custom-20260903-175815-cca15fb8/algorithm.stdout`
- `runs/custom-20260903-175815-cca15fb8/driver.stderr`
- `runs/custom-20260903-175815-cca15fb8/driver.stdout`
- `runs/custom-20260903-175815-cca15fb8/method_result.json`
- `runs/custom-20260903-175815-cca15fb8/result.json`
- `runs/custom-20260903-175815-cca15fb8/structural_analysis.json`
- `runs/custom-20260903-180125-835e6017/algorithm.stderr`
- `runs/custom-20260903-180125-835e6017/algorithm.stdout`
- `runs/custom-20260903-180125-835e6017/driver.stderr`
- `runs/custom-20260903-180125-835e6017/driver.stdout`
- `runs/custom-20260903-180125-835e6017/incidence_search_report.json`
- `runs/custom-20260903-180125-835e6017/method_result.json`
- `runs/custom-20260903-180125-835e6017/result.json`
- `runs/custom-20260903-184335-4a78fda4/algorithm.stderr`
- `runs/custom-20260903-184335-4a78fda4/algorithm.stdout`
- `runs/custom-20260903-184335-4a78fda4/driver.stderr`
- `runs/custom-20260903-184335-4a78fda4/driver.stdout`
- `runs/custom-20260903-184335-4a78fda4/method_result.json`
- `runs/custom-20260903-184335-4a78fda4/result.json`
- `runs/custom-20260903-184533-2d18baf6/algorithm.stderr`
- `runs/custom-20260903-184533-2d18baf6/algorithm.stdout`
- `runs/custom-20260903-184533-2d18baf6/driver.stderr`
- `runs/custom-20260903-184533-2d18baf6/driver.stdout`
- `runs/custom-20260903-184533-2d18baf6/method_result.json`
- `runs/custom-20260903-184533-2d18baf6/result.json`
- `runs/custom-20260903-184533-2d18baf6/sparse_binary_repair_report.json`
- `runs/gurobi-20260903-174959-389eab23/best.sol`
- `runs/gurobi-20260903-174959-389eab23/driver.stderr`
- `runs/gurobi-20260903-174959-389eab23/driver.stdout`
- `runs/gurobi-20260903-174959-389eab23/result.json`
- `runs/gurobi-20260903-174959-389eab23/solver.log`
- `runs/gurobi-20260903-180936-fb7410f6/best.sol`
- `runs/gurobi-20260903-180936-fb7410f6/driver.stderr`
- `runs/gurobi-20260903-180936-fb7410f6/driver.stdout`
- `runs/gurobi-20260903-180936-fb7410f6/result.json`
- `runs/gurobi-20260903-180936-fb7410f6/solver.log`
- `solutions/public/gsvm2rl11-1.sol.gz`
- `solutions/public/gsvm2rl11-2.sol.gz`
- `strategy.md`
- `structure-gurobi.log`
- `structure.json`
- `verification/copt-20260903-175003-45824498.exact-check.json`
- `verification/copt-20260903-175003-45824498.exact-check.txt`
- `verification/gurobi-20260903-174959-389eab23.exact-check.json`
- `verification/gurobi-20260903-174959-389eab23.exact-check.txt`
- `verification/gurobi-20260903-180936-fb7410f6.exact-check.json`
- `verification/gurobi-20260903-180936-fb7410f6.exact-check.txt`

## Excluded files

- `input/gsvm2rl11.mps.gz (2088949 bytes; raw benchmark input; sha256 cb0ac74efdefd93f223634473d8d9c4fd7cf5f0478c849ab6000dd347f04ead2)`
