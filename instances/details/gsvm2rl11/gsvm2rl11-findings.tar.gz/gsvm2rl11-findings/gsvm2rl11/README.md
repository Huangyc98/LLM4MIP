# `gsvm2rl11` Experiment Archive

## Result at a glance

This archive contains a **partial feasible result**, not a proof of optimality or infeasibility.

| Item | Value |
|---|---:|
| Objective sense | minimize |
| Best solver-reported primal | `18539.127113105696` |
| Verification of raw best primal | not independently verified |
| Best tolerance-verified primal | `18539.12716192643` |
| Verification tolerance | `1e-9` |
| Best dual bound | `2096.755457820071` |
| Combined relative gap | `0.8869010690186253` |
| Optimality proved | no |
| Infeasibility proved | no |

The best raw Gurobi incumbent was slightly better numerically but did not pass the controller's independent check. Use `18539.12716192643` when citing the verified feasible solution.

## Experiment overview

Seven runs were recorded:

- Short 300-second COPT baseline: `TIMEOUT`, verified incumbent `46710.228668301774`, dual bound `1915.16751668607`.
- Short 300-second Gurobi baseline: `TIME_LIMIT`, raw incumbent `18539.127113105696` (not independently verified), best dual bound `2096.755457820071`.
- Four structure-specific custom Python attempts: one `completed` and three `unsupported`; none returned a primal bound, dual bound, or proof.
- Longer 1800-second Gurobi follow-up: `TIME_LIMIT`, verified incumbent `18539.12716192643`, dual bound `1662.54834974925`.

A time limit is not an optimality or infeasibility result. The custom `unsupported` statuses likewise establish nothing about feasibility.

## Reproducibility

The experiment used COPT, Gurobi, and CPU-only custom Python jobs in a controlled bubblewrap sandbox with no network access and read-only model inputs. Time, memory, output-size, and thread limits were controller-enforced. Python standard-library and C++17 capabilities were available; CaDiCaL and `drat-trim` were configured, but no successful proof was produced with them.

Exact host-machine details, solver/tool version strings, numeric sandbox limits, full parameter dictionaries, and explicit random seeds were not visible in the compressed archival summaries used to draft this README. They are not guessed. Where available, consult the controller-managed `experiments.json`, `result.json`, and `reporting_bundle.json`. The baseline budgets were 300 seconds per solver, and the longer Gurobi run used 1800 seconds. No explicit seed was reported in the compressed summary.

Custom source paths should be read from the retained file inventory and machine-readable experiment records. The final report deliberately avoids inventing filenames that were absent from the compressed summary.

## Files

- [`final_report.md`](final_report.md): detailed results, verification boundary, methods, reproducibility notes, and recommendation
- [`experiments.md`](experiments.md): controller-generated experiment table
- `experiments.json`: controller-managed machine-readable run ledger
- `result.json`: controller-managed result record
- `reporting_bundle.json`: consolidated reporting metadata

## Recommended continuation

Repair the custom reader that produced the rapid `unsupported` exits, validate its recognized model structure with a deterministic dry run, and independently check every generated candidate. A future exact-solver experiment should focus on materially strengthening the lower bound while retaining the verified incumbent, because the archived combined gap is about `88.69%`.
