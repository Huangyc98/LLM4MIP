import argparse, gzip, json, math, os, re, time


def open_model(path):
    return gzip.open(path, 'rt', errors='replace') if path.endswith('.gz') else open(path, 'r', errors='replace')


def parse_mps(path):
    rows = {}
    row_order = []
    objrow = None
    sense = 'MIN'
    cols = {}
    obj = {}
    rhs = {}
    ranges = set()
    lb, ub = {}, {}
    integer = set()
    binary = set()
    section = None
    intmode = False
    with open_model(path) as f:
        for raw in f:
            s = raw.strip()
            if not s or s.startswith('*'):
                continue
            t = s.split()
            key = t[0].upper()
            if key in ('NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA','OBJSENSE','OBJNAME'):
                section = key
                if key == 'ENDATA':
                    break
                continue
            if section == 'OBJSENSE':
                u = t[0].upper()
                if u.startswith('MAX'): sense = 'MAX'
                elif u.startswith('MIN'): sense = 'MIN'
                continue
            if section == 'ROWS':
                typ, name = t[0].upper(), t[1]
                if typ == 'N' and objrow is None:
                    objrow = name
                else:
                    rows[name] = typ
                    row_order.append(name)
                continue
            if section == 'COLUMNS':
                if any('MARKER' in z.upper() for z in t):
                    u = ' '.join(t).upper()
                    if 'INTORG' in u: intmode = True
                    if 'INTEND' in u: intmode = False
                    continue
                var = t[0]
                if intmode: integer.add(var)
                cols.setdefault(var, {})
                for k in range(1, len(t)-1, 2):
                    r = t[k]
                    try: v = float(t[k+1])
                    except ValueError: continue
                    if r == objrow:
                        obj[var] = obj.get(var, 0.0) + v
                    elif r in rows:
                        cols[var][r] = cols[var].get(r, 0.0) + v
                continue
            if section == 'RHS':
                for k in range(1, len(t)-1, 2):
                    r = t[k]
                    if r in rows and r not in rhs:
                        try: rhs[r] = float(t[k+1])
                        except ValueError: pass
                continue
            if section == 'RANGES':
                for k in range(1, len(t)-1, 2):
                    if t[k] in rows: ranges.add(t[k])
                continue
            if section == 'BOUNDS':
                typ = t[0].upper()
                if len(t) < 3: continue
                var = t[2]
                try: val = float(t[3]) if len(t) > 3 else 0.0
                except ValueError: val = 0.0
                if typ == 'LO': lb[var] = val
                elif typ == 'UP': ub[var] = val
                elif typ == 'FX': lb[var] = val; ub[var] = val
                elif typ == 'FR': lb[var] = -math.inf; ub[var] = math.inf
                elif typ == 'MI': lb[var] = -math.inf
                elif typ == 'PL': ub[var] = math.inf
                elif typ == 'BV':
                    lb[var] = 0.0; ub[var] = 1.0
                    integer.add(var); binary.add(var)
                elif typ == 'LI': lb[var] = val; integer.add(var)
                elif typ == 'UI': ub[var] = val; integer.add(var)
                elif typ == 'SC': ub[var] = val
    variables = list(cols)
    for v in variables:
        lb.setdefault(v, 0.0)
        ub.setdefault(v, math.inf)
        if v in integer and lb[v] == 0.0 and ub[v] == 1.0: binary.add(v)
    return rows, cols, obj, rhs, ranges, lb, ub, integer, binary, sense


def read_solution(path):
    x = {}
    original = open(path, 'r', errors='replace').read()
    for line in original.splitlines():
        s = line.strip()
        if not s or s.startswith('#'): continue
        t = s.split()
        if len(t) >= 2:
            try: x[t[0]] = float(t[1])
            except ValueError: pass
    return x, original


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--incumbent', required=True)
    ap.add_argument('--pair-limit', type=int, default=250000)
    a = ap.parse_args()
    start = time.time()
    rows, cols, obj, rhs, ranges, lb, ub, ints, bins, sense = parse_mps(a.model)
    x, original = read_solution(a.incumbent)
    for v in cols: x.setdefault(v, 0.0)
    byrow = {r: [] for r in rows}
    act = {r: 0.0 for r in rows}
    for v, cc in cols.items():
        xv = x[v]
        for r, c in cc.items():
            byrow[r].append((v,c)); act[r] += c*xv
    tol = 2e-10
    frozen = set()
    for v, cc in cols.items():
        if any(rows[r] == 'E' or r in ranges for r in cc): frozen.add(v)

    def feasible_delta(v, d):
        nv = x[v] + d
        if nv < lb[v]-tol or nv > ub[v]+tol: return False
        for r,c in cols[v].items():
            z = act[r] + c*d; b = rhs.get(r,0.0); typ = rows[r]
            if typ == 'L' and z > b + tol: return False
            if typ == 'G' and z < b - tol: return False
            if typ == 'E' and abs(z-b) > tol: return False
        return True

    def apply(v,d):
        x[v] += d
        for r,c in cols[v].items(): act[r] += c*d

    sign = 1.0 if sense == 'MIN' else -1.0
    initial_obj = sum(obj.get(v,0.0)*x[v] for v in cols)
    moves = 0
    # Coordinate descent is especially effective for sparse packing rows.
    candidates = [v for v in ints if v not in frozen and abs(obj.get(v,0.0)) > 0]
    candidates.sort(key=lambda v: sign*obj.get(v,0.0))
    changed = True
    while changed:
        changed = False
        for v in candidates:
            c = sign*obj.get(v,0.0)
            if c < 0:
                target = ub[v]
                if not math.isfinite(target): continue
                target = math.floor(target + tol)
            else:
                target = lb[v]
                if not math.isfinite(target): continue
                target = math.ceil(target - tol)
            d = target-x[v]
            if abs(d) > tol and c*d < -tol and feasible_delta(v,d):
                apply(v,d); moves += 1; changed = True

    # One-for-one exchanges traverse faces on which direct additions are blocked.
    selected = [v for v in bins if v not in frozen and x[v] > 0.5]
    absent = [v for v in bins if v not in frozen and x[v] < 0.5]
    absent.sort(key=lambda v: sign*obj.get(v,0.0))
    tests = 0; exchanges = 0
    improved = True
    while improved and tests < a.pair_limit:
        improved = False
        selected.sort(key=lambda v: sign*obj.get(v,0.0), reverse=True)
        for outv in selected:
            apply(outv,-1.0)
            accepted = None
            for inv in absent:
                tests += 1
                delta_obj = sign*(obj.get(inv,0.0)-obj.get(outv,0.0))
                if delta_obj < -tol and feasible_delta(inv,1.0):
                    accepted = inv; break
                if tests >= a.pair_limit: break
            if accepted is not None:
                apply(accepted,1.0)
                selected.remove(outv); selected.append(accepted)
                absent.remove(accepted); absent.append(outv)
                exchanges += 1; improved = True
                break
            apply(outv,1.0)
            if tests >= a.pair_limit: break

    final_obj = sum(obj.get(v,0.0)*x[v] for v in cols)
    maxviol = 0.0
    for r,typ in rows.items():
        b=rhs.get(r,0.0); z=act[r]
        viol = max(0.0,z-b) if typ=='L' else max(0.0,b-z) if typ=='G' else abs(z-b)
        maxviol=max(maxviol,viol)
    improved_obj = sign*(final_obj-initial_obj) < -1e-8
    if improved_obj and maxviol <= 5e-10:
        with open('best.sol','w') as f:
            f.write('# Objective value = %.17g\n' % final_obj)
            for v in cols:
                if abs(x[v]) > 1e-15: f.write('%s %.17g\n' % (v,x[v]))
    else:
        with open('best.sol','w') as f: f.write(original)
    result = {'status':'candidate_generated','method':'sparse_row_coordinate_and_binary_exchange','objective_sense':sense,'initial_objective':initial_obj,'candidate_objective':final_obj,'emitted_improvement':bool(improved_obj and maxviol <= 5e-10),'coordinate_moves':moves,'exchanges':exchanges,'exchange_tests':tests,'maximum_internal_row_violation':maxviol,'integer_variables':len(ints),'binary_variables':len(bins),'frozen_equality_or_ranged_variables':len(frozen),'runtime_seconds':time.time()-start}
    with open('method_result.json','w') as f: json.dump(result,f,indent=2,sort_keys=True)
    with open('search_diagnostics.json','w') as f: json.dump(result,f,indent=2,sort_keys=True)

if __name__ == '__main__': main()
