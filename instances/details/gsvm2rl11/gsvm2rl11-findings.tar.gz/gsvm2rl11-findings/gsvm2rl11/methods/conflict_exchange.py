import argparse, gzip, json, math, os, time
from collections import defaultdict


def open_text(path):
    return gzip.open(path, 'rt', errors='replace') if path.endswith('.gz') else open(path, 'r', errors='replace')


def parse_mps(path):
    rows = {}
    objrow = None
    cols = defaultdict(dict)
    rhs = defaultdict(float)
    lb, ub = {}, {}
    integer = set()
    section = None
    int_mode = False
    sense = 'MIN'
    has_ranges = False
    with open_text(path) as f:
        for raw in f:
            s = raw.strip()
            if not s or s.startswith('*'):
                continue
            tok = s.split()
            head = tok[0].upper()
            if head in ('NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA','OBJSENSE'):
                section = head
                if head == 'RANGES':
                    has_ranges = True
                if head == 'ENDATA':
                    break
                continue
            if section == 'OBJSENSE':
                if head.startswith('MAX'):
                    sense = 'MAX'
                elif head.startswith('MIN'):
                    sense = 'MIN'
            elif section == 'ROWS':
                if len(tok) >= 2:
                    typ, name = tok[0].upper(), tok[1]
                    if typ == 'N' and objrow is None:
                        objrow = name
                    elif typ in ('L','G','E'):
                        rows[name] = typ
            elif section == 'COLUMNS':
                if len(tok) >= 3 and tok[1].strip("'").upper() == 'MARKER':
                    marker = tok[2].strip("'").upper()
                    int_mode = marker == 'INTORG'
                    continue
                if len(tok) < 3:
                    continue
                var = tok[0]
                if int_mode:
                    integer.add(var)
                for k in range(1, len(tok)-1, 2):
                    r = tok[k]
                    try:
                        v = float(tok[k+1])
                    except ValueError:
                        continue
                    cols[var][r] = cols[var].get(r, 0.0) + v
            elif section == 'RHS':
                for k in range(1, len(tok)-1, 2):
                    try:
                        rhs[tok[k]] = float(tok[k+1])
                    except ValueError:
                        pass
            elif section == 'BOUNDS' and len(tok) >= 3:
                typ, var = tok[0].upper(), tok[2]
                val = float(tok[3]) if len(tok) >= 4 else 0.0
                if typ == 'BV':
                    integer.add(var); lb[var] = 0.0; ub[var] = 1.0
                elif typ in ('LI','SI'):
                    integer.add(var); lb[var] = val
                elif typ in ('UI',):
                    integer.add(var); ub[var] = val
                elif typ == 'LO': lb[var] = val
                elif typ == 'UP': ub[var] = val
                elif typ == 'FX': lb[var] = val; ub[var] = val
                elif typ == 'FR': lb[var] = -math.inf; ub[var] = math.inf
                elif typ == 'MI': lb[var] = -math.inf
                elif typ == 'PL': ub[var] = math.inf
    variables = list(cols.keys())
    for v in variables:
        lb.setdefault(v, 0.0)
        ub.setdefault(v, math.inf)
    return rows, objrow, cols, rhs, lb, ub, integer, sense, has_ranges


def read_solution(path):
    x = {}
    with open(path, 'r', errors='replace') as f:
        for line in f:
            s = line.strip()
            if not s or s.startswith('#'):
                continue
            t = s.split()
            if len(t) >= 2:
                try:
                    x[t[0]] = float(t[1])
                except ValueError:
                    pass
    return x


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--start', required=True)
    ap.add_argument('--seconds', type=int, default=3500)
    ap.add_argument('--candidate-limit', type=int, default=2500)
    ap.add_argument('--partner-limit', type=int, default=5000)
    a = ap.parse_args()
    started = time.time()
    deadline = started + max(10, a.seconds - 15)
    rows, objrow, cols, rhs, lb, ub, integer, sense, has_ranges = parse_mps(a.model)
    x = read_solution(a.start)
    for v in cols:
        x.setdefault(v, 0.0)
    objective = {v: data.get(objrow, 0.0) for v, data in cols.items()}
    rowvars = defaultdict(list)
    activity = defaultdict(float)
    for v, data in cols.items():
        xv = x[v]
        for r, coef in data.items():
            if r == objrow or r not in rows:
                continue
            rowvars[r].append((v, coef))
            activity[r] += coef * xv
    tol = 2e-10
    def row_bad(r, val):
        b = rhs.get(r, 0.0)
        typ = rows[r]
        if typ == 'L': return val > b + tol
        if typ == 'G': return val < b - tol
        return abs(val-b) > tol
    initial_bad = [r for r in rows if row_bad(r, activity.get(r, 0.0))]
    binary = []
    for v in integer:
        if v in cols and abs(lb.get(v,0.0)) <= tol and abs(ub.get(v,math.inf)-1.0) <= tol and (abs(x[v]) <= 1e-7 or abs(x[v]-1.0) <= 1e-7):
            x[v] = 1.0 if x[v] > 0.5 else 0.0
            binary.append(v)
    direction = 1.0 if sense == 'MIN' else -1.0
    def flip_delta(v):
        return 1.0 - 2.0*x[v]
    def obj_value(vals):
        return sum(objective.get(v,0.0)*vals.get(v,0.0) for v in cols)
    initial_obj = obj_value(x)
    accepted_one = 0
    accepted_two = 0
    tested_pairs = 0
    passes = 0
    if not has_ranges and not initial_bad:
        while time.time() < deadline:
            passes += 1
            improving = []
            for v in binary:
                od = direction*objective.get(v,0.0)*flip_delta(v)
                if od < -1e-12:
                    improving.append((od, v))
            improving.sort()
            improving = improving[:a.candidate_limit]
            moved = False
            for _, v in improving:
                if time.time() >= deadline: break
                dv = flip_delta(v)
                affected1 = {r: coef*dv for r,coef in cols[v].items() if r in rows}
                bad = [r for r,d in affected1.items() if row_bad(r, activity.get(r,0.0)+d)]
                if not bad:
                    x[v] = 1.0-x[v]
                    for r,d in affected1.items(): activity[r] += d
                    accepted_one += 1; moved = True; break
                pool = {}
                seed_rows = sorted(bad, key=lambda r: len(rowvars[r]))[:3]
                for r in seed_rows:
                    for w,_ in rowvars[r]:
                        if w != v and w in integer and w in cols and abs(lb.get(w,0.0)) <= tol and abs(ub.get(w,math.inf)-1.0) <= tol and (abs(x[w]) <= tol or abs(x[w]-1.0) <= tol):
                            pool[w] = direction*objective.get(w,0.0)*flip_delta(w)
                partners = sorted(pool, key=lambda w: pool[w])[:a.partner_limit]
                for w in partners:
                    tested_pairs += 1
                    if direction*(objective.get(v,0.0)*dv + objective.get(w,0.0)*flip_delta(w)) >= -1e-12:
                        continue
                    dw = flip_delta(w)
                    changes = dict(affected1)
                    for r,c in cols[w].items():
                        if r in rows: changes[r] = changes.get(r,0.0) + c*dw
                    if all(not row_bad(r, activity.get(r,0.0)+d) for r,d in changes.items()):
                        x[v] = 1.0-x[v]; x[w] = 1.0-x[w]
                        for r,d in changes.items(): activity[r] += d
                        accepted_two += 1; moved = True; break
                if moved: break
            if not moved: break
    final_bad = [r for r in rows if row_bad(r, activity.get(r,0.0))]
    final_obj = obj_value(x)
    improved = direction*(final_obj-initial_obj) < -1e-8 and not final_bad
    with open('best.sol','w') as f:
        f.write('# Conflict-guided binary exchange solution\n')
        f.write('# Objective value = %.17g\n' % final_obj)
        for v in cols:
            f.write('%s %.17g\n' % (v, x[v]))
    report = {
        'method':'conflict_guided_binary_exchange',
        'sense':sense,
        'rows':len(rows),'variables':len(cols),'binary_variables':len(binary),
        'ranges_present':has_ranges,'initial_bad_rows':len(initial_bad),'final_bad_rows':len(final_bad),
        'initial_objective':initial_obj,'final_objective':final_obj,'improved':improved,
        'accepted_one_flips':accepted_one,'accepted_two_flips':accepted_two,
        'tested_pairs':tested_pairs,'passes':passes,'runtime_seconds':time.time()-started,
        'scope':'Nonbinary variables are fixed at the verified incumbent; only feasible binary one- and two-flip exchanges are searched.'
    }
    with open('conflict_exchange_report.json','w') as f: json.dump(report,f,indent=2,sort_keys=True)
    with open('method_result.json','w') as f:
        json.dump({'status':'feasible_candidate' if not final_bad else 'diagnostic_only','objective':final_obj if not final_bad else None,'improved':improved,'artifact':'best.sol','details':'conflict_exchange_report.json'},f,indent=2)

if __name__ == '__main__':
    main()
