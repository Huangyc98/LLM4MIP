import argparse, gzip, json, math, os, random, time

INF = 1.0e100

def num(s):
    return float(s.replace('D','E').replace('d','e'))

def read_mps(path):
    op = gzip.open if path.endswith('.gz') else open
    rows = {}
    objrow = None
    cols = {}
    rhs = {}
    lb, ub = {}, {}
    integer = set()
    section = None
    sense = 'min'
    int_mode = False
    ranges = False
    with op(path, 'rt', errors='replace') as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith('*'):
                continue
            t = line.split()
            head = t[0].upper()
            if head in ('NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA','OBJSENSE','OBJNAME'):
                section = head
                if head == 'RANGES':
                    ranges = True
                if head == 'ENDATA':
                    break
                continue
            if section == 'OBJSENSE':
                if head.startswith('MAX'):
                    sense = 'max'
                elif head.startswith('MIN'):
                    sense = 'min'
                continue
            if section == 'ROWS':
                typ, name = t[0].upper(), t[1]
                if typ == 'N' and objrow is None:
                    objrow = name
                elif typ in ('L','G','E'):
                    rows[name] = typ
            elif section == 'COLUMNS':
                joined = ' '.join(t).upper()
                if 'MARKER' in joined:
                    if 'INTORG' in joined:
                        int_mode = True
                    elif 'INTEND' in joined:
                        int_mode = False
                    continue
                v = t[0]
                cols.setdefault(v, {})
                if int_mode:
                    integer.add(v)
                k = 1
                while k + 1 < len(t):
                    r, a = t[k], num(t[k+1])
                    cols[v][r] = cols[v].get(r, 0.0) + a
                    k += 2
            elif section == 'RHS':
                k = 1
                while k + 1 < len(t):
                    rhs[t[k]] = num(t[k+1])
                    k += 2
            elif section == 'BOUNDS':
                typ = t[0].upper()
                v = t[2]
                val = num(t[3]) if len(t) > 3 else 0.0
                if typ == 'LO': lb[v] = val
                elif typ == 'UP': ub[v] = val
                elif typ == 'FX': lb[v] = val; ub[v] = val
                elif typ == 'FR': lb[v] = -INF; ub[v] = INF
                elif typ == 'MI': lb[v] = -INF
                elif typ == 'PL': ub[v] = INF
                elif typ == 'BV': lb[v] = 0.0; ub[v] = 1.0; integer.add(v)
                elif typ == 'LI': lb[v] = val; integer.add(v)
                elif typ == 'UI': ub[v] = val; integer.add(v)
    names = list(cols)
    for v in names:
        lb.setdefault(v, 0.0)
        ub.setdefault(v, INF)
    return rows, objrow, cols, rhs, lb, ub, integer, sense, ranges

def read_start(path):
    ans = {}
    if not path or not os.path.exists(path):
        return ans
    with open(path, 'r', errors='replace') as f:
        for line in f:
            q = line.strip().replace('=', ' ').split()
            if len(q) >= 2 and not q[0].startswith('#'):
                try: ans[q[0]] = float(q[1])
                except ValueError: pass
    return ans

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--start', default='')
    ap.add_argument('--seed', type=int, default=1)
    ap.add_argument('--search-seconds', type=float, default=1700.0)
    a = ap.parse_args()
    rng = random.Random(a.seed)
    rows, objrow, cols, rhs, lbs, ubs, ints, sense, ranges = read_mps(a.model)
    binaries = [v for v in cols if v in ints and lbs[v] >= -1e-10 and ubs[v] <= 1.0+1e-10]
    nonbinary_int = [v for v in cols if v in ints and v not in set(binaries)]
    bindex = {v:i for i,v in enumerate(binaries)}
    cont = [v for v in cols if v not in bindex]
    objcoef = {v: cols[v].get(objrow, 0.0) for v in cols}
    incidence = {r: [] for r in rows}
    cont_occ = {v: [] for v in cont}
    for v, entries in cols.items():
        for r, coefficient in entries.items():
            if r == objrow or r not in rows or coefficient == 0.0:
                continue
            if v in bindex:
                incidence[r].append((bindex[v], coefficient))
            else:
                cont_occ[v].append((r, coefficient))
    unsupported = []
    if ranges: unsupported.append('ranged rows')
    if nonbinary_int: unsupported.append('nonbinary integer variables')
    for v, occ in cont_occ.items():
        if len(occ) > 1:
            unsupported.append('continuous variable occurring in multiple rows: '+v)
            break
    row_cont = {r: None for r in rows}
    for v, occ in cont_occ.items():
        if len(occ) == 1:
            r, coefficient = occ[0]
            if row_cont[r] is not None:
                unsupported.append('multiple continuous variables in row: '+r)
                break
            row_cont[r] = (v, coefficient)
    report = {'algorithm':'binary search after exact singleton-continuous elimination','seed':a.seed,
              'variables':len(cols),'rows':len(rows),'binary_variables':len(binaries),
              'continuous_variables':len(cont),'objective_sense':sense}
    if unsupported:
        report.update(status='unsupported', reasons=unsupported)
        with open('singleton_elimination_report.json','w') as f: json.dump(report,f,indent=2)
        with open('method_result.json','w') as f: json.dump({'status':'unsupported','reasons':unsupported},f,indent=2)
        return
    row_names = list(rows)
    rid = {r:i for i,r in enumerate(row_names)}
    inc_by_bit = [[] for _ in binaries]
    for r in row_names:
        for i,c in incidence[r]: inc_by_bit[i].append((rid[r],c))

    def row_eval(r, bsum):
        typ = rows[r]; target = rhs.get(r,0.0); cv = row_cont[r]
        if cv is None:
            if typ == 'E': viol = abs(bsum-target)
            elif typ == 'L': viol = max(0.0,bsum-target)
            else: viol = max(0.0,target-bsum)
            return viol, 0.0, None
        v, av = cv
        lo, hi = lbs[v], ubs[v]
        q = target-bsum
        if typ == 'E':
            z = q/av
            zc = min(hi,max(lo,z))
            return abs(av*zc-q), objcoef[v]*zc, zc
        if typ == 'L':
            if av > 0: hi = min(hi,q/av)
            else: lo = max(lo,q/av)
        else:
            if av > 0: lo = max(lo,q/av)
            else: hi = min(hi,q/av)
        if lo > hi + 1e-10:
            z = (lo+hi)/2 if abs(lo)<INF/2 and abs(hi)<INF/2 else (lo if abs(lo)<INF/2 else hi)
            return (lo-hi)*abs(av), objcoef[v]*z, z
        c = objcoef[v]
        want_hi = (sense == 'min' and c < 0) or (sense == 'max' and c > 0)
        z = hi if want_hi else lo
        if abs(z) >= INF/2:
            z = lo if abs(lo)<INF/2 else (hi if abs(hi)<INF/2 else 0.0)
        return 0.0, c*z, z

    free_cont = [v for v in cont if not cont_occ[v]]
    free_values = {}
    free_obj = 0.0
    for v in free_cont:
        c=objcoef[v]; lo,hi=lbs[v],ubs[v]
        want_hi=(sense=='min' and c<0) or (sense=='max' and c>0)
        z=hi if want_hi else lo
        if abs(z)>=INF/2: z=0.0
        free_values[v]=z; free_obj += c*z

    start = read_start(a.start)
    base_bits = [1 if start.get(v,0.0) >= 0.5 else 0 for v in binaries]
    orient = 1.0 if sense == 'min' else -1.0
    deadline = time.monotonic()+a.search_seconds
    proposals = accepted = restarts = 0
    best = None

    def initialize(bits):
        sums=[0.0]*len(row_names)
        for j,x in enumerate(bits):
            if x:
                for rr,c in inc_by_bit[j]: sums[rr]+=c
        vals=[]; viol=0.0; robj=0.0
        for rr,r in enumerate(row_names):
            e=row_eval(r,sums[rr]); vals.append(e); viol+=e[0]; robj+=e[1]
        obj=free_obj+robj+sum(objcoef[v]*bits[i] for i,v in enumerate(binaries))
        return sums,vals,viol,obj

    def save_candidate(bits,sums,vals,viol,obj):
        nonlocal best
        if viol <= 1e-8 and (best is None or orient*obj < orient*best[0]-1e-9):
            allvals={}
            for i,v in enumerate(binaries): allvals[v]=float(bits[i])
            for rr,r in enumerate(row_names):
                if row_cont[r] is not None: allvals[row_cont[r][0]]=vals[rr][2]
            allvals.update(free_values)
            best=(obj,list(bits),allvals)

    while time.monotonic() < deadline:
        bits=list(base_bits)
        if restarts:
            for j in rng.sample(range(len(bits)), min(len(bits),2+rng.randrange(24))): bits[j]^=1
        sums,vals,viol,obj=initialize(bits)
        save_candidate(bits,sums,vals,viol,obj)
        penalty=1.0e10
        temperature=max(1.0,abs(obj)*0.002)
        inner=0
        while inner < 180000 and time.monotonic() < deadline:
            inner+=1; proposals+=1
            u=rng.random()
            k=1 if u<0.18 else (2 if u<0.88 else (3 if u<0.98 else 4))
            move=rng.sample(range(len(bits)),k)
            changed={}
            for j in move:
                d=1.0 if bits[j]==0 else -1.0
                for rr,c in inc_by_bit[j]: changed[rr]=changed.get(rr,0.0)+d*c
            nv=viol; no=obj
            fresh={}
            for rr,d in changed.items():
                e=row_eval(row_names[rr],sums[rr]+d)
                fresh[rr]=e; nv += e[0]-vals[rr][0]; no += e[1]-vals[rr][1]
            for j in move:
                d=1.0 if bits[j]==0 else -1.0
                no += objcoef[binaries[j]]*d
            oldscore=penalty*viol+orient*obj
            newscore=penalty*nv+orient*no
            delta=newscore-oldscore
            accept=delta < -1e-10 or (delta < 50.0*temperature and rng.random() < math.exp(-max(0.0,delta)/max(temperature,1e-12)))
            if accept:
                accepted+=1
                for j in move: bits[j]^=1
                for rr,d in changed.items(): sums[rr]+=d; vals[rr]=fresh[rr]
                viol=max(0.0,nv); obj=no
                save_candidate(bits,sums,vals,viol,obj)
            temperature*=0.99994
            if temperature < 1e-4: temperature=max(1.0,abs(obj)*0.0002)
        restarts+=1

    if best is not None:
        objective,bits,allvals=best
        with open('best.sol','w') as f:
            f.write('# singleton-continuous elimination incumbent\n')
            f.write('# objective %.17g\n'%objective)
            for v in cols:
                f.write('%s %.17g\n'%(v,allvals.get(v,0.0)))
        status='feasible_candidate'
    else:
        objective=None; status='no_feasible_candidate'
    report.update(status=status, objective=objective, restarts=restarts, proposals=proposals,
                  accepted_moves=accepted, start_loaded=bool(start), elapsed_seconds=a.search_seconds)
    with open('singleton_elimination_report.json','w') as f: json.dump(report,f,indent=2)
    with open('method_result.json','w') as f: json.dump({'status':status,'objective':objective,'report':'singleton_elimination_report.json'},f,indent=2)

if __name__ == '__main__': main()
