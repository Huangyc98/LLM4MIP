import argparse, gzip, json, math, os, random, shlex, time

INF = 1e100

def tokens(line):
    try:
        return shlex.split(line, posix=True)
    except Exception:
        return line.split()

def read_mps(path):
    op = gzip.open if path.lower().endswith('.gz') else open
    section = None
    sense = 'MIN'
    rowtype, rows, rhs = {}, {}, {}
    objrow = None
    obj = {}
    lb, ub = {}, {}
    variables = []
    seen = set()
    integers = set()
    intmode = False
    ranges = 0
    with op(path, 'rt', encoding='utf-8', errors='replace') as f:
        for raw in f:
            line = raw.rstrip('\n\r')
            if not line or line.lstrip().startswith('*'):
                continue
            t = tokens(line)
            if not t:
                continue
            key = t[0].upper()
            if key in ('NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA','OBJSENSE','OBJNAME'):
                section = key
                if key == 'ENDATA':
                    break
                continue
            if section == 'OBJSENSE':
                if key.startswith('MAX'):
                    sense = 'MAX'
                elif key.startswith('MIN'):
                    sense = 'MIN'
            elif section == 'ROWS':
                if len(t) >= 2:
                    typ, name = t[0].upper(), t[1]
                    if typ == 'N' and objrow is None:
                        objrow = name
                    else:
                        rowtype[name] = typ
                        rows[name] = {}
            elif section == 'COLUMNS':
                upper = [x.upper().strip("'") for x in t]
                if 'MARKER' in upper:
                    if 'INTORG' in upper:
                        intmode = True
                    if 'INTEND' in upper:
                        intmode = False
                    continue
                var = t[0]
                if var not in seen:
                    seen.add(var); variables.append(var)
                if intmode:
                    integers.add(var)
                k = 1
                while k + 1 < len(t):
                    rn = t[k]
                    try:
                        a = float(t[k+1])
                    except Exception:
                        k += 2; continue
                    if rn == objrow:
                        obj[var] = obj.get(var, 0.0) + a
                    elif rn in rows:
                        rows[rn][var] = rows[rn].get(var, 0.0) + a
                    k += 2
            elif section == 'RHS':
                k = 1
                while k + 1 < len(t):
                    try:
                        rhs[t[k]] = float(t[k+1])
                    except Exception:
                        pass
                    k += 2
            elif section == 'RANGES':
                ranges += max(0, (len(t)-1)//2)
            elif section == 'BOUNDS':
                if len(t) < 3:
                    continue
                typ, var = t[0].upper(), t[2]
                val = float(t[3]) if len(t) > 3 else 0.0
                if var not in seen:
                    seen.add(var); variables.append(var)
                if typ == 'LO': lb[var] = val
                elif typ == 'UP': ub[var] = val
                elif typ == 'FX': lb[var] = val; ub[var] = val
                elif typ == 'FR': lb[var] = -INF; ub[var] = INF
                elif typ == 'MI': lb[var] = -INF
                elif typ == 'PL': ub[var] = INF
                elif typ == 'BV': lb[var] = 0.0; ub[var] = 1.0; integers.add(var)
                elif typ == 'LI': lb[var] = val; integers.add(var)
                elif typ == 'UI': ub[var] = val; integers.add(var)
    for v in variables:
        lb.setdefault(v, 0.0)
        ub.setdefault(v, INF)
        obj.setdefault(v, 0.0)
    for r in rows:
        rhs.setdefault(r, 0.0)
    return sense, variables, rowtype, rows, rhs, obj, lb, ub, integers, ranges

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--seed', type=int, default=11711)
    ap.add_argument('--seconds', type=float, default=1700.0)
    args = ap.parse_args()
    started = time.time()
    sense, variables, rtype, rows, rhs, obj, lb, ub, integers, ranges = read_mps(args.model)
    rng = random.Random(args.seed)
    occurrence = {v:0 for v in variables}
    for rr in rows.values():
        for v,a in rr.items():
            if abs(a) > 0:
                occurrence[v] = occurrence.get(v,0) + 1
    binaries = [v for v in variables if v in integers and lb[v] >= -1e-12 and ub[v] <= 1+1e-12]
    other_integer = [v for v in variables if v in integers and v not in set(binaries) and ub[v] > lb[v]+1e-12]
    continuous = [v for v in variables if v not in integers and ub[v] > lb[v]+1e-12]
    private = set(v for v in continuous if occurrence.get(v,0) == 1)
    row_private = {}
    ambiguous_rows = []
    for r,co in rows.items():
        q = [v for v in co if v in private]
        if len(q) == 1:
            row_private[r] = q[0]
        elif len(q) > 1:
            # Use one eliminable variable and leave the others fixed at a favorable bound.
            q.sort(key=lambda v:(occurrence[v], abs(obj[v])))
            row_private[r] = q[0]
            ambiguous_rows.append(r)
    chosen_private = set(row_private.values())
    public = [v for v in continuous if v not in chosen_private]
    fixed = {v:lb[v] for v in variables if ub[v] <= lb[v]+1e-12}
    base_public = {}
    for v in public:
        if lb[v] <= 0 <= ub[v]: base_public[v] = 0.0
        elif lb[v] > -INF/2: base_public[v] = lb[v]
        elif ub[v] < INF/2: base_public[v] = ub[v]
        else: base_public[v] = 0.0
    for v in other_integer:
        if lb[v] <= 0 <= ub[v]: base_public[v] = 0.0
        elif lb[v] > -INF/2: base_public[v] = math.ceil(lb[v]-1e-12)
        else: base_public[v] = math.floor(ub[v]+1e-12)

    def complete(bits, pub):
        vals = dict(fixed); vals.update(pub); vals.update(bits)
        feasible = True
        for r,co in rows.items():
            pv = row_private.get(r)
            base = 0.0
            for v,a in co.items():
                if v != pv:
                    base += a*vals.get(v, 0.0)
            typ = rtype[r]; b = rhs[r]
            if pv is None:
                if typ == 'L' and base > b+2e-7: feasible=False; break
                if typ == 'G' and base < b-2e-7: feasible=False; break
                if typ == 'E' and abs(base-b) > 2e-7: feasible=False; break
                continue
            a = co[pv]
            lo, hi = lb[pv], ub[pv]
            target = b-base
            if abs(a) < 1e-18:
                feasible=False; break
            cut = target/a
            if typ == 'E': lo=max(lo,cut); hi=min(hi,cut)
            elif (typ == 'L' and a > 0) or (typ == 'G' and a < 0): hi=min(hi,cut)
            else: lo=max(lo,cut)
            if lo > hi+2e-8:
                feasible=False; break
            c = obj[pv]
            if c > 0: x=lo
            elif c < 0: x=hi
            else: x=min(max(0.0,lo),hi)
            if x <= -INF/2 or x >= INF/2:
                feasible=False; break
            vals[pv]=x
        if not feasible:
            return None, None
        z=sum(obj[v]*vals.get(v,0.0) for v in variables)
        return z, vals

    def better(a,b):
        if a is None: return False
        if b is None: return True
        return a < b-1e-8 if sense == 'MIN' else a > b+1e-8

    def optimize_public(bits, pub, rounds=1):
        current=dict(pub)
        z, vals=complete(bits,current)
        # Exact breakpoint coordinate optimization is practical only for a few shared variables.
        movable=[v for v in public if ub[v] > lb[v]+1e-12][:3]
        for _ in range(rounds):
            for g in movable:
                cand={current[g]}
                if lb[g]>-INF/2: cand.add(lb[g])
                if ub[g]<INF/2: cand.add(ub[g])
                for r,co in rows.items():
                    ag=co.get(g,0.0)
                    if abs(ag)<1e-18: continue
                    pv=row_private.get(r)
                    base=0.0
                    for v,a in co.items():
                        if v!=g and v!=pv: base += a*(bits.get(v,current.get(v,fixed.get(v,0.0))))
                    targets=[rhs[r]]
                    if pv is not None:
                        apv=co[pv]
                        if lb[pv]>-INF/2: targets.append(rhs[r]-apv*lb[pv])
                        if ub[pv]<INF/2: targets.append(rhs[r]-apv*ub[pv])
                    for target in targets:
                        x=(target-base)/ag
                        if x>=lb[g]-1e-9 and x<=ub[g]+1e-9 and math.isfinite(x): cand.add(min(ub[g],max(lb[g],x)))
                if len(cand)>3500:
                    sc=sorted(cand); step=max(1,len(sc)//3500); cand=set(sc[::step]+[sc[-1]])
                bestz=z; bestx=current[g]; bestvals=vals
                for x in cand:
                    trial=dict(current); trial[g]=x
                    zz,vv=complete(bits,trial)
                    if better(zz,bestz): bestz,bestx,bestvals=zz,x,vv
                current[g]=bestx; z,vals=bestz,bestvals
        return z,vals,current

    bestz=None; bestvals=None; bestbits=None; bestpub=None
    starts=max(4,min(12, 2+len(binaries)//80))
    for st in range(starts):
        if time.time()-started > args.seconds: break
        if st==0: bits={v:0.0 for v in binaries}
        elif st==1: bits={v:1.0 for v in binaries}
        else: bits={v:float(rng.randrange(2)) for v in binaries}
        pub=dict(base_public)
        z,vals,pub=optimize_public(bits,pub,1)
        order=list(binaries)
        for sweep in range(8):
            if time.time()-started > args.seconds: break
            rng.shuffle(order); changed=0
            for v in order:
                if time.time()-started > args.seconds: break
                bits[v]=1.0-bits[v]
                zz,vv=complete(bits,pub)
                if better(zz,z): z,vals=zz,vv; changed+=1
                else: bits[v]=1.0-bits[v]
            z,vals,pub=optimize_public(bits,pub,1)
            if changed==0: break
        if better(z,bestz):
            bestz,bestvals,bestbits,bestpub=z,vals,dict(bits),dict(pub)
    status='candidate_found' if bestvals is not None else 'no_feasible_completion'
    if bestvals is not None:
        with open('best.sol','w',encoding='utf-8') as f:
            f.write('# Objective value = %.17g\n'%bestz)
            for v in variables:
                x=bestvals.get(v,0.0)
                if abs(x)>1e-15: f.write('%s %.17g\n'%(v,x))
    report={
      'status':status,'objective':bestz,'objective_sense':sense,'variables':len(variables),
      'rows':len(rows),'integer_variables':len(integers),'binary_search_variables':len(binaries),
      'other_integer_variables':len(other_integer),'continuous_variables':len(continuous),
      'row_private_continuous_variables':len(chosen_private),'shared_continuous_variables':len(public),
      'rows_with_private_completion':len(row_private),'ambiguous_private_rows':len(ambiguous_rows),
      'range_entries':ranges,'elapsed_seconds':time.time()-started,'seed':args.seed
    }
    with open('mixed_incidence_report.json','w',encoding='utf-8') as f: json.dump(report,f,indent=2,sort_keys=True)
    result={'status':status,'objective':bestz,'solution_file':'best.sol' if bestvals is not None else None,'report_file':'mixed_incidence_report.json'}
    with open('method_result.json','w',encoding='utf-8') as f: json.dump(result,f,indent=2,sort_keys=True)

if __name__=='__main__': main()
