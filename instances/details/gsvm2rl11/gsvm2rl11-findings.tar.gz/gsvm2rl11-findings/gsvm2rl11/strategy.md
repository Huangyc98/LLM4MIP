# Formal-solving strategy

1. Measure the exact incidence and repeated-template structure with a custom MPS analyzer.
2. If rows form small integer-centered blocks coupled by a common continuous core, implement local integer-state enumeration with a coordinated continuous repair step.
3. If repeated templates dominate, aggregate equivalent blocks before search. If coupling is dense without useful blocks, switch to a structure-derived relaxation or Lagrangian method rather than generic parameter tuning.
4. Emit candidate solutions with conservative feasibility margins and rely on the controller's exact checker.
5. Use a commercial solver later only to improve a custom warm start, solve a derived subproblem, or close the primal-dual gap as a proof engine.
6. Declare optimality only after strict solver status or independently checked matching primal and dual bounds.
