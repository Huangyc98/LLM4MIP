# Package manifest: bley_xs1

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 12
Excluded source files: 1

## Included files

- `README.md`
- `logs/bley_xs1-copt-baseline.log`
- `logs/bley_xs1-gurobi-baseline.log`
- `logs/bley_xs1-known3855896-gurobi.log`
- `logs/bley_xs1-path-lns.log`
- `scripts/bley_path_lns.py`
- `scripts/solve_with_miplib_start.py`
- `solutions/bley_xs1-known3855896.sol`
- `solutions/bley_xs1-known3855896.sol.gz`
- `solutions/bley_xs1-lns-candidate.sol`
- `solutions/bley_xs1-lns-rounded.sol`
- `solutions/bley_xs1-verified3855896.sol`

## Excluded files

- `input/bley_xs1.mps.gz (142054 bytes; raw benchmark input; sha256 02a0eba05ad39eaade8b266555fe2eb981954452990fbe0ac42bc727378256e8)`
