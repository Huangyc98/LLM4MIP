#!/usr/bin/env python3
"""Run a rank-modulo shard of anchored exact four-district COPT models."""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from decimal import Decimal
from pathlib import Path


THIS = Path(__file__).resolve()
sys.path.insert(0, str(THIS.parent))
from exact_district_quad_copt import (  # noqa: E402
    DISTRICTS,
    NODES,
    extract_graph,
    objective,
    rank_quads,
    sha256,
)


def summary(path: Path, reused: bool) -> dict[str, object]:
    report = json.loads(path.read_text(encoding="utf-8"))
    best = report.get("best_connected")
    return {
        "quad_zero_based": report["selected_quad_zero_based"],
        "reused_existing_result": reused,
        "result": path.as_posix(),
        "result_sha256": sha256(path),
        "termination": report.get("termination"),
        "anchored_connected_quad_optimality_proved": bool(
            report.get("anchored_connected_quad_optimality_proved")
        ),
        "connectivity_cuts_added": report.get("connectivity_cuts_added"),
        "rounds": len(report.get("rounds", [])),
        "wall_seconds": report.get("wall_seconds"),
        "old_internal_cut_weight": report.get("old_internal_cut_weight"),
        "best_connected_full_objective": best.get("full_objective") if best else None,
        "best_connected_objective_delta": best.get("objective_delta") if best else None,
    }


def write(path: Path, manifest: dict[str, object]) -> None:
    records = manifest["records"]
    manifest["quads_completed"] = len(records)
    manifest["quads_proved_optimal"] = sum(
        bool(item["anchored_connected_quad_optimality_proved"])
        for item in records
    )
    manifest["quads_without_proof"] = sum(
        not bool(item["anchored_connected_quad_optimality_proved"])
        for item in records
    )
    manifest["improving_quads"] = sum(
        item["best_connected_objective_delta"] is not None
        and Decimal(item["best_connected_objective_delta"]) < 0
        for item in records
    )
    path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8", newline="\n")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("graph_mps", type=Path)
    parser.add_argument("assignment", type=Path)
    parser.add_argument("outdir", type=Path)
    parser.add_argument("--top", type=int, default=67)
    parser.add_argument("--time-limit-per-quad", type=float, default=120.0)
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--max-rounds", type=int, default=1000)
    parser.add_argument("--existing-result", action="append", type=Path, default=[])
    parser.add_argument("--shard-count", type=int, default=1)
    parser.add_argument("--shard-index", type=int, default=0)
    args = parser.parse_args()

    populations, edges = extract_graph(args.graph_mps)
    source = json.loads(args.assignment.read_text(encoding="utf-8"))
    assignment = list(source["assignment_zero_based_district"])
    if len(assignment) != NODES or set(assignment) != set(range(DISTRICTS)):
        raise ValueError("invalid assignment")
    initial = objective(assignment, edges)
    full_ranking = rank_quads(assignment, edges)[:args.top]
    if args.shard_count < 1 or not 0 <= args.shard_index < args.shard_count:
        raise ValueError("invalid shard index/count")
    ranking = [
        dict(row, global_rank=index + 1)
        for index, row in enumerate(full_ranking)
        if index % args.shard_count == args.shard_index
    ]
    args.outdir.mkdir(parents=True, exist_ok=True)
    manifest_path = args.outdir / "manifest.json"
    manifest: dict[str, object] = {
        "schema": "nj-anchored-district-quad-copt-shard-v1",
        "evidence_level": (
            "anchored four-district local models with exact integer-scaled cut "
            "and population arithmetic plus iterative connectivity cuts"
        ),
        "graph_mps": args.graph_mps.as_posix(),
        "graph_mps_sha256": sha256(args.graph_mps),
        "assignment": args.assignment.as_posix(),
        "assignment_sha256": sha256(args.assignment),
        "initial_full_objective": str(initial),
        "quads_total_requested": len(full_ranking),
        "quads_in_shard": len(ranking),
        "shard_count": args.shard_count,
        "shard_index": args.shard_index,
        "ranking": ranking,
        "time_limit_per_quad": args.time_limit_per_quad,
        "threads": args.threads,
        "records": [],
        "stopped_early_for_improvement": False,
        "started_unix_time": time.time(),
    }
    done = set()
    for path in args.existing_result:
        record = summary(path, True)
        key = tuple(record["quad_zero_based"])
        done.add(key)
        manifest["records"].append(record)
    write(manifest_path, manifest)

    for row in ranking:
        labels = row["quad"]
        key = tuple(labels)
        if key in done:
            continue
        stem = "quad-" + "-".join(map(str, labels))
        result_path = args.outdir / f"{stem}.result.json"
        solver_log = args.outdir / f"{stem}.solver.log"
        launcher_log = args.outdir / f"{stem}.launcher.log"
        command = [
            sys.executable,
            str(THIS.parent / "exact_district_quad_copt.py"),
            str(args.graph_mps), str(args.assignment), str(result_path),
            "--quad", *map(str, labels),
            "--time-limit", str(args.time_limit_per_quad),
            "--threads", str(args.threads),
            "--max-rounds", str(args.max_rounds),
            "--log", str(solver_log),
        ]
        with launcher_log.open("w", encoding="utf-8", newline="\n") as stream:
            process = subprocess.run(
                command, stdout=stream, stderr=subprocess.STDOUT,
                env=os.environ.copy(), check=False,
            )
        if process.returncode != 0 or not result_path.is_file():
            record = {
                "quad_zero_based": labels,
                "reused_existing_result": False,
                "result": result_path.as_posix(),
                "result_sha256": None,
                "solver_log": solver_log.as_posix() if solver_log.is_file() else None,
                "solver_log_sha256": sha256(solver_log) if solver_log.is_file() else None,
                "launcher_log": launcher_log.as_posix(),
                "launcher_log_sha256": sha256(launcher_log),
                "returncode": process.returncode,
                "termination": "child_error",
                "anchored_connected_quad_optimality_proved": False,
                "best_connected_objective_delta": None,
            }
        else:
            record = summary(result_path, False)
            record.update({
                "solver_log": solver_log.as_posix(),
                "solver_log_sha256": sha256(solver_log),
                "launcher_log": launcher_log.as_posix(),
                "launcher_log_sha256": sha256(launcher_log),
                "returncode": process.returncode,
            })
        manifest["records"].append(record)
        write(manifest_path, manifest)
        delta = record["best_connected_objective_delta"]
        print(
            f"quad={','.join(map(str, labels))} termination={record['termination']} "
            f"proved={record['anchored_connected_quad_optimality_proved']} delta={delta}",
            flush=True,
        )
        if delta is not None and Decimal(delta) < 0:
            manifest["stopped_early_for_improvement"] = True
            manifest["improving_result"] = result_path.as_posix()
            write(manifest_path, manifest)
            break

    manifest["finished_unix_time"] = time.time()
    write(manifest_path, manifest)
    print("MANIFEST=" + str(manifest_path), flush=True)


if __name__ == "__main__":
    main()
