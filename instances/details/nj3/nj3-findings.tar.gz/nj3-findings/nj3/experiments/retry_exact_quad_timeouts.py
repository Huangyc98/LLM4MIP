#!/usr/bin/env python3
"""Retry unproved exact-quad shard records with a longer COPT time limit."""

from __future__ import annotations

import argparse
import concurrent.futures
import json
import os
import subprocess
import sys
import time
from decimal import Decimal
from pathlib import Path


THIS = Path(__file__).resolve()
sys.path.insert(0, str(THIS.parent))
from exact_district_quad_copt import sha256  # noqa: E402


def write(path: Path, manifest: dict[str, object]) -> None:
    records = manifest["records"]
    manifest["retries_completed"] = len(records)
    manifest["retries_proved_optimal"] = sum(
        bool(row["anchored_connected_quad_optimality_proved"]) for row in records
    )
    manifest["retries_without_proof"] = sum(
        not bool(row["anchored_connected_quad_optimality_proved"]) for row in records
    )
    manifest["improving_quads"] = sum(
        row.get("best_connected_objective_delta") is not None
        and Decimal(row["best_connected_objective_delta"]) < 0
        for row in records
    )
    path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8", newline="\n")


def run_one(
    args: argparse.Namespace, item: dict[str, object]
) -> dict[str, object]:
    labels = [int(value) for value in item["quad_zero_based"]]
    stem = "quad-" + "-".join(map(str, labels))
    result_path = args.outdir / f"{stem}.result.json"
    solver_log = args.outdir / f"{stem}.solver.log"
    launcher_log = args.outdir / f"{stem}.launcher.log"
    command = [
        sys.executable,
        str(THIS.parent / "exact_district_quad_copt.py"),
        str(args.graph_mps),
        str(args.assignment),
        str(result_path),
        "--quad",
        *map(str, labels),
        "--time-limit",
        str(args.time_limit),
        "--threads",
        str(args.threads),
        "--max-rounds",
        str(args.max_rounds),
        "--log",
        str(solver_log),
    ]
    with launcher_log.open("w", encoding="utf-8", newline="\n") as stream:
        process = subprocess.run(
            command,
            stdout=stream,
            stderr=subprocess.STDOUT,
            env=os.environ.copy(),
            check=False,
        )
    record: dict[str, object] = {
        "quad_zero_based": labels,
        "global_rank": item.get("global_rank"),
        "initial_result": item.get("result"),
        "initial_result_sha256": item.get("result_sha256"),
        "result": result_path.as_posix(),
        "result_sha256": sha256(result_path) if result_path.is_file() else None,
        "solver_log": solver_log.as_posix() if solver_log.is_file() else None,
        "solver_log_sha256": sha256(solver_log) if solver_log.is_file() else None,
        "launcher_log": launcher_log.as_posix(),
        "launcher_log_sha256": sha256(launcher_log),
        "returncode": process.returncode,
    }
    if process.returncode != 0 or not result_path.is_file():
        record.update(
            {
                "termination": "child_error",
                "anchored_connected_quad_optimality_proved": False,
                "best_connected_objective_delta": None,
            }
        )
        return record
    report = json.loads(result_path.read_text(encoding="utf-8"))
    best = report.get("best_connected")
    record.update(
        {
            "termination": report.get("termination"),
            "anchored_connected_quad_optimality_proved": bool(
                report.get("anchored_connected_quad_optimality_proved")
            ),
            "connectivity_cuts_added": report.get("connectivity_cuts_added"),
            "rounds": len(report.get("rounds", [])),
            "wall_seconds": report.get("wall_seconds"),
            "last_solver_status": (
                report["rounds"][-1].get("status") if report.get("rounds") else None
            ),
            "best_connected_full_objective": (
                best.get("full_objective") if best else None
            ),
            "best_connected_objective_delta": (
                best.get("objective_delta") if best else None
            ),
        }
    )
    return record


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("graph_mps", type=Path)
    parser.add_argument("assignment", type=Path)
    parser.add_argument("outdir", type=Path)
    parser.add_argument("--manifest", action="append", type=Path, required=True)
    parser.add_argument("--time-limit", type=float, default=600.0)
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--max-rounds", type=int, default=1000)
    args = parser.parse_args()

    args.outdir.mkdir(parents=True, exist_ok=True)
    todo_by_quad: dict[tuple[int, ...], dict[str, object]] = {}
    for manifest_path in args.manifest:
        source = json.loads(manifest_path.read_text(encoding="utf-8"))
        ranks = {
            tuple(row["quad"]): row.get("global_rank") for row in source["ranking"]
        }
        for source_record in source["records"]:
            if source_record.get("anchored_connected_quad_optimality_proved"):
                continue
            key = tuple(source_record["quad_zero_based"])
            item = dict(source_record)
            item["global_rank"] = ranks[key]
            todo_by_quad[key] = item

    manifest_path = args.outdir / "manifest.json"
    manifest: dict[str, object] = {
        "schema": "nj-anchored-district-quad-copt-retry-v1",
        "graph_mps": args.graph_mps.as_posix(),
        "graph_mps_sha256": sha256(args.graph_mps),
        "assignment": args.assignment.as_posix(),
        "assignment_sha256": sha256(args.assignment),
        "source_manifests": [path.as_posix() for path in args.manifest],
        "retries_requested": len(todo_by_quad),
        "time_limit_per_quad": args.time_limit,
        "threads_per_quad": args.threads,
        "parallel_workers": args.workers,
        "started_unix_time": time.time(),
        "records": [],
    }
    write(manifest_path, manifest)
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = {
            pool.submit(run_one, args, item): key
            for key, item in todo_by_quad.items()
        }
        for future in concurrent.futures.as_completed(futures):
            record = future.result()
            manifest["records"].append(record)
            manifest["records"].sort(key=lambda row: int(row["global_rank"]))
            write(manifest_path, manifest)
            print(
                "quad="
                + ",".join(map(str, record["quad_zero_based"]))
                + f" termination={record['termination']}"
                + f" proved={record['anchored_connected_quad_optimality_proved']}"
                + f" delta={record['best_connected_objective_delta']}",
                flush=True,
            )
    manifest["finished_unix_time"] = time.time()
    write(manifest_path, manifest)
    print("MANIFEST=" + str(manifest_path), flush=True)


if __name__ == "__main__":
    main()
