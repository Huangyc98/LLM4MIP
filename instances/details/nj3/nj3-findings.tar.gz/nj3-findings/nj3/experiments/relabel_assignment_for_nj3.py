#!/usr/bin/env python3
"""Relabel an audited nj2 assignment so zero-based node 0 has label 0.

The only transformation is a permutation of two district labels.  It leaves
the unlabeled partition, district shapes, cut edges, and boundary objective
unchanged.  Full nj3 feasibility is established separately by lifting this
assignment and checking the original MPS exactly.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


NODES = 595
DISTRICTS = 12


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def relabel_vector(values: list[int], old_to_new: list[int]) -> list[int]:
    if len(values) != DISTRICTS:
        raise ValueError("district-indexed vector must have length 12")
    result = [0] * DISTRICTS
    for old_label, value in enumerate(values):
        result[old_to_new[old_label]] = value
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source_assignment", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    source = json.loads(args.source_assignment.read_text(encoding="utf-8"))
    assignment = list(source["assignment_zero_based_district"])
    if len(assignment) != NODES or set(assignment) - set(range(DISTRICTS)):
        raise ValueError("source assignment must contain 595 labels in 0..11")
    if set(assignment) != set(range(DISTRICTS)):
        raise ValueError("all 12 district labels must be present")

    node_zero_old_label = assignment[0]
    old_to_new = list(range(DISTRICTS))
    old_to_new[0], old_to_new[node_zero_old_label] = node_zero_old_label, 0
    relabelled = [old_to_new[label] for label in assignment]
    if relabelled[0] != 0:
        raise RuntimeError("relabeling failed to anchor node 0 in district 0")

    result = {
        "evidence_level": (
            "deterministic district-label permutation; requires separate exact lift/check "
            "against the full original nj3 MPS"
        ),
        "source_assignment_sha256": sha256(args.source_assignment),
        "operation": "swap label 0 with the original label of zero-based node 0",
        "old_to_new_district_label": old_to_new,
        "node_zero_old_label": node_zero_old_label,
        "node_zero_new_label": relabelled[0],
        "boundary_objective_original_units": source["boundary_objective_original_units"],
        "objective_change": "0",
        "assignment_zero_based_district": relabelled,
        "district_populations": relabel_vector(source["district_populations"], old_to_new),
        "district_component_sizes": relabel_vector(source["district_component_sizes"], old_to_new),
        "cut_edges": source["cut_edges"],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({
        "source_assignment_sha256": result["source_assignment_sha256"],
        "old_to_new_district_label": old_to_new,
        "node_zero": [node_zero_old_label, relabelled[0]],
        "objective": result["boundary_objective_original_units"],
    }, indent=2))


if __name__ == "__main__":
    main()
