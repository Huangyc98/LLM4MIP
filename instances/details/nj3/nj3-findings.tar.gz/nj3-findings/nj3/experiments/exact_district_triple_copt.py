#!/usr/bin/env python3
"""COPT prototype for an anchored connected three-district repartition."""

from __future__ import annotations

import argparse
import json
import math
import os
import platform
import sys
import time
from decimal import Decimal
from itertools import combinations
from pathlib import Path


THIS = Path(__file__).resolve()
NJ1_EXPERIMENTS = Path(
    os.environ.get("NJ_HELPER_DIR", THIS.parents[2] / "nj1" / "experiments")
)
sys.path.insert(0, str(NJ1_EXPERIMENTS))
sys.path.insert(0, str(THIS.parent))
from connected_boundary_steepest_descent import (  # noqa: E402
    DISTRICTS,
    LOWER_POPULATION,
    NODES,
    UPPER_POPULATION,
    extract_graph,
    objective,
)
from exact_district_pair_copt import components, safe_attr, sha256  # noqa: E402


def rank_triples(assignment, edges):
    pair_weight: dict[tuple[int, int], Decimal] = {}
    for left, right, cost in edges:
        first, second = assignment[left], assignment[right]
        if first == second:
            continue
        pair = tuple(sorted((first, second)))
        pair_weight[pair] = pair_weight.get(pair, Decimal(0)) + cost
    rows = []
    for triple in combinations(range(DISTRICTS), 3):
        adjacency = {district: set() for district in triple}
        for first, second in combinations(triple, 2):
            if (first, second) in pair_weight:
                adjacency[first].add(second)
                adjacency[second].add(first)
        seen = {triple[0]}
        queue = [triple[0]]
        for district in queue:
            for neighbor in adjacency[district]:
                if neighbor not in seen:
                    seen.add(neighbor)
                    queue.append(neighbor)
        if len(seen) != 3:
            continue
        internal = sum(
            (pair_weight.get((first, second), Decimal(0))
             for first, second in combinations(triple, 2)),
            Decimal(0),
        )
        rows.append({
            "triple": list(triple),
            "current_internal_cut_weight": str(internal),
            "current_full_objective_contribution": str(2 * internal),
            "pair_weights": {
                f"{first}-{second}": str(pair_weight.get((first, second), Decimal(0)))
                for first, second in combinations(triple, 2)
            },
        })
    return sorted(
        rows,
        key=lambda row: (-Decimal(row["current_internal_cut_weight"]), row["triple"]),
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("graph_mps", type=Path)
    parser.add_argument("assignment", type=Path)
    parser.add_argument("output", type=Path, nargs="?")
    parser.add_argument("--triple", nargs=3, type=int, metavar=("A", "B", "C"))
    parser.add_argument("--list-triples", action="store_true")
    parser.add_argument("--time-limit", type=float, default=300.0)
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--max-rounds", type=int, default=1000)
    parser.add_argument("--log", type=Path)
    args = parser.parse_args()

    populations, edges = extract_graph(args.graph_mps)
    source = json.loads(args.assignment.read_text(encoding="utf-8"))
    assignment = list(source["assignment_zero_based_district"])
    if len(assignment) != NODES or set(assignment) != set(range(DISTRICTS)):
        raise ValueError("invalid assignment")
    initial_objective = objective(assignment, edges)
    recorded = source.get("boundary_objective_original_units")
    if recorded is not None and Decimal(recorded) != initial_objective:
        raise ValueError(f"recorded objective {recorded} != exact {initial_objective}")
    ranking = rank_triples(assignment, edges)
    if args.list_triples:
        print(json.dumps(ranking, indent=2))
        return
    if args.output is None:
        parser.error("OUTPUT is required unless --list-triples is used")
    labels = sorted(args.triple) if args.triple else ranking[0]["triple"]
    if tuple(labels) not in {tuple(row["triple"]) for row in ranking}:
        raise ValueError(f"triple {labels} is not connected in the district graph")

    try:
        import coptpy as cp
    except ImportError as error:
        raise SystemExit("coptpy is required for optimization") from error

    nodes = [node for node, label in enumerate(assignment) if label in labels]
    node_set = set(nodes)
    induced = [
        (left, right, cost) for left, right, cost in edges
        if left in node_set and right in node_set
    ]
    adjacency = {node: [] for node in nodes}
    for left, right, _ in induced:
        adjacency[left].append(right)
        adjacency[right].append(left)
    for neighbors in adjacency.values():
        neighbors.sort()
    anchors = {label: min(node for node in nodes if assignment[node] == label)
               for label in labels}
    old_internal_cut = sum(
        (cost for left, right, cost in induced
         if assignment[left] != assignment[right]),
        Decimal(0),
    )

    digits = max((max(0, -cost.as_tuple().exponent) for _, _, cost in induced), default=0)
    scale = 10 ** digits
    integer_costs = [int(cost * scale) for _, _, cost in induced]
    if any(Decimal(value) != cost * scale
           for value, (_, _, cost) in zip(integer_costs, induced)):
        raise RuntimeError("edge scaling is not exact")
    divisor = 0
    for value in integer_costs:
        divisor = math.gcd(divisor, value)
    divisor = max(divisor, 1)
    integer_costs = [value // divisor for value in integer_costs]

    environment = cp.Envr()
    model = environment.createModel("nj-triple-" + "-".join(map(str, labels)))
    x = {
        (node, label): model.addVar(vtype=cp.COPT.BINARY, name=f"x_{node}_{label}")
        for node in nodes for label in labels
    }
    cut = {
        index: model.addVar(vtype=cp.COPT.BINARY, name=f"cut_{left}_{right}")
        for index, (left, right, _) in enumerate(induced)
    }
    for node in nodes:
        model.addConstr(
            cp.quicksum(x[node, label] for label in labels) == 1,
            name=f"assign_{node}",
        )
    for label in labels:
        model.addConstr(x[anchors[label], label] == 1, name=f"anchor_{label}")
        population = cp.quicksum(populations[node] * x[node, label] for node in nodes)
        model.addConstr(population >= LOWER_POPULATION, name=f"pop_lb_{label}")
        model.addConstr(population <= UPPER_POPULATION, name=f"pop_ub_{label}")
    for index, (left, right, _) in enumerate(induced):
        for label in labels:
            model.addConstr(cut[index] >= x[left, label] - x[right, label])
            model.addConstr(cut[index] >= x[right, label] - x[left, label])
    model.setObjective(
        cp.quicksum(integer_costs[index] * cut[index] for index in range(len(induced))),
        cp.COPT.MINIMIZE,
    )

    variables = [x[node, label] for node in nodes for label in labels] + list(cut.values())
    values = (
        [int(assignment[node] == label) for node in nodes for label in labels]
        + [int(assignment[left] != assignment[right]) for left, right, _ in induced]
    )
    model.setMipStart(variables, values)
    load_return = model.loadMipStart()
    if args.log:
        args.log.parent.mkdir(parents=True, exist_ok=True)
        model.setLogFile(str(args.log))
    model.setParam(cp.COPT.Param.Threads, args.threads)
    model.setParam(cp.COPT.Param.RelGap, 0.0)
    model.setParam(cp.COPT.Param.GPUMode, 0)

    started = time.monotonic()
    rounds = []
    total_cuts = 0
    best_connected = None
    proof = False
    termination = None
    for round_number in range(1, args.max_rounds + 1):
        remaining = args.time_limit - (time.monotonic() - started)
        if remaining <= 0:
            termination = "total_time_limit"
            break
        model.setParam(cp.COPT.Param.TimeLimit, max(0.01, remaining))
        model.solve()
        status = safe_attr(model, "status", "Status")
        has_solution = bool(safe_attr(model, "hasmipsol", "HasMipSol"))
        record = {
            "round": round_number,
            "status": str(status),
            "has_mip_solution": has_solution,
            "numerical_objective_scaled": str(safe_attr(model, "objval", "ObjVal")),
            "numerical_best_bound_scaled": str(safe_attr(model, "bestbnd", "BestBnd")),
        }
        if not has_solution:
            rounds.append(record)
            termination = "no_mip_solution"
            break
        candidate = {
            node: max(labels, key=lambda label: x[node, label].x) for node in nodes
        }
        exact_cut = sum(
            (cost for left, right, cost in induced
             if candidate[left] != candidate[right]),
            Decimal(0),
        )
        component_map = {
            label: components(
                {node for node in nodes if candidate[node] == label}, adjacency
            )
            for label in labels
        }
        record.update({
            "exact_internal_cut_weight": str(exact_cut),
            "populations": {
                str(label): sum(populations[node] for node in nodes
                                if candidate[node] == label)
                for label in labels
            },
            "component_sizes": {
                str(label): [len(item) for item in component_map[label]]
                for label in labels
            },
        })
        if all(len(component_map[label]) == 1 for label in labels):
            trial = assignment.copy()
            for node in nodes:
                trial[node] = candidate[node]
            full_value = objective(trial, edges)
            expected = initial_objective + 2 * (exact_cut - old_internal_cut)
            if full_value != expected:
                raise RuntimeError("triple-local and full exact objectives disagree")
            best_connected = {
                "internal_cut_weight": str(exact_cut),
                "full_objective": str(full_value),
                "objective_delta": str(full_value - initial_objective),
                "assignment_zero_based_district": trial,
            }
            proof = status == cp.COPT.OPTIMAL
            record["connected"] = True
            rounds.append(record)
            termination = "connected_relaxation_optimum" if proof else "connected_incumbent"
            break

        record["connected"] = False
        added = 0
        for label in labels:
            root_component = next(
                item for item in component_map[label] if anchors[label] in item
            )
            for item in component_map[label]:
                if item is root_component:
                    continue
                boundary = sorted({
                    neighbor for node in item for neighbor in adjacency[node]
                    if neighbor not in item
                })
                representative = min(item)
                model.addConstr(
                    cp.quicksum(x[node, label] for node in boundary)
                    >= x[representative, label],
                    name=f"conn_{label}_{round_number}_{representative}",
                )
                added += 1
        if added == 0:
            raise RuntimeError("disconnected solution generated no cuts")
        record["connectivity_cuts_added"] = added
        rounds.append(record)
        total_cuts += added
    else:
        termination = "max_rounds"

    report = {
        "schema": "nj-anchored-district-triple-copt-v1",
        "evidence_level": (
            "exact integer-scaled internal cut and population arithmetic with "
            "fixed current anchors and iterative connectivity cuts; local only"
        ),
        "host": platform.node(),
        "solver": "COPT",
        "graph_mps": args.graph_mps.as_posix(),
        "graph_mps_sha256": sha256(args.graph_mps),
        "assignment": args.assignment.as_posix(),
        "assignment_sha256": sha256(args.assignment),
        "initial_full_objective": str(initial_objective),
        "selected_triple_zero_based": labels,
        "selection_rule": "maximum current internal boundary weight among connected triples",
        "ranking_first": ranking[0],
        "nodes": len(nodes),
        "induced_edges": len(induced),
        "anchors_zero_based": {str(label): anchors[label] for label in labels},
        "old_internal_cut_weight": str(old_internal_cut),
        "decimal_digits": digits,
        "integer_objective_divisor": divisor,
        "effective_integer_scale": str(Decimal(scale) / Decimal(divisor)),
        "load_mip_start_return": repr(load_return),
        "time_limit": args.time_limit,
        "threads": args.threads,
        "rounds": rounds,
        "connectivity_cuts_added": total_cuts,
        "termination": termination,
        "anchored_connected_triple_optimality_proved": proof,
        "best_connected": best_connected,
        "wall_seconds": time.monotonic() - started,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8", newline="\n")
    print("RESULT=" + str(args.output), flush=True)


if __name__ == "__main__":
    main()
