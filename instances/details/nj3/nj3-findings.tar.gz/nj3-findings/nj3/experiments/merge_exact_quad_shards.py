#!/usr/bin/env python3
"""Validate and merge rank-modulo exact-quad batch shards into one manifest."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def local_artifact(
    archive: Path, shard: Path, record: dict[str, object], kind: str
) -> Path | None:
    if record.get("reused_existing_result"):
        names = {"result": "result.json", "solver_log": "solver.log", "launcher_log": "launcher.log"}
        return archive / names[kind]
    remote = record.get(kind)
    if remote is None:
        return None
    return shard / Path(str(remote)).name


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    parser.add_argument("--shard", action="append", type=Path, required=True)
    parser.add_argument("--retry-manifest", action="append", type=Path, default=[])
    parser.add_argument("--replacement-result", action="append", type=Path, default=[])
    parser.add_argument("--replacement-remote-directory", action="append", default=[])
    parser.add_argument("--legacy-prototype-script-sha256")
    parser.add_argument("--solver-script", type=Path, required=True)
    parser.add_argument("--batch-script", type=Path, required=True)
    parser.add_argument("--retry-script", type=Path, required=True)
    parser.add_argument("--merge-script", type=Path, required=True)
    args = parser.parse_args()

    archive = args.archive.resolve()
    shard_dirs = [path.resolve() for path in args.shard]
    ranking_by_quad: dict[tuple[int, ...], dict[str, object]] = {}
    record_by_quad: dict[tuple[int, ...], dict[str, object]] = {}
    shard_summaries: list[dict[str, object]] = []
    retry_summaries: list[dict[str, object]] = []
    replacement_summaries: list[dict[str, object]] = []
    common: dict[str, object] | None = None

    for shard_index, shard in enumerate(shard_dirs):
        manifest_path = shard / "manifest.json"
        source = json.loads(manifest_path.read_text(encoding="utf-8"))
        if int(source["shard_index"]) != shard_index:
            raise ValueError(f"unexpected shard index in {manifest_path}")
        fields = {
            name: source[name]
            for name in (
                "graph_mps_sha256",
                "assignment_sha256",
                "initial_full_objective",
                "quads_total_requested",
                "shard_count",
                "time_limit_per_quad",
                "threads",
            )
        }
        if common is None:
            common = fields
        elif common != fields:
            raise ValueError(f"inconsistent shard configuration: {manifest_path}")

        for row in source["ranking"]:
            key = tuple(int(label) for label in row["quad"])
            if key in ranking_by_quad:
                raise ValueError(f"duplicate ranked quad {key}")
            ranking_by_quad[key] = dict(row)

        for record in source["records"]:
            key = tuple(int(label) for label in record["quad_zero_based"])
            if key in record_by_quad:
                raise ValueError(f"duplicate completed quad {key}")
            if key not in ranking_by_quad:
                raise ValueError(f"completed quad absent from shard ranking: {key}")

            merged = dict(record)
            merged["source_shard"] = shard_index
            merged["global_rank"] = int(ranking_by_quad[key]["global_rank"])
            for kind in ("result", "solver_log", "launcher_log"):
                path = local_artifact(archive, shard, record, kind)
                if path is None:
                    continue
                if not path.is_file():
                    raise FileNotFoundError(path)
                field = f"{kind}_sha256"
                actual = sha256(path)
                recorded = record.get(field)
                if recorded is not None and actual != recorded:
                    raise ValueError(f"hash mismatch for {path}: {actual} != {recorded}")
                remote = record.get(kind)
                if remote is None and record.get("reused_existing_result"):
                    result_parent = Path(str(record["result"])).parent
                    remote = (result_parent / path.name).as_posix()
                merged[f"remote_{kind}"] = remote
                merged[kind] = path.relative_to(archive).as_posix()
                merged[field] = actual

            report_path = archive / str(merged["result"])
            report = json.loads(report_path.read_text(encoding="utf-8"))
            if tuple(report["selected_quad_zero_based"]) != key:
                raise ValueError(f"result label mismatch in {report_path}")
            expected_rule = (
                "maximum current internal boundary weight among connected quads"
                if record.get("reused_existing_result")
                else "explicit connected quad supplied with --quad"
            )
            if report.get("selection_rule") != expected_rule:
                raise ValueError(
                    f"selection_rule mismatch in {report_path}: "
                    f"{report.get('selection_rule')!r}"
                )
            merged["selection_rule"] = report["selection_rule"]
            merged["result_ranking_position"] = report.get("ranking_position", 1)
            merged["last_solver_status"] = (
                report["rounds"][-1].get("status") if report.get("rounds") else None
            )
            merged["time_limit_exhausted"] = merged["last_solver_status"] == "8"
            merged["old_internal_cut_weight"] = report.get("old_internal_cut_weight")
            record_by_quad[key] = merged

        shard_summaries.append(
            {
                "shard_index": shard_index,
                "directory": shard.relative_to(archive).as_posix(),
                "manifest": manifest_path.relative_to(archive).as_posix(),
                "manifest_sha256": sha256(manifest_path),
                "quads_in_shard": source["quads_in_shard"],
                "quads_completed": source["quads_completed"],
                "quads_proved_optimal": source["quads_proved_optimal"],
                "quads_without_proof": source["quads_without_proof"],
                "improving_quads": source["improving_quads"],
                "stopped_early_for_improvement": source["stopped_early_for_improvement"],
                "started_unix_time": source["started_unix_time"],
                "finished_unix_time": source.get("finished_unix_time"),
                "elapsed_seconds": (
                    float(source.get("finished_unix_time", source["started_unix_time"]))
                    - float(source["started_unix_time"])
                ),
            }
        )

    initial_records = [dict(record) for record in record_by_quad.values()]
    if len(args.replacement_result) != len(args.replacement_remote_directory):
        raise ValueError("each replacement result needs one remote directory")
    if args.legacy_prototype_script_sha256 is not None and (
        len(args.legacy_prototype_script_sha256) != 64
        or any(character not in "0123456789abcdef" for character in args.legacy_prototype_script_sha256)
    ):
        raise ValueError("invalid legacy prototype script SHA-256")
    for replacement_number, (path_arg, remote_dir) in enumerate(
        zip(args.replacement_result, args.replacement_remote_directory), start=1
    ):
        result_path = path_arg.resolve()
        report = json.loads(result_path.read_text(encoding="utf-8"))
        key = tuple(int(label) for label in report["selected_quad_zero_based"])
        if key not in record_by_quad:
            raise ValueError(f"replacement refers to unknown quad {key}")
        initial = record_by_quad[key]
        if args.legacy_prototype_script_sha256 and initial.get("reused_existing_result"):
            initial = dict(initial)
            initial["solver_script_sha256"] = args.legacy_prototype_script_sha256
            initial["solver_script_note"] = (
                "pre-metadata-fix prototype; mathematical model is unchanged"
            )
        stem = result_path.name.removesuffix(".result.json")
        solver_log = result_path.with_name(stem + ".solver.log")
        launcher_log = result_path.with_name(stem + ".launcher.log")
        for artifact in (result_path, solver_log, launcher_log):
            if not artifact.is_file():
                raise FileNotFoundError(artifact)
        if tuple(report["selected_quad_zero_based"]) != key:
            raise ValueError(f"replacement result label mismatch in {result_path}")
        if report.get("selection_rule") != "explicit connected quad supplied with --quad":
            raise ValueError(f"replacement selection_rule mismatch in {result_path}")
        best = report.get("best_connected")
        merged = {
            "quad_zero_based": list(key),
            "global_rank": initial["global_rank"],
            "source_shard": initial["source_shard"],
            "reused_existing_result": False,
            "replacement_number": replacement_number,
            "replacement_reason": "metadata-clean replay with the archived solver script",
            "initial_attempt": initial,
            "result": result_path.relative_to(archive).as_posix(),
            "result_sha256": sha256(result_path),
            "solver_log": solver_log.relative_to(archive).as_posix(),
            "solver_log_sha256": sha256(solver_log),
            "launcher_log": launcher_log.relative_to(archive).as_posix(),
            "launcher_log_sha256": sha256(launcher_log),
            "remote_result": remote_dir.rstrip("/") + "/" + result_path.name,
            "remote_solver_log": remote_dir.rstrip("/") + "/" + solver_log.name,
            "remote_launcher_log": remote_dir.rstrip("/") + "/" + launcher_log.name,
            "returncode": 0,
            "termination": report.get("termination"),
            "anchored_connected_quad_optimality_proved": bool(
                report.get("anchored_connected_quad_optimality_proved")
            ),
            "connectivity_cuts_added": report.get("connectivity_cuts_added"),
            "rounds": len(report.get("rounds", [])),
            "wall_seconds": report.get("wall_seconds"),
            "old_internal_cut_weight": report.get("old_internal_cut_weight"),
            "best_connected_full_objective": best.get("full_objective") if best else None,
            "best_connected_objective_delta": best.get("objective_delta") if best else None,
            "selection_rule": report["selection_rule"],
            "result_ranking_position": report.get("ranking_position"),
            "last_solver_status": (
                report["rounds"][-1].get("status") if report.get("rounds") else None
            ),
        }
        merged["time_limit_exhausted"] = merged["last_solver_status"] == "8"
        record_by_quad[key] = merged
        replacement_summaries.append(
            {
                "replacement_number": replacement_number,
                "quad_zero_based": list(key),
                "global_rank": initial["global_rank"],
                "directory": result_path.parent.relative_to(archive).as_posix(),
                "result": result_path.relative_to(archive).as_posix(),
                "result_sha256": sha256(result_path),
                "remote_directory": remote_dir,
                "wall_seconds": report.get("wall_seconds"),
            }
        )

    assert common is not None
    for retry_number, retry_manifest_path in enumerate(args.retry_manifest, start=1):
        retry_manifest_path = retry_manifest_path.resolve()
        retry_dir = retry_manifest_path.parent
        retry_source = json.loads(retry_manifest_path.read_text(encoding="utf-8"))
        for retry_record in retry_source["records"]:
            key = tuple(int(label) for label in retry_record["quad_zero_based"])
            if key not in record_by_quad:
                raise ValueError(f"retry refers to unknown quad {key}")
            initial = record_by_quad[key]
            merged = dict(retry_record)
            merged["global_rank"] = initial["global_rank"]
            merged["source_shard"] = initial["source_shard"]
            merged["retry_number"] = retry_number
            merged["initial_attempt"] = initial
            for kind in ("result", "solver_log", "launcher_log"):
                remote = retry_record.get(kind)
                if remote is None:
                    continue
                path = retry_dir / Path(str(remote)).name
                if not path.is_file():
                    raise FileNotFoundError(path)
                actual = sha256(path)
                recorded = retry_record.get(f"{kind}_sha256")
                if recorded is not None and actual != recorded:
                    raise ValueError(f"hash mismatch for retry artifact {path}")
                merged[f"remote_{kind}"] = remote
                merged[kind] = path.relative_to(archive).as_posix()
                merged[f"{kind}_sha256"] = actual
            report_path = archive / str(merged["result"])
            report = json.loads(report_path.read_text(encoding="utf-8"))
            if tuple(report["selected_quad_zero_based"]) != key:
                raise ValueError(f"retry result label mismatch in {report_path}")
            if report.get("selection_rule") != "explicit connected quad supplied with --quad":
                raise ValueError(f"retry selection_rule mismatch in {report_path}")
            merged["selection_rule"] = report["selection_rule"]
            merged["result_ranking_position"] = report.get("ranking_position")
            merged["last_solver_status"] = (
                report["rounds"][-1].get("status") if report.get("rounds") else None
            )
            merged["time_limit_exhausted"] = merged["last_solver_status"] == "8"
            merged["old_internal_cut_weight"] = report.get("old_internal_cut_weight")
            record_by_quad[key] = merged
        retry_summaries.append(
            {
                "retry_number": retry_number,
                "directory": retry_dir.relative_to(archive).as_posix(),
                "manifest": retry_manifest_path.relative_to(archive).as_posix(),
                "manifest_sha256": sha256(retry_manifest_path),
                "retries_requested": retry_source["retries_requested"],
                "retries_completed": retry_source["retries_completed"],
                "retries_proved_optimal": retry_source["retries_proved_optimal"],
                "retries_without_proof": retry_source["retries_without_proof"],
                "improving_quads": retry_source["improving_quads"],
                "time_limit_per_quad": retry_source["time_limit_per_quad"],
            }
        )

    expected = int(common["quads_total_requested"])
    if len(ranking_by_quad) != expected:
        raise ValueError(f"ranking covers {len(ranking_by_quad)} quads, expected {expected}")
    if len(record_by_quad) != expected:
        raise ValueError(f"only {len(record_by_quad)} completed quads, expected {expected}")
    records = sorted(record_by_quad.values(), key=lambda row: int(row["global_rank"]))
    if [int(row["global_rank"]) for row in records] != list(range(1, expected + 1)):
        raise ValueError("global ranks are not exactly 1..N")

    proved = sum(bool(row["anchored_connected_quad_optimality_proved"]) for row in records)
    improving = sum(
        row.get("best_connected_objective_delta") is not None
        and float(row["best_connected_objective_delta"]) < -1e-12
        for row in records
    )
    child_errors = sum(row.get("termination") == "child_error" for row in records)
    final_timeouts = sum(bool(row.get("time_limit_exhausted")) for row in records)
    final_cuts = sum(int(row.get("connectivity_cuts_added") or 0) for row in records)
    final_wall = sum(float(row.get("wall_seconds") or 0.0) for row in records)
    initial_wall = sum(float(row.get("wall_seconds") or 0.0) for row in initial_records)
    retry_wall = sum(
        float(row.get("wall_seconds") or 0.0)
        for path in args.retry_manifest
        for row in json.loads(path.read_text(encoding="utf-8"))["records"]
    )
    replacement_wall = sum(
        float(row.get("wall_seconds") or 0.0) for row in replacement_summaries
    )
    parallel_started = min(float(row["started_unix_time"]) for row in shard_summaries)
    parallel_finished = max(float(row["finished_unix_time"]) for row in shard_summaries)
    merged_manifest = {
        "schema": "nj-anchored-district-quad-copt-complete-v1",
        "claim": (
            "complete anchor-fixed four-district local audit over every connected "
            "quad in the current district-adjacency graph"
        ),
        "scope_limitation": (
            "Each model fixes one current anchor per district. This is not the "
            "unanchored four-district neighborhood and does not establish a global "
            "lower bound or global optimality for the original MIP."
        ),
        "proof_portability": (
            "Solver-backed COPT optimal statuses with exact assignment replay; "
            "no portable solver-independent MIP proof file was emitted."
        ),
        **common,
        "connected_quads_ranked": len(ranking_by_quad),
        "connected_quads_completed": len(records),
        "connected_quads_proved_optimal": proved,
        "connected_quads_without_proof": len(records) - proved,
        "connected_quads_time_limit_exhausted": final_timeouts,
        "improving_quads": improving,
        "child_errors": child_errors,
        "final_attempt_connectivity_cuts_added": final_cuts,
        "final_attempt_wall_seconds_sum": final_wall,
        "initial_batch_wall_seconds_sum": initial_wall,
        "retry_wall_seconds_sum": retry_wall,
        "replacement_wall_seconds_sum": replacement_wall,
        "all_attempts_wall_seconds_sum": initial_wall + retry_wall + replacement_wall,
        "initial_parallel_batch_elapsed_seconds": parallel_finished - parallel_started,
        "solver_script": args.solver_script.as_posix(),
        "solver_script_sha256": sha256(args.solver_script),
        "batch_script": args.batch_script.as_posix(),
        "batch_script_sha256": sha256(args.batch_script),
        "retry_script": args.retry_script.as_posix(),
        "retry_script_sha256": sha256(args.retry_script),
        "merge_script": args.merge_script.as_posix(),
        "merge_script_sha256": sha256(args.merge_script),
        "shards": shard_summaries,
        "retries": retry_summaries,
        "replacements": replacement_summaries,
        "superseded_rank1_prototype_solver_script_sha256": (
            args.legacy_prototype_script_sha256
        ),
        "ranking": sorted(ranking_by_quad.values(), key=lambda row: int(row["global_rank"])),
        "records": records,
    }
    output = archive / "manifest.json"
    output.write_text(json.dumps(merged_manifest, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(output)


if __name__ == "__main__":
    main()
