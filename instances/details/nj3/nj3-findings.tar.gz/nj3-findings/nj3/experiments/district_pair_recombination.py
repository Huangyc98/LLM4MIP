#!/usr/bin/env python3
"""Deterministic seeded district-pair spanning-tree recombination for nj.

For every adjacent district pair, randomized Kruskal trees are built on the
induced union.  Every tree edge whose removal gives two population-feasible
connected components is evaluated with the exact Decimal cut objective.  The
best improving repartition is applied, and the scan repeats.  The output is an
assignment certificate and still requires a full original-MPS lift/check.
"""

from __future__ import annotations

import argparse
import json
import random
import sys
from decimal import Decimal
from pathlib import Path


THIS = Path(__file__).resolve()
NJ1_EXPERIMENTS = THIS.parents[2] / "nj1" / "experiments"
sys.path.insert(0, str(NJ1_EXPERIMENTS))
from connected_boundary_steepest_descent import (  # noqa: E402
    DISTRICTS,
    LOWER_POPULATION,
    NODES,
    UPPER_POPULATION,
    component,
    extract_graph,
    objective,
)
from nj_block_forensics import sha256  # noqa: E402


class DisjointSet:
    def __init__(self, nodes: list[int]) -> None:
        self.parent = {node: node for node in nodes}
        self.rank = {node: 0 for node in nodes}

    def find(self, node: int) -> int:
        parent = self.parent[node]
        if parent != node:
            self.parent[node] = self.find(parent)
        return self.parent[node]

    def union(self, left: int, right: int) -> bool:
        left = self.find(left)
        right = self.find(right)
        if left == right:
            return False
        if self.rank[left] < self.rank[right]:
            left, right = right, left
        self.parent[right] = left
        if self.rank[left] == self.rank[right]:
            self.rank[left] += 1
        return True


def district_populations(assignment: list[int], populations: list[int]) -> list[int]:
    return [
        sum(populations[node] for node, label in enumerate(assignment) if label == district)
        for district in range(DISTRICTS)
    ]


def connected(assignment: list[int], district: int, adjacency: list[list[int]]) -> bool:
    return len(component(assignment, district, adjacency)) == assignment.count(district)


def random_tree(
    nodes: list[int],
    induced_edges: list[tuple[int, int, Decimal]],
    rng: random.Random,
) -> list[tuple[int, int]]:
    order = list(range(len(induced_edges)))
    rng.shuffle(order)
    forest = DisjointSet(nodes)
    tree = []
    for index in order:
        left, right, _ = induced_edges[index]
        if forest.union(left, right):
            tree.append((left, right))
            if len(tree) + 1 == len(nodes):
                break
    if len(tree) + 1 != len(nodes):
        raise ValueError("adjacent district union is disconnected")
    return tree


def rooted_tree_data(
    nodes: list[int], tree: list[tuple[int, int]], populations: list[int]
) -> tuple[list[int], dict[int, int | None], dict[int, int], dict[int, int], dict[int, int]]:
    adjacency = {node: [] for node in nodes}
    for left, right in tree:
        adjacency[left].append(right)
        adjacency[right].append(left)
    for neighbors in adjacency.values():
        neighbors.sort()

    root = min(nodes)
    parent: dict[int, int | None] = {root: None}
    order = [root]
    for node in order:
        for neighbor in adjacency[node]:
            if neighbor not in parent:
                parent[neighbor] = node
                order.append(neighbor)

    children = {node: [] for node in nodes}
    for node in order[1:]:
        predecessor = parent[node]
        assert predecessor is not None
        children[predecessor].append(node)

    euler = []
    tin: dict[int, int] = {}
    tout: dict[int, int] = {}
    stack: list[tuple[int, bool]] = [(root, False)]
    while stack:
        node, leaving = stack.pop()
        if leaving:
            tout[node] = len(euler) - 1
            continue
        tin[node] = len(euler)
        euler.append(node)
        stack.append((node, True))
        for child in reversed(children[node]):
            stack.append((child, False))

    subtree_population = {node: populations[node] for node in nodes}
    for node in reversed(order[1:]):
        predecessor = parent[node]
        assert predecessor is not None
        subtree_population[predecessor] += subtree_population[node]
    return euler, parent, tin, tout, subtree_population


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("graph_mps", type=Path)
    parser.add_argument("initial_assignment", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--restarts-per-pair", type=int, default=200)
    parser.add_argument("--max-iterations", type=int, default=20)
    parser.add_argument("--seed", type=int, default=20260908)
    args = parser.parse_args()

    populations, edges = extract_graph(args.graph_mps)
    adjacency = [[] for _ in range(NODES)]
    for left, right, _ in edges:
        adjacency[left].append(right)
        adjacency[right].append(left)
    for neighbors in adjacency:
        neighbors.sort()

    source = json.loads(args.initial_assignment.read_text(encoding="utf-8"))
    assignment = list(source["assignment_zero_based_district"])
    if len(assignment) != NODES or set(assignment) != set(range(DISTRICTS)):
        raise ValueError("assignment must contain 595 labels and all districts 0..11")
    if assignment[0] != 0:
        raise ValueError("nj3-compatible input must assign zero-based node 0 to district 0")
    if any(not connected(assignment, district, adjacency) for district in range(DISTRICTS)):
        raise ValueError("initial assignment has a disconnected district")
    initial_populations = district_populations(assignment, populations)
    if any(not LOWER_POPULATION <= value <= UPPER_POPULATION for value in initial_populations):
        raise ValueError("initial assignment violates a population bound")

    initial_objective = objective(assignment, edges)
    recorded = source.get("boundary_objective_original_units")
    if recorded is not None and Decimal(recorded) != initial_objective:
        raise ValueError(f"recorded objective {recorded} != exact {initial_objective}")

    moves = []
    terminal = None
    for iteration in range(1, args.max_iterations + 1):
        current_objective = objective(assignment, edges)
        pairs = sorted({
            tuple(sorted((assignment[left], assignment[right])))
            for left, right, _ in edges
            if assignment[left] != assignment[right]
        })
        best_key = None
        best_assignment = None
        best_record = None
        feasible_cuts = 0
        trees_built = 0

        for first, second in pairs:
            nodes = [node for node, label in enumerate(assignment) if label in (first, second)]
            node_set = set(nodes)
            induced_edges = [
                (left, right, cost) for left, right, cost in edges
                if left in node_set and right in node_set
            ]
            old_cut = sum(
                (cost for left, right, cost in induced_edges
                 if assignment[left] != assignment[right]),
                Decimal(0),
            )
            total_population = sum(populations[node] for node in nodes)

            for restart in range(args.restarts_per_pair):
                rng = random.Random(f"{args.seed}:{iteration}:{first}:{second}:{restart}")
                tree = random_tree(nodes, induced_edges, rng)
                trees_built += 1
                euler, parent, tin, tout, subtree_population = rooted_tree_data(
                    nodes, tree, populations
                )
                for child in euler[1:]:
                    child_population = subtree_population[child]
                    other_population = total_population - child_population
                    if not (
                        LOWER_POPULATION <= child_population <= UPPER_POPULATION
                        and LOWER_POPULATION <= other_population <= UPPER_POPULATION
                    ):
                        continue
                    feasible_cuts += 1
                    begin, end = tin[child], tout[child]

                    def in_child(node: int) -> bool:
                        position = tin[node]
                        return begin <= position <= end

                    new_cut = sum(
                        (cost for left, right, cost in induced_edges
                         if in_child(left) != in_child(right)),
                        Decimal(0),
                    )
                    if new_cut >= old_cut:
                        continue
                    child_has_zero = in_child(0) if 0 in node_set else False
                    child_label = first
                    other_label = second
                    if first == 0 or second == 0:
                        nonzero_label = second if first == 0 else first
                        child_label = 0 if child_has_zero else nonzero_label
                        other_label = nonzero_label if child_has_zero else 0
                    trial = assignment.copy()
                    for node in nodes:
                        trial[node] = child_label if in_child(node) else other_label
                    value = objective(trial, edges)
                    expected = current_objective + 2 * (new_cut - old_cut)
                    if value != expected:
                        raise RuntimeError("pair-local and full objective changes disagree")
                    key = (value, first, second, restart, child)
                    if best_key is None or key < best_key:
                        best_key = key
                        best_assignment = trial
                        best_record = {
                            "district_pair_zero_based": [first, second],
                            "restart": restart,
                            "tree_cut_child_zero_based": child,
                            "component_populations": [child_population, other_population],
                            "old_pair_cut_weight": str(old_cut),
                            "new_pair_cut_weight": str(new_cut),
                        }

        if best_assignment is None or best_record is None or best_key is None:
            terminal = {
                "iteration": iteration,
                "adjacent_district_pairs": len(pairs),
                "trees_built": trees_built,
                "population_feasible_tree_cuts": feasible_cuts,
                "improving_tree_cuts": 0,
            }
            break

        new_objective = objective(best_assignment, edges)
        if new_objective >= current_objective:
            raise RuntimeError("selected recombination does not improve the objective")
        assignment = best_assignment
        if assignment[0] != 0:
            raise RuntimeError("selected recombination broke the nj3 label anchor")
        if any(not connected(assignment, district, adjacency) for district in range(DISTRICTS)):
            raise RuntimeError("selected recombination broke connectivity")
        new_populations = district_populations(assignment, populations)
        if any(not LOWER_POPULATION <= value <= UPPER_POPULATION for value in new_populations):
            raise RuntimeError("selected recombination broke population balance")
        best_record.update({
            "iteration": iteration,
            "objective_before": str(current_objective),
            "objective_after": str(new_objective),
            "objective_delta": str(new_objective - current_objective),
            "adjacent_district_pairs_scanned": len(pairs),
            "trees_built": trees_built,
            "population_feasible_tree_cuts": feasible_cuts,
        })
        moves.append(best_record)
        print(
            f"iteration={iteration} pair={best_record['district_pair_zero_based']} "
            f"delta={new_objective - current_objective} objective={new_objective}",
            flush=True,
        )
    else:
        raise SystemExit("hit --max-iterations before a terminal no-improvement scan")

    final_objective = objective(assignment, edges)
    final_populations = district_populations(assignment, populations)
    result = {
        "schema": "nj-district-pair-tree-recombination-v1",
        "evidence_level": (
            "deterministic seeded spanning-tree recombination with exact population, "
            "connectivity and Decimal objective checks; requires original-MPS lift/check"
        ),
        "source_mps_sha256": sha256(args.graph_mps),
        "initial_assignment_sha256": sha256(args.initial_assignment),
        "seed": args.seed,
        "restarts_per_pair": args.restarts_per_pair,
        "initial_boundary_objective_original_units": str(initial_objective),
        "boundary_objective_original_units": str(final_objective),
        "objective_improvement": str(initial_objective - final_objective),
        "moves_applied": len(moves),
        "moves": moves,
        "terminal_scan": terminal,
        "assignment_zero_based_district": assignment,
        "district_populations": final_populations,
        "district_component_sizes": [assignment.count(d) for d in range(DISTRICTS)],
        "cut_edges": sum(assignment[left] != assignment[right] for left, right, _ in edges),
        "node_zero_district_zero_based": assignment[0],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8", newline="\n")
    print("RESULT=" + str(args.output))


if __name__ == "__main__":
    main()
