#!/usr/bin/env python3
"""Audit the exact algebraic relationship between official nj2 and nj3.

The script only parses the two MPS files.  It never invokes a solver.  Every
coefficient, RHS, bound, and integrality comparison uses Decimal arithmetic.
"""

from __future__ import annotations

import argparse
import json
import sys
from decimal import Decimal
from pathlib import Path


THIS = Path(__file__).resolve()
NJ1_EXPERIMENTS = THIS.parents[2] / "nj1" / "experiments"
sys.path.insert(0, str(NJ1_EXPERIMENTS))
from nj_block_forensics import parse_mps, sha256  # noqa: E402


NODES = 595
DISTRICTS = 12
ROOT_BASE = 78_085
NJ2_ROWS = 118_975


def cname(index: int) -> str:
    return f"C{index:04d}"


def rname(index: int) -> str:
    return f"R{index:04d}"


def normalized(terms: list[tuple[str, Decimal]]) -> list[tuple[str, Decimal]]:
    return sorted(terms)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("nj2_mps", type=Path)
    parser.add_argument("nj3_mps", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    nj2 = parse_mps(args.nj2_mps)
    nj3 = parse_mps(args.nj3_mps)

    common_row_failures: list[str] = []
    for index in range(1, NJ2_ROWS + 1):
        row = rname(index)
        left = nj2["rows"][row]
        right = nj3["rows"][row]
        if (
            left["sense"] != right["sense"]
            or nj2["rhs"].get(row, Decimal(0)) != nj3["rhs"].get(row, Decimal(0))
            or normalized(left["terms"]) != normalized(right["terms"])
        ):
            common_row_failures.append(row)

    nj2_objective = rname(NJ2_ROWS + 1)
    nj3_objective = rname(NJ2_ROWS + DISTRICTS)
    objective_exact = (
        nj2["rows"][nj2_objective]["sense"] == "N"
        and nj3["rows"][nj3_objective]["sense"] == "N"
        and normalized(nj2["rows"][nj2_objective]["terms"])
        == normalized(nj3["rows"][nj3_objective]["terms"])
    )

    variable_failures: list[str] = []
    if list(nj2["variables"]) != list(nj3["variables"]):
        variable_failures.append("ordered variable-name list")
    else:
        for variable, left in nj2["variables"].items():
            right = nj3["variables"][variable]
            if (
                left["integer"] != right["integer"]
                or left["lower"] != right["lower"]
                or left["upper"] != right["upper"]
            ):
                variable_failures.append(variable)

    added_rows = []
    added_failures = []
    for district in range(DISTRICTS - 1):
        row = rname(NJ2_ROWS + 1 + district)
        expected = []
        for node in range(NODES):
            expected.append((cname(ROOT_BASE + DISTRICTS * node + district), Decimal(-1)))
            expected.append((cname(ROOT_BASE + DISTRICTS * node + district + 1), Decimal(node + 1)))
        info = nj3["rows"][row]
        actual_rhs = nj3["rhs"].get(row, Decimal(0))
        exact = info["sense"] == "G" and actual_rhs == 1 and normalized(info["terms"]) == normalized(expected)
        if not exact:
            added_failures.append(row)
        added_rows.append({
            "row": row,
            "district_pair_zero_based": [district, district + 1],
            "sense": info["sense"],
            "rhs": str(actual_rhs),
            "nonzeros": len(info["terms"]),
            "expected_template_exact": exact,
            "template": (
                f"-sum_n root[n,{district}] + "
                f"sum_n (n+1)*root[n,{district + 1}] >= 1"
            ),
        })

    result = {
        "evidence_level": (
            "exact Decimal matrix comparison of official nj2/nj3, including all common rows, "
            "the shifted objective, all variable bounds/types, and every added-row coefficient"
        ),
        "sha256": {
            "nj2_mps_gz": sha256(args.nj2_mps),
            "nj3_mps_gz": sha256(args.nj3_mps),
        },
        "dimensions": {
            "nj2": {
                "algebraic_rows": sum(info["sense"] != "N" for info in nj2["rows"].values()),
                "variables": len(nj2["variables"]),
                "linear_nonzeros": sum(
                    len(info["terms"]) for info in nj2["rows"].values() if info["sense"] != "N"
                ),
                "objective_nonzeros": sum(
                    len(info["terms"]) for info in nj2["rows"].values() if info["sense"] == "N"
                ),
            },
            "nj3": {
                "algebraic_rows": sum(info["sense"] != "N" for info in nj3["rows"].values()),
                "variables": len(nj3["variables"]),
                "linear_nonzeros": sum(
                    len(info["terms"]) for info in nj3["rows"].values() if info["sense"] != "N"
                ),
                "objective_nonzeros": sum(
                    len(info["terms"]) for info in nj3["rows"].values() if info["sense"] == "N"
                ),
            },
        },
        "common_core": {
            "rows_checked": NJ2_ROWS,
            "row_failure_count": len(common_row_failures),
            "row_failure_sample": common_row_failures[:20],
            "objective_mapping": f"{nj2_objective} -> {nj3_objective}",
            "objective_exact": objective_exact,
            "variables_checked": len(nj2["variables"]),
            "bound_or_integrality_failure_count": len(variable_failures),
            "bound_or_integrality_failure_sample": variable_failures[:20],
            "exact": not common_row_failures and objective_exact and not variable_failures,
        },
        "nj3_extension": {
            "row_range": [rname(NJ2_ROWS + 1), rname(NJ2_ROWS + DISTRICTS - 1)],
            "row_count": DISTRICTS - 1,
            "nonzeros_per_row": 2 * NODES,
            "total_added_nonzeros": 2 * NODES * (DISTRICTS - 1),
            "rows": added_rows,
            "template_failure_count": len(added_failures),
            "template_failure_sample": added_failures[:20],
        },
        "interpretation": {
            "exact_algebra": (
                "Using the existing one-root-per-district equation, each added row reduces to "
                "sum_n (n+1)*root[n,d+1] >= 2."
            ),
            "consequence_with_nj2_root_layer": (
                "The nj2 q/root symmetry layer forces root[n,d] to be the minimum-index selected node. "
                "Thus the 11 new rows forbid zero-based node 0 from districts 1..11, so node 0 must "
                "carry district label 0.  They do not impose a full ordering of all 12 root indices."
            ),
            "migration": (
                "Any nj2 assignment can satisfy nj3 without changing its unlabeled partition or objective "
                "by permuting district labels so the district containing node 0 is labeled 0."
            ),
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({
        "common_core_exact": result["common_core"]["exact"],
        "added_template_failures": len(added_failures),
        "nj2_dimensions": result["dimensions"]["nj2"],
        "nj3_dimensions": result["dimensions"]["nj3"],
    }, indent=2))
    if not result["common_core"]["exact"] or added_failures:
        raise SystemExit("nj2/nj3 exact projection audit failed")


if __name__ == "__main__":
    main()
