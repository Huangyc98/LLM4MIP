#!/usr/bin/env python3
"""Run exact_district_pair_copt.py over adjacent pairs in ranked order."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import time
from decimal import Decimal
from pathlib import Path


THIS = Path(__file__).resolve()
sys.path.insert(0, str(THIS.parent))
from exact_district_pair_copt import (  # noqa: E402
    DISTRICTS,
    NODES,
    extract_graph,
    objective,
    pair_rows,
    sha256,
)


def summarize(path: Path, *, reused: bool) -> dict[str, object]:
    report = json.loads(path.read_text(encoding="utf-8"))
    result = report["result"]
    connected = result.get("best_connected")
    return {
        "pair_zero_based": result["pair_zero_based"],
        "reused_existing_result": reused,
        "result": path.as_posix(),
        "result_sha256": sha256(path),
        "solver_log": None,
        "solver_log_sha256": None,
        "termination": result.get("termination"),
        "connected_pair_optimality_proved": bool(
            result.get("connected_pair_optimality_proved")
        ),
        "connectivity_cuts_added": result.get("connectivity_cuts_added"),
        "rounds": len(result.get("rounds", [])),
        "wall_seconds": result.get("wall_seconds"),
        "old_pair_cut_weight": result.get("old_pair_cut_weight"),
        "best_connected_full_objective": (
            connected.get("full_objective") if connected else None
        ),
        "best_connected_objective_delta": (
            connected.get("objective_delta") if connected else None
        ),
    }


def write_manifest(path: Path, manifest: dict[str, object]) -> None:
    records = manifest["records"]
    manifest["pairs_completed"] = len(records)
    manifest["pairs_proved_optimal"] = sum(
        bool(item["connected_pair_optimality_proved"]) for item in records
    )
    manifest["pairs_without_proof"] = sum(
        not bool(item["connected_pair_optimality_proved"]) for item in records
    )
    manifest["improving_pairs"] = sum(
        item["best_connected_objective_delta"] is not None
        and Decimal(item["best_connected_objective_delta"]) < 0
        for item in records
    )
    path.write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8", newline="\n"
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("graph_mps", type=Path)
    parser.add_argument("assignment", type=Path)
    parser.add_argument("outdir", type=Path)
    parser.add_argument("--time-limit-per-pair", type=float, default=60.0)
    parser.add_argument("--threads", type=int, default=1)
    parser.add_argument("--max-rounds", type=int, default=500)
    parser.add_argument("--existing-result", action="append", type=Path, default=[])
    args = parser.parse_args()

    populations, edges = extract_graph(args.graph_mps)
    source = json.loads(args.assignment.read_text(encoding="utf-8"))
    assignment = list(source["assignment_zero_based_district"])
    if len(assignment) != NODES or set(assignment) != set(range(DISTRICTS)):
        raise ValueError("invalid assignment")
    initial_objective = objective(assignment, edges)
    ranked_pairs = pair_rows(assignment, populations, edges)
    args.outdir.mkdir(parents=True, exist_ok=True)
    manifest_path = args.outdir / "manifest.json"
    manifest: dict[str, object] = {
        "schema": "nj-exact-district-pair-copt-batch-v1",
        "evidence_level": (
            "collection of independent COPT pair-local runs; see every result for "
            "integer scaling and connectivity-cut proof boundary"
        ),
        "graph_mps": args.graph_mps.as_posix(),
        "graph_mps_sha256": sha256(args.graph_mps),
        "assignment": args.assignment.as_posix(),
        "assignment_sha256": sha256(args.assignment),
        "initial_full_objective": str(initial_objective),
        "pairs_total": len(ranked_pairs),
        "time_limit_per_pair": args.time_limit_per_pair,
        "threads": args.threads,
        "ranked_pairs": ranked_pairs,
        "records": [],
        "stopped_early_for_improvement": False,
        "started_unix_time": time.time(),
    }

    completed = set()
    for existing in args.existing_result:
        record = summarize(existing, reused=True)
        pair = tuple(record["pair_zero_based"])
        if pair in completed:
            raise ValueError(f"duplicate existing pair {pair}")
        completed.add(pair)
        manifest["records"].append(record)
    write_manifest(manifest_path, manifest)

    for row in ranked_pairs:
        first, second = row["pair"]
        if (first, second) in completed:
            continue
        stem = f"pair-{first}-{second}"
        result_path = args.outdir / f"{stem}.result.json"
        solver_log = args.outdir / f"{stem}.solver.log"
        launcher_log = args.outdir / f"{stem}.launcher.log"
        command = [
            sys.executable,
            str(THIS.parent / "exact_district_pair_copt.py"),
            str(args.graph_mps),
            str(args.assignment),
            str(result_path),
            "--pair", str(first), str(second),
            "--time-limit", str(args.time_limit_per_pair),
            "--threads", str(args.threads),
            "--max-rounds", str(args.max_rounds),
            "--log", str(solver_log),
        ]
        with launcher_log.open("w", encoding="utf-8", newline="\n") as stream:
            completed_process = subprocess.run(
                command,
                stdout=stream,
                stderr=subprocess.STDOUT,
                env=os.environ.copy(),
                check=False,
            )
        if completed_process.returncode != 0 or not result_path.is_file():
            manifest["records"].append({
                "pair_zero_based": [first, second],
                "reused_existing_result": False,
                "result": result_path.as_posix(),
                "result_sha256": None,
                "solver_log": solver_log.as_posix() if solver_log.is_file() else None,
                "solver_log_sha256": sha256(solver_log) if solver_log.is_file() else None,
                "launcher_log": launcher_log.as_posix(),
                "launcher_log_sha256": sha256(launcher_log),
                "returncode": completed_process.returncode,
                "termination": "child_error",
                "connected_pair_optimality_proved": False,
                "best_connected_objective_delta": None,
            })
            write_manifest(manifest_path, manifest)
            continue

        record = summarize(result_path, reused=False)
        record.update({
            "solver_log": solver_log.as_posix(),
            "solver_log_sha256": sha256(solver_log),
            "launcher_log": launcher_log.as_posix(),
            "launcher_log_sha256": sha256(launcher_log),
            "returncode": completed_process.returncode,
        })
        manifest["records"].append(record)
        write_manifest(manifest_path, manifest)
        delta = record["best_connected_objective_delta"]
        print(
            f"pair={first},{second} termination={record['termination']} "
            f"proved={record['connected_pair_optimality_proved']} delta={delta}",
            flush=True,
        )
        if delta is not None and Decimal(delta) < 0:
            manifest["stopped_early_for_improvement"] = True
            manifest["improving_result"] = result_path.as_posix()
            write_manifest(manifest_path, manifest)
            break

    manifest["finished_unix_time"] = time.time()
    write_manifest(manifest_path, manifest)
    print("MANIFEST=" + str(manifest_path), flush=True)


if __name__ == "__main__":
    main()
