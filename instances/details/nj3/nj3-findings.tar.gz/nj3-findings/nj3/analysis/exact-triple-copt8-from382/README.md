# Anchored exact three-district audit from 382.0606208032

This directory archives COPT 8.0.4 models for all 39 connected triples in the
district-adjacency graph of the strict `382.0606208032` assignment. The source
assignment is
[`../../../nj1/analysis/final-assignment-382.0606208032.json`](../../../nj1/analysis/final-assignment-382.0606208032.json),
SHA-256
`a13e58bd98050c830ca3436eb616410cb60fc64d3b2424f8bf5f29cac6ddeba5`.

For a selected triple, the model arbitrarily reassigns all nodes in the three
districts' union, enforces all three exact population bounds, and minimizes
the integer-scaled exact internal cut. It fixes the current minimum-index node
of each district to that district as an anchor. Rooted connectivity cuts are
available and are separated from disconnected integer optima.

All 39 models returned the current assignment as a COPT-optimal solution in
their first round. Every returned partition was already connected, so no
connectivity cut was needed. Thus the current assignment attains the optimum
of the weaker population-balanced cut model for every tested triple and there
is no improving repartition in this complete **anchor-fixed** three-district
neighborhood.

Summary:

- connected district triples: 39;
- completed and COPT-optimal: 39;
- timeouts or runs without proof: 0;
- improving triples: 0;
- connectivity cuts added: 0;
- sum of recorded wall times: about 74.24 seconds, maximum 10.87 seconds;
- every exact full-objective delta: `0E-10`.

The qualification "anchor-fixed" matters. A three-way repartition that places
two of the current anchors in the same new district is outside these models.
The result is not a full-MIP lower bound and does not prove global optimality.
COPT optimal status is a numerical solver certificate; the scripts separately
recompute objective weights, populations, connectivity, and full-objective
deltas with exact integer/Decimal arithmetic.

[`manifest.json`](manifest.json), SHA-256
`c037b3b9afa48826a06f6cdaecb03901a5f5b3e9f4e2406ce6c3ef7bcadcc35e`,
contains the complete ranking and one proof record per triple. Every triple
has matching `result.json`, `solver.log`, and `launcher.log` artifacts.
[`SHA256SUMS`](SHA256SUMS), whose own SHA-256 is
`d806a14ce0226f72154ca624c069da6b9c3a9bfb1a3c215d455fd002da7a4562`,
covers `batch.log`, `manifest.json`, and all `39 * 3` per-triple artifacts
(119 entries; `README.md` and `SHA256SUMS` itself are intentionally excluded).

Metadata erratum: the 38 per-triple results launched with an explicit
`--triple` retain the legacy `selection_rule` text "maximum current internal
boundary weight". The batch actually passed each triple explicitly in the
order recorded by `manifest.json`; only the first ranked triple is itself the
maximum. This wording does not affect any model, coefficient, solution, or
proof flag. Treat the manifest ranking and each `selected_triple_zero_based`
field as authoritative.

Reproduce with:

```bash
python instances/nj3/experiments/run_exact_triple_batch.py \
  instances/nj1/input/nj1.mps.gz \
  instances/nj1/analysis/final-assignment-382.0606208032.json \
  exact-triple-run \
  --top 39 --time-limit-per-triple 60 --threads 4 --max-rounds 1000
```
