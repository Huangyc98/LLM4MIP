# Package manifest: shs1042

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 40
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/all_component_neighborhood_search_batch1.json`
- `artifacts/all_component_neighborhood_search_batch2.json`
- `artifacts/component_neighborhood_strict_retry.json`
- `artifacts/components_threshold20.npz`
- `artifacts/copt_default_175s.json`
- `artifacts/decomposition_analysis.json`
- `artifacts/gurobi_aggressive_900s.json`
- `artifacts/gurobi_dual_175s.json`
- `artifacts/gurobi_race_seed1_600s.json`
- `artifacts/gurobi_race_seed7_sym2_600s.json`
- `artifacts/multi_component_neighborhood_search_strict.json`
- `artifacts/partition_articles_free_180s.json`
- `artifacts/public_solution_audit.json`
- `artifacts/public_solution_integer_rounded_audit.json`
- `artifacts/research_summary_2026-09-07.json`
- `artifacts/rins_analysis_corrected_1s.json`
- `artifacts/shs1042-rounded-audit.json`
- `artifacts/small_domain_onehot_240s.json`
- `artifacts/truck_schedule_radius0_tight_confirm.json`
- `artifacts/truck_schedule_radius2_tight_confirm.json`
- `input/shs1042-public-3.sol.gz`
- `logs/copt_default_175s.log`
- `logs/gurobi_aggressive_900s.log`
- `logs/gurobi_dual_175s.log`
- `logs/gurobi_race_seed1_600s.log`
- `logs/gurobi_race_seed7_sym2_600s.log`
- `logs/partition_articles_free_180s.log`
- `logs/small_domain_onehot_240s.log`
- `logs/truck_schedule_radius0_tight_confirm.log`
- `logs/truck_schedule_radius2_tight_confirm.log`
- `scripts/analyze_decomposition.py`
- `scripts/component_neighborhood_search.py`
- `scripts/multi_component_neighborhood_search.py`
- `scripts/partition_neighborhood_search.py`
- `scripts/repair_public_solution.py`
- `scripts/rins_submip.py`
- `scripts/small_domain_extension_probe.py`
- `scripts/truck_schedule_local_branching.py`
- `solutions/shs1042-rounded.sol.gz`

## Excluded files

- `input/shs1042.mps.gz (7832019 bytes; raw benchmark input; sha256 5d66ae49b1b1916c9b6086419cc3d90e80e8cd2d00365e98f62c2ebe2da885f6)`
