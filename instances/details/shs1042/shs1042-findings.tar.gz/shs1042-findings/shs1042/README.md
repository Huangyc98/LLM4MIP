# `shs1042` extended research report — 2026-09-07

## Executive result

`shs1042` is **not proved globally optimal**, and no primal improvement over the
MIPLIB incumbent was found. The main new results are nevertheless substantive:

1. A strictly feasible repair of the public solution was produced at
   **11070.7016616034**.
2. A 900-second dual-focused Gurobi run improved our reproducible full-model lower
   bound to **10905.7397762548**, reducing the gap to **1.490076%**.
3. The anonymized MPS was decomposed into exactly **400 article-flow networks** and
   **8 truck-flow networks** plus a coupling layer.
4. With all truck-network integers fixed, all **452,077 article-network integer
   variables were jointly reoptimized** and the incumbent was proved optimal for
   that partition.
5. With a strict `1e-5` improvement cutoff, no improving solution exists whose
   1,728 small-domain truck decisions have categorical Hamming distance at most two
   from the incumbent. This was confirmed with `DualReductions=0`,
   `FeasibilityTol=1e-9`, and `IntFeasTol=1e-9`.

These are conditional/local optimality statements, not a global proof. Any globally
better solution must make a larger coordinated change to the truck schedule and
simultaneously reroute article flows.

## Benchmark and external state

The [MIPLIB instance page](https://miplib.zib.de/instance_details_shs1042.html) still
lists the instance as open. It describes joint online truck scheduling and inventory
management for multiple warehouses and reports:

- 467,589 variables and 133,377 rows;
- 864 binary, 464,295 general integer, and 2,430 continuous variables;
- public objective **11070.7015802402**.

The primary [case-study paper](https://optimization-online.org/wp-content/uploads/2005/01/1051.pdf)
shows that the model couples time-discretized truck-flow networks, one pallet-flow
network per article, loading/unloading and truck-capacity constraints, and convex
piecewise-linear inventory-quality costs.

A 2025 [Smoothie Phase I report](https://optimization-online.org/wp-content/uploads/2025/10/Smoothie-PhaseI.pdf)
reports primal **11070.702**, dual **11067.84**, and gap **0.0258%** for `shs1042`.
That run used 25 concurrent single-thread Gurobi/Xpress workers, 512 GB or more of RAM,
and a 12-hour limit. The authors explicitly caution that their dual bounds were not
independently verified. Therefore 11067.84 is important evidence and a target, but it
is not presented here as our bound or as a certified proof.

## Public-solution repair

Direct evaluation of the public solution reproduced small numerical violations:

- maximum bound violation: `6.5101e-7`;
- maximum integrality violation: `6.5101e-7` across 40 integer variables;
- maximum row violation: `6.5101e-7`;
- no violation above `1e-6`.

Rounding those 40 integer values produces a full solution with:

- objective **11070.701661603372**;
- zero bound and integrality violation;
- maximum row violation `1.8858e-11`;
- zero row violations above `1e-9`.

The repaired objective is `8.14e-5` worse than the tolerance-feasible MIPLIB value,
so this is a numerical repair, not a primal improvement.

## Recovered block structure

Connecting variables through equality rows of degree at most 20 recovers 408
components:

- 400 article components, normally 1,124--1,128 variables each, with nine slightly
  larger special components;
- 8 truck components: six around 849--853 variables and two of size 3,988;
- a remaining high-degree coupling layer containing capacity and aggregate linking
  rows.

All 1,728 original small-domain integer variables belong to the truck components:

- 864 variables with domain `[0,1]`;
- 864 variables with domain `[0,2]`.

This matches the model interpretation: article flows are conditionally easy, while
the small-domain truck decisions define the difficult shared schedule.

## Primal and neighborhood experiments

### Single-network neighborhoods

Every one of the 408 components was opened while all other integer variables were
fixed. The first pass used Gurobi's default relative-gap tolerance; 81 article
subproblems still had a lower-bound difference up to about 1.095 and were therefore
not accepted as exact evidence. Those 81 were rerun with `MIPGap=1e-9`.

Final result: all 408 single-network neighborhoods close at the incumbent to numerical
precision; no improvement larger than `1e-7` exists in any single component.

### Multi-network neighborhoods

Fifty-seven combined neighborhoods were rerun with `MIPGap=1e-9`, including:

- pairs of the five initially most promising article components;
- each such article component plus one truck component;
- each such article component plus all eight truck components;
- all five article components together;
- all five article components plus all eight truck components.

The largest neighborhood opened 18,711 integer variables. All 57 closed at the
incumbent at the root node, with no improvement.

### LP-guided RINS neighborhood

A plain-LP/incumbent comparison opened every integer variable on which the two
solutions disagreed and fixed the rest:

- integer variables opened: 11,158;
- integer variables fixed: 454,001;
- fractional integer variables in the plain LP: 2,384.

With `MIPGap=1e-9`, this sub-MIP closed at the incumbent at the root. The plain LP
objective is weaker than Gurobi's MIP root because MIP presolve uses integrality to
strengthen the formulation; the experiment is still a valid exact neighborhood test.

### All articles free, all trucks fixed

This is the strongest primal structural result. All 13,082 truck-component integer
variables were fixed to the incumbent and all 452,077 article-component integers were
opened simultaneously. Gurobi reduced the model and proved at the root:

- candidate: **11070.7016616036** (numerically the incumbent);
- bound: **11070.7016616034**;
- gap: approximately `1.8e-14`;
- status: `OPTIMAL` with `MIPGap=1e-9`.

Thus no reallocation or exchange among the 400 articles improves the solution while
the full truck plan is fixed.

### Truck-schedule local branching

The 864 ternary `[0,2]` truck variables were represented by one-hot binaries, and the
864 `[0,1]` truck variables were promoted to explicit binaries. A categorical Hamming
distance was then imposed on these 1,728 decisions while every other original variable
remained free. The model also required an objective at least `1e-5` better than the
incumbent.

For numerical rigor the confirmation runs used `FeasibilityTol=1e-9`,
`IntFeasTol=1e-9`, `MIPGap=1e-9`, and `DualReductions=0`.

- Distance 0: `INFEASIBLE` at the root in 7.67 seconds.
- Distance 1--2: `INFEASIBLE` after 79 nodes in 308.51 seconds.

Therefore no solution improving the incumbent by at least `1e-5` exists within
categorical Hamming distance two of its small-domain truck schedule. A better solution,
if one exists, must change at least three such truck decisions.

## Full-model dual experiments

All full-model runs used the repaired incumbent.

| Solver/configuration | Time | Best lower bound | Gap | Outcome |
|---|---:|---:|---:|---|
| Gurobi, 8 threads, `MIPFocus=3`, `Cuts=2` | 175 s | 10737.5404035 | 3.0094% | baseline dual run |
| Gurobi, 16 threads, `MIPFocus=3`, `Cuts=3` | 900 s | **10905.7397763** | **1.4901%** | best local full-model bound |
| Gurobi race seed 1, 8 threads, `Cuts=2` | 600 s | 10857.4575975 | 1.9262% | no improvement over best |
| Gurobi race seed 7, `Symmetry=2`, 8 threads | 600 s | 10855.9151071 | 1.9401% | no benefit from forced symmetry |
| One-hot small-domain extension, 16 threads | 240 s | 10676.7173028 | 3.5588% | valid but weaker at cutoff |
| COPT 8.0.3 default | about 208 s | 10459.9650629 | -- | weaker root processing |

The 900-second Gurobi run never left the root. It used 512,664 simplex iterations and
generated primarily flow-cover cuts (1,219), followed by MIR (387), strong-CG (80),
zero-half (60), and implied-bound cuts (52). The lower bound continued to rise until
the time limit, showing that long root separation is productive on this instance.

The two-worker parameter race did not beat the single 16-thread long run. This does
not contradict Smoothie: Smoothie used 25 workers, two commercial solvers, dynamic
restarts, shared incumbents/no-goods, and a 12-hour horizon.

## What is proved and what is not

Proved or directly checked here:

- the repaired incumbent is strictly feasible to the reported tolerances;
- no single recovered network improves the incumbent by more than `1e-7`;
- none of the 57 tested multi-network neighborhoods improves it;
- no LP-guided 11,158-integer RINS move improves it;
- with all truck integers fixed, joint reoptimization of all article integers cannot
  improve it;
- no improvement of at least `1e-5` exists when at most two of the 1,728 small-domain
  truck decisions change.

Not proved:

- global optimality of 11070.7016616034;
- impossibility of a coordinated truck move at Hamming distance three or larger;
- independent validity of the Smoothie dual bound 11067.84;
- a full-model lower bound stronger than our 10905.7397763.

## Research conclusion and next route

The incumbent appears exceptionally strong. Large generic primal searches, exact
single- and multi-component neighborhoods, LP-guided RINS, full joint article
reoptimization, and truck-radius-two local branching all failed to improve it. The
remaining difficulty is not article routing conditional on a truck plan; it is selecting
a globally different truck schedule and coordinating the resulting changes across many
articles.

The most defensible next algorithmic direction is a truck-master decomposition:

1. use the 1,728 small-domain truck variables as the master schedule;
2. solve the 400 article networks conditionally as subproblems;
3. add Benders/Lagrangian or logic-based no-good cuts to the truck master;
4. expand local-branching radii from 2 to 4, 8, and beyond only when the smaller radius
   is certified;
5. run a longer multi-seed/multi-solver portfolio if comparable compute is available.

This mirrors the actual mathematical bottleneck and the successful design ideas in the
Smoothie report more closely than another short generic MIP run.

## Reproduction artifacts

Key scripts:

- `scripts/repair_public_solution.py`
- `scripts/analyze_decomposition.py`
- `scripts/component_neighborhood_search.py`
- `scripts/multi_component_neighborhood_search.py`
- `scripts/rins_submip.py`
- `scripts/partition_neighborhood_search.py`
- `scripts/small_domain_extension_probe.py`
- `scripts/truck_schedule_local_branching.py`

Key results:

- `solutions/shs1042-rounded.sol.gz`
- `artifacts/decomposition_analysis.json`
- `artifacts/component_neighborhood_strict_retry.json`
- `artifacts/multi_component_neighborhood_search_strict.json`
- `artifacts/rins_analysis_corrected_1s.json`
- `artifacts/partition_articles_free_180s.json`
- `artifacts/gurobi_aggressive_900s.json` and `logs/gurobi_aggressive_900s.log`
- `artifacts/gurobi_race_seed1_600s.json` and `logs/gurobi_race_seed1_600s.log`
- `artifacts/gurobi_race_seed7_sym2_600s.json` and `logs/gurobi_race_seed7_sym2_600s.log`
- `artifacts/small_domain_onehot_240s.json` and `logs/small_domain_onehot_240s.log`
- `artifacts/truck_schedule_radius0_tight_confirm.json` and `logs/truck_schedule_radius0_tight_confirm.log`
- `artifacts/truck_schedule_radius2_tight_confirm.json` and `logs/truck_schedule_radius2_tight_confirm.log`

Input SHA-256 hashes:

- MPS: `5d66ae49b1b1916c9b6086419cc3d90e80e8cd2d00365e98f62c2ebe2da885f6`
- public solution: `1af00631835e8435ba3462ff14d9701a3acafade9036c534080522ea470bb16e`
- strict repaired solution: `e8a010307bf5f926afbac38664a0f409df03b9e65d0e5ea90abfcd92e6682a53`
