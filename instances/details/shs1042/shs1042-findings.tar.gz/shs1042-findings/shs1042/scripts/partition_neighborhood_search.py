from __future__ import annotations

import argparse
import gzip
import json
import time
from collections import defaultdict
from pathlib import Path

import gurobipy as gp
import numpy as np
from gurobipy import GRB


def read_solution(path: Path) -> dict[str, float]:
    opener = gzip.open if path.suffix == ".gz" else open
    values: dict[str, float] = {}
    with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
        for line in handle:
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) >= 2:
                try:
                    values[parts[0]] = float(parts[1])
                except ValueError:
                    pass
    return values


def write_solution(path: Path, variables, values: np.ndarray, objective: float) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "wt", encoding="utf-8", newline="\n") as handle:
        handle.write(f"# Objective value = {objective:.17g}\n")
        handle.write("# Partition-neighborhood solution for shs1042.\n")
        for var, value in zip(variables, values):
            handle.write(f"{var.VarName} {float(value):.17g}\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", type=Path, required=True)
    parser.add_argument("--solution", type=Path, required=True)
    parser.add_argument("--components", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--best-solution", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--free", choices=("articles", "trucks"), required=True)
    parser.add_argument("--time-limit", type=float, default=300.0)
    parser.add_argument("--threads", type=int, default=16)
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.log.parent.mkdir(parents=True, exist_ok=True)
    wall_started = time.time()
    model = gp.read(str(args.mps))
    variables = model.getVars()
    roots = np.load(args.components)["roots_threshold20"]
    supplied = read_solution(args.solution)
    incumbent = np.asarray([supplied.get(v.VarName, 0.0) for v in variables], dtype=np.float64)
    is_integer = np.asarray(
        [v.VType in (GRB.BINARY, GRB.INTEGER, GRB.SEMIINT) for v in variables], dtype=bool
    )
    incumbent[is_integer] = np.rint(incumbent[is_integer])

    members: dict[int, list[int]] = defaultdict(list)
    for index, root in enumerate(roots):
        members[int(root)].append(index)
    component_minimum = {root: min(indices) for root, indices in members.items() if len(indices) > 1}
    truck_roots = {root for root, minimum in component_minimum.items() if minimum >= 334876}
    article_roots = set(component_minimum) - truck_roots
    free_roots = article_roots if args.free == "articles" else truck_roots
    free_mask = np.asarray([int(root) in free_roots for root in roots], dtype=bool) & is_integer
    fixed_indices = np.flatnonzero(is_integer & ~free_mask)
    fixed_vars = [variables[int(i)] for i in fixed_indices]
    fixed_values = incumbent[fixed_indices].tolist()
    model.setAttr("LB", fixed_vars, fixed_values)
    model.setAttr("UB", fixed_vars, fixed_values)
    model.setAttr("Start", variables, incumbent.tolist())

    model.Params.TimeLimit = args.time_limit
    model.Params.Threads = args.threads
    model.Params.Presolve = 2
    model.Params.MIPFocus = 1
    model.Params.Heuristics = 0.5
    model.Params.NoRelHeurTime = min(30.0, args.time_limit / 6.0)
    model.Params.Cuts = 2
    model.Params.MIPGap = 1e-9
    model.Params.LogFile = str(args.log)
    model.optimize()

    candidate = float(model.ObjVal) if model.SolCount else None
    if model.SolCount:
        values = np.asarray(model.getAttr("X", variables), dtype=np.float64)
        values[is_integer] = np.rint(values[is_integer])
        write_solution(args.best_solution, variables, values, candidate)
    incumbent_objective = float(sum(v.Obj * value for v, value in zip(variables, incumbent)))
    report = {
        "instance": model.ModelName,
        "method": f"partition neighborhood with {args.free} integer networks free",
        "article_components": len(article_roots),
        "truck_components": len(truck_roots),
        "integer_variables_opened": int(free_mask.sum()),
        "integer_variables_fixed": int(len(fixed_indices)),
        "incumbent_objective": incumbent_objective,
        "candidate_objective": candidate,
        "improvement": None if candidate is None else incumbent_objective - candidate,
        "status": int(model.Status),
        "best_bound": float(model.ObjBound) if model.IsMIP else None,
        "relative_gap": float(model.MIPGap) if model.IsMIP and model.SolCount else None,
        "node_count": float(model.NodeCount) if model.IsMIP else None,
        "solver_runtime_seconds": float(model.Runtime),
        "wall_runtime_seconds": time.time() - wall_started,
        "time_limit": args.time_limit,
        "threads": args.threads,
    }
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
