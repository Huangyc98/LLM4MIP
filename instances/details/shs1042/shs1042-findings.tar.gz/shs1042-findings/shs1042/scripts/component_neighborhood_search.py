from __future__ import annotations

import argparse
import gzip
import json
import math
import time
from collections import defaultdict
from pathlib import Path

import gurobipy as gp
import numpy as np
from gurobipy import GRB


def read_values(path: Path) -> dict[str, float]:
    opener = gzip.open if path.suffix == ".gz" else open
    result = {}
    with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
        for line in handle:
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) >= 2:
                try:
                    result[parts[0]] = float(parts[1])
                except ValueError:
                    pass
    return result


def write_solution(path: Path, variables, values: np.ndarray, objective: float) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "wt", encoding="utf-8", newline="\n") as handle:
        handle.write(f"# Objective value = {objective:.17g}\n")
        handle.write("# Component-neighborhood search solution.\n")
        for var, value in zip(variables, values):
            handle.write(f"{var.VarName} {float(value):.17g}\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", type=Path, required=True)
    parser.add_argument("--solution", type=Path, required=True)
    parser.add_argument("--components", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--best-solution", type=Path, required=True)
    parser.add_argument("--article-count", type=int, default=12)
    parser.add_argument("--time-per-neighborhood", type=float, default=5.0)
    parser.add_argument("--start-order", type=int, default=1)
    parser.add_argument("--stop-order", type=int)
    parser.add_argument(
        "--retry-report",
        type=Path,
        action="append",
        help="Only retry orders whose previous incumbent-minus-bound gap exceeds 1e-7.",
    )
    args = parser.parse_args()

    started = time.time()
    model = gp.read(str(args.mps))
    model.Params.OutputFlag = 0
    model.Params.Threads = 8
    model.Params.Presolve = 2
    model.Params.MIPFocus = 1
    model.Params.Heuristics = 0.25
    model.Params.MIPGap = 1e-9

    variables = model.getVars()
    nvars = len(variables)
    roots = np.load(args.components)["roots_threshold20"]
    if len(roots) != nvars:
        raise ValueError("component array does not match model")
    supplied = read_values(args.solution)
    current = np.asarray([supplied.get(v.VarName, 0.0) for v in variables], dtype=np.float64)
    original_lb = np.asarray([v.LB for v in variables], dtype=np.float64)
    original_ub = np.asarray([v.UB for v in variables], dtype=np.float64)
    is_integer = np.asarray(
        [v.VType in (GRB.BINARY, GRB.INTEGER, GRB.SEMIINT) for v in variables], dtype=bool
    )
    current[is_integer] = np.rint(current[is_integer])
    obj = np.asarray([v.Obj for v in variables], dtype=np.float64)

    members = defaultdict(list)
    for idx, root in enumerate(roots):
        members[int(root)].append(idx)
    component_rows = []
    for root, indices_list in members.items():
        indices = np.asarray(indices_list, dtype=np.int32)
        if len(indices) <= 1:
            continue
        component_rows.append(
            {
                "root": root,
                "indices": indices,
                "min_index": int(indices.min()),
                "size": int(len(indices)),
                "integer_count": int(is_integer[indices].sum()),
                "objective_contribution": float(np.dot(obj[indices], current[indices])),
            }
        )

    article_components = [row for row in component_rows if row["min_index"] < 334876]
    truck_components = [row for row in component_rows if row["min_index"] >= 334876]
    article_components.sort(key=lambda row: row["objective_contribution"], reverse=True)
    truck_components.sort(key=lambda row: row["min_index"])
    selected_all = article_components[: args.article_count] + truck_components
    stop_order = args.stop_order if args.stop_order is not None else len(selected_all)
    selected_with_orders = list(enumerate(selected_all, 1))[args.start_order - 1 : stop_order]
    retry_orders = None
    retry_gap_by_order = None
    if args.retry_report:
        retry_orders = set()
        retry_gap_by_order = {}
        for report_path in args.retry_report:
            previous = json.loads(report_path.read_text(encoding="utf-8"))
            for attempt in previous["attempts"]:
                if attempt.get("bound") is not None and attempt["before"] - attempt["bound"] > 1e-7:
                    previous_order = int(attempt["order"])
                    previous_gap = float(attempt["before"] - attempt["bound"])
                    retry_orders.add(previous_order)
                    retry_gap_by_order[previous_order] = max(
                        previous_gap, retry_gap_by_order.get(previous_order, 0.0)
                    )
        selected_with_orders = [item for item in selected_with_orders if item[0] in retry_orders]
        selected_with_orders.sort(key=lambda item: retry_gap_by_order[item[0]], reverse=True)

    # Start from a fixed-integer LP. This also reoptimizes the continuous variables.
    fixed_lb = original_lb.copy()
    fixed_ub = original_ub.copy()
    fixed_lb[is_integer] = current[is_integer]
    fixed_ub[is_integer] = current[is_integer]
    model.setAttr("LB", variables, fixed_lb.tolist())
    model.setAttr("UB", variables, fixed_ub.tolist())
    model.Params.TimeLimit = 30.0
    model.optimize()
    if model.SolCount == 0:
        raise RuntimeError("rounded incumbent is infeasible when integers are fixed")
    current = np.asarray(model.getAttr("X", variables), dtype=np.float64)
    incumbent = float(model.ObjVal)
    initial_fixed_lp = incumbent

    attempts = []
    for order, row in selected_with_orders:
        indices = row["indices"]
        integer_indices = indices[is_integer[indices]]
        if len(integer_indices) == 0:
            continue
        vars_to_open = [variables[int(i)] for i in integer_indices]
        model.setAttr("LB", vars_to_open, original_lb[integer_indices].tolist())
        model.setAttr("UB", vars_to_open, original_ub[integer_indices].tolist())
        model.setAttr("Start", variables, current.tolist())
        model.Params.TimeLimit = args.time_per_neighborhood
        before = incumbent
        run_started = time.time()
        model.optimize()
        accepted = False
        candidate = None
        bound = None
        if model.IsMIP:
            bound = float(model.ObjBound)
        if model.SolCount:
            candidate = float(model.ObjVal)
            if candidate < incumbent - 1e-7:
                current = np.asarray(model.getAttr("X", variables), dtype=np.float64)
                current[is_integer] = np.rint(current[is_integer])
                incumbent = candidate
                accepted = True
        model.setAttr("LB", vars_to_open, current[integer_indices].tolist())
        model.setAttr("UB", vars_to_open, current[integer_indices].tolist())
        attempts.append(
            {
                "order": order,
                "root": row["root"],
                "min_index": row["min_index"],
                "component_size": row["size"],
                "integer_variables_opened": int(len(integer_indices)),
                "original_objective_contribution": row["objective_contribution"],
                "before": before,
                "candidate": candidate,
                "bound": bound,
                "accepted": accepted,
                "improvement": before - incumbent,
                "status": int(model.Status),
                "nodes": float(model.NodeCount) if model.IsMIP else 0.0,
                "runtime_seconds": time.time() - run_started,
            }
        )
        print(
            f"{order}/{len(selected_all)} min={row['min_index']} size={row['size']} "
            f"before={before:.12f} candidate={candidate} accepted={accepted}"
        )

    # One final LP reoptimization with all integer values fixed to the best neighborhood result.
    model.Params.TimeLimit = 30.0
    model.optimize()
    if model.SolCount:
        final_values = np.asarray(model.getAttr("X", variables), dtype=np.float64)
        final_values[is_integer] = np.rint(final_values[is_integer])
        final_objective = float(model.ObjVal)
        if final_objective <= incumbent + 1e-7:
            current = final_values
            incumbent = final_objective

    write_solution(args.best_solution, variables, current, incumbent)
    report = {
        "instance": model.ModelName,
        "method": "one-component-at-a-time exact MIP neighborhoods",
        "initial_fixed_integer_lp_objective": initial_fixed_lp,
        "final_objective": incumbent,
        "total_improvement": initial_fixed_lp - incumbent,
        "selected_article_components": args.article_count,
        "selected_truck_components": len(truck_components),
        "total_selected_components": len(selected_all),
        "start_order": args.start_order,
        "stop_order": stop_order,
        "retry_orders": sorted(retry_orders) if retry_orders is not None else None,
        "time_per_neighborhood": args.time_per_neighborhood,
        "attempts": attempts,
        "accepted_improvements": sum(item["accepted"] for item in attempts),
        "wall_runtime_seconds": time.time() - started,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
