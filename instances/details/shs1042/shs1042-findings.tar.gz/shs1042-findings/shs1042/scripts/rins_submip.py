from __future__ import annotations

import argparse
import gzip
import json
import math
import time
from pathlib import Path

import gurobipy as gp
import numpy as np
from gurobipy import GRB


def read_solution(path: Path) -> dict[str, float]:
    opener = gzip.open if path.suffix == ".gz" else open
    values: dict[str, float] = {}
    with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
        for line in handle:
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) < 2:
                continue
            try:
                values[parts[0]] = float(parts[1])
            except ValueError:
                pass
    return values


def write_solution(path: Path, variables, values: np.ndarray, objective: float) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "wt", encoding="utf-8", newline="\n") as handle:
        handle.write(f"# Objective value = {objective:.17g}\n")
        handle.write("# RINS sub-MIP solution for shs1042.\n")
        for var, value in zip(variables, values):
            handle.write(f"{var.VarName} {float(value):.17g}\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", type=Path, required=True)
    parser.add_argument("--solution", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--best-solution", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--time-limit", type=float, default=240.0)
    parser.add_argument("--threads", type=int, default=16)
    parser.add_argument("--agreement-tolerance", type=float, default=1e-6)
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.log.parent.mkdir(parents=True, exist_ok=True)
    wall_started = time.time()

    model = gp.read(str(args.mps))
    variables = model.getVars()
    supplied = read_solution(args.solution)
    incumbent = np.asarray([supplied.get(v.VarName, 0.0) for v in variables], dtype=np.float64)
    is_integer = np.asarray(
        [v.VType in (GRB.BINARY, GRB.INTEGER, GRB.SEMIINT) for v in variables], dtype=bool
    )
    incumbent[is_integer] = np.rint(incumbent[is_integer])

    # Gurobi requires pending model changes to be synchronized before relax();
    # otherwise the copied LP can omit data even immediately after read().
    model.update()
    relaxation = model.relax()
    relaxation.Params.OutputFlag = 0
    relaxation.Params.Threads = args.threads
    relaxation.Params.Method = 2
    relaxation.optimize()
    if relaxation.Status != GRB.OPTIMAL:
        raise RuntimeError(f"LP relaxation status {relaxation.Status}, expected OPTIMAL")
    lp_values = np.asarray(relaxation.getAttr("X", relaxation.getVars()), dtype=np.float64)
    lp_objective = float(relaxation.ObjVal)

    integer_indices = np.flatnonzero(is_integer)
    deviations = np.abs(lp_values[integer_indices] - incumbent[integer_indices])
    open_mask = deviations > args.agreement_tolerance
    open_integer_indices = integer_indices[open_mask]
    fixed_integer_indices = integer_indices[~open_mask]
    fractional_mask = np.abs(lp_values[integer_indices] - np.rint(lp_values[integer_indices])) > 1e-6

    fixed_vars = [variables[int(i)] for i in fixed_integer_indices]
    fixed_values = incumbent[fixed_integer_indices].tolist()
    model.setAttr("LB", fixed_vars, fixed_values)
    model.setAttr("UB", fixed_vars, fixed_values)
    model.setAttr("Start", variables, incumbent.tolist())
    model.Params.TimeLimit = args.time_limit
    model.Params.Threads = args.threads
    model.Params.Presolve = 2
    model.Params.MIPFocus = 1
    model.Params.Heuristics = 0.35
    model.Params.Cuts = 2
    model.Params.MIPGap = 1e-9
    model.Params.ImproveStartTime = min(30.0, max(1.0, args.time_limit / 8.0))
    model.Params.LogFile = str(args.log)
    model.optimize()

    candidate = float(model.ObjVal) if model.SolCount else None
    candidate_values = (
        np.asarray(model.getAttr("X", variables), dtype=np.float64) if model.SolCount else None
    )
    if candidate_values is not None:
        candidate_values[is_integer] = np.rint(candidate_values[is_integer])
        write_solution(args.best_solution, variables, candidate_values, candidate)

    incumbent_objective = float(sum(v.Obj * value for v, value in zip(variables, incumbent)))
    report = {
        "instance": model.ModelName,
        "method": "RINS sub-MIP: fix integer variables where root LP agrees with incumbent",
        "agreement_tolerance": args.agreement_tolerance,
        "root_lp_objective": lp_objective,
        "integer_variables": int(is_integer.sum()),
        "fractional_integer_variables_at_root_lp": int(fractional_mask.sum()),
        "integer_variables_opened": int(len(open_integer_indices)),
        "integer_variables_fixed": int(len(fixed_integer_indices)),
        "maximum_lp_incumbent_deviation": float(deviations.max()),
        "incumbent_objective": incumbent_objective,
        "candidate_objective": candidate,
        "improvement": None if candidate is None else incumbent_objective - candidate,
        "status": int(model.Status),
        "status_name": {
            GRB.OPTIMAL: "OPTIMAL",
            GRB.INFEASIBLE: "INFEASIBLE",
            GRB.TIME_LIMIT: "TIME_LIMIT",
            GRB.NODE_LIMIT: "NODE_LIMIT",
            GRB.INTERRUPTED: "INTERRUPTED",
        }.get(model.Status, "OTHER"),
        "best_bound": float(model.ObjBound) if model.IsMIP else None,
        "relative_gap": float(model.MIPGap) if model.IsMIP and model.SolCount else None,
        "node_count": float(model.NodeCount) if model.IsMIP else None,
        "solver_runtime_seconds": float(model.Runtime),
        "wall_runtime_seconds": time.time() - wall_started,
        "threads": args.threads,
        "time_limit": args.time_limit,
    }
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
