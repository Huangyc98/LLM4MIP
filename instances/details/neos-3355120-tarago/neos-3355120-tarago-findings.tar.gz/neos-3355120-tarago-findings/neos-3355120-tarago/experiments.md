# Experiment ledger

This file is generated from `runs/*/result.json` by the controller.

| Run | Solver | Status | Primal | Dual | Gap | Verified | Runtime (s) |
|---|---|---|---:|---:|---:|---|---:|
| `copt-20260903-174958-adfd4169` | copt | TIMEOUT | 1e+30 | -11849289.3051982 | 1e+30 | not checked | 300.029963970184 |
| `copt-20260903-191947-2f3002ee` | copt | TIMEOUT | -11009399.7280333 | -11440065.4646254 | 0.0376453909222701 | yes @ 1e-9 | 8400.06414198875 |
| `custom-20260903-181644-ca9e4b8b` | custom-python | ERROR | — | — | — | not checked | 0.874560832977295 |
| `gurobi-20260903-174954-c7cc3629` | gurobi | TIME_LIMIT | -10092857.3563375 | -11642746.7972474 | 0.153562998682102 | yes @ 1e-9 | 300.067890882492 |
| `gurobi-20260903-181838-81b619e2` | gurobi | TIME_LIMIT | -11004906.2579962 | -11308517.7463384 | 0.0275887391700026 | yes @ 1e-9 | 3600.20454192162 |
| `gurobi-20260903-191942-b870c1ab` | gurobi | TIME_LIMIT | -11110906.68929 | -11123832.6769704 | 0.00116336029469853 | yes @ 1e-9 | 8400.13036084175 |
