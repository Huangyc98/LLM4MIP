# neos-3355120-tarago Experiment Archive

2026-09-14 independent dual-bound review: [adopted bound, proof chain, checks, and limitations](../../docs/dual-bound-audit-2026-09-14/cases/neos-3355120-tarago.zh.md). Reviewed lower bound: **approximately -11123832.676970437**. This review distinguishes exact, literature, and numerical evidence; historical statements below remain dated records.

## Result at a glance

This archive records a **partial feasible result**, not a solved instance.

| Item | Value |
|---|---:|
| Objective sense | Minimize |
| Best tolerance-verified primal bound | -11,110,906.689290017 |
| Best dual bound | -11,123,832.676970437 |
| Combined relative gap | 0.001163360294698528 (about 0.116336%) |
| Feasibility check | Passed controller Decimal checks at tolerance 1e-9 |
| Optimality proved | No |
| Infeasibility proved | No |
| Best run | `gurobi-20260903-191942-b870c1ab` |
| Best-run termination | `TIME_LIMIT` |

The incumbent is solver-accepted and tolerance-verified, but it is not backed by an exact certificate. A time limit is not an optimal or infeasible status.

## Experiment outline

### Generic-solver baseline

The controller first ran short, approximately 300-second COPT and Gurobi baselines. COPT found no incumbent during its short run. Gurobi found a tolerance-verified incumbent of -10,092,857.3563375. Both runs ended at their time limits.

### Problem-specific research

The selected custom method used the model's equality structure: independently parse the MPS model, group integer variables by equality-coefficient signature, and test equality-preserving exchanges with incremental row checks. The intent was to progress from pair exchanges to short equality-nullspace cycles or block-fixed exact subproblems.

The custom Python run ended with `ERROR` after about 0.875 seconds and produced no accepted bound or verified solution. This is an implementation failure, not evidence that the mathematical neighborhood is ineffective. The custom source reference and design rationale are preserved in the run metadata and `method_selection.md`; the compressed experiment table does not expose the exact source filename, so it is not guessed here.

### Longer generic-solver runs

Longer Gurobi and COPT runs followed the custom attempt. The final 8,400-second Gurobi run found the best verified incumbent and best dual bound, but terminated with `TIME_LIMIT`. No strict optimal run and no strict infeasible run occurred.

## Run status summary

- COPT baseline: `TIMEOUT`, no incumbent, 300.030 seconds.
- Gurobi baseline: `TIME_LIMIT`, verified incumbent, 300.068 seconds.
- Custom Python method: `ERROR`, no result, 0.875 seconds.
- Gurobi follow-up: `TIME_LIMIT`, verified incumbent, 3,600.205 seconds.
- Gurobi extended run: `TIME_LIMIT`, best verified incumbent and dual, 8,400.130 seconds.
- COPT extended run: `TIMEOUT`, verified incumbent, 8,400.064 seconds.

## Reproducibility notes

Execution was controller managed. Solver time limits, threads, and output paths were controlled externally. Custom code ran CPU-only in an isolated bubblewrap sandbox with no network, read-only model/tool inputs, a private writable output directory, and controller-enforced time, memory, file-size, and thread limits.

The reporting summaries identify the stacks as Gurobi, COPT, and custom Python. Exact host hardware, OS build, solver/tool version strings, numeric sandbox memory and file-size caps, complete nondefault parameter dictionaries, and explicit random seeds are not exposed in the compressed archival summary. They are therefore recorded as unavailable here rather than inferred. Authoritative details, where captured, remain in `experiments.json` and per-run records. CaDiCaL and DRAT-trim were configured capabilities but were not used to produce a proof.

## Archive contents

- `final_report.md` — detailed outcome, methods, all termination statuses, reproducibility limitations, and recommendation.
- `result.json` — controller-managed final machine-readable result.
- `experiments.json` — controller-managed machine-readable run ledger and parameters.
- `experiments.md` — controller-generated run table.
- `reporting_bundle.json` — compressed reporting provenance.
- `strategy.md` — solving strategy.
- `method_selection.md` — custom-method selection and implementation record.

## Recommended continuation

First repair the custom method's immediate failure and make it emit deterministic parser, signature-group, and row-activity diagnostics. Then test equality-preserving pair exchanges from the best verified incumbent, expand useful moves to short nullspace cycles or block-fixed exact subproblems, independently verify improvements, and only afterward run a proof-oriented solver continuation.

For full details and the exact claim boundary, see `final_report.md`.
