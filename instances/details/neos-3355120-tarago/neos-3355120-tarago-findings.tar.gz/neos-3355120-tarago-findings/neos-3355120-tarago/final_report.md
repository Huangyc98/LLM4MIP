# Final Report: neos-3355120-tarago

## 1. Outcome

This experiment produced a **partial feasible result** for the minimization instance `neos-3355120-tarago`.

- Best tolerance-verified primal bound: **-11,110,906.689290017**
- Best dual bound: **-11,123,832.676970437**
- Absolute primal-dual separation: **12,925.98768042028**
- Combined relative gap: **0.001163360294698528** (about **0.116336%**)
- Best run: `gurobi-20260903-191942-b870c1ab`
- Verification: the incumbent passed the controller's Decimal-based feasibility checks at tolerance **1e-9**
- Final classification: **feasible, verified at tolerance**
- Proof status: **optimality was not proved and infeasibility was not proved**

Tolerance verification is not an exact feasibility certificate. No run returned a strict optimal or strict infeasible status. Every generic-solver run ended because of a time limit, and the custom Python run ended with an error. Accordingly, this report makes neither an optimality claim nor an infeasibility claim.

## 2. Bound interpretation

The objective is minimized. The best verified incumbent gives the upper/primal bound, while the solver's best bound gives the lower/dual bound:

```text
-11,123,832.676970437 <= optimum <= -11,110,906.689290017
```

The reported 0.001163360294698528 gap is the controller's combined relative gap using the best verified primal and best dual bounds. It must not be interpreted as a proof of optimality.

## 3. Complete run ledger and termination review

| Run | Role | Solver/tool | Termination | Primal | Dual | Gap | Verification | Runtime (s) |
|---|---|---|---|---:|---:|---:|---|---:|
| `copt-20260903-174958-adfd4169` | Short generic baseline | COPT | `TIMEOUT` | No incumbent (`1e30` sentinel) | -11,849,289.305198202 | Not meaningful (`1e30` sentinel) | Not checked | 300.029964 |
| `gurobi-20260903-174954-c7cc3629` | Short generic baseline | Gurobi | `TIME_LIMIT` | -10,092,857.3563375 | -11,642,746.7972474 | 0.153562998682102 | Yes, tolerance 1e-9 | 300.067891 |
| `custom-20260903-181644-ca9e4b8b` | Structure-specific research | Custom Python | `ERROR` | — | — | — | Not checked | 0.874561 |
| `gurobi-20260903-181838-81b619e2` | Longer generic-solver follow-up | Gurobi | `TIME_LIMIT` | -11,004,906.2579962 | -11,308,517.7463384 | 0.0275887391700026 | Yes, tolerance 1e-9 | 3,600.204542 |
| `gurobi-20260903-191942-b870c1ab` | Extended generic-solver run | Gurobi | `TIME_LIMIT` | -11,110,906.689290017 | -11,123,832.676970437 | 0.001163360294698528 | Yes, tolerance 1e-9 | 8,400.130361 |
| `copt-20260903-191947-2f3002ee` | Extended generic-solver run | COPT | `TIMEOUT` | -11,009,399.7280333 | -11,440,065.4646254 | 0.0376453909222701 | Yes, tolerance 1e-9 | 8,400.064142 |

The first COPT run found no incumbent before its limit; this is not evidence of infeasibility. Likewise, none of the five solver time-limit statuses is an optimality or infeasibility certificate. The custom `ERROR` status provides no mathematical claim.

## 4. Short generic-solver baseline

The controller launched a short two-solver baseline before the structure-specific method:

- COPT: approximately 300 seconds; no incumbent; dual bound -11,849,289.305198202.
- Gurobi: approximately 300 seconds; tolerance-verified incumbent -10,092,857.3563375 and dual bound -11,642,746.7972474.

These runs established that the model was computationally difficult but that Gurobi could quickly obtain a feasible anchor. The baseline used the controller-managed execution interface. Time limits, threads, and result/log paths were controller controlled rather than embedded in source code. The compressed reporting materials do not expose additional nondefault parameter values, so none are invented here.

## 5. Problem-specific research method

### 5.1 Design rationale

The selected solver-independent method treated the integer model through its linear row structure rather than as a parameter-tuning exercise. Its intended workflow was:

1. Preserve the already tolerance-verified incumbent as a feasibility anchor.
2. Parse the MPS model independently.
3. Group integer variables by equality-row coefficient signatures.
4. Search equality-preserving pair exchanges.
5. Check changed rows incrementally so that candidate moves preserve the linear constraints and bounds.
6. Measure signature-group sizes, variable coverage, feasible-exchange density, and objective improvement.
7. If pair exchanges succeeded, extend the neighborhood to short equality-nullspace cycles and pass an improved verified incumbent to a solver for bound closure.
8. If pair exchanges failed, use row-variable incidence information to form block-fixed exact subproblems.

This is materially different from adjusting generic MIP parameters: it derives candidate moves from the model's equality structure and checks their feasibility independently.

### 5.2 Execution result

The structure-specific custom Python run was `custom-20260903-181644-ca9e4b8b`. It terminated with `ERROR` after 0.874560832977295 seconds. It produced no accepted primal or dual bound and no verified solution. Therefore, the custom method did not improve the baseline, and no performance conclusion about the proposed neighborhood itself can be drawn from this failed execution.

The exact custom source path is preserved by the run metadata and archived method-selection material; it should be read together with this report. The compressed experiment table available during reporting identifies the runtime as `custom-python` but does not expose the source filename, so this report does not guess one.

### 5.3 Most informative negative result

The useful negative result is operational rather than mathematical: the first implementation failed before it could report neighborhood statistics or candidate quality. It did not establish that equality-signature exchanges are ineffective. A future experiment should first reproduce and repair that early error under a very small diagnostic case, emit parser and row-check summaries, and only then devote time to neighborhood search.

## 6. Longer solver follow-up

After the required custom attempt, longer generic-solver runs materially improved the incumbent and bound:

- The 3,600-second Gurobi run reduced the reported gap to about 2.759%.
- The extended COPT run ended with a tolerance-verified incumbent and a 3.765% reported gap.
- The extended Gurobi run obtained both the best verified incumbent and the best dual bound, reducing the combined gap to about 0.1163%.

These improvements are valuable, but the final Gurobi status remained `TIME_LIMIT`. The near-closed gap is not a proof.

## 7. Reproducibility and execution environment

### 7.1 Machines and sandbox

Runs were performed on the controller-managed experiment machine. The reporting bundle does not expose the host CPU model, operating-system build, physical core count, or RAM quantity; those values are therefore recorded as **not available in the compressed archive summary**, rather than inferred.

Custom execution used the controlled CPU-only bubblewrap sandbox described by the experiment protocol:

- no network access;
- original model, controlled inputs, and requested tools mounted read-only;
- private writable output directory;
- controller-enforced wall-time, memory, file-size, and thread limits;
- Python standard library and C++17 available;
- configured optional tools: CaDiCaL and DRAT-trim.

CaDiCaL and DRAT-trim were capabilities only and were not used to produce a certificate in this experiment. Numerical custom-sandbox memory, file-size, and thread caps are not present in the compressed reporting material, so they cannot be stated reliably.

### 7.2 Solver and tool versions

The experiment used COPT, Gurobi, and a custom Python implementation. Exact COPT, Gurobi, Python, CaDiCaL, and DRAT-trim version strings are not exposed in the compressed reporting bundle or experiment table available during this archival pass. They are therefore marked **not recorded here** rather than fabricated. Where present, authoritative per-run manifests and logs remain the source for exact version strings.

### 7.3 Parameters, limits, and random seeds

The controller controlled solver threads, time limits, and log/result paths. The observed run limits were approximately:

- baseline COPT: 300 seconds;
- baseline Gurobi: 300 seconds;
- first longer Gurobi run: 3,600 seconds;
- extended Gurobi run: 8,400 seconds;
- extended COPT run: 8,400 seconds;
- custom Python attempt: terminated by error after about 0.875 seconds.

No explicit random-seed value or complete nondefault solver parameter dictionary appears in the compressed reporting materials. Thus, random seeds are recorded as **not specified in the reporting summary**, and no unsupported seed or tuning value is claimed. Exact parameter dictionaries, if captured, remain in the controller-managed `experiments.json` and per-run records.

## 8. Archived files and provenance

Controller-managed records:

- `result.json`: final machine-readable result;
- `experiments.json`: complete machine-readable experiment ledger;
- `experiments.md`: generated human-readable run ledger;
- `reporting_bundle.json`: compressed reporting and provenance bundle.

Research and reporting records:

- `strategy.md`: formal-solving strategy;
- `method_selection.md`: rationale and implementation inventory for the custom method;
- `final_report.md`: this report;
- `README.md`: concise archive guide.

Controller-managed ledgers were not overwritten during reporting.

## 9. Recommended next experiment

The next experiment should not begin with another undifferentiated parameter sweep. It should:

1. diagnose the custom Python run's immediate error;
2. add deterministic parser tests and explicit row-activity checks;
3. record equality-signature group counts and candidate-move statistics before optimization;
4. search pair exchanges from the best verified incumbent;
5. extend successful moves to short nullspace cycles or block-fixed exact subproblems;
6. independently verify any improved incumbent at the same or tighter tolerance;
7. use the improved incumbent as a warm start for a controlled proof-oriented solver run.

Because the remaining gap is already about 0.1163%, a repaired structural neighborhood combined with subsequent bound closure is more informative than treating the current feasible result as solved.

## 10. Final claim boundary

The strongest justified statement is:

> A feasible incumbent with objective -11,110,906.689290017 was verified at tolerance 1e-9. The best recorded dual bound is -11,123,832.676970437, leaving a combined relative gap of 0.001163360294698528. No run proved optimality or infeasibility.
