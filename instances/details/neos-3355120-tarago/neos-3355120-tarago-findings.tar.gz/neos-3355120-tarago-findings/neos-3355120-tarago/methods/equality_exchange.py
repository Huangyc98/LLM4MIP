#!/usr/bin/env python3
import argparse, gzip, json, math, os, shlex, sys, time
from collections import defaultdict


def num(s):
    return float(s.replace('D','E').replace('d','e'))


def open_model(path):
    return gzip.open(path, 'rt', encoding='utf-8', errors='replace') if path.endswith('.gz') else open(path, 'r', encoding='utf-8', errors='replace')


def parse_mps(path):
    section = None
    rows = {}
    nrows = []
    cols = defaultdict(dict)
    rhs = defaultdict(float)
    lb = defaultdict(float)
    ub = defaultdict(lambda: float('inf'))
    integer = set()
    in_integer = False
    ranges_seen = False
    with open_model(path) as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith('*'):
                continue
            tok = line.split()
            head = tok[0].upper()
            if head in ('NAME','OBJSENSE','OBJNAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA'):
                section = head
                if head == 'RANGES': ranges_seen = True
                if head == 'ENDATA': break
                continue
            if section == 'ROWS':
                if len(tok) >= 2:
                    sense, name = tok[0].upper(), tok[1]
                    rows[name] = sense
                    if sense == 'N': nrows.append(name)
            elif section == 'COLUMNS':
                if 'MARKER' in line.upper():
                    up = line.upper()
                    if 'INTORG' in up: in_integer = True
                    if 'INTEND' in up: in_integer = False
                    continue
                v = tok[0]
                if in_integer: integer.add(v)
                pairs = tok[1:]
                for i in range(0, len(pairs)-1, 2):
                    r, a = pairs[i], num(pairs[i+1])
                    cols[v][r] = cols[v].get(r, 0.0) + a
            elif section == 'RHS':
                pairs = tok[1:]
                for i in range(0, len(pairs)-1, 2):
                    rhs[pairs[i]] = num(pairs[i+1])
            elif section == 'BOUNDS':
                if len(tok) < 3: continue
                bt, v = tok[0].upper(), tok[2]
                val = num(tok[3]) if len(tok) > 3 else 0.0
                if bt == 'BV':
                    lb[v], ub[v] = 0.0, 1.0; integer.add(v)
                elif bt in ('LI','LO'):
                    lb[v] = val
                    if bt == 'LI': integer.add(v)
                elif bt in ('UI','UP'):
                    ub[v] = val
                    if bt == 'UI': integer.add(v)
                elif bt == 'FX': lb[v] = ub[v] = val
                elif bt == 'FR': lb[v], ub[v] = -float('inf'), float('inf')
                elif bt == 'MI': lb[v] = -float('inf')
                elif bt == 'PL': ub[v] = float('inf')
    if ranges_seen:
        raise RuntimeError('RANGES section is not supported by this test implementation')
    objrow = nrows[0] if nrows else None
    variables = sorted(cols)
    objective = {v: cols[v].get(objrow, 0.0) for v in variables}
    matrix = {v: {r:a for r,a in cols[v].items() if r != objrow and rows.get(r) != 'N'} for v in variables}
    constraints = {r:s for r,s in rows.items() if s != 'N'}
    return variables, constraints, matrix, rhs, lb, ub, integer, objective


def parse_solution(path):
    x = defaultdict(float)
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith('#'): continue
            try:
                t = shlex.split(line)
            except ValueError:
                t = line.split()
            if len(t) >= 2:
                try: x[t[0]] = num(t[1])
                except ValueError: pass
    return x


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--start', default='/resources/best.sol')
    ap.add_argument('--passes', type=int, default=30)
    ap.add_argument('--shortlist', type=int, default=70)
    ap.add_argument('--reserve-seconds', type=float, default=8.0)
    args = ap.parse_args()
    started = time.time()
    V, senses, A, rhs, lb, ub, ints, c = parse_mps(args.model)
    if not os.path.exists(args.start):
        raise RuntimeError('Verified start solution was not mounted at ' + args.start)
    x = parse_solution(args.start)
    for v in V:
        if v not in x: x[v] = 0.0
    rowcols = defaultdict(list)
    lhs = defaultdict(float)
    for v in V:
        xv = x[v]
        for r,a in A[v].items():
            rowcols[r].append((v,a))
            lhs[r] += a*xv
    eqrows = {r for r,s in senses.items() if s == 'E'}
    signatures = defaultdict(list)
    for v in V:
        sig = tuple(sorted((r,a) for r,a in A[v].items() if r in eqrows and a != 0.0))
        signatures[sig].append(v)
    initial_obj = sum(c[v]*x[v] for v in V)
    tol = 1e-7
    accepted = []

    def max_step(changes):
        cap = float('inf')
        delta_by_row = defaultdict(float)
        for v,d in changes.items():
            if d > 0:
                cap = min(cap, (ub[v]-x[v])/d)
            elif d < 0:
                cap = min(cap, (x[v]-lb[v])/(-d))
            for r,a in A[v].items(): delta_by_row[r] += a*d
        for r,d in delta_by_row.items():
            if abs(d) <= 1e-15: continue
            s = senses[r]
            if s == 'E':
                if abs(d) > tol: return 0, delta_by_row
            elif s == 'L' and d > 0:
                cap = min(cap, (rhs[r]-lhs[r]+tol)/d)
            elif s == 'G' and d < 0:
                cap = min(cap, (lhs[r]-rhs[r]+tol)/(-d))
        if cap == float('inf'): cap = 1.0
        k = max(0, int(math.floor(cap + 1e-9)))
        return k, delta_by_row

    def apply(changes, k, delta_rows, dobj, kind):
        for v,d in changes.items(): x[v] += k*d
        for r,d in delta_rows.items(): lhs[r] += k*d
        accepted.append({'kind':kind,'changes':changes,'step':k,'objective_delta':k*dobj})

    empty_group = signatures.get((), [])
    deadline_hint = started + 3300
    for p in range(args.passes):
        if time.time() > deadline_hint: break
        moves_this_pass = 0
        # Equality-neutral coordinate moves.
        for v in sorted(empty_group, key=lambda z: c[z]):
            if abs(c[v]) <= 1e-15: continue
            d = 1 if c[v] < 0 else -1
            dobj = c[v]*d
            k, dr = max_step({v:d})
            if k > 0 and dobj < -1e-10:
                apply({v:d}, k, dr, dobj, 'coordinate')
                moves_this_pass += 1
        # Matched exchanges preserve every equality exactly.
        for sig, group in signatures.items():
            if len(group) < 2: continue
            inc = [v for v in group if x[v] + 0.5 < ub[v]]
            dec = [v for v in group if x[v] - 0.5 > lb[v]]
            inc = sorted(inc, key=lambda z:c[z])[:args.shortlist]
            dec = sorted(dec, key=lambda z:c[z], reverse=True)[:args.shortlist]
            best = None
            for vi in inc:
                for vj in dec:
                    if vi == vj: continue
                    dobj = c[vi]-c[vj]
                    if dobj >= -1e-10: continue
                    k, dr = max_step({vi:1, vj:-1})
                    if k > 0:
                        gain = -k*dobj
                        if best is None or gain > best[0]: best = (gain,vi,vj,k,dr,dobj)
            if best is not None:
                _,vi,vj,k,dr,dobj = best
                apply({vi:1,vj:-1}, k, dr, dobj, 'signature_exchange')
                moves_this_pass += 1
        if moves_this_pass == 0: break

    final_obj = sum(c[v]*x[v] for v in V)
    max_violation = 0.0
    for r,s in senses.items():
        if s == 'L': viol = max(0.0,lhs[r]-rhs[r])
        elif s == 'G': viol = max(0.0,rhs[r]-lhs[r])
        else: viol = abs(lhs[r]-rhs[r])
        max_violation = max(max_violation,viol)
    max_int = max((abs(x[v]-round(x[v])) for v in ints), default=0.0)
    feasible = max_violation <= 1e-6 and max_int <= 1e-7
    with open('best.sol','w',encoding='utf-8') as f:
        f.write('# Objective value = %.17g\n' % final_obj)
        for v in V:
            if abs(x[v]) > 1e-14: f.write('%s %.17g\n' % (v,x[v]))
    sizes = sorted((len(g) for g in signatures.values()), reverse=True)
    report = {
        'method':'equality_signature_exchange', 'initial_objective':initial_obj,
        'final_objective':final_obj, 'improvement':initial_obj-final_obj,
        'accepted_moves':len(accepted), 'moves':accepted[-200:],
        'variables':len(V), 'equalities':len(eqrows),
        'signature_groups':len(signatures), 'nontrivial_groups':sum(1 for g in signatures.values() if len(g)>1),
        'variables_in_nontrivial_groups':sum(len(g) for g in signatures.values() if len(g)>1),
        'largest_group_sizes':sizes[:20], 'empty_signature_variables':len(empty_group),
        'max_row_violation_float':max_violation, 'max_integrality_violation_float':max_int,
        'feasible_float_check':feasible, 'runtime_seconds':time.time()-started
    }
    with open('exchange_report.json','w',encoding='utf-8') as f: json.dump(report,f,indent=2)
    result = {'status':'feasible' if feasible else 'error','objective':final_obj if feasible else None,
              'solution_file':'best.sol','method':'equality_signature_exchange',
              'improvement':initial_obj-final_obj,'report':'exchange_report.json'}
    with open('method_result.json','w',encoding='utf-8') as f: json.dump(result,f,indent=2)
    print(json.dumps(result))
    return 0 if feasible else 2

if __name__ == '__main__':
    sys.exit(main())
