import argparse, gzip, json, math, os, random, time


def open_model(path):
    if path.lower().endswith('.gz'):
        return gzip.open(path, 'rt', errors='replace')
    return open(path, 'r', errors='replace')


def parse_mps(path):
    section = None
    sense = 'MIN'
    row_type = {}
    row_order = []
    cols = {}
    obj = {}
    rhs = {}
    ranges = {}
    lb = {}
    ub = {}
    integers = set()
    integer_mode = False
    objective_row = None
    with open_model(path) as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith('*'):
                continue
            tok = line.split()
            head = tok[0].upper()
            if head in ('NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA','OBJSENSE','OBJNAME'):
                section = head
                if head == 'ENDATA':
                    break
                continue
            if section == 'OBJSENSE':
                sense = tok[0].upper()
            elif section == 'ROWS' and len(tok) >= 2:
                typ, name = tok[0].upper(), tok[1]
                row_type[name] = typ
                row_order.append(name)
                if typ == 'N' and objective_row is None:
                    objective_row = name
            elif section == 'COLUMNS' and len(tok) >= 3:
                if any('MARKER' in x.upper() for x in tok):
                    integer_mode = any('INTORG' in x.upper() for x in tok)
                    if any('INTEND' in x.upper() for x in tok):
                        integer_mode = False
                    continue
                var = tok[0]
                if integer_mode:
                    integers.add(var)
                pairs = tok[1:]
                for k in range(0, len(pairs) - 1, 2):
                    row = pairs[k]
                    try:
                        val = float(pairs[k+1].replace('D','E').replace('d','e'))
                    except ValueError:
                        continue
                    if row == objective_row or row_type.get(row) == 'N':
                        if row == objective_row:
                            obj[var] = obj.get(var, 0.0) + val
                    else:
                        cols.setdefault(var, []).append((row, val))
            elif section == 'RHS' and len(tok) >= 3:
                pairs = tok[1:]
                for k in range(0, len(pairs) - 1, 2):
                    try:
                        rhs[pairs[k]] = float(pairs[k+1].replace('D','E').replace('d','e'))
                    except ValueError:
                        pass
            elif section == 'RANGES' and len(tok) >= 3:
                pairs = tok[1:]
                for k in range(0, len(pairs) - 1, 2):
                    try:
                        ranges[pairs[k]] = float(pairs[k+1].replace('D','E').replace('d','e'))
                    except ValueError:
                        pass
            elif section == 'BOUNDS' and len(tok) >= 3:
                bt = tok[0].upper()
                var = tok[2]
                val = 0.0
                if len(tok) >= 4:
                    try:
                        val = float(tok[3].replace('D','E').replace('d','e'))
                    except ValueError:
                        val = 0.0
                if bt == 'BV':
                    lb[var], ub[var] = 0.0, 1.0
                    integers.add(var)
                elif bt in ('LO','LI'):
                    lb[var] = val
                    if bt == 'LI': integers.add(var)
                elif bt in ('UP','UI'):
                    ub[var] = val
                    if bt == 'UI': integers.add(var)
                elif bt == 'FX':
                    lb[var] = ub[var] = val
                elif bt == 'FR':
                    lb[var], ub[var] = -math.inf, math.inf
                elif bt == 'MI':
                    lb[var] = -math.inf
                elif bt == 'PL':
                    ub[var] = math.inf
    names = list(dict.fromkeys(list(cols.keys()) + list(obj.keys()) + list(lb.keys()) + list(ub.keys())))
    idx = {v:i for i,v in enumerate(names)}
    n = len(names)
    lo = [lb.get(v, 0.0) for v in names]
    hi = [ub.get(v, math.inf) for v in names]
    isint = [v in integers for v in names]
    c = [obj.get(v, 0.0) for v in names]
    if sense.startswith('MAX'):
        work_c = [-z for z in c]
    else:
        work_c = c[:]
    rows = [r for r in row_order if row_type.get(r) != 'N']
    ridx = {r:i for i,r in enumerate(rows)}
    rlo, rhi = [], []
    for r in rows:
        b = rhs.get(r, 0.0)
        typ = row_type[r]
        if typ == 'L':
            a, z = -math.inf, b
        elif typ == 'G':
            a, z = b, math.inf
        else:
            a = z = b
        if r in ranges:
            q = ranges[r]
            if typ == 'L':
                a = b - abs(q)
            elif typ == 'G':
                z = b + abs(q)
            elif q >= 0:
                a, z = b, b + q
            else:
                a, z = b + q, b
        rlo.append(a); rhi.append(z)
    col_adj = [[] for _ in range(n)]
    row_adj = [[] for _ in rows]
    for v, entries in cols.items():
        j = idx[v]
        for r, a in entries:
            if r in ridx and a != 0.0:
                i = ridx[r]
                col_adj[j].append((i,a))
                row_adj[i].append((j,a))
    return names, lo, hi, isint, c, work_c, rows, rlo, rhi, col_adj, row_adj, sense


def clipped_initial(lo, hi, isint):
    x = []
    for a,b,z in zip(lo,hi,isint):
        if a <= 0.0 <= b:
            q = 0.0
        elif math.isfinite(a):
            q = a
        elif math.isfinite(b):
            q = b
        else:
            q = 0.0
        if z: q = round(q)
        x.append(q)
    return x


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--time', type=float, default=900.0)
    ap.add_argument('--seed', type=int, default=3355120)
    args = ap.parse_args()
    start = time.time()
    rng = random.Random(args.seed)
    data = parse_mps(args.model)
    names, lo, hi, isint, orig_c, c, rows, rlo, rhi, col_adj, row_adj, sense = data
    n, m = len(names), len(rows)
    scales = []
    for a,b in zip(rlo,rhi):
        ref = 0.0
        if math.isfinite(a): ref = max(ref, abs(a))
        if math.isfinite(b): ref = max(ref, abs(b))
        scales.append(1.0 + ref)

    def violation(i, value):
        if value < rlo[i] - 1e-7 * scales[i]:
            return (rlo[i] - value) / scales[i]
        if value > rhi[i] + 1e-7 * scales[i]:
            return (value - rhi[i]) / scales[i]
        return 0.0

    def candidate_values(j, x, act, focus_row=None):
        vals = set()
        cur = x[j]
        if isint[j]:
            vals.add(cur - 1); vals.add(cur + 1)
            if math.isfinite(lo[j]): vals.add(math.ceil(lo[j] - 1e-9))
            if math.isfinite(hi[j]): vals.add(math.floor(hi[j] + 1e-9))
            if lo[j] <= 0 <= hi[j]: vals.add(0.0)
            if lo[j] <= 1 <= hi[j]: vals.add(1.0)
        else:
            if math.isfinite(lo[j]): vals.add(lo[j])
            if math.isfinite(hi[j]): vals.add(hi[j])
            if lo[j] <= 0 <= hi[j]: vals.add(0.0)
        entries = col_adj[j] if focus_row is None else [(i,a) for i,a in col_adj[j] if i == focus_row]
        for i,a in entries:
            if a == 0: continue
            for target in (rlo[i], rhi[i]):
                if math.isfinite(target):
                    q = cur + (target - act[i]) / a
                    if isint[j]:
                        vals.add(math.floor(q)); vals.add(math.ceil(q))
                    else:
                        vals.add(q)
        out = []
        for q in vals:
            q = max(lo[j], min(hi[j], q))
            if isint[j]: q = float(round(q))
            if abs(q-cur) > 1e-10 and math.isfinite(q): out.append(q)
        return out

    best_x = None
    best_obj = math.inf
    best_v = math.inf
    iterations = 0
    restarts = 0
    deadline = start + max(5.0, args.time)
    while time.time() < deadline:
        restarts += 1
        x = clipped_initial(lo,hi,isint)
        # Activation-first diversification: selectively enable sparse, favorable binary columns.
        favorable = [j for j in range(n) if isint[j] and lo[j] <= 0 and hi[j] >= 1 and c[j] < 0]
        favorable.sort(key=lambda j: c[j] / max(1, len(col_adj[j])))
        take = min(len(favorable), max(1, int(len(favorable) * rng.uniform(0.05,0.30))))
        for j in favorable[:take]:
            if rng.random() < 0.75:
                x[j] = 1.0
        act = [0.0] * m
        for j,val in enumerate(x):
            if val:
                for i,a in col_adj[j]: act[i] += a*val
        viol = [violation(i,act[i]) for i in range(m)]
        total_v = sum(viol)
        stagnant = 0
        max_steps = max(2000, min(200000, 30*m + 10*n))
        for step in range(max_steps):
            iterations += 1
            if time.time() >= deadline: break
            if total_v <= 1e-8:
                objw = sum(c[j]*x[j] for j in range(n))
                if objw < best_obj:
                    best_obj, best_x, best_v = objw, x[:], total_v
                # Feasibility-preserving sparse objective neighborhood.
                improved = False
                order = sorted(range(n), key=lambda j: c[j])
                if len(order) > 3000:
                    order = order[:1500] + rng.sample(order[1500:], 1500)
                for j in order:
                    for q in candidate_values(j,x,act):
                        dobj = c[j]*(q-x[j])
                        if dobj >= -1e-9: continue
                        good = True
                        for i,a in col_adj[j]:
                            nv = act[i] + a*(q-x[j])
                            if violation(i,nv) > 1e-8:
                                good = False; break
                        if good:
                            d = q-x[j]; x[j] = q
                            for i,a in col_adj[j]: act[i] += a*d
                            objw += dobj; improved = True
                            if objw < best_obj:
                                best_obj, best_x, best_v = objw, x[:], 0.0
                            break
                if not improved: break
                continue
            worst = max(viol)
            pool_rows = [i for i,v in enumerate(viol) if v >= max(1e-12, worst*0.80)]
            ri = rng.choice(pool_rows)
            candidates = row_adj[ri]
            if len(candidates) > 250:
                candidates = sorted(candidates, key=lambda p: abs(p[1]), reverse=True)[:120] + rng.sample(candidates[120:], min(130,len(candidates)-120))
            moves = []
            for j,a0 in candidates:
                old_local = sum(viol[i] for i,a in col_adj[j])
                for q in candidate_values(j,x,act,ri):
                    d = q-x[j]
                    new_local = 0.0
                    for i,a in col_adj[j]: new_local += violation(i, act[i]+a*d)
                    gain = old_local-new_local
                    if gain > 1e-12:
                        moves.append((gain, -c[j]*d, rng.random(), j, q))
            if not moves:
                stagnant += 1
                if stagnant > 100: break
                # Random bounded kick on a variable in the violated row.
                if candidates:
                    j,_ = rng.choice(candidates)
                    vv = candidate_values(j,x,act,ri)
                    if vv:
                        q = rng.choice(vv); d=q-x[j]; x[j]=q
                        for i,a in col_adj[j]:
                            old=viol[i]; act[i]+=a*d; viol[i]=violation(i,act[i]); total_v += viol[i]-old
                continue
            moves.sort(reverse=True)
            pick = moves[0] if len(moves) == 1 or rng.random() > 0.12 else rng.choice(moves[:min(8,len(moves))])
            _,_,_,j,q = pick
            d=q-x[j]; x[j]=q
            for i,a in col_adj[j]:
                old=viol[i]; act[i]+=a*d; viol[i]=violation(i,act[i]); total_v += viol[i]-old
            stagnant = 0
            if total_v < best_v:
                best_v = total_v
        if restarts >= 3 and best_x is not None and time.time() > start + 0.75*args.time:
            break

    elapsed = time.time()-start
    feasible = best_x is not None
    original_obj = None
    if feasible:
        original_obj = sum(orig_c[j]*best_x[j] for j in range(n))
        with open('best.sol','w') as f:
            f.write('# Objective value = %.17g\n' % original_obj)
            for name,val in zip(names,best_x):
                if abs(val) > 1e-12:
                    f.write('%s %.17g\n' % (name,val))
    result = {
        'method':'activation-first sparse row repair with feasibility-preserving neighborhood search',
        'status':'feasible' if feasible else 'no_feasible_solution_found',
        'objective':original_obj,
        'working_objective':best_obj if feasible else None,
        'best_normalized_violation':best_v,
        'variables':n,'rows':m,'integer_variables':sum(isint),
        'iterations':iterations,'restarts':restarts,'elapsed_seconds':elapsed,
        'claim':'Heuristic result only; feasibility and objective require controller verification.'
    }
    with open('method_result.json','w') as f: json.dump(result,f,indent=2,sort_keys=True)
    with open('search_report.txt','w') as f:
        for k,v in result.items(): f.write('%s: %s\n' % (k,v))

if __name__ == '__main__':
    main()
