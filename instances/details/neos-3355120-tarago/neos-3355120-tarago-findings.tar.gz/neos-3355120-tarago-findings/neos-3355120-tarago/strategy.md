# Formal-solving strategy

1. Preserve the exactly verified baseline incumbent as the feasibility anchor.
2. Test equality-preserving integer exchange neighborhoods using an independent MPS parser and incremental row checks.
3. Use the custom report to measure equality-signature group sizes, variables covered, feasible exchange density, and objective improvement.
4. If pair exchanges work, enlarge the neighborhood to short equality-nullspace cycles and then pass the best verified solution to a solver as a warm start for proof.
5. If pair exchanges fail, analyze the row-variable incidence structure and construct block-fixed exact subproblems instead of spending budget on parameter-only portfolios.
6. Claim optimality only when a strict solver status or independently reproducible proof matches the verified primal bound.