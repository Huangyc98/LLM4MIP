# `sing11` — stronger root bound; global optimum still open

2026-09-14 independent dual-bound review: [adopted bound, proof chain, checks, and limitations](../../docs/dual-bound-audit-2026-09-14/cases/sing11.zh.md). Reviewed lower bound: **approximately 18853382.0323116**. This review distinguishes exact, literature, and numerical evidence; historical statements below remain dated records.

Official MIPLIB page: <https://miplib.zib.de/instance_details_sing11.html>

## Result

`sing11` remains **globally open**. This study produced a substantially stronger
reproducible numerical lower bound, repaired the public headline solution to a
strict witness, and closed many conditional block neighborhoods. It did not
make the upper and lower bounds meet.

| Quantity | Value | Evidence boundary |
|---|---:|---|
| Strict feasible upper bound | **19,108,639.4603941927675439822** | Original-MPS fixed-integer LP repair; maximum row violation about `4.5e-13` |
| New locally reproducible lower bound | **18,853,382.0323116** | Gurobi 13.0.2 aggressive root cuts, 1,200 s, four threads, one node |
| Reproducible relative gap | **1.3358221%** | `(UB-LB)/abs(UB)` |
| Archived COPT 10-hour lower bound | **18,776,564.1** | Finite-precision PDF value; no matching raw log or proof trace |
| Improvement over that archived value | **about 76,817.9** | Closes about 23.13% of the previous strict gap |

The lower bound is floating-point solver evidence rather than an independently
checked rational certificate.

## Why the headline objective is not used as the strict UB

MIPLIB currently displays `19,108,639.4392498955` for the 2025 cuOpt solution,
but the same entry reports a `9.2e-6` constraint violation. Direct row replay
found a maximum violation of about `9.233e-6`. Fixing all 165,337 integer
variables and reoptimizing only the 10,015 continuous variables produces the
strict solution in
[`solutions/sing11-strict-repaired.sol`](solutions/sing11-strict-repaired.sol).
Its integer pattern is unchanged and its objective agrees with the 2019
ODH|CPlex solution. The apparent `0.0211443` improvement in the headline file is
therefore a precision/feasibility effect, not a new integer schedule.

The full audit is
[`sing11-public-fixed-lp-repair.json`](artifacts/sing11-public-fixed-lp-repair.json).
The exact file published here was also reread independently; the resulting
float replay is [`published-solution-replay.json`](artifacts/published-solution-replay.json).

## Structure and experiments

The model has 175,352 variables (165,337 binary and 10,015 continuous), 105,858
rows, and 479,075 nonzeros. The official decomposition contains 74 blocks and
336 master rows, with 189 master-only variables. See
[`sing11-structure.json`](artifacts/sing11-structure.json) and
[`sing11-decomposition.json`](artifacts/sing11-decomposition.json).

The strongest run kept the full original model, supplied every variable in the
strict MIP start, set aggressive presolve/cuts and `MIPFocus=3`, and limited the
tree to one node. The 1,200-second run reached
`18,853,382.0323116`; the [JSON](artifacts/sing11-gurobi-rootcuts-1200s.json)
and [raw log](logs/sing11-gurobi-rootcuts-1200s.log) are archived. Its gain came
from root-node MIR and flow-cover separation, not deep-tree enumeration.

Official-decomposition LNS then established the following conditional facts:

- all **74/74** one-block subproblems returned `OPTIMAL` with `MIPGap=0` and
  `MIPGapAbs=0`, without improving the incumbent;
- six historical-difference groups — `(61,71)`, `(7,18)`, `(2,19)`, `(12,73)`,
  `(61,71,7,18)`, and `(2,19,12,73)` — were also closed without improvement;
- the largest tested joint neighborhood released 26,563 variables.

These results are in
[`sing11-block-lns-all74-gap0.json`](artifacts/sing11-block-lns-all74-gap0.json)
and [`sing11-block-group-lns.json`](artifacts/sing11-block-group-lns.json), with
raw subproblem logs under [`logs/`](logs/). They prove optimality only after
all variables outside the selected block set are fixed; they are not a global
optimality proof.

The published one-block filenames are normalized to `sing11-block-XX.log`.
Inside each unedited raw log, Gurobi's `LogFile` header still records the
historical generic runner name `sing17-block-XX.log`; the model line and all
solver output identify the actual instance as `sing11`.

At the full-LP dual multipliers, the integer Lagrangian subproblem closed at
approximately `18,640,171.224643`, essentially the LP relaxation. Twenty
proximal-bundle inner MIPs all solved to zero gap; 19 candidate moves were null
steps and none improved the bound meaningfully. The aggregate record is
[`sing11-lagrangian-bundle-20.json`](artifacts/sing11-lagrangian-bundle-20.json).

## Reproduction

Download the official MPS as described in [`input/README.md`](input/README.md),
then run these commands from this instance directory with Gurobi 13.x.

Repair and re-audit the current public solution:

```powershell
python scripts/repair_fixed_integer_solution.py `
  --mps input/sing11.mps.gz --solution input/sing11-public.sol.gz `
  --output-json replay/fixed-lp-repair.json `
  --output-sparse-sol replay/strict-repaired.sol `
  --output-full-sol replay/strict-repaired-full.sol `
  --log replay/fixed-lp-repair.log --time-limit 300 --threads 2
```

Reproduce the root-cut configuration:

```powershell
python scripts/sing17_experiment.py `
  --mps input/sing11.mps.gz --solution solutions/sing11-strict-repaired.sol `
  --output replay/rootcuts-1200s.json --log replay/rootcuts-1200s.log `
  --time-limit 1200 --threads 4 --seed 512 --mip-focus 3 `
  --cuts 3 --symmetry 2 --heuristics 0 --presolve 2 --node-limit 1 `
  --result-tag sing11-rootcuts
```

The filename `sing17_experiment.py` is historical; the runner is instance
agnostic. Input hashes are in [`input/SHA256SUMS`](input/SHA256SUMS), and the
cross-instance interpretation is in the
[`sing` family report](../../docs/sing-family-2026-09-08.zh.md).

## Scope of the conclusion

The strict UB and new reproducible LB still differ by about 255,257.43. The
LNS closures are conditional and the global LB is numerical. Consequently,
**`sing11` remains open**, despite the material lower-bound improvement.
