# Input provenance

The original model is not duplicated in Git. Download
[`sing11.mps.gz`](https://miplib.zib.de/WebData/instances/sing11.mps.gz) from
MIPLIB and save it in this directory before rerunning the scripts. The expected
SHA-256 is recorded in `SHA256SUMS`.

`sing11.dec` is the official original-model decomposition from
<https://miplib.zib.de/WebData/decomps_orig/sing11.dec>. The compressed solution
files preserve the 2025 headline, 2019 ODH|CPlex, and 2018 selection solutions
used in the audit. The 2025 file is retained as source material; it is not the
strict witness used for the reported upper bound.
