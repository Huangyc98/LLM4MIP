from __future__ import annotations

import argparse
import gzip
import json
import math
import time
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def parse_dec(path: Path) -> tuple[dict[str, int], set[str]]:
    row_to_block: dict[str, int] = {}
    master_rows: set[str] = set()
    current_block: int | None = None
    in_master = False
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    index = 0
    while index < len(lines):
        line = lines[index].strip()
        index += 1
        if not line or line.startswith("\\"):
            continue
        upper = line.upper()
        if upper == "NBLOCKS":
            while index < len(lines) and not lines[index].strip():
                index += 1
            index += 1
        elif upper.startswith("BLOCK "):
            current_block = int(line.split()[1])
            in_master = False
        elif upper == "MASTERCONSS":
            current_block = None
            in_master = True
        elif upper in {"PRESOLVED", "0"}:
            continue
        elif in_master:
            master_rows.add(line)
        elif current_block is not None:
            row_to_block[line] = current_block
    return row_to_block, master_rows


def read_sparse_solution(path: Path) -> dict[str, float]:
    opener = gzip.open if path.suffix == ".gz" else open
    values: dict[str, float] = {}
    with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
        for line in handle:
            fields = line.strip().split()
            if not fields or fields[0].startswith("#") or fields[0].startswith("=") or len(fields) < 2:
                continue
            try:
                values[fields[0]] = float(fields[1])
            except ValueError:
                continue
    return values


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Dualize official DEC master rows and retain integrality inside every independent block."
    )
    parser.add_argument("--mps", type=Path, required=True)
    parser.add_argument("--dec", type=Path, required=True)
    parser.add_argument("--solution", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--lp-log", type=Path, required=True)
    parser.add_argument("--mip-log", type=Path, required=True)
    parser.add_argument("--time-limit", type=float, default=1200.0)
    parser.add_argument("--threads", type=int, default=6)
    parser.add_argument("--method", type=int, default=1)
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument("--cuts", type=int, default=2)
    parser.add_argument("--mip-focus", type=int, default=3)
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.lp_log.parent.mkdir(parents=True, exist_ok=True)
    args.mip_log.parent.mkdir(parents=True, exist_ok=True)
    started = time.time()

    row_to_block, master_names = parse_dec(args.dec)
    model = gp.read(str(args.mps))
    model.update()
    all_row_names = {row.ConstrName for row in model.getConstrs()}
    assigned = set(row_to_block) | master_names
    if assigned != all_row_names:
        raise RuntimeError(
            f"DEC mismatch: {len(all_row_names - assigned)} unassigned and {len(assigned - all_row_names)} absent rows"
        )

    lp = model.relax()
    lp.Params.Threads = args.threads
    lp.Params.Method = args.method
    lp.Params.Presolve = 2
    lp.Params.NumericFocus = 2
    lp.Params.OptimalityTol = 1e-9
    lp.Params.FeasibilityTol = 1e-9
    lp.Params.LogFile = str(args.lp_log)
    lp.optimize()
    if lp.Status != GRB.OPTIMAL:
        raise RuntimeError(f"LP relaxation status {lp.Status}, expected OPTIMAL")

    duals = {name: lp.getConstrByName(name).Pi for name in master_names}
    lagrangian = model.copy()
    lagrangian.update()
    lag_vars = lagrangian.getVars()
    objective = [var.Obj for var in lag_vars]
    lag_constant = lagrangian.ObjCon
    master_sense_counts = {"=": 0, "<": 0, ">": 0}
    dual_sign_violations = 0
    for name in master_names:
        row = lagrangian.getConstrByName(name)
        dual = duals[name]
        master_sense_counts[row.Sense] += 1
        if row.Sense == GRB.GREATER_EQUAL and dual < -1e-8:
            dual_sign_violations += 1
        if row.Sense == GRB.LESS_EQUAL and dual > 1e-8:
            dual_sign_violations += 1
        lag_constant += dual * row.RHS
        expression = lagrangian.getRow(row)
        for position in range(expression.size()):
            var = expression.getVar(position)
            objective[var.index] -= dual * expression.getCoeff(position)

    lagrangian.setAttr(GRB.Attr.Obj, lag_vars, objective)
    lagrangian.ObjCon = lag_constant
    lagrangian.remove([lagrangian.getConstrByName(name) for name in master_names])
    lagrangian.update()

    validation = lagrangian.relax()
    validation.Params.OutputFlag = 0
    validation.Params.Threads = args.threads
    validation.Params.Method = args.method
    validation.Params.Presolve = 2
    validation.Params.OptimalityTol = 1e-9
    validation.optimize()
    if validation.Status != GRB.OPTIMAL:
        raise RuntimeError(f"Lagrangian validation LP status {validation.Status}")
    validation_difference = validation.ObjVal - lp.ObjVal
    if abs(validation_difference) > 1e-3:
        raise RuntimeError(
            f"dualization sign/assembly check failed: Lagrangian LP differs by {validation_difference}"
        )
    if dual_sign_violations:
        raise RuntimeError(f"LP dual contains {dual_sign_violations} master-row sign violations")

    start_info = None
    if args.solution:
        sparse = read_sparse_solution(args.solution)
        for var in lag_vars:
            var.Start = sparse.get(var.VarName, 0.0)
        start_info = {
            "solution_entries": len(sparse),
            "initialized_variables": len(lag_vars),
        }

    lagrangian.Params.TimeLimit = args.time_limit
    lagrangian.Params.Threads = args.threads
    lagrangian.Params.Presolve = 2
    lagrangian.Params.Cuts = args.cuts
    lagrangian.Params.MIPFocus = args.mip_focus
    lagrangian.Params.Seed = args.seed
    lagrangian.Params.NumericFocus = 2
    lagrangian.Params.MIPGap = 0.0
    lagrangian.Params.LogFile = str(args.mip_log)
    lagrangian.optimize()

    subgradient = None
    if lagrangian.SolCount:
        lag_solution = lagrangian.getAttr(GRB.Attr.X, lag_vars)
        residuals = []
        original_objective = model.ObjCon + math.fsum(
            var.Obj * lag_solution[var.index] for var in model.getVars()
        )
        violated_master_rows = 0
        for name in master_names:
            original_row = model.getConstrByName(name)
            expression = model.getRow(original_row)
            activity = math.fsum(
                expression.getCoeff(position) * lag_solution[expression.getVar(position).index]
                for position in range(expression.size())
            )
            residual = original_row.RHS - activity
            residuals.append(residual)
            if original_row.Sense == GRB.EQUAL:
                violated_master_rows += abs(residual) > 1e-7
            elif original_row.Sense == GRB.GREATER_EQUAL:
                violated_master_rows += residual > 1e-7
            else:
                violated_master_rows += residual < -1e-7
        subgradient = {
            "definition": "b-A*x for a Lagrangian-minimizing incumbent x",
            "l1_norm": math.fsum(abs(value) for value in residuals),
            "l2_norm": math.sqrt(math.fsum(value * value for value in residuals)),
            "max_absolute": max(abs(value) for value in residuals),
            "nonzero_above_1e-7": sum(abs(value) > 1e-7 for value in residuals),
            "violated_master_rows": violated_master_rows,
            "original_objective_at_lagrangian_incumbent": original_objective,
        }

    report = {
        "instance": model.ModelName,
        "method": "integer Lagrangian relaxation of official DEC master constraints",
        "formula": "min over block-feasible integer x of c*x + pi*(b-A*x)",
        "official_decomposition": {
            "block_rows": len(row_to_block),
            "master_rows": len(master_names),
            "master_senses": master_sense_counts,
        },
        "full_lp_relaxation_objective": float(lp.ObjVal),
        "lagrangian_relaxation_lp_objective": float(validation.ObjVal),
        "lp_validation_difference": float(validation_difference),
        "dual_sign_violations": dual_sign_violations,
        "dual_stats": {
            "min": min(duals.values()),
            "max": max(duals.values()),
            "nonzero": sum(abs(value) > 1e-12 for value in duals.values()),
        },
        "subgradient": subgradient,
        "start": start_info,
        "parameters": {
            "time_limit": args.time_limit,
            "threads": args.threads,
            "lp_method": args.method,
            "cuts": args.cuts,
            "mip_focus": args.mip_focus,
            "seed": args.seed,
        },
        "lagrangian_mip": {
            "status": int(lagrangian.Status),
            "status_name": {
                GRB.OPTIMAL: "OPTIMAL",
                GRB.TIME_LIMIT: "TIME_LIMIT",
                GRB.NODE_LIMIT: "NODE_LIMIT",
                GRB.INFEASIBLE: "INFEASIBLE",
            }.get(lagrangian.Status, "OTHER"),
            "solution_count": int(lagrangian.SolCount),
            "best_objective": float(lagrangian.ObjVal) if lagrangian.SolCount else None,
            "valid_global_lower_bound": float(lagrangian.ObjBound),
            "relative_gap": float(lagrangian.MIPGap) if lagrangian.SolCount else None,
            "nodes": float(lagrangian.NodeCount),
            "simplex_iterations": float(lagrangian.IterCount),
            "barrier_iterations": int(lagrangian.BarIterCount),
            "runtime_seconds": float(lagrangian.Runtime),
        },
        "wall_runtime_seconds": time.time() - started,
        "notes": [
            "The reported ObjBound is a valid lower bound for the original minimization problem because only master constraints are dualized.",
            "The LP equality check verifies the multiplier sign convention and model assembly numerically.",
            "This is floating-point solver evidence, not an exact rational certificate.",
        ],
    }
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
