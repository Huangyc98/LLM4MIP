from __future__ import annotations

import argparse
import gzip
import json
import math
import time
from collections import Counter
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def read_solution(path: Path) -> tuple[dict[str, float], float | None]:
    opener = gzip.open if path.suffix == ".gz" else open
    values: dict[str, float] = {}
    declared = None
    with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
        for line in handle:
            stripped = line.strip()
            if not stripped:
                continue
            if stripped.startswith("#"):
                lower = stripped.lower()
                if "objective value" in lower:
                    start = lower.index("objective value") + len("objective value")
                    tail = stripped[start:].lstrip(" :=")
                    try:
                        declared = float(tail.split()[0])
                    except (ValueError, IndexError):
                        pass
                continue
            parts = stripped.split()
            if len(parts) >= 2:
                if parts[0].lower() in {"=obj=", "=best=", "=opt="}:
                    try:
                        declared = float(parts[1])
                    except ValueError:
                        pass
                    continue
                try:
                    values[parts[0]] = float(parts[1])
                except ValueError:
                    pass
    return values, declared


def violation_summary(values: list[float]) -> dict:
    levels = [1e-9, 1e-8, 1e-7, 1e-6, 1e-5, 1e-4]
    nonzero = [x for x in values if x > 0]
    return {
        "max": max(values, default=0.0),
        "positive_count": len(nonzero),
        "counts_above": {f"{tol:.0e}": sum(x > tol for x in values) for tol in levels},
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", type=Path, required=True)
    parser.add_argument("--solution", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--round-integers", action="store_true")
    args = parser.parse_args()

    started = time.time()
    model = gp.read(str(args.mps))
    model.update()
    sol, declared = read_solution(args.solution)

    vars_ = model.getVars()
    constraints = model.getConstrs()
    missing_nondefault = []
    x = []
    bound_violations = []
    integrality_violations = []
    type_counts = Counter()
    for var in vars_:
        value = sol.get(var.VarName, 0.0)
        if args.round_integers and var.VType in (GRB.BINARY, GRB.INTEGER, GRB.SEMIINT):
            value = float(round(value))
        x.append(value)
        type_counts[var.VType] += 1
        bv = max(var.LB - value, value - var.UB, 0.0)
        bound_violations.append(bv)
        if var.VType in (GRB.BINARY, GRB.INTEGER, GRB.SEMIINT):
            integrality_violations.append(abs(value - round(value)))
        else:
            integrality_violations.append(0.0)
        if var.VarName not in sol and (var.LB > 0 or var.UB < 0):
            missing_nondefault.append(var.VarName)

    row_violations = []
    row_residuals = []
    worst_rows = []
    sense_counts = Counter()
    nnz_by_row = []
    for constr in constraints:
        row = model.getRow(constr)
        lhs = 0.0
        for k in range(row.size()):
            lhs += row.getCoeff(k) * x[row.getVar(k).index]
        rhs = constr.RHS
        sense = constr.Sense
        sense_counts[sense] += 1
        nnz_by_row.append(row.size())
        if sense == "<":
            violation = max(lhs - rhs, 0.0)
            residual = lhs - rhs
        elif sense == ">":
            violation = max(rhs - lhs, 0.0)
            residual = rhs - lhs
        else:
            violation = abs(lhs - rhs)
            residual = lhs - rhs
        row_violations.append(violation)
        row_residuals.append(residual)
        if violation > 0:
            worst_rows.append((violation, constr.ConstrName, sense, lhs, rhs, row.size()))

    worst_rows.sort(reverse=True)
    objective = model.ObjCon + math.fsum(var.Obj * value for var, value in zip(vars_, x))
    nnz_sorted = sorted(nnz_by_row)
    report = {
        "model": {
            "name": model.ModelName,
            "sense": "minimize" if model.ModelSense == GRB.MINIMIZE else "maximize",
            "variables": model.NumVars,
            "constraints": model.NumConstrs,
            "nonzeros": model.NumNZs,
            "variable_types": dict(type_counts),
            "constraint_senses": dict(sense_counts),
            "row_nnz": {
                "min": nnz_sorted[0] if nnz_sorted else 0,
                "median": nnz_sorted[len(nnz_sorted) // 2] if nnz_sorted else 0,
                "max": nnz_sorted[-1] if nnz_sorted else 0,
            },
        },
        "solution": {
            "integer_values_rounded_before_audit": args.round_integers,
            "entries_in_file": len(sol),
            "declared_objective": declared,
            "recomputed_objective": objective,
            "objective_difference": None if declared is None else objective - declared,
            "missing_nondefault_bound_variables": missing_nondefault[:20],
        },
        "feasibility": {
            "bounds": violation_summary(bound_violations),
            "integrality": violation_summary(integrality_violations),
            "constraints": violation_summary(row_violations),
            "worst_constraint_rows": [
                {
                    "violation": v,
                    "name": name,
                    "sense": sense,
                    "lhs": lhs,
                    "rhs": rhs,
                    "nonzeros": nnz,
                }
                for v, name, sense, lhs, rhs, nnz in worst_rows[:20]
            ],
        },
        "runtime_seconds": time.time() - started,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
