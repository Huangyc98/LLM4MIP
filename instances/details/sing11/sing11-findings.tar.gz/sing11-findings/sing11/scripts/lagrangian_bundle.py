from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB

from lagrangian_decomposition import parse_dec, read_sparse_solution


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Proximal bundle search for an equality-constrained integer Lagrangian dual."
    )
    parser.add_argument("--mps", type=Path, required=True)
    parser.add_argument("--dec", type=Path, required=True)
    parser.add_argument("--solution", type=Path, required=True)
    parser.add_argument("--upper-bound", type=float, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--log-dir", type=Path, required=True)
    parser.add_argument("--best-multipliers", type=Path, required=True)
    parser.add_argument("--iterations", type=int, default=40)
    parser.add_argument("--inner-time-limit", type=float, default=120.0)
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--rho", type=float, default=1000.0)
    parser.add_argument("--rho-min", type=float, default=1.0)
    parser.add_argument("--rho-max", type=float, default=1e8)
    parser.add_argument("--box-radius", type=float, default=20.0)
    parser.add_argument("--serious-ratio", type=float, default=0.2)
    parser.add_argument("--seed", type=int, default=4500)
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.log_dir.mkdir(parents=True, exist_ok=True)
    args.best_multipliers.parent.mkdir(parents=True, exist_ok=True)
    started = time.time()

    row_to_block, master_name_set = parse_dec(args.dec)
    model = gp.read(str(args.mps))
    model.update()
    all_names = {row.ConstrName for row in model.getConstrs()}
    assigned = set(row_to_block) | master_name_set
    if assigned != all_names:
        raise RuntimeError(
            f"DEC mismatch: {len(all_names-assigned)} unassigned, "
            f"{len(assigned-all_names)} absent"
        )
    master_names = sorted(master_name_set)
    master_rows = [model.getConstrByName(name) for name in master_names]
    supported_senses = {GRB.EQUAL, GRB.GREATER_EQUAL, GRB.LESS_EQUAL}
    if any(row.Sense not in supported_senses for row in master_rows):
        raise RuntimeError("Unsupported master-row sense")
    master_senses = [row.Sense for row in master_rows]

    variables = model.getVars()
    original_cost = [float(variable.Obj) for variable in variables]
    original_constant = float(model.ObjCon)
    rhs = [float(row.RHS) for row in master_rows]
    terms: list[list[tuple[int, float]]] = []
    for row in master_rows:
        expression = model.getRow(row)
        terms.append(
            [
                (
                    expression.getVar(position).index,
                    float(expression.getCoeff(position)),
                )
                for position in range(expression.size())
            ]
        )

    lp = model.relax()
    lp.Params.OutputFlag = 0
    lp.Params.Threads = args.threads
    lp.Params.Method = 1
    lp.Params.Presolve = 2
    lp.Params.NumericFocus = 2
    lp.Params.OptimalityTol = 1e-9
    lp.Params.FeasibilityTol = 1e-9
    lp.optimize()
    if lp.Status != GRB.OPTIMAL:
        raise RuntimeError(f"Full LP status {lp.Status}")
    center = []
    raw_lp_duals = [float(lp.getConstrByName(name).Pi) for name in master_names]
    for dual, sense in zip(raw_lp_duals, master_senses):
        if sense == GRB.GREATER_EQUAL:
            center.append(max(0.0, dual))
        elif sense == GRB.LESS_EQUAL:
            center.append(min(0.0, dual))
        else:
            center.append(dual)
    initial_dual_sign_corrections = sum(
        abs(raw - corrected) > 0.0
        for raw, corrected in zip(raw_lp_duals, center)
    )

    lagrangian = model.copy()
    lagrangian.remove(
        [lagrangian.getConstrByName(name) for name in master_names]
    )
    lagrangian.update()
    lag_variables = lagrangian.getVars()
    sparse = read_sparse_solution(args.solution)
    inner_start = [sparse.get(variable.VarName, 0.0) for variable in lag_variables]
    lagrangian.Params.Threads = args.threads
    lagrangian.Params.Presolve = 2
    lagrangian.Params.Cuts = 3
    lagrangian.Params.MIPFocus = 3
    lagrangian.Params.NumericFocus = 2
    lagrangian.Params.MIPGap = 0.0
    lagrangian.Params.OptimalityTol = 1e-9
    lagrangian.Params.FeasibilityTol = 1e-9
    lagrangian.Params.IntFeasTol = 1e-9
    lagrangian.Params.TimeLimit = args.inner_time_limit

    def solve_inner(multipliers: list[float], iteration: int) -> dict:
        nonlocal inner_start
        objective = list(original_cost)
        constant = original_constant
        for multiplier, row_rhs, row_terms in zip(multipliers, rhs, terms):
            constant += multiplier * row_rhs
            for variable_index, coefficient in row_terms:
                objective[variable_index] -= multiplier * coefficient

        lagrangian.reset(0)
        lagrangian.setAttr(GRB.Attr.Obj, lag_variables, objective)
        lagrangian.ObjCon = constant
        for variable, value in zip(lag_variables, inner_start):
            variable.Start = value
        lagrangian.Params.Seed = args.seed + iteration
        lagrangian.Params.LogFile = str(
            args.log_dir / f"bundle-inner-{iteration:03d}.log"
        )
        lagrangian.optimize()
        if lagrangian.Status != GRB.OPTIMAL:
            raise RuntimeError(
                f"Iteration {iteration}: inner status {lagrangian.Status}; "
                "bundle cuts require an OPTIMAL-status inner solve"
            )
        values = [float(variable.X) for variable in lag_variables]
        inner_start = values
        residual = []
        for row_rhs, row_terms in zip(rhs, terms):
            activity = sum(
                coefficient * values[variable_index]
                for variable_index, coefficient in row_terms
            )
            residual.append(row_rhs - activity)
        original_value = original_constant + sum(
            coefficient * value
            for coefficient, value in zip(original_cost, values)
        )
        recomputed = original_value + sum(
            multiplier * value
            for multiplier, value in zip(multipliers, residual)
        )
        if abs(recomputed - lagrangian.ObjVal) > 1e-4:
            raise RuntimeError(
                f"Iteration {iteration}: assembly error "
                f"{recomputed-lagrangian.ObjVal}"
            )
        # Min protects against tiny floating inversions between ObjVal and ObjBound.
        valid_bound = min(float(lagrangian.ObjVal), float(lagrangian.ObjBound))
        return {
            "valid_bound": valid_bound,
            "lagrangian_objective": float(lagrangian.ObjVal),
            "original_value": original_value,
            "residual": residual,
            "nodes": float(lagrangian.NodeCount),
            "simplex_iterations": float(lagrangian.IterCount),
            "runtime_seconds": float(lagrangian.Runtime),
            "assembly_error": recomputed - float(lagrangian.ObjVal),
        }

    first = solve_inner(center, 0)
    center_value = first["valid_bound"]
    best_value = center_value
    best_multipliers = list(center)
    best_iteration = 0
    # Persist the incumbent even when the LP-dual starting point remains best.
    # Previously this file was only created after a >1e-6 improvement, which
    # made a fully null-step run unnecessarily hard to reproduce.
    args.best_multipliers.write_text(
        json.dumps(
            {
                "instance": model.ModelName,
                "iteration": best_iteration,
                "valid_lower_bound": best_value,
                "master_names": master_names,
                "multipliers": best_multipliers,
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    # Each solver-verified minimizer supplies an upper plane on the sampled
    # floating-point Lagrangian dual function.
    cuts: list[tuple[float, list[float]]] = [
        (first["original_value"], first["residual"])
    ]
    records = [
        {
            "iteration": 0,
            "step_type": "initial LP-dual multiplier",
            "valid_lower_bound": first["valid_bound"],
            "best_bound_so_far": best_value,
            "center_bound": center_value,
            "master_residual_l2": math.sqrt(
                sum(value * value for value in first["residual"])
            ),
            "master_residual_max_abs": max(
                abs(value) for value in first["residual"]
            ),
            "nodes": first["nodes"],
            "runtime_seconds": first["runtime_seconds"],
            "assembly_error": first["assembly_error"],
        }
    ]
    rho = args.rho

    def build_checkpoint() -> dict:
        return {
            "instance": model.ModelName,
            "method": "proximal bundle search on integer Lagrangian dual",
            "known_upper_bound": args.upper_bound,
            "full_lp_bound": float(lp.ObjVal),
            "master_constraints": {
                "=": sum(sense == GRB.EQUAL for sense in master_senses),
                ">": sum(sense == GRB.GREATER_EQUAL for sense in master_senses),
                "<": sum(sense == GRB.LESS_EQUAL for sense in master_senses),
            },
            "initial_dual_sign_corrections": initial_dual_sign_corrections,
            "parameters": {
                "iterations_requested": args.iterations,
                "inner_time_limit": args.inner_time_limit,
                "threads": args.threads,
                "initial_rho": args.rho,
                "rho_min": args.rho_min,
                "rho_max": args.rho_max,
                "box_radius": args.box_radius,
                "serious_ratio": args.serious_ratio,
                "seed": args.seed,
            },
            "best_valid_lower_bound": best_value,
            "best_iteration": best_iteration,
            "improvement_over_full_lp": best_value - float(lp.ObjVal),
            "gap_to_known_upper_bound": (
                args.upper_bound - best_value
            ) / abs(args.upper_bound),
            "iterations_completed": len(records),
            "records": records,
            "wall_runtime_seconds": time.time() - started,
            "notes": [
                "Every reported lower bound comes from a Gurobi OPTIMAL inner-MIP solve.",
                "The bundle master's predicted gain is not itself a valid lower bound.",
                "Equality multipliers are free; >= multipliers are projected to nonnegative and <= multipliers to nonpositive.",
                "This is floating-point solver evidence, not an exact certificate.",
            ],
        }

    checkpoint = build_checkpoint()
    args.output.write_text(
        json.dumps(checkpoint, indent=2) + "\n", encoding="utf-8"
    )

    for iteration in range(1, args.iterations):
        master = gp.Model(f"bundle-master-{iteration}")
        master.Params.OutputFlag = 0
        displacement = []
        for index, (multiplier, sense) in enumerate(zip(center, master_senses)):
            lower = -args.box_radius
            upper = args.box_radius
            if sense == GRB.GREATER_EQUAL:
                lower = max(lower, -multiplier)
            elif sense == GRB.LESS_EQUAL:
                upper = min(upper, -multiplier)
            displacement.append(
                master.addVar(lb=lower, ub=upper, name=f"d_{index}")
            )
        eta = master.addVar(
            lb=-GRB.INFINITY,
            ub=max(0.0, args.upper_bound - center_value),
            name="eta",
        )
        for cut_index, (cut_constant, cut_residual) in enumerate(cuts):
            intercept = (
                cut_constant
                + sum(
                    multiplier * residual
                    for multiplier, residual in zip(center, cut_residual)
                )
                - center_value
            )
            master.addConstr(
                eta
                <= intercept
                + gp.quicksum(
                    residual * variable
                    for residual, variable in zip(cut_residual, displacement)
                    if residual
                ),
                name=f"cut_{cut_index}",
            )
        master.setObjective(
            0.5 * rho * gp.quicksum(variable * variable for variable in displacement)
            - eta,
            GRB.MINIMIZE,
        )
        master.optimize()
        if master.Status != GRB.OPTIMAL:
            raise RuntimeError(f"Bundle master status {master.Status}")
        direction = [float(variable.X) for variable in displacement]
        predicted_gain = float(eta.X)
        direction_norm = math.sqrt(sum(value * value for value in direction))
        candidate = [
            multiplier + delta for multiplier, delta in zip(center, direction)
        ]

        evaluated = solve_inner(candidate, iteration)
        cuts.append((evaluated["original_value"], evaluated["residual"]))
        actual_gain = evaluated["valid_bound"] - center_value
        denominator = max(predicted_gain, 1e-12)
        ratio = actual_gain / denominator
        serious = actual_gain > 1e-6 and ratio >= args.serious_ratio
        if serious:
            center = candidate
            center_value = evaluated["valid_bound"]
        if evaluated["valid_bound"] > best_value + 1e-6:
            best_value = evaluated["valid_bound"]
            best_multipliers = list(candidate)
            best_iteration = iteration
            args.best_multipliers.write_text(
                json.dumps(
                    {
                        "instance": model.ModelName,
                        "iteration": iteration,
                        "valid_lower_bound": best_value,
                        "master_names": master_names,
                        "multipliers": best_multipliers,
                    },
                    indent=2,
                )
                + "\n",
                encoding="utf-8",
            )

        rho_before = rho
        if ratio < 0.1:
            rho = min(args.rho_max, rho * 2.0)
        elif ratio > 0.75:
            rho = max(args.rho_min, rho * 0.7)

        record = {
            "iteration": iteration,
            "step_type": "serious" if serious else "null",
            "valid_lower_bound": evaluated["valid_bound"],
            "best_bound_so_far": best_value,
            "center_bound": center_value,
            "improvement_over_full_lp": best_value - float(lp.ObjVal),
            "predicted_gain": predicted_gain,
            "actual_gain_from_center": actual_gain,
            "actual_to_predicted_ratio": ratio,
            "direction_l2": direction_norm,
            "master_residual_l2": math.sqrt(
                sum(value * value for value in evaluated["residual"])
            ),
            "master_residual_max_abs": max(
                abs(value) for value in evaluated["residual"]
            ),
            "rho_used": rho_before,
            "rho_next": rho,
            "bundle_cuts": len(cuts),
            "nodes": evaluated["nodes"],
            "runtime_seconds": evaluated["runtime_seconds"],
            "assembly_error": evaluated["assembly_error"],
        }
        records.append(record)
        checkpoint = build_checkpoint()
        args.output.write_text(
            json.dumps(checkpoint, indent=2) + "\n", encoding="utf-8"
        )
        print(json.dumps(record), flush=True)

        if predicted_gain <= 1e-7 and direction_norm <= 1e-7:
            break

    print(json.dumps(checkpoint, indent=2))


if __name__ == "__main__":
    main()
