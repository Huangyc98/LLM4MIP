from __future__ import annotations

import argparse
import gzip
import json
import time
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def apply_sparse_start(model: gp.Model, path: Path, round_integers: bool) -> dict:
    opener = gzip.open if path.suffix == ".gz" else open
    assigned = 0
    missing = 0
    rounded = 0
    # MIPLIB solution files are sparse: every omitted variable is exactly zero.
    # Initialize the entire vector so Gurobi receives a complete, reproducible
    # start instead of trying to complete tens of thousands of unspecified vars.
    for var in model.getVars():
        var.Start = 0.0
    with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
        for line in handle:
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) < 2:
                continue
            if parts[0].lower() == "=obj=":
                continue
            try:
                value = float(parts[1])
            except ValueError:
                continue
            var = model.getVarByName(parts[0])
            if var is None:
                missing += 1
                continue
            if round_integers and var.VType in (GRB.BINARY, GRB.INTEGER, GRB.SEMIINT):
                new_value = float(round(value))
                rounded += new_value != value
                value = new_value
            var.Start = value
            assigned += 1
    return {
        "solution_file_values": assigned,
        "variables_explicitly_initialized": model.NumVars,
        "missing_names": missing,
        "rounded_values": rounded,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", type=Path, required=True)
    parser.add_argument("--solution", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--time-limit", type=float, default=300.0)
    parser.add_argument("--threads", type=int, default=8)
    parser.add_argument("--mip-focus", type=int, default=3)
    parser.add_argument("--cuts", type=int, default=2)
    parser.add_argument("--heuristics", type=float)
    parser.add_argument("--no-rel-heur-time", type=float)
    parser.add_argument("--node-limit", type=float)
    parser.add_argument("--symmetry", type=int)
    parser.add_argument("--rins", type=int)
    parser.add_argument("--sub-mip-nodes", type=int)
    parser.add_argument("--concurrent-mip", type=int)
    parser.add_argument("--seed", type=int)
    parser.add_argument("--mip-gap", type=float)
    parser.add_argument("--round-integers", action="store_true")
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.log.parent.mkdir(parents=True, exist_ok=True)
    wall_started = time.time()
    model = gp.read(str(args.mps))
    model.Params.TimeLimit = args.time_limit
    model.Params.Threads = args.threads
    model.Params.MIPFocus = args.mip_focus
    model.Params.Presolve = 2
    model.Params.Cuts = args.cuts
    model.Params.LogFile = str(args.log)
    if args.node_limit is not None:
        model.Params.NodeLimit = args.node_limit
    if args.symmetry is not None:
        model.Params.Symmetry = args.symmetry
    if args.rins is not None:
        model.Params.RINS = args.rins
    if args.sub_mip_nodes is not None:
        model.Params.SubMIPNodes = args.sub_mip_nodes
    if args.concurrent_mip is not None:
        model.Params.ConcurrentMIP = args.concurrent_mip
    if args.seed is not None:
        model.Params.Seed = args.seed
    if args.mip_gap is not None:
        model.Params.MIPGap = args.mip_gap
    if args.heuristics is not None:
        model.Params.Heuristics = args.heuristics
    if args.no_rel_heur_time is not None:
        model.Params.NoRelHeurTime = args.no_rel_heur_time

    start_info = None
    if args.solution:
        start_info = apply_sparse_start(model, args.solution, args.round_integers)

    model.optimize()
    report = {
        "instance": model.ModelName,
        "parameters": {
            "time_limit": args.time_limit,
            "threads": args.threads,
            "mip_focus": args.mip_focus,
            "heuristics": args.heuristics,
            "no_rel_heur_time": args.no_rel_heur_time,
            "node_limit": args.node_limit,
            "symmetry": args.symmetry,
            "rins": args.rins,
            "sub_mip_nodes": args.sub_mip_nodes,
            "concurrent_mip": args.concurrent_mip,
            "seed": args.seed,
            "mip_gap": args.mip_gap,
            "presolve": 2,
            "cuts": args.cuts,
        },
        "start": start_info,
        "status": int(model.Status),
        "status_name": {
            GRB.OPTIMAL: "OPTIMAL",
            GRB.INFEASIBLE: "INFEASIBLE",
            GRB.INF_OR_UNBD: "INF_OR_UNBD",
            GRB.UNBOUNDED: "UNBOUNDED",
            GRB.TIME_LIMIT: "TIME_LIMIT",
            GRB.NODE_LIMIT: "NODE_LIMIT",
            GRB.INTERRUPTED: "INTERRUPTED",
        }.get(model.Status, "OTHER"),
        "solution_count": int(model.SolCount),
        "objective": float(model.ObjVal) if model.SolCount else None,
        "best_bound": float(model.ObjBound) if model.IsMIP else None,
        "relative_gap": float(model.MIPGap) if model.IsMIP and model.SolCount else None,
        "node_count": float(model.NodeCount) if model.IsMIP else None,
        "simplex_iterations": float(model.IterCount),
        "barrier_iterations": int(model.BarIterCount),
        "solver_runtime_seconds": float(model.Runtime),
        "wall_runtime_seconds": time.time() - wall_started,
        "work_units": float(model.Work),
    }
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
