from __future__ import annotations

import argparse
import gzip
import json
import math
import time
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


STATUS_NAMES = {
    GRB.LOADED: "LOADED",
    GRB.OPTIMAL: "OPTIMAL",
    GRB.INFEASIBLE: "INFEASIBLE",
    GRB.INF_OR_UNBD: "INF_OR_UNBD",
    GRB.UNBOUNDED: "UNBOUNDED",
    GRB.CUTOFF: "CUTOFF",
    GRB.ITERATION_LIMIT: "ITERATION_LIMIT",
    GRB.NODE_LIMIT: "NODE_LIMIT",
    GRB.TIME_LIMIT: "TIME_LIMIT",
    GRB.SOLUTION_LIMIT: "SOLUTION_LIMIT",
    GRB.INTERRUPTED: "INTERRUPTED",
    GRB.NUMERIC: "NUMERIC",
    GRB.SUBOPTIMAL: "SUBOPTIMAL",
    GRB.WORK_LIMIT: "WORK_LIMIT",
    GRB.MEM_LIMIT: "MEM_LIMIT",
}


def load_full_start(model: gp.Model, solution_path: Path) -> dict:
    """Load a sparse MIPLIB solution as a complete zero-filled Gurobi start."""
    variables = model.getVars()
    for var in variables:
        var.Start = 0.0

    by_name = {var.VarName: var for var in variables}
    opener = gzip.open if solution_path.suffix == ".gz" else open
    assigned = 0
    rounded = 0
    missing_names: list[str] = []
    metadata_lines = 0
    declared_objective = None

    with opener(solution_path, "rt", encoding="utf-8", errors="replace") as handle:
        for raw_line in handle:
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if parts[0] == "=" or parts[0].startswith("="):
                metadata_lines += 1
                for token in reversed(parts):
                    try:
                        declared_objective = float(token)
                        break
                    except ValueError:
                        continue
                continue
            if len(parts) < 2:
                continue
            try:
                value = float(parts[1])
            except ValueError:
                continue
            var = by_name.get(parts[0])
            if var is None:
                if len(missing_names) < 20:
                    missing_names.append(parts[0])
                continue
            if var.VType in (GRB.BINARY, GRB.INTEGER, GRB.SEMIINT):
                rounded_value = float(round(value))
                rounded += int(rounded_value != value)
                value = rounded_value
            var.Start = value
            assigned += 1

    return {
        "zero_filled_variables": len(variables),
        "explicit_values": assigned,
        "metadata_lines": metadata_lines,
        "declared_objective": declared_objective,
        "rounded_integer_values": rounded,
        "missing_name_count": len(missing_names),
        "missing_name_examples": missing_names,
    }


def safe_attr(model: gp.Model, attr: str):
    try:
        value = getattr(model, attr)
    except (AttributeError, gp.GurobiError):
        return None
    if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
        return None
    return value


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", type=Path, required=True)
    parser.add_argument("--solution", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--best-solution", type=Path)
    parser.add_argument("--time-limit", type=float, default=2400.0)
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--seed", type=int, default=1701)
    parser.add_argument("--mip-focus", type=int, default=3)
    parser.add_argument("--cuts", type=int, default=3)
    parser.add_argument("--symmetry", type=int, default=2)
    parser.add_argument("--heuristics", type=float, default=0.0)
    parser.add_argument("--presolve", type=int, default=2)
    parser.add_argument("--node-limit", type=float)
    parser.add_argument("--method", type=int)
    parser.add_argument("--node-method", type=int)
    parser.add_argument("--aggregate", type=int, default=2)
    parser.add_argument("--pre-sparsify", type=int, default=2)
    parser.add_argument("--numeric-focus", type=int, default=1)
    parser.add_argument("--result-tag", default="sing17-deep")
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.log.parent.mkdir(parents=True, exist_ok=True)
    if args.best_solution:
        args.best_solution.parent.mkdir(parents=True, exist_ok=True)

    wall_start = time.time()
    model = gp.read(str(args.mps))
    initial_counts = {
        "variables": model.NumVars,
        "constraints": model.NumConstrs,
        "nonzeros": model.NumNZs,
        "integer_variables": model.NumIntVars,
        "binary_variables": model.NumBinVars,
        "continuous_variables": model.NumVars - model.NumIntVars,
    }
    start_info = load_full_start(model, args.solution)

    parameter_values = {
        "TimeLimit": args.time_limit,
        "Threads": args.threads,
        "Seed": args.seed,
        "MIPFocus": args.mip_focus,
        "Cuts": args.cuts,
        "Symmetry": args.symmetry,
        "Heuristics": args.heuristics,
        "Presolve": args.presolve,
        "Aggregate": args.aggregate,
        "PreSparsify": args.pre_sparsify,
        "NumericFocus": args.numeric_focus,
        "NodefileStart": 4.0,
        "LogFile": str(args.log),
    }
    if args.node_limit is not None:
        parameter_values["NodeLimit"] = args.node_limit
    if args.method is not None:
        parameter_values["Method"] = args.method
    if args.node_method is not None:
        parameter_values["NodeMethod"] = args.node_method
    for name, value in parameter_values.items():
        setattr(model.Params, name, value)

    progress: list[dict] = []
    last_record_time = -math.inf

    def callback(cb_model: gp.Model, where: int) -> None:
        nonlocal last_record_time
        if where != GRB.Callback.MIP:
            return
        runtime = cb_model.cbGet(GRB.Callback.RUNTIME)
        if runtime - last_record_time < 30.0:
            return
        last_record_time = runtime
        progress.append(
            {
                "runtime": float(runtime),
                "nodes": float(cb_model.cbGet(GRB.Callback.MIP_NODCNT)),
                "solutions": int(cb_model.cbGet(GRB.Callback.MIP_SOLCNT)),
                "incumbent": float(cb_model.cbGet(GRB.Callback.MIP_OBJBST)),
                "bound": float(cb_model.cbGet(GRB.Callback.MIP_OBJBND)),
                "open_nodes": float(cb_model.cbGet(GRB.Callback.MIP_NODLFT)),
            }
        )

    model.optimize(callback)

    if args.best_solution and model.SolCount:
        model.write(str(args.best_solution))

    result = {
        "experiment": args.result_tag,
        "instance": model.ModelName,
        "source_model": str(args.mps),
        "source_solution": str(args.solution),
        "initial_counts": initial_counts,
        "start": start_info,
        "parameters": parameter_values,
        "status": int(model.Status),
        "status_name": STATUS_NAMES.get(model.Status, "OTHER"),
        "solution_count": int(model.SolCount),
        "objective": safe_attr(model, "ObjVal") if model.SolCount else None,
        "best_bound": safe_attr(model, "ObjBound") if model.IsMIP else None,
        "relative_gap": safe_attr(model, "MIPGap") if model.IsMIP and model.SolCount else None,
        "node_count": safe_attr(model, "NodeCount"),
        "simplex_iterations": safe_attr(model, "IterCount"),
        "barrier_iterations": safe_attr(model, "BarIterCount"),
        "solver_runtime_seconds": safe_attr(model, "Runtime"),
        "wall_runtime_seconds": time.time() - wall_start,
        "work_units": safe_attr(model, "Work"),
        "max_constraint_violation": safe_attr(model, "ConstrVio") if model.SolCount else None,
        "max_bound_violation": safe_attr(model, "BoundVio") if model.SolCount else None,
        "max_integrality_violation": safe_attr(model, "IntVio") if model.SolCount else None,
        "progress": progress,
    }
    args.output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
