from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict, deque
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def coeff_key(value: float) -> float:
    return round(value, 9)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    model = gp.read(str(args.mps))
    model.update()
    variables = model.getVars()
    constraints = model.getConstrs()
    index = {var.VarName: i for i, var in enumerate(variables)}

    coarse_signatures: Counter[tuple] = Counter()
    ordered_coarse: list[tuple] = []
    hierarchy_rows = []
    balance_rows = []
    degree2_rows = []
    vbd_rows = []
    parent_counts: Counter[int] = Counter()
    child_counts: Counter[int] = Counter()
    hierarchy_type_signatures: Counter[tuple] = Counter()
    hierarchy_offsets: Counter[tuple] = Counter()

    for row_index, constr in enumerate(constraints):
        row = model.getRow(constr)
        terms = [(index[row.getVar(i).VarName], coeff_key(row.getCoeff(i))) for i in range(row.size())]
        coeffs = tuple(sorted(coef for _, coef in terms))
        types = tuple(sorted(variables[var_index].VType for var_index, _ in terms))
        rhs_zero = abs(constr.RHS) <= 1e-12
        coarse = (constr.Sense, len(terms), coeffs, types, rhs_zero)
        coarse_signatures[coarse] += 1
        ordered_coarse.append(coarse)

        if constr.Sense == GRB.EQUAL and rhs_zero and len(terms) == 3:
            positive = [var_index for var_index, coef in terms if coef == 1.0]
            negative = [var_index for var_index, coef in terms if coef == -1.0]
            if len(positive) == 1 and len(negative) == 2:
                parent = positive[0]
                children = tuple(sorted(negative))
                hierarchy_rows.append((row_index, parent, *children))
                parent_counts[parent] += 1
                child_counts.update(children)
                hierarchy_type_signatures[(variables[parent].VType, *(variables[c].VType for c in children))] += 1
                hierarchy_offsets[(children[0] - parent, children[1] - parent)] += 1
            elif len(positive) == 2 and len(negative) == 1:
                balance_rows.append((row_index, negative[0], *sorted(positive)))

        if constr.Sense == GRB.EQUAL and rhs_zero and len(terms) == 2 and coeffs == (-1.0, 1.0):
            degree2_rows.append((row_index, *(var_index for var_index, _ in sorted(terms))))

        if len(terms) == 2 and constr.Sense in (GRB.LESS_EQUAL, GRB.GREATER_EQUAL):
            term_types = {variables[var_index].VType for var_index, _ in terms}
            if GRB.CONTINUOUS in term_types and (GRB.INTEGER in term_types or GRB.BINARY in term_types):
                vbd_rows.append((row_index, constr.Sense, constr.RHS, terms))

    runs = []
    start = 0
    for i in range(1, len(ordered_coarse) + 1):
        if i == len(ordered_coarse) or ordered_coarse[i] != ordered_coarse[start]:
            if i - start >= 5:
                signature = ordered_coarse[start]
                runs.append({
                    "start_row_1based": start + 1,
                    "end_row_1based": i,
                    "length": i - start,
                    "sense": signature[0],
                    "degree": signature[1],
                    "coefficients": signature[2],
                    "variable_types": signature[3],
                    "rhs_is_zero": signature[4],
                })
            start = i

    graph: dict[int, set[int]] = defaultdict(set)
    directed_children: dict[int, list[int]] = defaultdict(list)
    indegree: Counter[int] = Counter()
    hierarchy_vars = set()
    for _, parent, child1, child2 in hierarchy_rows:
        for child in (child1, child2):
            graph[parent].add(child)
            graph[child].add(parent)
            directed_children[parent].append(child)
            indegree[child] += 1
            hierarchy_vars.add(child)
        hierarchy_vars.add(parent)

    components = []
    unseen = set(hierarchy_vars)
    while unseen:
        seed = unseen.pop()
        queue = deque([seed])
        component = {seed}
        edge_twice = 0
        while queue:
            node = queue.popleft()
            edge_twice += len(graph[node])
            for neighbor in graph[node]:
                if neighbor in unseen:
                    unseen.remove(neighbor)
                    component.add(neighbor)
                    queue.append(neighbor)
        components.append((len(component), edge_twice // 2))

    roots = [node for node in hierarchy_vars if indegree[node] == 0 and node in directed_children]
    leaves = [node for node in hierarchy_vars if node not in directed_children]
    top_components = sorted(components, reverse=True)[:30]

    top_signatures = []
    for signature, count in coarse_signatures.most_common(40):
        top_signatures.append({
            "count": count,
            "sense": signature[0],
            "degree": signature[1],
            "coefficients": signature[2],
            "variable_types": signature[3],
            "rhs_is_zero": signature[4],
        })

    report = {
        "instance": model.ModelName,
        "hierarchy": {
            "parent_equals_two_children_rows": len(hierarchy_rows),
            "two_positive_equals_one_negative_rows": len(balance_rows),
            "variables": len(hierarchy_vars),
            "roots": len(roots),
            "leaves": len(leaves),
            "connected_components": len(components),
            "largest_components_nodes_edges": top_components,
            "parents_used_more_than_once": sum(count > 1 for count in parent_counts.values()),
            "children_with_multiple_parents": sum(count > 1 for count in child_counts.values()),
            "all_parent_indices_before_children": all(parent < child1 and parent < child2 for _, parent, child1, child2 in hierarchy_rows),
            "type_signatures": [
                {"types": signature, "count": count}
                for signature, count in hierarchy_type_signatures.most_common()
            ],
            "common_child_offsets": [
                {"offsets": offsets, "count": count}
                for offsets, count in hierarchy_offsets.most_common(20)
            ],
        },
        "degree2_equalities": len(degree2_rows),
        "two_term_mixed_vbd_rows": len(vbd_rows),
        "top_row_signatures": top_signatures,
        "long_consecutive_row_runs": sorted(runs, key=lambda item: item["length"], reverse=True)[:60],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
