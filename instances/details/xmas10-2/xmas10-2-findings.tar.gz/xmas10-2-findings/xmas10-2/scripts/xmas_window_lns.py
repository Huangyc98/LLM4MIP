#!/usr/bin/env python3
"""
Rectangular large-neighborhood search for xmas10-2.

The input is the public sparse Gurobi solution.  Variables omitted from the
solution are zero.  The script uses no solver and no external packages.

For each rectangular window, cells outside the window remain fixed.  A
row-mask backtracking search replaces all cells inside the window, enforces:
  * exact degrees of all exterior selected cells adjacent to the window;
  * selected-cell degree 2 internally, except cells 0 and 899 have degree 1;
  * every 2x2 block intersecting the window has at most three selected cells;
  * endpoints remain selected.

The local search uses row masks, early degree/2x2 rejection, an admissible
suffix-cardinality bound, node/candidate caps, and a full global path audit
before accepting any candidate.

Usage:
  python3 xmas10_2_rect_search.py xmas10-2.sol.gz 1200 xmas10-2-local
"""

import argparse
import gzip
import json
import os
import random
import re
import sys
import time


N = 30
TOTAL = N * N
START = 0
END = TOTAL - 1
CHECKPOINT_SECONDS = 20.0
WINDOW_NODE_CAP = 140000
WINDOW_CANDIDATE_CAP = 1200
SEED = 20251225


def cell_id(r, c):
    return r * N + c


def rc(v):
    return divmod(v, N)


def adjacent(v):
    r, c = rc(v)
    out = []
    if r:
        out.append(v - N)
    if r + 1 < N:
        out.append(v + N)
    if c:
        out.append(v - 1)
    if c + 1 < N:
        out.append(v + 1)
    return out


NEIGHBORS = [adjacent(v) for v in range(TOTAL)]


def open_text(path):
    return gzip.open(path, "rt") if path.endswith(".gz") else open(path, "rt")


def parse_solution(path):
    """
    Parse sparse Gurobi .sol lines, tolerating comments/annotations.

    Valid variable lines begin with C<integer> followed by a numeric value.
    Omitted C variables are treated as zero.
    """
    values = [0.0] * TOTAL
    pat = re.compile(
        r"^\s*(C([0-9]{1,4}))\s+"
        r"([-+]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][-+]?[0-9]+)?)"
        r"(?:\s|$)"
    )
    seen = set()
    with open_text(path) as f:
        for raw in f:
            match = pat.match(raw)
            if not match:
                continue
            idx = int(match.group(2))
            if idx >= TOTAL:
                continue
            values[idx] = float(match.group(3))
            seen.add(idx)

    selected = set()
    fractional = []
    for i, value in enumerate(values):
        if abs(value) <= 1e-8:
            continue
        if abs(value - 1.0) <= 1e-8:
            selected.add(i)
        else:
            fractional.append([i, value])

    if fractional:
        raise RuntimeError("non-binary C values in input: %r" % fractional[:10])
    return selected, sorted(seen)


def bitmap(selected):
    return "\n".join(
        "".join("#" if cell_id(r, c) in selected else "." for c in range(N))
        for r in range(N)
    )


def ordered_path(selected):
    if START not in selected or END not in selected:
        return None
    order = [START]
    previous = -1
    current = START
    while current != END:
        options = [
            nxt for nxt in NEIGHBORS[current]
            if nxt in selected and nxt != previous
        ]
        if len(options) != 1:
            return None
        previous, current = current, options[0]
        if current in order:
            return None
        order.append(current)
        if len(order) > len(selected):
            return None
    return order if len(order) == len(selected) else None


def audit(selected, require_497=False, fixed=None):
    selected = set(selected)
    fixed = fixed or {}
    degree = {
        v: sum(w in selected for w in NEIGHBORS[v])
        for v in selected
    }
    endpoint_degree_ok = (
        START in selected and END in selected
        and degree.get(START) == 1
        and degree.get(END) == 1
    )
    internal_bad = [
        v for v in selected
        if v not in (START, END) and degree[v] != 2
    ]
    endpoint_bad = [
        v for v in (START, END)
        if v not in selected or degree.get(v) != 1
    ]

    reached = set()
    if START in selected:
        stack = [START]
        reached.add(START)
        while stack:
            v = stack.pop()
            for w in NEIGHBORS[v]:
                if w in selected and w not in reached:
                    reached.add(w)
                    stack.append(w)

    filled_squares = []
    for r in range(N - 1):
        for c in range(N - 1):
            sq = {
                cell_id(r, c), cell_id(r + 1, c),
                cell_id(r, c + 1), cell_id(r + 1, c + 1),
            }
            if sq.issubset(selected):
                filled_squares.append([r, c])

    order = ordered_path(selected)
    fixed_violations = sorted(
        v for v, value in fixed.items() if int(v in selected) != value
    )
    valid = (
        endpoint_degree_ok
        and not internal_bad
        and len(reached) == len(selected)
        and not filled_squares
        and not fixed_violations
        and order is not None
    )
    if require_497:
        valid = valid and len(selected) == 497

    return {
        "valid": valid,
        "selected_count": len(selected),
        "start_selected": START in selected,
        "end_selected": END in selected,
        "endpoint_degree_ok": endpoint_degree_ok,
        "endpoint_bad_cells": endpoint_bad,
        "internal_degree_bad_cells": internal_bad,
        "connected": len(reached) == len(selected),
        "reachable_count_from_C0": len(reached),
        "filled_2x2_blocks": filled_squares,
        "fixed_cell_violation_count": len(fixed_violations),
        "fixed_cell_violations": fixed_violations,
        "ordered_path": order,
    }


class WindowSearch:
    """
    Search one physical rectangle, optionally transposed internally so the
    mask width is min(height, width).
    """

    def __init__(self, incumbent, fixed, r0, c0, height, width, deadline, rng):
        self.old = incumbent
        self.fixed = fixed
        self.r0 = r0
        self.c0 = c0
        self.ph = height
        self.pw = width
        self.transposed = width > height
        self.h = width if self.transposed else height
        self.w = height if self.transposed else width
        self.deadline = deadline
        self.rng = rng
        self.window_cells = {
            cell_id(r, c)
            for r in range(r0, r0 + height)
            for c in range(c0, c0 + width)
        }
        self.old_inside = len(self.old & self.window_cells)
        self.nodes = 0
        self.completed = 0
        self.cutoff = False
        self.pruned_bound = 0
        self.pruned_local = 0
        self.best = None
        self.forced = {}
        self.allowed = []
        self.row_max = []
        self.suffix = []

    def physical(self, rr, cc):
        if self.transposed:
            return self.r0 + cc, self.c0 + rr
        return self.r0 + rr, self.c0 + cc

    def oriented_from_physical(self, r, c):
        if self.transposed:
            return c - self.c0, r - self.r0
        return r - self.r0, c - self.c0

    def inside_oriented(self, rr, cc):
        return 0 <= rr < self.h and 0 <= cc < self.w

    def value(self, rr, cc, masks):
        """Candidate value inside; fixed incumbent value outside."""
        r, c = self.physical(rr, cc)
        if not (0 <= r < N and 0 <= c < N):
            return 0
        if self.inside_oriented(rr, cc):
            if rr >= len(masks):
                raise RuntimeError("attempted to inspect unassigned row")
            return (masks[rr] >> cc) & 1
        return int(cell_id(r, c) in self.old)

    def prepare_forced_boundary(self):
        """
        Every exterior selected cell has a fixed required total degree.  Its
        selected neighbours outside the window determine exactly how many
        neighbouring window cells must be selected.
        """
        forced = {}
        for q in self.old - self.window_cells:
            inside_neighbors = [p for p in NEIGHBORS[q] if p in self.window_cells]
            if not inside_neighbors:
                continue
            required = 1 if q in (START, END) else 2
            outside_degree = sum(
                p in self.old and p not in self.window_cells
                for p in NEIGHBORS[q]
            )
            needed = required - outside_degree
            if needed < 0 or needed > len(inside_neighbors):
                return False
            if len(inside_neighbors) == 1:
                p = inside_neighbors[0]
                value = needed
                old_value = forced.get(p)
                if old_value is not None and old_value != value:
                    return False
                forced[p] = value
            else:
                # This cannot occur for a conventional rectangle, but retain
                # correctness by rejecting the unsupported multi-port form.
                return False

        for endpoint in (START, END):
            if endpoint in self.window_cells:
                old_value = forced.get(endpoint)
                if old_value is not None and old_value != 1:
                    return False
                forced[endpoint] = 1

        for cell, value in self.fixed.items():
            if cell not in self.window_cells:
                continue
            old_value = forced.get(cell)
            if old_value is not None and old_value != value:
                return False
            forced[cell] = value

        self.forced = forced
        return True

    def make_allowed_masks(self):
        self.allowed = []
        self.row_max = []
        for rr in range(self.h):
            fixed_one = 0
            fixed_zero = 0
            for cc in range(self.w):
                r, c = self.physical(rr, cc)
                v = cell_id(r, c)
                forced = self.forced.get(v)
                if forced == 1:
                    fixed_one |= 1 << cc
                elif forced == 0:
                    fixed_zero |= 1 << cc
            masks = [
                mask for mask in range(1 << self.w)
                if (mask & fixed_one) == fixed_one and not (mask & fixed_zero)
            ]
            # Dense masks first; deterministic random ordering breaks repeated
            # structural ties without changing reproducibility.
            self.rng.shuffle(masks)
            masks.sort(key=int.bit_count, reverse=True)
            if not masks:
                return False
            self.allowed.append(masks)
            self.row_max.append(max(mask.bit_count() for mask in masks))

        self.suffix = [0] * (self.h + 1)
        for rr in range(self.h - 1, -1, -1):
            self.suffix[rr] = self.suffix[rr + 1] + self.row_max[rr]
        return True

    def valid_square_pair(self, upper_rr, lower_rr, masks):
        """
        Check all 2x2 blocks between two oriented adjacent rows, including
        side halos.  At a physical boundary, nonexistent blocks are skipped.
        """
        for cc in range(-1, self.w):
            cells = [
                self.physical(upper_rr, cc),
                self.physical(upper_rr, cc + 1),
                self.physical(lower_rr, cc),
                self.physical(lower_rr, cc + 1),
            ]
            if any(not (0 <= r < N and 0 <= c < N) for r, c in cells):
                continue
            if sum(
                self.value(rr, col, masks)
                for rr, col in (
                    (upper_rr, cc), (upper_rr, cc + 1),
                    (lower_rr, cc), (lower_rr, cc + 1),
                )
            ) == 4:
                return False
        return True

    def valid_degree_row(self, rr, masks):
        for cc in range(self.w):
            r, c = self.physical(rr, cc)
            v = cell_id(r, c)
            if not self.value(rr, cc, masks):
                continue
            degree = (
                self.value(rr - 1, cc, masks)
                + self.value(rr + 1, cc, masks)
                + self.value(rr, cc - 1, masks)
                + self.value(rr, cc + 1, masks)
            )
            required = 1 if v in (START, END) else 2
            if degree != required:
                return False
        return True

    def locally_valid_after_append(self, masks):
        rr = len(masks) - 1
        if rr == 0:
            if not self.valid_square_pair(-1, 0, masks):
                return False
        else:
            if not self.valid_square_pair(rr - 1, rr, masks):
                return False
            if not self.valid_degree_row(rr - 1, masks):
                return False
        return True

    def finish_local_valid(self, masks):
        return (
            self.valid_square_pair(self.h - 1, self.h, masks)
            and self.valid_degree_row(self.h - 1, masks)
        )

    def candidate_selected(self, masks):
        selected = set(self.old - self.window_cells)
        for rr, mask in enumerate(masks):
            for cc in range(self.w):
                if (mask >> cc) & 1:
                    r, c = self.physical(rr, cc)
                    selected.add(cell_id(r, c))
        return selected

    def search(self):
        if not self.prepare_forced_boundary() or not self.make_allowed_masks():
            return None

        # An admissible cardinality bound: even choosing the maximum-popcount
        # mask in every unassigned row cannot beat the incumbent.
        if self.suffix[0] <= self.old_inside:
            self.pruned_bound += 1
            return None

        masks = []

        def dfs(score):
            if time.monotonic() >= self.deadline:
                self.cutoff = True
                return True
            if self.nodes >= WINDOW_NODE_CAP:
                self.cutoff = True
                return True
            self.nodes += 1
            rr = len(masks)

            if score + self.suffix[rr] <= self.old_inside:
                self.pruned_bound += 1
                return False

            if rr == self.h:
                if not self.finish_local_valid(masks):
                    self.pruned_local += 1
                    return False
                self.completed += 1
                if self.completed > WINDOW_CANDIDATE_CAP:
                    self.cutoff = True
                    return True
                selected = self.candidate_selected(masks)
                if len(selected) <= len(self.old):
                    return False
                report = audit(selected, fixed=self.fixed)
                if report["valid"]:
                    self.best = (selected, report)
                    return True
                return False

            for mask in self.allowed[rr]:
                masks.append(mask)
                if self.locally_valid_after_append(masks):
                    if dfs(score + mask.bit_count()):
                        return True
                else:
                    self.pruned_local += 1
                masks.pop()
            return False

        dfs(0)
        return self.best


def window_specs():
    # Width/height combinations include all 5x5 through 8x8 and 5..8 by 9.
    specs = []
    for h in range(5, 9):
        for w in range(5, 10):
            specs.append((h, w))
    return specs


def make_windows(incumbent, changed):
    """
    Score windows by number of path boundary crossings and by incumbent
    sparsity.  Windows overlapping the most recent successful move are first.
    """
    entries = []
    changed = set(changed)
    for h, w in window_specs():
        for r0 in range(N - h + 1):
            for c0 in range(N - w + 1):
                cells = {
                    cell_id(r, c)
                    for r in range(r0, r0 + h)
                    for c in range(c0, c0 + w)
                }
                ports = 0
                for v in incumbent & cells:
                    ports += sum(n not in cells and n in incumbent for n in NEIGHBORS[v])
                overlap = len(cells & changed)
                inside = len(cells & incumbent)
                # More ports make rewiring useful; lower density leaves room.
                score = (overlap * 10000) + ports * 100 - inside
                entries.append((-score, r0, c0, h, w))
    entries.sort()
    return [(r0, c0, h, w) for _, r0, c0, h, w in entries]


def write_outputs(prefix, selected, start_selected, fixed, producing_window, stats, elapsed, terminated):
    report = audit(selected, fixed=fixed)
    added = sorted(selected - start_selected)
    removed = sorted(start_selected - selected)
    result = {
        "instance": "xmas10-2",
        "method": "rectangular_row_mask_segment_replacement",
        "seed": SEED,
        "elapsed_seconds": elapsed,
        "terminated_by_wall_time": terminated,
        "selected_count": len(selected),
        "starting_selected_count": len(start_selected),
        "fixed_cell_count": len(fixed),
        "improvement": len(selected) - len(start_selected),
        "producing_window": producing_window,
        "added_cells_from_public_solution": added,
        "removed_cells_from_public_solution": removed,
        "audit": report,
        "windows_attempted": stats["attempted"],
        "windows_exhausted": stats["exhausted"],
        "windows_cut_off": stats["cutoff"],
        "windows_pruned_by_cardinality_bound": stats["bound_pruned"],
        "local_rejections": stats["local_pruned"],
        "backtracking_nodes": stats["nodes"],
        "completed_local_candidates": stats["completed"],
    }
    with open(prefix + ".json", "w", encoding="ascii") as f:
        json.dump(result, f, indent=2, sort_keys=True)
        f.write("\n")
    with open(prefix + ".txt", "w", encoding="ascii") as f:
        f.write(bitmap(selected))
        f.write("\n")
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("solution_gz")
    parser.add_argument("max_wall_seconds", nargs="?", type=float, default=1200.0)
    parser.add_argument("output_prefix", nargs="?", default="xmas10-2-local")
    parser.add_argument("--fixed-cells", required=True,
                        help="JSON mapping cell indices to fixed 0/1 values")
    args = parser.parse_args()

    if args.max_wall_seconds <= 0:
        raise SystemExit("max_wall_seconds must be positive")

    started = time.monotonic()
    deadline = started + args.max_wall_seconds
    rng = random.Random(SEED)

    original, seen = parse_solution(args.solution_gz)
    with open(args.fixed_cells, "rt", encoding="ascii") as source:
        fixed_text = source.read()
        fixed_payload = json.loads(fixed_text[fixed_text.index("{"):])
        fixed = {int(k): int(v) for k, v in fixed_payload.items()}
    if any(v < 0 or v >= TOTAL or value not in (0, 1) for v, value in fixed.items()):
        raise SystemExit("invalid fixed-cell JSON")
    initial_audit = audit(original, require_497=True, fixed=fixed)
    if not initial_audit["valid"]:
        raise SystemExit(
            "input is not the required audited 497-cell C0-to-C899 path:\n%s"
            % json.dumps(initial_audit, indent=2)
        )

    incumbent = set(original)
    producing_window = None
    changed_for_priority = set()
    stats = {
        "attempted": 0,
        "exhausted": 0,
        "cutoff": 0,
        "bound_pruned": 0,
        "local_pruned": 0,
        "nodes": 0,
        "completed": 0,
    }
    next_checkpoint = started + CHECKPOINT_SECONDS
    terminated = False

    while time.monotonic() < deadline:
        improved_this_round = False
        windows = make_windows(incumbent, changed_for_priority)

        for r0, c0, h, w in windows:
            if time.monotonic() >= deadline:
                terminated = True
                break

            search = WindowSearch(
                incumbent, fixed, r0, c0, h, w, deadline, rng
            )
            stats["attempted"] += 1
            found = search.search()
            stats["bound_pruned"] += search.pruned_bound
            stats["local_pruned"] += search.pruned_local
            stats["nodes"] += search.nodes
            stats["completed"] += search.completed
            if search.cutoff:
                stats["cutoff"] += 1
            else:
                stats["exhausted"] += 1

            if found is not None:
                candidate, report = found
                old = incumbent
                incumbent = candidate
                changed_for_priority = old ^ incumbent
                producing_window = {
                    "row0": r0,
                    "column0": c0,
                    "height": h,
                    "width": w,
                    "transposed_for_masks": search.transposed,
                    "nodes": search.nodes,
                    "completed_local_candidates": search.completed,
                }
                write_outputs(
                    args.output_prefix, incumbent, original, fixed, producing_window,
                    stats, time.monotonic() - started, False
                )
                print(
                    "improvement: %d cells via window r=%d c=%d h=%d w=%d"
                    % (len(incumbent), r0, c0, h, w),
                    flush=True,
                )
                improved_this_round = True
                break

            if time.monotonic() >= next_checkpoint:
                write_outputs(
                    args.output_prefix, incumbent, original, fixed, producing_window,
                    stats, time.monotonic() - started, False
                )
                next_checkpoint = time.monotonic() + CHECKPOINT_SECONDS

        if terminated:
            break
        if not improved_this_round:
            # All scheduled windows were searched or safely capped. Repeat in
            # another deterministic shuffled tie order only while time remains.
            changed_for_priority = set()
            rng.seed(SEED + stats["attempted"])

    if time.monotonic() >= deadline:
        terminated = True

    result = write_outputs(
        args.output_prefix, incumbent, original, fixed, producing_window,
        stats, time.monotonic() - started, terminated
    )
    print(json.dumps({
        "selected_count": result["selected_count"],
        "improvement": result["improvement"],
        "terminated_by_wall_time": result["terminated_by_wall_time"],
        "json": os.path.abspath(args.output_prefix + ".json"),
        "bitmap": os.path.abspath(args.output_prefix + ".txt"),
    }, indent=2))


if __name__ == "__main__":
    main()
