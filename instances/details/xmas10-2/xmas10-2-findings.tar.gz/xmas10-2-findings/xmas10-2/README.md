# xmas10-2

Status: **best known feasible value reproduced; global optimum still open**.

The audited path has 497 selected cells (MPS objective **-497**). No longer
path was found, and the official cardinality interval remains 497--511.

[MIPLIB instance page](https://miplib.zib.de/instance_details_xmas10-2.html)

## Exact projection

The formulation encodes a 30-by-30 grid puzzle using 900 binary cell variables
and 7,200 continuous flow variables. Exact row inspection recovered:

- 841 constraints forbidding a fully selected 2-by-2 square;
- 898 lower and 898 upper local-degree constraints;
- two fixed path endpoints, `C0` and `C899`; and
- 192 cells fixed to zero or one as puzzle clues.

The 7,200 artificial flow variables were removed to obtain a cell-only search.
Connectivity was enforced by lazy component/cycle cuts. A selected-cell pattern
was accepted only after reconstruction in the original continuous-flow
subsystem and a full original-model audit.

The exact projection retained all 2,663 cell-only rows. After 1,739.7 seconds,
it still had a 497-cell path and numerical upper bound 515; the official 511
bound is stronger. The reconstructed original solution has zero row and bound
violations.

## Solver-free neighborhood search

A separate rectangular row-mask search exhaustively replaced path segments in
prioritized windows while enforcing the clues, exact degrees, crossing 2-by-2
constraints, and a final global path audit. In 1,200 seconds it attempted 795
windows, exhausted 793, visited 2,129,396 backtracking nodes, and found no
improvement. This is strong local evidence, not a global certificate.

Scripts are under `scripts/`, structured outputs under `artifacts/`, raw traces
under `logs/`, and the reconstructed witness under `solutions/`.

This was a five-turn direct-API investigation using 92,788 tokens. Raw API
conversations and credentials are excluded.

SHA-256:

- MPS: `6D47C225FCEF5745DB70FD0F6ADBEAFC6A0B23F6EDBD253BE895C16042E5EE45`
- public solution: `26D107B9B6149D7F1A733962106C8DFDDA07A59A15ECBAAA37807F92BA5687C2`
- reconstructed solution: `48CC5DA9738F2CD1B2BC22C05B97D711BAFCE8D0DD4B6A5F73450672AEEA2398`
