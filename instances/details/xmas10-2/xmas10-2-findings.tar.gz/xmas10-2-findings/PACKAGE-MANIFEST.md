# Package manifest: xmas10-2

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 13
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/fixed_cells.json`
- `artifacts/lns-result.json`
- `artifacts/result.json`
- `artifacts/structure.json`
- `logs/cell-projection.log`
- `logs/window-lns.log`
- `scripts/extract_fixed_cells.py`
- `scripts/extract_grid.py`
- `scripts/solve_xmas10_2.py`
- `scripts/xmas_window_lns.py`
- `solutions/xmas10-2-public-3.sol.gz`
- `solutions/xmas10-2-reconstructed.sol`

## Excluded files

- `input/xmas10-2.mps.gz (190983 bytes; raw benchmark input; sha256 6d47c225fcef5745db70fd0f6adbeafc6a0b23f6edbd253be895c16042e5ee45)`
