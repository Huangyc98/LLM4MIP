#!/usr/bin/env python3
import argparse, gzip, json, os, sys, time
from collections import defaultdict, Counter, deque
import gurobipy as gp


def die(msg):
    raise SystemExit("ERROR: " + msg)


def parse_solution(path):
    if not path:
        return {}
    ans = {}
    opener = gzip.open if str(path).endswith(".gz") else open
    kwargs = {"mode": "rt", "errors": "replace"} if opener is gzip.open else {"mode": "r", "errors": "replace"}
    with opener(path, **kwargs) as f:
        for line in f:
            s = line.strip()
            if not s or s.startswith("#") or s.startswith("="):
                continue
            p = s.split()
            if len(p) >= 2:
                try:
                    ans[p[0]] = float(p[1])
                except ValueError:
                    pass
    return ans


def write_opb(path, names, edges, target):
    names = list(names)
    with open(path, "w") as f:
        f.write("* #variable= %d #constraint= %d\n" %
                (len(names), len(edges) + 1))
        f.write("* decision form: independent set cardinality at least %d\n" %
                target)
        if names:
            f.write(" + ".join("1 %s" % x for x in names))
        else:
            f.write("0")
        f.write(" >= %d;\n" % target)
        for a, b in edges:
            f.write("1 %s + 1 %s <= 1;\n" % (a, b))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mps", required=True)
    ap.add_argument("--sol")
    ap.add_argument("--out", default="z26_forensic")
    ap.add_argument("--target-size", type=int, default=1199)
    ap.add_argument("--reduction-seconds", type=float, default=120.0)
    args = ap.parse_args()

    model = gp.read(args.mps)          # read-only: no optimize/presolve
    vs = model.getVars()
    rows = model.getConstrs()
    n = len(vs)

    # Gurobi may expose MPS BV columns as integer variables with [0,1]
    # bounds.  Algebraically these are binary and are accepted explicitly.
    if any(v.VType not in (gp.GRB.BINARY, gp.GRB.INTEGER, "B", "b", "I")
           or float(v.LB) != 0.0 or float(v.UB) != 1.0 for v in vs):
        die("not all variables are binary or [0,1] integer variables")
    if any(float(v.Obj) != -1.0 for v in vs):
        die("objective is not exactly -sum(x)")
    if model.ModelSense != gp.GRB.MINIMIZE:
        die("model is not a minimization model")

    vid = {v.VarName: i for i, v in enumerate(vs)}
    supports = []
    row_meta = []
    unsupported = []
    for r in rows:
        expr = model.getRow(r)
        ss = []
        good = (r.Sense in ("<", gp.GRB.LESS_EQUAL) and
                float(r.RHS) == 1.0)
        for j in range(expr.size()):
            v, c = expr.getVar(j), float(expr.getCoeff(j))
            if c == 0.0:
                continue
            if c != 1.0 or v.VarName not in vid:
                good = False
            else:
                ss.append(vid[v.VarName])
        ss = tuple(sorted(set(ss)))
        if not good:
            unsupported.append(r.ConstrName)
        supports.append(ss)
        row_meta.append({
            "name": r.ConstrName,
            "family": r.ConstrName[:1],
            "support": [vs[i].VarName for i in ss],
            "degree": len(ss)
        })
    if unsupported:
        die("rows not algebraically normalizable to sum(S)x <= 1: " +
            ",".join(unsupported[:10]))

    # Exact row families and partition audit.
    E = [supports[i] for i, r in enumerate(rows)
         if r.ConstrName.startswith("E")]
    K = [supports[i] for i, r in enumerate(rows)
         if r.ConstrName.startswith("K")]
    nonempty_K = [s for s in K if s]
    flat = [i for s in nonempty_K for i in s]
    partition = (len(flat) == n and len(set(flat)) == n)
    k_owner = {}
    if partition:
        for g, s in enumerate(nonempty_K):
            for i in s:
                k_owner[i] = g

    # Build graph and complete row provenance.
    adj = [set() for _ in range(n)]
    edge_rows = defaultdict(list)
    for ri, s in enumerate(supports):
        if len(s) >= 2:
            for p in range(len(s)):
                for q in range(p + 1, len(s)):
                    a, b = s[p], s[q]
                    if b not in adj[a]:
                        adj[a].add(b); adj[b].add(a)
                    edge_rows["%d,%d" % (a, b)].append(rows[ri].ConstrName)

    sol = parse_solution(args.sol)
    selected = []
    unknown_one = []
    for v in vs:
        z = sol.get(v.VarName, 0.0)
        if abs(z - 1.0) <= 1e-9:
            selected.append(vid[v.VarName])
        elif abs(z) <= 1e-9:
            pass
        else:
            die("solution value is not binary for " + v.VarName)
    selected_set = set(selected)
    bad_rows = [rows[i].ConstrName for i, s in enumerate(supports)
                if len(selected_set.intersection(s)) > 1]
    bad_edges = sum(1 for a in selected for b in adj[a] if b in selected_set and a < b)
    incumbent_ok = not bad_rows and bad_edges == 0
    incumbent_obj = -len(selected)

    ledger = []
    active = set(range(n))
    forced = set()
    deleted = set()
    row_removed = {}

    # Remove duplicate supports; retain one representative.
    reps = {}
    for i, s in enumerate(supports):
        if s in reps:
            row_removed[rows[i].ConstrName] = {
                "reason": "duplicate-row",
                "representative": rows[reps[s]].ConstrName,
                "support": list(s)
            }
        else:
            reps[s] = i

    # Remove rows subsumed by a retained larger row.  Candidate supersets are
    # found through an inverted index; the quadratic all-pairs scan is
    # intractable here because z26 has roughly 850,000 rows.
    unique = list(reps)
    rows_by_vertex = defaultdict(set)
    for uid, support in enumerate(unique):
        for vertex in support:
            rows_by_vertex[vertex].add(uid)
    for uid, support in enumerate(unique):
        if not support:
            continue
        pivot = min(support, key=lambda vertex: len(rows_by_vertex[vertex]))
        support_set = set(support)
        for tid in rows_by_vertex[pivot]:
            larger = unique[tid]
            if len(larger) > len(support) and support_set.issubset(larger):
                row_removed[rows[reps[support]].ConstrName] = {
                    "reason": "subsumed-row",
                    "by": rows[reps[larger]].ConstrName,
                    "support": list(support)
                }
                break

    def remove_vertex(u, reason, data):
        if u not in active:
            return
        old = sorted(vs[x].VarName for x in adj[u] if x in active)
        for w in list(adj[u]):
            adj[w].discard(u)
        adj[u].clear()
        active.remove(u)
        deleted.add(u)
        ledger.append({"kind": reason, "variable": vs[u].VarName,
                       "neighbors": old, **data})

    # Connected components are recorded as exact additive decomposition.
    def components():
        seen, out = set(), []
        for s in active:
            if s in seen:
                continue
            q, c = [s], []
            seen.add(s)
            while q:
                u = q.pop(); c.append(u)
                for w in adj[u]:
                    if w in active and w not in seen:
                        seen.add(w); q.append(w)
            out.append(sorted(c))
        return out

    comps_before = components()

    # Iterated safe reductions.
    reduction_deadline = time.monotonic() + args.reduction_seconds
    changed = True
    reduction_timed_out = False
    while changed and time.monotonic() < reduction_deadline:
        changed = False

        # Simplicial forcing: N(v) a clique, unit weights.
        for u in list(active):
            N = [w for w in adj[u] if w in active]
            if len(N) > 32:
                continue
            if all(v in adj[w] for i, v in enumerate(N)
                   for w in N[i + 1:]):
                forced.add(u)
                active.remove(u)
                removed = [w for w in list(adj[u]) if w in active]
                for w in removed:
                    remove_vertex(w, "simplicial-neighbor",
                                  {"forced": vs[u].VarName})
                for w in list(adj[u]):
                    adj[w].discard(u)
                adj[u].clear()
                ledger.append({"kind": "simplicial-forcing",
                               "variable": vs[u].VarName,
                               "clique_neighbors":
                               [vs[w].VarName for w in removed]})
                changed = True
                break
        if changed:
            continue

        # True twins: adjacent vertices with identical closed neighborhoods.
        buckets = defaultdict(list)
        for u in active:
            sig = frozenset(adj[u] & active | {u})
            buckets[sig].append(u)
        found = False
        for sig, b in buckets.items():
            if len(b) > 1:
                keep = min(b)
                for u in b:
                    if u != keep and u in active:
                        remove_vertex(u, "true-twin",
                                      {"representative": vs[keep].VarName,
                                       "closed_neighborhood":
                                       [vs[x].VarName for x in sig]})
                        found = True
                if found:
                    break
        if found:
            changed = True
            continue

        # Open-neighborhood dominance: if u,v are nonadjacent and
        # N(u) subseteq N(v), u safely replaces v in every independent set,
        # so the more constrained vertex v can be deleted.
        found = False
        for u in list(active):
            if time.monotonic() >= reduction_deadline:
                reduction_timed_out = True
                break
            Nu = adj[u] & active
            if not Nu or len(Nu) > 32:
                continue
            cand = set(active)
            for a in Nu:
                cand &= adj[a]
            for v in cand:
                if v == u or v not in active or v in adj[u]:
                    continue
                Nv = adj[v] & active
                if Nu.issubset(Nv):
                    remove_vertex(v, "neighborhood-dominance",
                                  {"replacement": vs[u].VarName,
                                   "direction": "N(u) subseteq N(v)"})
                    found = True
                    break
            if found:
                break
        changed = found

    if time.monotonic() >= reduction_deadline:
        reduction_timed_out = True

    comps_after = components()

    # Remaining pair constraints are an exactly equivalent clique
    # consolidation of all surviving original rows.
    red_edges = set()
    for u in active:
        for v in adj[u]:
            if v in active and u < v:
                red_edges.add((u, v))

    # Forced vertices contribute one each; target is adjusted accordingly.
    reduced_target = args.target_size - len(forced)
    names = [vs[i].VarName for i in sorted(active)]
    edge_names = [(vs[a].VarName, vs[b].VarName) for a, b in sorted(red_edges)]

    prefix = args.out
    opb_path = prefix + ".strict1199.opb"
    write_opb(opb_path, names, edge_names, reduced_target)

    report = {
        "model": os.path.basename(args.mps),
        "variables": n,
        "rows": len(rows),
        "nonzeros": sum(len(s) for s in supports),
        "objective": {"sense": "min", "all_coefficients": -1,
                      "constant": float(model.ObjCon)},
        "normalization": {"all_rows_are_sum_x_le_1": True,
                          "empty_rows": sum(not s for s in supports),
                          "families": Counter(r.ConstrName[:1] for r in rows)},
        "K_partition": {"nonempty_rows": len(nonempty_K),
                        "partitions_variables": partition,
                        "max_group": max(map(len, nonempty_K), default=0)},
        "graph": {"vertices": n, "edges": sum(len(a) for a in adj)//2,
                  "edge_provenance_entries": len(edge_rows)},
        "incumbent": {"supplied": bool(args.sol), "selected": len(selected),
                      "objective": incumbent_obj, "feasible": incumbent_ok,
                      "bad_rows": bad_rows[:20],
                      "selected_variables": [vs[i].VarName for i in selected]},
        "target": {"original": args.target_size,
                   "reduced": reduced_target,
                   "forced_offset": len(forced)},
        "reductions": {
            "components_before": len(comps_before),
            "components_after": len(comps_after),
            "active_vertices": len(active),
            "deleted_vertices": len(deleted),
            "forced_vertices": [vs[i].VarName for i in sorted(forced)],
            "duplicate_or_subsumed_rows": len(row_removed),
            "reduced_edges": len(red_edges),
            "unreduced_equivalent_opb": not ledger and not row_removed
            ,"time_limit_reached": reduction_timed_out
            ,"time_limit_seconds": args.reduction_seconds
        },
        "row_cleanup": row_removed,
        "ledger": ledger,
        "files": {"strict_opb": opb_path}
    }
    json_path = prefix + ".report.json"
    with open(json_path, "w") as f:
        json.dump(report, f, indent=2, sort_keys=True)
    print(json.dumps({
        "report": json_path, "strict_opb": opb_path,
        "incumbent_feasible": incumbent_ok,
        "incumbent_size": len(selected),
        "active_vertices": len(active),
        "forced": len(forced),
        "reductions": len(ledger) + len(row_removed)
    }, indent=2))


if __name__ == "__main__":
    main()
