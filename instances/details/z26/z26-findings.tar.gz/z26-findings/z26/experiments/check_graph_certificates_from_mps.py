#!/usr/bin/env python3
"""Independently verify z26 MIS, dominance, clique-cover, and solution certificates.

Only the original MPS and the claimed certificates are trusted as inputs.  The
conflict graph is rebuilt here without importing the search/generator scripts.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
from array import array
from collections import Counter, defaultdict
from decimal import Decimal
from pathlib import Path


SECTIONS = {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}


def open_text(path: Path):
    return gzip.open(path, "rt", encoding="latin-1") if path.suffix == ".gz" else path.open(encoding="latin-1")


def parse_vertex(name: str) -> int:
    if not name.startswith("x") or not name[1:].isdigit():
        raise ValueError(f"unexpected variable name {name!r}")
    return int(name[1:]) - 1


def parse_row(name: str) -> tuple[str, int]:
    if len(name) < 2 or name[0] not in "EK" or not name[1:].isdigit():
        raise ValueError(f"unexpected constraint name {name!r}")
    return name[0], int(name[1:])


def ensure(flags: bytearray, index: int) -> None:
    if index >= len(flags):
        flags.extend(b"\0" * (index + 1 - len(flags)))


def selected_from_sol(path: Path) -> set[int]:
    selected: set[int] = set()
    with (gzip.open(path, "rt", encoding="utf-8") if path.suffix == ".gz" else path.open(encoding="utf-8")) as handle:
        for raw in handle:
            tokens = raw.split()
            if len(tokens) < 2 or not tokens[0].startswith("x"):
                continue
            value = Decimal(tokens[1])
            if value not in {Decimal(0), Decimal(1)}:
                raise ValueError(f"nonbinary value in {path}: {tokens[:2]}")
            if value == 1:
                selected.add(parse_vertex(tokens[0]))
    return selected


def validate_independent(selected: set[int], adjacency: list[int]) -> tuple[bool, list[list[int]]]:
    mask = sum(1 << vertex for vertex in selected)
    conflicts: list[list[int]] = []
    for vertex in selected:
        conflicts_mask = adjacency[vertex] & mask & ~((1 << (vertex + 1)) - 1)
        while conflicts_mask and len(conflicts) < 20:
            bit = conflicts_mask & -conflicts_mask
            conflicts.append([vertex + 1, bit.bit_length()])
            conflicts_mask ^= bit
    return not conflicts, conflicts


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("official_solution", type=Path)
    parser.add_argument("dominance_certificate", type=Path)
    parser.add_argument("clique_cover_certificate", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--kamis-output", type=Path, action="append", default=[])
    args = parser.parse_args()

    source_hash = hashlib.sha256(args.mps.read_bytes()).hexdigest()
    row_present = {"E": bytearray(1), "K": bytearray(1)}
    row_rhs = {"E": bytearray(1), "K": bytearray(1)}
    duplicate_rows: list[str] = []
    bad_row_senses: list[str] = []
    bad_rhs: list[list[str]] = []
    rhs_duplicates: list[str] = []
    objective_row_seen = False
    row_count = 0
    ranges_seen = 0

    # E rows are pair conflicts in this instance.  K rows are small cliques.
    e_first = array("i", [-1])
    e_second = array("i", [-1])
    e_counts = bytearray(1)
    k_vertices: defaultdict[int, list[int]] = defaultdict(list)
    bad_coefficients: list[list[str | int]] = []
    objective: list[Decimal] = []
    variable_seen = bytearray()
    integer_seen = bytearray()
    upper_one = bytearray()
    bound_errors: list[list[str | int]] = []

    def ensure_vertex(vertex: int) -> None:
        size = vertex + 1
        if size > len(variable_seen):
            extension = size - len(variable_seen)
            variable_seen.extend(b"\0" * extension)
            integer_seen.extend(b"\0" * extension)
            upper_one.extend(b"\0" * extension)
            objective.extend([Decimal(0)] * extension)

    section = ""
    integer_mode = False
    previous_vertex = -1
    with open_text(args.mps) as handle:
        for raw in handle:
            tokens = raw.split()
            if not tokens or tokens[0].startswith("*"):
                continue
            if not raw[0].isspace() and tokens[0] in SECTIONS:
                section = tokens[0]
                continue
            if section == "ROWS":
                sense, name = tokens
                if name == "obj":
                    objective_row_seen = sense == "N"
                    continue
                family, row = parse_row(name)
                ensure(row_present[family], row)
                if row_present[family][row]:
                    duplicate_rows.append(name)
                row_present[family][row] = 1
                row_count += 1
                if sense != "L":
                    bad_row_senses.append(name)
            elif section == "COLUMNS":
                if "'MARKER'" in tokens:
                    integer_mode = "'INTORG'" in tokens
                    continue
                vertex = parse_vertex(tokens[0])
                ensure_vertex(vertex)
                if vertex < previous_vertex:
                    raise ValueError("MPS columns are not nondecreasing")
                previous_vertex = vertex
                variable_seen[vertex] = 1
                if integer_mode:
                    integer_seen[vertex] = 1
                for row_name, value_text in zip(tokens[1::2], tokens[2::2]):
                    value = Decimal(value_text.replace("D", "E").replace("d", "e"))
                    if row_name == "obj":
                        objective[vertex] += value
                        continue
                    family, row = parse_row(row_name)
                    if value != 1:
                        if len(bad_coefficients) < 20:
                            bad_coefficients.append([vertex + 1, row_name, str(value)])
                    if family == "E":
                        if row >= len(e_counts):
                            extension = row + 1 - len(e_counts)
                            e_counts.extend(b"\0" * extension)
                            e_first.extend(array("i", [-1]) * extension)
                            e_second.extend(array("i", [-1]) * extension)
                        e_counts[row] += 1
                        if e_first[row] < 0:
                            e_first[row] = vertex
                        elif e_second[row] < 0:
                            e_second[row] = vertex
                        elif len(bad_coefficients) < 20:
                            bad_coefficients.append([vertex + 1, row_name, "third E-row entry"])
                    else:
                        k_vertices[row].append(vertex)
            elif section == "RHS":
                for row_name, value_text in zip(tokens[1::2], tokens[2::2]):
                    family, row = parse_row(row_name)
                    ensure(row_rhs[family], row)
                    if row_rhs[family][row]:
                        rhs_duplicates.append(row_name)
                    row_rhs[family][row] = 1
                    value = Decimal(value_text.replace("D", "E").replace("d", "e"))
                    if value != 1 and len(bad_rhs) < 20:
                        bad_rhs.append([row_name, str(value)])
            elif section == "RANGES":
                ranges_seen += 1
            elif section == "BOUNDS":
                kind = tokens[0]
                vertex = parse_vertex(tokens[2])
                ensure_vertex(vertex)
                value = Decimal(tokens[3]) if len(tokens) > 3 else Decimal(0)
                if kind in {"UP", "UI"} and value == 1:
                    upper_one[vertex] = 1
                elif kind == "BV":
                    upper_one[vertex] = 1
                    integer_seen[vertex] = 1
                elif kind in {"LO", "LI"} and value == 0:
                    pass
                elif kind == "PL":
                    pass
                elif len(bound_errors) < 20:
                    bound_errors.append([kind, vertex + 1, str(value)])

    n = len(variable_seen)
    e_indices = [row for row in range(1, len(row_present["E"])) if row_present["E"][row]]
    k_indices = [row for row in range(1, len(row_present["K"])) if row_present["K"][row]]
    missing_rhs = [
        f"{family}{row}"
        for family, indices in (("E", e_indices), ("K", k_indices))
        for row in indices
        if row >= len(row_rhs[family]) or not row_rhs[family][row]
    ]
    bad_e_sizes = [[row, e_counts[row] if row < len(e_counts) else 0] for row in e_indices if row >= len(e_counts) or e_counts[row] != 2]

    edges: set[int] = set()
    raw_pair_occurrences = 0
    for row in e_indices:
        if row < len(e_counts) and e_counts[row] == 2:
            left, right = sorted((e_first[row], e_second[row]))
            edges.add(left * n + right)
            raw_pair_occurrences += 1
    k_duplicate_entries: list[int] = []
    for row in k_indices:
        raw_vertices = k_vertices.get(row, [])
        vertices = sorted(set(raw_vertices))
        if len(vertices) != len(raw_vertices):
            k_duplicate_entries.append(row)
        raw_pair_occurrences += len(vertices) * (len(vertices) - 1) // 2
        for position, left in enumerate(vertices):
            for right in vertices[position + 1 :]:
                edges.add(left * n + right)
    adjacency = [0] * n
    for encoded in edges:
        left, right = divmod(encoded, n)
        adjacency[left] |= 1 << right
        adjacency[right] |= 1 << left

    mapping_checks = {
        "objective_row_is_N": objective_row_seen,
        "all_rows_unique_and_le": not duplicate_rows and not bad_row_senses,
        "all_rows_have_rhs_one_exactly_once": not bad_rhs and not rhs_duplicates and not missing_rhs,
        "no_ranges": ranges_seen == 0,
        "all_columns_present_binary_zero_one": all(variable_seen) and all(integer_seen) and all(upper_one) and not bound_errors,
        "all_objective_coefficients_exactly_minus_one": len(objective) == n and all(value == -1 for value in objective),
        "all_matrix_coefficients_exactly_one": not bad_coefficients,
        "every_E_row_has_exactly_two_entries": not bad_e_sizes,
        "no_duplicate_K_row_entries": not k_duplicate_entries,
    }

    official = selected_from_sol(args.official_solution)
    official_independent, official_conflicts = validate_independent(official, adjacency)

    dominance = json.loads(args.dominance_certificate.read_text(encoding="utf-8"))
    active = (1 << n) - 1
    mapped = set(official)
    dominance_errors: list[dict[str, object]] = []
    for step, entry in enumerate(dominance["reduction_sequence"], 1):
        deleted = entry["delete_one_based"] - 1
        dominator = entry["dominator_one_based"] - 1
        deleted_bit = 1 << deleted
        dominator_bit = 1 << dominator
        active_pair = bool(active & deleted_bit) and bool(active & dominator_bit)
        adjacent = bool(adjacency[dominator] & deleted_bit)
        nu = adjacency[dominator] & active & ~deleted_bit
        nv = adjacency[deleted] & active & ~dominator_bit
        subset = nu & ~nv == 0
        if not (active_pair and adjacent and subset):
            dominance_errors.append(
                {"step": step, "deleted": deleted + 1, "dominator": dominator + 1, "active": active_pair, "edge": adjacent, "subset": subset}
            )
            break
        if deleted in mapped:
            mapped.remove(deleted)
            mapped.add(dominator)
        active ^= deleted_bit
    mapped_independent, mapped_conflicts = validate_independent(mapped, adjacency)
    claimed_remaining = [vertex - 1 for vertex in dominance["remaining_vertices_one_based"]]
    claimed_mapped = [vertex - 1 for vertex in dominance["mapped_incumbent_one_based"]]
    dominance_checks = {
        "source_hash_matches": dominance.get("source_sha256") == source_hash,
        "every_deletion_satisfies_adjacent_open_neighborhood_domination": not dominance_errors,
        "claimed_counts_match_replay": dominance.get("vertices_before") == n
        and dominance.get("vertices_deleted") == len(dominance["reduction_sequence"])
        and dominance.get("vertices_remaining") == active.bit_count(),
        "claimed_remaining_set_matches_replay": claimed_remaining == [vertex for vertex in range(n) if active & (1 << vertex)],
        "official_1198_back_mapping_matches_replay": len(official) == 1198
        and sorted(mapped) == claimed_mapped
        and dominance.get("mapped_incumbent_size") == len(mapped),
        "mapped_incumbent_is_active_and_independent": mapped_independent
        and all(active & (1 << vertex) for vertex in mapped),
    }

    cover = json.loads(args.clique_cover_certificate.read_text(encoding="utf-8"))
    cover_cliques = [[vertex - 1 for vertex in clique] for clique in cover["cliques_one_based"]]
    covered = [vertex for clique in cover_cliques for vertex in clique]
    cover_pair_errors: list[list[int]] = []
    for clique in cover_cliques:
        for position, left in enumerate(clique):
            for right in clique[position + 1 :]:
                if not adjacency[left] & (1 << right):
                    if len(cover_pair_errors) < 20:
                        cover_pair_errors.append([left + 1, right + 1])
    cover_checks = {
        "source_hash_matches": cover.get("source_sha256") == source_hash,
        "dominance_certificate_hash_matches": cover.get("dominance_reduction_sha256")
        == hashlib.sha256(args.dominance_certificate.read_bytes()).hexdigest(),
        "cover_partitions_exactly_the_reduced_vertices": sorted(covered) == claimed_remaining and len(covered) == len(set(covered)),
        "every_cover_class_is_a_conflict_clique": not cover_pair_errors,
        "claimed_bound_equals_number_of_cliques": cover.get("clique_count_upper_bound_on_independence_number")
        == len(cover_cliques),
    }

    solver_outputs = []
    for path in args.kamis_output:
        values = [line.strip() for line in path.read_text(encoding="ascii").splitlines()]
        format_ok = len(values) == n and all(value in {"0", "1"} for value in values)
        selected = {vertex for vertex, value in enumerate(values) if value == "1"} if format_ok else set()
        independent, conflicts = validate_independent(selected, adjacency) if format_ok else (False, [])
        solver_outputs.append(
            {
                "path": str(path),
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                "format_is_one_zero_line_per_vertex": format_ok,
                "selected_vertices": len(selected),
                "independent_in_graph_reconstructed_from_original_mps": independent,
                "conflict_examples": conflicts,
            }
        )

    all_checks = all(mapping_checks.values()) and official_independent and all(dominance_checks.values()) and all(cover_checks.values())
    all_checks &= all(item["format_is_one_zero_line_per_vertex"] and item["independent_in_graph_reconstructed_from_original_mps"] for item in solver_outputs)
    alpha_lb = max([len(official)] + [item["selected_vertices"] for item in solver_outputs])
    alpha_ub = len(cover_cliques)
    report = {
        "kind": "independent_original_mps_check_of_z26_graph_certificates",
        "source_mps_sha256": source_hash,
        "exact_mps_to_mis_mapping_checks": mapping_checks,
        "graph": {
            "vertices": n,
            "E_rows": len(e_indices),
            "K_rows": len(k_indices),
            "unique_edges": len(edges),
            "raw_pair_occurrences": raw_pair_occurrences,
        },
        "official_solution": {
            "selected_vertices": len(official),
            "independent": official_independent,
            "conflict_examples": official_conflicts,
        },
        "dominance_theorem": "In the current induced graph, if uv is an edge and N(u)\\{v} is a subset of N(v)\\{u}, every independent set containing v can replace v by u; deleting v therefore preserves alpha exactly.",
        "dominance_checks": dominance_checks,
        "dominance_error_examples": dominance_errors[:20],
        "mapped_incumbent_conflict_examples": mapped_conflicts,
        "clique_cover_checks": cover_checks,
        "clique_cover_pair_error_examples": cover_pair_errors,
        "solver_outputs": solver_outputs,
        "certified_alpha_interval": [alpha_lb, alpha_ub],
        "certified_original_minimization_objective_interval": [-alpha_ub, -alpha_lb],
        "all_checks_passed": all_checks,
    }
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if all_checks else 1


if __name__ == "__main__":
    raise SystemExit(main())
