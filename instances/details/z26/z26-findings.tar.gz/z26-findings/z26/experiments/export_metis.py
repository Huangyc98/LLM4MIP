#!/usr/bin/env python3
"""Export the audited z26 conflict graph in KaMIS/METIS adjacency format."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from clique_cover_search import load_graph


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("graph", type=Path)
    parser.add_argument("manifest", type=Path)
    parser.add_argument(
        "--unit-weights",
        action="store_true",
        help="emit METIS fmt=10 with vertex weight one (for weighted_branch_reduce)",
    )
    args = parser.parse_args()
    adjacency, _, edges = load_graph(args.mps)
    with args.graph.open("w", encoding="ascii", newline="\n") as handle:
        suffix = " 10" if args.unit_weights else ""
        handle.write(f"{len(adjacency)} {edges}{suffix}\n")
        for neighbors in adjacency:
            values = []
            mask = neighbors
            while mask:
                bit = mask & -mask
                values.append(str(bit.bit_length()))  # zero-based id + 1
                mask ^= bit
            prefix = ["1"] if args.unit_weights else []
            handle.write(" ".join(prefix + values) + "\n")
    payload = {
        "kind": "audited_z26_conflict_graph_metis_export",
        "source_mps_sha256": hashlib.sha256(args.mps.read_bytes()).hexdigest(),
        "vertices": len(adjacency),
        "edges": edges,
        "unit_vertex_weights": args.unit_weights,
        "graph_sha256": hashlib.sha256(args.graph.read_bytes()).hexdigest(),
    }
    args.manifest.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
