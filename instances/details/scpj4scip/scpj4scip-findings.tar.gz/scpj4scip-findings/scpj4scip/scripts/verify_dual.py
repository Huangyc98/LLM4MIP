#!/usr/bin/env python3
"""Independent exact-integer checker for the saved set-cover LP dual."""

import argparse
import json
from pathlib import Path

from setcover_structure import parse_mps


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("certificate", type=Path)
    args = parser.parse_args()

    senses, rhs, costs, columns = parse_mps(args.model)
    report = json.loads(args.certificate.read_text(encoding="utf-8"))
    cert = report["lp_relaxation"]["exact_dual_certificate"]
    denominator = int(cert["denominator"])
    numerators = {row: int(value) for row, value in cert["row_numerators"].items()}
    assert set(numerators) == set(senses)
    assert all(senses[row] == "G" and rhs[row] == 1.0 and numerators[row] >= 0 for row in senses)

    maximum_violation = None
    worst_column = None
    for variable, entries in columns.items():
        assert all(value == 1.0 for value in entries.values())
        cost = costs[variable]
        assert cost == round(cost)
        violation = sum(numerators[row] for row in entries) - int(round(cost)) * denominator
        if maximum_violation is None or violation > maximum_violation:
            maximum_violation = violation
            worst_column = variable
    bound_numerator = sum(numerators.values())
    integer_lower_bound = (bound_numerator + denominator - 1) // denominator
    assert maximum_violation <= 0
    assert bound_numerator == int(cert["bound_numerator"])
    assert integer_lower_bound == int(cert["integer_objective_lower_bound"])
    result = {
        "verified": True,
        "rows": len(senses),
        "columns": len(columns),
        "denominator": denominator,
        "bound_numerator": bound_numerator,
        "integer_objective_lower_bound": integer_lower_bound,
        "maximum_dual_constraint_violation_numerator": maximum_violation,
        "worst_column": worst_column,
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
