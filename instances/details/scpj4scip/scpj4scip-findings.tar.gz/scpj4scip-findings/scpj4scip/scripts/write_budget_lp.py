#!/usr/bin/env python3
"""Write an exact feasibility LP for a set-cover objective cutoff."""

import argparse
import hashlib
import json
from pathlib import Path

from setcover_structure import parse_mps


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("--bound", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--metadata", type=Path, required=True)
    args = parser.parse_args()
    senses, rhs, costs, columns = parse_mps(args.model)
    assert all(sense == "G" and rhs[row] == 1 for row, sense in senses.items())
    assert all(costs[name] == int(costs[name]) for name in columns)
    covering = {row: [] for row in senses}
    for name, rows in columns.items():
        for row in rows:
            covering[row].append(name)
    with args.output.open("w", encoding="ascii", newline="\n") as stream:
        stream.write("Minimize\n obj: 0\nSubject To\n")
        for row, names in covering.items():
            stream.write(f" {row}: " + " + ".join(names) + " >= 1\n")
        terms = [f"{int(costs[name])} {name}" for name in columns]
        stream.write(" budget: " + " + ".join(terms) + f" <= {args.bound}\n")
        stream.write("Binary\n")
        for name in columns:
            stream.write(f" {name}\n")
        stream.write("End\n")
    report = {
        "source_model": str(args.model),
        "source_sha256": digest(args.model),
        "output": str(args.output),
        "output_sha256": digest(args.output),
        "variables": len(columns),
        "covering_rows": len(senses),
        "budget": args.bound,
        "equivalence": "LP is feasible iff the reduced set-cover model has an integer solution of cost at most the budget",
    }
    args.metadata.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
