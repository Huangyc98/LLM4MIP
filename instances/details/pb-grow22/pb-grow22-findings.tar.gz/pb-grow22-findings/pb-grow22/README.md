# `pb-grow22`

## Result

The instance remains open. The strict public incumbent and strongest strict
solver bound observed in this study give

```text
-449546 <= OPT <= -449536.
```

No feasible solution better than `-449536` was found. The main structural
result is an exact orbit quotient: all 25,124 binary variables were recovered
into 946 fixed-point source-variable groups, and complete column signatures
give 17,909 exact permutation orbits. Replacing each orbit by a bounded integer
count preserves the complete model and reproduces the published symmetry
census.

## Important solver-tolerance boundary

The short default-Gurobi run returned status `OPTIMAL` at `-449536` while its
best bound was `-449566`. That status only means the relative gap was below the
default `MIPGap=1e-4`; it is **not** a strict optimality proof. With `MIPGap=0`,
the 300-second run ended at `TIME_LIMIT`, incumbent `-449536`, and bound
`-449546`. No portable PB/SAT UNSAT certificate or complete branch proof was
produced, so the interval must not be reported as closed.

The exact quotient is a model-preserving reduction, not by itself a lower-bound
or optimality certificate. Exhaustive 2-flip search and two completed
mother-group searches are only local evidence; the attempted 4-flip phase was
invalid and is explicitly excluded from the evidence.

## Provenance

- [MIPLIB instance page](https://miplib.zib.de/instance_details_pb-grow22.html)
- Original MPS SHA-256:
  `6407df50ac88f9130f810d7285bd06a41f1894404d82950b86f0e9e1c26ee2bc`
- Source identity: the PB-evaluation fixed-point conversion of Netlib `grow22`
- Research date: 2026-09-09
- Research effort: 68 minutes; generic solver optimization 302.06 seconds

## Reproduce the quotient audit

From this instance directory:

```powershell
python .\scripts\pb_grow22_quotient.py `
  .\input\pb-grow22.mps.gz `
  .\input\pb-grow22-public-11.sol.gz `
  --output .\artifacts\quotient_audit.recheck.json
```

This checks the exact column-signature orbits and the incumbent projection; it
does not attempt to prove the unresolved cutoff.

## Contents

- [`reports/final_report.md`](reports/final_report.md): full findings and caveats
- [`reports/effort_ledger.md`](reports/effort_ledger.md): experiment accounting
- [`sources/official_background.md`](sources/official_background.md): conversion provenance and references
- [`artifacts/quotient_audit.json`](artifacts/quotient_audit.json): exact orbit audit
- [`artifacts/gurobi_strict_300s.json`](artifacts/gurobi_strict_300s.json): strict-gap run summary
- [`logs/gurobi_strict_300s.log`](logs/gurobi_strict_300s.log): corresponding solver log
- [`artifacts/gurobi_300s.json`](artifacts/gurobi_300s.json): documented default-gap tolerance trap

