#!/usr/bin/env python3
"""
Read-only structural quotient analysis for PB grow22.

Usage:
  python pb_grow22_quotient.py INSTANCE.mps INCUMBENT.sol.gz \
      --output quotient.json

The MPS may also be gzipped. This script never calls optimize() or presolve().
"""

import argparse
import collections
import gzip
import json
import math
import os
import re
import shutil
import tempfile
from fractions import Fraction

import gurobipy as gp
from gurobipy import GRB


MAX_EXCEPTIONS = 100
MAX_CLASS_SAMPLES = 50
MAX_GROUP_SAMPLES = 50
MAX_ROW_EXCEPTIONS = 50

EXPECTED_FACTORS = {
    4: 22,
    5: 44,
    6: 110,
    7: 198,
    8: 154,
    9: 88,
    10: 88,
    11: 88,
    12: 67,
    13: 87,
}


def frac(value):
    """Stable exact rationalization of MPS numeric data."""
    if isinstance(value, Fraction):
        return value
    if isinstance(value, int):
        return Fraction(value, 1)
    x = float(value)
    if x == 0.0:
        return Fraction(0, 1)
    return Fraction(str(x)).limit_denominator(10**12)


def fstr(value):
    value = frac(value)
    return str(value.numerator) if value.denominator == 1 else str(value)


def open_model(path):
    """Read ordinary or gzipped MPS without modifying the model."""
    if not path.lower().endswith(".gz"):
        model = gp.read(path)
        model.update()
        return model

    fd, temporary = tempfile.mkstemp(suffix=".mps")
    os.close(fd)
    try:
        with gzip.open(path, "rb") as source, open(temporary, "wb") as target:
            shutil.copyfileobj(source, target, length=1024 * 1024)
        model = gp.read(temporary)
        model.update()
        return model
    finally:
        try:
            os.unlink(temporary)
        except OSError:
            pass


def natural_name_key(name):
    match = re.match(r"^(.*?)(-?\d+)$", name)
    if match:
        return match.group(1), int(match.group(2))
    return name, -1


def sparse_row(model, constraint):
    row = model.getRow(constraint)
    result = {}
    for k in range(row.size()):
        variable = row.getVar(k)
        coefficient = frac(row.getCoeff(k))
        if coefficient:
            result[variable.index] = coefficient
    return result


def full_column_signature(model, variable):
    """
    Exact symmetry signature including objective, complete indexed column,
    variable type, and bounds.
    """
    column = model.getCol(variable)
    entries = []
    for k in range(column.size()):
        constraint = column.getConstr(k)
        coefficient = frac(column.getCoeff(k))
        if coefficient:
            entries.append((constraint.index, coefficient))
    entries.sort()

    ub = "INF" if variable.UB >= GRB.INFINITY else frac(variable.UB)
    lb = "-INF" if variable.LB <= -GRB.INFINITY else frac(variable.LB)

    return (
        variable.VType,
        lb,
        ub,
        frac(variable.Obj),
        tuple(entries),
    )


def recover_mother_groups(model):
    """
    Recover 880 shortened groups from cap-row supports and split the remaining
    1,980 consecutive columns into 66 groups of 30.
    """
    variables = model.getVars()
    constraints = model.getConstrs()
    exceptions = []

    if len(constraints) < 880:
        raise RuntimeError("Model has fewer than 880 cap rows")

    owner = {}
    groups = []

    for row_index in range(880):
        constraint = constraints[row_index]
        support = sorted(sparse_row(model, constraint))
        if not support:
            exceptions.append({
                "type": "empty_cap_support",
                "row": constraint.ConstrName,
            })

        duplicates = [j for j in support if j in owner]
        if duplicates:
            exceptions.append({
                "type": "overlapping_cap_support",
                "row": constraint.ConstrName,
                "columns": duplicates[:20],
            })

        for j in support:
            owner.setdefault(j, row_index)

        consecutive_indices = (
            not support or support == list(range(support[0], support[-1] + 1))
        )
        names = [variables[j].VarName for j in support]
        naturally_sorted = names == sorted(names, key=natural_name_key)

        if not consecutive_indices:
            exceptions.append({
                "type": "nonconsecutive_cap_group",
                "row": constraint.ConstrName,
                "size": len(support),
                "first_indices": support[:20],
            })

        groups.append({
            "group": row_index,
            "kind": "shortened_cap",
            "cap_row": row_index,
            "columns": support,
            "consecutive_indices": consecutive_indices,
            "naturally_sorted_names": naturally_sorted,
        })

    remaining = sorted(set(range(model.NumVars)) - set(owner))
    if len(remaining) != 1980:
        exceptions.append({
            "type": "unexpected_uncapped_column_count",
            "expected": 1980,
            "actual": len(remaining),
        })

    remaining_consecutive = (
        not remaining
        or remaining == list(range(remaining[0], remaining[-1] + 1))
    )
    if not remaining_consecutive:
        exceptions.append({
            "type": "uncapped_columns_not_one_consecutive_run",
            "first_indices": remaining[:20],
            "last_indices": remaining[-20:],
        })

    complete_chunks = len(remaining) // 30
    for local_group in range(complete_chunks):
        columns = remaining[30 * local_group:30 * (local_group + 1)]
        groups.append({
            "group": 880 + local_group,
            "kind": "full_30_bit",
            "cap_row": None,
            "columns": columns,
            "consecutive_indices": (
                columns == list(range(columns[0], columns[-1] + 1))
            ),
            "naturally_sorted_names": (
                [variables[j].VarName for j in columns]
                == sorted(
                    [variables[j].VarName for j in columns],
                    key=natural_name_key,
                )
            ),
        })

    trailing = remaining[30 * complete_chunks:]
    if trailing:
        exceptions.append({
            "type": "incomplete_final_30_bit_group",
            "size": len(trailing),
            "columns": trailing[:20],
        })
        groups.append({
            "group": len(groups),
            "kind": "incomplete_uncapped",
            "cap_row": None,
            "columns": trailing,
            "consecutive_indices": False,
            "naturally_sorted_names": False,
        })

    coverage = collections.Counter(
        column for group in groups for column in group["columns"]
    )

    return groups, owner, remaining, exceptions, coverage


def build_orbits(model):
    signatures = collections.defaultdict(list)
    signature_by_column = {}

    for variable in model.getVars():
        signature = full_column_signature(model, variable)
        signatures[signature].append(variable.index)
        signature_by_column[variable.index] = signature

    ordered = sorted(
        signatures.items(),
        key=lambda item: (item[1][0], len(item[1])),
    )

    orbits = []
    orbit_of_column = {}
    for orbit_index, (signature, columns) in enumerate(ordered):
        columns = sorted(columns)
        orbit = {
            "orbit": orbit_index,
            "columns": columns,
            "multiplicity": len(columns),
            "signature": signature,
            "representative": columns[0],
        }
        orbits.append(orbit)
        for column in columns:
            orbit_of_column[column] = orbit_index

    return orbits, orbit_of_column, signature_by_column


def verify_orbits(model, orbits):
    """
    Recompute every member signature and verify it equals its representative.
    Equality of these full signatures proves arbitrary permutations within
    each class preserve objective, rows, domains, and bounds.
    """
    tested_columns = 0
    mismatches = []
    variables = model.getVars()

    for orbit in orbits:
        representative_signature = full_column_signature(
            model, variables[orbit["representative"]]
        )
        for column in orbit["columns"]:
            tested_columns += 1
            candidate = full_column_signature(
                model, variables[column]
            )
            if candidate != representative_signature:
                if len(mismatches) < MAX_EXCEPTIONS:
                    mismatches.append({
                        "orbit": orbit["orbit"],
                        "representative": orbit["representative"],
                        "column": column,
                    })

    return tested_columns, mismatches


def parse_solution(path, model):
    """
    Parse plain, gzipped, and XML-like Gurobi solution formats.
    """
    by_name = {v.VarName: v.index for v in model.getVars()}
    values = {}
    exceptions = []

    opener = gzip.open if path.lower().endswith(".gz") else open
    xml_pattern = re.compile(
        r'<variable\b[^>]*\bname="([^"]+)"[^>]*\bvalue="([^"]+)"'
    )
    reverse_xml_pattern = re.compile(
        r'<variable\b[^>]*\bvalue="([^"]+)"[^>]*\bname="([^"]+)"'
    )

    try:
        with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
            for line_number, line in enumerate(handle, 1):
                text = line.strip()
                if not text or text.startswith("#"):
                    continue

                name = None
                value_text = None

                match = xml_pattern.search(text)
                if match:
                    name, value_text = match.group(1), match.group(2)
                else:
                    match = reverse_xml_pattern.search(text)
                    if match:
                        value_text, name = match.group(1), match.group(2)
                    elif not text.startswith("<"):
                        parts = text.replace("=", " ").split()
                        if len(parts) >= 2:
                            name, value_text = parts[0], parts[1]

                if name is None or name not in by_name:
                    continue

                try:
                    value = frac(value_text)
                except Exception:
                    if len(exceptions) < MAX_EXCEPTIONS:
                        exceptions.append({
                            "type": "invalid_solution_value",
                            "line": line_number,
                            "name": name,
                            "value": value_text,
                        })
                    continue

                index = by_name[name]
                if index in values and values[index] != value:
                    if len(exceptions) < MAX_EXCEPTIONS:
                        exceptions.append({
                            "type": "duplicate_conflicting_value",
                            "name": name,
                            "first": fstr(values[index]),
                            "second": fstr(value),
                        })
                values[index] = value
    except OSError as error:
        exceptions.append({
            "type": "solution_read_error",
            "message": str(error),
        })

    return values, exceptions


def validate_and_aggregate_incumbent(model, values, orbits):
    variables = model.getVars()
    constraints = model.getConstrs()
    exceptions = []

    missing = sorted(set(range(model.NumVars)) - set(values))
    extra_integrality = []
    bound_violations = []

    for variable in variables:
        value = values.get(variable.index, Fraction(0, 1))

        if variable.VType == GRB.BINARY and value not in (
            Fraction(0, 1), Fraction(1, 1)
        ):
            extra_integrality.append({
                "column": variable.index,
                "name": variable.VarName,
                "value": fstr(value),
            })

        lb = frac(variable.LB)
        ub = None if variable.UB >= GRB.INFINITY else frac(variable.UB)
        if value < lb or (ub is not None and value > ub):
            bound_violations.append({
                "column": variable.index,
                "name": variable.VarName,
                "value": fstr(value),
                "lb": fstr(lb),
                "ub": None if ub is None else fstr(ub),
            })

    orbit_counts = {}
    count_violations = []
    for orbit in orbits:
        count = sum(
            values.get(column, Fraction(0, 1))
            for column in orbit["columns"]
        )
        orbit_counts[orbit["orbit"]] = count
        if count.denominator != 1 or count < 0 or count > orbit["multiplicity"]:
            count_violations.append({
                "orbit": orbit["orbit"],
                "count": fstr(count),
                "multiplicity": orbit["multiplicity"],
            })

    original_objective = sum(
        frac(variable.Obj) * values.get(variable.index, Fraction(0, 1))
        for variable in variables
    )
    quotient_objective = sum(
        frac(variables[orbit["representative"]].Obj)
        * orbit_counts[orbit["orbit"]]
        for orbit in orbits
    )

    original_row_violations = []
    quotient_row_violations = []
    quotient_reproduction_failures = []

    for row_index, constraint in enumerate(constraints):
        row = model.getRow(constraint)
        original_lhs = Fraction(0, 1)
        for k in range(row.size()):
            variable = row.getVar(k)
            original_lhs += (
                frac(row.getCoeff(k))
                * values.get(variable.index, Fraction(0, 1))
            )

        quotient_lhs = Fraction(0, 1)
        for orbit in orbits:
            signature = orbit["signature"]
            entries = signature[4]
            coefficient = Fraction(0, 1)
            # Each signature has only a small number of row entries.
            for indexed_row, indexed_coefficient in entries:
                if indexed_row == row_index:
                    coefficient = indexed_coefficient
                    break
                if indexed_row > row_index:
                    break
            if coefficient:
                quotient_lhs += (
                    coefficient * orbit_counts[orbit["orbit"]]
                )

        if quotient_lhs != original_lhs:
            if len(quotient_reproduction_failures) < MAX_ROW_EXCEPTIONS:
                quotient_reproduction_failures.append({
                    "row": constraint.ConstrName,
                    "original_lhs": fstr(original_lhs),
                    "quotient_lhs": fstr(quotient_lhs),
                })

        rhs = frac(constraint.RHS)
        if constraint.Sense == GRB.EQUAL:
            violated = original_lhs != rhs
        elif constraint.Sense == GRB.GREATER_EQUAL:
            violated = original_lhs < rhs
        else:
            violated = original_lhs > rhs

        if violated and len(original_row_violations) < MAX_ROW_EXCEPTIONS:
            original_row_violations.append({
                "row": constraint.ConstrName,
                "sense": constraint.Sense,
                "lhs": fstr(original_lhs),
                "rhs": fstr(rhs),
            })

        if constraint.Sense == GRB.EQUAL:
            quotient_violated = quotient_lhs != rhs
        elif constraint.Sense == GRB.GREATER_EQUAL:
            quotient_violated = quotient_lhs < rhs
        else:
            quotient_violated = quotient_lhs > rhs

        if quotient_violated and len(quotient_row_violations) < MAX_ROW_EXCEPTIONS:
            quotient_row_violations.append({
                "row": constraint.ConstrName,
                "sense": constraint.Sense,
                "lhs": fstr(quotient_lhs),
                "rhs": fstr(rhs),
            })

    return {
        "parsed_columns": len(values),
        "missing_columns_assumed_zero": len(missing),
        "missing_column_examples": missing[:20],
        "integrality_violations": extra_integrality[:MAX_EXCEPTIONS],
        "bound_violations": bound_violations[:MAX_EXCEPTIONS],
        "orbit_count_violations": count_violations[:MAX_EXCEPTIONS],
        "original_objective": fstr(original_objective),
        "quotient_objective": fstr(quotient_objective),
        "objective_reproduced_exactly": original_objective == quotient_objective,
        "original_row_violations": original_row_violations,
        "quotient_row_violations": quotient_row_violations,
        "quotient_lhs_reproduction_failures": quotient_reproduction_failures,
        "all_rows_reproduced_exactly": not quotient_reproduction_failures,
        "selected_binary_variables": fstr(sum(values.values())),
        "selected_orbit_counts": fstr(sum(orbit_counts.values())),
        "nonzero_orbit_counts": sum(value != 0 for value in orbit_counts.values()),
        "saturated_orbits": sum(
            orbit_counts[orbit["orbit"]] == orbit["multiplicity"]
            for orbit in orbits
        ),
        "fractional_orbit_counts": sum(
            value.denominator != 1 for value in orbit_counts.values()
        ),
        "orbit_count_sample": [
            {
                "orbit": orbit["orbit"],
                "multiplicity": orbit["multiplicity"],
                "count": fstr(orbit_counts[orbit["orbit"]]),
            }
            for orbit in orbits
            if orbit_counts[orbit["orbit"]] != 0
        ][:MAX_CLASS_SAMPLES],
    }


def analyze_group_orbit_incidence(groups, orbits, orbit_of_column):
    group_orbits = []
    orbit_groups = collections.defaultdict(set)

    for group in groups:
        counts = collections.Counter(
            orbit_of_column[column] for column in group["columns"]
        )
        for orbit_index in counts:
            orbit_groups[orbit_index].add(group["group"])

        group_orbits.append({
            "group": group["group"],
            "kind": group["kind"],
            "size": len(group["columns"]),
            "orbit_count": len(counts),
            "orbit_multiplicities_inside_group": dict(
                sorted(collections.Counter(counts.values()).items())
            ),
            "cross_group_orbit_count": 0,  # filled below
        })

    for summary in group_orbits:
        group = groups[summary["group"]]
        orbit_indices = {
            orbit_of_column[column] for column in group["columns"]
        }
        summary["cross_group_orbit_count"] = sum(
            len(orbit_groups[orbit_index]) > 1
            for orbit_index in orbit_indices
        )

    crossing = {
        orbit_index: sorted(group_indices)
        for orbit_index, group_indices in orbit_groups.items()
        if len(group_indices) > 1
    }

    return {
        "groups": group_orbits,
        "orbit_groups": orbit_groups,
        "crossing": crossing,
        "orbits_within_one_mother_group": sum(
            len(group_indices) == 1
            for group_indices in orbit_groups.values()
        ),
        "orbits_crossing_mother_groups": len(crossing),
        "maximum_mother_groups_per_orbit": max(
            (len(group_indices) for group_indices in orbit_groups.values()),
            default=0,
        ),
    }


def quotient_nonzeros(orbits):
    """
    One coefficient per row represented in each orbit signature.
    """
    return sum(len(orbit["signature"][4]) for orbit in orbits)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", help="PB grow22 MPS, optionally .gz")
    parser.add_argument("incumbent", help="Public incumbent .sol or .sol.gz")
    parser.add_argument("--output", help="Output JSON path")
    args = parser.parse_args()

    model = open_model(args.mps)
    variables = model.getVars()

    groups, cap_owner, remaining, group_exceptions, coverage = (
        recover_mother_groups(model)
    )
    orbits, orbit_of_column, signature_by_column = build_orbits(model)
    tested_columns, orbit_mismatches = verify_orbits(model, orbits)

    values, solution_parse_exceptions = parse_solution(args.incumbent, model)
    incumbent = validate_and_aggregate_incumbent(model, values, orbits)

    incidence = analyze_group_orbit_incidence(
        groups, orbits, orbit_of_column
    )

    multiplicity_histogram = collections.Counter(
        orbit["multiplicity"] for orbit in orbits
    )
    observed_nontrivial = {
        size: count
        for size, count in sorted(multiplicity_histogram.items())
        if size > 1
    }

    factor_reconciliation = []
    for size in sorted(set(EXPECTED_FACTORS) | set(observed_nontrivial)):
        expected = EXPECTED_FACTORS.get(size, 0)
        observed = observed_nontrivial.get(size, 0)
        factor_reconciliation.append({
            "symmetric_group_degree": size,
            "expected_exponent": expected,
            "observed_signature_classes": observed,
            "difference": observed - expected,
            "matches": observed == expected,
        })

    unexplained_factors = [
        entry for entry in factor_reconciliation if not entry["matches"]
    ]

    group_size_histogram = collections.Counter(
        len(group["columns"]) for group in groups
    )
    cap_group_size_histogram = collections.Counter(
        len(group["columns"])
        for group in groups
        if group["kind"] == "shortened_cap"
    )

    objective_orbits = sum(
        orbit["signature"][3] != 0 for orbit in orbits
    )
    quotient_nnz = quotient_nonzeros(orbits)

    class_samples = []
    for orbit in sorted(
        orbits,
        key=lambda item: (-item["multiplicity"], item["representative"]),
    )[:MAX_CLASS_SAMPLES]:
        signature = orbit["signature"]
        class_samples.append({
            "orbit": orbit["orbit"],
            "multiplicity": orbit["multiplicity"],
            "representative": orbit["representative"],
            "representative_name": variables[
                orbit["representative"]
            ].VarName,
            "column_examples": orbit["columns"][:20],
            "type": signature[0],
            "lb": (
                signature[1]
                if isinstance(signature[1], str)
                else fstr(signature[1])
            ),
            "ub": (
                signature[2]
                if isinstance(signature[2], str)
                else fstr(signature[2])
            ),
            "objective": fstr(signature[3]),
            "row_degree": len(signature[4]),
            "mother_group_count": len(
                incidence["orbit_groups"].get(orbit["orbit"], set())
            ),
        })

    group_samples = []
    for summary in incidence["groups"][:MAX_GROUP_SAMPLES]:
        group_samples.append(summary)

    all_columns_once = (
        len(coverage) == model.NumVars
        and sum(coverage.values()) == model.NumVars
        and all(count == 1 for count in coverage.values())
    )

    all_cap_sizes_valid = all(
        22 <= len(group["columns"]) <= 31
        for group in groups[:880]
    )
    full_groups_valid = (
        len(groups) == 946
        and all(len(group["columns"]) == 30 for group in groups[880:])
    )

    quotient_description = {
        "variables": (
            "For every full-column signature orbit o, introduce integer "
            "y_o=sum_{j in o} x_j with bounds 0<=y_o<=|o|."
        ),
        "rows": (
            "For every original row i, use one representative coefficient "
            "a_io per orbit and impose sum_o a_io*y_o with the original "
            "sense and RHS."
        ),
        "objective": (
            "Use sum_o c_o*y_o, where c_o is the common objective "
            "coefficient of the orbit."
        ),
        "exactness": (
            "Every integer y_o in [0,|o|] is realizable by selecting any "
            "y_o members of orbit o. Since all members have identical full "
            "columns, objective, type and bounds, this gives a bijection "
            "between orbit-count vectors and equivalence classes of binary "
            "assignments."
        ),
        "caveat": (
            "This proves symmetry reduction and incumbent reproduction, not "
            "optimality or infeasibility below the incumbent."
        ),
    }

    result = {
        "instance": {
            "mps": os.path.abspath(args.mps),
            "incumbent": os.path.abspath(args.incumbent),
            "variables": model.NumVars,
            "constraints": model.NumConstrs,
            "nonzeros": model.NumNZs,
            "binary_variables": sum(
                variable.VType == GRB.BINARY for variable in variables
            ),
            "objective_nonzero_columns": sum(
                frac(variable.Obj) != 0 for variable in variables
            ),
        },
        "mother_group_recovery": {
            "cap_groups": 880,
            "uncapped_columns": len(remaining),
            "full_30_bit_groups": sum(
                group["kind"] == "full_30_bit" for group in groups
            ),
            "total_groups": len(groups),
            "expected_total_groups": 946,
            "covered_columns": len(coverage),
            "coverage_occurrences": sum(coverage.values()),
            "all_columns_covered_once": all_columns_once,
            "cap_group_sizes_all_22_through_31": all_cap_sizes_valid,
            "uncapped_groups_all_size_30": full_groups_valid,
            "group_size_histogram": dict(sorted(group_size_histogram.items())),
            "cap_group_size_histogram": dict(
                sorted(cap_group_size_histogram.items())
            ),
            "exceptions": group_exceptions[:MAX_EXCEPTIONS],
        },
        "signature_orbits": {
            "orbit_count": len(orbits),
            "columns_covered": sum(
                orbit["multiplicity"] for orbit in orbits
            ),
            "columns_rechecked": tested_columns,
            "full_signature_mismatches": orbit_mismatches,
            "genuine_interchangeable_symmetry": not orbit_mismatches,
            "singleton_orbits": multiplicity_histogram.get(1, 0),
            "nontrivial_orbits": sum(
                count for size, count in multiplicity_histogram.items()
                if size > 1
            ),
            "multiplicity_histogram": dict(
                sorted(multiplicity_histogram.items())
            ),
            "objective_nonzero_orbits": objective_orbits,
            "factor_reconciliation": factor_reconciliation,
            "all_published_factors_reconciled": not unexplained_factors,
            "unexplained_factors": unexplained_factors,
            "samples": class_samples,
        },
        "group_orbit_incidence": {
            "orbits_within_one_mother_group":
                incidence["orbits_within_one_mother_group"],
            "orbits_crossing_mother_groups":
                incidence["orbits_crossing_mother_groups"],
            "maximum_mother_groups_per_orbit":
                incidence["maximum_mother_groups_per_orbit"],
            "crossing_orbit_samples": [
                {
                    "orbit": orbit,
                    "mother_group_count": len(group_indices),
                    "mother_groups": group_indices[:20],
                }
                for orbit, group_indices in sorted(
                    incidence["crossing"].items()
                )[:MAX_CLASS_SAMPLES]
            ],
            "mother_group_samples": group_samples,
        },
        "quotient": {
            "original_variables": model.NumVars,
            "quotient_integer_count_variables": len(orbits),
            "variable_reduction": model.NumVars - len(orbits),
            "variable_reduction_ratio": (
                len(orbits) / model.NumVars if model.NumVars else None
            ),
            "original_constraints": model.NumConstrs,
            "quotient_constraints": model.NumConstrs,
            "original_nonzeros": model.NumNZs,
            "quotient_nonzeros": quotient_nnz,
            "nonzero_reduction": model.NumNZs - quotient_nnz,
            "nonzero_reduction_ratio": (
                quotient_nnz / model.NumNZs if model.NumNZs else None
            ),
            "maximum_count_upper_bound": max(
                (orbit["multiplicity"] for orbit in orbits),
                default=0,
            ),
            "description": quotient_description,
        },
        "incumbent": {
            "parse_exceptions": solution_parse_exceptions,
            **incumbent,
        },
        "ranked_next_experiments": [
            {
                "rank": 1,
                "experiment": (
                    "Write the exact quotient as OPB or MPS using one bounded "
                    "integer count per signature orbit, then independently "
                    "verify every quotient coefficient and the -449536 "
                    "incumbent count vector. Do not solve during the verifier."
                ),
                "information": (
                    "Confirms the large published symmetry reduction is "
                    "usable as an exact model transformation."
                ),
            },
            {
                "rank": 2,
                "experiment": (
                    "Construct association neighborhoods between quotient "
                    "orbits using shared rows, weighted by overlap and "
                    "objective support; enumerate exact 2-orbit and 4-orbit "
                    "count changes preserving all affected rows."
                ),
                "information": (
                    "Directly targets the local-search mechanism associated "
                    "with previous incumbent improvements while removing "
                    "within-orbit redundancy."
                ),
            },
            {
                "rank": 3,
                "experiment": (
                    "Encode the quotient in pseudo-Boolean form, expanding "
                    "only count variables when required, and test the cutoff "
                    "objective <= -449537 incrementally."
                ),
                "information": (
                    "Tests whether the quotient is small enough for an exact "
                    "SAT/PB infeasibility campaign."
                ),
            },
            {
                "rank": 4,
                "experiment": (
                    "Cross-reference mother groups with quotient orbit "
                    "incidence and identify repeated 22-block templates for "
                    "a second-level block or dynamic-programming quotient."
                ),
                "information": (
                    "May expose structure beyond pure interchangeable-column "
                    "symmetry."
                ),
            },
        ],
        "claims": {
            "optimization_called": False,
            "presolve_called": False,
            "optimality_claimed": False,
            "cutoff_infeasibility_claimed": False,
        },
    }

    text = json.dumps(result, indent=2, sort_keys=True)
    if args.output:
        with open(args.output, "w", encoding="utf-8") as handle:
            handle.write(text)
            handle.write("\n")
    else:
        print(text)


if __name__ == "__main__":
    main()
