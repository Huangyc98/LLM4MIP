#!/usr/bin/env python3
"""
Exact structural analysis of the pb-grow22 binary formulation against Netlib
grow22.

This script is read-only with respect to the models. It never calls
optimize() or presolve(). It uses sparse row access and exact Fraction
arithmetic after importing coefficients through Gurobi.

Usage:

  python analyze_grow22_mapping.py binary.mps grow22.mps \
      --solutions sol449302.sol.gz sol449467.sol.gz sol449536.sol.gz \
      --output grow22_mapping.json

Compressed MPS input is accepted as well as ordinary MPS input.
"""

import argparse
import collections
import gzip
import json
import math
import os
import tempfile
from fractions import Fraction

import gurobipy as gp
from gurobipy import GRB


MAX_EXCEPTIONS = 100
MAX_GROUPS_IN_JSON = 100
MAX_EXAMPLE_VALUES = 20


def exact(x):
    """Convert a Gurobi numeric value to a reproducible rational."""
    if isinstance(x, int):
        return Fraction(x, 1)
    return Fraction(str(float(x))).limit_denominator(10**9)


def read_mps(path):
    """
    gurobipy.read() does not consistently accept compressed paths across
    Gurobi versions, so compressed MPS content is materialized temporarily.
    """
    if not path.lower().endswith(".gz"):
        model = gp.read(path)
        model.update()
        return model

    fd, tmp = tempfile.mkstemp(suffix=".mps")
    os.close(fd)
    try:
        with gzip.open(path, "rb") as src, open(tmp, "wb") as dst:
            while True:
                block = src.read(1024 * 1024)
                if not block:
                    break
                dst.write(block)
        model = gp.read(tmp)
        model.update()
        return model
    finally:
        try:
            os.unlink(tmp)
        except OSError:
            pass


def sparse_row(model, constr):
    row = model.getRow(constr)
    result = {}
    for k in range(row.size()):
        var = row.getVar(k)
        value = exact(row.getCoeff(k))
        if value:
            result[var.index] = value
    return result


def sparse_equality_matrix(model, equality_rows):
    """
    Return columns restricted to the designated equality rows:
      columns[var_index] = {local_row_index: coefficient}
    """
    columns = collections.defaultdict(dict)
    for i, constr in enumerate(equality_rows):
        row = model.getRow(constr)
        for k in range(row.size()):
            var = row.getVar(k)
            value = exact(row.getCoeff(k))
            if value:
                columns[var.index][i] = value
    return dict(columns)


def vector_key(vector):
    """
    Normalize a nonzero rational vector by its first nonzero entry.
    This allows exact proportionality, including negative proportionality.
    """
    if not vector:
        return None
    first_index = min(vector)
    first_value = vector[first_index]
    if not first_value:
        return None
    return tuple(
        (int(i), vector[i] / first_value)
        for i in sorted(vector)
        if vector[i]
    )


def vector_scale(vector, key):
    """
    Recover the scalar alpha such that vector = alpha * normalized(key).
    """
    if not vector or key is None:
        return None
    first_index = key[0][0]
    if first_index not in vector:
        return None
    return vector[first_index]


def multiply_vector(vector, scalar):
    return {i: value * scalar for i, value in vector.items()}


def vectors_equal(left, right):
    return left == right


def group_signature(weights):
    return tuple(sorted(str(w) for w in weights))


def load_solution(path, model):
    """
    Parse common Gurobi .sol files and simple "name value" files.
    Unknown names and XML-like metadata are ignored.
    """
    variables = {v.VarName: v for v in model.getVars()}
    values = {}
    errors = []

    opener = gzip.open if path.lower().endswith(".gz") else open
    try:
        with opener(path, "rt", errors="replace") as handle:
            for line in handle:
                text = line.strip()
                if not text or text.startswith("#") or text.startswith("<"):
                    continue

                parts = text.replace("=", " ").split()
                if len(parts) < 2:
                    continue

                name = parts[0]
                try:
                    value = float(parts[1])
                except ValueError:
                    continue

                if name in variables:
                    values[variables[name].index] = exact(value)
    except OSError as exc:
        errors.append(str(exc))

    return values, errors


def check_binary_solution(model, values):
    violations = []
    objective = Fraction(0, 1)

    for var in model.getVars():
        value = values.get(var.index)
        if value is None:
            continue

        objective += exact(var.Obj) * value

        if var.VType == GRB.BINARY:
            if value not in (Fraction(0, 1), Fraction(1, 1)):
                violations.append({
                    "type": "integrality",
                    "variable": var.VarName,
                    "value": str(value),
                })

        lb = exact(var.LB)
        ub = exact(var.UB) if var.UB < GRB.INFINITY else None
        if value < lb or (ub is not None and value > ub):
            violations.append({
                "type": "bound",
                "variable": var.VarName,
                "value": str(value),
                "lb": str(lb),
                "ub": None if ub is None else str(ub),
            })

    for constr in model.getConstrs():
        row = model.getRow(constr)
        lhs = Fraction(0, 1)
        complete = True
        for k in range(row.size()):
            var = row.getVar(k)
            if var.index not in values:
                complete = False
                continue
            lhs += exact(row.getCoeff(k)) * values[var.index]

        rhs = exact(constr.RHS)
        bad = (
            abs(lhs - rhs) > 0
            if constr.Sense == GRB.EQUAL
            else lhs < rhs
            if constr.Sense == GRB.GREATER_EQUAL
            else lhs > rhs
        )
        if bad:
            violations.append({
                "type": "row",
                "row": constr.ConstrName,
                "sense": constr.Sense,
                "lhs": str(lhs),
                "rhs": str(rhs),
                "complete": complete,
            })
            if len(violations) >= MAX_EXCEPTIONS:
                break

    return objective, violations[:MAX_EXCEPTIONS]


def infer_groups(binary, source):
    bconstrs = binary.getConstrs()
    sconstrs = source.getConstrs()

    if len(bconstrs) < 1320:
        raise RuntimeError("binary model has fewer than 1320 rows")
    if len(sconstrs) != 440:
        raise RuntimeError("source model does not have exactly 440 rows")

    cap_rows = bconstrs[:880]
    binary_eq_rows = bconstrs[880:]
    source_eq_rows = sconstrs[:440]

    cap_groups = []
    cap_owner = {}
    cap_exceptions = []

    for cap_index, constr in enumerate(cap_rows):
        row = sparse_row(binary, constr)
        group = sorted(row)
        weights = {}
        for var_index, coefficient in row.items():
            if coefficient >= 0:
                cap_exceptions.append({
                    "type": "cap_nonnegative_coefficient",
                    "row": constr.ConstrName,
                    "variable_index": var_index,
                    "coefficient": str(coefficient),
                })
            weights[var_index] = -coefficient

            if var_index in cap_owner:
                cap_exceptions.append({
                    "type": "cap_support_overlap",
                    "variable_index": var_index,
                    "first_cap_row": cap_owner[var_index],
                    "second_cap_row": cap_index,
                })
            else:
                cap_owner[var_index] = cap_index

        cap_groups.append({
            "kind": "capped",
            "cap_row": cap_index,
            "columns": group,
            "weights": weights,
            "upper_bound": str(-exact(constr.RHS)),
        })

    all_columns = {v.index for v in binary.getVars()}
    uncapped_columns = sorted(all_columns - set(cap_owner))
    eq_columns = sparse_equality_matrix(binary, binary_eq_rows)

    direction_groups = collections.defaultdict(list)
    zero_direction_columns = []
    for var_index in uncapped_columns:
        key = vector_key(eq_columns.get(var_index, {}))
        if key is None:
            zero_direction_columns.append(var_index)
        else:
            direction_groups[key].append(var_index)

    free_groups = []
    for key, columns in sorted(
        direction_groups.items(),
        key=lambda item: (item[0], item[1]),
    ):
        free_groups.append({
            "kind": "uncapped",
            "columns": sorted(columns),
            "direction_key": key,
        })

    return {
        "cap_groups": cap_groups,
        "free_groups": free_groups,
        "cap_owner": cap_owner,
        "uncapped_columns": uncapped_columns,
        "zero_direction_columns": zero_direction_columns,
        "binary_eq_rows": binary_eq_rows,
        "source_eq_rows": source_eq_rows,
        "eq_columns": eq_columns,
        "cap_exceptions": cap_exceptions,
    }


def map_groups_to_source(binary, source, structure):
    source_columns = sparse_equality_matrix(source, structure["source_eq_rows"])
    source_by_direction = collections.defaultdict(list)

    for var_index, vector in source_columns.items():
        key = vector_key(vector)
        if key is not None:
            source_by_direction[key].append(var_index)

    groups = structure["cap_groups"] + structure["free_groups"]
    mapped = []
    exceptions = []

    for group_index, group in enumerate(groups):
        columns = group["columns"]
        if not columns:
            exceptions.append({
                "type": "empty_group",
                "group": group_index,
            })
            continue

        first_vector = structure["eq_columns"].get(columns[0], {})
        direction = vector_key(first_vector)
        candidates = source_by_direction.get(direction, [])

        if len(candidates) != 1:
            exceptions.append({
                "type": "source_direction_ambiguity",
                "group": group_index,
                "kind": group["kind"],
                "candidate_count": len(candidates),
                "candidates": candidates[:MAX_EXAMPLE_VALUES],
            })
            continue

        source_index = candidates[0]
        source_vector = source_columns[source_index]
        source_scale = vector_scale(source_vector, direction)

        if group["kind"] == "capped":
            weights = dict(group["weights"])
        else:
            weights = {}
            for column in columns:
                binary_vector = structure["eq_columns"].get(column, {})
                binary_scale = vector_scale(binary_vector, direction)
                if source_scale == 0:
                    exceptions.append({
                        "type": "zero_source_scale",
                        "group": group_index,
                        "source_index": source_index,
                    })
                    continue
                weights[column] = binary_scale / source_scale

        mapped.append({
            "group_index": group_index,
            "kind": group["kind"],
            "columns": columns,
            "weights": weights,
            "source_index": source_index,
            "source_name": source.getVars()[source_index].VarName,
            "direction": direction,
            "digit_multiplicity": len(columns),
        })

    return mapped, exceptions, source_columns


def verify_mapping(binary, source, structure, mapped, source_columns):
    b_eq_columns = structure["eq_columns"]
    row_scales = {}
    row_scale_conflicts = []
    matrix_matches = 0
    matrix_tests = 0
    matrix_exceptions = []

    for i in range(440):
        inferred = None
        for item in mapped:
            j = item["source_index"]
            a = source_columns[j].get(i, Fraction(0, 1))
            for column, weight in item["weights"].items():
                b = b_eq_columns.get(column, {}).get(i, Fraction(0, 1))
                if a and weight:
                    ratio = b / (a * weight)
                    if inferred is None:
                        inferred = ratio
                    elif ratio != inferred:
                        row_scale_conflicts.append({
                            "row": i,
                            "group": item["group_index"],
                            "column": column,
                            "expected_scale": str(inferred),
                            "actual_scale": str(ratio),
                        })
                        if len(row_scale_conflicts) >= MAX_EXCEPTIONS:
                            break
                elif b != 0:
                    matrix_exceptions.append({
                        "type": "unexpected_binary_equality_coefficient",
                        "row": i,
                        "group": item["group_index"],
                        "column": column,
                        "value": str(b),
                    })
                matrix_tests += 1
                if b == (inferred or Fraction(0, 1)) * a * weight:
                    matrix_matches += 1
            if len(row_scale_conflicts) >= MAX_EXCEPTIONS:
                break
        row_scales[i] = inferred if inferred is not None else Fraction(0, 1)

    return {
        "matrix_tests": matrix_tests,
        "matrix_exact_matches": matrix_matches,
        "matrix_match_rate": (
            matrix_matches / matrix_tests if matrix_tests else None
        ),
        "row_scales": {
            str(i): str(value) for i, value in row_scales.items()
        },
        "row_scale_distinct_values": sorted(
            {str(value) for value in row_scales.values()}
        )[:MAX_EXAMPLE_VALUES],
        "row_scale_conflicts": row_scale_conflicts[:MAX_EXCEPTIONS],
        "matrix_exceptions": matrix_exceptions[:MAX_EXCEPTIONS],
        "matrix_proven": (
            matrix_tests > 0
            and matrix_matches == matrix_tests
            and not row_scale_conflicts
            and not matrix_exceptions
        ),
    }


def objective_analysis(binary, source, mapped, solutions):
    source_vars = source.getVars()
    binary_vars = binary.getVars()

    source_obj = {
        v.index: exact(v.Obj)
        for v in source_vars
    }
    binary_obj = {
        v.index: exact(v.Obj)
        for v in binary_vars
    }

    coefficient_tests = 0
    coefficient_matches = 0
    coefficient_exceptions = []

    for item in mapped:
        c = source_obj[item["source_index"]]
        for column, weight in item["weights"].items():
            expected = c * weight
            actual = binary_obj[column]
            coefficient_tests += 1
            if actual == expected:
                coefficient_matches += 1
            elif len(coefficient_exceptions) < MAX_EXCEPTIONS:
                coefficient_exceptions.append({
                    "group": item["group_index"],
                    "column": column,
                    "source_index": item["source_index"],
                    "expected": str(expected),
                    "actual": str(actual),
                })

    solution_results = []
    constants = []

    for path, values in solutions:
        decoded = {}
        decode_exceptions = []

        for item in mapped:
            j = item["source_index"]
            lb = exact(source_vars[j].LB)
            value = lb
            for column, weight in item["weights"].items():
                value += weight * values.get(column, Fraction(0, 1))
            decoded[j] = value

        source_obj_value = sum(
            source_obj[j] * value for j, value in decoded.items()
        )
        binary_obj_value = sum(
            binary_obj[j] * values.get(j, Fraction(0, 1))
            for j in binary_obj
        )
        constant = binary_obj_value - source_obj_value
        constants.append(constant)

        source_bound_violations = []
        for var in source_vars:
            if var.index not in decoded:
                continue
            value = decoded[var.index]
            lb = exact(var.LB)
            ub = exact(var.UB) if var.UB < GRB.INFINITY else None
            if value < lb or (ub is not None and value > ub):
                source_bound_violations.append({
                    "variable": var.VarName,
                    "value": str(value),
                    "lb": str(lb),
                    "ub": None if ub is None else str(ub),
                })

        source_eq_violations = []
        for i, constr in enumerate(source.getConstrs()[:440]):
            row = source.getRow(constr)
            lhs = Fraction(0, 1)
            complete = True
            for k in range(row.size()):
                var = row.getVar(k)
                if var.index not in decoded:
                    complete = False
                    continue
                lhs += exact(row.getCoeff(k)) * decoded[var.index]
            rhs = exact(constr.RHS)
            if not complete or lhs != rhs:
                source_eq_violations.append({
                    "row": i,
                    "lhs": str(lhs),
                    "rhs": str(rhs),
                    "complete": complete,
                })
                if len(source_eq_violations) >= MAX_EXCEPTIONS:
                    break

        solution_results.append({
            "file": os.path.abspath(path),
            "decoded_source_variables": len(decoded),
            "source_bound_violations": source_bound_violations[:MAX_EXCEPTIONS],
            "source_equality_violations": source_eq_violations,
            "binary_objective": str(binary_obj_value),
            "decoded_source_objective": str(source_obj_value),
            "affine_constant": str(constant),
            "constant_matches_first": (
                constant == constants[0] if constants else False
            ),
        })

    return {
        "binary_nonzero_objective_columns": sum(
            value != 0 for value in binary_obj.values()
        ),
        "source_nonzero_objective_variables": sum(
            value != 0 for value in source_obj.values()
        ),
        "coefficient_tests": coefficient_tests,
        "coefficient_exact_matches": coefficient_matches,
        "coefficient_match_rate": (
            coefficient_matches / coefficient_tests
            if coefficient_tests else None
        ),
        "coefficient_exceptions": coefficient_exceptions,
        "single_affine_constant": (
            len(constants) > 0 and all(c == constants[0] for c in constants)
        ),
        "affine_constants": [str(c) for c in constants],
        "solution_results": solution_results,
    }


def bounded_group_output(items):
    output = []
    for item in items[:MAX_GROUPS_IN_JSON]:
        output.append({
            "group_index": item.get("group_index"),
            "kind": item.get("kind"),
            "source_index": item.get("source_index"),
            "source_name": item.get("source_name"),
            "column_count": len(item["columns"]),
            "columns": item["columns"][:MAX_EXAMPLE_VALUES],
            "weights": {
                str(k): str(v)
                for k, v in list(item["weights"].items())[:MAX_EXAMPLE_VALUES]
            },
            "digit_multiplicity": item.get("digit_multiplicity"),
        })
    return output


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("binary_mps")
    parser.add_argument("source_mps")
    parser.add_argument("--solutions", nargs="*", default=[])
    parser.add_argument("--output")
    args = parser.parse_args()

    binary = read_mps(args.binary_mps)
    source = read_mps(args.source_mps)

    structure = infer_groups(binary, source)
    mapped, mapping_exceptions, source_columns = map_groups_to_source(
        binary, source, structure
    )

    verification = verify_mapping(
        binary, source, structure, mapped, source_columns
    )

    solution_inputs = []
    binary_solution_checks = []
    for path in args.solutions[:10]:
        values, parse_errors = load_solution(path, binary)
        objective, violations = check_binary_solution(binary, values)
        solution_inputs.append((path, values))
        binary_solution_checks.append({
            "file": os.path.abspath(path),
            "parsed_values": len(values),
            "parse_errors": parse_errors,
            "binary_objective": str(objective),
            "binary_violations": violations,
        })

    objective = objective_analysis(
        binary, source, mapped, solution_inputs
    )

    multiplicities = collections.Counter(
        len(group["columns"])
        for group in structure["cap_groups"] + structure["free_groups"]
    )
    cap_weights = collections.Counter()
    for group in structure["cap_groups"]:
        cap_weights.update(str(w) for w in group["weights"].values())

    repeated_groups = collections.Counter(
        tuple(sorted(str(w) for w in group["weights"].values()))
        for group in structure["cap_groups"]
    )

    all_groups = structure["cap_groups"] + structure["free_groups"]
    covered_columns = [
        column
        for group in all_groups
        for column in group["columns"]
    ]
    covered_counter = collections.Counter(covered_columns)

    result = {
        "dimensions": {
            "binary_variables": binary.NumVars,
            "binary_constraints": binary.NumConstrs,
            "binary_nonzeros": binary.NumNZs,
            "source_variables": source.NumVars,
            "source_constraints": source.NumConstrs,
            "source_nonzeros": source.NumNZs,
        },
        "row_partition": {
            "cap_rows": 880,
            "binary_equality_rows": 440,
            "cap_senses": collections.Counter(
                c.Sense for c in binary.getConstrs()[:880]
            ),
            "equality_senses": collections.Counter(
                c.Sense for c in binary.getConstrs()[880:]
            ),
        },
        "group_recovery": {
            "cap_group_count": len(structure["cap_groups"]),
            "uncapped_direction_group_count": len(structure["free_groups"]),
            "total_group_count": len(all_groups),
            "expected_group_count": source.NumVars,
            "all_source_groups_recovered": len(all_groups) == source.NumVars,
            "covered_columns": len(covered_columns),
            "unique_covered_columns": len(covered_counter),
            "expected_binary_columns": binary.NumVars,
            "all_columns_covered_once": (
                len(covered_columns) == binary.NumVars
                and len(covered_counter) == binary.NumVars
                and all(v == 1 for v in covered_counter.values())
            ),
            "uncapped_columns": len(structure["uncapped_columns"]),
            "zero_equality_direction_columns": len(
                structure["zero_direction_columns"]
            ),
            "cap_exceptions": structure["cap_exceptions"][:MAX_EXCEPTIONS],
            "mapping_exceptions": mapping_exceptions[:MAX_EXCEPTIONS],
        },
        "digit_statistics": {
            "group_size_histogram": dict(sorted(multiplicities.items())),
            "cap_digit_weight_histogram": dict(
                cap_weights.most_common(100)
            ),
            "repeated_cap_digit_vectors": [
                {"multiplicity": count, "digit_count": len(signature)}
                for signature, count in repeated_groups.most_common(50)
                if count > 1
            ],
            "groups_with_size_22": sum(
                len(g["columns"]) == 22 for g in all_groups
            ),
            "groups_with_size_44": sum(
                len(g["columns"]) == 44 for g in all_groups
            ),
            "group_size_factors": {
                "divisible_by_22": sum(
                    len(g["columns"]) % 22 == 0 for g in all_groups
                ),
                "divisible_by_44": sum(
                    len(g["columns"]) % 44 == 0 for g in all_groups
                ),
            },
        },
        "groups_sample": bounded_group_output(mapped),
        "matrix_verification": verification,
        "binary_solution_checks": binary_solution_checks,
        "objective_verification": objective,
        "recommendations": [
            "If matrix_proven and single_affine_constant are true, move immediately to source-space or orbit-aggregated search.",
            "If cap supports are disjoint but uncapped directions do not form 66 groups, inspect zero or duplicate equality directions before using SAT/PB encoding.",
            "If equality mapping succeeds but objective coefficients fail, test fixed lower-bound offsets and a generated objective constant before rejecting equivalence.",
            "If digit multiplicity vectors repeat 22 or 44 times, quotient those groups and enumerate orbit-level 2-/4-flip neighborhoods.",
            "If decoded source equalities fail while binary rows remain feasible, the encoding includes an offset or auxiliary affine term that must be recovered from row RHS values.",
        ],
    }

    # Convert Counter objects to ordinary JSON objects.
    def jsonable(value):
        if isinstance(value, collections.Counter):
            return dict(value)
        if isinstance(value, dict):
            return {str(k): jsonable(v) for k, v in value.items()}
        if isinstance(value, list):
            return [jsonable(v) for v in value]
        return value

    text = json.dumps(jsonable(result), indent=2, sort_keys=True)
    if args.output:
        with open(args.output, "w") as handle:
            handle.write(text + "\n")
    else:
        print(text)


if __name__ == "__main__":
    main()
