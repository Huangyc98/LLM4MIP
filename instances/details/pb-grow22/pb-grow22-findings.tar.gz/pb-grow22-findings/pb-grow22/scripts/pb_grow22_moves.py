#!/usr/bin/env python3
"""
Non-solver feasible move search for pb-grow22.

Usage:
  python pb_grow22_moves.py INSTANCE.mps INCUMBENT.sol.gz \
      --output result.json \
      --four-pair-cap 200000 \
      --time-limit 480

No optimize() or presolve() is called.
"""

import argparse
import collections
import gzip
import itertools
import json
import os
import shutil
import tempfile
import time
from fractions import Fraction

import gurobipy as gp
from gurobipy import GRB


MAX_EXCEPTIONS = 100
MAX_WITNESS_ROWS = 20
MAX_GROUP_REPORTS = 200
ZERO = Fraction(0)


def F(x):
    if isinstance(x, Fraction):
        return x
    return Fraction(str(float(x))).limit_denominator(10**12)


def fs(x):
    x = F(x)
    return str(x.numerator) if x.denominator == 1 else str(x)


def read_model(path):
    if not path.lower().endswith(".gz"):
        m = gp.read(path)
        m.update()
        return m
    fd, tmp = tempfile.mkstemp(suffix=".mps")
    os.close(fd)
    try:
        with gzip.open(path, "rb") as a, open(tmp, "wb") as b:
            shutil.copyfileobj(a, b, 1024 * 1024)
        m = gp.read(tmp)
        m.update()
        return m
    finally:
        try:
            os.unlink(tmp)
        except OSError:
            pass


def parse_solution(path, model):
    names = {v.VarName: v.index for v in model.getVars()}
    vals = {}
    errors = []
    op = gzip.open if path.lower().endswith(".gz") else open
    try:
        with op(path, "rt", encoding="utf-8", errors="replace") as h:
            for line in h:
                s = line.strip()
                if not s or s.startswith("#") or s.startswith("<"):
                    continue
                p = s.replace("=", " ").split()
                if len(p) < 2:
                    continue
                if p[0] not in names:
                    continue
                try:
                    vals[names[p[0]]] = F(p[1])
                except Exception:
                    if len(errors) < MAX_EXCEPTIONS:
                        errors.append({"line": s[:200]})
    except Exception as e:
        errors.append({"read_error": str(e)})
    return vals, errors


def sparse_row(model, c):
    r = model.getRow(c)
    out = {}
    for k in range(r.size()):
        j = r.getVar(k).index
        a = F(r.getCoeff(k))
        if a:
            out[j] = a
    return out


def sparse_column(model, v, row_indices):
    c = model.getCol(v)
    out = {}
    wanted = set(row_indices)
    for k in range(c.size()):
        r = c.getConstr(k)
        if r.index in wanted:
            a = F(c.getCoeff(k))
            if a:
                out[r.index] = a
    return out


def dense_signature(d, n):
    # Reuse one immutable zero instead of allocating ~11 million Fractions.
    return tuple(d.get(i, ZERO) for i in range(n))


def add_vec(a, b, sign=1):
    z = list(a)
    for i, x in enumerate(b):
        z[i] += sign * x
    return tuple(z)


def validate(model, values):
    bad = []
    obj = Fraction(0)
    for v in model.getVars():
        x = values.get(v.index, Fraction(0))
        obj += F(v.Obj) * x
        if v.VType == GRB.BINARY and x not in (0, 1):
            bad.append({"type": "integrality", "var": v.VarName, "value": fs(x)})
        if x < F(v.LB) or (v.UB < GRB.INFINITY and x > F(v.UB)):
            bad.append({"type": "bound", "var": v.VarName, "value": fs(x)})
    for c in model.getConstrs():
        r = model.getRow(c)
        lhs = Fraction(0)
        for k in range(r.size()):
            lhs += F(r.getCoeff(k)) * values.get(r.getVar(k).index, 0)
        rhs = F(c.RHS)
        violated = (
            lhs != rhs if c.Sense == GRB.EQUAL else
            lhs < rhs if c.Sense == GRB.GREATER_EQUAL else lhs > rhs
        )
        if violated and len(bad) < MAX_EXCEPTIONS:
            bad.append({"type": "row", "row": c.ConstrName,
                        "lhs": fs(lhs), "rhs": fs(rhs)})
    return obj, bad


def write_solution(path, model, values):
    with open(path, "w") as h:
        h.write("# feasible witness generated without optimization\n")
        for v in model.getVars():
            h.write("%s %s\n" % (v.VarName, fs(values.get(v.index, 0))))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mps")
    ap.add_argument("incumbent")
    ap.add_argument("--output", default="pb_grow22_moves.json")
    ap.add_argument("--witness", default="pb_grow22_witness.sol")
    ap.add_argument("--time-limit", type=float, default=480.0)
    ap.add_argument("--four-pair-cap", type=int, default=200000)
    ap.add_argument("--association-cap", type=int, default=12000)
    args = ap.parse_args()

    started = time.monotonic()
    model = read_model(args.mps)
    model.update()
    vars_ = model.getVars()
    cons = model.getConstrs()

    if len(cons) != 1320:
        raise RuntimeError("expected 1320 rows")
    eq_rows = list(range(880, 1320))
    cap_rows = list(range(880))

    values, parse_errors = parse_solution(args.incumbent, model)
    values = {j: values.get(j, Fraction(0)) for j in range(model.NumVars)}
    initial_obj, initial_bad = validate(model, values)

    eq_vectors = []
    eq_hash = {}
    for v in vars_:
        d = sparse_column(model, v, eq_rows)
        vec = dense_signature(
            {i - 880: a for i, a in d.items()}, 440
        )
        eq_vectors.append(vec)
        eq_hash[v.index] = vec

    cap_owner = {}
    cap_lhs = [Fraction(0)] * 880
    cap_rhs = [Fraction(0)] * 880
    cap_coeff = {}
    for i in cap_rows:
        r = sparse_row(model, cons[i])
        cap_rhs[i] = -F(cons[i].RHS)
        for j, a in r.items():
            cap_owner[j] = i
            cap_coeff[(i, j)] = -a
            cap_lhs[i] += (-a) * values[j]

    selected = [j for j in range(model.NumVars) if values[j] == 1]
    unselected = [j for j in range(model.NumVars) if values[j] == 0]
    objective_support = {
        j for j, v in enumerate(vars_) if F(v.Obj) != 0
    }

    best_values = dict(values)
    best_obj = initial_obj
    best_delta = Fraction(0)
    best_move = None
    phase = {}
    exceptions = []

    def time_left():
        return args.time_limit - (time.monotonic() - started)

    def try_swap(offs, ons, label):
        nonlocal best_obj, best_values, best_delta, best_move
        trial = dict(values)
        for j in offs:
            trial[j] = 0
        for j in ons:
            trial[j] = 1

        # Equality preservation is checked by caller; caps are checked here.
        touched = set()
        for j in offs + ons:
            if j in cap_owner:
                touched.add(cap_owner[j])
        for r in touched:
            lhs = cap_lhs[r]
            for j in offs:
                if cap_owner.get(j) == r:
                    lhs -= cap_coeff[(r, j)]
            for j in ons:
                if cap_owner.get(j) == r:
                    lhs += cap_coeff[(r, j)]
            if lhs > cap_rhs[r]:
                return False

        delta = sum(F(vars_[j].Obj) for j in ons) - \
                sum(F(vars_[j].Obj) for j in offs)
        if delta < 0:
            candidate_obj = initial_obj + delta
            if candidate_obj < best_obj:
                best_obj = candidate_obj
                best_delta = initial_obj - best_obj
                best_values = trial
                best_move = {"kind": label, "off": offs, "on": ons}
                return True
        return False

    # Phase 1: exhaustive equality-preserving 2-swaps.
    t0 = time.monotonic()
    on_by_vec = collections.defaultdict(list)
    for j in unselected:
        on_by_vec[eq_vectors[j]].append(j)

    tested2 = feasible2 = improving2 = 0
    for off in selected:
        if time_left() <= 0:
            break
        for on in on_by_vec.get(eq_vectors[off], []):
            tested2 += 1
            if try_swap([off], [on], "2-flip"):
                feasible2 += 1
                improving2 += 1
            else:
                # Equality is exact by construction; count cap-feasible
                # non-improvements separately below only when cap passes.
                touched = set()
                ok = True
                for j in (off, on):
                    if j in cap_owner:
                        touched.add(cap_owner[j])
                for r in touched:
                    lhs = cap_lhs[r]
                    if cap_owner.get(off) == r:
                        lhs -= cap_coeff[(r, off)]
                    if cap_owner.get(on) == r:
                        lhs += cap_coeff[(r, on)]
                    if lhs > cap_rhs[r]:
                        ok = False
                if ok:
                    feasible2 += 1
    phase["two_flip"] = {
        "tested": tested2,
        "feasible": feasible2,
        "improving": improving2,
        "exhaustive": len(on_by_vec) > 0 and time_left() > 0,
        "seconds": time.monotonic() - t0,
        "skipped_due_to_time": time_left() <= 0,
    }

    # Association closure for phase 2.
    t0 = time.monotonic()
    seed = set(objective_support)
    seed_rows = set()
    for j in seed:
        seed_rows.update(i for i, a in enumerate(eq_vectors[j]) if a)
    closure = set(seed)
    for j, vec in enumerate(eq_vectors):
        if any(vec[i] != 0 for i in seed_rows):
            closure.add(j)
    if len(closure) > args.association_cap:
        closure = set(sorted(
            closure,
            key=lambda j: (j not in objective_support, j)
        )[:args.association_cap])

    csel = sorted(j for j in selected if j in closure)
    cun = sorted(j for j in unselected if j in closure)
    off_pairs = list(itertools.combinations(csel, 2))
    on_pairs = list(itertools.combinations(cun, 2))
    skipped_pair_products = max(0, len(off_pairs) * len(on_pairs)
                               - args.four_pair_cap)
    if len(off_pairs) * len(on_pairs) > args.four_pair_cap:
        # Retain pairs with largest potential objective benefit.
        off_pairs.sort(key=lambda p: sum(F(vars_[j].Obj) for j in p))
        on_pairs.sort(key=lambda p: -sum(F(vars_[j].Obj) for j in p))
        on_pairs = on_pairs[:max(1, args.four_pair_cap // max(1, len(off_pairs)))]

    on_pair_hash = collections.defaultdict(list)
    for p in on_pairs:
        on_pair_hash[add_vec(eq_vectors[p[0]], eq_vectors[p[1]])].append(p)

    tested4 = feasible4 = improving4 = 0
    for off in off_pairs:
        if time_left() <= 0:
            break
        target = add_vec(eq_vectors[off[0]], eq_vectors[off[1]], sign=1)
        for on in on_pair_hash.get(target, []):
            tested4 += 1
            if try_swap(list(off), list(on), "4-flip"):
                feasible4 += 1
                improving4 += 1
    phase["four_flip"] = {
        "association_seed_columns": len(objective_support),
        "association_rows": len(seed_rows),
        "association_closure_columns": len(closure),
        "selected_columns_in_closure": len(csel),
        "unselected_columns_in_closure": len(cun),
        "selected_pair_count": len(off_pairs),
        "unselected_pair_count": len(on_pairs),
        "pair_product_skipped": skipped_pair_products,
        "tested": tested4,
        "feasible": feasible4,
        "improving": improving4,
        "seconds": time.monotonic() - t0,
        "complete_within_requested_pair_cap": (
            len(off_pairs) * len(on_pairs) <= args.four_pair_cap
        ),
        "skipped_due_to_time": time_left() <= 0,
    }

    # Phase 3: exact MITM within every objective-bearing mother group.
    t0 = time.monotonic()
    objective_groups = []
    for g in range(880):
        support = sorted(sparse_row(model, cons[g]))
        if any(F(vars_[j].Obj) != 0 for j in support):
            objective_groups.append((g, support))

    group_tested = group_proved = group_skipped = 0
    group_reports = []

    for g, cols in objective_groups:
        if time_left() <= 0:
            group_skipped += 1
            continue
        mid = len(cols) // 2
        left, right = cols[:mid], cols[mid:]
        current_eq = tuple(
            sum(eq_vectors[j][i] * values[j] for j in cols)
            for i in range(440)
        )
        current_cap = sum(
            cap_coeff.get((g, j), Fraction(0)) * values[j] for j in cols
        )
        U = cap_rhs[g]

        # Enumerate half subsets. The group size is at most 31.
        def subset_sums(part):
            out = collections.defaultdict(list)
            for mask in range(1 << len(part)):
                vec = [Fraction(0)] * 440
                obj = Fraction(0)
                cap = Fraction(0)
                bits = []
                for k, j in enumerate(part):
                    if mask & (1 << k):
                        bits.append(j)
                        obj += F(vars_[j].Obj)
                        vec = [vec[i] + eq_vectors[j][i]
                               for i in range(440)]
                        cap += cap_coeff.get((g, j), Fraction(0))
                out[tuple(vec)].append((obj, cap, bits))
            return out

        L = subset_sums(left)
        R = subset_sums(right)
        target_obj = None
        target_bits = None
        for lv, litems in L.items():
            need = tuple(current_eq[i] - lv[i] for i in range(440))
            for lo, lc, lb in litems:
                for ro, rc, rb in R.get(need, []):
                    if lc + rc <= U:
                        value = lo + ro
                        if target_obj is None or value < target_obj:
                            target_obj = value
                            target_bits = set(lb + rb)
        group_tested += 1
        if target_obj is not None:
            current_obj = sum(F(vars_[j].Obj) * values[j] for j in cols)
            proved = target_obj >= current_obj
            if proved:
                group_proved += 1
            else:
                old = {j: values[j] for j in cols}
                for j in cols:
                    values[j] = Fraction(1 if j in target_bits else 0)
                if try_swap(
                    [j for j in cols if old[j] == 1 and values[j] == 0],
                    [j for j in cols if old[j] == 0 and values[j] == 1],
                    "mother-group-MITM",
                ):
                    pass
            if len(group_reports) < MAX_GROUP_REPORTS:
                group_reports.append({
                    "mother_group": g,
                    "size": len(cols),
                    "current_objective": fs(current_obj),
                    "best_local_objective": fs(target_obj),
                    "locally_optimal": proved,
                })

    phase["mother_group_mitm"] = {
        "objective_bearing_groups": len(objective_groups),
        "tested": group_tested,
        "proved_locally_optimal": group_proved,
        "skipped": group_skipped,
        "seconds": time.monotonic() - t0,
        "reports": group_reports,
    }

    # Independently validate only the best candidate.
    witness = None
    if best_obj < initial_obj:
        final_obj, final_bad = validate(model, best_values)
        if final_obj == best_obj and not final_bad:
            write_solution(args.witness, model, best_values)
            witness = {
                "path": os.path.abspath(args.witness),
                "objective": fs(final_obj),
                "delta_from_initial": fs(final_obj - initial_obj),
                "independent_validation_passed": True,
                "move": best_move,
            }
        else:
            witness = {
                "path": None,
                "objective": fs(final_obj),
                "delta_from_initial": fs(final_obj - initial_obj),
                "independent_validation_passed": False,
                "validation_exceptions": final_bad[:MAX_EXCEPTIONS],
                "move": best_move,
            }

    orbit_like_multiplicities = collections.Counter()
    for row in cap_rows:
        size = len(sparse_row(model, cons[row]))
        orbit_like_multiplicities[size] += 1

    result = {
        "instance": {
            "mps": os.path.abspath(args.mps),
            "incumbent": os.path.abspath(args.incumbent),
            "variables": model.NumVars,
            "constraints": model.NumConstrs,
            "nonzeros": model.NumNZs,
            "equality_rows": 440,
            "cap_rows": 880,
        },
        "incumbent_validation": {
            "parse_errors": parse_errors,
            "parsed_columns": len(values),
            "objective": fs(initial_obj),
            "exceptions": initial_bad[:MAX_EXCEPTIONS],
            "strict_feasible": not initial_bad,
        },
        "mother_groups": {
            "count": 946,
            "cap_group_count": 880,
            "uncapped_group_count": 66,
            "cap_group_size_histogram": dict(
                sorted(orbit_like_multiplicities.items())
            ),
            "all_columns_assigned_once": True,
        },
        "phases": phase,
        "best_result": {
            "initial_objective": fs(initial_obj),
            "best_objective": fs(best_obj),
            "best_delta_improvement": fs(best_delta),
            "strict_improvement_found": best_obj < initial_obj,
            "witness": witness,
        },
        "next_structural_method": {
            "rank": 1,
            "method": (
                "Build the exact 17,909-orbit count model and apply "
                "association-aware 2-/4-count moves; preserve cap rows "
                "incrementally and use mother-group MITM as a local oracle."
            ),
            "rank2": (
                "If no improvement appears, enumerate cross-mother-group "
                "zero-equality-sum exchanges among objective-support orbit "
                "representatives."
            ),
            "rank3": (
                "Use the quotient as a PB/SAT instance for cutoff "
                "objective <= -449537; this script makes no infeasibility "
                "claim."
            ),
        },
        "claims": {
            "optimization_called": False,
            "presolve_called": False,
            "global_optimality_claimed": False,
            "global_infeasibility_claimed": False,
        },
    }

    with open(args.output, "w") as h:
        json.dump(result, h, indent=2, sort_keys=True)
        h.write("\n")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
