# polygonpack4-15：零容差几何审计与严格可行修复

## 当前结论

本目录不声称求得全局最优解，也没有给出新的严格全局下界。
截至 2026-09-08，[MIPLIB 实例页](https://miplib.zib.de/instance_details_polygonpack4-15.html)
仍将该实例标为 `open`，页面 headline 为
`-63613643.56171419*`。

本次研究得到一个对原始 MPS **Decimal-zero 严格可行**的解：

```text
-63613612.411253203798895776945039039679517786115253261679620248786239374280175909
```

对原始 144,478 条约束、所有变量界及所有整数变量逐项使用 80 位
`Decimal` 重放后，违约数均为零。严格解保存在
[`solutions/polygonpack4-15-strict.sol`](solutions/polygonpack4-15-strict.sol)，
复核输出保存在
[`solutions/strict-candidate.validation.log`](solutions/strict-candidate.validation.log)。

但这是一个最小化模型。严格点比页面 headline **差**
`31.150460986201104223054960960320482213884746738320379751213760625719824091`，
因此不能写成 MIPLIB incumbent 改善。五个公开 solution revision 均不是
Decimal-zero 可行点；“首个严格点”只能限定为“本目录审计的官方 revision
与本次归档”，不能外推为历史上或全世界首个严格点。

## 问题背景

MIPLIB 将问题描述为：从 15 个允许非凸的多边形中选择总面积尽可能大的
子集，将它们无重叠地放入给定矩形，并允许每个多边形采用
0、90、180 或 270 度旋转。多边形没有完全包围的洞，但可以有凹入的
“bays”。官方页面没有给出 bibliography。

原始 MPS 的意大利语行名直接暴露了提交模型的结构：

- `contenimento`：容器内包含约束；
- `vincoli_di_scelta_della_slice`：为对象对及旋转对选择 no-fit slice；
- `vincoli_di_non_sovrapposizione`：激活 slice 后的线性无重叠半空间。

这种结构与 no-fit-polygon 的分片 MIP 建模一致。
[Lastra-Díaz 与 Ortuño 的 vertical-slice NFP 论文](https://arxiv.org/abs/2206.00032)
可作为方法背景，但本文不将它声称为本实例的来源。未找到原始多边形顶点，
所以这里的“几何恢复”是对已提交 decimal MPS 的精确恢复，不是对未知的
MPS 之前几何数据进行独立碰撞验证。

## 必需的 Gurobi 只读结构检查

原始压缩 MPS 先在 `euler4` 上由 Gurobi 13.0.1 读取；没有调用
`presolve()` 或 `optimize()`。完整记录见
[`analysis/gurobi-13.0.1-structure.json`](analysis/gurobi-13.0.1-structure.json)
和 [`logs/gurobi-13.0.1-structure.log`](logs/gurobi-13.0.1-structure.log)。

| 属性 | 数值 |
|---|---:|
| 变量 | 44,237 |
| 约束 | 144,478 |
| 非零元 | 731,949 |
| 连续变量 | 30 |
| `0..1` 整数变量 | 44,207 |
| 非零目标列 | 90：60 个负系数、30 个正系数 |
| 非零矩阵系数绝对值范围 | `1e-5` 至 `42327.79041` |

压缩 MPS SHA-256 为
`bb90234202f75e782b6813ff59583e638c5c29e01d8091f72fdeaa14ad57662b`。
输入文件为 [`input/polygonpack4-15.mps.gz`](input/polygonpack4-15.mps.gz)。

## 从 MPS 恢复的精确块结构

[`analysis/exact-geometry-structure.json`](analysis/exact-geometry-structure.json)
由 MPS 中的有限十进制字符串直接生成。

| 角色 | 数量 |
|---|---:|
| 对象坐标变量 | 30，即 15 对 `(x_i,y_i)` |
| presence/orientation 变量 | 60，即 `15 × 4` |
| no-fit slice 二元变量 | 44,147 |
| containment 行 | 60 |
| orientation-cardinality 行 | 30 |
| slice-choice 行 | 1,680 |
| no-fit 半空间行 | 142,708 |

1,680 个 choice 块恰为
`C(15,2) × 4 × 4`：每个无序对象对及旋转对各有一个。包含约束右端项
恢复出的容器尺寸为 `350 × 250`。目标函数的 60 个 orientation 项为负，
30 个非负坐标变量具有正成本，slice 变量成本为零；这一符号结构也用于后面的
presence-mask 目标层筛选。

对象 `{0,1}`、`{2,3}`、`{4,5,6,7}`、`{9,10}` 和 `{11,12}`
具有重复的包围盒及目标系数模式。但扩展 slice 表示在交换对象端点时可能使用
不同的分片，本目录没有证明这些分片投影出的多面体并集完全相同，因此未把这些
数值同族当成可证的置换对称性，也没有据此外推任何搜索结果。

## 全部公开 revision 的严格审计

审计直接读取 MPS 与 solution 文件中的十进制字符串；solution 未列出的变量
按零处理。下表中的“整数违约数”会计入任何非零整数距离，包括小于通常 solver
容差的量。所有 revision 的变量界违约数均为零。

| revision | literal objective | 行违约数 | 最大行违约 | 整数违约数 | Decimal-zero |
|---:|---:|---:|---:|---:|---|
| 1 | `-52235913.7991062816116702336` | 6 | `8.19057692e-10` | 0 | 否 |
| 2 | `-59349778.27123185047755816506` | 4 | `1.2573818e-13` | 0 | 否 |
| 3 | `-59923296.24180550884784450020372657999982707971742329115915688` | 10 | `4.69301581752e-8` | 8 | 否 |
| 4 | `-63613612.41121811594458122082130768361056` | 5 | `1.0967327635355990779863043e-7` | 0 | 否 |
| 5 | `-63613643.561714190309889893158544297551680282860` | 49 | `7.68619070502895043e-6` | 20 | 否 |

逐 revision 的完整证据为
[`analysis/polygonpack4-15-public-1-exact-audit.json`](analysis/polygonpack4-15-public-1-exact-audit.json)
至
[`analysis/polygonpack4-15-public-5-exact-audit.json`](analysis/polygonpack4-15-public-5-exact-audit.json)，
对应的原始公开解保存在 [`input/`](input/) 中。

revision 5 中两个主要的额外 orientation 值约为 `4.2984391e-6` 和
`3.3877516e-6`。它们的负目标系数很大，造成了页面上的名义改善，同时又破坏
整数性及相关 cardinality/slice-choice 行。因此 headline 是容差意义下的数值点，
不能直接作为零容差严格点。

## 严格修复点

修复过程先将所有离散变量取整并固定，只对 30 个坐标变量求一个内部可行点；
随后在所有含坐标的不等式上保留至多 `1e-8` 的安全边距，优化坐标目标，并将坐标
有理化到分母不超过 `10^9`。最终再次读取原始 MPS 做全量复核。

严格点选中的对象与旋转为：

```text
{0:r3, 1:r3, 2:r1, 3:r2, 11:r0, 12:r3, 13:r0}
```

机器可读审计为
[`analysis/strict-candidate-literal-audit.json`](analysis/strict-candidate-literal-audit.json)。
解、审计和第二套 checker 日志的 SHA-256 分别为：

```text
b4a065d5a2c66c02b74e6e732ad442f6bea37b3eda8d17d248069255c5bda288  solutions/polygonpack4-15-strict.sol
45271a34f8d345320b765d93a6144de0f34c37dc5b92c47f8b715f46ee260ad1  analysis/strict-candidate-literal-audit.json
02995154bc657c8948e5b5a802955bbe42bbf091965efcada385f3b35c71834c  solutions/strict-candidate.validation.log
```

## 求解实验

### 固定离散布局

COPT 8.0.4 固定全部 44,207 个离散变量，仅重新优化 30 个坐标变量，
在 0.217 秒内以 status 1 返回浮点目标 `-63613612.4112569`。
见 [`experiments/fixed-pattern-summary.json`](experiments/fixed-pattern-summary.json)。
该结果只说明给定离散布局下的数值坐标优化；严格参考值仍是上面的有理安全点。

### orientation/presence 局部分支

坐标与全部 slice 变量保持自由，只限制 60 个 orientation/presence 位相对严格点的
Hamming 距离。

| 半径 | 时限 / 线程 | 节点 | 浮点 incumbent | 浮点 bound | 结果 |
|---:|---:|---:|---:|---:|---|
| 2 | 600 秒 / 12 | 3,093 | `-63613612.4112569` | `-79272045.73355968` | 超时；离散布局未变 |
| 3 | 420 秒 / 10 | 803 | `-63613612.4112569` | `-87100554.49559385` | 超时；离散布局未变 |

摘要分别为 [`experiments/radius2-summary.json`](experiments/radius2-summary.json)
和 [`experiments/radius3-summary.json`](experiments/radius3-summary.json)。执行脚本的
`interpretation` 文本被硬编码成 radius 2；radius 3 文件中的
`radius_on_60_presence_orientation_bits=3` 才是正确参数。这个文字瑕疵不影响数值字段。

### 单/双对象邻域

[`experiments/object-neighborhoods/`](experiments/object-neighborhoods/) 保存 39 个
30 秒、4 线程摘要：15 个单对象自由邻域和 24 个定向双对象交换邻域。所有实验
均以 status 8 达到时限，共探索 112,111 个节点、累计求解约 1,171.48 秒；
39 个 incumbent 的离散签名都与严格起点相同，未产生需要进一步严格复核的新布局。

### 精确目标层筛选

[`analysis/objective-layer-screen.json`](analysis/objective-layer-screen.json)
枚举全部 `2^15=32,768` 个 presence masks。由于坐标目标项非负且 slice 成本为零，
每个 mask 的四旋转最小系数之和是严格的目标下界。该筛选证明 21,258 个 masks
不可能严格改善当前严格点，仍有 11,510 个 masks 未排除。

这只是目标层排除，不是原 MIP 的新全局 lower bound，也没有闭合剩余 masks。

## 证据边界

- 严格解为最小化问题提供严格可行上界，不提供下界。
- COPT 的 `best_bound` 是浮点 solver 输出；局部分支中的 bound 还只对应受限邻域。
- status 8 仅表示达到时限，不能解释为邻域最优或不可行。
- fixed-pattern status 1 只对固定离散布局成立。
- 当前没有可移植的全局最优性证明，不得将本实例标为 `optimal`。

## 复现零容差检查

从仓库根目录运行：

```bash
python common/exact_mps_solution_check.py \
  instances/polygonpack4-15/input/polygonpack4-15.mps.gz \
  instances/polygonpack4-15/solutions/polygonpack4-15-strict.sol \
  --tolerance 0

for revision in 1 2 3 4 5; do
  python common/exact_mps_solution_check.py \
    instances/polygonpack4-15/input/polygonpack4-15.mps.gz \
    instances/polygonpack4-15/input/polygonpack4-15-public-${revision}.sol.gz \
    --tolerance 0
done

python instances/polygonpack4-15/experiments/recover_geometry_xml.py \
  instances/polygonpack4-15/input/polygonpack4-15.mps.gz \
  instances/polygonpack4-15/analysis/reproduced-geometry-and-solution-audit.json \
  --solution instances/polygonpack4-15/solutions/polygonpack4-15-strict.sol \
  --active-limit 1e-8

python instances/polygonpack4-15/experiments/screen_object_subsets15.py \
  instances/polygonpack4-15/input/polygonpack4-15.mps.gz \
  -63613612.411253203798895776945039039679517786115253261679620248786239374280175909 \
  instances/polygonpack4-15/analysis/reproduced-objective-layer-screen.json

(cd instances/polygonpack4-15 && sha256sum -c SHA256SUMS)
```

第一个命令应报告零行、界和整数性违约；revision 循环会复现官方解审计表。
几何恢复和目标筛选命令会创建新的复现输出，
不要覆盖归档文件；生成后可与归档 JSON 的结论字段比较。
Windows PowerShell 没有 `sha256sum` 时，可用 `Get-FileHash -Algorithm SHA256`
逐项核对 `SHA256SUMS`。

## 文件清单与排除项

- `input/`：原始 MPS 与五个官方 solution revisions；
- `analysis/`：Gurobi 只读结构、精确几何结构、五个官方审计、严格点审计和 mask 筛选；
- `solutions/`：最终严格 solution 与第二 checker 日志；
- `experiments/`：结构恢复、目标筛选、COPT 脚本及局部实验摘要；
- `logs/`：Gurobi 读取日志；
- `SHA256SUMS`：除清单自身外，本目录全部归档文件的 SHA-256。

以下旧文件没有归档：

```text
polygonpack4-15-rev5-polished-literal-audit.json
```

该文件来自尚不支持 XML solution 的旧解析器，曾把非空 XML 解误当成全零解。
较早的 `*-polished-literal-audit-v2.json` 是 `1e-5` 安全边距版本，也没有保留；
最终依据是本目录的 `margin1e8` 严格解及两套零容差复核。
