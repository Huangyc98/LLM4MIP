# Package manifest: polygonpack4-15

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 66
Excluded source files: 1

## Included files

- `README.md`
- `SHA256SUMS`
- `analysis/exact-geometry-structure.json`
- `analysis/gurobi-13.0.1-structure.json`
- `analysis/objective-layer-screen.json`
- `analysis/polygonpack4-15-public-1-exact-audit.json`
- `analysis/polygonpack4-15-public-2-exact-audit.json`
- `analysis/polygonpack4-15-public-3-exact-audit.json`
- `analysis/polygonpack4-15-public-4-exact-audit.json`
- `analysis/polygonpack4-15-public-5-exact-audit.json`
- `analysis/strict-candidate-literal-audit.json`
- `experiments/copt_fix_and_reoptimize30.py`
- `experiments/copt_object_neighborhood.py`
- `experiments/copt_orientation_local_branch.py`
- `experiments/fixed-pattern-summary.json`
- `experiments/object-neighborhoods/case-0.json`
- `experiments/object-neighborhoods/case-1.json`
- `experiments/object-neighborhoods/case-10.json`
- `experiments/object-neighborhoods/case-11-10.json`
- `experiments/object-neighborhoods/case-11-14.json`
- `experiments/object-neighborhoods/case-11-4.json`
- `experiments/object-neighborhoods/case-11-5.json`
- `experiments/object-neighborhoods/case-11-6.json`
- `experiments/object-neighborhoods/case-11-7.json`
- `experiments/object-neighborhoods/case-11-8.json`
- `experiments/object-neighborhoods/case-11-9.json`
- `experiments/object-neighborhoods/case-11.json`
- `experiments/object-neighborhoods/case-12-10.json`
- `experiments/object-neighborhoods/case-12-14.json`
- `experiments/object-neighborhoods/case-12-4.json`
- `experiments/object-neighborhoods/case-12-5.json`
- `experiments/object-neighborhoods/case-12-6.json`
- `experiments/object-neighborhoods/case-12-7.json`
- `experiments/object-neighborhoods/case-12-8.json`
- `experiments/object-neighborhoods/case-12-9.json`
- `experiments/object-neighborhoods/case-12.json`
- `experiments/object-neighborhoods/case-13-10.json`
- `experiments/object-neighborhoods/case-13-14.json`
- `experiments/object-neighborhoods/case-13-4.json`
- `experiments/object-neighborhoods/case-13-5.json`
- `experiments/object-neighborhoods/case-13-6.json`
- `experiments/object-neighborhoods/case-13-7.json`
- `experiments/object-neighborhoods/case-13-8.json`
- `experiments/object-neighborhoods/case-13-9.json`
- `experiments/object-neighborhoods/case-13.json`
- `experiments/object-neighborhoods/case-14.json`
- `experiments/object-neighborhoods/case-2.json`
- `experiments/object-neighborhoods/case-3.json`
- `experiments/object-neighborhoods/case-4.json`
- `experiments/object-neighborhoods/case-5.json`
- `experiments/object-neighborhoods/case-6.json`
- `experiments/object-neighborhoods/case-7.json`
- `experiments/object-neighborhoods/case-8.json`
- `experiments/object-neighborhoods/case-9.json`
- `experiments/radius2-summary.json`
- `experiments/radius3-summary.json`
- `experiments/recover_geometry_xml.py`
- `experiments/screen_object_subsets15.py`
- `input/polygonpack4-15-public-1.sol.gz`
- `input/polygonpack4-15-public-2.sol.gz`
- `input/polygonpack4-15-public-3.sol.gz`
- `input/polygonpack4-15-public-4.sol.gz`
- `input/polygonpack4-15-public-5.sol.gz`
- `logs/gurobi-13.0.1-structure.log`
- `solutions/polygonpack4-15-strict.sol`
- `solutions/strict-candidate.validation.log`

## Excluded files

- `input/polygonpack4-15.mps.gz (6659645 bytes; raw benchmark input; sha256 bb90234202f75e782b6813ff59583e638c5c29e01d8091f72fdeaa14ad57662b)`
