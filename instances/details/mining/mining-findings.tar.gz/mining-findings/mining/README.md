# `mining` — certified lower bound from a 40-row Lagrangian relaxation

## Result (2026-09-07)

This is a minimization instance.  The strongest bounds established in this
directory are

```text
strict global lower bound  LB = -835361895.5863052144840282387439
exact feasible upper bound UB = -833589149.2736538586882046
```

Thus

```text
LB <= optimum <= UB.
```

For a negative minimization objective, improving the lower bound means making
it *larger* (less negative).  Using the requested definition

```text
(UB - LB) / max(1, |UB|)
```

the certified relative gap is
`0.002126642740246840477890906013...`, or **0.2126642740%**.  The
absolute gap is `1772746.3126513557958236387439`.

The current [MIPLIB instance page](https://miplib.zib.de/instance_details_mining.html)
labels the problem open and publishes the incumbent (rounded on the page), but
does not publish a current dual bound.  The older
[MIPLIB 2010 page](https://miplib2010.zib.de/miplib2010/mining.php) publishes
the historical LP value `-949724584.696851`.  The new certified bound is
`114362689.1105457855159717612561` higher than that historical value and
closes 98.4735526% of the interval from that LP value to the exact incumbent.
This is specifically a comparison with the **historical MIPLIB 2010 LP
value**, not a claim to beat an unpublished current MIPLIB dual bound.

The user supplied the earlier result that the 20-level threshold DAG and
maximum-closure/min-cut route had already been tried without a bound
improvement.  That result is treated as prior work.  The new contribution here
is the exact original-MPS audit, the discovery that the audited block graph is
a disjoint union of paths, the 40-capacity Lagrangian optimization, and its
standalone certificate replay.

## Exact structure recovered from the original MPS

Gurobi 13.0.1 on `euler4` was used first and only for `gp.read()` plus
read-only matrix/attribute inspection; `optimize()` was never called.  The
machine used `/home/wyc/miniconda3/envs/milp-ps/bin/python`.  The resulting
[JSON](analysis/mining-gurobi-structure.json) and
[log](analysis/gurobi-read-euler4.log) record `optimize_called: false`,
661,133 rows, 348,921 columns, 3,844,879 stored nonzeros, 348,920 integer
variables and one continuous variable.

The independent parser then checked every coefficient needed by the reduction:

- The 348,920 binaries form 17,446 blocks of 20.  The 331,474 vertical rows
  force each block to be a binary suffix, represented exactly by one of 21
  threshold states (first selected period 0--19, or 20 for never).
- All 329,580 horizontal rows form 16,479 audited 20-row implication gadgets.
  On suffix states, each gadget is exactly `threshold[u] <= threshold[v]`.
- The resulting graph has 967 weak components, 16,479 distinct edges, no
  cycle, duplicate or self edge, maximum in/out-degree one, and no transitive
  edge.  It is therefore 967 disjoint directed paths, not a general DAG.
- Of the 78 mixed rows, 38 difference rows have nonpositive activity for every
  block state and zero RHS, so they are redundant on the exact threshold
  domain.  The other 40 are two resources times 20 periods and are the only
  rows relaxed.
- `x348921` has objective coefficient `948653737.393142` and is fixed to one
  by the final equality.  The checker derives this constant from the MPS; it
  is not a checker-side magic number.

The full audit is in [structure.json](analysis/structure.json), with the
reconstructor in [reconstruct_threshold_dag.py](experiments/reconstruct_threshold_dag.py).

## Why the lower bound is global

For the 40 original capacity inequalities `Ax <= b`, choose the nonnegative
finite-decimal multipliers in
[lagrangian-refine2-6000.json](experiments/lagrangian-refine2-6000.json).
For every original feasible integer solution,

```text
c(x) + lambda * (A x - b) <= c(x).
```

After relaxing those 40 rows, all retained constraints are exactly the 967
monotone paths described above.  Their Lagrangian inner minimum is computed by
an exhaustive 21-state dynamic program on each path.  Consequently that inner
minimum is a valid global lower bound on the original minimization model.  A
finite decimal is a rational number, so the stored multipliers and all MPS
coefficients are replayed with 80-digit `Decimal` arithmetic, not floating
point.

[lagrangian-refine2-6000-trace.jsonl.gz](experiments/lagrangian-refine2-6000-trace.jsonl.gz)
stores every one of the final refinement's 6,001 evaluations: both 20-vectors
of multipliers, both 20-vectors of subgradients, the current bound, and the
best-so-far bound.  Its SHA-256 is
`787532f419d30e164edbc31418cd7e1c5dea47e9633151b5c17cda9320084318`,
also frozen inside the certificate.

Most importantly,
[check_lagrangian_from_mps.py](experiments/check_lagrangian_from_mps.py) reads
only the original MPS and the final certificate.  It does **not** trust the
generated threshold model or edge file.  It independently reconstructs the
reduction and exact DP.  The saved
[replay report](experiments/lagrangian-refine2-6000-from-mps-replay.json) has
**21/21 checks true**.  Those 21 checks cover: source hash; row layout/senses;
absence of ranges; column presence; integrality and bounds; exact vertical
rows; mixed-column support; difference-row RHS and statewise redundancy;
capacity senses and period pattern; horizontal gadgets; path-forest coverage;
the fixed continuous constant; the exact list of dualized rows; multiplier
finiteness/nonnegativity; witness monotonicity; witness equality with the DP;
resource-usage equality; and final stored-bound equality.

The official solution was separately evaluated against all original rows with
exact decimals and tolerance zero:

```text
objective=-833589149.2736538586882046
rows=661133 exact_row_violations=0
bound_violations=0 integrality_violations=0
```

No new feasible solution was found and optimality is not proved.

## Reproduction

Run from the repository root:

```sh
python instances/mining/experiments/reconstruct_threshold_dag.py \
  instances/mining/input/mining.mps.gz \
  instances/mining/analysis/structure.rebuilt.json \
  --solution instances/mining/solutions/official-best.sol.gz \
  --threshold-model instances/mining/analysis/threshold-model.rebuilt.jsonl.gz \
  --edges instances/mining/analysis/threshold-dag-edges.rebuilt.json

python instances/mining/experiments/check_lagrangian_from_mps.py \
  instances/mining/input/mining.mps.gz \
  instances/mining/experiments/lagrangian-refine2-6000.json \
  instances/mining/experiments/lagrangian-refine2-6000-from-mps-replay.rebuilt.json

python common/exact_mps_solution_check.py \
  instances/mining/input/mining.mps.gz \
  instances/mining/solutions/official-best.sol.gz --tolerance 0
```

The original compressed MPS SHA-256 is
`b460c0f02b2bd0262d2a53c677705cdceffca77db61623730c5260e703b76a57`.

## Background sources

- [Current MIPLIB `mining` page](https://miplib.zib.de/instance_details_mining.html):
  open status, current incumbent, dimensions, and the documented 20-variable
  implication tightening.
- [MIPLIB 2010 `mining` page](https://miplib2010.zib.de/miplib2010/mining.php):
  historical LP value and original application note.
- [Muñoz et al., *A study of the Bienstock-Zuckerberg algorithm*](https://arxiv.org/abs/1607.01104):
  general background on Lagrangian/decomposition methods for mining and
  resource-constrained project scheduling.  MIPLIB itself calls this exact
  instance an unspecified mining application, so the paper is context rather
  than a claimed provenance match.
