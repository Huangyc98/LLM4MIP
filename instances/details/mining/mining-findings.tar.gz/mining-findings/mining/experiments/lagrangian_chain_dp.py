#!/usr/bin/env python3
"""Optimize a Lagrangian bound for mining's 967 precedence chains.

The 40 per-period capacity rows are dualized.  The remaining problem is a
collection of 21-state monotone chains and is solved exactly by dynamic
programming at every iteration.  A final finite-decimal multiplier vector is
re-evaluated with Decimal arithmetic and written as a replayable certificate.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
import time
from decimal import Decimal, getcontext
from pathlib import Path


getcontext().prec = 80
PERIODS = 20
NEVER = 20


def load_model(threshold_model: Path, edges_path: Path, structure_path: Path):
    costs: list[list[float]] = []
    weights1: list[list[float]] = []
    weights2: list[list[float]] = []
    exact_records: list[dict] = []
    with gzip.open(threshold_model, "rt", encoding="utf-8") as handle:
        for expected_block, raw in enumerate(handle):
            record = json.loads(raw)
            if record["block_zero_based"] != expected_block:
                raise ValueError("threshold records are not in block order")
            exact_records.append(record)
            block_costs = [float(value) for value in record["objective_by_first_selected_period_zero_based_or_never"]]
            block_w1 = [0.0] * (PERIODS + 1)
            block_w2 = [0.0] * (PERIODS + 1)
            for state, entries in enumerate(record["mixed_activity_by_state"]):
                for row, value_text in entries:
                    value = float(value_text)
                    if 19 <= row <= 38:
                        if state == NEVER or row != 19 + state or block_w1[state] != 0.0:
                            raise ValueError(f"unexpected first resource entry in block {expected_block}, state {state}")
                        block_w1[state] = value
                    elif 58 <= row <= 77:
                        if state == NEVER or row != 58 + state or block_w2[state] != 0.0:
                            raise ValueError(f"unexpected second resource entry in block {expected_block}, state {state}")
                        block_w2[state] = value
                    elif not ((state > 0 and row == state - 1 and value <= 0) or (state > 0 and row == 39 + state - 1 and value <= 0)):
                        raise ValueError(f"nonredundant unexpected row {row} in block {expected_block}, state {state}")
            costs.append(block_costs)
            weights1.append(block_w1)
            weights2.append(block_w2)

    edge_payload = json.loads(edges_path.read_text(encoding="utf-8"))
    edges = [tuple(edge) for edge in edge_payload["edges_zero_based"]]
    n = len(costs)
    successor = [-1] * n
    indegree = [0] * n
    for left, right in edges:
        if successor[left] >= 0:
            raise ValueError("DAG is not a disjoint union of directed paths")
        successor[left] = right
        indegree[right] += 1
        if indegree[right] > 1:
            raise ValueError("DAG is not a disjoint union of directed paths")
    paths: list[list[int]] = []
    seen: set[int] = set()
    for source in range(n):
        if indegree[source]:
            continue
        path: list[int] = []
        node = source
        while node >= 0:
            if node in seen:
                raise ValueError("cycle or repeated node")
            seen.add(node)
            path.append(node)
            node = successor[node]
        paths.append(path)
    if len(seen) != n:
        raise ValueError("not all blocks were covered by source paths")

    structure = json.loads(structure_path.read_text(encoding="utf-8"))
    rhs_by_row = {entry["row"] - 331475: float(entry["rhs"]) for entry in structure["mixed_rows"]}
    capacities1 = [rhs_by_row[19 + period] for period in range(PERIODS)]
    capacities2 = [rhs_by_row[58 + period] for period in range(PERIODS)]
    constant = float(structure["mixed_rows"][0].get("unused", 948653737.393142))
    # x348921 is fixed to one by c661133; its objective is audited by the
    # reconstruction and Gurobi logs.  Keep the exact MPS decimal here.
    constant = 948653737.393142
    return costs, weights1, weights2, paths, capacities1, capacities2, constant, exact_records, edge_payload


def solve_inner(costs, weights1, weights2, paths, lam1, lam2, capacities1, capacities2, constant, recover=True):
    total = constant - sum(lam * cap for lam, cap in zip(lam1, capacities1)) - sum(
        lam * cap for lam, cap in zip(lam2, capacities2)
    )
    usage1 = [0.0] * PERIODS
    usage2 = [0.0] * PERIODS
    states = [NEVER] * len(costs) if recover else None
    for path in paths:
        parents: list[list[int]] = []
        first = path[0]
        dp = [
            costs[first][state]
            + (lam1[state] * weights1[first][state] + lam2[state] * weights2[first][state] if state < PERIODS else 0.0)
            for state in range(PERIODS + 1)
        ]
        for node in path[1:]:
            prefix_value = math.inf
            prefix_arg = -1
            new_dp = [0.0] * (PERIODS + 1)
            parent = [0] * (PERIODS + 1)
            for state in range(PERIODS + 1):
                if dp[state] < prefix_value:
                    prefix_value = dp[state]
                    prefix_arg = state
                adjustment = 0.0
                if state < PERIODS:
                    adjustment = lam1[state] * weights1[node][state] + lam2[state] * weights2[node][state]
                new_dp[state] = prefix_value + costs[node][state] + adjustment
                parent[state] = prefix_arg
            parents.append(parent)
            dp = new_dp
        end_state = min(range(PERIODS + 1), key=dp.__getitem__)
        total += dp[end_state]
        if recover:
            path_states = [NEVER] * len(path)
            path_states[-1] = end_state
            for index in range(len(path) - 1, 0, -1):
                path_states[index - 1] = parents[index - 1][path_states[index]]
            for node, state in zip(path, path_states):
                states[node] = state
                if state < PERIODS:
                    usage1[state] += weights1[node][state]
                    usage2[state] += weights2[node][state]
    return total, usage1, usage2, states


def exact_replay(exact_records, paths, multipliers1: list[Decimal], multipliers2: list[Decimal], capacities1, capacities2):
    exact_costs = [[Decimal(value) for value in record["objective_by_first_selected_period_zero_based_or_never"]] for record in exact_records]
    exact_w1 = [[Decimal(0)] * (PERIODS + 1) for _ in exact_records]
    exact_w2 = [[Decimal(0)] * (PERIODS + 1) for _ in exact_records]
    for block, record in enumerate(exact_records):
        for state, entries in enumerate(record["mixed_activity_by_state"]):
            for row, value_text in entries:
                if 19 <= row <= 38:
                    exact_w1[block][state] = Decimal(value_text)
                elif 58 <= row <= 77:
                    exact_w2[block][state] = Decimal(value_text)
    total = Decimal("948653737.393142")
    total -= sum(lam * Decimal(str(cap)) for lam, cap in zip(multipliers1, capacities1))
    total -= sum(lam * Decimal(str(cap)) for lam, cap in zip(multipliers2, capacities2))
    states = [NEVER] * len(exact_records)
    usage1 = [Decimal(0)] * PERIODS
    usage2 = [Decimal(0)] * PERIODS
    for path in paths:
        parents: list[list[int]] = []
        first = path[0]
        dp = [
            exact_costs[first][state]
            + (
                multipliers1[state] * exact_w1[first][state] + multipliers2[state] * exact_w2[first][state]
                if state < PERIODS
                else Decimal(0)
            )
            for state in range(PERIODS + 1)
        ]
        for node in path[1:]:
            prefix_value: Decimal | None = None
            prefix_arg = -1
            new_dp: list[Decimal] = []
            parent: list[int] = []
            for state in range(PERIODS + 1):
                if prefix_value is None or dp[state] < prefix_value:
                    prefix_value = dp[state]
                    prefix_arg = state
                adjustment = Decimal(0)
                if state < PERIODS:
                    adjustment = multipliers1[state] * exact_w1[node][state] + multipliers2[state] * exact_w2[node][state]
                new_dp.append(prefix_value + exact_costs[node][state] + adjustment)
                parent.append(prefix_arg)
            parents.append(parent)
            dp = new_dp
        end_state = min(range(PERIODS + 1), key=dp.__getitem__)
        total += dp[end_state]
        path_states = [NEVER] * len(path)
        path_states[-1] = end_state
        for index in range(len(path) - 1, 0, -1):
            path_states[index - 1] = parents[index - 1][path_states[index]]
        for node, state in zip(path, path_states):
            states[node] = state
            if state < PERIODS:
                usage1[state] += exact_w1[node][state]
                usage2[state] += exact_w2[node][state]
    return total, usage1, usage2, states


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("threshold_model", type=Path)
    parser.add_argument("edges", type=Path)
    parser.add_argument("structure", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--iterations", type=int, default=2000)
    parser.add_argument("--known-upper-bound", type=float, default=-833589149.2736539)
    parser.add_argument("--checkpoint-every", type=int, default=100)
    parser.add_argument("--initial-certificate", type=Path)
    parser.add_argument("--alpha-start", type=float, default=1.8)
    parser.add_argument("--alpha-end", type=float, default=0.05)
    parser.add_argument("--trace-jsonl-gz", type=Path)
    args = parser.parse_args()

    model = load_model(args.threshold_model, args.edges, args.structure)
    costs, weights1, weights2, paths, caps1, caps2, constant, exact_records, edge_payload = model
    if args.initial_certificate:
        initial = json.loads(args.initial_certificate.read_text(encoding="utf-8"))
        lam1 = [float(value) for value in initial["multipliers_first_resource"]]
        lam2 = [float(value) for value in initial["multipliers_second_resource"]]
    else:
        lam1 = [0.0] * PERIODS
        lam2 = [0.0] * PERIODS
    best_bound = -math.inf
    best_lam1 = lam1[:]
    best_lam2 = lam2[:]
    trace = []
    full_trace_handle = gzip.open(args.trace_jsonl_gz, "wt", encoding="utf-8") if args.trace_jsonl_gz else None
    started = time.time()
    for iteration in range(args.iterations + 1):
        bound, use1, use2, _ = solve_inner(
            costs, weights1, weights2, paths, lam1, lam2, caps1, caps2, constant, recover=True
        )
        if bound > best_bound:
            best_bound = bound
            best_lam1 = lam1[:]
            best_lam2 = lam2[:]
        subgradient = [use - cap for use, cap in zip(use1, caps1)] + [use - cap for use, cap in zip(use2, caps2)]
        norm2 = sum(value * value for value in subgradient)
        if full_trace_handle:
            full_trace_handle.write(
                json.dumps(
                    {
                        "iteration": iteration,
                        "bound": bound,
                        "best_bound": best_bound,
                        "multipliers_first": lam1,
                        "multipliers_second": lam2,
                        "subgradient_first": subgradient[:PERIODS],
                        "subgradient_second": subgradient[PERIODS:],
                    },
                    separators=(",", ":"),
                )
                + "\n"
            )
        if iteration % args.checkpoint_every == 0 or iteration == args.iterations:
            record = {
                "iteration": iteration,
                "bound": bound,
                "best_bound": best_bound,
                "maximum_capacity_violation": max(subgradient),
                "subgradient_norm": math.sqrt(norm2),
                "elapsed_seconds": time.time() - started,
            }
            trace.append(record)
            print(json.dumps(record), flush=True)
        if iteration == args.iterations or norm2 == 0:
            break
        # Polyak ascent with a conservatively decaying relaxation factor.
        phase = iteration / max(1, args.iterations)
        alpha = args.alpha_start * (1.0 - phase) + args.alpha_end * phase
        gap = max(1.0, args.known_upper_bound - bound)
        step = alpha * gap / norm2
        lam1 = [max(0.0, value + step * gradient) for value, gradient in zip(lam1, subgradient[:PERIODS])]
        lam2 = [max(0.0, value + step * gradient) for value, gradient in zip(lam2, subgradient[PERIODS:])]

    if full_trace_handle:
        full_trace_handle.close()

    # Freeze short finite decimals, then recompute the lower bound exactly.
    frozen1 = [Decimal(format(value, ".12g")) for value in best_lam1]
    frozen2 = [Decimal(format(value, ".12g")) for value in best_lam2]
    exact_bound, exact_use1, exact_use2, exact_states = exact_replay(
        exact_records, paths, frozen1, frozen2, caps1, caps2
    )
    certificate = {
        "kind": "mining_lagrangian_40_capacity_chain_dp_lower_bound",
        "valid_scope": "global lower bound for the original integer minimization model",
        "source_mps_sha256": edge_payload["source_sha256"],
        "threshold_model_sha256": hashlib.sha256(args.threshold_model.read_bytes()).hexdigest(),
        "edge_file_sha256": hashlib.sha256(args.edges.read_bytes()).hexdigest(),
        "dualized_original_row_numbers": list(range(331494, 331514)) + list(range(331533, 331553)),
        "multipliers_first_resource": [str(value) for value in frozen1],
        "multipliers_second_resource": [str(value) for value in frozen2],
        "all_multipliers_nonnegative": all(value >= 0 for value in frozen1 + frozen2),
        "exact_decimal_lower_bound": str(exact_bound),
        "floating_optimization_best_before_freeze": best_bound,
        "known_strict_upper_bound_used_only_for_stepsize": args.known_upper_bound,
        "inner_minimizer_thresholds_zero_based_or_20_never": exact_states,
        "inner_minimizer_resource_usage_first": [str(value) for value in exact_use1],
        "inner_minimizer_resource_usage_second": [str(value) for value in exact_use2],
        "trace": trace,
        "full_iteration_trace": str(args.trace_jsonl_gz) if args.trace_jsonl_gz else None,
        "full_iteration_trace_sha256": hashlib.sha256(args.trace_jsonl_gz.read_bytes()).hexdigest() if args.trace_jsonl_gz else None,
        "iterations": args.iterations,
        "elapsed_seconds": time.time() - started,
        "proof_note": "For lambda>=0 and Ax<=b, min_x c(x)+lambda(Ax-b) is a valid lower bound. Each path minimum is exhaustively evaluated by the 21-state monotone DP recurrence.",
    }
    args.output.write_text(json.dumps(certificate, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"exact_decimal_lower_bound": str(exact_bound), "output": str(args.output)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
