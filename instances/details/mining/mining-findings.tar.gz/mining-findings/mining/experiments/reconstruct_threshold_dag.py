#!/usr/bin/env python3
"""Audit mining.mps.gz and reconstruct its 20-period threshold DAG exactly.

The script recognizes structure only after checking every original matrix
coefficient used by the reduction.  It writes a compact, reproducible JSONL
description of the 21 states (period 1..20 or never) for every block.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
from array import array
from collections import Counter, defaultdict, deque
from decimal import Decimal, getcontext
from pathlib import Path


getcontext().prec = 80
SECTIONS = {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}
PERIODS = 20
BINARY_VARIABLES = 348_920
BLOCKS = BINARY_VARIABLES // PERIODS
VERTICAL_ROWS = BLOCKS * (PERIODS - 1)  # 331474
MIXED_FIRST = VERTICAL_ROWS + 1
MIXED_LAST = MIXED_FIRST + 78 - 1
HORIZONTAL_FIRST = MIXED_LAST + 1
HORIZONTAL_ROWS = 16_479 * PERIODS
HORIZONTAL_LAST = HORIZONTAL_FIRST + HORIZONTAL_ROWS - 1
FIXED_ROW = HORIZONTAL_LAST + 1


def number(text: str) -> Decimal:
    return Decimal(text.replace("D", "E").replace("d", "e"))


def open_text(path: Path):
    return gzip.open(path, "rt", encoding="latin-1") if path.suffix == ".gz" else path.open(encoding="latin-1")


def parse_index(name: str, prefix: str) -> int:
    if not name.startswith(prefix) or not name[len(prefix) :].isdigit():
        raise ValueError(f"unexpected name {name!r}")
    return int(name[len(prefix) :])


def parse_solution(path: Path | None) -> set[int]:
    if path is None:
        return set()
    opener = gzip.open if path.suffix == ".gz" else open
    selected: set[int] = set()
    with opener(path, "rt", encoding="utf-8") as handle:
        for raw in handle:
            tokens = raw.split()
            if len(tokens) >= 2 and tokens[0].startswith("x") and tokens[0][1:].isdigit():
                if number(tokens[1]) == 1:
                    selected.add(int(tokens[0][1:]))
    return selected


class UnionFind:
    def __init__(self, n: int):
        self.parent = list(range(n))
        self.size = [1] * n

    def find(self, x: int) -> int:
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x

    def union(self, x: int, y: int) -> None:
        x, y = self.find(x), self.find(y)
        if x == y:
            return
        if self.size[x] < self.size[y]:
            x, y = y, x
        self.parent[y] = x
        self.size[x] += self.size[y]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--solution", type=Path)
    parser.add_argument("--threshold-model", type=Path)
    parser.add_argument("--edges", type=Path)
    args = parser.parse_args()

    selected = parse_solution(args.solution)
    sha256 = hashlib.sha256(args.mps.read_bytes()).hexdigest()
    row_types: dict[int, str] = {}
    rhs: dict[int, Decimal] = defaultdict(Decimal)
    upper_bounds: dict[int, Decimal] = {}
    integer_variables: set[int] = set()
    objective = [Decimal(0)] * (BINARY_VARIABLES + 1)
    official_objective = Decimal(0)
    official_mixed_activity = [Decimal(0)] * 78

    horizontal_pos = array("i", [-1]) * HORIZONTAL_ROWS
    horizontal_neg1 = array("i", [-1]) * HORIZONTAL_ROWS
    horizontal_neg2 = array("i", [-1]) * HORIZONTAL_ROWS
    horizontal_entry_counts = array("b", [0]) * HORIZONTAL_ROWS
    vertical_seen = 0
    vertical_bad: list[dict[str, object]] = []
    horizontal_bad_coefficients: list[dict[str, object]] = []
    mixed_row_nnz = [0] * 78
    mixed_positive = [0] * 78
    mixed_negative = [0] * 78
    mixed_min: list[Decimal | None] = [None] * 78
    mixed_max: list[Decimal | None] = [None] * 78

    threshold_handle = gzip.open(args.threshold_model, "wt", encoding="utf-8") if args.threshold_model else None
    current_block = -1
    block_objective = [Decimal(0)] * PERIODS
    block_mixed: list[dict[int, Decimal]] = [defaultdict(Decimal) for _ in range(PERIODS)]
    state_resource_nnz: Counter[int] = Counter()
    block_state_signature_counts: Counter[tuple[int, ...]] = Counter()

    def flush_block(block: int) -> None:
        nonlocal block_objective, block_mixed
        if block < 0:
            return
        running_objective = Decimal(0)
        running_resources: dict[int, Decimal] = {}
        state_costs: list[str] = ["0"] * (PERIODS + 1)
        state_resources: list[list[list[object]]] = [[] for _ in range(PERIODS + 1)]
        for period in range(PERIODS - 1, -1, -1):
            running_objective += block_objective[period]
            for row, coefficient in block_mixed[period].items():
                value = running_resources.get(row, Decimal(0)) + coefficient
                if value:
                    running_resources[row] = value
                else:
                    running_resources.pop(row, None)
            state_costs[period] = str(running_objective)
            state_resources[period] = [[row, str(value)] for row, value in sorted(running_resources.items())]
            state_resource_nnz[len(running_resources)] += 1
        state_resource_nnz[0] += 1  # never extracted
        block_state_signature_counts[tuple(len(entries) for entries in state_resources)] += 1
        if threshold_handle:
            threshold_handle.write(
                json.dumps(
                    {
                        "block_zero_based": block,
                        "objective_by_first_selected_period_zero_based_or_never": state_costs,
                        "mixed_activity_by_state": state_resources,
                    },
                    separators=(",", ":"),
                )
                + "\n"
            )
        block_objective = [Decimal(0)] * PERIODS
        block_mixed = [defaultdict(Decimal) for _ in range(PERIODS)]

    section = ""
    integer_mode = False
    with open_text(args.mps) as handle:
        for raw in handle:
            tokens = raw.split()
            if not tokens or tokens[0].startswith("*"):
                continue
            if not raw[0].isspace() and tokens[0] in SECTIONS:
                section = tokens[0]
                continue
            if section == "ROWS":
                if tokens[1] != "obj":
                    row_types[parse_index(tokens[1], "c")] = tokens[0]
            elif section == "COLUMNS":
                if "'MARKER'" in tokens:
                    integer_mode = "'INTORG'" in tokens
                    continue
                variable = parse_index(tokens[0], "x")
                if integer_mode:
                    integer_variables.add(variable)
                if variable <= BINARY_VARIABLES:
                    block = (variable - 1) // PERIODS
                    period = (variable - 1) % PERIODS
                    if block != current_block:
                        flush_block(current_block)
                        current_block = block
                else:
                    flush_block(current_block)
                    current_block = -2
                for row_name, coefficient_text in zip(tokens[1::2], tokens[2::2]):
                    coefficient = number(coefficient_text)
                    if row_name == "obj":
                        objective[variable - 1] += coefficient
                        if variable in selected:
                            official_objective += coefficient
                        if variable <= BINARY_VARIABLES:
                            block_objective[period] += coefficient
                        continue
                    row = parse_index(row_name, "c")
                    if row <= VERTICAL_ROWS:
                        vertical_seen += 1
                        block = (variable - 1) // PERIODS
                        period = (variable - 1) % PERIODS
                        base = block * (PERIODS - 1)
                        expected = []
                        if period < PERIODS - 1:
                            expected.append((base + period + 1, Decimal(1)))
                        if period > 0:
                            expected.append((base + period, Decimal(-1)))
                        if (row, coefficient) not in expected and len(vertical_bad) < 100:
                            vertical_bad.append({"variable": variable, "row": row, "coefficient": str(coefficient)})
                    elif MIXED_FIRST <= row <= MIXED_LAST:
                        offset = row - MIXED_FIRST
                        mixed_row_nnz[offset] += 1
                        mixed_positive[offset] += coefficient > 0
                        mixed_negative[offset] += coefficient < 0
                        mixed_min[offset] = coefficient if mixed_min[offset] is None else min(mixed_min[offset], coefficient)
                        mixed_max[offset] = coefficient if mixed_max[offset] is None else max(mixed_max[offset], coefficient)
                        if variable <= BINARY_VARIABLES:
                            block_mixed[period][offset] += coefficient
                        if variable in selected:
                            official_mixed_activity[offset] += coefficient
                    elif HORIZONTAL_FIRST <= row <= HORIZONTAL_LAST:
                        offset = row - HORIZONTAL_FIRST
                        horizontal_entry_counts[offset] += 1
                        if coefficient == 1 and horizontal_pos[offset] < 0:
                            horizontal_pos[offset] = variable
                        elif coefficient == -1 and horizontal_neg1[offset] < 0:
                            horizontal_neg1[offset] = variable
                        elif coefficient == -1 and horizontal_neg2[offset] < 0:
                            horizontal_neg2[offset] = variable
                        elif len(horizontal_bad_coefficients) < 100:
                            horizontal_bad_coefficients.append(
                                {"variable": variable, "row": row, "coefficient": str(coefficient)}
                            )
                    elif row == FIXED_ROW:
                        if not (variable == BINARY_VARIABLES + 1 and coefficient == 1):
                            horizontal_bad_coefficients.append(
                                {"kind": "fixed_row", "variable": variable, "row": row, "coefficient": str(coefficient)}
                            )
            elif section == "RHS":
                for row_name, value in zip(tokens[1::2], tokens[2::2]):
                    rhs[parse_index(row_name, "c")] += number(value)
            elif section == "BOUNDS":
                kind, variable = tokens[0], parse_index(tokens[2], "x")
                value = number(tokens[3]) if len(tokens) > 3 else Decimal(0)
                if kind in {"UP", "UI"}:
                    upper_bounds[variable] = value
                elif kind == "BV":
                    upper_bounds[variable] = Decimal(1)
                    integer_variables.add(variable)
    flush_block(current_block)
    if threshold_handle:
        threshold_handle.close()

    edges: list[tuple[int, int]] = []
    template_errors: list[dict[str, object]] = []
    for edge_index in range(HORIZONTAL_ROWS // PERIODS):
        left_block = right_block = -1
        for period in range(PERIODS):
            offset = edge_index * PERIODS + period
            positive = horizontal_pos[offset]
            negatives = [value for value in (horizontal_neg1[offset], horizontal_neg2[offset]) if value >= 0]
            positive_block = (positive - 1) // PERIODS if positive > 0 else -1
            positive_period = (positive - 1) % PERIODS if positive > 0 else -1
            if period == 0 and len(negatives) == 1:
                right_block = positive_block
                left_block = (negatives[0] - 1) // PERIODS
                valid = (
                    horizontal_entry_counts[offset] == 2
                    and positive_period == 0
                    and (negatives[0] - 1) % PERIODS == 0
                )
            elif period > 0 and len(negatives) == 2:
                expected_same = right_block * PERIODS + period  # one-based x index for period-1
                expected_left = left_block * PERIODS + period + 1
                valid = (
                    horizontal_entry_counts[offset] == 3
                    and positive_block == right_block
                    and positive_period == period
                    and sorted(negatives) == sorted([expected_same, expected_left])
                )
            else:
                valid = False
            if not valid and len(template_errors) < 100:
                template_errors.append(
                    {
                        "row": HORIZONTAL_FIRST + offset,
                        "positive": positive,
                        "negatives": negatives,
                        "entry_count": horizontal_entry_counts[offset],
                    }
                )
        edges.append((left_block, right_block))

    adjacency: list[list[int]] = [[] for _ in range(BLOCKS)]
    reverse: list[list[int]] = [[] for _ in range(BLOCKS)]
    uf = UnionFind(BLOCKS)
    duplicate_edges = len(edges) - len(set(edges))
    self_edges = 0
    for left, right in sorted(set(edges)):
        if left == right:
            self_edges += 1
        adjacency[left].append(right)
        reverse[right].append(left)
        uf.union(left, right)

    indegree = [len(reverse[node]) for node in range(BLOCKS)]
    queue = deque(node for node in range(BLOCKS) if indegree[node] == 0)
    topological: list[int] = []
    while queue:
        node = queue.popleft()
        topological.append(node)
        for child in adjacency[node]:
            indegree[child] -= 1
            if indegree[child] == 0:
                queue.append(child)
    dag = len(topological) == BLOCKS

    component_sizes: Counter[int] = Counter(uf.find(node) for node in range(BLOCKS))
    redundant_edges = None
    if dag:
        reachability = [0] * BLOCKS
        for node in reversed(topological):
            reach = 0
            for child in adjacency[node]:
                reach |= (1 << child) | reachability[child]
            reachability[node] = reach
        redundant_edges = 0
        for node, children in enumerate(adjacency):
            if len(children) < 2:
                continue
            for child in children:
                if any(other != child and (reachability[other] & (1 << child)) for other in children):
                    redundant_edges += 1

    thresholds: list[int] = []
    threshold_shape_errors: list[int] = []
    for block in range(BLOCKS):
        bits = [block * PERIODS + period + 1 in selected for period in range(PERIODS)]
        threshold = next((period for period, value in enumerate(bits) if value), PERIODS)
        if any(bits[period] != (period >= threshold) for period in range(PERIODS)):
            threshold_shape_errors.append(block)
        thresholds.append(threshold)
    precedence_violations = [
        (left, right, thresholds[left], thresholds[right])
        for left, right in edges
        if thresholds[left] > thresholds[right]
    ]
    mixed_slacks = [rhs[MIXED_FIRST + row] - official_mixed_activity[row] for row in range(78)]
    if args.edges:
        args.edges.write_text(
            json.dumps(
                {
                    "source_sha256": sha256,
                    "meaning": "Each zero-based pair [u,v] enforces threshold[u] <= threshold[v].",
                    "edges_zero_based": edges,
                },
                separators=(",", ":"),
            )
            + "\n",
            encoding="utf-8",
        )

    vertical_expected_entries = BLOCKS * 2 * (PERIODS - 1)
    horizontal_equivalence_audit = not template_errors and not horizontal_bad_coefficients
    row_type_counts = Counter(row_types.values())
    result = {
        "source_sha256": sha256,
        "dimensions": {
            "variables": BINARY_VARIABLES + 1,
            "binary_variables": BINARY_VARIABLES,
            "continuous_variables": 1,
            "rows": len(row_types),
            "blocks": BLOCKS,
            "periods_per_block": PERIODS,
            "threshold_states_per_block": PERIODS + 1,
        },
        "row_classes_reconstructed": {
            "vertical_monotonicity_rows": VERTICAL_ROWS,
            "mixed_resource_rows": 78,
            "horizontal_original_implication_rows": HORIZONTAL_ROWS,
            "fixed_continuous_row": 1,
            "row_type_counts": dict(sorted(row_type_counts.items())),
        },
        "exact_structure_audit": {
            "integer_marker_variables": len(integer_variables),
            "binary_upper_bounds_one": sum(upper_bounds.get(variable) == 1 for variable in range(1, BINARY_VARIABLES + 1)),
            "continuous_x348921_upper_bound": str(upper_bounds.get(BINARY_VARIABLES + 1)),
            "vertical_entries_seen": vertical_seen,
            "vertical_entries_expected": vertical_expected_entries,
            "vertical_bad_examples": vertical_bad,
            "horizontal_template_passed": horizontal_equivalence_audit,
            "horizontal_template_errors": template_errors,
            "horizontal_bad_coefficient_examples": horizontal_bad_coefficients,
            "fixed_row_rhs": str(rhs[FIXED_ROW]),
        },
        "threshold_dag": {
            "edge_count": len(edges),
            "duplicate_edges": duplicate_edges,
            "self_edges": self_edges,
            "is_dag": dag,
            "weak_component_count": len(component_sizes),
            "weak_component_sizes_descending": sorted(component_sizes.values(), reverse=True),
            "source_blocks": sum(not reverse[node] for node in range(BLOCKS)),
            "sink_blocks": sum(not adjacency[node] for node in range(BLOCKS)),
            "maximum_indegree": max(map(len, reverse)),
            "maximum_outdegree": max(map(len, adjacency)),
            "transitively_redundant_edges": redundant_edges,
            "equivalence_statement": "For binary suffix states, each audited 20-row implication gadget is equivalent to threshold(left) <= threshold(right).",
        },
        "mixed_rows": [
            {
                "row": MIXED_FIRST + offset,
                "nnz": mixed_row_nnz[offset],
                "positive": mixed_positive[offset],
                "negative": mixed_negative[offset],
                "minimum_coefficient": str(mixed_min[offset]),
                "maximum_coefficient": str(mixed_max[offset]),
                "rhs": str(rhs[MIXED_FIRST + offset]),
                "official_activity": str(official_mixed_activity[offset]),
                "official_slack": str(mixed_slacks[offset]),
            }
            for offset in range(78)
        ],
        "threshold_state_sparsity": {
            "mixed_nonzeros_per_block_state_distribution": {str(key): value for key, value in sorted(state_resource_nnz.items())},
            "distinct_per_block_state_sparsity_signatures": len(block_state_signature_counts),
            "most_common_signatures": [
                {"signature": list(signature), "blocks": count}
                for signature, count in block_state_signature_counts.most_common(20)
            ],
        },
        "official_solution": {
            "selected_binary_variables": sum(variable <= BINARY_VARIABLES for variable in selected),
            "x348921": 1 if BINARY_VARIABLES + 1 in selected else 0,
            "exact_objective": str(official_objective),
            "threshold_shape_violations": len(threshold_shape_errors),
            "precedence_edge_violations": len(precedence_violations),
            "mixed_row_minimum_slack": str(min(mixed_slacks)),
            "mixed_row_tight_count": sum(slack == 0 for slack in mixed_slacks),
        },
        "threshold_model_jsonl_gz": str(args.threshold_model) if args.threshold_model else None,
        "threshold_edges_json": str(args.edges) if args.edges else None,
    }
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))
    passed = (
        len(row_types) == FIXED_ROW
        and row_type_counts == Counter({"L": FIXED_ROW - 1, "E": 1})
        and len(integer_variables) == BINARY_VARIABLES
        and vertical_seen == vertical_expected_entries
        and not vertical_bad
        and horizontal_equivalence_audit
        and rhs[FIXED_ROW] == 1
        and upper_bounds.get(BINARY_VARIABLES + 1) == 2
        and dag
        and not threshold_shape_errors
        and not precedence_violations
    )
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
