#!/usr/bin/env python3
"""Independent exact-arithmetic replay of a mining Lagrangian certificate."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
from decimal import Decimal, getcontext
from pathlib import Path


getcontext().prec = 80
PERIODS = 20


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("threshold_model", type=Path)
    parser.add_argument("edges", type=Path)
    parser.add_argument("structure", type=Path)
    parser.add_argument("certificate", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    cert = json.loads(args.certificate.read_text(encoding="utf-8"))
    edge_payload = json.loads(args.edges.read_text(encoding="utf-8"))
    structure = json.loads(args.structure.read_text(encoding="utf-8"))
    lam1 = [Decimal(value) for value in cert["multipliers_first_resource"]]
    lam2 = [Decimal(value) for value in cert["multipliers_second_resource"]]
    if len(lam1) != PERIODS or len(lam2) != PERIODS or any(value < 0 for value in lam1 + lam2):
        raise ValueError("multipliers are not 40 nonnegative finite decimals")

    costs: list[list[Decimal]] = []
    w1: list[list[Decimal]] = []
    w2: list[list[Decimal]] = []
    redundant_rows_nonpositive = True
    with gzip.open(args.threshold_model, "rt", encoding="utf-8") as handle:
        for expected, raw in enumerate(handle):
            record = json.loads(raw)
            if record["block_zero_based"] != expected:
                raise ValueError("block order mismatch")
            costs.append([Decimal(value) for value in record["objective_by_first_selected_period_zero_based_or_never"]])
            first = [Decimal(0)] * 21
            second = [Decimal(0)] * 21
            for state, entries in enumerate(record["mixed_activity_by_state"]):
                for row, value_text in entries:
                    value = Decimal(value_text)
                    if 19 <= row <= 38:
                        if state >= PERIODS or row != 19 + state:
                            raise ValueError("first capacity does not match state")
                        first[state] += value
                    elif 58 <= row <= 77:
                        if state >= PERIODS or row != 58 + state:
                            raise ValueError("second capacity does not match state")
                        second[state] += value
                    else:
                        redundant_rows_nonpositive &= value <= 0
            w1.append(first)
            w2.append(second)

    n = len(costs)
    successor = [-1] * n
    predecessor = [-1] * n
    for left, right in edge_payload["edges_zero_based"]:
        if successor[left] >= 0 or predecessor[right] >= 0:
            raise ValueError("not a path forest")
        successor[left] = right
        predecessor[right] = left
    paths = []
    seen = set()
    for source in range(n):
        if predecessor[source] >= 0:
            continue
        path = []
        node = source
        while node >= 0:
            if node in seen:
                raise ValueError("cycle")
            seen.add(node)
            path.append(node)
            node = successor[node]
        paths.append(path)
    if len(seen) != n:
        raise ValueError("path forest does not cover all nodes")

    rhs = {entry["row"]: Decimal(entry["rhs"]) for entry in structure["mixed_rows"]}
    caps1 = [rhs[331494 + period] for period in range(PERIODS)]
    caps2 = [rhs[331533 + period] for period in range(PERIODS)]

    def adjusted(node: int, state: int) -> Decimal:
        value = costs[node][state]
        if state < PERIODS:
            value += lam1[state] * w1[node][state] + lam2[state] * w2[node][state]
        return value

    # Independent recurrence: dp[i][s] is the best suffix of a path when the
    # preceding block was assigned state s, so later states are enumerated s..20.
    exact_minimum = Decimal("948653737.393142")
    exact_minimum -= sum(value * cap for value, cap in zip(lam1, caps1))
    exact_minimum -= sum(value * cap for value, cap in zip(lam2, caps2))
    for path in paths:
        next_dp = [Decimal(0)] * 21
        for node in reversed(path):
            current = [Decimal(0)] * 21
            for minimum_state in range(21):
                current[minimum_state] = min(adjusted(node, state) + next_dp[state] for state in range(minimum_state, 21))
            next_dp = current
        exact_minimum += next_dp[0]

    witness_states = cert["inner_minimizer_thresholds_zero_based_or_20_never"]
    witness_monotone = len(witness_states) == n and all(
        witness_states[left] <= witness_states[right] for left, right in edge_payload["edges_zero_based"]
    )
    witness_value = Decimal("948653737.393142")
    witness_value -= sum(value * cap for value, cap in zip(lam1, caps1))
    witness_value -= sum(value * cap for value, cap in zip(lam2, caps2))
    if len(witness_states) == n:
        witness_value += sum(adjusted(node, int(state)) for node, state in enumerate(witness_states))

    checks = {
        "source_hash_matches": cert["source_mps_sha256"] == edge_payload["source_sha256"] == structure["source_sha256"],
        "threshold_model_hash_matches": cert["threshold_model_sha256"] == hashlib.sha256(args.threshold_model.read_bytes()).hexdigest(),
        "edge_file_hash_matches": cert["edge_file_sha256"] == hashlib.sha256(args.edges.read_bytes()).hexdigest(),
        "multipliers_nonnegative": all(value >= 0 for value in lam1 + lam2),
        "omitted_difference_state_contributions_all_nonpositive": redundant_rows_nonpositive,
        "path_forest_covers_all_blocks": len(seen) == n,
        "witness_states_monotone": witness_monotone,
        "witness_equals_independent_dp": witness_value == exact_minimum,
        "stored_bound_equals_independent_dp": Decimal(cert["exact_decimal_lower_bound"]) == exact_minimum,
    }
    report = {
        "kind": "independent_exact_replay_of_mining_lagrangian_bound",
        "checks": checks,
        "all_checks_passed": all(checks.values()),
        "recomputed_exact_decimal_lower_bound": str(exact_minimum),
        "recomputed_witness_lagrangian_value": str(witness_value),
        "paths": len(paths),
        "blocks": n,
    }
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["all_checks_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
