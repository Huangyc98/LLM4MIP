# Package manifest: bley_xs1noM

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 34
Excluded source files: 2

## Included files

- `README.md`
- `experiments/bley-projection-result.json`
- `experiments/bley_projection.py`
- `experiments/copt8-vtype-crosscheck.json`
- `experiments/deep-20260908/bley_xs1noM-tightM100.mps.gz`
- `experiments/deep-20260908/logs/routing-fixed.log`
- `experiments/deep-20260908/logs/strict-seed11-720s.log`
- `experiments/deep-20260908/logs/tightM-primal-seed23-540s.log`
- `experiments/deep-20260908/logs/tightM-strict-seed17-720s.log`
- `experiments/deep-20260908/results/bigM-equivalence-certificate.json`
- `experiments/deep-20260908/results/block-lns-720s.json`
- `experiments/deep-20260908/results/gurobi-structure-audit.json`
- `experiments/deep-20260908/results/routing-fixed.json`
- `experiments/deep-20260908/results/strict-seed11-720s.json`
- `experiments/deep-20260908/results/tightM-primal-exact-validation.json`
- `experiments/deep-20260908/results/tightM-primal-original-mps-audit.json`
- `experiments/deep-20260908/results/tightM-primal-seed23-540s.json`
- `experiments/deep-20260908/results/tightM-strict-seed17-720s.json`
- `experiments/deep-20260908/scripts/conditional_optimize.py`
- `experiments/deep-20260908/scripts/design_block_lns.py`
- `experiments/deep-20260908/scripts/gurobi_search.py`
- `experiments/deep-20260908/scripts/gurobi_structure_audit.py`
- `experiments/deep-20260908/scripts/tighten_big_m.py`
- `experiments/deep-20260908/summary.json`
- `experiments/remote_copt_probe.py`
- `input/SHA256SUMS`
- `reports/SOURCES-20260908.md`
- `reports/deep-study-2026-09-08.zh.md`
- `solutions/official-best.sol`
- `solutions/official-best.sol.gz`
- `solutions/sibling-official-best.sol`
- `solutions/sibling-official-best.sol.gz`
- `solutions/transferred-sibling-best.sol`
- `solutions/transferred-sibling-best.validation.log`

## Excluded files

- `input/bley_xs1.mps.gz (142054 bytes; raw benchmark input; sha256 02a0eba05ad39eaade8b266555fe2eb981954452990fbe0ac42bc727378256e8)`
- `input/bley_xs1noM.mps.gz (141853 bytes; raw benchmark input; sha256 ec819fa9682edd2b6430f464aa5d56ac105eeb26b9bbd9231ef86b1214d21f4a)`
