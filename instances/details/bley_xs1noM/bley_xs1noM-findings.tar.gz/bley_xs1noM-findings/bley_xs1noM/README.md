# bley_xs1noM: sibling projection and strict incumbent improvement

## Result

The public `bley_xs1` incumbent maps by the identity column map to an exactly
feasible `bley_xs1noM` solution with objective **3,855,895.86**.  The public
`bley_xs1noM` baseline has objective **3,873,690.77**, so this is a strict
incumbent improvement of **17,794.91**.

This is an incumbent result only.  It is not a proof of global optimality, and
the formulation relationship by itself must not be read as one.

The mapped solution is
[`solutions/transferred-sibling-best.sol`](solutions/transferred-sibling-best.sol).

## 2026-09-08 deeper structural study

A subsequent 42-minute study did not improve the strict incumbent or prove
global optimality, but it produced an integer-feasible-set-equivalent Big-M
strengthening and several exact conditional/local results.

- The original model has 349 rows of the form
  `10^20 sum(z) - x >= 0`, with binary `z` and `0 <= x <= 100`.  Replacing
  every `10^20` coefficient by `100` is equivalent for integer points: if all
  `z=0`, both rows force `x=0`; otherwise `100-x>=0` follows from the upper
  bound.  The complete certificate covers 1,333 coefficients.
- Under the same 720-second strict-search budget, the numerical lower bound
  improved from `3,344,369.4370` to `3,344,924.0428`, a gain of `554.6058`.
- Fixing all 2,253 zero-cost routing/metric variables and optimizing all 990
  costed design variables closes in one node at `3,855,895.86`.
- All 53 single capacity-block and 20 selected high-cost two-block strict
  improvement subproblems return `CUTOFF`; all routing variables remain free
  in these neighborhoods.

These are not a global lower-bound closure.  The full evidence is in
[`experiments/deep-20260908/`](experiments/deep-20260908/) and the detailed
Chinese report is
[`reports/deep-study-2026-09-08.zh.md`](reports/deep-study-2026-09-08.zh.md).
The equivalent strengthened model is archived as
[`bley_xs1noM-tightM100.mps.gz`](experiments/deep-20260908/bley_xs1noM-tightM100.mps.gz),
SHA-256 `0ddad5c74a40b7ee301657f5691ce82ea3a5524cd9425589041b5219bfd8b66d`.

## Exact formulation certificate

[`experiments/bley_projection.py`](experiments/bley_projection.py) parses both
fixed/free MPS records with `Decimal` and compares names, order, row senses,
matrix coefficients, RHS, ranges, objective coefficients, bounds, and integer
status.  Its complete machine-readable output is
[`experiments/bley-projection-result.json`](experiments/bley-projection-result.json).

The certificate establishes:

- the 3,290 rows and 3,243 columns have identical names and order, so the
  variable permutation is the identity;
- all row senses, coefficients, RHS, ranges, and objective coefficients agree;
- integer status agrees for every column: both MPS files open `INTORG` before
  the first structural column and close `INTEND` after the last one;
- 2,360 variables are binary and 883 are general integer in both models;
- the only formulation differences are 883 upper bounds: `bley_xs1` has
  `LI 0` with no finite upper bound, while `bley_xs1noM` has `UP 100`;
- consequently the target feasible set is a subset of the sibling feasible
  set, while transfer feasibility is proved separately for this concrete
  candidate.

The mapped incumbent has zero row, bound, and integrality violations under
zero-tolerance `Decimal` checking against the original compressed target MPS.
The captured report is
[`solutions/transferred-sibling-best.validation.log`](solutions/transferred-sibling-best.validation.log).
The official target baseline is checked by the same code.

As an independent parser/API cross-check, COPT 8.0.4 reports 2,360 binary, 883
integer, and 0 continuous columns for the target; see
[`experiments/copt8-vtype-crosscheck.json`](experiments/copt8-vtype-crosscheck.json).

## Provenance and hashes

The models, public incumbents, and official metadata pages came from MIPLIB:

- <https://miplib.zib.de/instance_details_bley_xs1noM.html>
- <https://miplib.zib.de/instance_details_bley_xs1.html>
- <https://miplib.zib.de/downloads/solutions/bley_xs1noM/3/bley_xs1noM.sol.gz>
- <https://miplib.zib.de/downloads/solutions/bley_xs1/8/bley_xs1.sol.gz>

[`input/SHA256SUMS`](input/SHA256SUMS) records the exact downloaded bytes.  In
particular, the noM official baseline is the MIPLIB solution revision `/3/`
linked above; it is not a locally generated benchmark.

## Reproduce

From the repository root:

```bash
python instances/bley_xs1noM/experiments/bley_projection.py \
  --target-mps instances/bley_xs1noM/input/bley_xs1noM.mps.gz \
  --sibling-mps instances/bley_xs1noM/input/bley_xs1.mps.gz \
  --sibling-solution instances/bley_xs1noM/solutions/sibling-official-best.sol.gz \
  --target-official-solution instances/bley_xs1noM/solutions/official-best.sol.gz \
  --mapped-solution instances/bley_xs1noM/solutions/transferred-sibling-best.sol \
  --output instances/bley_xs1noM/experiments/bley-projection-result.json
```

For the independent COPT type check, copy
[`experiments/remote_copt_probe.py`](experiments/remote_copt_probe.py)
to a machine with COPT 8 and run it on the target MPS without `--solve`.
