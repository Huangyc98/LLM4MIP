#!/usr/bin/env python3
"""Audit the bley_xs1 -> bley_xs1noM identity projection exactly.

The two formulations use the same row and column names.  This script does not
assume that this makes a solution transferable: it parses both original MPS
files with Decimal arithmetic, compares every algebraic record, proves the
direction of the feasible-set inclusion from the bounds, maps a sibling
solution by variable name, and evaluates it against the target MPS.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
from collections import OrderedDict, defaultdict
from decimal import Decimal, getcontext
from pathlib import Path


getcontext().prec = 80


def dec(value: str) -> Decimal:
    return Decimal(value.replace("D", "E").replace("d", "e"))


def open_text(path: Path):
    if path.suffix == ".gz":
        return gzip.open(path, "rt", encoding="latin-1")
    return path.open(encoding="latin-1")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def parse_mps(path: Path) -> dict:
    model = {
        "name": None,
        "rows": OrderedDict(),
        "variables": OrderedDict(),
        "rhs": defaultdict(Decimal),
        "ranges": defaultdict(Decimal),
        "bounds_raw": [],
    }
    section = ""
    integer_mode = False
    with open_text(path) as handle:
        for raw in handle:
            tokens = raw.split()
            if not tokens or tokens[0].startswith("*"):
                continue
            if not raw[0].isspace() and tokens[0] in {
                "NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"
            }:
                section = tokens[0]
                if section == "NAME" and len(tokens) > 1:
                    model["name"] = tokens[1]
                continue
            if section == "ROWS":
                model["rows"][tokens[1]] = {
                    "sense": tokens[0],
                    "coefficients": OrderedDict(),
                }
            elif section == "COLUMNS":
                if "'MARKER'" in tokens:
                    integer_mode = "'INTORG'" in tokens
                    continue
                variable = tokens[0]
                info = model["variables"].setdefault(variable, {"integer": integer_mode})
                info["integer"] = info["integer"] or integer_mode
                for row, value in zip(tokens[1::2], tokens[2::2]):
                    coefficients = model["rows"][row]["coefficients"]
                    coefficients[variable] = coefficients.get(variable, Decimal(0)) + dec(value)
            elif section == "RHS":
                for row, value in zip(tokens[1::2], tokens[2::2]):
                    model["rhs"][row] += dec(value)
            elif section == "RANGES":
                for row, value in zip(tokens[1::2], tokens[2::2]):
                    model["ranges"][row] += dec(value)
            elif section == "BOUNDS":
                model["bounds_raw"].append(tokens)

    for variable, info in model["variables"].items():
        info["lower"] = Decimal(0)
        info["upper"] = None
        info["bound_kind"] = "default"
    for tokens in model["bounds_raw"]:
        kind, variable = tokens[0], tokens[2]
        value = dec(tokens[3]) if len(tokens) > 3 else Decimal(0)
        info = model["variables"][variable]
        info["bound_kind"] = kind
        if kind == "LO":
            info["lower"] = value
        elif kind == "UP":
            info["upper"] = value
        elif kind == "FX":
            info["lower"] = info["upper"] = value
        elif kind == "FR":
            info["lower"], info["upper"] = Decimal("-Infinity"), None
        elif kind == "MI":
            info["lower"] = Decimal("-Infinity")
        elif kind == "PL":
            info["upper"] = None
        elif kind == "BV":
            info["lower"], info["upper"], info["integer"] = Decimal(0), Decimal(1), True
        elif kind == "LI":
            info["lower"], info["integer"] = value, True
        elif kind == "UI":
            info["upper"], info["integer"] = value, True
        else:
            raise ValueError(f"unsupported bound kind {kind}")
    return model


def read_solution(path: Path) -> dict[str, Decimal]:
    values: dict[str, Decimal] = {}
    with open_text(path) as handle:
        for raw in handle:
            tokens = raw.split()
            if len(tokens) < 2 or tokens[0].startswith(("#", "=")):
                continue
            try:
                values[tokens[0]] = dec(tokens[1])
            except Exception:
                pass
    return values


def compare_models(sibling: dict, target: dict) -> dict:
    sibling_rows = list(sibling["rows"])
    target_rows = list(target["rows"])
    sibling_vars = list(sibling["variables"])
    target_vars = list(target["variables"])
    row_order_equal = sibling_rows == target_rows
    column_order_equal = sibling_vars == target_vars

    row_sense_differences = []
    rhs_differences = []
    range_differences = []
    matrix_differences = []
    if set(sibling_rows) == set(target_rows):
        for row in sibling_rows:
            if sibling["rows"][row]["sense"] != target["rows"][row]["sense"]:
                row_sense_differences.append(row)
            if sibling["rhs"].get(row, Decimal(0)) != target["rhs"].get(row, Decimal(0)):
                rhs_differences.append(row)
            if sibling["ranges"].get(row, Decimal(0)) != target["ranges"].get(row, Decimal(0)):
                range_differences.append(row)
            if sibling["rows"][row]["coefficients"] != target["rows"][row]["coefficients"]:
                matrix_differences.append(row)

    objective_rows = [row for row in sibling_rows if sibling["rows"][row]["sense"] == "N"]
    objective_differences = [
        row for row in objective_rows
        if sibling["rows"][row]["coefficients"] != target["rows"][row]["coefficients"]
    ]
    integrality_differences = []
    bound_differences = []
    target_subset_sibling = set(sibling_vars) == set(target_vars)
    if set(sibling_vars) == set(target_vars):
        for variable in sibling_vars:
            left = sibling["variables"][variable]
            right = target["variables"][variable]
            if left["integer"] != right["integer"]:
                integrality_differences.append(variable)
                target_subset_sibling = False
            if (left["lower"], left["upper"]) != (right["lower"], right["upper"]):
                bound_differences.append({
                    "variable": variable,
                    "sibling_lower": str(left["lower"]),
                    "sibling_upper": None if left["upper"] is None else str(left["upper"]),
                    "sibling_kind": left["bound_kind"],
                    "target_lower": str(right["lower"]),
                    "target_upper": None if right["upper"] is None else str(right["upper"]),
                    "target_kind": right["bound_kind"],
                })
            if right["lower"] < left["lower"]:
                target_subset_sibling = False
            if left["upper"] is not None and (right["upper"] is None or right["upper"] > left["upper"]):
                target_subset_sibling = False

    return {
        "row_name_sets_equal": set(sibling_rows) == set(target_rows),
        "row_order_equal": row_order_equal,
        "column_name_sets_equal": set(sibling_vars) == set(target_vars),
        "column_order_equal": column_order_equal,
        "variable_mapping": "identity by exact MPS column name" if column_order_equal else "not identity",
        "row_sense_difference_count": len(row_sense_differences),
        "rhs_difference_count": len(rhs_differences),
        "range_difference_count": len(range_differences),
        "matrix_row_difference_count": len(matrix_differences),
        "objective_row_difference_count": len(objective_differences),
        "integrality_difference_count": len(integrality_differences),
        "bound_difference_count": len(bound_differences),
        "bound_differences": bound_differences,
        "target_feasible_set_is_subset_of_sibling": target_subset_sibling,
    }


def validate(model: dict, values: dict[str, Decimal]) -> dict:
    variables = model["variables"]
    unknown = sorted(set(values) - set(variables))
    missing = sorted(set(variables) - set(values))
    row_violations = []
    objective = Decimal(0)
    for row, info in model["rows"].items():
        lhs = sum((coefficient * values.get(variable, Decimal(0))
                   for variable, coefficient in info["coefficients"].items()), Decimal(0))
        sense = info["sense"]
        if sense == "N":
            objective += lhs
            continue
        rhs = model["rhs"].get(row, Decimal(0))
        if sense == "E":
            violation = abs(lhs - rhs)
        elif sense == "L":
            violation = max(Decimal(0), lhs - rhs)
        elif sense == "G":
            violation = max(Decimal(0), rhs - lhs)
        else:
            raise ValueError(f"unsupported row sense {sense}")
        if violation:
            row_violations.append((violation, row, lhs, rhs))

    bound_violations = []
    integrality_violations = []
    for variable, info in variables.items():
        value = values.get(variable, Decimal(0))
        violation = max(Decimal(0), info["lower"] - value)
        if info["upper"] is not None:
            violation = max(violation, value - info["upper"])
        if violation:
            bound_violations.append((violation, variable, value))
        if info["integer"] and value != value.to_integral_value():
            integrality_violations.append((abs(value - value.to_integral_value()), variable, value))
    row_violations.sort(reverse=True)
    bound_violations.sort(reverse=True)
    integrality_violations.sort(reverse=True)
    return {
        "objective": str(objective),
        "specified_variables": len(values),
        "implicit_zero_variables": len(missing),
        "unknown_solution_variables": unknown,
        "exact_row_violation_count": len(row_violations),
        "max_exact_row_violation": str(row_violations[0][0] if row_violations else 0),
        "exact_bound_violation_count": len(bound_violations),
        "max_exact_bound_violation": str(bound_violations[0][0] if bound_violations else 0),
        "exact_integrality_violation_count": len(integrality_violations),
        "max_exact_integrality_violation": str(integrality_violations[0][0] if integrality_violations else 0),
        "strictly_feasible": not row_violations and not bound_violations and not integrality_violations and not unknown,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sibling-mps", type=Path, required=True)
    parser.add_argument("--target-mps", type=Path, required=True)
    parser.add_argument("--sibling-solution", type=Path, required=True)
    parser.add_argument("--target-official-solution", type=Path, required=True)
    parser.add_argument("--mapped-solution", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    sibling = parse_mps(args.sibling_mps)
    target = parse_mps(args.target_mps)
    comparison = compare_models(sibling, target)
    values = read_solution(args.sibling_solution)
    target_official_values = read_solution(args.target_official_solution)
    sibling_validation = validate(sibling, values)
    target_validation = validate(target, values)
    target_official_validation = validate(target, target_official_values)

    args.mapped_solution.parent.mkdir(parents=True, exist_ok=True)
    with args.mapped_solution.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write("# Identity projection of the official bley_xs1 solution into bley_xs1noM.\n")
        handle.write(f"# Exact target objective: {target_validation['objective']}\n")
        for variable in target["variables"]:
            value = values.get(variable, Decimal(0))
            if value:
                handle.write(f"{variable} {value}\n")

    baseline = Decimal("3873690.77")
    candidate = Decimal(target_validation["objective"])
    result = {
        "claim": "strict new incumbent for bley_xs1noM; no optimality claim",
        "evidence_level": "exact primal certificate against the original target MPS",
        "sources": {
            "target_instance": "https://miplib.zib.de/instance_details_bley_xs1noM.html",
            "target_official_solution": "https://miplib.zib.de/downloads/solutions/bley_xs1noM/3/bley_xs1noM.sol.gz",
            "sibling_instance": "https://miplib.zib.de/instance_details_bley_xs1.html",
            "sibling_official_solution": "https://miplib.zib.de/downloads/solutions/bley_xs1/8/bley_xs1.sol.gz",
        },
        "sha256": {
            "sibling_mps_gz": sha256(args.sibling_mps),
            "target_mps_gz": sha256(args.target_mps),
            "sibling_solution_gz_or_text": sha256(args.sibling_solution),
            "target_official_solution_gz_or_text": sha256(args.target_official_solution),
        },
        "dimensions": {
            "rows_including_objective": len(target["rows"]),
            "variables": len(target["variables"]),
        },
        "formulation_comparison": comparison,
        "sibling_solution_validation": sibling_validation,
        "mapped_target_solution_validation": target_validation,
        "target_official_solution_validation": target_official_validation,
        "official_target_baseline": str(baseline),
        "candidate_target_objective": str(candidate),
        "absolute_improvement": str(baseline - candidate),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({
        "claim": result["claim"],
        "candidate": result["candidate_target_objective"],
        "improvement": result["absolute_improvement"],
        "strictly_feasible": target_validation["strictly_feasible"],
        "bound_differences": comparison["bound_difference_count"],
    }, indent=2))


if __name__ == "__main__":
    main()
