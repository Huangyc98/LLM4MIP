#!/usr/bin/env python3
"""Read bley_xs1noM with Gurobi and strictly audit a MIPLIB solution."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
from collections import Counter, defaultdict
from pathlib import Path

import gurobipy as gp


def open_text(path: Path):
    return gzip.open(path, "rt", encoding="latin-1") if path.suffix == ".gz" else path.open(encoding="latin-1")


def read_sol(path: Path) -> dict[str, float]:
    values: dict[str, float] = {}
    with open_text(path) as handle:
        for line in handle:
            fields = line.split()
            if len(fields) < 2 or fields[0].startswith(("#", "=")):
                continue
            try:
                values[fields[0]] = float(fields[1])
            except ValueError:
                pass
    return values


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def finite_key(x: float):
    if abs(x) >= gp.GRB.INFINITY / 2:
        return "inf" if x > 0 else "-inf"
    return round(x, 12)


def audit(model: gp.Model, values: dict[str, float]) -> dict:
    by_name = {v.VarName: v for v in model.getVars()}
    unknown = sorted(set(values) - set(by_name))
    x = {name: values.get(name, 0.0) for name in by_name}
    row_bad = []
    for c in model.getConstrs():
        row = model.getRow(c)
        lhs = sum(row.getCoeff(j) * x[row.getVar(j).VarName] for j in range(row.size()))
        if c.Sense == "=":
            viol = abs(lhs - c.RHS)
        elif c.Sense == "<":
            viol = max(0.0, lhs - c.RHS)
        else:
            viol = max(0.0, c.RHS - lhs)
        if viol > 0:
            row_bad.append((viol, c.ConstrName, lhs, c.Sense, c.RHS))
    bound_bad = []
    int_bad = []
    for v in model.getVars():
        val = x[v.VarName]
        bviol = max(0.0, v.LB - val, val - v.UB)
        if bviol > 0:
            bound_bad.append((bviol, v.VarName, val, v.LB, v.UB))
        if v.VType in (gp.GRB.INTEGER, gp.GRB.BINARY):
            iv = abs(val - round(val))
            if iv > 0:
                int_bad.append((iv, v.VarName, val))
    objective = sum(v.Obj * x[v.VarName] for v in model.getVars()) + model.ObjCon
    row_bad.sort(reverse=True)
    bound_bad.sort(reverse=True)
    int_bad.sort(reverse=True)
    return {
        "objective": objective,
        "specified": len(values),
        "implicit_zero": len(by_name) - len(set(values) & set(by_name)),
        "unknown": unknown,
        "max_row_violation": row_bad[0][0] if row_bad else 0.0,
        "row_violations_gt_1e_9": sum(v[0] > 1e-9 for v in row_bad),
        "worst_rows": row_bad[:20],
        "max_bound_violation": bound_bad[0][0] if bound_bad else 0.0,
        "bound_violations_gt_1e_9": sum(v[0] > 1e-9 for v in bound_bad),
        "max_integrality_violation": int_bad[0][0] if int_bad else 0.0,
        "integrality_violations_gt_1e_9": sum(v[0] > 1e-9 for v in int_bad),
        "strict_1e_9_feasible": not unknown and not any(v[0] > 1e-9 for v in row_bad + bound_bad + int_bad),
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--mps", type=Path, required=True)
    ap.add_argument("--solution", type=Path, required=True)
    ap.add_argument("--sibling-mps", type=Path)
    ap.add_argument("--output", type=Path, required=True)
    args = ap.parse_args()

    m = gp.read(str(args.mps))
    variables = m.getVars()
    constraints = m.getConstrs()
    bound_profiles = Counter((finite_key(v.LB), finite_key(v.UB), v.VType) for v in variables)
    obj_profile = Counter(round(v.Obj, 12) for v in variables)
    row_profiles = Counter((c.Sense, m.getRow(c).size(), round(c.RHS, 12)) for c in constraints)
    row_size = Counter(m.getRow(c).size() for c in constraints)
    row_sense = Counter(c.Sense for c in constraints)

    # Column-index ranges are meaningful here because the MPS preserves the
    # submitter's systematic x<number> names.  Record gaps and objective blocks.
    numeric_names = [(int(v.VarName[1:]), v) for v in variables if v.VarName.startswith("x") and v.VarName[1:].isdigit()]
    numeric_names.sort()
    objective_vars = [(v.VarName, v.Obj, v.LB, v.UB) for v in variables if v.Obj != 0]
    no_obj = [v.VarName for v in variables if v.Obj == 0]

    sibling = None
    if args.sibling_mps:
        s = gp.read(str(args.sibling_mps))
        sv = {v.VarName: v for v in s.getVars()}
        diff = []
        for v in variables:
            u = sv[v.VarName]
            if (v.LB, v.UB, v.VType) != (u.LB, u.UB, u.VType):
                diff.append({"name": v.VarName, "target": [finite_key(v.LB), finite_key(v.UB), v.VType], "sibling": [finite_key(u.LB), finite_key(u.UB), u.VType]})
        sibling = {
            "rows": s.NumConstrs,
            "variables": s.NumVars,
            "nonzeros": s.NumNZs,
            "bound_or_type_differences": len(diff),
            "first_differences": diff[:20],
        }

    result = {
        "timestamp": __import__("datetime").datetime.now().astimezone().isoformat(),
        "gurobi_version": gp.gurobi.version(),
        "mps": str(args.mps),
        "mps_sha256": sha256(args.mps),
        "model": {
            "sense": "min" if m.ModelSense == 1 else "max",
            "variables": m.NumVars,
            "constraints": m.NumConstrs,
            "nonzeros_gurobi": m.NumNZs,
            "integer_variables_gurobi": m.NumIntVars,
            "gurobi_binary_type_variables": m.NumBinVars,
            "binary_by_integer_bounds_0_1": sum(v.VType in (gp.GRB.INTEGER, gp.GRB.BINARY) and v.LB == 0 and v.UB == 1 for v in variables),
            "general_integer_by_bounds": sum(v.VType in (gp.GRB.INTEGER, gp.GRB.BINARY) and not (v.LB == 0 and v.UB == 1) for v in variables),
            "bound_profiles": [{"lb": k[0], "ub": k[1], "vtype": k[2], "count": n} for k, n in bound_profiles.most_common()],
            "objective_nonzeros": len(objective_vars),
            "objective_zero_variables": len(no_obj),
            "objective_coefficient_profile_top": obj_profile.most_common(30),
            "objective_variables_first": objective_vars[:40],
            "row_senses": dict(row_sense),
            "row_sizes": sorted(row_size.items()),
            "row_profiles_top": row_profiles.most_common(50),
            "first_variables": [v.VarName for v in variables[:50]],
            "first_constraints": [c.ConstrName for c in constraints[:50]],
            "numeric_name_minmax": [numeric_names[0][0], numeric_names[-1][0]],
        },
        "public_solution": audit(m, read_sol(args.solution)),
        "sibling_comparison": sibling,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"model": result["model"], "public_solution": result["public_solution"], "sibling_comparison": sibling}, indent=2))


if __name__ == "__main__":
    main()
