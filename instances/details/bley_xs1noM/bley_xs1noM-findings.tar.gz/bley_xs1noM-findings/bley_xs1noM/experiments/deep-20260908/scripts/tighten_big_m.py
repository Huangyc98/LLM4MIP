#!/usr/bin/env python3
"""Replace provably redundant 1e20 coefficients by the exact tight M=100."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import gurobipy as gp


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--mps", type=Path, required=True)
    ap.add_argument("--output-mps", type=Path, required=True)
    ap.add_argument("--certificate", type=Path, required=True)
    args = ap.parse_args()
    m = gp.read(str(args.mps))
    rows = []
    changes = []
    for c in m.getConstrs():
        row = m.getRow(c)
        big = []
        other = []
        for i in range(row.size()):
            v, a = row.getVar(i), row.getCoeff(i)
            (big if abs(a) >= 1e19 else other).append((v, a))
        if not big:
            continue
        # The following assertions are the mechanical equivalence certificate.
        assert c.Sense == ">" and c.RHS == 0
        assert all(a > 0 and v.LB == 0 and v.UB == 1 and v.VType in (gp.GRB.INTEGER, gp.GRB.BINARY) for v, a in big)
        assert len(other) == 1
        x, ax = other[0]
        assert ax == -1 and x.LB == 0 and x.UB == 100 and x.VType in (gp.GRB.INTEGER, gp.GRB.BINARY)
        rows.append({
            "row": c.ConstrName,
            "binary_switches": [v.VarName for v, _ in big],
            "bounded_integer": x.VarName,
            "old_coefficients": [a for _, a in big],
            "new_coefficient": 100,
        })
        for v, a in big:
            changes.append((c, v, 100.0))
    assert len(rows) == 349, len(rows)
    for c, v, a in changes:
        m.chgCoeff(c, v, a)
    m.update()
    args.output_mps.parent.mkdir(parents=True, exist_ok=True)
    m.write(str(args.output_mps))
    result = {
        "claim": "integer-feasible-set and objective preserving Big-M tightening",
        "proof": "Each changed row is M*sum(z)-x>=0 with z binary and 0<=x<=100 integer. For sum(z)=0 both M=1e20 and M=100 force x=0; for sum(z)>=1 both are implied by x<=100.",
        "source_sha256": sha256(args.mps),
        "changed_rows": len(rows),
        "changed_coefficients": len(changes),
        "old_M_min": min(a for r in rows for a in r["old_coefficients"]),
        "old_M_max": max(a for r in rows for a in r["old_coefficients"]),
        "new_M": 100,
        "all_row_patterns_asserted": True,
        "rows": rows,
    }
    args.certificate.parent.mkdir(parents=True, exist_ok=True)
    args.certificate.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: result[k] for k in ("claim", "changed_rows", "changed_coefficients", "old_M_min", "old_M_max", "new_M")}, indent=2))


if __name__ == "__main__":
    main()
