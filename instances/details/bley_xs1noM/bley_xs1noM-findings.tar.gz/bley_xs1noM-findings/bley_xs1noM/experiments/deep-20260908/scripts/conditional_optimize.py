#!/usr/bin/env python3
"""Exact conditional optimization with either routing or design fixed."""

from __future__ import annotations

import argparse
import gzip
import json
import math
import time
from pathlib import Path

import gurobipy as gp


def read_sol(path: Path) -> dict[str, float]:
    opener = gzip.open if path.suffix == ".gz" else open
    out = {}
    with opener(path, "rt", encoding="latin-1") as f:
        for line in f:
            t = line.split()
            if len(t) >= 2 and not t[0].startswith(("#", "=")):
                try:
                    out[t[0]] = float(t[1])
                except ValueError:
                    pass
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--mps", type=Path, required=True)
    ap.add_argument("--start", type=Path, required=True)
    ap.add_argument("--fix", choices=["routing", "design"], required=True)
    ap.add_argument("--seconds", type=float, default=300)
    ap.add_argument("--log", type=Path, required=True)
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--sol", type=Path, required=True)
    args = ap.parse_args()
    vals = read_sol(args.start)
    m = gp.read(str(args.mps))
    fixed = 0
    for v in m.getVars():
        value = round(vals.get(v.VarName, 0.0))
        v.Start = value
        should_fix = (args.fix == "routing" and v.Obj == 0) or (args.fix == "design" and v.Obj != 0)
        if should_fix:
            v.LB = v.UB = value
            fixed += 1
    m.Params.TimeLimit = args.seconds
    m.Params.Threads = 2
    m.Params.MIPGap = 0
    m.Params.MIPGapAbs = 0
    m.Params.NumericFocus = 2
    m.Params.FeasibilityTol = 1e-9
    m.Params.IntFeasTol = 1e-9
    m.Params.LogFile = str(args.log)
    t0 = time.monotonic()
    m.optimize()
    result = {
        "scope": f"conditional optimum with {args.fix} variables fixed; not global",
        "fixed_variables": fixed,
        "free_variables": m.NumVars - fixed,
        "status": {gp.GRB.OPTIMAL: "OPTIMAL", gp.GRB.TIME_LIMIT: "TIME_LIMIT", gp.GRB.INFEASIBLE: "INFEASIBLE"}.get(m.Status, str(m.Status)),
        "elapsed": time.monotonic() - t0,
        "objective": m.ObjVal if m.SolCount else None,
        "bound": m.ObjBound,
        "gap": m.MIPGap if m.SolCount else None,
        "nodes": m.NodeCount,
    }
    if m.SolCount:
        args.sol.parent.mkdir(parents=True, exist_ok=True)
        m.write(str(args.sol))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
