#!/usr/bin/env python3
"""COPT LNS for selected interleaved tugela vehicle blocks."""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import time
from fractions import Fraction
from pathlib import Path

import coptpy as cp

from helper_route_logic import parse


def read_solution(path: Path) -> dict[str, float]:
    answer: dict[str, float] = {}
    for raw in path.read_text(encoding="ascii").splitlines():
        fields = raw.split()
        if len(fields) == 2 and not fields[0].startswith(("#", "=")):
            answer[fields[0]] = float(Fraction(fields[1]))
    return answer


def safe(model, attribute, default=None):
    try:
        return getattr(model, attribute)
    except Exception:
        return default


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--model", type=Path, required=True)
    ap.add_argument("--solution", type=Path, required=True)
    ap.add_argument("--blocks", required=True, help="comma-separated one-based blocks")
    ap.add_argument("--output-dir", type=Path, required=True)
    ap.add_argument("--time-limit", type=float, default=120)
    ap.add_argument("--threads", type=int, default=4)
    args = ap.parse_args()
    selected = {int(piece) - 1 for piece in args.blocks.split(",")}
    if not selected or min(selected) < 0 or max(selected) >= 18:
        raise ValueError(selected)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    supplied = read_solution(args.solution)
    _, _, variables_exact, _, _, _, _, _, integer = parse(args.model)

    model = cp.Envr().createModel("tugela-interleaved-block-lns")
    model.read(str(args.model))
    variables = model.getVars().getAll()
    assert [variable.name for variable in variables] == variables_exact
    free_integer = fixed_integer = 0
    block_integer_counts = [0] * 18
    for position, variable in enumerate(variables):
        if variable.name not in integer:
            continue
        block = position % 18
        block_integer_counts[block] += 1
        if block in selected:
            free_integer += 1
        else:
            value = float(round(supplied.get(variable.name, 0.0)))
            variable.setInfo(cp.COPT.Info.LB, value)
            variable.setInfo(cp.COPT.Info.UB, value)
            fixed_integer += 1
    assert block_integer_counts == [1259] * 18, block_integer_counts

    start_values = [supplied.get(variable.name, 0.0) for variable in variables]
    model.setMipStart(variables, start_values)
    load_return = model.loadMipStart()
    model.setLogFile(str(args.output_dir / "solver.log"))
    model.setParam(cp.COPT.Param.Logging, 1)
    model.setParam(cp.COPT.Param.Threads, args.threads)
    model.setParam(cp.COPT.Param.TimeLimit, args.time_limit)
    model.setParam(cp.COPT.Param.RelGap, 0.0)
    model.setParam(cp.COPT.Param.GPUMode, 0)
    try:
        model.setParam(cp.COPT.Param.FeasTol, 1e-9)
    except Exception:
        pass
    for parameter, value in (
        (cp.COPT.Param.HeurLevel, 3),
        (cp.COPT.Param.PreRootHeurLevel, 3),
        (cp.COPT.Param.RoundingHeurLevel, 3),
        (cp.COPT.Param.DivingHeurLevel, 3),
        (cp.COPT.Param.FAPHeurLevel, 4),
        (cp.COPT.Param.SubMipHeurLevel, 3),
        (cp.COPT.Param.MipRepair, 3),
    ):
        model.setParam(parameter, value)
    started = time.time()
    model.solve()
    elapsed = time.time() - started
    result = {
        "schema": "tugela-interleaved-block-copt-lns-v1",
        "host": platform.node(),
        "model_sha256": sha(args.model),
        "start_sha256": sha(args.solution),
        "script_sha256": sha(Path(__file__)),
        "selected_blocks_one_based": sorted(block + 1 for block in selected),
        "free_integer_variables": free_integer,
        "fixed_integer_variables": fixed_integer,
        "free_continuous_variables": len(variables) - len(integer),
        "load_mip_start_return": repr(load_return),
        "time_limit": args.time_limit,
        "threads": args.threads,
        "wall_seconds": elapsed,
        "status": safe(model, "status"),
        "has_mip_solution": bool(safe(model, "hasmipsol", False)),
        "objective": safe(model, "objval"),
        "best_bound": safe(model, "bestbnd"),
        "relative_gap": safe(model, "mipgap"),
        "node_count": safe(model, "nodecnt"),
        "solver_time": safe(model, "solvingtime"),
    }
    if result["has_mip_solution"]:
        candidate = args.output_dir / "candidate.sol"
        model.writeSol(str(candidate))
        result["candidate_sha256"] = sha(candidate)
    (args.output_dir / "result.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print("FINAL_RESULT " + json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
