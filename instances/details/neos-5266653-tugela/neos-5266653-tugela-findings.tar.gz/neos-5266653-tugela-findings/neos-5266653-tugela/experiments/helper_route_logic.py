#!/usr/bin/env python3
"""Independent exact structural audit for ns1905797.

This helper deliberately uses only the Python standard library.  It recovers
the four directed arc layers from the flow-incidence rows and prints compact
constraint signatures useful for building a native routing formulation.
"""

from __future__ import annotations

import argparse
import collections
import gzip
import json
from fractions import Fraction
from pathlib import Path


def q(text: str) -> Fraction:
    return Fraction(text.replace("D", "E").replace("d", "e"))


def parse(path: Path):
    rows = {}
    row_order = []
    cols = collections.OrderedDict()
    rhs = {}
    lb = {}
    ub = {}
    integer = set()
    section = ""
    int_mode = False
    with gzip.open(path, "rt", encoding="ascii") as stream:
        for raw in stream:
            s = raw.strip()
            if not s or s.startswith("*"):
                continue
            t = s.split()
            key = t[0].upper()
            if key in {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}:
                section = key
                if key == "ENDATA":
                    break
                continue
            if section == "ROWS":
                if t[0] != "N":
                    rows[t[1]] = t[0]
                    row_order.append(t[1])
            elif section == "COLUMNS":
                if len(t) >= 3 and t[1].strip("'").upper() == "MARKER":
                    int_mode = t[2].strip("'").upper() == "INTORG"
                    continue
                name = t[0]
                if name not in cols:
                    cols[name] = {}
                    lb[name] = Fraction(0)
                    ub[name] = None
                if int_mode:
                    integer.add(name)
                for i in range(1, len(t), 2):
                    cols[name][t[i]] = cols[name].get(t[i], Fraction(0)) + q(t[i + 1])
            elif section == "RHS":
                for i in range(1, len(t), 2):
                    rhs[t[i]] = q(t[i + 1])
            elif section == "BOUNDS":
                kind, name = t[0], t[2]
                val = q(t[3]) if len(t) > 3 else None
                if kind == "LO": lb[name] = val
                elif kind == "UP": ub[name] = val
                elif kind == "FX": lb[name] = ub[name] = val
                elif kind == "BV": integer.add(name); lb[name] = Fraction(0); ub[name] = Fraction(1)
                elif kind == "LI": integer.add(name); lb[name] = val
                elif kind == "UI": integer.add(name); ub[name] = val
                elif kind == "FR": lb[name] = ub[name] = None
                elif kind == "MI": lb[name] = None
                elif kind == "PL": ub[name] = None
    by_row = {r: [] for r in row_order}
    for v, terms in cols.items():
        for r, a in terms.items():
            if r in by_row and a:
                by_row[r].append((v, a))
    return rows, row_order, list(cols), cols, by_row, rhs, lb, ub, integer


def f(x):
    return str(x.numerator) if x.denominator == 1 else str(x)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=Path, required=True)
    ap.add_argument("--output", type=Path)
    a = ap.parse_args()
    senses, row_order, variables, cols, by_row, rhs, lb, ub, integer = parse(a.model)
    pos = {v: i for i, v in enumerate(variables)}
    binaries = {v for v in integer if lb[v] == 0 and ub[v] == 1}

    # Recover every arc endpoint from the 67x4 flow equalities.
    incidence = collections.defaultdict(list)
    for node in range(67):
        for block in range(4):
            row = f"R{16413 + 4 * node + block:04d}"
            for v, coef in by_row[row]:
                if v in binaries:
                    incidence[v].append((node, coef))
    arcs = {}
    for v in binaries:
        ent = incidence[v]
        if len(ent) == 2:
            tail = [n for n, c in ent if c == -1]
            head = [n for n, c in ent if c == 1]
            if len(tail) == len(head) == 1:
                arcs[v] = (tail[0], head[0], pos[v] % 4)
    assert len(arcs) == 17676

    general = sorted(integer - binaries, key=pos.get)
    continuous = [v for v in variables if v not in integer]
    result = {
        "variables": len(variables),
        "continuous": len(continuous),
        "binary": len(binaries),
        "general": [{"name": v, "lb": f(lb[v]), "ub": f(ub[v]), "position": pos[v]} for v in general],
        "special_rows": [],
        "arc_pruning": {},
        "big_m_active_examples": [],
        "big_m_coverage": [],
        "positive_time_arc_proof": {},
    }

    # All non-big-M rows before the 268 flow rows.  Emit support grouped by
    # logical arc sets and coefficient, plus any continuous/general terms.
    interesting = [1, 60, 61, 62, 63, 64] + list(range(16389, 16413))
    for rid in interesting:
        r = f"R{rid:04d}"
        terms = by_row[r]
        grouped = collections.Counter()
        other = []
        for v, c in terms:
            if v in arcs:
                i, j, b = arcs[v]
                def node_class(node):
                    if node == 0:
                        return "depot0"
                    if node <= 60:
                        return "task1-60"
                    if node <= 65:
                        return "special61-65"
                    return "special66"
                grouped[(b + 1, f(c), f"{node_class(i)}->{node_class(j)}")] += 1
            else:
                logical = None
                if v in continuous:
                    logical_idx = pos[v] // 4
                    logical = ("time", logical_idx) if logical_idx < 67 else ("work", logical_idx - 67)
                other.append({"var": v, "coef": f(c), "block": pos[v] % 4 + 1, "logical": logical})
        result["special_rows"].append({
            "row": r, "sense": senses[r], "rhs": f(rhs.get(r, Fraction(0))),
            "nnz": len(terms), "arc_groups": [[*k, n] for k, n in sorted(grouped.items())],
            "other": other,
        })

    # Interval-implied impossible direct arcs from the active single-trigger
    # time/work precedence rows.  A trigger is impossible if its active
    # difference inequality contradicts variable bounds.  This is a formal
    # local implication and does not depend on heuristic tolerances.
    impossible = collections.defaultdict(set)
    reasons = collections.Counter()
    signature_counts = collections.Counter()
    signature_examples = {}
    arc_trigger_counts = collections.Counter()
    single_time_durations = collections.defaultdict(list)
    for r in row_order:
        terms = by_row[r]
        trigs = [(v, c) for v, c in terms if v in arcs and c == 50]
        cont = [(v, c) for v, c in terms if v not in integer]
        if not trigs or not cont or senses[r] != "L":
            continue
        trig_arcs = tuple(arcs[v][:2] for v, _ in trigs)
        logical_cont = []
        for v, c in cont:
            logical_idx = pos[v] // 4
            kind_idx = ("time", logical_idx) if logical_idx < 67 else ("work", logical_idx - 67)
            logical_cont.append((kind_idx[0], kind_idx[1], f(c)))
        key = (len(trigs), tuple(logical_cont), f(rhs.get(r, Fraction(0)) - 50 * len(trigs)))
        # Aggregate without logical node ids to keep the report compact.
        coarse_key = (
            len(trigs),
            tuple((kind, coef) for kind, _, coef in logical_cont),
            tuple(
                ("0" if i == 0 else "T" if i <= 60 else "B" if i <= 65 else "L",
                 "0" if j == 0 else "T" if j <= 60 else "B" if j <= 65 else "L")
                for i, j in trig_arcs
            ),
        )
        signature_counts[coarse_key] += 1
        signature_examples.setdefault(coarse_key, {
            "row": r,
            "triggers": [list(x) for x in trig_arcs],
            "continuous": [list(x) for x in logical_cont],
            "active_rhs": f(rhs.get(r, Fraction(0)) - 50 * len(trigs)),
        })
        for v, _ in trigs:
            arc_trigger_counts[(arcs[v][0], arcs[v][1], arcs[v][2], logical_cont[0][0])] += 1
        if len(trigs) == 1 and logical_cont[0][0] == "time" and len(cont) == 2:
            trig = trigs[0][0]
            tail, head, block = arcs[trig]
            logical = []
            for v, c in cont:
                logical.append((pos[v] // 4, c))
            coef = dict(logical)
            # Every sequencing row should have t_tail - t_head <= -duration.
            if coef.get(tail) == 1 and coef.get(head) == -1:
                duration = -(rhs.get(r, Fraction(0)) - 50)
                single_time_durations[(tail, head, block)].append(duration)
        if len(trigs) != 1:
            continue
        trig = trigs[0][0]
        active_rhs = rhs.get(r, Fraction(0)) - 50
        min_lhs = sum(min(c * lb[v], c * ub[v]) for v, c in cont)
        if min_lhs > active_rhs:
            impossible[arcs[trig][2]].add((arcs[trig][0], arcs[trig][1]))
            kinds = tuple("time" if pos[v] // 4 < 67 else "work" for v, _ in cont)
            reasons[kinds] += 1
    result["arc_pruning"] = {
        "formally_impossible_single_trigger_arcs_per_block": [len(impossible[b]) for b in range(4)],
        "reason_counts_all_blocks": {"+".join(k): v for k, v in reasons.items()},
        "impossible_arcs_block1": [list(x) for x in sorted(impossible[0])],
    }
    result["big_m_active_examples"] = [
        {"signature": [n, [list(x) for x in c], [list(x) for x in ac]], "count": count, "example": signature_examples[key]}
        for key, count in sorted(signature_counts.items(), key=lambda item: (-item[1], str(item[0])))
        for n, c, ac in [key]
    ]
    coverage = collections.Counter()
    for (i, j, b, kind), count in arc_trigger_counts.items():
        def cls(node):
            return "0" if node == 0 else "T" if node <= 60 else "B" if node <= 65 else "L"
        coverage[(kind, cls(i), cls(j), count)] += 1
    result["big_m_coverage"] = [
        {"kind": k[0], "tail": k[1], "head": k[2], "constraints_per_arc": k[3], "arc_count_all_blocks": n}
        for k, n in sorted(coverage.items())
    ]
    uncovered = []
    nonpositive = []
    all_positive = []
    for v, (i, j, b) in arcs.items():
        ds = single_time_durations.get((i, j, b), [])
        if not ds:
            uncovered.append((i, j, b))
        else:
            all_positive.extend(ds)
            if min(ds) <= 0:
                nonpositive.append((i, j, b, f(min(ds))))
    result["positive_time_arc_proof"] = {
        "covered_directed_arcs": len(single_time_durations),
        "uncovered_count": len(uncovered),
        "uncovered_categories": dict(collections.Counter(
            ("0" if i == 0 else "T" if i <= 60 else "B" if i <= 65 else "L") + "->" +
            ("0" if j == 0 else "T" if j <= 60 else "B" if j <= 65 else "L")
            for i, j, _ in uncovered
        )),
        "uncovered_block1": [list(x[:2]) for x in uncovered if x[2] == 0],
        "minimum_positive_increment": f(min(all_positive)),
        "maximum_positive_increment": f(max(all_positive)),
        "nonpositive_count": len(nonpositive),
        "nonpositive_examples": [list(x) for x in nonpositive[:20]],
    }

    text = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if a.output:
        a.output.write_text(text, encoding="utf-8")
    print(text)


if __name__ == "__main__":
    main()
