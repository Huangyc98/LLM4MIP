#!/usr/bin/env python3
"""Fix all original integer variables to a supplied pattern and reoptimize."""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import time
from pathlib import Path

import coptpy as cp
from coptpy import COPT

from helper_route_logic import parse


def values(path: Path) -> dict[str, float]:
    answer: dict[str, float] = {}
    for raw in path.read_text(encoding="ascii").splitlines():
        fields = raw.split()
        if len(fields) != 2 or fields[0].startswith(("#", "=")):
            continue
        answer[fields[0]] = float(fields[1])
    return answer


def safe(model, attribute, default=None):
    try:
        return getattr(model, attribute)
    except Exception:
        return default


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--model", type=Path, required=True)
    ap.add_argument("--pattern", type=Path, required=True)
    ap.add_argument("--output-dir", type=Path, required=True)
    ap.add_argument("--time-limit", type=float, default=300)
    ap.add_argument("--threads", type=int, default=4)
    args = ap.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    supplied = values(args.pattern)
    _, _, _, _, _, _, _, _, integer = parse(args.model)

    model = cp.Envr().createModel("fixed-integer-reoptimization")
    model.read(str(args.model))
    variables = model.getVars().getAll()
    fixed = 0
    for variable in variables:
        if variable.name not in integer:
            continue
        value = float(round(supplied.get(variable.name, 0.0)))
        variable.setInfo(COPT.Info.LB, value)
        variable.setInfo(COPT.Info.UB, value)
        fixed += 1
    model.setLogFile(str(args.output_dir / "solver.log"))
    model.setParam(COPT.Param.Logging, 1)
    model.setParam(COPT.Param.Threads, args.threads)
    model.setParam(COPT.Param.TimeLimit, args.time_limit)
    model.setParam(COPT.Param.RelGap, 0.0)
    model.setParam(COPT.Param.GPUMode, 0)
    try:
        model.setParam(COPT.Param.FeasTol, 1e-9)
    except Exception:
        pass
    started = time.time()
    model.solve()
    elapsed = time.time() - started
    result = {
        "schema": "fixed-integer-copt-reoptimization-v1",
        "host": platform.node(),
        "copt_version": [COPT.VERSION_MAJOR, COPT.VERSION_MINOR, COPT.VERSION_TECHNICAL],
        "model_sha256": digest(args.model),
        "pattern_sha256": digest(args.pattern),
        "script_sha256": digest(Path(__file__)),
        "variables": len(variables),
        "fixed_integer_variables": fixed,
        "free_continuous_variables": len(variables) - fixed,
        "time_limit": args.time_limit,
        "threads": args.threads,
        "wall_seconds": elapsed,
        "status": safe(model, "status"),
        "has_mip_solution": bool(safe(model, "hasmipsol", False)),
        "objective": safe(model, "objval"),
        "best_bound": safe(model, "bestbnd"),
        "relative_gap": safe(model, "mipgap"),
        "solver_time": safe(model, "solvingtime"),
    }
    if result["has_mip_solution"]:
        path = args.output_dir / "solution.sol"
        model.writeSol(str(path))
        result["solution_sha256"] = digest(path)
    (args.output_dir / "result.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print("FINAL_RESULT " + json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
