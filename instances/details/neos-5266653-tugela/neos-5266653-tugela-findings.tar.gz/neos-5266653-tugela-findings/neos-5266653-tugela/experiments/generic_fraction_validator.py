#!/usr/bin/env python3
"""Exact Fraction validation for a sparse MIPLIB solution and MPS file."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
from fractions import Fraction
from pathlib import Path

from helper_route_logic import parse


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def solution_lines(path: Path) -> list[str]:
    if path.suffix == ".gz":
        with gzip.open(path, "rt", encoding="ascii") as stream:
            return stream.read().splitlines()
    return path.read_text(encoding="ascii").splitlines()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--solution", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--sample-limit", type=int, default=100)
    args = parser.parse_args()

    senses, row_order, variables, columns, rows, rhs, lower, upper, integer = parse(args.model)
    variable_set = set(variables)
    sparse: dict[str, Fraction] = {}
    header_objective = None
    for line_number, raw_line in enumerate(solution_lines(args.solution), 1):
        line = raw_line.strip()
        if not line:
            continue
        if line.startswith("=obj="):
            header_objective = Fraction(line.split(None, 1)[1])
            continue
        if line.startswith("#"):
            marker = "Objective value ="
            if marker in line:
                header_objective = Fraction(line.split(marker, 1)[1].strip())
            continue
        pieces = line.split()
        if len(pieces) != 2:
            raise ValueError(f"{args.solution}:{line_number}: expected NAME VALUE")
        variable, raw_value = pieces
        if variable not in variable_set:
            raise ValueError(f"{args.solution}:{line_number}: unknown variable {variable}")
        if variable in sparse:
            raise ValueError(f"{args.solution}:{line_number}: duplicate variable {variable}")
        sparse[variable] = Fraction(raw_value)
    values = {variable: sparse.get(variable, Fraction(0)) for variable in variables}

    bound_count = 0
    bound_samples = []
    integrality_count = 0
    integrality_samples = []
    for variable in variables:
        value = values[variable]
        violation = (
            (lower[variable] is not None and value < lower[variable])
            or (upper[variable] is not None and value > upper[variable])
        )
        if violation:
            bound_count += 1
            if len(bound_samples) < args.sample_limit:
                bound_samples.append(
                    [variable, str(value), str(lower[variable]), str(upper[variable])]
                )
        if variable in integer and value.denominator != 1:
            integrality_count += 1
            if len(integrality_samples) < args.sample_limit:
                integrality_samples.append([variable, str(value)])

    row_count = 0
    row_samples = []
    maximum_violation = Fraction(0)
    maximum_row = None
    for row in row_order:
        activity = sum(coefficient * values[variable] for variable, coefficient in rows[row])
        target = rhs.get(row, Fraction(0))
        if senses[row] == "E":
            violation = abs(activity - target)
        elif senses[row] == "L":
            violation = max(Fraction(0), activity - target)
        else:
            violation = max(Fraction(0), target - activity)
        if violation > maximum_violation:
            maximum_violation = violation
            maximum_row = row
        if violation:
            row_count += 1
            if len(row_samples) < args.sample_limit:
                row_samples.append(
                    [row, str(activity), senses[row], str(target), str(violation)]
                )

    objective_rows = {
        row
        for terms in columns.values()
        for row, coefficient in terms.items()
        if row not in senses and coefficient
    }
    if len(objective_rows) != 1:
        raise ValueError(f"could not identify unique objective row: {objective_rows}")
    objective_row = next(iter(objective_rows))
    objective = sum(
        columns[variable].get(objective_row, Fraction(0)) * values[variable]
        for variable in variables
    )
    result = {
        "schema": "generic-miplib-solution-fraction-validation-v1",
        "model": args.model.as_posix(),
        "model_sha256": file_sha256(args.model),
        "solution": args.solution.as_posix(),
        "solution_sha256": file_sha256(args.solution),
        "variables_materialized": len(variables),
        "explicit_values": len(sparse),
        "rows_checked": len(row_order),
        "objective_fraction": str(objective),
        "objective_decimal": float(objective),
        "header_objective_fraction": None if header_objective is None else str(header_objective),
        "header_matches_exact_objective": header_objective is None or header_objective == objective,
        "bound_violation_count": bound_count,
        "integrality_violation_count": integrality_count,
        "row_violation_count": row_count,
        "maximum_exact_row_violation": str(maximum_violation),
        "maximum_exact_row_violation_decimal": float(maximum_violation),
        "maximum_violation_row": maximum_row,
        "valid_at_zero_tolerance": bound_count == 0 and integrality_count == 0 and row_count == 0,
        "bound_violation_samples": bound_samples,
        "integrality_violation_samples": integrality_samples,
        "row_violation_samples": row_samples,
        "validator_sha256": file_sha256(Path(__file__)),
        "parser_sha256": file_sha256(Path(__file__).with_name("helper_route_logic.py")),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({
        key: result[key]
        for key in (
            "objective_fraction",
            "header_matches_exact_objective",
            "bound_violation_count",
            "integrality_violation_count",
            "row_violation_count",
            "maximum_exact_row_violation",
            "maximum_violation_row",
            "valid_at_zero_tolerance",
        )
    }, indent=2))


if __name__ == "__main__":
    main()
