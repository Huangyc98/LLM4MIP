#!/usr/bin/env python3
"""Exactly repair continuous difference variables for a fixed integer pattern."""

from __future__ import annotations

import argparse
import hashlib
import json
from fractions import Fraction
from pathlib import Path

from helper_route_logic import parse


def read_solution(path: Path) -> dict[str, Fraction]:
    values: dict[str, Fraction] = {}
    for raw in path.read_text(encoding="ascii").splitlines():
        fields = raw.split()
        if len(fields) == 2 and not fields[0].startswith(("#", "=")):
            values[fields[0]] = Fraction(fields[1])
    return values


def terminating(value: Fraction) -> str:
    if value == 0:
        return "0"
    sign = "-" if value < 0 else ""
    numerator, denominator = abs(value.numerator), value.denominator
    twos = fives = 0
    while denominator % 2 == 0:
        denominator //= 2
        twos += 1
    while denominator % 5 == 0:
        denominator //= 5
        fives += 1
    if denominator != 1:
        raise ValueError(f"nonterminating fraction: {value}")
    places = max(twos, fives)
    scaled = numerator * 2 ** (places - twos) * 5 ** (places - fives)
    digits = str(scaled).rjust(places + 1, "0")
    if places == 0:
        return sign + digits
    result = sign + digits[:-places] + "." + digits[-places:]
    return result.rstrip("0").rstrip(".")


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--model", type=Path, required=True)
    ap.add_argument("--pattern", type=Path, required=True)
    ap.add_argument("--output-solution", type=Path, required=True)
    ap.add_argument("--report", type=Path, required=True)
    args = ap.parse_args()
    senses, row_order, variables, columns, rows, rhs, lb, ub, integer = parse(args.model)
    supplied = read_solution(args.pattern)
    fixed = {variable: Fraction(round(float(supplied.get(variable, Fraction(0))))) for variable in integer}
    continuous = [variable for variable in variables if variable not in integer]
    index = {variable: number + 1 for number, variable in enumerate(continuous)}
    zero = 0
    edges: list[tuple[int, int, Fraction, str]] = []
    integer_only_infeasible = []
    unsupported = []

    def add_inequality(row: str, terms: list[tuple[str, Fraction]], target: Fraction) -> None:
        integer_activity = sum(coefficient * fixed[variable] for variable, coefficient in terms if variable in integer)
        cterms = [(variable, coefficient) for variable, coefficient in terms if variable not in integer and coefficient]
        residual = target - integer_activity
        if not cterms:
            if residual < 0:
                integer_only_infeasible.append([row, str(-residual)])
            return
        if len(cterms) == 1:
            variable, coefficient = cterms[0]
            if coefficient == 1:
                edges.append((zero, index[variable], residual, row))
            elif coefficient == -1:
                edges.append((index[variable], zero, residual, row))
            else:
                unsupported.append([row, [[v, str(a)] for v, a in cterms], str(residual)])
            return
        if len(cterms) == 2:
            positive = [variable for variable, coefficient in cterms if coefficient == 1]
            negative = [variable for variable, coefficient in cterms if coefficient == -1]
            if len(positive) == len(negative) == 1:
                # positive - negative <= residual
                edges.append((index[negative[0]], index[positive[0]], residual, row))
            else:
                unsupported.append([row, [[v, str(a)] for v, a in cterms], str(residual)])
            return
        unsupported.append([row, [[v, str(a)] for v, a in cterms], str(residual)])

    for row in row_order:
        target = rhs.get(row, Fraction(0))
        if senses[row] in ("L", "E"):
            add_inequality(row + ("/upper" if senses[row] == "E" else ""), rows[row], target)
        if senses[row] in ("G", "E"):
            add_inequality(
                row + ("/lower" if senses[row] == "E" else ""),
                [(variable, -coefficient) for variable, coefficient in rows[row]],
                -target,
            )
    for variable in continuous:
        if ub[variable] is not None:
            edges.append((zero, index[variable], ub[variable], f"BOUND/UB/{variable}"))
        if lb[variable] is not None:
            edges.append((index[variable], zero, -lb[variable], f"BOUND/LB/{variable}"))
    if integer_only_infeasible or unsupported:
        raise RuntimeError(json.dumps({
            "integer_only_infeasible": integer_only_infeasible[:20],
            "unsupported": unsupported[:20],
        }, indent=2))

    distances = [Fraction(0) for _ in range(len(continuous) + 1)]
    predecessor: list[tuple[int, str] | None] = [None] * len(distances)
    iterations = 0
    last_changed = None
    for iteration in range(len(distances)):
        changed = None
        for source, destination, weight, label in edges:
            candidate = distances[source] + weight
            if distances[destination] > candidate:
                distances[destination] = candidate
                predecessor[destination] = (source, label)
                changed = destination
        iterations = iteration + 1
        last_changed = changed
        if changed is None:
            break
    if last_changed is not None and iterations == len(distances):
        cursor = last_changed
        for _ in range(len(distances)):
            assert predecessor[cursor] is not None
            cursor = predecessor[cursor][0]
        cycle = []
        start = cursor
        while True:
            prior, label = predecessor[cursor]
            cycle.append([cursor, prior, label])
            cursor = prior
            if cursor == start or len(cycle) > len(distances) + 1:
                break
        raise RuntimeError("negative cycle: " + json.dumps(cycle))

    offset = distances[zero]
    values = dict(fixed)
    for variable in continuous:
        values[variable] = distances[index[variable]] - offset

    bound_violations = integrality_violations = row_violations = 0
    maximum_violation = Fraction(0)
    violation_samples = []
    for variable in variables:
        value = values[variable]
        if ((lb[variable] is not None and value < lb[variable])
                or (ub[variable] is not None and value > ub[variable])):
            bound_violations += 1
        if variable in integer and value.denominator != 1:
            integrality_violations += 1
    for row in row_order:
        activity = sum(coefficient * values[variable] for variable, coefficient in rows[row])
        target = rhs.get(row, Fraction(0))
        violation = (
            abs(activity - target) if senses[row] == "E"
            else max(Fraction(0), activity - target) if senses[row] == "L"
            else max(Fraction(0), target - activity)
        )
        if violation:
            row_violations += 1
            if len(violation_samples) < 20:
                violation_samples.append([row, str(activity), senses[row], str(target), str(violation)])
        maximum_violation = max(maximum_violation, violation)

    objective_rows = {row for terms in columns.values() for row in terms if row not in senses}
    assert len(objective_rows) == 1
    objective_row = next(iter(objective_rows))
    objective = sum(columns[v].get(objective_row, Fraction(0)) * values[v] for v in variables)
    args.output_solution.parent.mkdir(parents=True, exist_ok=True)
    with args.output_solution.open("w", encoding="ascii", newline="\n") as stream:
        stream.write(f"=obj= {terminating(objective)}\n")
        for variable in variables:
            if values[variable]:
                stream.write(f"{variable} {terminating(values[variable])}\n")
    report = {
        "schema": "exact-difference-repair-v1",
        "continuous_variables": len(continuous),
        "fixed_integer_variables": len(integer),
        "difference_edges": len(edges),
        "bellman_ford_iterations": iterations,
        "objective_fraction": str(objective),
        "objective_decimal": terminating(objective),
        "bound_violation_count": bound_violations,
        "integrality_violation_count": integrality_violations,
        "row_violation_count": row_violations,
        "maximum_exact_row_violation": str(maximum_violation),
        "valid_at_zero_tolerance_before_serialized_reparse": (
            bound_violations == 0 and integrality_violations == 0 and row_violations == 0
        ),
        "violation_samples": violation_samples,
        "model_sha256": digest(args.model),
        "pattern_sha256": digest(args.pattern),
        "output_solution_sha256": digest(args.output_solution),
        "script_sha256": digest(Path(__file__)),
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
