#!/usr/bin/env python3
"""Optimize ns1905797 in COPT from a complete serialized MIP start."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import time
from pathlib import Path

import coptpy as cp


def attr(model, name, default=None):
    try:
        return getattr(model, name)
    except Exception:
        return default


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=Path, required=True)
    ap.add_argument("--solution", type=Path, required=True)
    ap.add_argument("--outdir", type=Path, required=True)
    ap.add_argument("--time-limit", type=float, default=900)
    ap.add_argument("--threads", type=int, default=32)
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)

    sparse = {}
    for line in args.solution.read_text(encoding="ascii").splitlines():
        pieces = line.split()
        if len(pieces) == 2 and not pieces[0].startswith("#"):
            sparse[pieces[0]] = float(pieces[1])
    environment = cp.Envr()
    model = environment.createModel("ns1905797-warmstart")
    model.read(str(args.model))
    variables = model.getVars().getAll()
    start_values = [sparse.get(variable.name, 0.0) for variable in variables]
    model.setMipStart(variables, start_values)
    load_return = model.loadMipStart()
    model.setLogFile(str(args.outdir / "solver.log"))
    model.setParam(cp.COPT.Param.Threads, args.threads)
    model.setParam(cp.COPT.Param.TimeLimit, args.time_limit)
    model.setParam(cp.COPT.Param.GPUMode, 0)
    model.setParam(cp.COPT.Param.RelGap, 0.0)
    for parameter, value in (
        (cp.COPT.Param.HeurLevel, 3),
        (cp.COPT.Param.PreRootHeurLevel, 3),
        (cp.COPT.Param.RoundingHeurLevel, 3),
        (cp.COPT.Param.DivingHeurLevel, 3),
        (cp.COPT.Param.FAPHeurLevel, 4),
        (cp.COPT.Param.SubMipHeurLevel, 3),
        (cp.COPT.Param.MipRepair, 3),
    ):
        model.setParam(parameter, value)

    started = time.time()
    model.solve()
    wall_seconds = time.time() - started
    result = {
        "schema": "ns1905797-copt-warmstart-v1",
        "host": platform.node(),
        "cpu_only": True,
        "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES", ""),
        "model_sha256": hashlib.sha256(args.model.read_bytes()).hexdigest(),
        "start_sha256": hashlib.sha256(args.solution.read_bytes()).hexdigest(),
        "model_variables": len(variables),
        "mip_start_values": len(start_values),
        "mip_start_explicit_nonzeros": len(sparse),
        "load_mip_start_return": repr(load_return),
        "parameters": {"time_limit": args.time_limit, "threads": args.threads, "gpu_mode": 0},
        "wall_seconds": wall_seconds,
        "status": attr(model, "status"),
        "has_mip_solution": bool(attr(model, "hasmipsol", False)),
        "objective": attr(model, "objval"),
        "best_bound": attr(model, "bestbnd"),
        "relative_gap": attr(model, "mipgap"),
        "node_count": attr(model, "nodecnt"),
        "solver_time": attr(model, "solvingtime"),
    }
    if result["has_mip_solution"]:
        model.write(str(args.outdir / "incumbent.sol"))
    (args.outdir / "result.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print("RESULT_JSON=" + json.dumps(result, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
