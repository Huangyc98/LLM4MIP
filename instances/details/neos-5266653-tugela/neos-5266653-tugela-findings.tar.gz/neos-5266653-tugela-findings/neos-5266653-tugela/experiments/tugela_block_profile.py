#!/usr/bin/env python3
"""Profile tugela's 18 interleaved vehicle blocks in an exact solution."""

from __future__ import annotations

import argparse
import hashlib
import json
from fractions import Fraction
from pathlib import Path

from helper_route_logic import parse


def solution(path: Path) -> dict[str, Fraction]:
    answer: dict[str, Fraction] = {}
    for raw in path.read_text(encoding="ascii").splitlines():
        fields = raw.split()
        if len(fields) == 2 and not fields[0].startswith(("#", "=")):
            answer[fields[0]] = Fraction(fields[1])
    return answer


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--model", type=Path, required=True)
    ap.add_argument("--solution", type=Path, required=True)
    ap.add_argument("--output", type=Path, required=True)
    args = ap.parse_args()
    senses, _, variables, columns, _, _, _, _, integer = parse(args.model)
    values = solution(args.solution)
    objective_rows = {row for terms in columns.values() for row in terms if row not in senses}
    assert len(objective_rows) == 1
    objective_row = next(iter(objective_rows))
    blocks = []
    for block in range(18):
        members = [variable for position, variable in enumerate(variables) if position % 18 == block]
        active = [variable for variable in members if variable in integer and values.get(variable, Fraction(0)) == 1]
        contribution = sum(
            columns[variable].get(objective_row, Fraction(0)) * values.get(variable, Fraction(0))
            for variable in members
        )
        blocks.append({
            "block_zero_based": block,
            "block_one_based": block + 1,
            "variables": len(members),
            "integer_variables": sum(variable in integer for variable in members),
            "continuous_variables": sum(variable not in integer for variable in members),
            "active_integer_count": len(active),
            "objective_fraction": str(contribution),
            "objective_decimal": float(contribution),
            "active_variable_sample": active[:100],
        })
    result = {
        "schema": "tugela-interleaved-block-profile-v1",
        "model_sha256": sha(args.model),
        "solution_sha256": sha(args.solution),
        "script_sha256": sha(Path(__file__)),
        "blocks": blocks,
        "ranking_by_objective": [
            item["block_one_based"]
            for item in sorted(blocks, key=lambda item: item["objective_decimal"], reverse=True)
        ],
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps([
        {key: item[key] for key in ("block_one_based", "active_integer_count", "objective_decimal")}
        for item in sorted(blocks, key=lambda item: item["objective_decimal"], reverse=True)
    ], indent=2))


if __name__ == "__main__":
    main()
