# neos-5266653-tugela：车辆块重优化与严格新上界

## 当前结论

截至 2026-09-08，[MIPLIB 实例页](https://miplib.zib.de/instance_details_neos-5266653-tugela.html)
仍把本实例标为 `open`，页面 headline 为带星号的容差解
`65505.2005752763*`。

本目录得到一个对原始 MPS **零容差严格可行**的新解：

```text
65257.573990387 = 65257573990387 / 1000000000
```

它比页面 headline 降低 `247.6265848893`。最终解见
[`solutions/tugela-65257.573990387-strict.sol`](solutions/tugela-65257.573990387-strict.sol)。
精确差分约束修复报告和第二套 Fraction 重解析分别见
[`analysis/triple-3-11-12-exact-repair.json`](analysis/triple-3-11-12-exact-repair.json)
与
[`analysis/triple-3-11-12-independent-validation.json`](analysis/triple-3-11-12-independent-validation.json)：
23,310 个变量的界、22,662 个整数变量和 23,458 条约束均零违约，最大精确行违约为零。
仓库公共 checker 的再次复核在
[`solutions/tugela-65257.573990387-strict.validation.log`](solutions/tugela-65257.573990387-strict.validation.log)。

这只是严格可行上界，不是最优解证明。最终全模型 COPT 运行在 600 秒时限内
没有继续改善，浮点 `best_bound=33589.17979976425`；该数值 bound 未经可移植的
精确证明复核，不能据此把实例标为 `optimal`。

## 背景与结构

MIPLIB 的说明只有“seem to be VRP”，并注明页面解来自 Gurobi 9.0；官方没有给出
bibliography。因此这里不猜测未知业务背景，而以原始 MPS 的系数级结构为准。

原始模型先在 `euler4` 上用 Gurobi 13.0.1 **只读读取**，没有调用
`presolve()` 或 `optimize()`。记录见
[`analysis/gurobi-13.0.1-structure.json`](analysis/gurobi-13.0.1-structure.json)
和 [`logs/gurobi-13.0.1-structure.log`](logs/gurobi-13.0.1-structure.log)。

| 属性 | 数值 |
|---|---:|
| 变量 | 23,310 |
| 约束 | 23,458 |
| 非零元 | 171,534 |
| 二元/整数变量 | 22,662 |
| 连续变量 | 648 |
| 目标非零列 | 22,644 |
| 目标方向 | 最小化 |

DEC 与逐列系数分析恢复出 18 个同型车辆块；每块恰有 1,295 个变量，含
1,259 个二元变量和 36 个连续势变量。行模板具有路径流、客户唯一分配、容量和
先后次序约束的模式，与 VRP 解释一致。严格种子中只有车辆块 3、10、11、12
非空，其成本贡献及激活列见
[`analysis/vehicle-block-profile.json`](analysis/vehicle-block-profile.json)。

原始输入为 [`input/neos-5266653-tugela.mps.gz`](input/neos-5266653-tugela.mps.gz)，
SHA-256 是
`f363a7804415c5bc60952b4a2c8ee73e47d41d21ab9122e6e4595cb521ef9ec7`；
DEC 和 MIPLIB official revision 3 也保存在 [`input/`](input/) 中。

## 官方解零容差审计

official revision 3 的字面目标为
`65505.200575276310617654960302300`，但它不是零容差可行点：

| 项目 | 结果 |
|---|---:|
| 精确行违约 | 227 |
| 整数性违约 | 23 |
| 变量界违约 | 1 |
| 最大违约 | `8.5960924212e-7` |

完整审计见
[`analysis/official-3-strict-validation.json`](analysis/official-3-strict-validation.json)
和 [`logs/official-3-common-checker.log`](logs/official-3-common-checker.log)。
这解释了 headline 的星号；新解与 headline 的比较仍按数值目标进行，但新解本身
已经通过严格验证。

## 求解过程

### 1. official 模式取整与势变量精确修复

先把 official 解的全部二元变量取整并固定，由 COPT 重新求连续部分；再把 648 个
连续势变量写成差分逻辑系统，以 Bellman--Ford 在有理数上构造可行势。得到第一份
严格种子
[`solutions/tugela-65505.241756227-strict.sol`](solutions/tugela-65505.241756227-strict.sol)，
目标 `65505.241756227`。其修复与独立重放见
[`analysis/rounded-official-strict-repair.json`](analysis/rounded-official-strict-repair.json)
和
[`analysis/rounded-official-independent-validation.json`](analysis/rounded-official-independent-validation.json)。

从该种子做 1,200 秒、12 线程全模型 COPT warm start，没有改善；浮点 bound 为
`33980.59039023698`，见
[`experiments/warm-from-65505/result.json`](experiments/warm-from-65505/result.json)。

### 2. 两车辆与三车辆块 LNS

对四个非空块的六个车辆对逐一释放对应二元变量，同时保持全部连续势变量自由；
其余二元变量固定。status 1 仅表示对应的**受限 COPT 子问题**数值闭合。

| 释放块 | 最终时限 | COPT 状态 | incumbent | bound | 结论 |
|---|---:|---:|---:|---:|---|
| 3,10 | 120s | 1 | `65505.241756227` | 同 incumbent | 无改善，受限子问题闭合 |
| 3,11 | 120s | 1 | `65505.241756227` | 同 incumbent | 无改善，受限子问题闭合 |
| 3,12 | 300s retry | 1 | `65505.241756227` | 同 incumbent | 无改善，受限子问题闭合 |
| 10,12 | 120s | 1 | `65505.241756227` | 同 incumbent | 无改善，受限子问题闭合 |
| 10,11 | 300s retry | 8 | `65505.241756227` | `63986.42577094592` | 超时，无改善 |
| 11,12 | 300s retry | 8 | `65505.241756227` | `54811.28698719349` | 超时，无改善 |

全部 result 与日志分别在 [`experiments/block-lns/`](experiments/block-lns/)
和 [`logs/block-lns/`](logs/block-lns/) 中。

随后同时释放块 3、11、12。600 秒、8 线程运行找到浮点候选
`65257.573990387`，但以 status 8 超时，局部浮点 bound 为
`59149.21891422553`。候选的全部二元模式经过差分势精确重建及第二套 Fraction
全行重放后形成当前严格解。三块运行本身没有闭合，所以不能称为该邻域最优。

### 3. 新严格点全模型确认

从 `65257.573990387` 严格点再跑 600 秒、8 线程全模型 COPT；探索 2,189 个节点，
没有新 incumbent，status 8，浮点 bound `33589.17979976425`。归档见
[`experiments/warm-from-65257/result.json`](experiments/warm-from-65257/result.json)
与 [`logs/warm-from-65257/`](logs/warm-from-65257/)。

## 证据边界

- `65257.573990387` 是原始十进制 MPS 上的严格可行上界。
- COPT 全模型 `best_bound` 是浮点数值，不是本目录提供的严格下界证书。
- pair/triple 的 bound 只属于固定其余车辆块后的受限邻域；不能外推为全局下界。
- status 8 表示达到时限，不表示最优、不可行或邻域闭合。
- status 1 的四个 pair 也只是 solver-backed 的受限计算闭合，没有可移植证明文件。
- 当前没有 global optimality proof，实例仍应保持 `open`。

## 复现

从仓库根目录执行零容差检查：

```bash
python common/exact_mps_solution_check.py \
  instances/neos-5266653-tugela/input/neos-5266653-tugela.mps.gz \
  instances/neos-5266653-tugela/solutions/tugela-65257.573990387-strict.sol \
  --tolerance 0

python common/exact_mps_solution_check.py \
  instances/neos-5266653-tugela/input/neos-5266653-tugela.mps.gz \
  instances/neos-5266653-tugela/input/neos-5266653-tugela-official-3.sol.gz \
  --tolerance 0
```

重跑三车辆受限搜索需要 COPT 8：

```bash
python instances/neos-5266653-tugela/experiments/copt_interleaved_block_lns.py \
  --model instances/neos-5266653-tugela/input/neos-5266653-tugela.mps.gz \
  --solution instances/neos-5266653-tugela/solutions/tugela-65505.241756227-strict.sol \
  --blocks 3,11,12 --output-dir /tmp/tugela-triple-3-11-12 \
  --time-limit 600 --threads 8
```

检查归档哈希：

```bash
(cd instances/neos-5266653-tugela && sha256sum -c SHA256SUMS)
```

`SHA256SUMS` 覆盖本目录除清单自身以外的全部归档文件。
