#!/usr/bin/env python3
"""Recover member/material and symmetry structure from eva1aprime5x5opt."""

from __future__ import annotations

import argparse
import gzip
from collections import Counter, defaultdict
from decimal import Decimal
from pathlib import Path


def open_text(path: Path):
    if path.suffix == ".gz":
        return gzip.open(path, "rt", encoding="latin-1")
    return path.open(encoding="latin-1")


def read_solution(path: Path) -> dict[str, Decimal]:
    result: dict[str, Decimal] = {}
    with path.open(encoding="utf-8") as handle:
        for line in handle:
            fields = line.split()
            if len(fields) != 2 or fields[0].startswith(("#", "=")):
                continue
            try:
                result[fields[0]] = Decimal(fields[1])
            except Exception:
                pass
    return result


class UnionFind:
    def __init__(self, count: int):
        self.parent = list(range(count))

    def find(self, item: int) -> int:
        while self.parent[item] != item:
            self.parent[item] = self.parent[self.parent[item]]
            item = self.parent[item]
        return item

    def union(self, first: int, second: int) -> None:
        a, b = self.find(first), self.find(second)
        if a != b:
            self.parent[b] = a


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("solution", type=Path)
    args = parser.parse_args()

    section = ""
    row_types: dict[str, str] = {}
    integer_variables: set[str] = set()
    variables: set[str] = set()
    row_variables: defaultdict[str, list[str]] = defaultdict(list)
    row_coefficients: defaultdict[str, list[Decimal]] = defaultdict(list)
    integer_mode = False
    with open_text(args.mps) as handle:
        for line in handle:
            fields = line.split()
            if not fields or fields[0].startswith("*"):
                continue
            if fields[0] in {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}:
                section = fields[0]
                continue
            if section == "ROWS":
                row_types[fields[1]] = fields[0]
            elif section == "COLUMNS":
                if "'MARKER'" in fields:
                    integer_mode = "'INTORG'" in fields
                    continue
                name = fields[0]
                variables.add(name)
                if integer_mode:
                    integer_variables.add(name)
                for row, coefficient in zip(fields[1::2], fields[2::2]):
                    row_variables[row].append(name)
                    row_coefficients[row].append(Decimal(coefficient))

    continuous = variables - integer_variables
    integer_indices = sorted(int(name.rsplit("_", 1)[1]) for name in integer_variables)
    if integer_indices != list(range(1313, 1713)):
        raise ValueError("unexpected integer-variable block")

    material1 = {f"x_{1313 + member}": member for member in range(200)}
    material2 = {f"x_{1513 + member}": member for member in range(200)}
    member_of = material1 | material2
    material_of = {name: 1 for name in material1} | {name: 2 for name in material2}

    signature_counts: Counter[tuple[str, int, int]] = Counter()
    for row, kind in row_types.items():
        if kind == "N":
            continue
        integer_count = sum(name in integer_variables for name in row_variables[row])
        continuous_count = sum(name in continuous for name in row_variables[row])
        signature_counts[(kind, continuous_count, integer_count)] += 1

    one_material_rows: list[str] = []
    crossing_rows: list[str] = []
    symmetry_rows: list[str] = []
    member_symmetry = UnionFind(200)
    for row, kind in row_types.items():
        names = row_variables[row]
        integers = [name for name in names if name in integer_variables]
        continuous_count = sum(name in continuous for name in names)
        if kind == "L" and continuous_count == 0 and len(integers) == 2:
            members = [member_of[name] for name in integers]
            materials = [material_of[name] for name in integers]
            if members[0] == members[1] and sorted(materials) == [1, 2]:
                one_material_rows.append(row)
        elif kind == "L" and continuous_count == 0 and len(integers) == 4:
            crossing_rows.append(row)
        elif kind == "E" and continuous_count == 0 and len(integers) == 2:
            members = [member_of[name] for name in integers]
            materials = [material_of[name] for name in integers]
            if materials[0] == materials[1]:
                symmetry_rows.append(row)
                member_symmetry.union(members[0], members[1])

    orbits: defaultdict[int, list[int]] = defaultdict(list)
    for member in range(200):
        orbits[member_symmetry.find(member)].append(member)
    orbit_sizes = Counter(len(orbit) for orbit in orbits.values())

    values = read_solution(args.solution)
    selected_m1 = [member for name, member in material1.items() if values.get(name, Decimal(0)) > Decimal("0.5")]
    selected_m2 = [member for name, member in material2.items() if values.get(name, Decimal(0)) > Decimal("0.5")]
    selected_members = sorted(selected_m1 + selected_m2)
    selected_orbits = {member_symmetry.find(member) for member in selected_members}

    print(f"variables={len(variables)} continuous={len(continuous)} integer={len(integer_variables)}")
    print("integer_block=x_1313..x_1512 (material 1), x_1513..x_1712 (material 2)")
    print(f"candidate_members=200 one_material_rows={len(one_material_rows)}")
    print(f"crossing_member_pair_rows={len(crossing_rows)}")
    print(f"symmetry_rows={len(symmetry_rows)} member_orbits={len(orbits)} orbit_sizes={dict(sorted(orbit_sizes.items()))}")
    print(f"official_selected_material1={len(selected_m1)} members={selected_m1}")
    print(f"official_selected_material2={len(selected_m2)} members={selected_m2}")
    print(f"official_existing_members={len(selected_members)} selected_symmetry_orbits={len(selected_orbits)}")
    print("row_signature_counts")
    for signature, count in sorted(signature_counts.items()):
        print(f"  sense={signature[0]} continuous={signature[1]} integer={signature[2]} count={count}")


if __name__ == "__main__":
    main()
