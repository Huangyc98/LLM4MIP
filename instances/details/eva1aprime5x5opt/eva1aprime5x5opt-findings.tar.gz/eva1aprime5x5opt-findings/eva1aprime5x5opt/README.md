# `eva1aprime5x5opt`

## Result

The official objective `-17.94807560443689` remains the best strict incumbent
in this study.  It has 14 selected member/material binaries and passes all rows,
bounds, and integrality checks below `1e-9`.  Global optimality remains open.

The main new result is a strict local certificate.  For the improvement target

```text
objective <= -17.94807660443689
```

Gurobi 13.0.1 proves the model **infeasible inside bit-Hamming radius 8** of
the official 400-bit material-selection vector.  The confirmation run used
`FeasibilityTol=1e-9`, `IntFeasTol=1e-9`, `NumericFocus=3`, and
`DualReductions=0`, and explicitly returned `Model is infeasible` after 71,682
nodes and 492.69 seconds.  Radius 10 found no improving point in 900 seconds but
did not close its tree, so the proved radius is 8.

## Input and provenance

- MPS SHA-256: `20EB8329BA8F417F782A89A22B1D1CFB9F6064536A5E16887879F5F90B224AF4`
- Official compressed solution SHA-256: `69A596213BABBD53824B03758C4C0C3D2916C3AF4C20A2DA2A1B10777FC79000`
- [MIPLIB instance page](https://miplib.zib.de/instance_details_eva1aprime5x5opt.html)
- Hirota and Kanno, [*Optimal Design of Periodic Frame Structures with Negative Thermal Expansion via Mixed Integer Programming*](https://www.keisu.t.u-tokyo.ac.jp/data/2014/METR14-02.pdf), DOI [10.1007/s11081-015-9276-z](https://doi.org/10.1007/s11081-015-9276-z)

## Recovered structure

The model selects a topology for a periodic frame made from two materials or
void.  Its objective is `1000*x_1`, the scaled thermally induced displacement
of an interface node.

| Component | Count | Role |
|---|---:|---|
| continuous variables | 1,312 | displacements, generalized stresses, and auxiliaries for two thermal/load states |
| material-1 binaries | 200 | `x_1313` through `x_1512` |
| material-2 binaries | 200 | `x_1513` through `x_1712` |
| one-material rows | 200 | at most one material for each candidate member |
| crossing-member packing rows | 3,424 | prohibit simultaneous intersecting members |
| symmetry equalities | 192 | pair symmetric member/material choices |

The 192 binary equalities induce 104 member symmetry orbits: 96 orbits of
size two and eight singleton orbits.  The official design selects six
material-1 members and eight material-2 members, occupying seven complete
symmetry orbits.  Gurobi presolve reduces the original 400 binaries to 152.
See [`discrete-structure-summary.txt`](artifacts/discrete-structure-summary.txt).

## Numerical-solution audit

An aggressive default-tolerance Gurobi run reported the apparently improved
value `-17.948224788857717`.  It had exactly the same binary pattern as the
official solution, and exact-decimal recomputation found a maximum row residual
of `1.9783e-7`.  Fixing all 400 binaries and reoptimizing with `1e-9`
feasibility tolerance returned to `-17.948075604436321`, effectively the
official objective.  The apparent improvement is therefore retained only as a
numerical diagnostic, not as a new incumbent.

A separate strict global Gurobi run changed the objective by only `1.9e-9`,
again without changing a binary.  This is below the study's `1e-6`
improvement margin and is also treated as same-pattern numerical noise.  Full
checker results are in [`exact-check-summary.txt`](artifacts/exact-check-summary.txt).

## Experiments

| Method | Threads | Limit | Result |
|---|---:|---:|---|
| Gurobi 13.0.1, default tolerance, NoRel + tree | 32 | 900 s | numerical `-17.9482247889`; same binaries; fails strict `1e-9` audit |
| Gurobi, fixed-pattern strict repair | 32 | under 1 s | returns official objective |
| Gurobi, strict global NoRel + tree | 32 | 900 s | no new topology; lower bound `-497.110592744` |
| COPT 8.0.4, aggressive heuristics | 32 | 900 s | official incumbent retained; lower bound **`-458.919072061`** |
| Gurobi strict local radius 2 | 32 | 7.54 s | target infeasible/unbounded; tree closed |
| Gurobi strict local radius 4 | 32 | 20.96 s | target infeasible/unbounded; tree closed |
| Gurobi strict local radius 6 | 32 | 112.86 s | target infeasible/unbounded; tree closed |
| Gurobi strict local radius 8, `DualReductions=0` | 64 | 492.69 s | **target infeasible**, 71,682 nodes |
| Gurobi strict local radius 10 | 32 | 900 s | no solution; 69,002 nodes; time limit |

The global lower bound remains extremely weak relative to the incumbent, so no
global optimality claim is made.  All COPT work on `altman` used CPU only;
**GPU0 was not used**.

## Method

For an incumbent bit vector `z`, local branching adds

```text
sum(z_i = 1)(1 - z_i) + sum(z_i = 0) z_i <= radius
```

together with the explicit strict-improvement cutoff.  This is the local-MILP
search suggested for larger instances in the source paper.  The radius counts
original material bits; symmetry equalities mean a physical symmetric member
change commonly consumes two bits.

Reproduce the structure and model generation with:

```powershell
python .\instances\eva1aprime5x5opt\scripts\analyze_discrete_structure.py `
  .\instances\eva1aprime5x5opt\input\eva1aprime5x5opt.mps.gz `
  .\instances\eva1aprime5x5opt\solutions\official-best.sol

python .\instances\eva1aprime5x5opt\scripts\make_local_branch_model.py `
  .\instances\eva1aprime5x5opt\input\eva1aprime5x5opt.mps.gz `
  .\instances\eva1aprime5x5opt\solutions\official-best.sol `
  8 .\instances\eva1aprime5x5opt\artifacts\eva_lb8.lp `
  --cutoff=-17.94807660443689
```

See the [Chinese report](reports/eva1aprime5x5opt-study.md),
[`scripts/`](scripts/), [`solutions/`](solutions/), and [`logs/`](logs/).
