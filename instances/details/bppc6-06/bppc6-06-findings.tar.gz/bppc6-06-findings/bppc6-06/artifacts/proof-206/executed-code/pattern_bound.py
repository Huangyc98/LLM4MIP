"""All-subset load patterns: LP proposes prices; integer enumeration checks them."""
import argparse
import json
from pathlib import Path
import time
from fractions import Fraction
from math import lcm, gcd
from functools import reduce
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import csr_matrix
from profile_core import coordinates, dump, load_mps


def subsets(heights, target):
    patterns = [(0, 0)]
    for i, height in enumerate(heights):
        patterns += [(mask | (1 << i), load + height) for mask, load in patterns if load + height <= target]
    return patterns


def run(data, target):
    started = time.monotonic()
    coords, widths = coordinates(data)
    heights = [it['height'] for it in data['items']]
    patterns = subsets(heights, target)
    rr, cc = [], []
    for r, (mask, load) in enumerate(patterns):
        for i in range(len(heights)):
            if mask >> i & 1:
                rr.append(r)
                cc.append(i)
    matrix = csr_matrix((np.ones(len(rr)), (rr, cc)), shape=(len(patterns), len(heights)))
    result = linprog(-np.array(widths, dtype=float), A_ub=matrix, b_ub=np.ones(len(patterns)),
                     bounds=(0, None), method='highs', options={'time_limit': 30})
    assert result.success, result.message
    fractions = [Fraction(float(max(0, x))).limit_denominator(10000) for x in result.x]
    denominator = lcm(*(v.denominator for v in fractions))
    q = [int(v * denominator) for v in fractions]
    divisor = reduce(gcd, q)
    q = [v // divisor for v in q]
    scale = max(sum(q[i] for i in range(len(q)) if mask >> i & 1) for mask, load in patterns)
    lhs = sum(w * v for w, v in zip(widths, q))
    rhs = coords[-1] * scale
    return dict(target=target, method='Full one-row subset-pattern dual bound',
        mps_sha256=data['mps_sha256'], weights=q, scale=scale,
        numerator=lhs, capacity_numerator=rhs, strict_contradiction=lhs > rhs,
        patterns=len(patterns), relaxed_required_length=lhs / scale, available_length=coords[-1],
        lp_required_length=-result.fun, seconds=time.monotonic()-started,
        note='A valid dual is independently checked on every feasible 0/1 load subset. No contradiction means inconclusive.')


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('mps', type=Path)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    data = load_mps(args.mps)
    output = [run(data, target) for target in range(201, 208)]
    dump(args.output, output)
    print(json.dumps(output, indent=2))
