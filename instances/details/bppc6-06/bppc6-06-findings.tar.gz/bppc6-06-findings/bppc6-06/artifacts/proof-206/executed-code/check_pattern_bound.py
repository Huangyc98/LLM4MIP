"""No solver: Gray-code enumeration of ALL subsets checks a BPPC certificate."""
import argparse
import json
from pathlib import Path
import time
from profile_core import coordinates, dump, load_mps


def check(data, cert):
    started = time.monotonic()
    assert cert['mps_sha256'] == data['mps_sha256']
    target, weights, scale = cert['target'], cert['weights'], cert['scale']
    assert type(target) is int and type(scale) is int and scale > 0
    assert len(weights) == len(data['items']) and all(type(w) is int and w >= 0 for w in weights)
    heights = [item['height'] for item in data['items']]
    # Independent from the certificate producer's recursive feasible-only generation.
    mask = load = weight = maximum = 0
    count = 1
    for k in range(1, 1 << len(heights)):
        new_mask = k ^ (k >> 1)
        bit = (new_mask ^ mask).bit_length() - 1
        sign = 1 if new_mask >> bit & 1 else -1
        load += sign * heights[bit]
        weight += sign * weights[bit]
        if load <= target:
            count += 1
            maximum = max(maximum, weight)
            assert weight <= scale, (new_mask, load, weight)
        mask = new_mask
    coords, widths = coordinates(data)
    numerator = sum(w * q for w, q in zip(widths, weights))
    capacity = scale * coords[-1]
    assert numerator == cert['numerator'] and capacity == cert['capacity_numerator']
    assert count == cert['patterns'] and maximum == scale
    assert cert['strict_contradiction'] == (numerator > capacity)
    return dict(verified=True, target=target, all_subsets_examined=1 << len(heights),
        feasible_subsets=count, maximum_pattern_weight=maximum, weights=weights, scale=scale,
        weighted_required_length=numerator, weighted_available_length=capacity,
        exact_lower_bound=target+1 if numerator > capacity else None,
        tight_every_profile_row=numerator == capacity, mps_sha256=data['mps_sha256'],
        seconds=time.monotonic()-started)


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('mps', type=Path)
    p.add_argument('certificates', type=Path)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    data = load_mps(args.mps)
    certs = json.loads(args.certificates.read_text())
    results = [check(data, c) for c in certs if c['target'] in (205, 207)]
    dump(args.output, results)
    print(json.dumps(results, indent=2))
