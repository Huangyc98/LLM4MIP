"""Read-only Gurobi path cross-check of every original BPPC row and column."""
import argparse
from pathlib import Path
import gurobipy as gp
from profile_core import dump, load_mps, coordinates, verify_assignment
import sys


def audit(mps, solution):
    data = load_mps(mps)
    model = gp.read(str(mps))
    rows = model.getConstrs()
    assert len(rows) == 273 and model.NumVars == 3922 and model.ModelSense == 1
    assert model.ObjCon == 0
    rid = {r.index: i for i, r in enumerate(rows)}
    expected = {}
    for item in data['items']:
        for o in item['options']:
            col = {item['item']: 1}
            col.update({20+t: item['height'] for t in range(o['a'], o['b'])})
            expected[o['name']] = col
    for i, r in enumerate(rows):
        assert r.Sense == ('=' if i < 20 else '<') and r.RHS == (1 if i < 20 else 0)
    for var in model.getVars():
        column = model.getCol(var)
        actual = {rid[column.getConstr(j).index]: column.getCoeff(j) for j in range(column.size())}
        if var.VarName in expected:
            assert var.VType in 'BI' and var.LB == 0 and var.UB == 1 and var.Obj == 0
            assert actual == expected[var.VarName]
        elif var.VarName == 'h':
            assert var.VType == 'C' and var.LB == 0 and var.UB >= gp.GRB.INFINITY and var.Obj == 1
            assert actual == {r: -1 for r in range(20, 273)}
        else:
            assert var.VarName in data['fixed_zero_variables'] and var.LB == var.UB == 0
    sys.path.insert(0, str(mps.parents[2] / 'tools'))
    from verify_sol import read_solution, verify
    values, obj, duplicates = read_solution(solution)
    assert not duplicates
    selected = [next(k for k, o in enumerate(item['options']) if values.get(o['name'], 0) == 1)
                for item in data['items']]
    peak, loads = verify_assignment(data, selected)
    validation = verify(mps, solution, 0)
    assert peak == obj == 208 and validation['valid_at_tolerance']
    coords, widths = coordinates(data)
    return dict(all_original_columns_checked=3922, all_original_rows_checked=273,
                mps_sha256=data['mps_sha256'], selected_official_options=selected,
                official_peak=peak, official_validation=validation,
                physical_horizon=coords[-1], widths=widths,
                all_original_columns_match_physical_coordinates=True)


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('mps', type=Path)
    p.add_argument('solution', type=Path)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    result = audit(args.mps, args.solution)
    dump(args.output, result)
    print(result)
