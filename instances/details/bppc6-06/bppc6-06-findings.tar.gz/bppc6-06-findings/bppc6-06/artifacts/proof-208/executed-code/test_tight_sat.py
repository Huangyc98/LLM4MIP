"""Exhaustive unit tests for the hand-written exact-one and BDD CNF encoders."""
import itertools
from tight_sat import CNF, eq_accept, leq_accept


def satisfiable_with_inputs(cnf, inputs, values):
    fixed = {v: b for v, b in zip(inputs, values)}
    aux = [v for v in range(1, cnf.nvars+1) if v not in fixed]
    for bits in itertools.product([False, True], repeat=len(aux)):
        assignment = dict(fixed, **{})
        assignment.update(zip(aux, bits))
        if all(any(assignment[abs(lit)] == (lit > 0) for lit in clause) for clause in cnf.clauses):
            return True
    return False


def check_bdd(weights, predicate, accept):
    cnf = CNF()
    inputs = [cnf.var(('input', i)) for i in range(len(weights))]
    cnf.bdd(inputs, weights, accept, 'test')
    for values in itertools.product([False, True], repeat=len(weights)):
        expected = predicate(sum(w for w, b in zip(weights, values) if b))
        assert satisfiable_with_inputs(cnf, inputs, values) == expected


def main():
    cnf = CNF()
    inputs = [cnf.var(('input', i)) for i in range(4)]
    cnf.exactly_one(inputs, 'one')
    for values in itertools.product([False, True], repeat=4):
        assert satisfiable_with_inputs(cnf, inputs, values) == (sum(values) == 1)
    check_bdd([1, 2, 1], lambda x: x == 2, eq_accept(2, 3))
    check_bdd([2, 3, 1], lambda x: x <= 3, leq_accept(3))
    print('exhaustive CNF encoder tests passed')


if __name__ == '__main__':
    main()
