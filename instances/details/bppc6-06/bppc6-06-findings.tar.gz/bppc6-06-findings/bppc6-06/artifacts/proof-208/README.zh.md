# bppc6-06 最优性证书（compact mirror）

结论：`optimal = 208`。

- 上界：MIPLIB 208 见证在原 MPS 上以零容差重新核验，所有行、界和整数条件均无违反。
- 下界：若 `h <= 207`，已穷举验证的组合权重迫使每个正宽度 profile 段满足
  `q-load = 4`。精确 interval/height CNF 不可满足。
- 第一检查器：drat-trim 对完整 DRAT 返回 `VERIFIED`，核心含 503,102 条原子句、
  1,001,496 条引理和 195,457,073 次归结，0 个 RAT 引理。
- 第二检查器：纯 Python、无 SAT/优化库的 LRAT RUP 重放检查 1,001,496 条引理和
  195,457,073 次 unit propagation，验证最终空子句，耗时 172.43 秒。

本目录保留约 650 KiB 的源码快照、映射、日志与复核结果。三个大文件继续保存在
euler4 的只读研究路径，不在本地重复占用约 2.65 GiB：

`/data1/wyc/automatic-research-10/bppc-priority/runs/20260906-tight-sat-proof-flush-rerun2-6100s/target-207/`

文件大小和 SHA256 见 `manifest.json`。两次较早、外部检查失败的 DRAT 不属于本证书。

