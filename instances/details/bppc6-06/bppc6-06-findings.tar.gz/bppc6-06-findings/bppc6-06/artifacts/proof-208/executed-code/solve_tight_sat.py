"""Run CaDiCaL on a frozen CNF; write a DRAT proof or decoded candidate."""
import argparse
import ctypes
import gzip
import hashlib
import json
from pathlib import Path
import time

from pysat.formula import CNF
from pysat.solvers import Solver, pysolvers

from profile_core import dump, load_mps, verify_assignment


def finalized_proof(solver):
    """Destroy CaDiCaL to flush its C proof stream before reading TemporaryFile.

    PySAT's get_proof() reads before cadical195_del().  For a 1 GiB trace that
    omitted the final buffered contradiction.  We keep the proof file open,
    finalize the native solver, then convert the complete binary DRUP stream.
    """
    backend = solver.solver if hasattr(solver, 'solver') else solver
    proof_file = backend.prfile
    assert backend.cadical and proof_file
    # CaDiCaL writes through a native stdio stream that PySAT does not expose.
    # Flush all C streams while the tracer is still attached, then finalize it.
    assert ctypes.CDLL(None).fflush(None) == 0
    pysolvers.cadical195_del(backend.cadical, proof_file)
    backend.cadical = None
    assert ctypes.CDLL(None).fflush(None) == 0
    proof_file.flush()
    proof_file.seek(0)
    raw = bytearray(proof_file.read()).strip()
    proof = Solver._proof_bin2text(raw)
    proof_file.close()
    backend.prfile = None
    # CaDiCaL/PySAT may omit the explicit final empty-clause record.  Appending
    # it is safe only because every emitted proof is subsequently accepted by
    # an external DRAT checker; an unsupported empty clause is rejected there.
    if not proof or proof[-1] != '0':
        proof.append('0')
    return proof


def main():
    p = argparse.ArgumentParser()
    p.add_argument('mps', type=Path)
    p.add_argument('folder', type=Path)
    p.add_argument('--result', type=Path, required=True)
    p.add_argument('--phase-solution', type=Path)
    a = p.parse_args()
    mapping = json.loads((a.folder/'mapping.json').read_text())
    assert hashlib.sha256(a.mps.read_bytes()).hexdigest() == mapping['mps_sha256']
    assert hashlib.sha256((a.folder/'model.cnf').read_bytes()).hexdigest() == mapping['cnf_sha256']
    formula = CNF(from_file=str(a.folder/'model.cnf'))
    assert formula.nv == mapping['variables'] and len(formula.clauses) == mapping['clauses']
    started = time.monotonic()
    with Solver(name='cadical195', bootstrap_with=formula.clauses, with_proof=True) as solver:
        phase_count = 0
        if a.phase_solution:
            values = {}
            with gzip.open(a.phase_solution, 'rt') as f:
                for raw in f:
                    fields = raw.split()
                    if len(fields) == 2 and not fields[0].startswith('#') and fields[0] != '=obj=':
                        values[fields[0]] = float(fields[1])
            phases = []
            for row in mapping['x']:
                chosen = [x for x in row if values.get(x['name'], 0) > .5]
                assert len(chosen) == 1
                phases += [x['variable'] if x is chosen[0] else -x['variable'] for x in row]
            solver.set_phases(phases)
            phase_count = len(phases)
        sat = solver.solve()
        stats = solver.accum_stats()
        result = {'status': 'SAT' if sat else 'UNSAT', 'seconds': time.monotonic()-started,
                  'statistics': stats, 'cnf_sha256': mapping['cnf_sha256'],
                  'proof_requires_external_check': not sat,
                  'phase_literals_from_verified_208_witness': phase_count}
        if sat:
            model = set(x for x in solver.get_model() if x > 0)
            selected = []
            for row in mapping['x']:
                chosen = [x['option_index'] for x in row if x['variable'] in model]
                assert len(chosen) == 1
                selected.append(chosen[0])
            data = load_mps(a.mps)
            peak, profile = verify_assignment(data, selected)
            assert peak <= mapping['target']
            result.update(objective=peak, chosen_options=selected)
            lines = [f'=obj= {peak}', f'h {peak}']
            lines += [item['options'][k]['name']+' 1' for item, k in zip(data['items'], selected)]
            (a.folder/'candidate.sol').write_text('\n'.join(lines)+'\n')
            dump(a.folder/'candidate.json', {'objective': peak, 'chosen_options': selected, 'profile': profile})
        else:
            proof = finalized_proof(solver)
            (a.folder/'proof.drat').write_text('\n'.join(proof)+'\n')
            result['proof_lines'] = len(proof)
            result['drat_sha256'] = hashlib.sha256((a.folder/'proof.drat').read_bytes()).hexdigest()
    dump(a.result, result)
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
