"""Bounded, immutable tight-profile SAT stage for bppc6-06."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time


def digest(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def dump(path, obj):
    path = Path(path)
    tmp = path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(obj, indent=2)+'\n')
    tmp.replace(path)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--stage', required=True)
    p.add_argument('--seconds', type=int, default=300)
    a = p.parse_args()
    root = Path(os.environ['RESEARCH_ROOT']).resolve()
    work = root/'bppc-priority'
    base = work/'runs'/a.stage
    assert 1 <= a.seconds <= 7200
    assert not base.exists(), 'Never duplicate or overwrite a stage'
    available = int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines()
                         if x.startswith('MemAvailable:')))*1024
    assert available > 32*1024**3 and shutil.disk_usage(work).free > 20*1024**3
    source = base/'executed-code'
    source.mkdir(parents=True)
    scripts = ['profile_core.py', 'tight_sat.py', 'test_tight_sat.py',
               'solve_tight_sat.py', 'test_proof_flush.py', 'launch_tight_sat_stage.py']
    for name in scripts:
        shutil.copy2(work/name, source/name)
    shutil.copy2(root/'genus-priority/limit_exec.py', source/'limit_exec.py')
    mps = root/'bppc6-06/input/bppc6-06.mps.gz'
    cert = work/'proof-206/pattern-bounds.json'
    phase_solution = root/'bppc6-06/solutions/official-best.sol.gz'
    expected = {
        'mps': '960123d55e8802a11a3435608e6973b5c1f856eeebc14e9d0227b0592d8728c4',
        'certificate': '43224e6104764628addb791010bdf3e1ea7713e3e2e0b11c8006a25bcad8d197',
        'phase_solution': 'a0facec6241163a27b726a9ec96dfd9e14905cabfa6c2c308d1ea8975d08c411'}
    assert digest(mps) == expected['mps'] and digest(cert) == expected['certificate']
    assert digest(phase_solution) == expected['phase_solution']
    started = time.time()
    state = {'state': 'preparing', 'pid': os.getpid(), 'instance': 'bppc6-06',
             'stage': a.stage, 'started_unix': started, 'budget_seconds': a.seconds,
             'deadline_unix': started+a.seconds, 'target': 207,
             'maximum_simultaneous_search_processes': 1,
             'address_space_cap_gib': 16, 'current_pid': None,
             'source_sha256': {p.name: digest(p) for p in sorted(source.iterdir())},
             'input_sha256': expected,
             'method': 'Tight q-profile equality plus exact interval/height CNF; CaDiCaL with DRAT.'}
    dump(base/'supervisor.json', state)
    env = {**os.environ, 'HOUR_PASS_MEMORY_GIB': '16', 'PYTHONDONTWRITEBYTECODE': '1'}
    try:
        with (base/'tests.log').open('x') as log:
            test = subprocess.run([sys.executable, str(source/'test_tight_sat.py')], cwd=source,
                                  stdout=log, stderr=subprocess.STDOUT, env=env, timeout=60)
        assert test.returncode == 0
        flush_proof = base/'proof-flush-regression.drat'
        with (base/'proof-flush-test.log').open('x') as log:
            test = subprocess.run([sys.executable, str(source/'test_proof_flush.py'),
                                   '--output', str(flush_proof)], cwd=source,
                                  stdout=log, stderr=subprocess.STDOUT, env=env, timeout=60)
        assert test.returncode == 0
        checked = subprocess.run([str(root/'hour-pass/drat-trim/drat-trim'),
                                  str(flush_proof.with_suffix('.cnf')), str(flush_proof)],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT, timeout=60)
        assert checked.returncode == 0
        encoding = base/'target-207'
        with (base/'encoding.log').open('x') as log:
            build = subprocess.run([sys.executable, str(source/'tight_sat.py'), str(mps), str(cert),
                                    '--target', '207', '--output', str(encoding)], cwd=source,
                                   stdout=log, stderr=subprocess.STDOUT, env=env, timeout=300)
        assert build.returncode == 0
        mapping = json.loads((encoding/'mapping.json').read_text())
        assert mapping['target'] == 207 and mapping['mps_sha256'] == expected['mps']
        command = [sys.executable, str(source/'limit_exec.py'), sys.executable,
                   str(source/'solve_tight_sat.py'), str(mps), str(encoding),
                   '--result', str(encoding/'sat-result.json'),
                   '--phase-solution', str(phase_solution)]
        state.update(state='solving', current_command=command)
        with (base/'solver.log').open('x') as log:
            child = subprocess.Popen(command, cwd=source, stdout=log, stderr=subprocess.STDOUT,
                                     env=env, start_new_session=True)
            state['current_pid'] = child.pid
            dump(base/'supervisor.json', state)
            try:
                code = child.wait(timeout=max(1, state['deadline_unix']-time.time()))
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGTERM)
                try:
                    child.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
                    child.wait()
                code = 124
        dump(base/'solver-exit.json', {'exit_code': code, 'finished_unix': time.time(),
                                      'pid': child.pid, 'command': command})
        state['current_pid'] = None
        if code == 124:
            state.update(state='complete', outcome='TIME_LIMIT',
                         conclusion='No candidate or proof; do not change [206,208].')
        else:
            assert code == 0
            result = json.loads((encoding/'sat-result.json').read_text())
            if result['status'] == 'SAT':
                verifier = root/'tools/verify_sol.py'
                check = subprocess.run([sys.executable, str(verifier), str(mps),
                                        str(encoding/'candidate.sol'), '--tol', '0',
                                        '--output', str(encoding/'candidate.validation.json')],
                                       env=env, timeout=300)
                validation = json.loads((encoding/'candidate.validation.json').read_text())
                assert check.returncode == 0 and validation['valid_at_tolerance']
                assert validation['computed_objective'] <= 207
                state.update(state='complete', outcome='SAT_VERIFIED_ORIGINAL_MPS',
                             verified_upper_bound=validation['computed_objective'])
            else:
                assert result['status'] == 'UNSAT'
                state.update(state='proof_checking', current_pid=None)
                dump(base/'supervisor.json', state)
                drat = root/'hour-pass/drat-trim/drat-trim'
                with (base/'drat-check.log').open('x') as log:
                    checked = subprocess.run([str(drat), str(encoding/'model.cnf'),
                                              str(encoding/'proof.drat'), '-L',
                                              str(encoding/'proof.lrat'), '-t', '7200'],
                                             stdout=log, stderr=subprocess.STDOUT,
                                             env=env, timeout=7500)
                assert checked.returncode == 0
                state.update(state='complete', outcome='UNSAT_DRAT_VERIFIED',
                             certified_lower_bound=208, verified_upper_bound=208,
                             optimal_objective=208)
        hashes = {str(p.relative_to(base)): digest(p) for p in sorted(base.rglob('*'))
                  if p.is_file() and p.name not in {'supervisor.json', 'artifact-integrity.json'}}
        dump(base/'artifact-integrity.json', {'files_sha256': hashes, 'file_count': len(hashes),
                                              'verified_unix': time.time()})
        state.update(finished_unix=time.time(), artifact_files=len(hashes))
        dump(base/'supervisor.json', state)
        print(json.dumps(state), flush=True)
    except BaseException as exc:
        state.update(state='failed', finished_unix=time.time(), current_pid=None,
                     failure=repr(exc))
        dump(base/'supervisor.json', state)
        raise


if __name__ == '__main__':
    main()
