"""Small independent exact checker for positive-hint LRAT (RUP-only) proofs.

The graph proof contains no RAT steps. Every learned clause is checked by unit
propagation of its negation using the explicitly named previous clauses.
"""
import argparse,json,time
from pathlib import Path

def check(cnf_path,proof_path):
    clauses={};pending=[];declared=None
    with Path(cnf_path).open() as stream:
        for line in stream:
            if line.startswith('c') or not line.strip():continue
            if line.startswith('p'):declared=int(line.split()[3]);continue
            for value in map(int,line.split()):
                if value:pending.append(value)
                else:clauses[len(clauses)+1]=tuple(pending);pending=[]
    assert not pending and len(clauses)==declared
    initial=len(clauses);learned=0;steps=0;empty=False;seen_ids=set(clauses);start=time.monotonic()
    with Path(proof_path).open() as stream:
        for line in stream:
            fields=line.split()
            if not fields or fields[0]=='c':continue
            cid=int(fields[0])
            if fields[1]=='d':
                assert fields[-1]=='0'
                for key in map(int,fields[2:-1]):assert key in clauses;del clauses[key]
                continue
            assert cid not in seen_ids;seen_ids.add(cid)
            payload=list(map(int,fields[1:]));sep=payload.index(0);lemma=payload[:sep];hints=payload[sep+1:]
            assert hints[-1]==0 and all(h>0 for h in hints[:-1])
            hints=hints[:-1];assignment={};conflict=False
            for lit in lemma:
                v=abs(lit);value=lit<0
                if v in assignment and assignment[v]!=value:conflict=True
                assignment[v]=value
            for hint in hints:
                if conflict:break
                clause=clauses[hint];unassigned=[];satisfied=False
                for lit in clause:
                    value=assignment.get(abs(lit))
                    if value is None:unassigned.append(lit)
                    elif value==(lit>0):satisfied=True;break
                assert not satisfied and len(unassigned)<=1,(cid,hint,'hint is not unit or conflicting')
                steps+=1
                if not unassigned:conflict=True
                else:assignment[abs(unassigned[0])]=unassigned[0]>0
            assert conflict,(cid,'RUP failed')
            clauses[cid]=tuple(lemma);learned+=1
            if not lemma:empty=True
    assert empty,'No verified empty clause'
    return {'verified':True,'initial_clauses':initial,'checked_lemmas':learned,
            'unit_propagation_steps':steps,'empty_clause_verified':True,'seconds':time.monotonic()-start,
            'arithmetic':'exact Boolean; no optimization solver calls'}

def main():
    p=argparse.ArgumentParser();p.add_argument('cnf',type=Path);p.add_argument('lrat',type=Path);p.add_argument('--output',type=Path);a=p.parse_args()
    r=check(a.cnf,a.lrat);payload=json.dumps(r,indent=2);print(payload)
    if a.output:a.output.write_text(payload+'\n')

if __name__=='__main__':main()
