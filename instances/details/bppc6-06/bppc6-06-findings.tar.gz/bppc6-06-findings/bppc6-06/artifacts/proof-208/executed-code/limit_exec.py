"""Apply a hard address-space limit before exec, without threaded preexec_fn."""
import os,resource,sys
cap=int(os.environ.get('HOUR_PASS_MEMORY_GIB','16'))*1024**3
resource.setrlimit(resource.RLIMIT_AS,(cap,cap))
os.execvpe(sys.argv[1],sys.argv[1:],os.environ)
