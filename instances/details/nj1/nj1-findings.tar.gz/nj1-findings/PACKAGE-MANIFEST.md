# Package manifest: nj1

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 75
Excluded source files: 1

## Included files

- `README.md`
- `analysis/compound-kick-382.0606208032-validation.json`
- `analysis/compound-kick-from383-382.0606208032.compact.json.gz`
- `analysis/compound-kick-from383-382.0606208032.full.json.gz`
- `analysis/compound-kick-terminal-from382.0606208032.compact.json.gz`
- `analysis/compound-kick-terminal-from382.0606208032.full.json.gz`
- `analysis/continuation-403-to-382.0606208032-archive.json`
- `analysis/copt8-post-descent-438.5907110388-validation.json`
- `analysis/copt8-warmstart-1800s-result.json`
- `analysis/copt8-warmstart-1800s-strict-validation.json`
- `analysis/copt8-warmstart-300s-result.json`
- `analysis/final-assignment-382.0606208032.json`
- `analysis/large-neighborhood-403.4107959378-archive.json`
- `analysis/large-neighborhood-403.4107959378-validation.json`
- `analysis/large-neighborhood-chain-403.4107959378.json`
- `analysis/large-neighborhood-chain-manifest-403.4107959378.json`
- `analysis/large-neighborhood-scan-383.6229250390.json.gz`
- `analysis/large-neighborhood-terminal-kicks-403.4107959378.compact.json.gz`
- `analysis/large-neighborhood-terminal-scan-382.0606208032.json.gz`
- `analysis/large-neighborhood-terminal-scan-403.4107959378.json.gz`
- `analysis/nj1-gurobi13-structure.json`
- `analysis/pair-recombination-383.6229250390-validation.json`
- `analysis/steepest-descent-assignment.json`
- `analysis/steepest-descent-validation.json`
- `analysis/structure.json`
- `analysis/tree-partition-assignment.json`
- `analysis/tree-partition-validation.json`
- `analysis/two-node-steepest-descent-assignment.json`
- `analysis/two-node-steepest-descent-validation.json`
- `experiments/build_and_check_nj_solution.py`
- `experiments/compact_terminal_kick_result.py`
- `experiments/compound_kick_descent.py`
- `experiments/connected_boundary_steepest_descent.py`
- `experiments/connected_large_neighborhood.py`
- `experiments/connected_partition_cpsat.py`
- `experiments/connected_partition_flow_cpsat.py`
- `experiments/connected_region_grow.py`
- `experiments/connected_tree_partition.py`
- `experiments/connected_two_node_steepest_descent.py`
- `experiments/copt8_warmstart.py`
- `experiments/district1-oracle-copt-result.json`
- `experiments/district1-oracle-copt.sol`
- `experiments/district1-oracle-copt.validation.log`
- `experiments/district1-oracle-extraction.json`
- `experiments/district1-oracle.mps.gz`
- `experiments/extract_district_oracle.py`
- `experiments/gurobi13_structure.py`
- `experiments/nj_block_forensics.py`
- `experiments/remote_copt_probe.py`
- `experiments/replay_large_neighborhood_chain.py`
- `experiments/run_copt8_search.py`
- `experiments/run_gurobi13_search.py`
- `experiments/verify_large_neighborhood_chain.py`
- `input/SHA256SUMS`
- `input/nj1.dec`
- `logs/copt8-warmstart-1800s.log`
- `logs/copt8-warmstart-300s.log`
- `logs/tree-partition-search.log`
- `solutions/compound-kick-382.0606208032.independent-check.log`
- `solutions/compound-kick-382.0606208032.sol`
- `solutions/copt8-post-descent-438.5907110388.independent-check.log`
- `solutions/copt8-post-descent-438.5907110388.sol`
- `solutions/copt8-warmstart-1800s.raw.independent-check.log`
- `solutions/copt8-warmstart-1800s.raw.sol`
- `solutions/copt8-warmstart-1800s.strict.sol`
- `solutions/large-neighborhood-403.4107959378.independent-check.log`
- `solutions/large-neighborhood-403.4107959378.sol`
- `solutions/pair-recombination-383.6229250390.independent-check.log`
- `solutions/pair-recombination-383.6229250390.sol`
- `solutions/steepest-descent-465.1832684642.independent-check.log`
- `solutions/steepest-descent-465.1832684642.sol`
- `solutions/tree-partition-529.9611973238.independent-check.log`
- `solutions/tree-partition-529.9611973238.sol`
- `solutions/two-node-steepest-descent-459.0072494478.independent-check.log`
- `solutions/two-node-steepest-descent-459.0072494478.sol`

## Excluded files

- `input/nj1.mps.gz (2011989 bytes; raw benchmark input; sha256 72ae4e301408a5e9ffe3f96c18f2b37b4243a74dfdaee1480c13997fd01a6166)`
