#!/usr/bin/env python3
"""Construct balanced connected nj districts by recursive spanning-tree cuts."""

from __future__ import annotations

import argparse
import json
import random
import sys
import time
from pathlib import Path


THIS = Path(__file__).resolve()
sys.path.insert(0, str(THIS.parent))
from connected_partition_cpsat import (  # noqa: E402
    DISTRICTS,
    LOWER_POPULATION,
    NODES,
    UPPER_POPULATION,
    components,
    extract_graph,
)
from nj_block_forensics import sha256  # noqa: E402


TARGET = 8_791_894 / 12


def random_dfs_tree(remaining: set[int], adjacency: list[list[int]], rng: random.Random):
    root = rng.choice(tuple(remaining))
    parent = {root: None}
    children = {node: [] for node in remaining}
    order = [root]
    stack = [(root, rng.sample([v for v in adjacency[root] if v in remaining],
                               sum(v in remaining for v in adjacency[root])))]
    while stack:
        node, neighbors = stack[-1]
        while neighbors and neighbors[-1] in parent:
            neighbors.pop()
        if not neighbors:
            stack.pop()
            continue
        neighbor = neighbors.pop()
        if neighbor in parent:
            continue
        parent[neighbor] = node
        children[node].append(neighbor)
        order.append(neighbor)
        candidates = [v for v in adjacency[neighbor] if v in remaining and v not in parent]
        rng.shuffle(candidates)
        stack.append((neighbor, candidates))
    if len(parent) != len(remaining):
        return None
    return root, parent, children, order


def descendants(start: int, children: dict[int, list[int]]) -> set[int]:
    result = {start}
    queue = [start]
    for node in queue:
        for child in children[node]:
            result.add(child)
            queue.append(child)
    return result


def choose_piece(remaining, remaining_districts, populations, edges, adjacency, rng, tree_trials):
    remaining_population = sum(populations[node] for node in remaining)
    candidates = []
    for _ in range(tree_trials):
        tree = random_dfs_tree(remaining, adjacency, rng)
        if tree is None:
            return None
        root, _, children, order = tree
        subtree_population = {node: populations[node] for node in remaining}
        # Parent can be recovered because every child occurs exactly once.
        parent_of = {child: node for node, values in children.items() for child in values}
        for node in reversed(order[1:]):
            subtree_population[parent_of[node]] += subtree_population[node]
        for node in order:
            if node == root:
                continue
            value = subtree_population[node]
            after = remaining_population - value
            if not LOWER_POPULATION <= value <= UPPER_POPULATION:
                continue
            if not ((remaining_districts - 1) * LOWER_POPULATION
                    <= after <= (remaining_districts - 1) * UPPER_POPULATION):
                continue
            candidates.append((abs(value - TARGET) + rng.random() * 8000, node, children, value))
    if not candidates:
        return None
    candidates.sort(key=lambda item: item[0])
    evaluated = []
    for _, node, children, value in candidates[:min(30, len(candidates))]:
        piece = descendants(node, children)
        cut_cost = sum(float(cost) for left, right, cost in edges
                       if (left in piece) != (right in piece)
                       and left in remaining and right in remaining)
        evaluated.append((cut_cost + rng.random() * 2.0, abs(value - TARGET), piece, value))
    evaluated.sort(key=lambda item: (item[0], item[1]))
    return evaluated[0][2], evaluated[0][3]


def construct(populations, edges, adjacency, rng, tree_trials):
    remaining = set(range(NODES))
    assignment = [-1] * NODES
    district_populations = []
    for district in range(DISTRICTS - 1):
        chosen = choose_piece(remaining, DISTRICTS - district, populations, edges,
                              adjacency, rng, tree_trials)
        if chosen is None:
            return None
        piece, population = chosen
        for node in piece:
            assignment[node] = district
        remaining.difference_update(piece)
        district_populations.append(population)
    final_population = sum(populations[node] for node in remaining)
    if not LOWER_POPULATION <= final_population <= UPPER_POPULATION:
        return None
    for node in remaining:
        assignment[node] = DISTRICTS - 1
    district_populations.append(final_population)
    return assignment, district_populations


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--restarts", type=int, default=100)
    parser.add_argument("--trees-per-cut", type=int, default=100)
    parser.add_argument("--seed", type=int, default=20260908)
    parser.add_argument("--time-limit", type=float, default=900)
    args = parser.parse_args()

    populations, edges = extract_graph(args.mps)
    adjacency = [[] for _ in range(NODES)]
    for left, right, _ in edges:
        adjacency[left].append(right)
        adjacency[right].append(left)
    rng = random.Random(args.seed)
    started = time.time()
    best = None
    attempted = 0
    for restart in range(1, args.restarts + 1):
        if time.time() - started > args.time_limit:
            break
        attempted = restart
        candidate = construct(populations, edges, adjacency, rng, args.trees_per_cut)
        if candidate is None:
            continue
        assignment, district_populations = candidate
        component_lists = [components(assignment, district, adjacency) for district in range(DISTRICTS)]
        if not all(len(items) == 1 for items in component_lists):
            raise RuntimeError("tree-cut construction returned a disconnected district")
        objective = sum(2 * cost for left, right, cost in edges
                        if assignment[left] != assignment[right])
        value = (objective, assignment, district_populations, component_lists, restart)
        if best is None or value[0] < best[0]:
            best = value
            print(f"restart={restart} objective={objective} populations={district_populations}", flush=True)
            # Durable checkpoint: a killed optimization run still leaves its best
            # already verified connected/balanced assignment on disk.
            checkpoint = {
                "evidence_level": "constructive recursive spanning-tree cuts plus explicit population/component checks; requires original-MPS lift/check",
                "source_mps_sha256": sha256(args.mps),
                "algorithm": "random DFS spanning tree, recursively cut balanced descendant subtrees",
                "random_seed": args.seed,
                "search_complete": False,
                "restarts_attempted": restart,
                "best_restart": restart,
                "trees_per_cut": args.trees_per_cut,
                "population_bounds": [LOWER_POPULATION, UPPER_POPULATION],
                "total_population": sum(populations),
                "assignment_zero_based_district": assignment,
                "district_populations": district_populations,
                "district_component_sizes": [len(items[0]) for items in component_lists],
                "cut_edges": sum(assignment[left] != assignment[right] for left, right, _ in edges),
                "boundary_objective_original_units": str(objective),
            }
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(json.dumps(checkpoint, indent=2) + "\n", encoding="utf-8")
    if best is None:
        raise SystemExit(f"no feasible recursive tree partition in {attempted} restarts")
    objective, assignment, district_populations, component_lists, restart = best
    result = {
        "evidence_level": "constructive recursive spanning-tree cuts plus explicit population/component checks; requires original-MPS lift/check",
        "source_mps_sha256": sha256(args.mps),
        "algorithm": "random DFS spanning tree, recursively cut balanced descendant subtrees",
        "random_seed": args.seed,
        "search_complete": True,
        "restarts_attempted": attempted,
        "best_restart": restart,
        "trees_per_cut": args.trees_per_cut,
        "population_bounds": [LOWER_POPULATION, UPPER_POPULATION],
        "total_population": sum(populations),
        "assignment_zero_based_district": assignment,
        "district_populations": district_populations,
        "district_component_sizes": [len(items[0]) for items in component_lists],
        "cut_edges": sum(assignment[left] != assignment[right] for left, right, _ in edges),
        "boundary_objective_original_units": str(objective),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print("CONNECTED_ASSIGNMENT=" + str(args.output))


if __name__ == "__main__":
    main()
