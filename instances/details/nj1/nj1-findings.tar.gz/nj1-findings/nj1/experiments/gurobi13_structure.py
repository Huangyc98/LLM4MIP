#!/usr/bin/env python3
"""Read an original MPS with Gurobi 13 and emit a reproducible JSON snapshot.

The script deliberately does not call optimize() or presolve().  It records the
matrix exactly as Gurobi read it, together with type/sense/bound/objective
summaries and the SHA-256 of both the supplied file and the uncompressed MPS.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
from collections import Counter
from pathlib import Path
from statistics import median

import gurobipy as gp


def sha256(path: Path, decompress: bool = False) -> str:
    digest = hashlib.sha256()
    opener = gzip.open if decompress and path.suffix == ".gz" else open
    with opener(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def numeric_summary(values) -> dict:
    data = [float(value) for value in values]
    if not data:
        return {"count": 0, "min": None, "median": None, "mean": None, "max": None}
    return {
        "count": len(data),
        "min": min(data),
        "median": median(data),
        "mean": math.fsum(data) / len(data),
        "max": max(data),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    model = gp.read(str(args.mps))
    variables = model.getVars()
    constraints = model.getConstrs()
    matrix = model.getA().tocsr()
    objective = model.getObjective()

    variable_types = Counter(variable.VType for variable in variables)
    logical_binaries = {
        i for i, variable in enumerate(variables)
        if variable.VType in (gp.GRB.BINARY, gp.GRB.INTEGER)
        and variable.LB == 0 and variable.UB == 1
    }
    constraint_senses = Counter(constraint.Sense for constraint in constraints)
    lower_categories = Counter()
    upper_categories = Counter()
    for variable in variables:
        lower_categories["minus_infinity" if variable.LB <= -gp.GRB.INFINITY else
                         "zero" if variable.LB == 0 else "finite_nonzero"] += 1
        upper_categories["plus_infinity" if variable.UB >= gp.GRB.INFINITY else
                         "zero" if variable.UB == 0 else "one" if variable.UB == 1 else
                         "finite_other"] += 1

    row_nnz = [int(matrix.indptr[i + 1] - matrix.indptr[i]) for i in range(matrix.shape[0])]
    csc = matrix.tocsc()
    column_nnz = [int(csc.indptr[i + 1] - csc.indptr[i]) for i in range(matrix.shape[1])]
    coefficients = matrix.data.tolist()
    abs_nonzero = [abs(value) for value in coefficients if value]
    obj_coefficients = [variable.Obj for variable in variables]
    obj_nonzero = [value for value in obj_coefficients if value]
    rhs = [constraint.RHS for constraint in constraints]

    set_partitioning_rows = []
    for row in range(matrix.shape[0]):
        if constraints[row].Sense != "=" or constraints[row].RHS != 1:
            continue
        start, end = matrix.indptr[row], matrix.indptr[row + 1]
        indices = matrix.indices[start:end]
        values = matrix.data[start:end]
        if len(indices) > 0 and all(index in logical_binaries for index in indices) and all(value == 1 for value in values):
            set_partitioning_rows.append({"name": constraints[row].ConstrName, "nonzeros": len(indices)})

    result = {
        "evidence_level": "Gurobi 13 read-only parse of the original MPS; optimize() and presolve() were not called",
        "input": {
            "path": str(args.mps.as_posix()),
            "sha256": sha256(args.mps),
            "uncompressed_sha256": sha256(args.mps, decompress=True),
        },
        "reader": {
            "gurobi_version": list(gp.gurobi.version()),
            "platform": gp.gurobi.platform(),
            "model_name": model.ModelName,
            "model_sense": "minimize" if model.ModelSense == gp.GRB.MINIMIZE else "maximize",
            "fingerprint": getattr(model, "Fingerprint", None),
            "optimize_called": False,
            "presolve_called": False,
        },
        "dimensions": {
            "variables": model.NumVars,
            "linear_constraints": model.NumConstrs,
            "linear_nonzeros": model.NumNZs,
            "quadratic_constraints": model.NumQConstrs,
            "sos_constraints": model.NumSOS,
            "general_constraints": model.NumGenConstrs,
        },
        "variables": {
            "type_counts": dict(sorted(variable_types.items())),
            "logical_binary_count_integer_or_binary_lb0_ub1": len(logical_binaries),
            "lower_bound_categories": dict(sorted(lower_categories.items())),
            "upper_bound_categories": dict(sorted(upper_categories.items())),
            "column_nonzeros": numeric_summary(column_nnz),
        },
        "constraints": {
            "sense_counts": dict(sorted(constraint_senses.items())),
            "row_nonzeros": numeric_summary(row_nnz),
            "rhs": numeric_summary(rhs),
            "set_partitioning_rows_all_integral_lb0_ub1_unit_coeff_rhs_one": {
                "count": len(set_partitioning_rows),
                "nonzero_histogram": dict(sorted(Counter(str(row["nonzeros"]) for row in set_partitioning_rows).items())),
                "first": set_partitioning_rows[:3],
                "last": set_partitioning_rows[-3:],
            },
        },
        "coefficients": {
            "matrix_absolute_nonzero": numeric_summary(abs_nonzero),
            "objective": numeric_summary(obj_coefficients),
            "objective_nonzero_count": len(obj_nonzero),
            "objective_positive_count": sum(value > 0 for value in obj_nonzero),
            "objective_negative_count": sum(value < 0 for value in obj_nonzero),
            "objective_constant": float(objective.getConstant()),
        },
        "names": {
            "first_variables": [variable.VarName for variable in variables[:5]],
            "last_variables": [variable.VarName for variable in variables[-5:]],
            "first_constraints": [constraint.ConstrName for constraint in constraints[:5]],
            "last_constraints": [constraint.ConstrName for constraint in constraints[-5:]],
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({
        "output": str(args.output),
        "gurobi_version": result["reader"]["gurobi_version"],
        "dimensions": result["dimensions"],
        "set_partitioning_rows": len(set_partitioning_rows),
    }, indent=2))


if __name__ == "__main__":
    main()
