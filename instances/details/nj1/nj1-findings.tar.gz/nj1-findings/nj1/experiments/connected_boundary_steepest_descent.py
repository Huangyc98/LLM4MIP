#!/usr/bin/env python3
"""Improve an audited nj assignment by exact connected one-node moves.

At every iteration the script examines every move of one boundary node to an
adjacent district.  A move is eligible only when both affected districts stay
connected and both exact integer populations remain inside the original MPS
bounds.  Among all improving moves it applies the one with the largest exact
objective decrease, with deterministic node/district tie breaking.

The output is an assignment certificate.  It must still be lifted and checked
against each complete original MPS with ``build_and_check_nj_solution.py``.
"""

from __future__ import annotations

import argparse
import json
import sys
from decimal import Decimal
from pathlib import Path


THIS = Path(__file__).resolve()
sys.path.insert(0, str(THIS.parent))
from nj_block_forensics import numeric_suffix, parse_mps, sha256  # noqa: E402


NODES = 595
DISTRICTS = 12
EDGES = 1574
LOWER_POPULATION = 696_025
UPPER_POPULATION = 769_290


def cname(index: int) -> str:
    return f"C{index:04d}"


def rname(index: int) -> str:
    return f"R{index:04d}"


def extract_graph(mps: Path) -> tuple[list[int], list[tuple[int, int, Decimal]]]:
    """Decode the exact common nj graph, populations, and boundary weights."""
    model = parse_mps(mps)
    if len(model["variables"]) != 78_084 or len(model["rows"]) - 1 != 97_579:
        raise ValueError("graph extraction expects the audited original nj1 MPS")

    populations = []
    for node in range(NODES):
        row = rname(90_440 + DISTRICTS * node)
        assignment = cname(63_805 + DISTRICTS * node)
        coefficients = [
            value for variable, value in model["rows"][row]["terms"]
            if variable == assignment
        ]
        populations.append(int(-coefficients[0]) if coefficients else 0)

    objective_rows = [row for row, info in model["rows"].items() if info["sense"] == "N"]
    if len(objective_rows) != 1:
        raise ValueError(f"unexpected objective rows: {objective_rows}")
    objective_row = objective_rows[0]
    objective_by_variable = dict(model["rows"][objective_row]["terms"])

    edges = []
    for edge in range(EDGES):
        row = rname(596 + DISTRICTS * edge)
        endpoints = [
            (numeric_suffix(variable) - 63_805) // DISTRICTS
            for variable, _ in model["rows"][row]["terms"]
            if 63_805 <= numeric_suffix(variable) < 63_805 + NODES * DISTRICTS
        ]
        if len(endpoints) != 2 or endpoints[0] == endpoints[1]:
            raise ValueError(f"cannot decode edge {edge} from {row}: {endpoints}")
        costs = [objective_by_variable[cname(1 + DISTRICTS * edge + district)]
                 for district in range(DISTRICTS)]
        if len(set(costs)) != 1 or costs[0] <= 0:
            raise ValueError(f"nonuniform boundary costs for edge {edge}: {costs}")
        edges.append((endpoints[0], endpoints[1], costs[0]))
    return populations, edges


def component(assignment: list[int], district: int, adjacency: list[list[int]]) -> set[int]:
    selected = {node for node, label in enumerate(assignment) if label == district}
    if not selected:
        return set()
    seen = {min(selected)}
    queue = list(seen)
    for node in queue:
        for neighbor in adjacency[node]:
            if neighbor in selected and neighbor not in seen:
                seen.add(neighbor)
                queue.append(neighbor)
    return seen


def objective(assignment: list[int], edges: list[tuple[int, int, Decimal]]) -> Decimal:
    # Every geographic cut edge activates one boundary variable in each of its
    # two incident districts, hence the exact factor two.
    return sum((2 * cost for left, right, cost in edges
                if assignment[left] != assignment[right]), Decimal(0))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("initial_assignment", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--max-moves", type=int, default=10_000)
    args = parser.parse_args()

    populations, edges = extract_graph(args.mps)
    adjacency = [[] for _ in range(NODES)]
    weighted_adjacency: list[list[tuple[int, Decimal]]] = [[] for _ in range(NODES)]
    for left, right, cost in edges:
        adjacency[left].append(right)
        adjacency[right].append(left)
        weighted_adjacency[left].append((right, cost))
        weighted_adjacency[right].append((left, cost))

    source = json.loads(args.initial_assignment.read_text(encoding="utf-8"))
    assignment = list(source["assignment_zero_based_district"])
    if len(assignment) != NODES or set(assignment) - set(range(DISTRICTS)):
        raise ValueError("assignment must contain 595 district labels in 0..11")
    for district in range(DISTRICTS):
        if len(component(assignment, district, adjacency)) != assignment.count(district):
            raise ValueError(f"initial district {district} is disconnected")

    district_populations = [
        sum(populations[node] for node, label in enumerate(assignment) if label == district)
        for district in range(DISTRICTS)
    ]
    if any(not LOWER_POPULATION <= value <= UPPER_POPULATION
           for value in district_populations):
        raise ValueError(f"initial population outside bounds: {district_populations}")

    initial_objective = objective(assignment, edges)
    recorded = source.get("boundary_objective_original_units")
    if recorded is not None and Decimal(recorded) != initial_objective:
        raise ValueError(f"initial objective mismatch: JSON={recorded}, decoded={initial_objective}")

    moves = []
    for iteration in range(1, args.max_moves + 1):
        current_objective = objective(assignment, edges)
        best = None
        feasible_moves_examined = 0
        for node in range(NODES):
            old_district = assignment[node]
            destinations = sorted({
                assignment[neighbor] for neighbor in adjacency[node]
                if assignment[neighbor] != old_district
            })
            if not destinations:
                continue
            old_population = district_populations[old_district] - populations[node]
            if not LOWER_POPULATION <= old_population <= UPPER_POPULATION:
                continue

            # Connectivity of the source district is destination-independent.
            trial = assignment.copy()
            trial[node] = -1
            if len(component(trial, old_district, adjacency)) != trial.count(old_district):
                continue

            for new_district in destinations:
                new_population = district_populations[new_district] + populations[node]
                if not LOWER_POPULATION <= new_population <= UPPER_POPULATION:
                    continue
                trial[node] = new_district
                # The destination test is kept explicit even though choosing
                # an adjacent district already makes the added node connected.
                if len(component(trial, new_district, adjacency)) != trial.count(new_district):
                    trial[node] = -1
                    continue
                feasible_moves_examined += 1
                delta = 2 * sum(
                    (cost if new_district != assignment[neighbor] else Decimal(0))
                    - (cost if old_district != assignment[neighbor] else Decimal(0))
                    for neighbor, cost in weighted_adjacency[node]
                )
                candidate = (delta, node, new_district, old_district)
                if delta < 0 and (best is None or candidate < best):
                    best = candidate
                trial[node] = -1

        if best is None:
            terminal_feasible_moves = feasible_moves_examined
            break

        delta, node, new_district, old_district = best
        population = populations[node]
        assignment[node] = new_district
        district_populations[old_district] -= population
        district_populations[new_district] += population
        new_objective = objective(assignment, edges)
        if new_objective != current_objective + delta:
            raise RuntimeError("incremental objective change disagrees with full recomputation")
        moves.append({
            "iteration": iteration,
            "node_zero_based": node,
            "old_district_zero_based": old_district,
            "new_district_zero_based": new_district,
            "node_population": population,
            "objective_delta": str(delta),
            "objective_after": str(new_objective),
            "feasible_moves_examined": feasible_moves_examined,
        })
        print(f"move={iteration} node={node} {old_district}->{new_district} "
              f"delta={delta} objective={new_objective}", flush=True)
    else:
        raise SystemExit(f"hit --max-moves={args.max_moves} before proving local optimality")

    final_objective = objective(assignment, edges)
    component_sizes = []
    for district in range(DISTRICTS):
        selected_count = assignment.count(district)
        connected = component(assignment, district, adjacency)
        if len(connected) != selected_count:
            raise RuntimeError(f"final district {district} is disconnected")
        component_sizes.append(selected_count)

    result = {
        "evidence_level": "deterministic exhaustive exact steepest descent over feasible connected one-node boundary moves; requires original-MPS lift/check",
        "source_mps_sha256": sha256(args.mps),
        "initial_assignment_sha256": sha256(args.initial_assignment),
        "algorithm": "repeat the lexicographically deterministic maximum-decrease one-node move between adjacent districts",
        "population_bounds": [LOWER_POPULATION, UPPER_POPULATION],
        "total_population": sum(populations),
        "initial_boundary_objective_original_units": str(initial_objective),
        "boundary_objective_original_units": str(final_objective),
        "objective_improvement": str(initial_objective - final_objective),
        "moves_applied": len(moves),
        "moves": moves,
        "terminal_feasible_moves_examined": terminal_feasible_moves,
        "strictly_locally_optimal_in_feasible_one_node_boundary_move_neighborhood": True,
        "assignment_zero_based_district": assignment,
        "district_populations": district_populations,
        "district_component_sizes": component_sizes,
        "cut_edges": sum(assignment[left] != assignment[right] for left, right, _ in edges),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8", newline="\n"
    )
    print("IMPROVED_ASSIGNMENT=" + str(args.output))


if __name__ == "__main__":
    main()
