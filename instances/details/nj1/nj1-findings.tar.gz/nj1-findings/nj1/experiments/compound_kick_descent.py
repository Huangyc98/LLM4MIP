#!/usr/bin/env python3
"""Evaluate deterministic compound kicks followed by exact one/two-node descent."""

from __future__ import annotations

import argparse
import json
import multiprocessing as mp
import os
import sys
from decimal import Decimal
from itertools import combinations
from pathlib import Path


HELPER_DIR = Path(os.environ.get("NJ_HELPER_DIR", Path(__file__).resolve().parent))
sys.path.insert(0, str(HELPER_DIR))

from connected_boundary_steepest_descent import (  # noqa: E402
    DISTRICTS,
    LOWER_POPULATION,
    NODES,
    UPPER_POPULATION,
    component,
    extract_graph,
    objective,
)
from nj_block_forensics import sha256  # noqa: E402


CTX = {}


def init_worker(populations, edges, adjacency, incident_edges, base_assignment):
    CTX.update({
        "populations": populations,
        "edges": edges,
        "adjacency": adjacency,
        "incident_edges": incident_edges,
        "base": base_assignment,
    })


def connected(assignment, district, adjacency):
    return len(component(assignment, district, adjacency)) == assignment.count(district)


def pops_for(assignment, populations):
    return [
        sum(populations[node] for node, label in enumerate(assignment) if label == district)
        for district in range(DISTRICTS)
    ]


def feasible_trial(assignment, pops, changes, populations, adjacency):
    affected = set()
    new_pops = pops.copy()
    for node, new in changes.items():
        old = assignment[node]
        if old == new:
            return None
        affected.update((old, new))
        new_pops[old] -= populations[node]
        new_pops[new] += populations[node]
    if any(not LOWER_POPULATION <= new_pops[d] <= UPPER_POPULATION for d in affected):
        return None
    trial = assignment.copy()
    for node, new in changes.items():
        trial[node] = new
    if any(not connected(trial, d, adjacency) for d in affected):
        return None
    return trial, new_pops


def exact_delta(assignment, trial, changes, edges, incident_edges):
    changed_edges = {edge for node in changes for edge in incident_edges[node]}
    delta = Decimal(0)
    for edge in changed_edges:
        left, right, cost = edges[edge]
        delta += 2 * cost * (
            int(trial[left] != trial[right]) - int(assignment[left] != assignment[right])
        )
    return delta


def small_descent(start, max_moves=100):
    populations = CTX["populations"]
    edges = CTX["edges"]
    adjacency = CTX["adjacency"]
    incident_edges = CTX["incident_edges"]
    assignment = start.copy()
    pops = pops_for(assignment, populations)
    trace = []

    for iteration in range(1, max_moves + 1):
        current = objective(assignment, edges)
        best = None

        def consider(kind_rank, kind, nodes, new_labels):
            nonlocal best
            changes = dict(zip(nodes, new_labels))
            checked = feasible_trial(
                assignment, pops, changes, populations, adjacency
            )
            if checked is None:
                return
            trial, new_pops = checked
            delta = exact_delta(assignment, trial, changes, edges, incident_edges)
            key = (delta, kind_rank, tuple(nodes), tuple(new_labels))
            if delta < 0 and (best is None or key < best[0]):
                best = (key, trial, new_pops, {
                    "kind": kind,
                    "nodes_zero_based": list(nodes),
                    "old_districts_zero_based": [assignment[node] for node in nodes],
                    "new_districts_zero_based": list(new_labels),
                })

        for node in range(NODES):
            old = assignment[node]
            for new in sorted({assignment[nbr] for nbr in adjacency[node]
                               if assignment[nbr] != old}):
                consider(0, "one_node_transfer", (node,), (new,))

        boundary = [
            node for node in range(NODES)
            if any(assignment[nbr] != assignment[node] for nbr in adjacency[node])
        ]
        for left, right in combinations(boundary, 2):
            ld, rd = assignment[left], assignment[right]
            if ld != rd:
                consider(1, "two_point_exchange", (left, right), (rd, ld))

        for left, right, _ in edges:
            old = assignment[left]
            if assignment[right] != old:
                continue
            destinations = sorted(
                ({assignment[nbr] for nbr in adjacency[left]}
                 | {assignment[nbr] for nbr in adjacency[right]}) - {old}
            )
            for new in destinations:
                consider(2, "adjacent_pair_transfer", (left, right), (new, new))

        if best is None:
            return assignment, trace
        key, assignment, pops, record = best
        record.update({
            "iteration": iteration,
            "objective_before": str(current),
            "objective_delta": str(key[0]),
            "objective_after": str(current + key[0]),
        })
        trace.append(record)
    raise RuntimeError("small descent hit max_moves")


def work(item):
    index, candidate = item
    populations = CTX["populations"]
    edges = CTX["edges"]
    adjacency = CTX["adjacency"]
    incident_edges = CTX["incident_edges"]
    base = CTX["base"]
    base_pops = pops_for(base, populations)
    changes = dict(zip(candidate["nodes_zero_based"], candidate["new_districts_zero_based"]))
    checked = feasible_trial(base, base_pops, changes, populations, adjacency)
    if checked is None:
        return {"candidate_index": index, "error": "kick no longer feasible"}
    kicked, _ = checked
    kick_delta = exact_delta(base, kicked, changes, edges, incident_edges)
    final, trace = small_descent(kicked)
    return {
        "candidate_index": index,
        "kick": candidate,
        "recomputed_kick_delta": str(kick_delta),
        "objective_after_kick": str(objective(kicked, edges)),
        "descent_moves": trace,
        "descent_move_count": len(trace),
        "final_objective": str(objective(final, edges)),
        "final_assignment": final,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("base_assignment", type=Path)
    parser.add_argument("large_scan", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--workers", type=int, default=32)
    parser.add_argument("--candidate-limit", type=int, default=100)
    args = parser.parse_args()

    populations, edges = extract_graph(args.mps)
    adjacency = [[] for _ in range(NODES)]
    incident_edges = [[] for _ in range(NODES)]
    for edge_index, (left, right, _) in enumerate(edges):
        adjacency[left].append(right)
        adjacency[right].append(left)
        incident_edges[left].append(edge_index)
        incident_edges[right].append(edge_index)
    for neighbors in adjacency:
        neighbors.sort()

    base_data = json.loads(args.base_assignment.read_text(encoding="utf-8"))
    base = list(map(int, base_data["assignment_zero_based_district"]))
    scan = json.loads(args.large_scan.read_text(encoding="utf-8"))
    candidates = scan["terminal_scan"]["best_feasible_candidates"][:args.candidate_limit]
    if not candidates:
        raise ValueError("large scan contains no terminal candidates")

    initargs = (populations, edges, adjacency, incident_edges, base)
    with mp.Pool(args.workers, initializer=init_worker, initargs=initargs) as pool:
        results = list(pool.imap_unordered(work, enumerate(candidates), chunksize=1))
    results.sort(key=lambda record: (
        Decimal(record.get("final_objective", "Infinity")), record["candidate_index"]
    ))
    base_objective = objective(base, edges)
    best = results[0]
    output = {
        "schema": "nj-compound-kick-small-descent-v1",
        "source_mps_sha256": sha256(args.mps),
        "base_assignment_sha256": sha256(args.base_assignment),
        "large_scan_sha256": sha256(args.large_scan),
        "base_objective": str(base_objective),
        "candidate_count": len(candidates),
        "workers": args.workers,
        "best_final_objective": best.get("final_objective"),
        "best_improvement": (
            str(base_objective - Decimal(best["final_objective"]))
            if "final_objective" in best else None
        ),
        "best_candidate_index": best["candidate_index"],
        "results": results,
        "assignment_zero_based_district": best.get("final_assignment"),
        "boundary_objective_original_units": best.get("final_objective"),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({key: value for key, value in output.items()
                      if key not in ("results", "assignment_zero_based_district")}, indent=2))


if __name__ == "__main__":
    main()
