#!/usr/bin/env python3
"""Find a population-balanced connected 12-way partition for nj1/nj2.

The compact CP-SAT model keeps only assignment/root/cut-edge variables.  Graph
connectivity is enforced by an exact outer loop: after every integer solution,
components not containing the chosen root receive valid node-to-boundary cuts.
The output is an assignment certificate, not yet an original-MPS solution; use
``build_and_check_nj_solution.py`` for the exact lift and independent check.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from collections import deque
from decimal import Decimal
from pathlib import Path

from ortools.sat.python import cp_model


THIS = Path(__file__).resolve()
sys.path.insert(0, str(THIS.parent))
from nj_block_forensics import numeric_suffix, parse_mps, sha256  # noqa: E402


NODES = 595
DISTRICTS = 12
EDGES = 1574
LOWER_POPULATION = 696_025
UPPER_POPULATION = 769_290


def extract_graph(mps: Path) -> tuple[list[int], list[tuple[int, int, Decimal]]]:
    model = parse_mps(mps)
    populations = []
    for node in range(NODES):
        row = f"R{90440 + 12 * node:04d}"
        assignment = f"C{63805 + 12 * node:04d}"
        coefficient = [value for variable, value in model["rows"][row]["terms"] if variable == assignment]
        populations.append(int(-coefficient[0]) if coefficient else 0)

    edges = []
    for edge in range(EDGES):
        row = f"R{596 + 12 * edge:04d}"
        endpoints = [
            (numeric_suffix(variable) - 63805) // 12
            for variable, _ in model["rows"][row]["terms"]
            if 63805 <= numeric_suffix(variable) <= 70944
        ]
        if len(endpoints) != 2 or endpoints[0] == endpoints[1]:
            raise ValueError(f"cannot decode edge {edge} from {row}: {endpoints}")
        objective_variable = f"C{1 + 12 * edge:04d}"
        costs = [
            value for objective_row, value in model["variables"][objective_variable]["rows"]
            if model["rows"][objective_row]["sense"] == "N"
        ]
        if len(costs) != 1:
            raise ValueError(f"cannot decode objective for edge {edge}: {costs}")
        edges.append((endpoints[0], endpoints[1], costs[0]))
    return populations, edges


def components(assignment: list[int], district: int, adjacency: list[list[int]]) -> list[list[int]]:
    remaining = {node for node, value in enumerate(assignment) if value == district}
    result = []
    while remaining:
        start = min(remaining)
        remaining.remove(start)
        queue = deque([start])
        component = []
        while queue:
            node = queue.popleft()
            component.append(node)
            for neighbor in adjacency[node]:
                if neighbor in remaining:
                    remaining.remove(neighbor)
                    queue.append(neighbor)
        result.append(sorted(component))
    return sorted(result, key=lambda item: (-len(item), item[0]))


def farthest_seeds(adjacency: list[list[int]], start: int) -> list[int]:
    """Deterministic unweighted farthest-point sampling on the connected graph."""
    seeds = [start]
    minimum_distance = [NODES + 1] * NODES
    while len(seeds) < DISTRICTS:
        distance = [-1] * NODES
        distance[seeds[-1]] = 0
        queue = deque([seeds[-1]])
        while queue:
            node = queue.popleft()
            for neighbor in adjacency[node]:
                if distance[neighbor] < 0:
                    distance[neighbor] = distance[node] + 1
                    queue.append(neighbor)
        if min(distance) < 0:
            raise ValueError("input graph is disconnected")
        minimum_distance = [min(old, new) for old, new in zip(minimum_distance, distance)]
        candidates = [node for node, value in enumerate(minimum_distance)
                      if value == max(minimum_distance) and node not in seeds]
        seeds.append(min(candidates))
    return seeds


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--progress", type=Path)
    parser.add_argument("--rounds", type=int, default=40)
    parser.add_argument("--time-per-round", type=float, default=120.0)
    parser.add_argument("--workers", type=int, default=32)
    parser.add_argument("--seed", type=int, default=20260908)
    parser.add_argument("--cost-scale", type=int, default=1_000_000)
    parser.add_argument("--log-search-progress", action="store_true")
    parser.add_argument("--farthest-seed-start", type=int,
                        help="fix one district seed each using farthest-point sampling from this node")
    args = parser.parse_args()

    populations, edges = extract_graph(args.mps)
    if sum(populations) != 8_791_894:
        raise ValueError(f"unexpected total population {sum(populations)}")
    adjacency = [[] for _ in range(NODES)]
    for left, right, _ in edges:
        adjacency[left].append(right)
        adjacency[right].append(left)

    model = cp_model.CpModel()
    x = [[model.new_bool_var(f"x_{node}_{district}") for district in range(DISTRICTS)]
         for node in range(NODES)]
    fixed_roots = None
    root = None
    if args.farthest_seed_start is not None:
        if not 0 <= args.farthest_seed_start < NODES:
            raise ValueError("--farthest-seed-start must be in 0..594")
        fixed_roots = farthest_seeds(adjacency, args.farthest_seed_start)
    else:
        root = [[model.new_bool_var(f"r_{node}_{district}") for district in range(DISTRICTS)]
                for node in range(NODES)]
    cut_edge = [model.new_bool_var(f"cut_{edge}") for edge in range(EDGES)]

    for node in range(NODES):
        model.add_exactly_one(x[node])
    for district in range(DISTRICTS):
        population = sum(populations[node] * x[node][district] for node in range(NODES))
        model.add(population >= LOWER_POPULATION)
        model.add(population <= UPPER_POPULATION)
        if fixed_roots is None:
            assert root is not None
            model.add_exactly_one(root[node][district] for node in range(NODES))
            for node in range(NODES):
                model.add(root[node][district] <= x[node][district])
        else:
            model.add(x[fixed_roots[district]][district] == 1)
    if fixed_roots is None:
        # Any unlabeled partition can be relabeled in this nondecreasing order.
        district_scores = [sum((node + 1) * x[node][district] for node in range(NODES))
                           for district in range(DISTRICTS)]
        for district in range(DISTRICTS - 1):
            model.add(district_scores[district] <= district_scores[district + 1])

    for edge, (left, right, _) in enumerate(edges):
        for district in range(DISTRICTS):
            model.add(cut_edge[edge] >= x[left][district] - x[right][district])
            model.add(cut_edge[edge] >= x[right][district] - x[left][district])
    scaled_costs = [max(1, int((cost * args.cost_scale).to_integral_value())) for _, _, cost in edges]
    model.minimize(sum(scaled_costs[edge] * cut_edge[edge] for edge in range(EDGES)))

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = args.time_per_round
    solver.parameters.num_search_workers = args.workers
    solver.parameters.random_seed = args.seed
    solver.parameters.log_search_progress = args.log_search_progress
    solver.parameters.cp_model_presolve = True

    history = []
    cuts_added = 0
    started = time.time()
    for round_index in range(1, args.rounds + 1):
        status = solver.solve(model)
        record = {
            "round": round_index,
            "status": solver.status_name(status),
            "wall_time": solver.wall_time,
            "cumulative_wall_time": time.time() - started,
            "cuts_before_round": cuts_added,
        }
        if status not in (cp_model.FEASIBLE, cp_model.OPTIMAL):
            history.append(record)
            break
        assignment = [next(district for district in range(DISTRICTS)
                           if solver.boolean_value(x[node][district])) for node in range(NODES)]
        if fixed_roots is None:
            assert root is not None
            roots = [next(node for node in range(NODES)
                          if solver.boolean_value(root[node][district])) for district in range(DISTRICTS)]
        else:
            roots = fixed_roots
        populations_by_district = [
            sum(populations[node] for node in range(NODES) if assignment[node] == district)
            for district in range(DISTRICTS)
        ]
        component_lists = [components(assignment, district, adjacency) for district in range(DISTRICTS)]
        record.update({
            "objective_scaled": int(round(solver.objective_value)),
            "best_bound_scaled": float(solver.best_objective_bound),
            "roots": roots,
            "populations": populations_by_district,
            "component_sizes": [[len(component) for component in items] for items in component_lists],
            "assignment_zero_based_district": assignment,
        })
        if all(len(items) == 1 for items in component_lists):
            history.append(record)
            result = {
                "evidence_level": "CP-SAT assignment plus explicit graph-component check; requires original-MPS lift/check",
                "source_mps_sha256": sha256(args.mps),
                "solver": {
                    "name": "OR-Tools CP-SAT",
                    "status_last_round": solver.status_name(status),
                    "workers": args.workers,
                    "seed": args.seed,
                    "cost_scale": args.cost_scale,
                },
                "population_bounds": [LOWER_POPULATION, UPPER_POPULATION],
                "total_population": sum(populations),
                "assignment_zero_based_district": assignment,
                "roots_used_for_separation_zero_based_node": roots,
                "district_populations": populations_by_district,
                "district_component_sizes": [len(items[0]) for items in component_lists],
                "cut_edges": sum(assignment[left] != assignment[right] for left, right, _ in edges),
                "boundary_objective_original_units": str(sum(
                    2 * cost for left, right, cost in edges if assignment[left] != assignment[right]
                )),
                "connectivity_cuts_added": cuts_added,
                "history": history,
            }
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
            print("CONNECTED_ASSIGNMENT=" + str(args.output))
            return

        new_cuts = 0
        for district, items in enumerate(component_lists):
            root_node = roots[district]
            for component in items:
                if root_node in component:
                    continue
                component_set = set(component)
                boundary = sorted({neighbor for node in component for neighbor in adjacency[node]
                                   if neighbor not in component_set})
                if not boundary:
                    raise RuntimeError(f"graph component has no boundary: district={district}, component={component}")
                root_in_component = 0 if fixed_roots is not None else sum(root[node][district] for node in component)
                selected_boundary = sum(x[node][district] for node in boundary)
                for node in component:
                    model.add(x[node][district] <= root_in_component + selected_boundary)
                    new_cuts += 1
        cuts_added += new_cuts
        record["cuts_added_after_round"] = new_cuts
        history.append(record)
        if args.progress:
            args.progress.parent.mkdir(parents=True, exist_ok=True)
            args.progress.write_text(json.dumps({"history": history}, indent=2) + "\n", encoding="utf-8")
        print(f"CONNECTIVITY_ROUND={round_index} NEW_CUTS={new_cuts} TOTAL_CUTS={cuts_added}", flush=True)

    if args.progress:
        args.progress.parent.mkdir(parents=True, exist_ok=True)
        args.progress.write_text(json.dumps({"history": history}, indent=2) + "\n", encoding="utf-8")
    raise SystemExit("no connected assignment found within configured rounds")


if __name__ == "__main__":
    main()
