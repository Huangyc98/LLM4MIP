#!/usr/bin/env python3
"""Replay and consolidate an exact NJ large-neighborhood improvement chain."""

from __future__ import annotations

import argparse
import json
import os
import sys
from decimal import Decimal
from pathlib import Path


HELPER_DIR = Path(os.environ.get("NJ_HELPER_DIR", Path(__file__).resolve().parent))
sys.path.insert(0, str(HELPER_DIR))

from connected_boundary_steepest_descent import (  # noqa: E402
    DISTRICTS,
    LOWER_POPULATION,
    NODES,
    UPPER_POPULATION,
    component,
    extract_graph,
    objective,
)
from nj_block_forensics import sha256  # noqa: E402


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("initial_assignment", type=Path)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    populations, edges = extract_graph(args.mps)
    adjacency = [[] for _ in range(NODES)]
    for left, right, _ in edges:
        adjacency[left].append(right)
        adjacency[right].append(left)
    for neighbors in adjacency:
        neighbors.sort()

    initial = json.loads(args.initial_assignment.read_text(encoding="utf-8"))
    assignment = list(map(int, initial["assignment_zero_based_district"]))
    if len(assignment) != NODES:
        raise ValueError("bad initial assignment length")
    initial_objective = objective(assignment, edges)
    manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
    trace = []
    stage_records = []

    def check_state(expected=None):
        value = objective(assignment, edges)
        if expected is not None and value != Decimal(str(expected)):
            raise AssertionError(f"objective {value} != expected {expected}")
        pops = [
            sum(populations[n] for n, label in enumerate(assignment) if label == d)
            for d in range(DISTRICTS)
        ]
        assert all(LOWER_POPULATION <= pop <= UPPER_POPULATION for pop in pops)
        for district in range(DISTRICTS):
            assert len(component(assignment, district, adjacency)) == assignment.count(district)
        return value, pops

    def apply_record(record, stage_index, role):
        before = objective(assignment, edges)
        if "objective_before" in record:
            assert before == Decimal(str(record["objective_before"]))
        nodes = list(map(int, record["nodes_zero_based"]))
        old_labels = list(map(int, record["old_districts_zero_based"]))
        new_labels = list(map(int, record["new_districts_zero_based"]))
        assert len(nodes) == len(set(nodes)) == len(old_labels) == len(new_labels)
        assert [assignment[node] for node in nodes] == old_labels
        for node, new in zip(nodes, new_labels):
            assignment[node] = new
        after, _ = check_state(record["objective_after"])
        delta = after - before
        assert delta == Decimal(str(record["objective_delta"]))
        trace.append({
            "global_step": len(trace) + 1,
            "stage_index": stage_index,
            "role": role,
            "kind": record["kind"],
            "nodes_zero_based": nodes,
            "old_districts_zero_based": old_labels,
            "new_districts_zero_based": new_labels,
            "node_populations": [populations[node] for node in nodes],
            "objective_before": str(before),
            "objective_delta": str(delta),
            "objective_after": str(after),
        })

    check_state(initial_objective)
    root = args.manifest.resolve().parent
    for stage_index, spec in enumerate(manifest["stages"], 1):
        path = (root / spec["path"]).resolve()
        data = json.loads(path.read_text(encoding="utf-8"))
        before = objective(assignment, edges)
        kind = spec["kind"]
        if kind in ("large", "small"):
            for record in data["moves"]:
                apply_record(record, stage_index, kind)
            expected_assignment = data["assignment_zero_based_district"]
            expected_objective = data["boundary_objective_original_units"]
        elif kind == "kick":
            chosen = data["results"][int(spec.get("result_index", 0))]
            apply_record(chosen["kick"], stage_index, "kick")
            for record in chosen["descent_moves"]:
                apply_record(record, stage_index, "small_after_kick")
            expected_assignment = chosen["final_assignment"]
            expected_objective = chosen["final_objective"]
        elif kind == "terminal_large":
            assert data["moves_applied"] == 0
            assert Decimal(data["terminal_scan"]["best_feasible_candidates"][0]["objective_delta"]) >= 0
            expected_assignment = data["assignment_zero_based_district"]
            expected_objective = data["boundary_objective_original_units"]
        elif kind == "terminal_kick":
            assert Decimal(data["best_improvement"]) == 0
            expected_assignment = data["assignment_zero_based_district"]
            expected_objective = data["boundary_objective_original_units"]
        else:
            raise ValueError(f"unknown stage kind {kind}")
        assert assignment == list(map(int, expected_assignment))
        after, _ = check_state(expected_objective)
        stage_records.append({
            "stage_index": stage_index,
            "kind": kind,
            "path": spec["path"],
            "sha256": sha256(path),
            "objective_before": str(before),
            "objective_after": str(after),
            "cumulative_move_count": len(trace),
            **({"candidate_count": data["candidate_count"]} if kind == "terminal_kick" else {}),
        })

    final_objective, pops = check_state(manifest["expected_final_objective"])
    result = {
        "schema": "nj-exact-large-neighborhood-chain-v1",
        "evidence_level": "exact replay of every accepted compound kick and descent move, with population/connectivity/objective checks after every step; original-MPS lift still required",
        "source_mps_sha256": sha256(args.mps),
        "initial_assignment_sha256": sha256(args.initial_assignment),
        "manifest_sha256": sha256(args.manifest),
        "initial_boundary_objective_original_units": str(initial_objective),
        "boundary_objective_original_units": str(final_objective),
        "objective_improvement": str(initial_objective - final_objective),
        "accepted_move_count_including_kicks": len(trace),
        "stages": stage_records,
        "moves": trace,
        "terminal_compound_kicks_fully_descended": manifest["terminal_compound_kicks_fully_descended"],
        "assignment_zero_based_district": assignment,
        "district_populations": pops,
        "district_component_sizes": [assignment.count(d) for d in range(DISTRICTS)],
        "cut_edges": sum(assignment[left] != assignment[right] for left, right, _ in edges),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({key: value for key, value in result.items()
                      if key not in ("moves", "assignment_zero_based_district")}, indent=2))


if __name__ == "__main__":
    main()
