#!/usr/bin/env python3
"""Run COPT 8 on an original nj MPS from a complete sparse .sol warm start."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import coptpy as cp


def safe_attr(model, *names):
    for name in names:
        try:
            return getattr(model, name)
        except Exception:
            pass
    return None


def read_solution(path: Path) -> dict[str, float]:
    values = {}
    with path.open(encoding="utf-8") as handle:
        for raw in handle:
            tokens = raw.split()
            if len(tokens) < 2 or tokens[0].startswith(("#", "=")):
                continue
            try:
                values[tokens[0]] = float(tokens[1])
            except ValueError:
                continue
    return values


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("warm_start", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("result_json", type=Path)
    parser.add_argument("--time-limit", type=float, default=300)
    parser.add_argument("--threads", type=int, default=32)
    args = parser.parse_args()

    env = cp.Envr()
    model = env.createModel("nj-warmstart")
    model.read(str(args.mps))
    sparse = read_solution(args.warm_start)
    variables = model.getVars()
    names = [variable.name for variable in variables]
    unknown = sorted(set(sparse) - set(names))
    if unknown:
        raise ValueError(f"warm start has unknown variables: {unknown[:20]}")
    model.setMipStart(variables, [sparse.get(name, 0.0) for name in names])
    model.loadMipStart()
    model.setParam(cp.COPT.Param.TimeLimit, args.time_limit)
    model.setParam(cp.COPT.Param.Threads, args.threads)
    try:
        model.setParam(cp.COPT.Param.RelGap, 0.0)
    except Exception:
        pass
    model.solve()
    has_solution = bool(safe_attr(model, "hasmipsol", "HasMipSol"))
    if has_solution:
        args.solution.parent.mkdir(parents=True, exist_ok=True)
        model.write(str(args.solution))
    result = {
        "solver": "COPT",
        "version": [cp.COPT.VERSION_MAJOR, cp.COPT.VERSION_MINOR, cp.COPT.VERSION_TECHNICAL],
        "model": str(args.mps),
        "warm_start": str(args.warm_start),
        "warm_start_values_supplied": len(names),
        "time_limit": args.time_limit,
        "threads": args.threads,
        "status": str(safe_attr(model, "status", "Status")),
        "has_mip_solution": has_solution,
        "objective": str(safe_attr(model, "objval", "ObjVal")),
        "best_bound": str(safe_attr(model, "bestbnd", "BestBnd")),
        "node_count": str(safe_attr(model, "nodecnt", "NodeCnt")),
        "solution": str(args.solution) if has_solution else None,
    }
    args.result_json.parent.mkdir(parents=True, exist_ok=True)
    args.result_json.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print("RESULT_JSON=" + json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
