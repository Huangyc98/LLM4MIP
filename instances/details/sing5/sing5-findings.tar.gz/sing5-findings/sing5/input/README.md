# Input provenance

The original model is not duplicated in Git. Download
[`sing5.mps.gz`](https://miplib.zib.de/WebData/instances/sing5.mps.gz) from
MIPLIB and save it in this directory before rerunning the scripts. The expected
SHA-256 is recorded in `SHA256SUMS`.

`sing5.dec` is the official original-model decomposition from
<https://miplib.zib.de/WebData/decomps_orig/sing5.dec>. The two compressed
solution files are the 2019 public incumbent and the 2018 selection solution
downloaded from the MIPLIB `sing5` page.
