from __future__ import annotations

import argparse
from collections import defaultdict
import json
from pathlib import Path
import time

import gurobipy as gp
from gurobipy import GRB

from run_block_lns import audit, read_decomposition, read_solution, write_sparse_solution


def parse_groups(specification: str) -> list[list[int]]:
    groups: list[list[int]] = []
    for raw_group in specification.split(";"):
        group = sorted({int(item) for item in raw_group.split(",") if item.strip()})
        if group:
            groups.append(group)
    if not groups:
        raise ValueError("at least one group is required")
    return groups


def main() -> None:
    parser = argparse.ArgumentParser(description="Multi-block LNS on official MIPLIB .dec blocks.")
    parser.add_argument("mps", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("decomposition", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("log_dir", type=Path)
    parser.add_argument("best_solution", type=Path)
    parser.add_argument("--groups", required=True, help="Semicolon-separated groups, e.g. 10,11,12;7,8")
    parser.add_argument("--time-per-group", type=float, default=120.0)
    parser.add_argument("--threads", type=int, default=2)
    parser.add_argument("--seed", type=int, default=5700)
    args = parser.parse_args()

    groups = parse_groups(args.groups)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.log_dir.mkdir(parents=True, exist_ok=True)
    args.best_solution.parent.mkdir(parents=True, exist_ok=True)
    started = time.time()

    model = gp.read(str(args.mps))
    variables = model.getVars()
    constraints = {constraint.ConstrName: constraint for constraint in model.getConstrs()}
    incumbent, solution_info = read_solution(model, args.solution)
    initial_audit = audit(model, incumbent)
    original_lbs = [variable.LB for variable in variables]
    original_ubs = [variable.UB for variable in variables]

    block_count, block_rows, master_rows = read_decomposition(args.decomposition)
    requested = set().union(*(set(group) for group in groups))
    invalid = sorted(requested - set(range(1, block_count + 1)))
    if invalid:
        raise ValueError(f"invalid block numbers: {invalid}")
    block_variables: dict[int, set[int]] = defaultdict(set)
    for block, row_names in block_rows.items():
        for row_name in row_names:
            row = model.getRow(constraints[row_name])
            block_variables[block].update(row.getVar(position).index for position in range(row.size()))
    master_variables: set[int] = set()
    for row_name in master_rows:
        row = model.getRow(constraints[row_name])
        master_variables.update(row.getVar(position).index for position in range(row.size()))
    all_block_variables = set().union(*block_variables.values())
    master_only = master_variables - all_block_variables

    for variable, value in zip(variables, incumbent):
        variable.LB = value
        variable.UB = value
        variable.Start = value
    model.update()

    best_objective = initial_audit["objective"]
    records: list[dict] = []
    for sequence, group in enumerate(groups, start=1):
        free = master_only | set().union(*(block_variables[block] for block in group))
        for index in free:
            variables[index].LB = original_lbs[index]
            variables[index].UB = original_ubs[index]
            variables[index].Start = incumbent[index]
        model.update()
        model.reset(0)
        label = "-".join(f"{block:02d}" for block in group)
        model.Params.OutputFlag = 1
        model.Params.LogFile = str(args.log_dir / f"sing5-group-{label}.log")
        model.Params.TimeLimit = args.time_per_group
        model.Params.Threads = args.threads
        model.Params.Seed = args.seed + sequence
        model.Params.MIPFocus = 1
        model.Params.Presolve = 2
        model.Params.Aggregate = 2
        model.Params.PreSparsify = 2
        model.Params.Symmetry = 2
        model.Params.Cuts = 2
        model.Params.Heuristics = 0.2
        model.Params.MIPGap = 0.0
        model.Params.MIPGapAbs = 0.0
        group_started = time.time()
        model.optimize()
        objective = float(model.ObjVal) if model.SolCount else None
        improved = objective is not None and objective < best_objective - 1e-6
        if improved:
            incumbent = [float(variable.X) for variable in variables]
            best_objective = objective
            write_sparse_solution(model, incumbent, args.best_solution)
        records.append({
            "sequence": sequence,
            "blocks": group,
            "block_rows": sum(len(block_rows[block]) for block in group),
            "free_variables": len(free),
            "status": int(model.Status),
            "status_name": {
                GRB.OPTIMAL: "OPTIMAL",
                GRB.TIME_LIMIT: "TIME_LIMIT",
            }.get(model.Status, str(model.Status)),
            "solutions": int(model.SolCount),
            "objective": objective,
            "bound": float(model.ObjBound),
            "gap": float(model.MIPGap) if model.SolCount else None,
            "zero_gap_certificate": bool(
                model.Status == GRB.OPTIMAL and model.SolCount
                and abs(float(model.ObjVal) - float(model.ObjBound)) <= 1e-6
            ),
            "nodes": float(model.NodeCount),
            "runtime_seconds": float(model.Runtime),
            "wall_seconds": time.time() - group_started,
            "improved": improved,
        })
        for index in free:
            variables[index].LB = incumbent[index]
            variables[index].UB = incumbent[index]
            variables[index].Start = incumbent[index]
        model.update()

        checkpoint = {
            "instance": model.ModelName,
            "method": "official .dec multi-block LNS; complement fixed to current incumbent",
            "solution": solution_info,
            "initial_audit": initial_audit,
            "decomposition": {
                "blocks": block_count,
                "master_rows": len(master_rows),
                "master_only_variables": len(master_only),
            },
            "parameters": {
                "mps": str(args.mps),
                "solution": str(args.solution),
                "decomposition": str(args.decomposition),
                "groups": groups,
                "time_per_group": args.time_per_group,
                "threads": args.threads,
                "seed": args.seed,
                "mip_gap": 0.0,
                "mip_gap_abs": 0.0,
            },
            "best_objective": best_objective,
            "objective_improvement": initial_audit["objective"] - best_objective,
            "records": records,
            "wall_seconds": time.time() - started,
        }
        args.output.write_text(json.dumps(checkpoint, indent=2) + "\n", encoding="utf-8")

    checkpoint["final_audit"] = audit(model, incumbent)
    checkpoint["wall_seconds"] = time.time() - started
    args.output.write_text(json.dumps(checkpoint, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(checkpoint, indent=2))


if __name__ == "__main__":
    main()
