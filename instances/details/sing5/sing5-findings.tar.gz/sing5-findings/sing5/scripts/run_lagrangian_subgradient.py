from __future__ import annotations

import argparse
from collections import defaultdict
import json
import math
from pathlib import Path
import time

import gurobipy as gp
from gurobipy import GRB

from run_block_lns import read_decomposition, read_solution


def log_line(path: Path, message: str) -> None:
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {message}"
    print(line, flush=True)
    with path.open("a", encoding="utf-8") as stream:
        stream.write(line + "\n")


def make_block_model(
    original: gp.Model,
    block: int,
    row_names: list[str],
    global_indices: list[int],
    constraints: dict[str, gp.Constr],
    seed: int,
    time_limit: float,
) -> tuple[gp.Model, list[gp.Var], dict[int, int]]:
    original_variables = original.getVars()
    local_of_global = {global_index: local for local, global_index in enumerate(global_indices)}
    subproblem = gp.Model(f"sing5-block-{block}")
    subproblem.Params.OutputFlag = 0
    subproblem_variables = subproblem.addVars(
        len(global_indices),
        lb=[original_variables[index].LB for index in global_indices],
        ub=[original_variables[index].UB for index in global_indices],
        vtype=[original_variables[index].VType for index in global_indices],
        name=[original_variables[index].VarName for index in global_indices],
    )
    local_variables = [subproblem_variables[index] for index in range(len(global_indices))]
    for row_name in row_names:
        original_row = original.getRow(constraints[row_name])
        expression = gp.LinExpr()
        for position in range(original_row.size()):
            global_index = original_row.getVar(position).index
            expression.add(local_variables[local_of_global[global_index]], original_row.getCoeff(position))
        constraint = constraints[row_name]
        subproblem.addLConstr(expression, constraint.Sense, constraint.RHS, name=row_name)
    subproblem.Params.Threads = 1
    subproblem.Params.Seed = seed + block
    subproblem.Params.TimeLimit = time_limit
    subproblem.Params.MIPGap = 0.0
    subproblem.Params.MIPGapAbs = 0.0
    subproblem.Params.Presolve = 2
    subproblem.Params.Aggregate = 2
    subproblem.Params.PreSparsify = 2
    subproblem.Params.Cuts = 2
    subproblem.Params.MIPFocus = 3
    subproblem.Params.Heuristics = 0.05
    subproblem.update()
    return subproblem, local_variables, local_of_global


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Maximize the integer Lagrangian dual by Polyak subgradient steps."
    )
    parser.add_argument("mps", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("decomposition", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("log", type=Path)
    parser.add_argument("--iterations", type=int, default=15)
    parser.add_argument("--time-per-block", type=float, default=30.0)
    parser.add_argument("--threads-lp", type=int, default=2)
    parser.add_argument("--seed", type=int, default=5900)
    parser.add_argument("--theta", type=float, default=1.5)
    parser.add_argument("--stagnation", type=int, default=4)
    parser.add_argument(
        "--fixed-step",
        type=float,
        help="Use fixed_step/sqrt(k+1) instead of a Polyak step.",
    )
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.log.parent.mkdir(parents=True, exist_ok=True)
    args.log.write_text("", encoding="utf-8")
    started = time.time()
    model = gp.read(str(args.mps))
    variables = model.getVars()
    constraints = {constraint.ConstrName: constraint for constraint in model.getConstrs()}
    incumbent, solution_info = read_solution(model, args.solution)
    upper_bound = solution_info["recomputed_objective"]
    block_count, block_rows, master_names = read_decomposition(args.decomposition)

    # Recover the official block partition and the coefficients of dualized rows.
    block_variables: dict[int, set[int]] = defaultdict(set)
    for block, names in block_rows.items():
        for name in names:
            row = model.getRow(constraints[name])
            block_variables[block].update(row.getVar(position).index for position in range(row.size()))
    all_block_variables = set().union(*block_variables.values())
    master_rows = sorted((constraints[name] for name in master_names), key=lambda row: int(row.ConstrName[1:]))
    master_index = {row.ConstrName: index for index, row in enumerate(master_rows)}
    master_terms: list[list[tuple[int, float]]] = [[] for _ in variables]
    master_variables: set[int] = set()
    for row in master_rows:
        row_index = master_index[row.ConstrName]
        expression = model.getRow(row)
        for position in range(expression.size()):
            variable_index = expression.getVar(position).index
            coefficient = expression.getCoeff(position)
            master_terms[variable_index].append((row_index, coefficient))
            master_variables.add(variable_index)
    master_only = sorted(master_variables - all_block_variables)

    # LP dual multipliers provide a validated starting point for the concave dual.
    relaxation = model.relax()
    relaxation.Params.OutputFlag = 0
    relaxation.Params.Threads = args.threads_lp
    relaxation.Params.Method = 1
    relaxation.Params.Presolve = 2
    relaxation.Params.NumericFocus = 2
    relaxation.Params.OptimalityTol = 1e-9
    relaxation.Params.FeasibilityTol = 1e-9
    relaxation.optimize()
    if relaxation.Status != GRB.OPTIMAL:
        raise RuntimeError(f"LP relaxation status {relaxation.Status}")
    multipliers = [float(relaxation.getConstrByName(row.ConstrName).Pi) for row in master_rows]
    senses = [row.Sense for row in master_rows]
    right_hand_sides = [float(row.RHS) for row in master_rows]
    if any(sense == GRB.GREATER_EQUAL and value < -1e-7 for sense, value in zip(senses, multipliers)):
        raise RuntimeError("unexpected sign in LP dual multipliers")

    # Each load-shedding variable is nonnegative and unbounded above.  Its reduced
    # cost gives a simple half-space needed to keep every Lagrangian subproblem bounded.
    unbounded_master_only = [
        index for index in master_only
        if math.isinf(variables[index].UB) and variables[index].LB == 0.0
    ]

    block_models: dict[int, tuple[gp.Model, list[gp.Var], list[int]]] = {}
    log_line(args.log, f"building {block_count} independent block models")
    for block in range(1, block_count + 1):
        global_indices = sorted(block_variables[block])
        subproblem, local_variables, _ = make_block_model(
            model, block, block_rows[block], global_indices, constraints,
            args.seed, args.time_per_block,
        )
        for local, global_index in enumerate(global_indices):
            local_variables[local].Start = incumbent[global_index]
        block_models[block] = (subproblem, local_variables, global_indices)
    log_line(args.log, f"block models ready after {time.time() - started:.2f}s")

    records: list[dict] = []
    best_bound = -math.inf
    best_multipliers = list(multipliers)
    theta = args.theta
    iterations_without_improvement = 0

    for iteration in range(args.iterations + 1):
        iteration_started = time.time()
        lagrangian_constant = model.ObjCon + math.fsum(
            multiplier * rhs for multiplier, rhs in zip(multipliers, right_hand_sides)
        )
        chosen_values = [0.0] * len(variables)
        sum_objectives = 0.0
        sum_bounds = 0.0
        all_optimal = True
        timed_out_blocks: list[int] = []
        total_nodes = 0.0

        for block in range(1, block_count + 1):
            subproblem, local_variables, global_indices = block_models[block]
            objectives = []
            for global_index in global_indices:
                reduced_objective = variables[global_index].Obj - math.fsum(
                    multipliers[row_index] * coefficient
                    for row_index, coefficient in master_terms[global_index]
                )
                objectives.append(reduced_objective)
            subproblem.setAttr(GRB.Attr.Obj, local_variables, objectives)
            subproblem.reset(0)
            subproblem.optimize()
            total_nodes += float(subproblem.NodeCount)
            all_optimal = all_optimal and subproblem.Status == GRB.OPTIMAL
            if subproblem.Status != GRB.OPTIMAL:
                timed_out_blocks.append(block)
            if not subproblem.SolCount:
                raise RuntimeError(f"block {block} has no incumbent at iteration {iteration}")
            sum_objectives += float(subproblem.ObjVal)
            sum_bounds += float(subproblem.ObjBound)
            for local, global_index in enumerate(global_indices):
                value = float(local_variables[local].X)
                chosen_values[global_index] = value
                local_variables[local].Start = value

        master_only_objective = 0.0
        dual_feasible = True
        for global_index in master_only:
            variable = variables[global_index]
            reduced_objective = variable.Obj - math.fsum(
                multipliers[row_index] * coefficient
                for row_index, coefficient in master_terms[global_index]
            )
            if reduced_objective >= -1e-9:
                value = variable.LB
            elif math.isfinite(variable.UB):
                value = variable.UB
            else:
                dual_feasible = False
                value = variable.LB
            chosen_values[global_index] = value
            master_only_objective += reduced_objective * value

        if not dual_feasible:
            raise RuntimeError(f"unbounded Lagrangian point at iteration {iteration}")
        lagrangian_value = lagrangian_constant + sum_objectives + master_only_objective
        valid_bound = lagrangian_constant + sum_bounds + master_only_objective
        activities = [0.0] * len(master_rows)
        for global_index in master_variables:
            value = chosen_values[global_index]
            for row_index, coefficient in master_terms[global_index]:
                activities[row_index] += coefficient * value
        residuals = [rhs - activity for rhs, activity in zip(right_hand_sides, activities)]
        subgradient_norm_squared = math.fsum(value * value for value in residuals)
        max_residual = max(abs(value) for value in residuals)

        improved = valid_bound > best_bound + 1e-5
        if improved:
            best_bound = valid_bound
            best_multipliers = list(multipliers)
            iterations_without_improvement = 0
        else:
            iterations_without_improvement += 1
            if iterations_without_improvement >= args.stagnation:
                theta *= 0.5
                iterations_without_improvement = 0

        step = 0.0
        if subgradient_norm_squared > 0.0:
            if args.fixed_step is not None:
                step = args.fixed_step / math.sqrt(iteration + 1.0)
            else:
                reference = min(upper_bound, max(valid_bound, lagrangian_value))
                step = theta * max(0.0, upper_bound - reference) / subgradient_norm_squared
        records.append({
            "iteration": iteration,
            "all_blocks_optimal": all_optimal,
            "timed_out_blocks": timed_out_blocks,
            "lagrangian_incumbent_value": lagrangian_value,
            "valid_global_lower_bound": valid_bound,
            "best_valid_global_lower_bound": best_bound,
            "gap_to_official_incumbent": (upper_bound - best_bound) / abs(upper_bound),
            "subgradient_l2": math.sqrt(subgradient_norm_squared),
            "subgradient_max_abs": max_residual,
            "nonzero_residuals": sum(abs(value) > 1e-7 for value in residuals),
            "violated_master_rows": sum(
                abs(value) > 1e-7 if sense == GRB.EQUAL else value > 1e-7
                for sense, value in zip(senses, residuals)
            ),
            "theta": theta,
            "step": step,
            "total_nodes": total_nodes,
            "runtime_seconds": time.time() - iteration_started,
        })
        log_line(
            args.log,
            f"iter={iteration:02d} bound={valid_bound:.9f} best={best_bound:.9f} "
            f"lag_obj={lagrangian_value:.9f} residual_l2={math.sqrt(subgradient_norm_squared):.3f} "
            f"step={step:.9g} optimal_blocks={block_count-len(timed_out_blocks)}/{block_count} "
            f"time={time.time()-iteration_started:.2f}s",
        )

        checkpoint = {
            "instance": model.ModelName,
            "method": "integer Lagrangian dual; official master rows; Polyak projected subgradient",
            "formula": "max_pi min_block-feasible-x c*x + pi*(b-A*x)",
            "official_incumbent": upper_bound,
            "full_lp_bound": float(relaxation.ObjVal),
            "best_valid_global_lower_bound": best_bound,
            "best_gap_to_official_incumbent": (upper_bound - best_bound) / abs(upper_bound),
            "solution": solution_info,
            "decomposition": {
                "blocks": block_count,
                "block_rows": sum(len(rows) for rows in block_rows.values()),
                "master_rows": len(master_rows),
                "master_equalities": sum(sense == GRB.EQUAL for sense in senses),
                "master_greater_equal": sum(sense == GRB.GREATER_EQUAL for sense in senses),
                "master_only_variables": len(master_only),
            },
            "parameters": {
                "iterations": args.iterations,
                "time_per_block": args.time_per_block,
                "threads_lp": args.threads_lp,
                "seed": args.seed,
                "initial_theta": args.theta,
                "stagnation": args.stagnation,
                "fixed_step": args.fixed_step,
            },
            "records": records,
            "wall_seconds": time.time() - started,
            "notes": [
                "Each reported lower bound sums Gurobi ObjBound values for all independent integer blocks.",
                "Equality multipliers are free; greater-equal multipliers are projected nonnegative.",
                "The 168 nonnegative unbounded master-only variables impose additional reduced-cost half-spaces.",
                "Floating-point solver evidence; not an exact rational certificate.",
            ],
        }
        args.output.write_text(json.dumps(checkpoint, indent=2) + "\n", encoding="utf-8")
        if iteration == args.iterations:
            break

        multipliers = [
            multiplier + step * residual
            for multiplier, residual in zip(multipliers, residuals)
        ]
        for row_index, sense in enumerate(senses):
            if sense == GRB.GREATER_EQUAL:
                multipliers[row_index] = max(0.0, multipliers[row_index])

        # Sequential projections onto c_j-a_j*pi >= 0 for unbounded master-only vars.
        for global_index in unbounded_master_only:
            terms = master_terms[global_index]
            reduced_objective = variables[global_index].Obj - math.fsum(
                multipliers[row_index] * coefficient for row_index, coefficient in terms
            )
            if reduced_objective < 0.0:
                norm_squared = math.fsum(coefficient * coefficient for _, coefficient in terms)
                correction = -reduced_objective / norm_squared
                for row_index, coefficient in terms:
                    multipliers[row_index] -= correction * coefficient

    checkpoint["best_multiplier_stats"] = {
        "min": min(best_multipliers),
        "max": max(best_multipliers),
        "nonzero": sum(abs(value) > 1e-10 for value in best_multipliers),
    }
    checkpoint["wall_seconds"] = time.time() - started
    args.output.write_text(json.dumps(checkpoint, indent=2) + "\n", encoding="utf-8")
    log_line(args.log, f"finished best_bound={best_bound:.9f} wall={time.time()-started:.2f}s")


if __name__ == "__main__":
    main()
