from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import time

import gurobipy as gp


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("output_model", type=Path)
    parser.add_argument("output_json", type=Path)
    parser.add_argument("log", type=Path)
    parser.add_argument("--presolve", type=int, default=2)
    parser.add_argument("--aggregate", type=int, default=2)
    parser.add_argument("--agg-fill", type=int, default=200)
    parser.add_argument("--pre-sparsify", type=int, default=2)
    parser.add_argument("--pre-dep-row", type=int, default=1)
    parser.add_argument("--threads", type=int, default=2)
    args = parser.parse_args()

    args.output_model.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.log.parent.mkdir(parents=True, exist_ok=True)
    started = time.time()
    model = gp.read(str(args.mps))
    model.Params.LogFile = str(args.log)
    model.Params.Presolve = args.presolve
    model.Params.Aggregate = args.aggregate
    model.Params.AggFill = args.agg_fill
    model.Params.PreSparsify = args.pre_sparsify
    model.Params.PreDepRow = args.pre_dep_row
    model.Params.Threads = args.threads
    presolved = model.presolve()
    presolved.write(str(args.output_model))

    payload = {
        "instance": model.ModelName,
        "parameters": {
            "presolve": args.presolve,
            "aggregate": args.aggregate,
            "agg_fill": args.agg_fill,
            "pre_sparsify": args.pre_sparsify,
            "pre_dep_row": args.pre_dep_row,
            "threads": args.threads,
        },
        "original": {
            "variables": model.NumVars,
            "constraints": model.NumConstrs,
            "nonzeros": model.NumNZs,
            "objective_nonzeros": sum(variable.Obj != 0.0 for variable in model.getVars()),
            "variable_types": dict(Counter(variable.VType for variable in model.getVars())),
            "constraint_senses": dict(Counter(constraint.Sense for constraint in model.getConstrs())),
        },
        "presolved": {
            "variables": presolved.NumVars,
            "constraints": presolved.NumConstrs,
            "nonzeros": presolved.NumNZs,
            "objective_nonzeros": sum(variable.Obj != 0.0 for variable in presolved.getVars()),
            "objective_constant": float(presolved.ObjCon),
            "variable_types": dict(Counter(variable.VType for variable in presolved.getVars())),
            "constraint_senses": dict(Counter(constraint.Sense for constraint in presolved.getConstrs())),
        },
        "removed": {
            "variables": model.NumVars - presolved.NumVars,
            "constraints": model.NumConstrs - presolved.NumConstrs,
            "nonzeros": model.NumNZs - presolved.NumNZs,
        },
        "output_model": str(args.output_model),
        "output_model_sha256": sha256(args.output_model),
        "runtime_seconds": time.time() - started,
        "warning": "This is a Gurobi-generated presolved model. It is a computational experiment artifact, not a portable exact reformulation certificate.",
    }
    args.output_json.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
