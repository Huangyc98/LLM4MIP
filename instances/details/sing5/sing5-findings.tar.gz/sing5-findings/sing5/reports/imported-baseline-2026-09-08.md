# `sing5` imported baseline supplement

Date: 2026-09-08

## Conclusion

The imported Gurobi log improves the best local reproducible lower bound from
`18,442,898.50581330` to

```text
18,462,676.77864.
```

The strict feasible incumbent remains `18,778,435.60767737`, so the new
reproducible interval is

```text
18,462,676.77864 <= OPT <= 18,778,435.60767737
```

with width `315,758.82903737` and relative gap
`1.6814969874715%`. The lower-bound increase is `19,778.27282670`.
`sing5` remains globally open.

## Retained solver evidence

The sanitized log records a Gurobi 13.0.2 solve of the untouched original MPS
with the public incumbent loaded. It used one thread, Seed 1 and `MIPGap=0`.
The solver completed its own termination sequence and printed:

```text
Time limit reached
Best objective 1.877843560768e+07
Best bound     1.846267677864e+07
Gap            1.6815%
```

The incumbent audit independently recomputes the current public solution at
`18,778,435.6076773694473176567`, with exact integrality/bound compliance and
maximum raw row violation `3.14e-13`. Thus no primal improvement is claimed.

The raw log is
[`imported-baseline-2026-09-08.log`](../logs/imported-baseline-2026-09-08.log),
and the imported incumbent audit is
[`imported-incumbent-decimal-audit.txt`](../artifacts/imported-incumbent-decimal-audit.txt).

## Runtime anomaly

The log is internally inconsistent about elapsed time:

- its parameter block records `TimeLimit 30`;
- progress advances from 24 seconds directly to 945 seconds;
- its final summary reports 945.67 seconds;
- no external wrapper timing record accompanied this baseline.

The solver did print a normal final bound and status, so the full-precision
bound is retained. The elapsed time is marked unreliable: this experiment is
not used in runtime totals or speed comparisons, and the nominal 30-second
setting must not be reported as actual runtime.

## Comparison and evidence boundary

The archived COPT 10-hour PDF reports a stronger numerical lower bound of
`18,605,207.3`, exceeding this imported value by `142,530.52136`. It has no
matching raw log in the repository and remains historical PDF-only evidence.

The imported Gurobi number is also finite-precision solver evidence, not an
independently checked rational certificate. It improves the reproducible local
record but does not establish global optimality. A separately supplied
shortage-eliminated MPS was rejected because its exact coefficient/objective
audit failed; it is intentionally not included. The attachment's rounded,
externally terminated follow-up bound is likewise excluded because it lacks a
full-precision final summary.
