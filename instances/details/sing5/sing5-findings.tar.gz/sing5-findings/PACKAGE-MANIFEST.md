# Package manifest: sing5

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 111
Excluded source files: 0

## Included files

- `README.md`
- `artifacts/block-lns-all68-gap0.json`
- `artifacts/block7-8-isomorphism-audit.txt`
- `artifacts/branch-focus3-method1-cuts2-600s.json`
- `artifacts/concurrent2-balanced-1200s.json`
- `artifacts/group-lns-structural-gap0.json`
- `artifacts/imported-baseline-result.json`
- `artifacts/imported-incumbent-decimal-audit.txt`
- `artifacts/lagrangian-lpdual-300s.json`
- `artifacts/lagrangian-subgradient-15.json`
- `artifacts/lagrangian-subgradient-fixed2e-4-5.json`
- `artifacts/published-solution-replay.json`
- `artifacts/root-fullstart-agg2.json`
- `artifacts/rootcuts-focus3-cuts3.json`
- `artifacts/sing5-decomposition.json`
- `artifacts/sing5-public-audit.json`
- `artifacts/sing5-root-probe.json`
- `artifacts/sing5-structure.json`
- `artifacts/solution-diff-2018-to-public.json`
- `input/README.md`
- `input/SHA256SUMS`
- `input/sing5-2018-selection.sol.gz`
- `input/sing5-public.sol.gz`
- `input/sing5.dec`
- `logs/block-lns-all68-gap0/sing5-block-01.log`
- `logs/block-lns-all68-gap0/sing5-block-02.log`
- `logs/block-lns-all68-gap0/sing5-block-03.log`
- `logs/block-lns-all68-gap0/sing5-block-04.log`
- `logs/block-lns-all68-gap0/sing5-block-05.log`
- `logs/block-lns-all68-gap0/sing5-block-06.log`
- `logs/block-lns-all68-gap0/sing5-block-07.log`
- `logs/block-lns-all68-gap0/sing5-block-08.log`
- `logs/block-lns-all68-gap0/sing5-block-09.log`
- `logs/block-lns-all68-gap0/sing5-block-10.log`
- `logs/block-lns-all68-gap0/sing5-block-11.log`
- `logs/block-lns-all68-gap0/sing5-block-12.log`
- `logs/block-lns-all68-gap0/sing5-block-13.log`
- `logs/block-lns-all68-gap0/sing5-block-14.log`
- `logs/block-lns-all68-gap0/sing5-block-15.log`
- `logs/block-lns-all68-gap0/sing5-block-16.log`
- `logs/block-lns-all68-gap0/sing5-block-17.log`
- `logs/block-lns-all68-gap0/sing5-block-18.log`
- `logs/block-lns-all68-gap0/sing5-block-19.log`
- `logs/block-lns-all68-gap0/sing5-block-20.log`
- `logs/block-lns-all68-gap0/sing5-block-21.log`
- `logs/block-lns-all68-gap0/sing5-block-22.log`
- `logs/block-lns-all68-gap0/sing5-block-23.log`
- `logs/block-lns-all68-gap0/sing5-block-24.log`
- `logs/block-lns-all68-gap0/sing5-block-25.log`
- `logs/block-lns-all68-gap0/sing5-block-26.log`
- `logs/block-lns-all68-gap0/sing5-block-27.log`
- `logs/block-lns-all68-gap0/sing5-block-28.log`
- `logs/block-lns-all68-gap0/sing5-block-29.log`
- `logs/block-lns-all68-gap0/sing5-block-30.log`
- `logs/block-lns-all68-gap0/sing5-block-31.log`
- `logs/block-lns-all68-gap0/sing5-block-32.log`
- `logs/block-lns-all68-gap0/sing5-block-33.log`
- `logs/block-lns-all68-gap0/sing5-block-34.log`
- `logs/block-lns-all68-gap0/sing5-block-35.log`
- `logs/block-lns-all68-gap0/sing5-block-36.log`
- `logs/block-lns-all68-gap0/sing5-block-37.log`
- `logs/block-lns-all68-gap0/sing5-block-38.log`
- `logs/block-lns-all68-gap0/sing5-block-39.log`
- `logs/block-lns-all68-gap0/sing5-block-40.log`
- `logs/block-lns-all68-gap0/sing5-block-41.log`
- `logs/block-lns-all68-gap0/sing5-block-42.log`
- `logs/block-lns-all68-gap0/sing5-block-43.log`
- `logs/block-lns-all68-gap0/sing5-block-44.log`
- `logs/block-lns-all68-gap0/sing5-block-45.log`
- `logs/block-lns-all68-gap0/sing5-block-46.log`
- `logs/block-lns-all68-gap0/sing5-block-47.log`
- `logs/block-lns-all68-gap0/sing5-block-48.log`
- `logs/block-lns-all68-gap0/sing5-block-49.log`
- `logs/block-lns-all68-gap0/sing5-block-50.log`
- `logs/block-lns-all68-gap0/sing5-block-51.log`
- `logs/block-lns-all68-gap0/sing5-block-52.log`
- `logs/block-lns-all68-gap0/sing5-block-53.log`
- `logs/block-lns-all68-gap0/sing5-block-54.log`
- `logs/block-lns-all68-gap0/sing5-block-55.log`
- `logs/block-lns-all68-gap0/sing5-block-56.log`
- `logs/block-lns-all68-gap0/sing5-block-57.log`
- `logs/block-lns-all68-gap0/sing5-block-58.log`
- `logs/block-lns-all68-gap0/sing5-block-59.log`
- `logs/block-lns-all68-gap0/sing5-block-60.log`
- `logs/block-lns-all68-gap0/sing5-block-61.log`
- `logs/block-lns-all68-gap0/sing5-block-62.log`
- `logs/block-lns-all68-gap0/sing5-block-63.log`
- `logs/block-lns-all68-gap0/sing5-block-64.log`
- `logs/block-lns-all68-gap0/sing5-block-65.log`
- `logs/block-lns-all68-gap0/sing5-block-66.log`
- `logs/block-lns-all68-gap0/sing5-block-67.log`
- `logs/block-lns-all68-gap0/sing5-block-68.log`
- `logs/branch-focus3-method1-cuts2-600s.log`
- `logs/concurrent2-balanced-1200s.log`
- `logs/group-lns-structural-gap0/sing5-group-01-02-03.log`
- `logs/group-lns-structural-gap0/sing5-group-04-05-06.log`
- `logs/group-lns-structural-gap0/sing5-group-07-08.log`
- `logs/group-lns-structural-gap0/sing5-group-10-11-12.log`
- `logs/group-lns-structural-gap0/sing5-group-13-14.log`
- `logs/group-lns-structural-gap0/sing5-group-66-67-68.log`
- `logs/imported-baseline-2026-09-08.log`
- `logs/rootcuts-focus3-cuts3.log`
- `reports/imported-baseline-2026-09-08.md`
- `scripts/analyze_decomposition.py`
- `scripts/build_presolved.py`
- `scripts/common_audit_solution.py`
- `scripts/gurobi_probe.py`
- `scripts/run_block_lns.py`
- `scripts/run_group_lns.py`
- `scripts/run_gurobi.py`
- `scripts/run_lagrangian_subgradient.py`

## Excluded files

- None
