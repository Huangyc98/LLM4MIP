# dfn-bwin-DBE

Status: **global optimum proved**.

Exact optimum: **73,623.79**.

[MIPLIB instance page](https://miplib.zib.de/instance_details_dfn-bwin-DBE.html)

## Proof

The model is a 10-node fixed-charge capacitated multicommodity network-design
problem. Positive demand exists for every ordered pair of nodes, so every
feasible installed-edge support is connected. A connected 10-node support has
at least nine edges; a nine-edge support is a tree. For every tree edge, its cut
uniquely determines the two directional loads and therefore the cheapest
feasible capacity choice.

Two different exact subset dynamic programs enumerated all spanning trees and
both returned **7,362,379 cents**. The independent verifier parses the original
MPS with `Decimal`, checks every HRC/CAP template and physical arc endpoint, and
obtains the same optimum for all ten possible roots. Designs with ten or more
selected physical edges cost at least the sum of the ten globally cheapest
positive opening costs, **8,122,240 cents**, which is strictly worse.

The archived integral DP-tree solution has objective 73,623.79 and zero exact
row, bound, and integrality violations. The slightly smaller objective printed
for the public MIPLIB solution comes from binary values within solver tolerance;
it is not an exactly integral solution.

## Reproduce

The final lower-bound verifier uses only the Python standard library:

```powershell
python .\instances\dfn-bwin-DBE\scripts\verify_dfn_exact.py `
  .\instances\dfn-bwin-DBE\input\dfn-bwin-DBE.mps.gz
```

Independently check the generated exact feasible solution:

```powershell
python .\common\exact_mps_solution_check.py `
  .\instances\dfn-bwin-DBE\input\dfn-bwin-DBE.mps.gz `
  .\instances\dfn-bwin-DBE\solutions\dfn-bwin-DBE.dp-tree.sol
```

`scripts/dfn_tree_certificate.py` is the first DP, solution generator, and
Gurobi-based original-model checker. Gurobi is used to read and evaluate the
model, not to optimize it. `scripts/verify_dfn_exact.py` is the independent,
solver-free parser and second DP recurrence. Their outputs are archived under
`logs/`; recovered structural metadata is under `artifacts/`.

## Provenance

This result was produced in a two-turn direct-API investigation using 93,766
tokens. Raw API responses and machine-specific runtime metadata are deliberately
not included; all mathematical evidence required to reproduce the conclusion is
archived here.

SHA-256:

- MPS: `DF12D48C2244ECC743D1086F24E653FB11343CD2E253B05CBAF55D257D4AF859`
- public solution: `EB1FA0B999EB9BE56E7BA4E3862A8198120736DBFA2623FF886E6A5442425685`
- exact DP-tree solution: `F108F24AD65C008CE3D9CABDC6D65F969F983FEA4C991E9C013E25F8A4CD9DD4`
