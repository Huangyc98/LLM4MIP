#!/usr/bin/env python3
import gzip
import re
import sys
from collections import defaultdict
from decimal import Decimal
from functools import lru_cache

D = Decimal
INF = 10**100

X_RE = re.compile(
    r"^XHC\(LD_LD_([0-9]+(?:\.[0-9]+)?)__(.+)\)$"
)


def number(s):
    return D(s.replace("d", "E").replace("D", "E"))


def open_text(path):
    if path.endswith(".gz"):
        return gzip.open(path, "rt", encoding="utf-8", errors="strict")
    return open(path, "rt", encoding="utf-8", errors="strict")


def parse_mps(path):
    section = None
    rowsense = {}
    nrows = []
    columns = defaultdict(lambda: defaultdict(D))
    variable_order = []
    seen_variables = set()
    rhs = defaultdict(D)
    rhs_vector = None
    bounds_records = []
    integer_variables = set()
    integer_mode = False
    objective_sense = "MIN"
    objective_name_hint = None
    ranges_seen = False

    headers = {
        "OBJSENSE", "OBJNAME", "ROWS", "COLUMNS",
        "RHS", "RANGES", "BOUNDS", "ENDATA"
    }

    with open_text(path) as f:
        for lineno, raw_line in enumerate(f, 1):
            if not raw_line.strip() or raw_line.lstrip().startswith("*"):
                continue

            tokens = raw_line.split()
            if "$" in tokens:
                tokens = tokens[:tokens.index("$")]
            if not tokens:
                continue

            key = tokens[0].upper()

            if key == "NAME":
                section = "NAME"
                continue

            if key in headers and (
                len(tokens) == 1 or key in {"ENDATA"}
            ):
                section = key
                if key == "ENDATA":
                    break
                continue

            # Accommodate "OBJNAME name" on one line.
            if key == "OBJNAME" and len(tokens) == 2:
                section = "OBJNAME"
                objective_name_hint = tokens[1]
                continue

            if section == "OBJSENSE":
                s = tokens[0].upper()
                if s not in {"MIN", "MAX"}:
                    raise RuntimeError(
                        f"Line {lineno}: unknown objective sense {tokens[0]}"
                    )
                objective_sense = s

            elif section == "OBJNAME":
                objective_name_hint = tokens[0]

            elif section == "ROWS":
                if len(tokens) != 2:
                    raise RuntimeError(
                        f"Line {lineno}: malformed ROWS entry"
                    )
                sense, row = tokens
                sense = sense.upper()
                if sense not in {"N", "E", "L", "G"}:
                    raise RuntimeError(
                        f"Line {lineno}: bad row sense {sense}"
                    )
                if row in rowsense:
                    raise RuntimeError(f"Duplicate row name {row}")
                rowsense[row] = sense
                if sense == "N":
                    nrows.append(row)

            elif section == "COLUMNS":
                clean = [x.strip("'\"") for x in tokens]
                if len(clean) >= 3 and clean[1].upper() == "MARKER":
                    marker = clean[2].upper()
                    if marker == "INTORG":
                        integer_mode = True
                    elif marker == "INTEND":
                        integer_mode = False
                    else:
                        raise RuntimeError(
                            f"Line {lineno}: unknown marker {marker}"
                        )
                    continue

                var = tokens[0]
                if var not in seen_variables:
                    seen_variables.add(var)
                    variable_order.append(var)
                if integer_mode:
                    integer_variables.add(var)

                entries = tokens[1:]
                if len(entries) % 2:
                    raise RuntimeError(
                        f"Line {lineno}: malformed COLUMNS entry"
                    )
                for i in range(0, len(entries), 2):
                    row = entries[i]
                    val = number(entries[i + 1])
                    columns[var][row] += val

            elif section == "RHS":
                if len(tokens) < 3 or (len(tokens) - 1) % 2:
                    raise RuntimeError(
                        f"Line {lineno}: malformed RHS entry"
                    )
                vector = tokens[0]
                if rhs_vector is None:
                    rhs_vector = vector
                elif vector != rhs_vector:
                    raise RuntimeError(
                        "Multiple RHS vectors are not supported"
                    )
                for i in range(1, len(tokens), 2):
                    rhs[tokens[i]] += number(tokens[i + 1])

            elif section == "RANGES":
                ranges_seen = True

            elif section == "BOUNDS":
                if len(tokens) not in {3, 4}:
                    raise RuntimeError(
                        f"Line {lineno}: malformed BOUNDS entry"
                    )
                btype = tokens[0].upper()
                var = tokens[2]
                val = number(tokens[3]) if len(tokens) == 4 else None
                bounds_records.append((btype, var, val))

            else:
                raise RuntimeError(
                    f"Line {lineno}: data outside recognized section: "
                    f"{raw_line.rstrip()}"
                )

    if ranges_seen:
        raise RuntimeError("Unexpected nonempty RANGES section")
    if objective_sense != "MIN":
        raise RuntimeError("Expected a minimization model")

    if objective_name_hint is not None:
        objective_row = objective_name_hint
        if rowsense.get(objective_row) != "N":
            raise RuntimeError("OBJNAME does not identify an N row")
    else:
        if not nrows:
            raise RuntimeError("No objective N row found")
        objective_row = nrows[0]

    # Remove any entries that canceled exactly to zero.
    for var in list(columns):
        for row in list(columns[var]):
            if columns[var][row] == 0:
                del columns[var][row]

    # Resolve standard MPS bounds.
    lb = {v: D(0) for v in variable_order}
    ub = {v: None for v in variable_order}  # None means +infinity

    for btype, var, val in bounds_records:
        if var not in lb:
            lb[var] = D(0)
            ub[var] = None
            variable_order.append(var)

        if btype == "LO":
            lb[var] = val
        elif btype == "UP":
            ub[var] = val
        elif btype == "FX":
            lb[var] = val
            ub[var] = val
        elif btype == "FR":
            lb[var] = None
            ub[var] = None
        elif btype == "MI":
            lb[var] = None
        elif btype == "PL":
            ub[var] = None
        elif btype == "BV":
            integer_variables.add(var)
            lb[var] = D(0)
            ub[var] = D(1)
        elif btype == "LI":
            integer_variables.add(var)
            lb[var] = val
        elif btype == "UI":
            integer_variables.add(var)
            ub[var] = val
        else:
            raise RuntimeError(f"Unsupported bound type {btype}")

    constrained_rows = {
        r: s for r, s in rowsense.items() if s != "N"
    }
    row_terms = defaultdict(dict)
    for var, entries in columns.items():
        for row, coef in entries.items():
            if row in constrained_rows:
                row_terms[row][var] = coef

    return {
        "rowsense": rowsense,
        "constrained_rows": constrained_rows,
        "objective_row": objective_row,
        "columns": columns,
        "row_terms": row_terms,
        "rhs": rhs,
        "variables": variable_order,
        "integer_variables": integer_variables,
        "lb": lb,
        "ub": ub,
    }


def main():
    if len(sys.argv) != 2:
        print("Usage: python verify_dfn_exact.py dfn-bwin-DBE.mps.gz")
        return 2

    mps = parse_mps(sys.argv[1])
    rowsense = mps["rowsense"]
    constrained_rows = mps["constrained_rows"]
    objective_row = mps["objective_row"]
    columns = mps["columns"]
    row_terms = mps["row_terms"]
    rhs = mps["rhs"]
    variables = mps["variables"]
    integer_variables = mps["integer_variables"]
    lb = mps["lb"]
    ub = mps["ub"]

    xvars = [v for v in variables if v.startswith("XHC(")]
    efvars = [v for v in variables if v.startswith("EF(")]
    fc_rows = [r for r in constrained_rows if r.startswith("FC(")]
    cap_rows = [r for r in constrained_rows if r.startswith("CAP(")]
    hrc_rows = [r for r in constrained_rows if r.startswith("HRC(")]

    assert len(variables) == 3285
    assert len(constrained_rows) == 235
    assert len(xvars) == 2475
    assert len(efvars) == 810
    assert len(fc_rows) == 100
    assert len(cap_rows) == 90
    assert len(hrc_rows) == 45
    assert set(variables) == set(xvars) | set(efvars)
    assert set(constrained_rows) == set(fc_rows) | set(cap_rows) | set(hrc_rows)

    # Bounds and types needed by the proof.
    for v in xvars:
        assert v in integer_variables
        assert lb[v] == 0 and ub[v] == 1
    for v in efvars:
        assert v not in integer_variables
        assert lb[v] == 0 and ub[v] is None

    # Parse FC row names and exact balances.
    groups = defaultdict(dict)
    for row in fc_rows:
        assert rowsense[row] == "E"
        inner = row[3:-1]
        group, node = inner.rsplit("__", 1)
        groups[group][node] = rhs.get(row, D(0))

    nodes = sorted({node for b in groups.values() for node in b})
    node_index = {node: i for i, node in enumerate(nodes)}
    n = len(nodes)
    full = (1 << n) - 1

    assert n == 10
    assert len(groups) == 10
    assert all(set(b) == set(nodes) for b in groups.values())

    # Infer exact directed EF arcs from +1 tail and -1 head coefficients.
    ef_fc_occurrences = defaultdict(list)
    for row in fc_rows:
        group, node = row[3:-1].rsplit("__", 1)
        for var, coef in row_terms[row].items():
            assert var.startswith("EF(")
            assert coef in {D(-1), D(1)}
            ef_fc_occurrences[var].append((group, node, coef))

    arc = {}
    for var in efvars:
        occ = ef_fc_occurrences[var]
        assert len(occ) == 2
        assert occ[0][0] == occ[1][0]
        group = occ[0][0]
        tails = [node for _, node, a in occ if a == 1]
        heads = [node for _, node, a in occ if a == -1]
        assert len(tails) == 1 and len(heads) == 1
        arc[var] = (
            group,
            node_index[tails[0]],
            node_index[heads[0]]
        )

    source = {}
    demand = {}
    for group, balances in groups.items():
        assert sum(balances.values(), D(0)) == 0
        assert all(x == x.to_integral_value() for x in balances.values())

        positive = [v for v in nodes if balances[v] > 0]
        negative = [v for v in nodes if balances[v] < 0]
        assert len(positive) == 1
        assert len(negative) == n - 1

        source[group] = node_index[positive[0]]
        demand[group] = {
            node_index[v]: int(-balances[v]) for v in negative
        }

    assert len(set(source.values())) == n
    for group in groups:
        s = source[group]
        assert set(demand[group]) == set(range(n)) - {s}
        assert all(x > 0 for x in demand[group].values())

    # Parse all design variables and exact objective coefficients.
    def endpoints_from_suffix(suffix):
        candidates = []
        for i in range(n):
            for j in range(i + 1, n):
                a, b = nodes[i], nodes[j]
                if suffix in {a + "_" + b, b + "_" + a}:
                    candidates.append((i, j))
        assert len(candidates) == 1, (suffix, candidates)
        return candidates[0]

    designs = defaultdict(list)
    xmeta = {}
    objective_cents = {}

    for var in xvars:
        match = X_RE.match(var)
        assert match is not None

        cap_decimal = number(match.group(1))
        assert cap_decimal == cap_decimal.to_integral_value()
        capacity = int(cap_decimal)

        edge = endpoints_from_suffix(match.group(2))
        obj = columns[var].get(objective_row, D(0))
        scaled = obj * 100

        # This is an exact Decimal test on the original MPS token value.
        assert scaled == scaled.to_integral_value()
        cents = int(scaled)

        # Required for extending the ten-edge bound to all larger supports.
        assert cents > 0

        designs[edge].append((capacity, cents, var))
        xmeta[var] = (edge, capacity, cents)
        objective_cents[var] = cents

    assert len(designs) == 45
    expected_edges = {
        (i, j) for i in range(n) for j in range(i + 1, n)
    }
    assert set(designs) == expected_edges

    expected_capacities = list(range(80000, 350001, 5000))
    for edge in designs:
        designs[edge].sort()
        assert [x[0] for x in designs[edge]] == expected_capacities

    for var in efvars:
        assert columns[var].get(objective_row, D(0)) == 0

    # Verify HRC exactly.
    hrc_edges = set()
    for row in hrc_rows:
        assert rowsense[row] == "G"
        assert rhs.get(row, D(0)) == -1
        terms = row_terms[row]
        assert len(terms) == 55

        edges = set()
        seen_x = set()
        for var, coef in terms.items():
            assert var in xmeta
            assert coef == -1
            edges.add(xmeta[var][0])
            seen_x.add(var)

        assert len(edges) == 1
        edge = next(iter(edges))
        assert seen_x == {x[2] for x in designs[edge]}
        hrc_edges.add(edge)

    assert hrc_edges == expected_edges

    # Verify CAP rows exactly, including the previously unchecked
    # correspondence between each EF arc and the physical design edge.
    cap_count = defaultdict(int)
    cap_directions = defaultdict(set)
    ef_cap_count = defaultdict(int)

    for row in cap_rows:
        assert rowsense[row] == "L"
        assert rhs.get(row, D(0)) == 0

        terms = row_terms[row]
        xs = [(v, a) for v, a in terms.items() if v in xmeta]
        fs = [(v, a) for v, a in terms.items() if v in arc]
        assert len(xs) == 55
        assert len(fs) == 9
        assert len(xs) + len(fs) == len(terms)

        edges = {xmeta[v][0] for v, _ in xs}
        assert len(edges) == 1
        edge = next(iter(edges))

        assert {v for v, _ in xs} == {x[2] for x in designs[edge]}
        for var, coef in xs:
            assert coef == -D(xmeta[var][1])

        directions = set()
        for var, coef in fs:
            assert coef == 1
            _, tail, head = arc[var]

            # Critical connectivity/linkage check.
            assert (min(tail, head), max(tail, head)) == edge
            directions.add((tail, head))
            ef_cap_count[var] += 1

        assert len(directions) == 1
        direction = next(iter(directions))
        cap_directions[edge].add(direction)
        cap_count[edge] += 1

    for edge in expected_edges:
        u, v = edge
        assert cap_count[edge] == 2
        assert cap_directions[edge] == {(u, v), (v, u)}

    assert all(ef_cap_count[v] == 1 for v in efvars)

    # Every variable must occur only in the expected three constraints.
    for var in xvars:
        incident = [
            row for row in columns[var]
            if rowsense.get(row) in {"E", "L", "G"}
        ]
        assert len(incident) == 3
        assert sum(r.startswith("HRC(") for r in incident) == 1
        assert sum(r.startswith("CAP(") for r in incident) == 2

    for var in efvars:
        incident = [
            row for row in columns[var]
            if rowsense.get(row) in {"E", "L", "G"}
        ]
        assert len(incident) == 3
        assert sum(r.startswith("FC(") for r in incident) == 2
        assert sum(r.startswith("CAP(") for r in incident) == 1

    print("EXACT_MPS_AUDIT")
    print(f"  nodes={n}")
    print(f"  commodities={len(groups)}")
    print(f"  exact_cent_design_coefficients={len(xvars)}")
    print(f"  minimum_design_cost_cents={min(objective_cents.values())}")
    print("  all_design_costs_positive=True")
    print("  all_ordered_demands_positive=True")
    print("  cap_endpoint_mismatches=0")
    print("  cap_direction_errors=0")
    print("  exact_structure_verified=True")

    # Exact directed traffic crossing each subset.
    cut_forward = [0] * (1 << n)
    cut_backward = [0] * (1 << n)
    cut_required = [0] * (1 << n)

    for mask in range(1, full):
        fwd = 0
        bwd = 0
        for group in groups:
            s = source[group]
            for t, amount in demand[group].items():
                sin = bool(mask & (1 << s))
                tin = bool(mask & (1 << t))
                if sin and not tin:
                    fwd += amount
                elif tin and not sin:
                    bwd += amount
        cut_forward[mask] = fwd
        cut_backward[mask] = bwd
        cut_required[mask] = max(fwd, bwd)

    # Required capacities must be invariant under complementing the cut.
    for mask in range(1, full):
        assert cut_required[mask] == cut_required[full ^ mask]

    @lru_cache(maxsize=None)
    def edge_cost(u, v, child_mask):
        edge = (min(u, v), max(u, v))
        required = cut_required[child_mask]
        feasible = [
            cents
            for capacity, cents, _ in designs[edge]
            if capacity >= required
        ]
        return min(feasible) if feasible else INF

    # Independent canonical-partition tree DP.
    #
    # tree[mask][r] is the best rooted tree on mask with root r.
    # The vertices other than r are partitioned into the connected
    # components obtained after deleting r. Each component C is attached
    # to r through one vertex u in C. Requiring C to contain the least
    # remaining vertex makes the partition enumeration canonical.
    tree = [[INF] * n for _ in range(1 << n)]
    for r in range(n):
        tree[1 << r][r] = 0

    @lru_cache(maxsize=None)
    def partition_cost(root, remaining):
        if remaining == 0:
            return 0

        anchor = remaining & -remaining
        best = INF
        component = remaining

        while component:
            if component & anchor:
                bits = component
                while bits:
                    ubit = bits & -bits
                    u = ubit.bit_length() - 1
                    bits ^= ubit

                    inside = tree[component][u]
                    if inside >= INF:
                        continue
                    joining = edge_cost(root, u, component)
                    if joining >= INF:
                        continue

                    rest = partition_cost(
                        root, remaining ^ component
                    )
                    candidate = inside + joining + rest
                    if candidate < best:
                        best = candidate

            component = (component - 1) & remaining

        return best

    for cardinality in range(2, n + 1):
        for mask in range(1, 1 << n):
            if mask.bit_count() != cardinality:
                continue
            bits = mask
            while bits:
                rbit = bits & -bits
                r = rbit.bit_length() - 1
                bits ^= rbit
                tree[mask][r] = partition_cost(
                    r, mask ^ (1 << r)
                )

    root_values = [tree[full][r] for r in range(n)]
    assert all(v == root_values[0] for v in root_values)
    tree_optimum = root_values[0]

    # Any support with at least ten physical edges pays at least the sum
    # of the ten globally smallest minimum edge-opening costs.
    minimum_edge_costs = [
        min(cents for _, cents, _ in designs[e])
        for e in expected_edges
    ]
    ten_edge_floor = sum(sorted(minimum_edge_costs)[:10])

    print("INDEPENDENT_EXACT_DP")
    print(f"  root_values_cents={root_values}")
    print(f"  tree_optimum_cents={tree_optimum}")
    print(f"  tree_optimum={D(tree_optimum) / 100}")
    print(f"  ten_edge_floor_cents={ten_edge_floor}")
    print(f"  ten_edge_floor={D(ten_edge_floor) / 100}")

    proof = ten_edge_floor >= tree_optimum
    print("GLOBAL_CERTIFICATE")
    print("  every_feasible_support_connected=True")
    print("  every_feasible_support_has_at_least_9_edges=True")
    print(f"  GLOBAL_PROOF={'YES' if proof else 'NO'}")
    if proof:
        print(f"  PROVEN_GLOBAL_OPTIMUM={D(tree_optimum) / 100}")

    return 0 if proof else 1


if __name__ == "__main__":
    raise SystemExit(main())
