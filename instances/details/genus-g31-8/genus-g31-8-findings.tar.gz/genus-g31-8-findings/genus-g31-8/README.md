# `genus-g31-8`

## Result

**Current exact-decimal MPS status: global lower bound -23; optimum unresolved.**
The native graph has orientable genus 3.

This is the unsymmetrized formulation of the same 31-vertex, 58-edge graph as
`genus-sym-g31-8`. A fresh exhaustive `multi_genus` run confirms orientable
genus **3** and therefore the original-MPS global lower bound **-23**.

The archived objective `-23` point is integral and within bounds, but it
violates six literal decimal MPS rows by `1e-15`: each active triangular face
evaluates `1 - 3*0.333333333333333 = 1e-15`. It is tolerance-feasible, not a
zero-tolerance rational witness. The native graph optimum is established, but
the literal exact-decimal MPS optimum is not closed until a strict `-23`
witness or another complete upper-bound argument is supplied. The detailed
recheck is in the
[rows 6–20 independent review](../../docs/rows-06-20-dual-bound-review-2026-09-18/genus-g31-8/README.md).

## Provenance

- Compressed MPS SHA-256: `577846B901B80F150FA8765AE0589ECCD838F5AC3251AA25DBBF6E99FD32D613`
- Official compressed solution SHA-256: `C51AF35DDB32EAA09DB14BA44183EB14BAC7A4C282E48C619BC940605C23BBF4`
- [MIPLIB instance page](https://miplib.zib.de/instance_details_genus-g31-8.html)

The rotation, adjacency data, and exact-program transcripts are under
[`artifacts/`](artifacts/) and [`logs/`](logs/). Shared source-recovery tooling
is in [`common/reproduce_genus_artifacts.py`](../../common/reproduce_genus_artifacts.py).
