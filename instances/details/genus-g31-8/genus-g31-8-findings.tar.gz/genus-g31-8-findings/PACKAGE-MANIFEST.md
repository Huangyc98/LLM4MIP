# Package manifest: genus-g31-8

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 7
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/genus-g31-8.adjacency.txt`
- `artifacts/genus-g31-8.exact-rotation.txt`
- `artifacts/genus-g31-8.mc`
- `logs/genus-g31-8.multi-genus-decision-gt-2.log`
- `logs/genus-g31-8.multi-genus.log`
- `solutions/official-23.sol.gz`

## Excluded files

- `input/genus-g31-8.mps.gz (1496011 bytes; raw benchmark input; sha256 577846b901b80f150fa8765ae0589eccd838f5ac3251aa25dbbf6e99fd32d613)`
