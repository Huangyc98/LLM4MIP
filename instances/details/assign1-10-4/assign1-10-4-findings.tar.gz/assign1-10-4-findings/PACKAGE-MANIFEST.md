# Package manifest: assign1-10-4

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 29
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/assign1-10-4_categories.json`
- `artifacts/assign1-10-4_factored.json`
- `artifacts/assign1-10-4_factored_exact.json`
- `artifacts/assign1-10-4_structure.json`
- `logs/assign1-10-4_certificate_20260902.log`
- `logs/assign1-10-4_gurobi_probe.log`
- `reports/assign1_optimality_proof.md`
- `reports/framework-revalidation-20260902.md`
- `runs/gurobi-20260902-201631-e8c4c12b/best.sol`
- `runs/gurobi-20260902-201631-e8c4c12b/driver.stderr`
- `runs/gurobi-20260902-201631-e8c4c12b/driver.stdout`
- `runs/gurobi-20260902-201631-e8c4c12b/result.json`
- `runs/gurobi-20260902-201631-e8c4c12b/solver.log`
- `scripts/assign1_aggregated_miqp.py`
- `scripts/assign1_decompose_categories.py`
- `scripts/assign1_factor_gurobi.py`
- `scripts/assign1_factor_weights.py`
- `scripts/assign1_gurobi_prove.py`
- `scripts/assign1_gurobi_structure.py`
- `scripts/assign1_optimality_certificate.py`
- `scripts/assign1_overlap_miqp.py`
- `scripts/assign1_row_bounds.py`
- `solutions/assign1-10-4_copt_422.sol`
- `solutions/assign1-10-4_gurobi_422.sol`
- `solutions/official-best.sol.gz`
- `solutions/official-best.validation.json`
- `structure-gurobi.log`
- `structure.json`

## Excluded files

- `input/assign1-10-4.mps.gz (90009 bytes; raw benchmark input; sha256 d85ac9d663bb7f6a26d98d52988b5de59bf8038c8c89789b7a3bedf546160422)`
