# `assign1-10-4`

## Result

The exact minimum is **422**. A feasible solution attains 422, and the independent certificate reconstructs the four categorical attributes from the original MPS and proves a matching combinatorial lower bound of 422 using exact integer arithmetic.

This proof does not depend on a branch-and-bound lower bound.

The result was revalidated on 2026-09-02: the exact certificate accepted both the archived Gurobi
and COPT objective-422 solutions, and a fresh controlled Gurobi 13.0.1 run reproduced objective 422.
See [the framework revalidation report](reports/framework-revalidation-20260902.md).

## Input

- SHA-256: `D85AC9D663BB7F6A26D98D52988B5DE59BF8038C8C89789B7A3BEDF546160422`
- Model: 52 people assigned to 10 groups; objective minimizes within-group categorical overlap.

## Reproduce the certificate

From the repository root:

```powershell
python .\instances\assign1-10-4\scripts\assign1_optimality_certificate.py `
  .\instances\assign1-10-4\input\assign1-10-4.mps.gz `
  --solution .\instances\assign1-10-4\solutions\assign1-10-4_gurobi_422.sol `
  --categories .\instances\assign1-10-4\artifacts\assign1-10-4_categories.json
```

Expected final line: `CERTIFIED OPTIMUM: 422`.

See the [full proof](reports/assign1_optimality_proof.md), [certificate script](scripts/assign1_optimality_certificate.py), and [Gurobi solution](solutions/assign1-10-4_gurobi_422.sol).
