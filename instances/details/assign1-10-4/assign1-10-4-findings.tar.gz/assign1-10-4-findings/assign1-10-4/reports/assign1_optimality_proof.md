# Exact optimum of `assign1-10-4`

The minimum objective value is

\[
\boxed{422}.
\]

The feasible solution is `assign1-10-4_gurobi_422.sol`.  The independent
verifier is `assign1_optimality_certificate.py`; it uses only the Python
standard library and exact integer arithmetic.

## 1. Structure read from the original MPS

The verifier parses the MPS and checks all of these facts directly.

- There are 52 nonnegative overlap variables `y[i]` and 520 binary assignment
  variables `x[i,g]`, for 52 people and 10 groups.
- Every person is assigned to exactly one group.
- Eight groups contain exactly 5 people and two groups contain exactly 6.
- For every person `i` and group `g`, the original MPS contains

  \[
  y_i-\sum_p w_{ip}x_{pg}\ge -5.
  \]

- The diagonal coefficients are `w[i,i]=5`.  For distinct people, `w[i,p]`
  is an integer from 0 through 4.
- The objective is `min sum(i) y[i]`.

The saved solution is checked against all 582 original constraints, all
bounds, all integrality declarations, and the original objective.

## 2. Recovering the four categorical attributes

The coefficient matrix is verified exactly to have the form

\[
w_{ip}=1_{i=p}+\sum_{k=1}^4 1_{c_{ik}=c_{pk}},
\]

where `c[i,k]` is person `i`'s type in category `k`.  The numerical names of
the recovered types are arbitrary; only equality within a category matters.
The four type-frequency lists are

```text
[32, 12, 4, 2, 1, 1]
[49, 3]
[23, 23, 3, 3]
[35, 8, 5, 4]
```

The stored decomposition is not trusted blindly: the verifier reconstructs
every one of the 52 by 52 original coefficients from it.

## 3. Exact lower bound

Let person `i` be assigned to group `g(i)`.  Substituting
`x[i,g(i)]=1` into the corresponding original MPS row gives

\[
y_i\ge \sum_{p\ne i}\sum_{k=1}^4
1_{c_{ik}=c_{pk}}x_{p,g(i)}.
\]

For a fixed category and type, let `n_g` be the number of people of that type
in group `g`.  Summing the previous inequalities over all people shows that
this type contributes at least

\[
\sum_{g=1}^{10} n_g(n_g-1)
\]

to the original objective.  If the total number of people of the type is
`n=10q+r`, convexity (or a one-person exchange argument) shows that the
minimum is attained by `r` groups of size `q+1` and `10-r` groups of size
`q`.  Thus the exact type-wise lower bound is

\[
r(q+1)q+(10-r)q(q-1).
\]

Applying this formula to the recovered frequencies gives

```text
category 1:  76
category 2: 192
category 3:  64
category 4:  90
----------------
total:      422
```

Therefore every feasible solution of the original MPS has objective at least
422.

## 4. Matching feasible solution

The saved assignment has original MPS objective 422.  Its category/type counts
attain every independent balancing lower bound above, so its own-group overlap
is also exactly 422.  Hence the lower and upper bounds coincide.

## Reproduction

From this directory, run

```sh
python assign1_optimality_certificate.py assign1-10-4.mps \
  --solution assign1-10-4_gurobi_422.sol \
  --categories assign1-10-4_categories.json
```

The final line must be

```text
CERTIFIED OPTIMUM: 422
```

Gurobi 13.0.1 found the incumbent.  COPT 8.0.4 independently read and accepted
the same solution with objective 422.  Neither solver's branch-and-bound lower
bound is needed for the certificate.
