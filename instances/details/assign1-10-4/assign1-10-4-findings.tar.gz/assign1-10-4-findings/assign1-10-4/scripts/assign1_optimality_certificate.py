#!/usr/bin/env python3
"""Exact, solver-independent optimality certificate for assign1-10-4."""

from __future__ import annotations

import argparse
import gzip
import json
from collections import Counter, defaultdict
from dataclasses import dataclass
from decimal import Decimal
from pathlib import Path


N_ITEMS = 52
N_GROUPS = 10
N_CATEGORIES = 4


def open_text(path: Path):
    if path.suffix == ".gz":
        return gzip.open(path, "rt", encoding="latin-1")
    return path.open(encoding="latin-1")


def integer(text: str) -> int:
    value = Decimal(text.replace("D", "E").replace("d", "e"))
    if value != value.to_integral_value():
        raise ValueError(f"Expected an integer MPS coefficient, got {text}")
    return int(value)


def variable_number(name: str) -> int:
    if not name.startswith("C") or not name[1:].isdigit():
        raise ValueError(f"Unexpected variable name {name}")
    return int(name[1:])


@dataclass
class MPS:
    name: str
    row_types: dict[str, str]
    columns: dict[str, dict[str, int]]
    rhs: dict[str, int]
    lower: dict[str, int]
    upper: dict[str, int | None]
    integer_variables: set[str]


def parse_mps(path: Path) -> MPS:
    section = ""
    name = path.stem
    row_types: dict[str, str] = {}
    columns: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
    rhs: dict[str, int] = defaultdict(int)
    bound_records: list[list[str]] = []
    integer_variables: set[str] = set()
    integer_mode = False
    section_names = {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}

    with open_text(path) as handle:
        for raw in handle:
            tokens = raw.split()
            if not tokens or tokens[0].startswith("*"):
                continue
            if tokens[0] in section_names:
                section = tokens[0]
                if section == "NAME" and len(tokens) > 1:
                    name = tokens[1]
                continue
            if section == "ROWS":
                row_types[tokens[1]] = tokens[0]
            elif section == "COLUMNS":
                if "'MARKER'" in tokens:
                    if "'INTORG'" in tokens:
                        integer_mode = True
                    elif "'INTEND'" in tokens:
                        integer_mode = False
                    continue
                variable = tokens[0]
                if integer_mode:
                    integer_variables.add(variable)
                for row, coefficient in zip(tokens[1::2], tokens[2::2]):
                    columns[variable][row] += integer(coefficient)
            elif section == "RHS":
                for row, value in zip(tokens[1::2], tokens[2::2]):
                    rhs[row] += integer(value)
            elif section == "BOUNDS":
                bound_records.append(tokens)
            elif section == "RANGES":
                raise ValueError("RANGES are not expected in assign1-10-4")

    lower = {variable: 0 for variable in columns}
    upper: dict[str, int | None] = {variable: None for variable in columns}
    for tokens in bound_records:
        kind, variable = tokens[0], tokens[2]
        value = integer(tokens[3]) if len(tokens) > 3 else 0
        if kind == "LO":
            lower[variable] = value
        elif kind == "UP":
            upper[variable] = value
        elif kind == "FX":
            lower[variable] = upper[variable] = value
        elif kind == "BV":
            lower[variable], upper[variable] = 0, 1
            integer_variables.add(variable)
        else:
            raise ValueError(f"Unsupported bound type {kind}")
    return MPS(name, row_types, dict(columns), dict(rhs), lower, upper, integer_variables)


def read_solution(path: Path) -> dict[str, int]:
    values: dict[str, int] = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        tokens = raw.split()
        if len(tokens) == 2 and not tokens[0].startswith("#"):
            values[tokens[0]] = integer(tokens[1])
    return values


def validate_original(model: MPS, values: dict[str, int]) -> int:
    if set(values) != set(model.columns):
        missing = sorted(set(model.columns) - set(values))
        extra = sorted(set(values) - set(model.columns))
        raise ValueError(f"Solution variable mismatch: missing={missing[:10]} extra={extra[:10]}")
    for variable, value in values.items():
        if value < model.lower[variable]:
            raise ValueError(f"Lower bound violated by {variable}")
        if model.upper[variable] is not None and value > model.upper[variable]:
            raise ValueError(f"Upper bound violated by {variable}")
        if variable in model.integer_variables and not isinstance(value, int):
            raise ValueError(f"Integrality violated by {variable}")

    constraint_rows = [row for row, kind in model.row_types.items() if kind != "N"]
    for row in constraint_rows:
        activity = sum(entries.get(row, 0) * values[variable] for variable, entries in model.columns.items())
        rhs = model.rhs.get(row, 0)
        sense = model.row_types[row]
        valid = (sense == "E" and activity == rhs) or (sense == "G" and activity >= rhs) or (sense == "L" and activity <= rhs)
        if not valid:
            raise ValueError(f"Row {row} violated exactly: activity={activity}, sense={sense}, rhs={rhs}")

    objective_rows = [row for row, kind in model.row_types.items() if kind == "N"]
    if len(objective_rows) != 1:
        raise ValueError(f"Expected one objective row, got {objective_rows}")
    objective_row = objective_rows[0]
    return sum(entries.get(objective_row, 0) * values[variable] for variable, entries in model.columns.items())


def extract_weights(model: MPS) -> tuple[list[list[int]], list[str], list[list[str]]]:
    variables = sorted(model.columns, key=variable_number)
    if len(variables) != N_ITEMS + N_ITEMS * N_GROUPS:
        raise ValueError("Unexpected variable count")
    y = variables[:N_ITEMS]
    x = [variables[N_ITEMS + i * N_GROUPS : N_ITEMS + (i + 1) * N_GROUPS] for i in range(N_ITEMS)]
    weights = [[0] * N_ITEMS for _ in range(N_ITEMS)]

    for i in range(N_ITEMS):
        reference: list[int] | None = None
        for group in range(N_GROUPS):
            row = f"R{i * N_GROUPS + group + 1:04d}"
            if model.row_types.get(row) != "G" or model.rhs.get(row, 0) != -5:
                raise ValueError(f"Unexpected load row {row}")
            expected_variables = {y[i]}
            row_weights: list[int] = []
            if model.columns[y[i]].get(row, 0) != 1:
                raise ValueError(f"Missing load variable in {row}")
            for person in range(N_ITEMS):
                variable = x[person][group]
                expected_variables.add(variable)
                row_weights.append(-model.columns[variable].get(row, 0))
            actual_variables = {variable for variable, entries in model.columns.items() if entries.get(row, 0)}
            if actual_variables - expected_variables:
                raise ValueError(f"Unexpected variable in {row}")
            if reference is None:
                reference = row_weights
            elif reference != row_weights:
                raise ValueError(f"Group-dependent weights for person {i + 1}")
        weights[i] = reference or []

    quotas = [5] * 8 + [6] * 2
    for i in range(N_ITEMS):
        row = f"R{521 + i:04d}"
        terms = {variable: model.columns[variable].get(row, 0) for variable in model.columns if model.columns[variable].get(row, 0)}
        if model.row_types.get(row) != "E" or model.rhs.get(row, 0) != 1 or terms != {variable: 1 for variable in x[i]}:
            raise ValueError(f"Unexpected assignment row {row}")
    for group, quota in enumerate(quotas):
        row = f"R{573 + group:04d}"
        expected = {x[i][group]: 1 for i in range(N_ITEMS)}
        terms = {variable: model.columns[variable].get(row, 0) for variable in model.columns if model.columns[variable].get(row, 0)}
        if model.row_types.get(row) != "E" or model.rhs.get(row, 0) != quota or terms != expected:
            raise ValueError(f"Unexpected quota row {row}")
    return weights, y, x


def balanced_overlap(count: int) -> int:
    quotient, remainder = divmod(count, N_GROUPS)
    return remainder * (quotient + 1) * quotient + (N_GROUPS - remainder) * quotient * (quotient - 1)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("--solution", type=Path, required=True)
    parser.add_argument("--categories", type=Path, required=True)
    args = parser.parse_args()

    model = parse_mps(args.mps)
    solution = read_solution(args.solution)
    objective = validate_original(model, solution)
    weights, y, x = extract_weights(model)

    category_data = json.loads(args.categories.read_text(encoding="utf-8"))
    categories: list[list[int]] = category_data["item_categories"]
    if len(categories) != N_ITEMS or any(len(row) != N_CATEGORIES for row in categories):
        raise ValueError("Unexpected category assignment dimensions")
    for i in range(N_ITEMS):
        for j in range(N_ITEMS):
            reconstructed = int(i == j) + sum(categories[i][k] == categories[j][k] for k in range(N_CATEGORIES))
            if weights[i][j] != reconstructed:
                raise ValueError(f"Category reconstruction failed at ({i + 1},{j + 1})")

    frequencies: list[list[int]] = []
    per_category_bounds: list[int] = []
    for category in range(N_CATEGORIES):
        counts = Counter(categories[i][category] for i in range(N_ITEMS))
        category_frequencies = sorted(counts.values(), reverse=True)
        frequencies.append(category_frequencies)
        per_category_bounds.append(sum(balanced_overlap(count) for count in category_frequencies))
    lower_bound = sum(per_category_bounds)

    groups: list[list[int]] = [[] for _ in range(N_GROUPS)]
    for i in range(N_ITEMS):
        selected = [group for group in range(N_GROUPS) if solution[x[i][group]] == 1]
        if len(selected) != 1:
            raise ValueError(f"Person {i + 1} has assignments {selected}")
        groups[selected[0]].append(i)
    own_overlaps = [
        sum(weights[i][person] for person in groups[next(group for group in range(N_GROUPS) if i in groups[group])]) - 5
        for i in range(N_ITEMS)
    ]
    if any(solution[y[i]] < own_overlaps[i] for i in range(N_ITEMS)):
        raise ValueError("Original overlap variable is below its own-group overlap")

    category_overlap = 0
    for category in range(N_CATEGORIES):
        for group in groups:
            counts = Counter(categories[i][category] for i in group)
            category_overlap += sum(count * (count - 1) for count in counts.values())
    if category_overlap != sum(own_overlaps):
        raise ValueError("Category overlap does not match the original pairwise coefficients")
    if objective != lower_bound or category_overlap != lower_bound:
        raise ValueError(
            f"Certificate is not tight: objective={objective}, category_overlap={category_overlap}, lower_bound={lower_bound}"
        )

    print(f"model={model.name} rows={sum(kind != 'N' for kind in model.row_types.values())} variables={len(model.columns)}")
    print(f"category_frequencies={frequencies}")
    print(f"unavoidable_category_overlaps={per_category_bounds}")
    print(f"exact_original_solution_objective={objective}")
    print(f"incumbent_category_overlap={category_overlap}")
    print("proof: original objective >= own-group overlap >= independently balanced type-count overlap")
    print(f"CERTIFIED OPTIMUM: {objective}")


if __name__ == "__main__":
    main()
