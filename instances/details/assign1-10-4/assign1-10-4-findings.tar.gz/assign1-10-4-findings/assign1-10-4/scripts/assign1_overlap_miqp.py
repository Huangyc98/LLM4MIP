#!/usr/bin/env python3
"""Convex balanced-partition lower bound for assign1-10-4."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


N_ITEMS = 52
N_GROUPS = 10
QUOTAS = [5] * 8 + [6] * 2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("structure", type=Path)
    parser.add_argument("--seconds", type=float, default=600.0)
    parser.add_argument("--threads", type=int, default=32)
    parser.add_argument("--log", type=Path)
    parser.add_argument("--result", type=Path)
    parser.add_argument("--write-model", type=Path)
    parser.add_argument("--no-symmetry", action="store_true")
    args = parser.parse_args()

    data = json.loads(args.structure.read_text(encoding="utf-8"))
    weights: list[list[int]] = data["weights"]
    gram = [[weights[i][j] - int(i == j) for j in range(N_ITEMS)] for i in range(N_ITEMS)]

    model = gp.Model("assign1_overlap_convex_miqp")
    x = model.addVars(N_ITEMS, N_GROUPS, vtype=GRB.BINARY, name="x")
    for i in range(N_ITEMS):
        model.addConstr(gp.quicksum(x[i, g] for g in range(N_GROUPS)) == 1, name=f"assign_{i + 1}")
    for g, quota in enumerate(QUOTAS):
        model.addConstr(gp.quicksum(x[i, g] for i in range(N_ITEMS)) == quota, name=f"quota_{g + 1}")

    if not args.no_symmetry:
        for first, last in ((0, 8), (8, 10)):
            for g in range(first + 1, last):
                for i in range(N_ITEMS):
                    model.addConstr(
                        x[i, g] <= gp.quicksum(x[k, g - 1] for k in range(i)),
                        name=f"order_min_g{g + 1}_i{i + 1}",
                    )

    objective = gp.QuadExpr(-sum(gram[i][i] for i in range(N_ITEMS)))
    for g in range(N_GROUPS):
        for i in range(N_ITEMS):
            objective.add(gram[i][i] * x[i, g] * x[i, g])
            for j in range(i + 1, N_ITEMS):
                if gram[i][j]:
                    objective.add(2 * gram[i][j] * x[i, g] * x[j, g])
    model.setObjective(objective, GRB.MINIMIZE)

    if "groups" in data:
        groups: list[list[int]] = data["groups"]
        for g, group in enumerate(groups):
            members = set(group)
            for i in range(N_ITEMS):
                x[i, g].Start = int(i in members)

    model.Params.TimeLimit = args.seconds
    model.Params.Threads = args.threads
    model.Params.MIPFocus = 3
    model.Params.Symmetry = 2
    model.Params.Presolve = 2
    model.Params.PreQLinearize = 0
    model.Params.DisplayInterval = 10
    if args.log:
        model.Params.LogFile = str(args.log)
    if args.write_model:
        model.write(str(args.write_model))
    model.optimize()
    print(
        f"FINAL status={model.Status} solcount={model.SolCount} nodes={model.NodeCount} "
        f"bound={model.ObjBound} runtime={model.Runtime:.3f}"
    )
    if model.SolCount:
        print(f"objective={model.ObjVal}")
        if args.result:
            model.write(str(args.result))
    if model.Status == GRB.OPTIMAL:
        print(f"CERTIFIED LOWER BOUND: {round(model.ObjVal)}")


if __name__ == "__main__":
    main()
