#!/usr/bin/env python3
"""Extract and verify the hidden balanced-partition structure of assign1-10-4."""

from __future__ import annotations

import argparse
import json
import math
from collections import Counter
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


N_ITEMS = 52
N_GROUPS = 10


def read_solution(path: Path) -> dict[str, float]:
    values: dict[str, float] = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        tokens = raw.split()
        if len(tokens) == 2 and not tokens[0].startswith("#"):
            values[tokens[0]] = float(tokens[1])
    return values


def integer(value: float, label: str) -> int:
    rounded = round(value)
    if abs(value - rounded) > 1e-9:
        raise ValueError(f"{label} is not integral: {value}")
    return int(rounded)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("--solution", type=Path)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()

    model = gp.read(str(args.mps))
    model.update()
    variables = model.getVars()
    constraints = model.getConstrs()

    print(
        f"model={model.ModelName} rows={model.NumConstrs} cols={model.NumVars} "
        f"nonzeros={model.NumNZs} sense={'min' if model.ModelSense == 1 else 'max'}"
    )
    print(f"variable_types={Counter(v.VType for v in variables)}")
    print(f"constraint_senses={Counter(c.Sense for c in constraints)}")
    print(f"objective_coefficients={Counter(v.Obj for v in variables)}")
    print(f"bounds={Counter((v.LB, v.UB) for v in variables)}")

    if len(variables) != N_ITEMS + N_ITEMS * N_GROUPS:
        raise ValueError("Unexpected variable count")
    if len(constraints) != N_ITEMS * N_GROUPS + N_ITEMS + N_GROUPS:
        raise ValueError("Unexpected constraint count")

    y = variables[:N_ITEMS]
    x = [variables[N_ITEMS + i * N_GROUPS : N_ITEMS + (i + 1) * N_GROUPS] for i in range(N_ITEMS)]
    load_rows = [
        constraints[i * N_GROUPS : (i + 1) * N_GROUPS] for i in range(N_ITEMS)
    ]
    assign_rows = constraints[N_ITEMS * N_GROUPS : N_ITEMS * N_GROUPS + N_ITEMS]
    quota_rows = constraints[N_ITEMS * N_GROUPS + N_ITEMS :]

    weights = [[0] * N_ITEMS for _ in range(N_ITEMS)]
    for i in range(N_ITEMS):
        reference: list[int] | None = None
        for g in range(N_GROUPS):
            row = load_rows[i][g]
            if row.Sense != GRB.GREATER_EQUAL or integer(row.RHS, row.ConstrName) != -5:
                raise ValueError(f"Unexpected load row {row.ConstrName}")
            expression = model.getRow(row)
            coefficients = {expression.getVar(k).VarName: expression.getCoeff(k) for k in range(expression.size())}
            if coefficients.pop(y[i].VarName, None) != 1:
                raise ValueError(f"Missing load variable in {row.ConstrName}")
            row_weights = []
            for p in range(N_ITEMS):
                coefficient = coefficients.pop(x[p][g].VarName, 0.0)
                row_weights.append(-integer(coefficient, f"{row.ConstrName}/{x[p][g].VarName}"))
            if coefficients:
                raise ValueError(f"Unexpected variables in {row.ConstrName}: {coefficients}")
            if reference is None:
                reference = row_weights
            elif row_weights != reference:
                raise ValueError(f"Group-dependent weights in item {i + 1}")
        weights[i] = reference or []

    quotas: list[int] = []
    for i, row in enumerate(assign_rows):
        expression = model.getRow(row)
        terms = {expression.getVar(k).VarName: expression.getCoeff(k) for k in range(expression.size())}
        expected = {x[i][g].VarName: 1.0 for g in range(N_GROUPS)}
        if row.Sense != GRB.EQUAL or row.RHS != 1 or terms != expected:
            raise ValueError(f"Unexpected assignment row {row.ConstrName}")
    for g, row in enumerate(quota_rows):
        expression = model.getRow(row)
        terms = {expression.getVar(k).VarName: expression.getCoeff(k) for k in range(expression.size())}
        expected = {x[i][g].VarName: 1.0 for i in range(N_ITEMS)}
        if row.Sense != GRB.EQUAL or terms != expected:
            raise ValueError(f"Unexpected quota row {row.ConstrName}")
        quotas.append(integer(row.RHS, row.ConstrName))

    symmetric = all(weights[i][j] == weights[j][i] for i in range(N_ITEMS) for j in range(N_ITEMS))
    diagonal = [weights[i][i] for i in range(N_ITEMS)]
    coefficient_counts = Counter(value for row in weights for value in row)
    row_sums = [sum(row) for row in weights]
    average_bounds = [max(0, math.ceil(total / N_GROUPS) - 5) for total in row_sums]
    print(f"quotas={quotas} total={sum(quotas)}")
    print(f"weights_symmetric={symmetric} diagonal={Counter(diagonal)} values={coefficient_counts}")
    print(f"row_sums={row_sums}")
    print(f"average_integer_bounds={average_bounds} sum={sum(average_bounds)}")

    report: dict[str, object] = {
        "name": model.ModelName,
        "quotas": quotas,
        "weights": weights,
        "row_sums": row_sums,
        "average_integer_bounds": average_bounds,
    }

    if args.solution:
        values = read_solution(args.solution)
        groups: list[list[int]] = [[] for _ in range(N_GROUPS)]
        for i in range(N_ITEMS):
            selected = [g for g in range(N_GROUPS) if values.get(x[i][g].VarName, 0.0) > 0.5]
            if len(selected) != 1:
                raise ValueError(f"Item {i + 1} has assignments {selected}")
            groups[selected[0]].append(i)

        exact_y: list[int] = []
        load_vectors: list[list[int]] = []
        for i in range(N_ITEMS):
            loads = [sum(weights[i][p] for p in groups[g]) for g in range(N_GROUPS)]
            load_vectors.append(loads)
            exact_y.append(max(loads) - 5)
        saved_y = [integer(values.get(variable.VarName, 0.0), variable.VarName) for variable in y]
        if saved_y != exact_y:
            raise ValueError(f"Saved y differs from exact y: saved={saved_y}, exact={exact_y}")
        slacks = [exact_y[i] - average_bounds[i] for i in range(N_ITEMS)]
        print(f"solution_groups_1based={[[item + 1 for item in group] for group in groups]}")
        print(f"solution_y={exact_y} objective={sum(exact_y)}")
        print(f"solution_slack_over_average={slacks} total={sum(slacks)} distribution={Counter(slacks)}")
        print(f"solution_max_loads={[max(loads) for loads in load_vectors]}")
        report.update(
            {
                "groups": groups,
                "solution_y": exact_y,
                "load_vectors": load_vectors,
                "slacks": slacks,
                "objective": sum(exact_y),
            }
        )

    if args.json:
        args.json.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print(f"wrote_json={args.json}")


if __name__ == "__main__":
    main()
