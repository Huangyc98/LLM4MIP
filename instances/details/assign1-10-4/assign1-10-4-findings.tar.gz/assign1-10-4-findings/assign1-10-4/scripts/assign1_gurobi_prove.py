#!/usr/bin/env python3
"""Try to prove that assign1-10-4 has no solution below a target objective."""

from __future__ import annotations

import argparse
import math
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


N_ITEMS = 52
N_GROUPS = 10


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("--target", type=int, default=421)
    parser.add_argument("--seconds", type=float, default=300.0)
    parser.add_argument("--threads", type=int, default=32)
    parser.add_argument("--log", type=Path)
    parser.add_argument("--result", type=Path)
    parser.add_argument("--no-symmetry", action="store_true")
    parser.add_argument("--concurrent", type=int, default=1)
    args = parser.parse_args()

    model = gp.read(str(args.mps))
    variables = model.getVars()
    constraints = model.getConstrs()
    if len(variables) != 572 or len(constraints) != 582:
        raise ValueError("Unexpected assign1-10-4 dimensions")

    y = variables[:N_ITEMS]
    x = [variables[N_ITEMS + i * N_GROUPS : N_ITEMS + (i + 1) * N_GROUPS] for i in range(N_ITEMS)]

    # Every load-row RHS is integral once x is integral, so an integer y vector
    # always exists whenever the original continuous-y formulation is feasible.
    for i, variable in enumerate(y):
        row_sum = 0
        load_row = constraints[i * N_GROUPS]
        expression = model.getRow(load_row)
        for k in range(expression.size()):
            candidate = expression.getVar(k)
            coefficient = expression.getCoeff(k)
            if candidate.index != variable.index:
                row_sum += round(-coefficient)
        variable.VType = GRB.INTEGER
        variable.LB = max(variable.LB, math.ceil(row_sum / N_GROUPS) - 5)

    model.addConstr(gp.quicksum(y) <= args.target, name=f"objective_at_most_{args.target}")
    # Keep the original objective as a node-selection signal even though the
    # cutoff row turns the task into a feasibility proof.
    model.setObjective(gp.quicksum(y), GRB.MINIMIZE)

    # Canonicalize equal-capacity groups by increasing minimum item.  For
    # adjacent groups a,b this states min(a) < min(b).  Every unlabeled
    # partition has exactly one such ordering, so these constraints are safe.
    if not args.no_symmetry:
        for first, last in ((0, 8), (8, 10)):
            for g in range(first + 1, last):
                for i in range(N_ITEMS):
                    model.addConstr(
                        x[i][g] <= gp.quicksum(x[k][g - 1] for k in range(i)),
                        name=f"order_min_g{g + 1}_i{i + 1}",
                    )

    model.Params.TimeLimit = args.seconds
    model.Params.Threads = args.threads
    model.Params.MIPFocus = 3
    model.Params.Heuristics = 0.0
    model.Params.Symmetry = 2
    model.Params.Presolve = 2
    model.Params.Cuts = 2
    model.Params.ConcurrentMIP = args.concurrent
    model.Params.DisplayInterval = 10
    if args.log:
        model.Params.LogFile = str(args.log)

    model.optimize()
    print(
        f"FINAL status={model.Status} solcount={model.SolCount} "
        f"nodes={model.NodeCount} runtime={model.Runtime:.3f}"
    )
    if model.SolCount:
        original_objective = sum(variable.X for variable in y)
        print(f"COUNTEREXAMPLE objective={original_objective}")
        if args.result:
            model.write(str(args.result))
    elif model.Status == GRB.INFEASIBLE:
        print(f"CERTIFIED: no solution with objective <= {args.target}")


if __name__ == "__main__":
    main()
