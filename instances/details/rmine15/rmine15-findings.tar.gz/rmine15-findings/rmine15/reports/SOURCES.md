# rmine15 背景资料（核查于 2026-09-08）

本文件只记录本次研究实际采用的官方实例页、作者论文或论文预印本。`rmine15` 的 MIPLIB 页面本身注明没有专属 bibliographic information，因此实例背景需从提交者参与的同类模型论文交叉确认。

1. **MIPLIB 官方实例页**  
   https://miplib.zib.de/instance_details_rmine15.html  
   用途：确认状态为 open、提交者 Daniel Espinoza、`rmine` 组、公开目标 `-5018.819990999996`，以及“立方体矿体、多个时期、每时期两个 knapsack constraints”的官方描述。页面还记录公开解由 Gurobi 9.1 NoRel heuristic 于 2020-11-25 找到。

2. **MIPLIB 官方原始 MPS**  
   https://miplib.zib.de/WebData/instances/rmine15.mps.gz  
   用途：所有结构恢复、求解和可行性审计均以此文件为准。

3. **MIPLIB 官方公开解（solution 2）**  
   https://miplib.zib.de/downloads/solutions/rmine15/2/rmine15.sol.gz  
   用途：公开 incumbent 热启动与逐变量、逐行独立复核。

4. **Chicoisne, Espinoza, Goycoolea, Moreno, Rubio (2012), _A New Algorithm for the Open-Pit Mine Production Scheduling Problem_, Operations Research 60(3):517–528.**  
   DOI: https://doi.org/10.1287/opre.1120.1050  
   官方期刊页：https://pubsonline.informs.org/doi/abs/10.1287/opre.1120.1050  
   用途：确认累计变量解释、坡面 precedence、逐期容量及折现净现值背景；论文提出单容量情形的 LP 分解、拓扑排序舍入和 local search。这直接支持本研究优先做“按时期精确重排窗口”，而非只跑匿名 MIP 参数。

5. **Bienstock and Zuckerberg (2009), _A New LP Algorithm for Precedence Constrained Production Scheduling_.**  
   作者公开预印本：https://optimization-online.org/wp-content/uploads/2009/08/2380.pdf  
   用途：论文把矿山调度刻画为 maximum-weight closure/min-cut 加少量 side constraints；这与本实例中 358,365 条 precedence 行、仅 30 条容量行完全吻合。其结论解释了为什么 Lagrangian/min-cut 和分解是自然的全局下界路线。

6. **Boland, Froyland, Fricke (2007/2009), _A strengthened formulation and cutting planes for the open pit mine production scheduling problem_.**  
   Optimization Online：https://optimization-online.org/2007/03/1624/  
   用途：作者把 precedence 与 production capacity 结合为 precedence-constrained knapsack，并使用 cover/clique 类不等式加强 LP；本次 Gurobi 试验因而开启 aggressive cover/MIR/flow-cover cuts，并将进一步的 induced-cover separation 列为主要后续方向。

7. **Rivera Letelier, Espinoza, Goycoolea, Moreno, Muñoz (2020), _Production Scheduling for Strategic Open Pit Mine Planning: A Mixed-Integer Programming Approach_, Operations Research 68(5):1425–1444.**  
   DOI: https://doi.org/10.1287/opre.2019.1965  
   用途：确认现代大规模方法依赖 preprocessing、production cuts、heuristics 和定制 branch-and-bound；也说明在大实例上严格闭合 gap 往往远比找到高质量可行解困难。

## 与本实例的直接结构对应

- `x_Bb_t=1`：矿块 `b` 在时期 `t` 结束前已经开采（累计变量）。
- `tprec_Bb_t`：`x[b,t] <= x[b,t+1]`，保证累计状态单调。
- `gprec_Bb_Bp_t`：`x[b,t] <= x[p,t]`，开采下层块前必须先开采其坡面前驱块。
- `tcap_c{0,1}_t`：两类资源对增量 `x[b,t]-x[b,t-1]` 的逐期容量上界。
- 目标系数在同一矿块上按约 0.9 比例跨期变化，对应折现净现值；因此在容量和坡面约束允许时，有价值矿块倾向提前、成本矿块倾向推迟。
