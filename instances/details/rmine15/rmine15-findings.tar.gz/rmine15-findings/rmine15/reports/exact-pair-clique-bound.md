# rmine15 precedence-clique cut 实验

## 结论

以 `agent-dual-family/rmine15/rmine15-prefix-pairs.mps.gz` 中 121 条已验证 pair cuts 为固定基线，三轮有限 clique separation 得到：

| 项目 | 数值 |
|---|---:|
| 121-pair 基线 root LP | -5042.229627238623 |
| 加 clique 后 root LP | -5042.036233392005 |
| root LP 额外提高 | 0.193393846618 |
| 新增 size>=3 clique cuts | 61 |
| 最大已加入 clique | 12 个节点 |
| separation 用时 | 139.49 s |

每轮连续 LP：

| 轮次 | 新增 cuts | root LP | 相对 pair 基线提高 |
|---:|---:|---:|---:|
| 1 | 40 | -5042.040480485482 | 0.189146753141 |
| 2 | 20 | -5042.036466230039 | 0.193161008584 |
| 3 | 1 | -5042.036233392005 | 0.193393846618 |

对 pair 基线和最终模型分别用 LP row dual 生成 exact max-flow/min-cut 证书，均独立通过：

```text
121-pair strict LB
  = -25211148136193234027920119679 / 5000000000000000000000000
  = -5042.229627238646806

pair + clique strict LB
  = -5042036233392018593064500651 / 1000000000000000000000000
  = -5042.036233392018593

strict improvement = 0.193393846628213
```

这说明 clique 改善不是 root-LP 数值噪声。不过它仍低于工作区 COPT 10h 的数值 dual `-5026.70481`；本实验回答的是 clique 对结构化 root relaxation 的增益，不宣称刷新 COPT 10h 全局下界。

## 有限候选图

脚本从 family 结果读取 121 条 seed pair，仅在其出现的时期 `0,8,9,10` 建图。每期保留所有 seed 端点，并加入最多 60 个高 LP 值 fractional、60 个高 closure-pressure fractional 和 30 个高 pressure integral 候选。所有 pair 均回到官方 MPS，用精确有理数重算同周期 precedence closure union 和累计资源容量。

| period | seed nodes | candidate nodes | exact edges | size>=3 maximal cliques | 最大候选 clique | 枚举截断 |
|---:|---:|---:|---:|---:|---:|---|
| 0 | 5 | 145 | 685 | 915 | 7 | false |
| 8 | 56 | 156 | 1016 | 1983 | 12 | false |
| 9 | 22 | 152 | 537 | 462 | 7 | false |
| 10 | 16 | 150 | 33 | 0 | 2 | false |

共 2,271 条 candidate-graph edges，四期的 maximal-clique enumeration 均完整结束，没有触及每期 100,000 上限。这里的 maximal 只相对于明确记录的有限候选图，并非完整 42,438 变量 conflict graph。

新增 clique 分布：

- period 8：1 条 size-4、16 条 size-11、4 条 size-12；
- period 9：2 条 size-3、4 条 size-4、14 条 size-5、3 条 size-6、17 条 size-7；
- periods 0、10 没有违反的 size>=3 clique。

separation 时的 clique violation 为约 `0.05363` 至 `1.75164`。

## 精确验证

`validate_clique_rmine15.py` 独立重新读取官方 MPS，并验证：

1. 121/121 条 seed pair 都由原始同周期 closure union 的严格累计容量超额推出；
2. 四个候选图被完整重建，2,271/2,271 条边及 graph hash 一致；
3. 61/61 条 clique 中的每一对节点都是 exact conflict；
4. seed MPS 的 `certified_family_pair_*` rows 与 family 结果逐项一致；
5. 最终 MPS 未改变变量、目标或 precedence arcs；
6. 新增 `certified_clique15_*` rows 系数全为 1、RHS 为 1，且无额外 rows。

所有已加入 clique 内 pair 的最小精确超额为：

```text
13007841 / 1000000 = 13.007841
```

官方 MPS SHA-256：

```text
7ec66fb34e25652563e276739f579cc2968807edccf40322b6b3f9b7acd522c7
```

121-pair MPS SHA-256：

```text
4a9fa814e0eb0f36ecb819737a9cbe6bad3710787546a08ab7f10f236cd7fadc
```

pair+clique MPS SHA-256：

```text
1fdcf3c988f8719588766f576c77311bd88012878fcf893d47564d03538ecdae
```

严格下界同样需要两层证据：validator 先证明 121 pair + 61 clique 对官方模型有效；flow=cut certificate 再证明增强模型的有理下界。

## 文件

- `../artifacts/proof-bundle/agent-clique-rmine15/clique_experiment_rmine15.py`：有限候选图、maximal/maximum-weight clique separation；
- `../artifacts/proof-bundle/agent-clique-rmine15/validate_clique_rmine15.py`：独立原始-MPS cut/graph/model validator；
- `../artifacts/proof-bundle/agent-clique-rmine15/run/result.json`：完整候选节点、graph hashes、逐轮和 clique pair witnesses；
- `../artifacts/proof-bundle/agent-clique-rmine15/run/validation.json`：独立 cut 验证结果；
- `../artifacts/proof-bundle/agent-clique-rmine15/run/rmine15-pairs-plus-cliques.mps.gz`：121 pair + 61 clique 模型；
- `../artifacts/exact-bound/exact-lb-lambda.json`、
  `../artifacts/exact-bound/exact-lb-cert.json.gz` 和
  `../artifacts/exact-bound/exact-lb-verification.json`：最终严格证书及复核结果。

为避免重复，发布包没有保留已被最终证书支配的 pair-only flow/cut 文件；pair
cuts 本身、pair-enhanced MPS 和 validator 均完整保留。逐层命令见
`../artifacts/proof-bundle/README.md`。

## 边界

- 只在四个 seed 时期构造有限候选图，未做完整 conflict-graph separation；
- 只加入 size>=3 clique，收益不是新增 size-2 pair rows 造成；
- clique 的不同边可由不同资源证明冲突；逐对不可共存已经足以推出 `sum_{i in Q}x_i<=1`；
- 全程只解连续 LP、有限图枚举和 closure min-cut，没有启动长原始 MIP；
- 总运行明显低于 15 分钟预算。
