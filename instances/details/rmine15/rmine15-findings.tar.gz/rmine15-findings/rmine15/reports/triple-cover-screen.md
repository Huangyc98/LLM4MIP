# rmine15 genuine minimal triple-cover screen

## Outcome

This was a bounded root-LP separation experiment on the already strengthened
pair-plus-clique model.  It generated **no new triple-cover row** in the part of
the candidate space reached before the wall-clock deadline.  Consequently, the
written enhanced MPS is byte-for-byte identical to the baseline, and the root
LP did not change.

| Quantity | Result |
|---|---:|
| Pair-plus-clique baseline root LP (floating point) | `-5042.036233392008` |
| Triple-strengthened root LP (floating point) | `-5042.036233392008` |
| Root-LP improvement | `0` |
| New genuine minimal triple cuts | `0` |
| Existing strict flow=cut lower bound, still applicable | `-5042.036233392018593` |
| Configured wall limit / observed elapsed time | `600 s` / `605.441 s` |

The strict lower bound above is not a new certificate: because the output MPS
has the same SHA-256 as the pair-plus-clique baseline, its independently
verified certificate remains applicable unchanged.

## Exact cut definition used

For three distinct variables in one period, the experiment forms each
variable's precedence closure from the **official rmine15 MPS**.  A retained
triple must satisfy both conditions:

1. every one of its three proper pairs has exact rational closure-union weight
   no larger than capacity for **both** cumulative resources; and
2. the full three-way closure union has exact rational weight strictly larger
   than capacity for at least one cumulative resource.

Only then is `x_i + x_j + x_k <= 2` valid as a genuine minimal triple cover.
No floating-point capacity comparison is used to accept a cut.

## Finite screen coverage

The four intended seed periods were `0, 8, 9, 10`, inherited from the prior
rmine15 conflict-graph experiment.  The deadline allowed period 0 to finish and
period 8 to run partially; periods 9 and 10 were not reached.

| Period | Status | Candidates | Candidate pairs | Exactly pair-compatible | LP-eligible triples examined | Genuine minimal triples found |
|---:|---|---:|---:|---:|---:|---:|
| 0 | complete for selected candidates | 86 | 3,655 | 3,567 | 93,380 | 0 |
| 8 | partial; deadline reached | 93 | 4,278 | 4,278 | 37,825 | 0 |
| 9 | not reached | — | — | — | 0 | — |
| 10 | not reached | — | — | — | 0 | — |
| **Total actually examined** |  |  | **7,933** | **7,845** | **131,205** | **0** |

`LP-eligible` means the current root-LP values summed to more than 2 before the
remaining exact pair-compatibility and triple-overload tests.  Candidate counts
can exceed the nominal `70` parameter because this version takes the union of
the top 70 by LP value and the top 23 by LP-value/closure-pressure score.

This is therefore a negative result for a **finite deterministic subset**, not
a proof that rmine15 has no genuine minimal triple covers or no useful such
cuts outside the screened subset.

## Independent validation and provenance

The independent validator reparsed the official, baseline, and output MPS
files; checked that variables, objective, precedence arcs, and every baseline
side row were unchanged; and confirmed that no unexpected row was added.
Since zero cuts were generated, per-cut proper-pair and overload verification is
vacuous.  It reported `verified: true` and
`enhanced_rows_exactly_verified: true`.

| Artifact | SHA-256 |
|---|---|
| Official `rmine15.mps.gz` | `7ec66fb34e25652563e276739f579cc2968807edccf40322b6b3f9b7acd522c7` |
| Pair-plus-clique baseline MPS | `1fdcf3c988f8719588766f576c77311bd88012878fcf893d47564d03538ecdae` |
| Output MPS | `1fdcf3c988f8719588766f576c77311bd88012878fcf893d47564d03538ecdae` |
| Published summary JSON | `583bb9ab63eecf4637e17512fc3d9c6e0a023eb73b71451b250549703124fc72` |
| Published validation JSON | `24472cf45b313fc9f90ecd70a1f1589856f1864429f3f73354bfb27cd45717ff` |

The publication bundle stores the primary machine-readable outputs as
`../artifacts/triple-cover-screen-summary.json` and
`../artifacts/triple-cover-screen-validation.json`.  The zero-cut output MPS
was byte-identical to the pair-plus-clique baseline and is therefore not
duplicated.  No long integer MIP was started.
