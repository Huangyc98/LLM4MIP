# `rmine15` 深入研究报告

研究日期：2026-09-08（Asia/Shanghai）  
实际研究区间：00:10:28–00:52:11  
实际墙钟时间：2,502.96 秒（41 分 42.96 秒）  
用户要求的最低探索时间：2,400 秒，已满足。

## 结论先行

本轮找到一份**严格可行的新 primal solution**：

- MIPLIB 公开目标（直接按原始 MPS 十进制系数重算）：`-5018.819991000000004879`
- 新目标：`-5018.823005000000004879`
- 改善：`0.003014000000000000`
- 新解文件：[`results/rmine15-improved-5018.823005.sol`](../solutions/rmine15-improved-5018.823005.sol)
- SHA-256：`98EE687E2B4CDA23C78944EA438A6A5A72EA1F7B045BDDF82C0DC6FFD67B9C75`

这不是浮点容差造成的假改善：新解先由 Gurobi 在原始 MPS 的 358,395 行上重算，再由一个不调用 Gurobi 的独立 MPS/solution 解析器以 50 位 `Decimal` 逐项复核；变量界、整数性和所有行的最大违反均为精确的 `0`。

但是，本轮**没有证明全局 optimal**。现有全局下界仍与新 primal 有距离；所有“零 gap”结论仅适用于报告中明确固定的局部邻域。

## 1. 数据来源和模型背景

MPS 和公开解均直接从 MIPLIB 官方页面下载，文件哈希如下：

| 文件 | SHA-256 |
|---|---|
| `rmine15.mps.gz` | `7EC66FB34E25652563E276739F579CC2968807EDCCF40322B6B3F9B7ACD522C7` |
| `rmine15-public.sol.gz` | `7C4AF284B2DCB16BAF897AD5D76241DDD02E4E9503BCFFD2876502143471E399` |

MIPLIB 将其描述为：在一个立方体矿体上进行多时期露天矿生产调度，每个时期有两条 knapsack 容量约束。公开 incumbent 是 Edward Rothberg 于 2020-11-25 使用 Gurobi 9.1 NoRel heuristic 找到的。

相关论文表明，该类问题的核心是：决定哪些矿块开采、何时开采，在坡面稳定性 precedence 和逐期资源容量下最大化折现净现值。若去掉少量容量边约束，模型就是 maximum-weight closure，可化为最小 `s-t` cut；论文也建议使用拓扑舍入、local search、production/cover cuts 和定制 branch-and-bound。

完整的一手资料与各资料在本研究中的用途见 [`sources.md`](SOURCES.md)。

## 2. Gurobi 结构读取结果

首先只读取原始 MPS，没有先假设问题语义。Gurobi 13.0.2 给出：

| 项目 | 数量 |
|---|---:|
| 变量 | 42,438 |
| `0 <= x <= 1` 的整数变量 | 42,438 |
| 连续变量 | 0 |
| 约束 | 358,395 |
| 非零系数 | 879,732 |
| 矿块 | 3,375 |
| 时期 | 15（`t=0,...,14`） |

行名、系数和变量名可以无歧义地恢复出：

| 约束族 | 数量 | 含义 |
|---|---:|---|
| `gprec_*` | 319,302 | 同期空间坡面 precedence：`x[b,t] <= x[p,t]` |
| `tprec_*` | 39,063 | 跨期累计单调性：`x[b,t] <= x[b,t+1]` |
| `tcap_*` | 30 | 15 个时期、每期 2 类资源的增量容量 |

去重后有 25,886 条矿块级空间 precedence arc。累计变量的语义是：`x_Bb_t=1` 表示矿块 `b` 在时期 `t` 结束前已经开采。容量行对 `x[b,t]-x[b,t-1]` 计量，所以限制的是当期新开采量。

该结构很特殊：358,365 条行保持闭包/网络结构，只有 30 条容量行破坏它。这也是为什么本研究同时采用“按时期精确重排”和“Lagrangian 最大闭包”两条路线。

结构和公开解审计原始记录：[`results/structure-public-audit.json`](../artifacts/structure-public-audit.json)。

## 3. 公开解特征

公开解开采 3,303 个矿块，72 个未开采。每期开采量为：

`234, 229, 228, 220, 221, 220, 214, 222, 205, 225, 229, 217, 225, 217, 197`。

容量利用率非常高：30 条容量行中，20 条 slack 小于 10，27 条小于 100；最小 slack 只有 `0.134039`。因此简单地把高价值矿块提前通常不可行，必须同时把若干矿块推迟或跨多个时期形成资源平衡交换。

另一个有用事实是：72 个未开采矿块在最后一期的单独目标系数均为正。将它们加入最终 pit 本身会增加最小化目标；只有当一组矿块的 precedence/收益组合能够抵消这些成本时，改变最终开采集合才可能有利。

详细排产和容量活动见 [`results/public-schedule-summary.json`](../artifacts/public-schedule-summary.json)。

## 4. 求解路线与结果

### 4.1 通用 Gurobi 强 primal 基线

以公开解热启动，配置 aggressive cuts、较高 heuristic 比例、RINS、feasibility pump 和 180 秒 NoRel，共运行约 600 秒。

结果：没有找到优于公开解的解，也没有完成根节点。这个结果说明继续只堆通用参数的边际价值不高。根 relaxation 的 barrier 曾得到约 `-5042.48297` 的数值点，但 crossover 在时限内未完成，因此本报告不把它登记为新的已完成下界结果。

证据：[`results/gurobi-primal-600s.json`](../artifacts/gurobi-primal-600s.json) 和 [`logs/gurobi-primal-600s.log`](../logs/gurobi-primal-600s.log)。

### 4.2 实例专用的时期窗口精确重排

对 seed schedule 中开采时期落在连续窗口 `[a,b]` 的所有矿块：

1. 窗口外矿块的全部累计变量固定为 seed；
2. 窗口内矿块可以在窗口中任意、联合地重新分配开采时期；
3. 所有原始 precedence 和两类容量约束保留；
4. 使用原始 MPS 目标，设置 `MIPGap=0`、`MIPGapAbs=0`；
5. 只有 solver objective 与 bound 闭合时才标记为局部零 gap。

这不是逐块 greedy move。一个窗口内几百至上千个矿块可以成组交换，Gurobi 在原始模型上对该受限子问题完整 branch-and-cut。

#### 第一轮：公开解为 seed

- 14 个相邻双时期窗口全部零 gap 求优，均无改善。
- 13 个连续三时期窗口全部零 gap 求优。
- 唯一发生改善的是 `[7,9]`，得到 `-5018.823005`。

双时期邻域看不到这次改善，是因为新排程需要三个时期共同形成容量平衡循环，包含一次 `7 -> 9` 的跨两期移动。

证据：

- [`results/pair-windows-exact-30s.json`](../artifacts/pair-windows-exact-30s.json)
- [`results/triple-windows-exact-60s.json`](../artifacts/triple-windows-exact-60s.json)

注意：`pair-windows-30s.json` 是发现默认 relative gap 会过早返回 `OPTIMAL` 后保留的 pilot，不能作为零 gap 证据；上面的 `pair-windows-exact-30s.json` 才是纠正后的正式结果。

#### 第二轮：新解为 seed

重新对全部 13 个连续三时期窗口求解，13 个都在零 gap 下返回同一个新目标。因此可以准确地说：

> 在保持最终开采集合不变、窗口外开采时期不变的条件下，新解是“任意连续三个时期联合重排”邻域的局部最优解。

这不是全局最优证明，因为同时跨越四个或更多时期的调整仍可能改进。

证据：[`results/triple-windows-iteration2.json`](../artifacts/triple-windows-iteration2.json)。

#### 更大的窗口

| 邻域组 | 试验数 | 零 gap | Time limit | 新改善 |
|---|---:|---:|---:|---:|
| 连续四时期 | 12 | 6 | 6 | 0 |
| 晚期选择邻域（含 72 个未开采块） | 4 | 3 | 1 | 0 |
| 聚焦五时期 `[5,9]`,`[6,10]`,`[7,11]` | 3 | 0 | 3 | 0 |
| 五时期 `[8,12]` | 1 | 0 | 1 | 0 |

四时期中完成证明的窗口是 `[1,4]`,`[2,5]`,`[3,6]`,`[4,7]`,`[8,11]`,`[11,14]`；其他四时期窗口只可表述为“90 秒内未找到改善”。

晚期选择邻域会同时释放窗口内已开采块和全部 72 个未开采块，因此可以改变最终 pit membership。`[13,14]`,`[12,14]`,`[11,14]` 均零 gap 且无改善；`[10,14]` 在 120 秒时限内未闭合。

所有五时期试验均为 time limit，不能写成局部最优证明。

证据：

- [`results/four-windows-exact-90s.json`](../artifacts/four-windows-exact-90s.json)
- [`results/late-selection-windows-120s.json`](../artifacts/late-selection-windows-120s.json)
- [`results/focused-five-windows-180s.json`](../artifacts/focused-five-windows-180s.json)
- [`results/focused-five-right-120s.json`](../artifacts/focused-five-right-120s.json)

正式窗口试验总计 60 个，其中 49 个零 gap 完成、11 个 time limit。

### 4.3 Lagrangian 最大闭包下界

将 30 条容量行以非负乘子 dualize，保留 358,365 条 precedence 行。每次 Lagrangian 子问题都是闭包多面体上的线性优化；实验中 100 次 oracle 解的最大 fractionality 均为 0。

采用 projected Polyak subgradient：

- 首次 closure LP/oracle 约 262.6 秒；
- 热启动后大部分迭代约 0.4–0.8 秒；
- 525 秒内完成 100 次 oracle；
- 最佳数值 Lagrangian 下界：`-5053.960722050726`（第 95 次）。

这个值是结构正确但较弱的数值下界，明显没有超过工作区既有 COPT 10 小时 run 的 `-5026.70481`。因此本轮**不声称 dual bound 改进**。主要经验是朴素 subgradient 在 30 维容量乘子上振荡明显；下一轮若推进证明端，应使用 Bienstock–Zuckerberg 式 restricted master/bundle stabilization，而不是继续增加 subgradient 次数。

证据：[`results/lagrangian-closure-600s.json`](../artifacts/lagrangian-closure-600s.json)。该下界使用浮点 Gurobi 和浮点乘子，属于 numerical bound，不是有理数证书。

## 5. 新解具体怎样改进

最终开采集合没有变化：仍为 3,303 个开采、72 个未开采。改变的是 34 个矿块的开采时期，共 35 个累计二进制变量翻转：

| 移动 | 矿块数 |
|---|---:|
| `7 -> 8` | 13 |
| `8 -> 7` | 12 |
| `9 -> 8` | 5 |
| `8 -> 9` | 3 |
| `7 -> 9` | 1 |

对应每期开采块数变化：

- 第 7 期：222 → 220
- 第 8 期：205 → 208
- 第 9 期：225 → 224

目标贡献变化为：

- 第 7 期：`+0.017541`（变差）
- 第 8 期：`-0.063467`（改善）
- 第 9 期：`+0.042912`（变差）
- 合计：`-0.003014`（净改善）

这显示了问题的典型特征：改进不是把单个“最好”的块提前，而是让一组矿块在两类几乎饱和的容量和 precedence 下完成跨期交换。第 8 期资源 slack 从公开解的 `(1.747079, 12.310514)` 收紧为 `(0.799249, 6.712778)`；第 9 期则释放一部分容量。

逐块变更明细：[`results/public-vs-new.json`](../artifacts/public-vs-new.json)。

## 6. 严格验证

### 6.1 原始 MPS + Gurobi 独立重算

将 `.sol` 重新读成数值向量，并直接用原始 MPS 的 bounds、integrality 和每一行系数计算：

| 指标 | 结果 |
|---|---:|
| 重算目标 | `-5018.823005` |
| 最大 bound violation | 0 |
| 最大 integrality violation | 0 |
| 最大 row violation | 0 |
| `>1e-9` 的违反行 | 0 |

证据：[`results/new-incumbent-audit.json`](../artifacts/new-incumbent-audit.json)。

### 6.2 不依赖 Gurobi 的 Decimal 复核

独立脚本直接解析压缩 MPS 的 ROWS/COLUMNS/RHS/BOUNDS 段和 `.sol`，以 50 位 `Decimal` 累加 879,732 个系数：

| 指标 | 公开解 | 新解 |
|---|---:|---:|
| 精确十进制目标 | `-5018.819991000000004879` | `-5018.823005000000004879` |
| 行违反 | 0 | 0 |
| 界违反 | 0 | 0 |
| 整数违反 | 0 | 0 |

证据：

- [`results/public-exact-decimal-audit.json`](../artifacts/public-exact-decimal-audit.json)
- [`results/new-incumbent-exact-decimal-audit.json`](../artifacts/new-incumbent-exact-decimal-audit.json)

## 7. 为什么还不能说 optimal

工作区已有 COPT 10 小时试验记录的数值 dual bound 为 `-5026.70481`。与新 primal 的剩余区间为：

- 绝对 gap：`7.881805`
- 相对 gap：约 `0.157045%`

该 COPT 值只是已有 solver run 的数值输出，不是本轮生成的独立证书，MIPLIB 实例页也没有列出官方 dual。因此即便 primal 已被严格验证，也不能把 `rmine15` 标成 optimal。

本报告中的“局部证明”同样有严格边界：它们是 Gurobi 对固定邻域在 `MIPGap=0` 下完成的数值 branch-and-cut 结果，没有输出可由第三方 proof checker 独立重放的全局证书。

## 8. 经验总结与下一步

1. **三时期是该实例的最小有效交换尺度。** 双时期全部局部最优，但三时期立刻找到改善，说明容量交换需要跨至少三期闭环。
2. **公开解已经非常强。** 34 个矿块的联合重排只改善 `0.003014`，且新解随后通过全部三时期窗口复查。
3. **最终 pit membership 的晚期局部改变不容易。** 释放全部 72 个未开采块后，11–14 期邻域仍被精确证明无改善。
4. **通用 NoRel 重跑不如结构邻域有效。** 600 秒通用 Gurobi 没有改善，而 16 秒的 `[7,9]` 精确子问题找到了新解。
5. **朴素 Lagrangian subgradient 不足以推进 dual。** 下一步应做 stabilized bundle/restricted master，并加入 precedence-induced cover/clique cuts。
6. **最值得继续的 primal 路线**是从 `[6,10]`、`[7,11]` 等 time-limit 五时期模型保存/恢复 branch-and-bound，或把窗口按空间 precedence cluster 再细分后做交叠迭代。
7. **若目标是正式 global proof**，需要完整闭合到新 primal，或输出可独立检查的 branch/cut、OPB/VeriPB 等证书；现有文件不满足这一标准。

## 9. 文件索引

- 机器汇总：[`SUMMARY.json`](../artifacts/summary.json)
- 背景来源：[`sources.md`](SOURCES.md)
- 新解：[`results/rmine15-improved-5018.823005.sol`](../solutions/rmine15-improved-5018.823005.sol)
- 结构与公开解审计：[`results/structure-public-audit.json`](../artifacts/structure-public-audit.json)
- 新解 Gurobi 审计：[`results/new-incumbent-audit.json`](../artifacts/new-incumbent-audit.json)
- 新解 Decimal 审计：[`results/new-incumbent-exact-decimal-audit.json`](../artifacts/new-incumbent-exact-decimal-audit.json)
- 排程变更：[`results/public-vs-new.json`](../artifacts/public-vs-new.json)
- 全部研究脚本：[`scripts/`](../scripts/)
- Gurobi 日志：[`logs/`](../logs/)

## 10. 证据分类

- **新严格 primal：是。**
- **primal 相比 MIPLIB 改进：是，改善 `0.003014`。**
- **新的全局 dual bound：否。**
- **局部零 gap 证明：是，范围见第 4 节。**
- **全局 optimal：否。**
- **独立全局 certificate：否。**

