#!/usr/bin/env python3
"""Independently rerun exact cut and strengthened-MPS checks for a family run."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from family_prefix_pair_experiment import (
    discover,
    parse_mps,
    verify_records,
    verify_strengthened_mps,
)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("original_mps")
    parser.add_argument("result_json")
    parser.add_argument("strengthened_mps")
    parser.add_argument("--output")
    args = parser.parse_args()
    result = json.loads(Path(args.result_json).read_text(encoding="utf-8"))
    original = parse_mps(args.original_mps)
    if original.sha256 != result["model"]["original_sha256"]:
        raise ValueError("result and original MPS hashes disagree")
    catalog = discover(original)
    records = result["cut_records"]
    cut_check = verify_records(original, catalog, records)
    model_check = verify_strengthened_mps(original, Path(args.strengthened_mps), records)
    payload = {
        "verified": True,
        "model": original.name,
        "original_sha256": original.sha256,
        **model_check,
        **cut_check,
    }
    rendered = json.dumps(payload, indent=2) + "\n"
    if args.output:
        Path(args.output).write_text(rendered, encoding="utf-8")
    print(rendered, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
