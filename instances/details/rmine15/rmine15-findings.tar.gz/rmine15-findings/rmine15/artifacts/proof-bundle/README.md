# `rmine15` exact cut-validity chain

Run these commands from `instances/rmine15/`.

Validate the 121 precedence-induced pair conflicts and the pair-enhanced MPS:

```sh
python artifacts/proof-bundle/agent-dual-family/verify_family_result.py \
  input/rmine15.mps.gz \
  artifacts/proof-bundle/agent-dual-family/rmine15/result.json \
  artifacts/proof-bundle/agent-dual-family/rmine15/rmine15-pairs.mps.gz
```

Validate the 2,271 conflict-graph edges, 61 clique inequalities, and final
enhanced MPS:

```sh
python artifacts/proof-bundle/agent-clique-rmine15/validate_clique_rmine15.py \
  input/rmine15.mps.gz \
  artifacts/proof-bundle/agent-dual-family/rmine15/result.json \
  artifacts/proof-bundle/agent-dual-family/rmine15/rmine15-pairs.mps.gz \
  artifacts/proof-bundle/agent-clique-rmine15/run/result.json \
  artifacts/proof-bundle/agent-clique-rmine15/run/rmine15-pairs-plus-cliques.mps.gz
```

Replay the exact flow/cut certificate:

```sh
python scripts/exact_lagrangian_certificate.py verify \
  artifacts/proof-bundle/agent-clique-rmine15/run/rmine15-pairs-plus-cliques.mps.gz \
  artifacts/exact-bound/exact-lb-cert.json.gz
```

The final certificate verifier uses only the Python standard library.  The cut
validators import the archived experiment modules and require `gurobipy` and
`networkx`; they do not reoptimize the original integer MIP.
