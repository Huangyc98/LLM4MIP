#!/usr/bin/env python3
"""Finite exact precedence-clique root-LP experiment for rmine15."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from fractions import Fraction
from pathlib import Path

sys.dont_write_bytecode = True
import gurobipy as gp


HERE = Path(__file__).resolve().parent
SHARED = HERE.parent / "agent-clique"
sys.path.insert(0, str(SHARED))
from clique_experiment import (  # noqa: E402
    build_exact_graph,
    choose_candidates,
    clique_pair_witnesses,
    closures_for_period,
    discover,
    enumerate_large_maximal_cliques,
    graph_digest,
    parse_mps,
    validate_seed_edges,
)


def family_seed_records(payload: dict):
    records = payload.get("cut_records")
    if records is None:
        raise ValueError("expected agent-dual-family result with top-level cut_records")
    return records


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("original_mps")
    parser.add_argument("seed_pair_result")
    parser.add_argument("seed_pair_mps")
    parser.add_argument("output_dir")
    parser.add_argument("--rounds", type=int, default=3)
    parser.add_argument("--extra-candidates", type=int, default=60)
    parser.add_argument("--cliques-per-period", type=int, default=20)
    parser.add_argument("--max-enumerated-per-period", type=int, default=100000)
    parser.add_argument("--wall-seconds", type=float, default=840.0)
    parser.add_argument("--threads", type=int, default=4)
    args = parser.parse_args()
    started = time.perf_counter()
    deadline = started + args.wall_seconds
    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    original = parse_mps(args.original_mps)
    if original.name != "rmine15":
        raise ValueError(f"this bounded run is for rmine15, got {original.name}")
    catalog = discover(original)
    seed_payload = json.loads(Path(args.seed_pair_result).read_text(encoding="utf-8"))
    if seed_payload["model"]["original_sha256"] != original.sha256:
        raise ValueError("family pair result does not match official MPS")
    pairs = family_seed_records(seed_payload)
    seed_by_period = {}
    for record in pairs:
        period = int(record["period"])
        seed_by_period.setdefault(period, set()).update(record["variables"])

    integer_model = gp.read(args.seed_pair_mps)
    relaxation = integer_model.relax()
    relaxation.Params.OutputFlag = 0
    relaxation.Params.Threads = args.threads
    relaxation.Params.TimeLimit = max(1.0, deadline - time.perf_counter())
    relaxation.optimize()
    if relaxation.Status != gp.GRB.OPTIMAL:
        raise RuntimeError(f"121-pair baseline LP not optimal; status={relaxation.Status}")
    baseline = relaxation.ObjVal
    lp_vars = {var.VarName: var for var in relaxation.getVars()}
    mip_vars = {var.VarName: var for var in integer_model.getVars()}
    initial_x = {name: var.X for name, var in lp_vars.items()}

    graphs = {}
    witnesses_by_period = {}
    cliques_by_period = {}
    graph_records = []
    for period in sorted(seed_by_period):
        if time.perf_counter() >= deadline:
            raise TimeoutError("wall budget exhausted while building candidate graphs")
        closures = closures_for_period(original, catalog, period)
        candidates, stats = choose_candidates(
            catalog, period, closures, initial_x, seed_by_period[period], args.extra_candidates
        )
        graph, witnesses = build_exact_graph(catalog, period, closures, candidates)
        maximal, total_seen, truncated = enumerate_large_maximal_cliques(
            graph, args.max_enumerated_per_period, deadline
        )
        graphs[period] = graph
        witnesses_by_period[period] = witnesses
        cliques_by_period[period] = maximal
        graph_records.append({
            "period": period,
            **stats,
            "edges": graph.number_of_edges(),
            "graph_sha256": graph_digest(graph),
            "maximal_cliques_size_at_least_3": len(maximal),
            "all_maximal_cliques_seen": total_seen,
            "enumeration_truncated": truncated,
            "largest_candidate_maximal_clique": max((len(clique) for clique in maximal), default=2),
            "candidates": candidates,
        })
    validate_seed_edges(pairs, graphs)

    added = set()
    cut_records = []
    round_records = []
    for round_index in range(1, args.rounds + 1):
        if time.perf_counter() >= deadline:
            break
        x_value = {name: var.X for name, var in lp_vars.items()}
        chosen = []
        for period in sorted(cliques_by_period):
            ranked = sorted(
                (
                    (sum(x_value[node] for node in clique), clique)
                    for clique in cliques_by_period[period] if clique not in added
                ),
                reverse=True,
            )
            accepted = 0
            for rank, (weight, clique) in enumerate(ranked, 1):
                if weight <= 1.0 + 1e-7:
                    break
                pair_witnesses = clique_pair_witnesses(clique, witnesses_by_period[period])
                chosen.append({
                    "round": round_index,
                    "period": period,
                    "candidate_maximal": True,
                    "separation_rank_in_period": rank,
                    "maximum_weight_size_ge_3_for_period": accepted == 0,
                    "variables": list(clique),
                    "size": len(clique),
                    "lp_weight": weight,
                    "lp_violation": weight - 1.0,
                    "minimum_pair_overload_margin": str(min(
                        Fraction(witness["exact_overload_margin"]) for witness in pair_witnesses
                    )),
                    "pair_witnesses": pair_witnesses,
                })
                added.add(clique)
                accepted += 1
                if accepted >= args.cliques_per_period:
                    break
        if not chosen:
            round_records.append({"round": round_index, "cuts": 0, "objective": relaxation.ObjVal})
            break
        for record in chosen:
            index = len(cut_records)
            name = f"certified_clique15_{index}"
            variables = record["variables"]
            relaxation.addConstr(gp.quicksum(lp_vars[var] for var in variables) <= 1, name=name)
            integer_model.addConstr(gp.quicksum(mip_vars[var] for var in variables) <= 1, name=name)
            cut_records.append(record)
        relaxation.Params.TimeLimit = max(1.0, deadline - time.perf_counter())
        relaxation.optimize()
        if relaxation.Status != gp.GRB.OPTIMAL:
            raise RuntimeError(f"clique LP not optimal; status={relaxation.Status}")
        round_records.append({
            "round": round_index,
            "cuts": len(chosen),
            "objective": relaxation.ObjVal,
            "improvement_over_121_pairs": relaxation.ObjVal - baseline,
        })

    enhanced_mps = output_dir / "rmine15-pairs-plus-cliques.mps.gz"
    integer_model.write(str(enhanced_mps))
    result = {
        "method": "rmine15_finite_candidate_exact_precedence_clique_root_lp",
        "original": {
            "path": str(Path(args.original_mps).resolve()),
            "sha256": original.sha256,
            "periods": catalog.periods,
            "resources": catalog.resources,
        },
        "seed_pair_result": str(Path(args.seed_pair_result).resolve()),
        "seed_pair_mps": str(Path(args.seed_pair_mps).resolve()),
        "seed_pair_mps_sha256": hashlib.sha256(Path(args.seed_pair_mps).read_bytes()).hexdigest(),
        "seed_pair_count": len(pairs),
        "parameters": {
            "rounds": args.rounds,
            "extra_candidates": args.extra_candidates,
            "cliques_per_period": args.cliques_per_period,
            "max_enumerated_per_period": args.max_enumerated_per_period,
            "wall_seconds": args.wall_seconds,
            "threads": args.threads,
            "minimum_clique_size": 3,
        },
        "pair_baseline_root_lp": baseline,
        "clique_strengthened_root_lp": relaxation.ObjVal,
        "root_lp_improvement_over_pairs": relaxation.ObjVal - baseline,
        "conflict_graphs": graph_records,
        "rounds": round_records,
        "clique_cuts": cut_records,
        "enhanced_mps": str(enhanced_mps),
        "enhanced_mps_sha256": hashlib.sha256(enhanced_mps.read_bytes()).hexdigest(),
        "elapsed_seconds": time.perf_counter() - started,
        "scope_note": "Finite candidate graphs and continuous LP only; no long original MIP.",
    }
    (output_dir / "result.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "pair_baseline_root_lp": baseline,
        "clique_strengthened_root_lp": relaxation.ObjVal,
        "root_lp_improvement_over_pairs": relaxation.ObjVal - baseline,
        "clique_cuts": len(cut_records),
        "maximum_added_clique_size": max((record["size"] for record in cut_records), default=0),
        "elapsed_seconds": result["elapsed_seconds"],
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
