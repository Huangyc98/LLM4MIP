#!/usr/bin/env python3
"""Finite root-LP separation of cumulative precedence-pair cuts for rmine.

Periods and resources are discovered from ``tcap_c*_t*`` row names.  No family
member count or capacity is hard-coded.  All overload tests use exact Fractions
parsed from the original MPS.  This script solves continuous LPs only; it never
starts a long integer optimization.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import time
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, Sequence, Tuple

import gurobipy as gp


HERE = Path(__file__).resolve().parent
SHARED = HERE.parent / "agent-dual"
sys.path.insert(0, str(SHARED))
from exact_lagrangian_certificate import ClosureModel, parse_mps  # noqa: E402


CAP_RE = re.compile(r"^tcap_c(.+)_t(-?\d+)$")
VAR_RE = re.compile(r"^x_B(.+)_t(-?\d+)$")


def period_of(name: str) -> int:
    match = VAR_RE.match(name)
    if not match:
        raise ValueError(f"unexpected rmine variable name: {name}")
    return int(match.group(2))


@dataclass
class Catalog:
    periods: List[int]
    resources: List[str]
    row: Dict[Tuple[str, int], str]
    variables_at: Dict[int, List[str]]
    weights: Dict[Tuple[str, int], Dict[str, Fraction]]
    prefix_capacity: Dict[Tuple[str, int], Fraction]


def discover(model: ClosureModel) -> Catalog:
    rows: Dict[Tuple[str, int], str] = {}
    for name in model.side_rows:
        match = CAP_RE.match(name)
        if match:
            key = (match.group(1), int(match.group(2)))
            if key in rows:
                raise ValueError(f"duplicate capacity key {key}")
            rows[key] = name
    if not rows:
        raise ValueError("no tcap_c*_t* rows found")
    periods = sorted({period for _resource, period in rows})
    resources = sorted({resource for resource, _period in rows})
    missing = [(r, t) for r in resources for t in periods if (r, t) not in rows]
    if missing:
        raise ValueError(f"capacity row grid is incomplete; examples: {missing[:5]}")
    variables_at = {period: [] for period in periods}
    for var in model.variables:
        period = period_of(var)
        if period not in variables_at:
            raise ValueError(f"variable period {period} has no capacity rows")
        variables_at[period].append(var)

    weights = {}
    prefix_capacity = {}
    for resource in resources:
        running = Fraction(0)
        for period in periods:
            row_name = rows[(resource, period)]
            running += model.side_rhs[row_name]
            prefix_capacity[(resource, period)] = running
            direct = model.side_columns[row_name]
            period_weights = {}
            for var in variables_at[period]:
                value = direct.get(var, Fraction(0))
                if value <= 0:
                    raise ValueError(f"{row_name} has no positive current-period weight for {var}")
                period_weights[var] = value
            weights[(resource, period)] = period_weights
    return Catalog(periods, resources, rows, variables_at, weights, prefix_capacity)


def same_period_closures(model: ClosureModel, catalog: Catalog, period: int):
    nodes = catalog.variables_at[period]
    node_set = set(nodes)
    successors = {v: [] for v in nodes}
    for tail, head in model.arcs:
        if tail in node_set and head in node_set:
            successors[tail].append(head)
    memo: Dict[str, frozenset[str]] = {}
    visiting = set()

    def closure(var: str) -> frozenset[str]:
        known = memo.get(var)
        if known is not None:
            return known
        if var in visiting:
            raise ValueError(f"cycle in same-period closure at {var}")
        visiting.add(var)
        result = {var}
        for successor in successors[var]:
            result.update(closure(successor))
        visiting.remove(var)
        memo[var] = frozenset(result)
        return memo[var]

    for var in nodes:
        closure(var)
    return memo


def closure_weights(
    catalog: Catalog,
    period: int,
    closures: Mapping[str, frozenset[str]],
    variables: Iterable[str],
):
    return {
        var: {
            resource: sum((catalog.weights[(resource, period)][u] for u in closures[var]), Fraction(0))
            for resource in catalog.resources
        }
        for var in variables
    }


def screen_candidates(
    catalog: Catalog,
    period: int,
    x_value: Mapping[str, float],
    closures: Mapping[str, frozenset[str]],
    candidate_limit: int,
):
    positive = [v for v in catalog.variables_at[period] if x_value[v] > 1e-8]
    weights = closure_weights(catalog, period, closures, positive)

    def pressure(var: str) -> float:
        return max(
            float(weights[var][resource] / catalog.prefix_capacity[(resource, period)])
            for resource in catalog.resources
        )

    fractional = [v for v in positive if x_value[v] < 1.0 - 1e-8]
    integral_one = [v for v in positive if x_value[v] >= 1.0 - 1e-8]
    selected = set(sorted(fractional, key=lambda v: x_value[v], reverse=True)[:candidate_limit])
    selected.update(sorted(fractional, key=pressure, reverse=True)[:candidate_limit])
    selected.update(sorted(integral_one, key=pressure, reverse=True)[:candidate_limit])
    candidates = sorted(selected, key=lambda v: x_value[v], reverse=True)
    return candidates, {v: weights[v] for v in candidates}, {
        "positive": len(positive),
        "fractional": len(fractional),
        "integral_one": len(integral_one),
        "screened": len(candidates),
    }


def separate_period(
    model: ClosureModel,
    catalog: Catalog,
    period: int,
    x_value: Mapping[str, float],
    candidate_limit: int,
    cut_limit: int,
):
    closures = same_period_closures(model, catalog, period)
    candidates, total_weight, stats = screen_candidates(
        catalog, period, x_value, closures, candidate_limit
    )
    found = []
    evaluated = 0
    for left_position, left in enumerate(candidates):
        for right in candidates[left_position + 1:]:
            violation = x_value[left] + x_value[right] - 1.0
            if violation <= 1e-7:
                break
            if x_value[left] >= 1.0 - 1e-8 and x_value[right] >= 1.0 - 1e-8:
                continue
            if right in closures[left] or left in closures[right]:
                continue
            evaluated += 1
            possibly_overloaded = [
                resource for resource in catalog.resources
                if total_weight[left][resource] + total_weight[right][resource]
                > catalog.prefix_capacity[(resource, period)]
            ]
            if not possibly_overloaded:
                continue
            outside = closures[right] - closures[left]
            overloads = []
            for resource in possibly_overloaded:
                union_weight = total_weight[left][resource] + sum(
                    (catalog.weights[(resource, period)][u] for u in outside), Fraction(0)
                )
                capacity = catalog.prefix_capacity[(resource, period)]
                if union_weight > capacity:
                    overloads.append((union_weight - capacity, resource, union_weight, capacity))
            if overloads:
                margin, resource, union_weight, capacity = max(overloads)
                found.append({
                    "kind": "precedence_pair",
                    "period": period,
                    "resource": resource,
                    "variables": [left, right],
                    "lp_violation": violation,
                    "closure_union_size": len(closures[left] | closures[right]),
                    "closure_union_weight": str(union_weight),
                    "prefix_capacity": str(capacity),
                    "exact_overload_margin": str(margin),
                })
    found.sort(
        key=lambda record: (record["lp_violation"], Fraction(record["exact_overload_margin"])),
        reverse=True,
    )
    stats["pairs_exactly_evaluated"] = evaluated
    stats["violated_conflicts_found_before_limit"] = len(found)
    return found[:cut_limit], stats


def verify_records(model: ClosureModel, catalog: Catalog, records: Sequence[dict]):
    closure_cache = {}
    minimum_margin = None
    for index, record in enumerate(records):
        if record.get("kind") != "precedence_pair":
            raise ValueError(f"unsupported cut kind at {index}")
        period = int(record["period"])
        resource = str(record["resource"])
        variables = record["variables"]
        if len(variables) != 2 or variables[0] == variables[1]:
            raise ValueError(f"malformed pair {index}")
        if period not in catalog.periods or resource not in catalog.resources:
            raise ValueError(f"unknown period/resource in cut {index}")
        if any(period_of(v) != period for v in variables):
            raise ValueError(f"cut {index} mixes periods")
        if period not in closure_cache:
            closure_cache[period] = same_period_closures(model, catalog, period)
        closures = closure_cache[period]
        union = closures[variables[0]] | closures[variables[1]]
        union_weight = sum(
            (catalog.weights[(resource, period)][u] for u in union), Fraction(0)
        )
        capacity = catalog.prefix_capacity[(resource, period)]
        margin = union_weight - capacity
        if margin <= 0:
            raise ValueError(f"cut {index} is not justified by exact overload")
        if str(union_weight) != record["closure_union_weight"]:
            raise ValueError(f"cut {index} union-weight record mismatch")
        if str(capacity) != record["prefix_capacity"]:
            raise ValueError(f"cut {index} capacity record mismatch")
        minimum_margin = margin if minimum_margin is None else min(minimum_margin, margin)
    return {
        "all_cuts_exactly_verified": True,
        "verified_cut_count": len(records),
        "minimum_exact_overload_margin": str(minimum_margin) if minimum_margin is not None else None,
    }


def verify_strengthened_mps(
    original: ClosureModel,
    strengthened_path: Path,
    records: Sequence[dict],
):
    strengthened = parse_mps(strengthened_path)
    if set(original.variables) != set(strengthened.variables):
        raise ValueError("strengthened MPS changed the variable set")
    if original.objective != strengthened.objective:
        raise ValueError("strengthened MPS changed the objective")
    if set(original.arcs) != set(strengthened.arcs):
        raise ValueError("strengthened MPS changed the closure arcs")
    expected_new = {f"certified_family_pair_{i}" for i in range(len(records))}
    if set(strengthened.side_rows) != set(original.side_rows) | expected_new:
        raise ValueError("strengthened MPS has missing or extra side rows")
    for index, record in enumerate(records):
        row = f"certified_family_pair_{index}"
        if strengthened.side_rhs[row] != 1:
            raise ValueError(f"wrong RHS in {row}")
        expected = {record["variables"][0]: Fraction(1), record["variables"][1]: Fraction(1)}
        if strengthened.side_columns[row] != expected:
            raise ValueError(f"wrong coefficients in {row}")
    return {
        "strengthened_mps_exactly_verified": True,
        "strengthened_sha256": strengthened.sha256,
        "strengthened_side_rows": len(strengthened.side_rows),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps")
    parser.add_argument("output_dir")
    parser.add_argument("--rounds", type=int, default=1)
    parser.add_argument("--candidate-limit", type=int, default=40)
    parser.add_argument("--cuts-per-period", type=int, default=100)
    parser.add_argument("--wall-seconds", type=float, default=540.0)
    parser.add_argument("--threads", type=int, default=4)
    args = parser.parse_args()
    if args.rounds < 1 or args.candidate_limit < 1 or args.cuts_per_period < 1:
        parser.error("round and limit arguments must be positive")

    started = time.perf_counter()
    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    exact = parse_mps(args.mps)
    catalog = discover(exact)
    integer_model = gp.read(args.mps)
    relaxation = integer_model.relax()
    relaxation.Params.OutputFlag = 0
    relaxation.Params.Threads = args.threads
    relaxation.Params.TimeLimit = max(1.0, args.wall_seconds - (time.perf_counter() - started))
    relaxation.optimize()
    if relaxation.Status != gp.GRB.OPTIMAL:
        raise RuntimeError(f"baseline LP not optimal; status={relaxation.Status}")
    baseline = relaxation.ObjVal
    lp_vars = {v.VarName: v for v in relaxation.getVars()}
    mip_vars = {v.VarName: v for v in integer_model.getVars()}
    signatures = set()
    all_records = []
    round_summaries = []
    stopped_on_wall_limit = False

    for round_index in range(1, args.rounds + 1):
        x_value = {name: var.X for name, var in lp_vars.items()}
        records = []
        period_stats = []
        for period in catalog.periods:
            if time.perf_counter() - started >= args.wall_seconds:
                stopped_on_wall_limit = True
                break
            found, stats = separate_period(
                exact, catalog, period, x_value, args.candidate_limit, args.cuts_per_period
            )
            accepted = 0
            for record in found:
                left, right = record["variables"]
                signature = (period, min(left, right), max(left, right))
                if signature in signatures:
                    continue
                signatures.add(signature)
                record["round"] = round_index
                records.append(record)
                accepted += 1
            stats["period"] = period
            stats["accepted_cuts"] = accepted
            period_stats.append(stats)
        if not records:
            round_summaries.append({"round": round_index, "cuts": 0, "period_stats": period_stats})
            break
        for record in records:
            left, right = record["variables"]
            cut_index = len(all_records)
            name = f"certified_family_pair_{cut_index}"
            relaxation.addConstr(lp_vars[left] + lp_vars[right] <= 1, name=name)
            integer_model.addConstr(mip_vars[left] + mip_vars[right] <= 1, name=name)
            all_records.append(record)
        remaining = max(1.0, args.wall_seconds - (time.perf_counter() - started))
        relaxation.Params.TimeLimit = remaining
        relaxation.optimize()
        if relaxation.Status != gp.GRB.OPTIMAL:
            raise RuntimeError(f"strengthened LP not optimal; status={relaxation.Status}")
        round_summaries.append({
            "round": round_index,
            "cuts": len(records),
            "objective": relaxation.ObjVal,
            "improvement_from_baseline": relaxation.ObjVal - baseline,
            "period_stats": period_stats,
        })
        if stopped_on_wall_limit:
            break

    cut_check = verify_records(exact, catalog, all_records)
    strengthened_path = output_dir / f"{exact.name}-prefix-pairs.mps.gz"
    integer_model.write(str(strengthened_path))
    mps_check = verify_strengthened_mps(exact, strengthened_path, all_records)
    elapsed = time.perf_counter() - started
    result = {
        "method": "finite_screened_same-period_precedence-closure_pair_cuts",
        "model": {
            "name": exact.name,
            "original_path": str(Path(args.mps).resolve()),
            "original_sha256": exact.sha256,
            "variables": len(exact.variables),
            "precedence_arcs": len(exact.arcs),
            "periods": catalog.periods,
            "resources": catalog.resources,
            "capacity_rows": len(catalog.periods) * len(catalog.resources),
        },
        "parameters": {
            "rounds": args.rounds,
            "candidate_limit_per_screen": args.candidate_limit,
            "cuts_per_period": args.cuts_per_period,
            "wall_seconds": args.wall_seconds,
            "threads": args.threads,
        },
        "baseline_root_lp": baseline,
        "strengthened_root_lp": relaxation.ObjVal,
        "root_lp_improvement": relaxation.ObjVal - baseline,
        "cuts": len(all_records),
        "rounds": round_summaries,
        "cut_records": all_records,
        "cut_verification": cut_check,
        "strengthened_mps_verification": mps_check,
        "stopped_on_wall_limit": stopped_on_wall_limit,
        "elapsed_seconds": elapsed,
        "scope_note": "Continuous root LP only; finite screened separation, not exhaustive; no long MIP was run.",
    }
    result_path = output_dir / "result.json"
    result_path.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    summary = {
        "name": exact.name,
        "periods": catalog.periods,
        "resources": catalog.resources,
        "baseline_root_lp": baseline,
        "strengthened_root_lp": relaxation.ObjVal,
        "root_lp_improvement": relaxation.ObjVal - baseline,
        "cuts": len(all_records),
        "all_cuts_exactly_verified": cut_check["all_cuts_exactly_verified"],
        "elapsed_seconds": elapsed,
    }
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
