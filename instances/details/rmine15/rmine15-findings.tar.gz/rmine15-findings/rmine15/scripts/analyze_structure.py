import argparse
import gzip
import hashlib
import json
import math
import re
import statistics
from collections import Counter, defaultdict
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


VAR_RE = re.compile(r"^x_B(?P<block>\d+)_t(?P<period>\d+)$")


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def quantiles(values):
    values = sorted(values)
    if not values:
        return {}
    return {
        "min": values[0],
        "median": statistics.median(values),
        "mean": statistics.fmean(values),
        "max": values[-1],
    }


def read_solution(path):
    opener = gzip.open if str(path).endswith(".gz") else open
    values = {}
    declared = None
    with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
        for raw in handle:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("=obj="):
                declared = float(line.split()[-1])
                continue
            pieces = line.split()
            if len(pieces) >= 2:
                values[pieces[0]] = float(pieces[1])
    return declared, values


def violation(sense, activity, rhs):
    if sense == "<":
        return max(0.0, activity - rhs)
    if sense == ">":
        return max(0.0, rhs - activity)
    return abs(activity - rhs)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", required=True)
    parser.add_argument("--solution", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    model = gp.read(args.mps)
    model.Params.OutputFlag = 0
    model.update()
    variables = model.getVars()
    constraints = model.getConstrs()
    index_by_name = {v.VarName: i for i, v in enumerate(variables)}

    block_period = defaultdict(list)
    malformed = []
    for variable in variables:
        match = VAR_RE.match(variable.VarName)
        if match:
            block_period[int(match.group("block"))].append(int(match.group("period")))
        else:
            malformed.append(variable.VarName)

    row_prefixes = Counter()
    row_samples = defaultdict(list)
    row_degrees = []
    col_degrees = [0] * len(variables)
    abs_coefficients = []
    row_records = []
    for row in constraints:
        expr = model.getRow(row)
        terms = []
        for j in range(expr.size()):
            variable = expr.getVar(j)
            coefficient = expr.getCoeff(j)
            terms.append((variable.VarName, coefficient))
            col_degrees[variable.index] += 1
            abs_coefficients.append(abs(coefficient))
        row_degrees.append(len(terms))
        prefix = row.ConstrName.split("_")[0]
        row_prefixes[prefix] += 1
        if len(row_samples[prefix]) < 5:
            row_samples[prefix].append({
                "name": row.ConstrName,
                "sense": row.Sense,
                "rhs": row.RHS,
                "terms": terms[:20],
                "term_count": len(terms),
            })
        row_records.append((row, terms))

    declared, public_values = read_solution(args.solution)
    vector = [public_values.get(v.VarName, 0.0) for v in variables]
    objective = model.ObjCon + sum(v.Obj * vector[i] for i, v in enumerate(variables))
    bound_violations = []
    integer_violations = []
    for i, variable in enumerate(variables):
        value = vector[i]
        bv = max(variable.LB - value, value - variable.UB, 0.0)
        iv = abs(value - round(value)) if variable.VType != GRB.CONTINUOUS else 0.0
        if bv > 0:
            bound_violations.append((bv, variable.VarName, value, variable.LB, variable.UB))
        if iv > 0:
            integer_violations.append((iv, variable.VarName, value))

    row_violations = []
    for row, terms in row_records:
        activity = sum(coef * vector[index_by_name[name]] for name, coef in terms)
        rv = violation(row.Sense, activity, row.RHS)
        if rv > 0:
            row_violations.append((rv, row.ConstrName, activity, row.Sense, row.RHS))
    row_violations.sort(reverse=True)

    period_counts = Counter()
    selected_counts = Counter()
    for block, periods in block_period.items():
        for period in periods:
            period_counts[period] += 1
            name = f"x_B{block}_t{period}"
            selected_counts[period] += int(public_values.get(name, 0.0) > 0.5)

    start_counts = Counter(min(periods) for periods in block_period.values())
    end_counts = Counter(max(periods) for periods in block_period.values())
    lengths = [len(periods) for periods in block_period.values()]

    output = {
        "instance": model.ModelName,
        "files": {
            "mps": str(Path(args.mps).resolve()),
            "mps_sha256": sha256(args.mps),
            "public_solution": str(Path(args.solution).resolve()),
            "public_solution_sha256": sha256(args.solution),
        },
        "gurobi_version": list(gp.gurobi.version()),
        "objective_sense": "min" if model.ModelSense == GRB.MINIMIZE else "max",
        "objective_constant": model.ObjCon,
        "counts": {
            "variables": model.NumVars,
            "constraints": model.NumConstrs,
            "nonzeros": model.NumNZs,
            "binaries_by_bounds": sum(v.LB == 0 and v.UB == 1 and v.VType in (GRB.BINARY, GRB.INTEGER) for v in variables),
            "integer_type": sum(v.VType == GRB.INTEGER for v in variables),
            "binary_type": sum(v.VType == GRB.BINARY for v in variables),
            "continuous_type": sum(v.VType == GRB.CONTINUOUS for v in variables),
        },
        "constraint_senses": dict(Counter(r.Sense for r in constraints)),
        "row_prefix_counts": dict(row_prefixes),
        "row_samples": dict(row_samples),
        "matrix": {
            "row_degree": quantiles(row_degrees),
            "column_degree": quantiles(col_degrees),
            "absolute_coefficient": quantiles(abs_coefficients),
        },
        "time_block_structure": {
            "parsed_variables": sum(len(v) for v in block_period.values()),
            "malformed_variable_names": malformed,
            "blocks": len(block_period),
            "periods": sorted(period_counts),
            "variables_by_period": dict(sorted(period_counts.items())),
            "public_selected_cumulative_by_period": dict(sorted(selected_counts.items())),
            "start_period_histogram": dict(sorted(start_counts.items())),
            "end_period_histogram": dict(sorted(end_counts.items())),
            "periods_per_block": quantiles(lengths),
        },
        "objective_coefficients": {
            "nonzero": sum(v.Obj != 0 for v in variables),
            "positive": sum(v.Obj > 0 for v in variables),
            "negative": sum(v.Obj < 0 for v in variables),
            "zero": sum(v.Obj == 0 for v in variables),
            "stats": quantiles([v.Obj for v in variables]),
        },
        "public_solution_audit": {
            "declared_objective": declared,
            "recomputed_objective": objective,
            "objective_difference": objective - declared if declared is not None else None,
            "listed_variables": len(public_values),
            "unknown_names": sorted(set(public_values) - set(index_by_name))[:50],
            "missing_model_variables_assumed_zero": sum(v.VarName not in public_values for v in variables),
            "max_bound_violation": max((x[0] for x in bound_violations), default=0.0),
            "max_integrality_violation": max((x[0] for x in integer_violations), default=0.0),
            "max_row_violation": max((x[0] for x in row_violations), default=0.0),
            "row_violations_gt_1e-9": sum(x[0] > 1e-9 for x in row_violations),
            "row_violations_gt_1e-7": sum(x[0] > 1e-7 for x in row_violations),
            "worst_rows": row_violations[:20],
        },
    }
    Path(args.out).write_text(json.dumps(output, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps({
        "counts": output["counts"],
        "prefixes": output["row_prefix_counts"],
        "blocks": output["time_block_structure"]["blocks"],
        "periods": output["time_block_structure"]["periods"],
        "public": output["public_solution_audit"],
    }, indent=2))


if __name__ == "__main__":
    main()
