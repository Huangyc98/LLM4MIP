import argparse
import gzip
import json
import math
import re
import time
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


VAR_RE = re.compile(r"^x_B(?P<block>\d+)_t(?P<period>\d+)$")


def read_solution(path):
    opener = gzip.open if path.endswith(".gz") else open
    values = {}
    with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
        for raw in handle:
            parts = raw.split()
            if len(parts) >= 2 and not raw.startswith(("#", "=obj=")):
                values[parts[0]] = float(parts[1])
    return values


def status_name(code):
    return {
        GRB.OPTIMAL: "OPTIMAL",
        GRB.TIME_LIMIT: "TIME_LIMIT",
        GRB.INFEASIBLE: "INFEASIBLE",
        GRB.INTERRUPTED: "INTERRUPTED",
    }.get(code, f"STATUS_{code}")


def extraction_periods(model, values):
    periods_by_block = {}
    for variable in model.getVars():
        match = VAR_RE.match(variable.VarName)
        if match:
            block = int(match.group("block"))
            period = int(match.group("period"))
            periods_by_block.setdefault(block, []).append((period, variable))
    extracted = {}
    for block, entries in periods_by_block.items():
        entries.sort()
        ones = [period for period, variable in entries if values.get(variable.VarName, 0.0) > 0.5]
        extracted[block] = min(ones) if ones else 15
    return periods_by_block, extracted


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", required=True)
    parser.add_argument("--start", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--sol-dir", required=True)
    parser.add_argument("--log-dir", required=True)
    parser.add_argument("--seconds-per-window", type=float, default=30)
    parser.add_argument("--threads", type=int, default=2)
    parser.add_argument("--windows", required=True, help="comma separated a-b intervals")
    parser.add_argument("--include-unmined", action="store_true")
    args = parser.parse_args()

    values = read_solution(args.start)
    windows = []
    for token in args.windows.split(","):
        a, b = map(int, token.split("-"))
        windows.append((a, b))
    Path(args.sol_dir).mkdir(parents=True, exist_ok=True)
    Path(args.log_dir).mkdir(parents=True, exist_ok=True)

    trials = []
    best = None
    all_started = time.monotonic()
    for trial_index, (a, b) in enumerate(windows):
        started = time.monotonic()
        model = gp.read(args.mps)
        model.Params.OutputFlag = 1
        model.Params.LogFile = str(Path(args.log_dir) / f"window-{a}-{b}.log")
        model.Params.TimeLimit = args.seconds_per_window
        model.Params.Threads = args.threads
        model.Params.Seed = 150000 + a * 101 + b
        model.Params.MIPFocus = 2
        model.Params.Heuristics = 0.1
        model.Params.Presolve = 2
        model.Params.Cuts = 3
        model.Params.Symmetry = 2
        model.Params.FeasibilityTol = 1e-8
        model.Params.IntFeasTol = 1e-8
        model.Params.MIPGap = 0.0
        model.Params.MIPGapAbs = 0.0
        periods_by_block, extracted = extraction_periods(model, values)

        active_blocks = set()
        for block, public_period in extracted.items():
            active = a <= public_period <= b
            if args.include_unmined and public_period == 15:
                active = True
            if active:
                active_blocks.add(block)
                for period, variable in periods_by_block[block]:
                    variable.Start = values.get(variable.VarName, 0.0)
                    if period < a:
                        variable.LB = variable.UB = values.get(variable.VarName, 0.0)
                    elif period > b and public_period < 15:
                        variable.LB = variable.UB = 1.0
            else:
                for period, variable in periods_by_block[block]:
                    value = values.get(variable.VarName, 0.0)
                    variable.LB = value
                    variable.UB = value
                    variable.Start = value
        model.update()
        model.optimize()
        sol_path = Path(args.sol_dir) / f"window-{a}-{b}.sol"
        if model.SolCount:
            model.write(str(sol_path))
        record = {
            "window": [a, b],
            "include_unmined": args.include_unmined,
            "active_block_count": len(active_blocks),
            "fixed_block_count": len(extracted) - len(active_blocks),
            "status": status_name(model.Status),
            "status_code": model.Status,
            "objective": model.ObjVal if model.SolCount else None,
            "bound": model.ObjBound if math.isfinite(model.ObjBound) else None,
            "gap": model.MIPGap if model.SolCount and math.isfinite(model.MIPGap) else None,
            "nodes": model.NodeCount,
            "solver_runtime": model.Runtime,
            "wall_seconds": time.monotonic() - started,
            "solution_path": str(sol_path) if model.SolCount else None,
            "local_proof": (
                model.Status == GRB.OPTIMAL
                and model.SolCount
                and abs(model.ObjVal - model.ObjBound) <= 5e-7
            ),
            "global_proof": False,
        }
        trials.append(record)
        if model.SolCount and (best is None or model.ObjVal < best[0]):
            best = (model.ObjVal, str(sol_path))
        Path(args.out).write_text(json.dumps({
            "method": "exact_public_extraction_period_window_reoptimization",
            "elapsed_seconds": time.monotonic() - all_started,
            "windows": trials,
            "best": {"objective": best[0], "path": best[1]} if best else None,
            "scope": "Only blocks whose seed-solution extraction period is in the tested window may move; all other blocks are fixed. With --include-unmined, seed-unmined blocks may also enter or remain unmined.",
            "global_optimality_claim": False,
        }, indent=2), encoding="utf-8")
        model.dispose()

    print(Path(args.out).read_text(encoding="utf-8"))


if __name__ == "__main__":
    main()
