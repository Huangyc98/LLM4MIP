# Package manifest: ns1631475

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 16
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/cyclic-cutwidth-lb-22050.json`
- `artifacts/cyclic-cutwidth-ub-22050.json`
- `artifacts/gurobi-baseline-result.json`
- `artifacts/optimality-verification.json`
- `artifacts/public-ring-solution.json`
- `artifacts/recovered-tsp-layers.json`
- `artifacts/structure.json`
- `logs/gurobi-baseline.log`
- `report.zh.md`
- `scripts/analyze_ring_solution.py`
- `scripts/gurobi_structure.py`
- `scripts/prove_cyclic_cutwidth.py`
- `scripts/recover_tsp_layers.py`
- `scripts/verify_ring_optimality.py`
- `solutions/official-best.sol.gz`

## Excluded files

- `input/ns1631475.mps.gz (604782 bytes; raw benchmark input; sha256 a8a42c5213f52fefb8c33ec451860378969b3e86dad261f9ba72df3769411e47)`
