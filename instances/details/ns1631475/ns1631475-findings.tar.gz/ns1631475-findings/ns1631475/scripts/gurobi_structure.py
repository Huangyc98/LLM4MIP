#!/usr/bin/env python3
"""Extract reproducible structural statistics and validate a public solution."""

from __future__ import annotations

import argparse
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path

import gurobipy as gp


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def parse_solution(path: Path):
    values = {}
    declared = None
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8") as stream:
        for raw in stream:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("=obj="):
                declared = float(line.split()[-1])
                continue
            name, value = line.split()[:2]
            values[name] = float(value)
    return declared, values


class DSU:
    def __init__(self, n):
        self.parent = list(range(n))
        self.size = [1] * n

    def find(self, x):
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x

    def union(self, a, b):
        a, b = self.find(a), self.find(b)
        if a == b:
            return
        if self.size[a] < self.size[b]:
            a, b = b, a
        self.parent[b] = a
        self.size[a] += self.size[b]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    model = gp.read(str(args.model))
    model.Params.OutputFlag = 0
    variables = model.getVars()
    constraints = model.getConstrs()
    dsu = DSU(len(variables) + len(constraints))
    row_signatures = Counter()
    row_nnz = []
    coefficient_values = Counter()
    for i, constraint in enumerate(constraints):
        row = model.getRow(constraint)
        row_nnz.append(row.size())
        coefficients = []
        for k in range(row.size()):
            variable = row.getVar(k)
            value = row.getCoeff(k)
            coefficients.append(value)
            coefficient_values[format(value, ".12g")] += 1
            dsu.union(variable.index, len(variables) + i)
        coeff_pattern = tuple(sorted(Counter(format(x, ".6g") for x in coefficients).items()))
        row_signatures[(constraint.Sense, format(constraint.RHS, ".12g"), row.size(), coeff_pattern)] += 1

    components = Counter(dsu.find(i) for i in range(len(variables) + len(constraints)))
    column_signatures = Counter()
    for variable in variables:
        column = model.getCol(variable)
        coeff_pattern = tuple(sorted(Counter(format(column.getCoeff(k), ".6g") for k in range(column.size())).items()))
        column_signatures[(variable.VType, column.size(), format(variable.Obj, ".12g"), coeff_pattern)] += 1
    declared, values = parse_solution(args.solution)
    missing = [v.VarName for v in variables if v.VarName not in values]
    max_bound_violation = 0.0
    max_integrality_violation = 0.0
    for variable in variables:
        value = values.get(variable.VarName, 0.0)
        max_bound_violation = max(max_bound_violation, variable.LB - value, value - variable.UB)
        if variable.VType != gp.GRB.CONTINUOUS:
            max_integrality_violation = max(max_integrality_violation, abs(value - round(value)))
    max_row_violation = 0.0
    for constraint in constraints:
        row = model.getRow(constraint)
        activity = sum(row.getCoeff(k) * values.get(row.getVar(k).VarName, 0.0) for k in range(row.size()))
        if constraint.Sense == gp.GRB.LESS_EQUAL:
            violation = activity - constraint.RHS
        elif constraint.Sense == gp.GRB.GREATER_EQUAL:
            violation = constraint.RHS - activity
        else:
            violation = abs(activity - constraint.RHS)
        max_row_violation = max(max_row_violation, violation)
    computed_objective = model.ObjCon + sum(v.Obj * values.get(v.VarName, 0.0) for v in variables)

    report = {
        "model_sha256": sha256(args.model),
        "solution_sha256": sha256(args.solution),
        "model": {
            "name": model.ModelName,
            "sense": "min" if model.ModelSense == 1 else "max",
            "variables": model.NumVars,
            "constraints": model.NumConstrs,
            "nonzeros": model.NumNZs,
            "types": dict(Counter(v.VType for v in variables)),
            "constraint_senses": dict(Counter(c.Sense for c in constraints)),
            "objective_nonzero": sum(abs(v.Obj) > 0 for v in variables),
            "objective_variables": [(v.VarName, v.Obj) for v in variables if abs(v.Obj) > 0],
            "continuous_variables": [(v.VarName, v.LB, v.UB, v.Obj) for v in variables if v.VType == gp.GRB.CONTINUOUS],
            "unbounded_integer_variables": [(v.VarName, v.LB, v.UB, v.Obj) for v in variables if v.VType != gp.GRB.CONTINUOUS and (v.LB < -1e90 or v.UB > 1e90)],
            "objective_values": Counter(format(v.Obj, ".12g") for v in variables).most_common(20),
            "bound_patterns": Counter((v.VType, format(v.LB, ".8g"), format(v.UB, ".8g")) for v in variables).most_common(20),
            "row_nnz": {"min": min(row_nnz), "max": max(row_nnz), "mean": sum(row_nnz) / len(row_nnz)},
            "row_signatures_top": [
                {"sense": key[0], "rhs": key[1], "nnz": key[2], "coefficients": key[3], "count": count}
                for key, count in row_signatures.most_common(30)
            ],
            "coefficient_values_top": coefficient_values.most_common(30),
            "column_signatures_top": [
                {"type": key[0], "nnz": key[1], "objective": key[2], "coefficients": key[3], "count": count}
                for key, count in column_signatures.most_common(30)
            ],
            "connected_components": sorted(components.values(), reverse=True)[:30],
            "variable_samples": [v.VarName for v in variables[:40]],
            "constraint_samples": [c.ConstrName for c in constraints[:40]],
        },
        "public_solution": {
            "declared_objective": declared,
            "computed_objective": computed_objective,
            "assignments": len(values),
            "missing_model_variables": len(missing),
            "max_bound_violation": max_bound_violation,
            "max_integrality_violation": max_integrality_violation,
            "max_row_violation": max_row_violation,
            "independently_feasible_at_1e-6": max(max_bound_violation, max_integrality_violation, max_row_violation) <= 1e-6,
        },
    }
    args.output.write_text(json.dumps(report, indent=2, default=list) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, default=list))


if __name__ == "__main__":
    main()
