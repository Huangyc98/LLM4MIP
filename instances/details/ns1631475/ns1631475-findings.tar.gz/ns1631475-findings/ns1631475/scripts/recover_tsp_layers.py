#!/usr/bin/env python3
"""Recover the anonymized 15-node directed core and its repeated binary layers."""

import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path

import gurobipy as gp


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    model = gp.read(str(args.model))
    variables = model.getVars()
    constraints = model.getConstrs()
    binaries = [v for v in variables if v.VType != gp.GRB.CONTINUOUS and v.LB == 0 and v.UB == 1]
    continuous = [v for v in variables if v.VType == gp.GRB.CONTINUOUS]
    general = [v for v in variables if v.VType != gp.GRB.CONTINUOUS and not (v.LB == 0 and v.UB == 1)]
    assert len(continuous) == 15 and len(binaries) == 22470 and len(general) == 211
    binary_names = {v.VarName for v in binaries}
    # R0001 is the objective-definition row; R0002--R0031 are the
    # 30 in/out assignment equations for the 15-node directed core.
    assignment_rows = constraints[1:31]
    base_names = set()
    for constraint in assignment_rows:
        row = model.getRow(constraint)
        base_names.update(row.getVar(k).VarName for k in range(row.size()))
    base = [v for v in binaries if v.VarName in base_names]
    assert len(base) == 210
    base_names = {v.VarName for v in base}
    occurrences_by_variable = defaultdict(list)
    for row_index, constraint in enumerate(assignment_rows):
        row = model.getRow(constraint)
        for k in range(row.size()):
            occurrences_by_variable[row.getVar(k).VarName].append(row_index)
    occurrence_histogram = Counter(len(occurrences_by_variable[v.VarName]) for v in base)
    row_graph = [set() for _ in assignment_rows]
    for occurrences in occurrences_by_variable.values():
        if len(occurrences) == 2:
            a, b = occurrences
            row_graph[a].add(b)
            row_graph[b].add(a)
    colors = {}
    for root in range(30):
        if root in colors:
            continue
        colors[root] = 0
        queue = [root]
        for current in queue:
            for neighbor in row_graph[current]:
                expected = 1 - colors[current]
                if neighbor in colors:
                    assert colors[neighbor] == expected
                else:
                    colors[neighbor] = expected
                    queue.append(neighbor)
    left_rows = sorted(i for i, color in colors.items() if color == 0)
    right_rows = sorted(i for i, color in colors.items() if color == 1)
    left_index = {row: i for i, row in enumerate(left_rows)}
    right_index = {row: i for i, row in enumerate(right_rows)}
    base_arc = {}
    for variable in base:
        occurrences = occurrences_by_variable[variable.VarName]
        if len(occurrences) != 2:
            continue
        left = [row for row in occurrences if row in left_index]
        right = [row for row in occurrences if row in right_index]
        if len(left) == len(right) == 1:
            base_arc[variable.VarName] = (left_index[left[0]], right_index[right[0]])
    raw_arcs = set(base_arc.values())
    missing_pairs = {(i, j) for i in range(15) for j in range(15)} - raw_arcs
    assert len(missing_pairs) == 15
    right_to_node = {right: left for left, right in missing_pairs}
    assert len(right_to_node) == 15
    base_arc = {name: (left, right_to_node[right]) for name, (left, right) in base_arc.items()}
    base_arc_bijection_valid = set(base_arc.values()) == {
        (i, j) for i in range(15) for j in range(15) if i != j
    }

    binary_index = {v.VarName: i for i, v in enumerate(binaries)}
    base_residues_mod_107 = Counter(binary_index[name] % 107 for name in base_names)
    if len(base_residues_mod_107) == 1:
        binary_order = "arc-major"
        layers = [[binaries[arc * 107 + layer] for arc in range(210)] for layer in range(107)]
    else:
        binary_order = "layer-major"
        layers = [binaries[offset:offset + 210] for offset in range(0, len(binaries), 210)]
    assert len(layers) == 107 and all(len(layer) == 210 for layer in layers)
    layer_name_sets = [{v.VarName for v in layer} for layer in layers]
    base_layer_index = next(i for i, names in enumerate(layer_name_sets) if names == base_names)
    variable_layer = {v.VarName: i for i, layer in enumerate(layers) for v in layer}
    variable_position = {v.VarName: j for layer in layers for j, v in enumerate(layer)}

    link_relationships = Counter()
    link_same_position = Counter()
    link_examples = []
    for constraint in constraints:
        if constraint.Sense != gp.GRB.GREATER_EQUAL or constraint.RHS != 0:
            continue
        row = model.getRow(constraint)
        if row.size() != 2:
            continue
        terms = [(row.getVar(k), row.getCoeff(k)) for k in range(2)]
        if sorted(value for _, value in terms) != [-1.0, 1.0]:
            continue
        if any(var.VarName not in binary_names for var, _ in terms):
            continue
        relationship = tuple(variable_layer[var.VarName] for var, _ in terms)
        link_relationships[str(relationship)] += 1
        link_same_position[variable_position[terms[0][0].VarName] == variable_position[terms[1][0].VarName]] += 1
        if len(link_examples) < 10:
            link_examples.append([(var.VarName, value) for var, value in terms])

    flow_rows_by_layer = defaultdict(list)
    for constraint in constraints:
        row = model.getRow(constraint)
        if constraint.Sense != gp.GRB.EQUAL or row.size() != 28 or constraint.RHS not in {-1.0, 0.0, 1.0}:
            continue
        coefficients = Counter(row.getCoeff(k) for k in range(row.size()))
        names = [row.getVar(k).VarName for k in range(row.size())]
        involved_layers = {variable_layer[name] for name in names if name in variable_layer}
        if coefficients == Counter({-1.0: 14, 1.0: 14}) and len(involved_layers) == 1:
            flow_rows_by_layer[next(iter(involved_layers))].append(constraint)
    flow_layer_valid = {}
    flow_rhs_pairs = []
    flow_endpoint_pairs = []
    position_to_arc = {j: base_arc[v.VarName] for j, v in enumerate(layers[0])}
    for layer_index, block in flow_rows_by_layer.items():
        rhs_values = Counter(c.RHS for c in block)
        flow_layer_valid[layer_index] = len(block) == 15 and rhs_values == Counter({0.0: 13, 1.0: 1, -1.0: 1})
        if flow_layer_valid[layer_index]:
            positive = next(c for c in block if c.RHS == 1.0)
            negative = next(c for c in block if c.RHS == -1.0)
            flow_rhs_pairs.append((positive.ConstrName, negative.ConstrName))
            endpoint_nodes = []
            for endpoint_row in (positive, negative):
                expression = model.getRow(endpoint_row)
                signed_arcs = {
                    position_to_arc[variable_position[expression.getVar(k).VarName]]: expression.getCoeff(k)
                    for k in range(expression.size())
                }
                matches = []
                for node in range(15):
                    expected = {
                        arc: (1.0 if arc[0] == node else -1.0)
                        for arc in position_to_arc.values()
                        if node in arc
                    }
                    if signed_arcs == expected or signed_arcs == {arc: -value for arc, value in expected.items()}:
                        matches.append(node)
                assert len(matches) == 1
                endpoint_nodes.append(matches[0])
            flow_endpoint_pairs.append(tuple(endpoint_nodes))

    coefficient_values_by_flow_layer = {}
    load_rows = constraints[24076:24286]
    for layer_index in range(2, 107):
        coefficients = set()
        layer_names = layer_name_sets[layer_index]
        for constraint in load_rows:
            row = model.getRow(constraint)
            for k in range(row.size()):
                if row.getVar(k).VarName in layer_names:
                    coefficients.add(abs(row.getCoeff(k)))
        coefficient_values_by_flow_layer[layer_index] = sorted(coefficients)

    flow_commodities = []
    for offset, endpoints in enumerate(flow_endpoint_pairs):
        layer_index = offset + 2
        values = coefficient_values_by_flow_layer[layer_index]
        assert len(values) <= 1
        flow_commodities.append(
            {
                "binary_layer": layer_index,
                "endpoints_zero_based": endpoints,
                "demand": values[0] if values else 0,
            }
        )

    row_type_ranges = []
    previous = None
    begin = 0
    for i, constraint in enumerate(constraints):
        row = model.getRow(constraint)
        key = (constraint.Sense, constraint.RHS, row.size(), tuple(sorted(Counter(row.getCoeff(k) for k in range(row.size())).items())))
        if previous is not None and key != previous:
            row_type_ranges.append({"first": begin + 1, "last": i, "signature": str(previous)})
            begin = i
        previous = key
    row_type_ranges.append({"first": begin + 1, "last": len(constraints), "signature": str(previous)})

    def row_record(one_based_index):
        constraint = constraints[one_based_index - 1]
        row = model.getRow(constraint)
        return {
            "index": one_based_index,
            "name": constraint.ConstrName,
            "sense": constraint.Sense,
            "rhs": constraint.RHS,
            "terms": [
                {
                    "variable": row.getVar(k).VarName,
                    "type": row.getVar(k).VType,
                    "coefficient": row.getCoeff(k),
                    "binary_layer": variable_layer.get(row.getVar(k).VarName),
                    "within_layer_position": variable_position.get(row.getVar(k).VarName),
                }
                for k in range(row.size())
            ],
        }

    report = {
        "nodes": 15,
        "directed_base_arcs": len(base),
        "assignment_occurrence_histogram": dict(occurrence_histogram),
        "base_arc_bijection_valid": base_arc_bijection_valid,
        "base_arc_by_variable": base_arc,
        "base_variable_range": [base[0].VarName, base[-1].VarName],
        "binary_layers": len(layers),
        "variables_per_layer": 210,
        "base_layer_index_zero_based": base_layer_index,
        "binary_storage_order": binary_order,
        "base_residues_mod_107": dict(base_residues_mod_107),
        "two_variable_binary_link_rows": sum(link_relationships.values()),
        "binary_link_layer_pairs": dict(link_relationships),
        "binary_link_same_within_layer_position": dict(link_same_position),
        "link_examples": link_examples,
        "flow_layers": len(flow_rows_by_layer),
        "valid_15_row_flow_layers": sum(flow_layer_valid.values()),
        "all_detected_flow_layers_valid": all(flow_layer_valid.values()),
        "flow_rhs_row_pairs": flow_rhs_pairs,
        "flow_endpoint_pairs_zero_based": flow_endpoint_pairs,
        "all_unordered_node_pairs_represented": {
            tuple(sorted(pair)) for pair in flow_endpoint_pairs
        } == {(i, j) for i in range(15) for j in range(i + 1, 15)},
        "load_coefficient_set_size_by_flow_layer": dict(
            Counter(len(values) for values in coefficient_values_by_flow_layer.values())
        ),
        "load_coefficient_values_by_flow_layer": coefficient_values_by_flow_layer,
        "flow_commodities": flow_commodities,
        "continuous_variables": [v.VarName for v in continuous],
        "general_integer_range": [general[0].VarName, general[-1].VarName],
        "objective_variables": [v.VarName for v in variables if v.Obj != 0],
        "row_type_ranges": row_type_ranges,
        "representative_rows": [
            row_record(index) for index in (1, 2, 32, 214, 228, 242, 452, 1817, 1922, 2027, 24077, 24287)
        ],
    }
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
