# ns1631475 — OPT = 11,100

This directory archives a structure-specific global optimum proof for the
MIPLIB open instance `ns1631475`.

## Result

**The global optimum is 11,100.**

- Upper bound: the public solution has objective 11,100.  Direct evaluation of
  all original bounds, integer variables, and rows reports maximum row
  violation `7.958e-13`.
- Lower bound: the original matrix is verified to be a 15-node Hamiltonian
  ring carrying 105 all-pairs binary commodity flows.  Exact enumeration proves
  that every cyclic order has a contiguous interval whose demand cut is at
  least 22,050.  The interval has two boundary ring edges, and every edge load
  is a multiple of 150; therefore at least one boundary load is at least
  11,100.

The upper and lower bounds coincide.

## What is checked

[`verify_ring_optimality.py`](scripts/verify_ring_optimality.py) checks the
original MPS structure rather than trusting a reformulated model: 30 assignment
rows, 210 tour-edge equations, 1,575 flow-balance rows, 22,050 flow/link rows,
210 load equations, and 210 objective-domination rows.  It then audits the
public solution and reruns the exact cyclic-order enumeration.  The verifier
uses Gurobi only to read the MPS matrix and does not call optimization.

The DFS fixes node 0 to remove rotations and visits 218,831 prefixes.  It
proves that no cyclic order can keep every interval cut at or below 21,900.
All 62 positive demands are multiples of 150, so the next possible cut value
is 22,050.

## Reproduction

Python 3 and `gurobipy` are required for the full original-MPS audit.

```sh
python scripts/verify_ring_optimality.py \
  input/ns1631475.mps.gz artifacts/recovered-tsp-layers.json \
  solutions/official-best.sol.gz --output optimality-replay.json

python scripts/prove_cyclic_cutwidth.py \
  artifacts/recovered-tsp-layers.json --threshold 21900 \
  --output cutwidth-replay.json
```

The second command is solver-free and uses exact integer arithmetic.  The
3,600-second Gurobi run in `logs/` is retained only as baseline evidence; its
floating-point bound is not used in the proof.

## Key SHA-256 values

| File | SHA-256 |
|---|---|
| original MPS | `a8a42c5213f52fefb8c33ec451860378969b3e86dad261f9ba72df3769411e47` |
| public solution | `4800e65a4062d59c7f10d721ae5ce32214c0111057db1ddd28a14f05952fb5dc` |
| full verifier | `5f30c63107a131366de0e60cbf54a3d3c8ae66682c1bb92071b026262512115b` |
| verification record | `fc3ca85dca8fb8696dac9eff9b37da08c66ef380471d315767726c44c06a399c` |

See [`report.zh.md`](report.zh.md) for the Chinese derivation and evidence
boundary.
