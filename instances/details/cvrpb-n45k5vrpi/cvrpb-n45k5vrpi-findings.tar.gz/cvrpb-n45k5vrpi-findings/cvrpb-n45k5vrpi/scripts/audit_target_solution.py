"""Independently audit a complete solution against the untouched original MPS."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from cvrpb_forensics import (
    audit_assignment,
    extract_indicators,
    extract_linear_rows,
    load_model_read_only,
    parse_gurobi_solution,
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", type=Path, required=True)
    parser.add_argument("--solution", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    model = load_model_read_only(args.mps)
    rows = extract_linear_rows(model)
    indicators, types, errors = extract_indicators(model)
    if errors or types != {"INDICATOR": model.NumGenConstrs}:
        raise RuntimeError(f"general-constraint extraction failed: {types}, {errors[:5]}")
    parsed = parse_gurobi_solution(args.solution)
    result = audit_assignment(model, rows, indicators, parsed)
    result["objective_is_751"] = abs(float(result.get("computed_objective", 1e100)) - 751) <= 1e-7
    result["untouched_original_model"] = True
    args.out.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
