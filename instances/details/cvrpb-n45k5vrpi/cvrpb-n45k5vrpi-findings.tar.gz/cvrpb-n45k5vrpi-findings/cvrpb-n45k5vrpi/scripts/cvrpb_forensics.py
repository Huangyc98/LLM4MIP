#!/usr/bin/env python3
"""
Forensic reconstruction and route-lifting audit for cvrpb-n45k5vrpi.

Required inputs (defaults):
  input/cvrpb-n45k5vrpi.mps.gz
  input/cvrpb-n45k5vrpi-public-2.sol.gz
  input/B-n45-k5.vrp
  input/B-n45-k5.sol

Default behavior is read-only with respect to the original model: Gurobi is used
only to parse it. No presolve or optimization is performed.

Optional bounded validation:
  --complete --completion-time-limit 300

This fixes only structurally certified route-selector assignments, fixes the
objective to 751, changes the optimization objective to zero, and asks Gurobi
for a bounded feasibility completion. Such a result is explicitly reported as
a numerical validation, never as a structural proof.

Outputs:
  forensic-report.json
  lifted-751.partial.mst
  lifted-751-known-values.json
"""

from __future__ import annotations

import argparse
import collections
import gzip
import hashlib
import json
import math
import os
import re
import sys
import traceback
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Optional

try:
    import gurobipy as gp
    from gurobipy import GRB
except Exception as exc:
    print(f"fatal: gurobipy is required: {exc}", file=sys.stderr)
    raise SystemExit(2)


TOL = 1.0e-7
INT_TOL = 1.0e-6


# ---------------------------------------------------------------------------
# Utility and serialization
# ---------------------------------------------------------------------------

def open_text(path: Path):
    if path.suffix.lower() == ".gz":
        return gzip.open(path, "rt", encoding="utf-8", errors="replace")
    return path.open("rt", encoding="utf-8", errors="replace")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    opener = gzip.open if path.suffix.lower() == ".gz" else open
    with opener(path, "rb") as fh:
        while True:
            block = fh.read(1024 * 1024)
            if not block:
                break
            h.update(block)
    return h.hexdigest()


def finite_json(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): finite_json(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [finite_json(v) for v in value]
    if isinstance(value, float):
        if math.isnan(value):
            return None
        if math.isinf(value):
            return "inf" if value > 0 else "-inf"
        if abs(value) < 1e-15:
            return 0.0
    return value


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        json.dump(finite_json(data), fh, indent=2, sort_keys=True)
        fh.write("\n")


def near_int(x: float, tol: float = INT_TOL) -> bool:
    return abs(x - round(x)) <= tol


def is_binary_var(v: gp.Var) -> bool:
    if v.VType == GRB.BINARY:
        return True
    return (
        v.VType in (GRB.INTEGER, GRB.BINARY)
        and v.LB >= -TOL
        and v.UB <= 1.0 + TOL
    )


def has_unit_interval(v: gp.Var) -> bool:
    return v.LB >= -TOL and v.UB <= 1.0 + TOL


def constraint_violation(lhs: float, sense: str, rhs: float) -> float:
    if sense == "=":
        return abs(lhs - rhs)
    if sense == "<":
        return max(0.0, lhs - rhs)
    if sense == ">":
        return max(0.0, rhs - lhs)
    return float("inf")


def stable_number(x: float) -> int | float:
    if near_int(x):
        return int(round(x))
    return float(x)


# ---------------------------------------------------------------------------
# CVRPLIB and route-file parsing
# ---------------------------------------------------------------------------

@dataclass
class CVRPInstance:
    name: str
    dimension: int
    capacity: int
    edge_weight_type: str
    coordinates: dict[int, tuple[float, float]]
    demands: dict[int, int]
    depots: list[int]
    distances: dict[int, dict[int, int]]
    headers: dict[str, str]


@dataclass
class RouteSolution:
    routes: list[list[int]]
    declared_cost: Optional[int]
    parser_notes: list[str]


def parse_vrplib(path: Path) -> CVRPInstance:
    headers: dict[str, str] = {}
    coords: dict[int, tuple[float, float]] = {}
    demands: dict[int, int] = {}
    depots: list[int] = []
    explicit_numbers: list[int] = []

    section: Optional[str] = None
    with open_text(path) as fh:
        for raw in fh:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue

            upper = line.upper()
            if upper in {
                "NODE_COORD_SECTION",
                "DEMAND_SECTION",
                "DEPOT_SECTION",
                "EDGE_WEIGHT_SECTION",
            }:
                section = upper
                continue
            if upper == "EOF":
                break

            if section is None:
                if ":" in line:
                    key, value = line.split(":", 1)
                    headers[key.strip().upper()] = value.strip()
                else:
                    parts = line.split(None, 1)
                    if len(parts) == 2:
                        headers[parts[0].strip().upper()] = parts[1].strip()
                continue

            parts = line.split()
            if section == "NODE_COORD_SECTION":
                if len(parts) < 3:
                    raise ValueError(f"bad coordinate line: {line}")
                coords[int(parts[0])] = (float(parts[1]), float(parts[2]))
            elif section == "DEMAND_SECTION":
                if len(parts) < 2:
                    raise ValueError(f"bad demand line: {line}")
                demands[int(parts[0])] = int(float(parts[1]))
            elif section == "DEPOT_SECTION":
                node = int(parts[0])
                if node == -1:
                    section = None
                else:
                    depots.append(node)
            elif section == "EDGE_WEIGHT_SECTION":
                explicit_numbers.extend(int(float(x)) for x in parts)

    dimension = int(headers.get("DIMENSION", len(coords) or len(demands)))
    capacity = int(float(headers.get("CAPACITY", "0")))
    edge_type = headers.get("EDGE_WEIGHT_TYPE", "EUC_2D").upper()
    name = headers.get("NAME", path.stem)

    node_ids = sorted(set(coords) | set(demands))
    if len(node_ids) != dimension:
        raise ValueError(
            f"VRPLIB dimension {dimension}, but found node IDs {len(node_ids)}"
        )
    if len(depots) != 1:
        raise ValueError(f"expected one depot, found {depots}")

    distances: dict[int, dict[int, int]] = {
        i: {} for i in node_ids
    }

    if edge_type == "EUC_2D":
        if len(coords) != dimension:
            raise ValueError("EUC_2D instance lacks complete coordinates")
        for i in node_ids:
            xi, yi = coords[i]
            for j in node_ids:
                xj, yj = coords[j]
                distances[i][j] = int(math.floor(math.hypot(xi - xj, yi - yj) + 0.5))
    elif edge_type == "CEIL_2D":
        if len(coords) != dimension:
            raise ValueError("CEIL_2D instance lacks complete coordinates")
        for i in node_ids:
            xi, yi = coords[i]
            for j in node_ids:
                xj, yj = coords[j]
                distances[i][j] = int(math.ceil(math.hypot(xi - xj, yi - yj)))
    elif edge_type == "EXPLICIT":
        fmt = headers.get("EDGE_WEIGHT_FORMAT", "").upper()
        if fmt != "FULL_MATRIX":
            raise ValueError(f"unsupported explicit format: {fmt}")
        if len(explicit_numbers) != dimension * dimension:
            raise ValueError("explicit FULL_MATRIX has wrong number of entries")
        p = 0
        for i in node_ids:
            for j in node_ids:
                distances[i][j] = explicit_numbers[p]
                p += 1
    else:
        raise ValueError(f"unsupported EDGE_WEIGHT_TYPE: {edge_type}")

    return CVRPInstance(
        name=name,
        dimension=dimension,
        capacity=capacity,
        edge_weight_type=edge_type,
        coordinates=coords,
        demands=demands,
        depots=depots,
        distances=distances,
        headers=headers,
    )


def parse_route_solution(path: Path) -> RouteSolution:
    routes: list[list[int]] = []
    declared_cost: Optional[int] = None
    notes: list[str] = []

    route_re = re.compile(r"^\s*Route(?:\s*#?\s*\d+)?\s*:\s*(.*)$", re.I)
    cost_re = re.compile(
        r"^\s*(?:Cost|Objective|Value)\s*(?::|=|\s)\s*(-?\d+(?:\.\d+)?)",
        re.I,
    )

    with open_text(path) as fh:
        for raw in fh:
            line = raw.strip()
            if not line:
                continue
            m = route_re.match(line)
            if m:
                values = [int(x) for x in re.findall(r"-?\d+", m.group(1))]
                routes.append(values)
                continue
            m = cost_re.match(line)
            if m:
                value = float(m.group(1))
                if not near_int(value):
                    notes.append(f"nonintegral declared cost {value}")
                declared_cost = int(round(value))
                continue

    if not routes:
        raise ValueError(f"no routes parsed from {path}")

    return RouteSolution(routes, declared_cost, notes)


def normalize_and_audit_routes(
    inst: CVRPInstance,
    solution: RouteSolution,
) -> tuple[list[list[int]], dict[str, Any]]:
    depot = inst.depots[0]
    customers = set(inst.demands) - {depot}

    def evaluate(shift: int, convention: str):
        normalized, observed, route_loads, route_costs, unknown = [], [], [], [], []
        for raw_route in solution.routes:
            route = [node + shift for node in raw_route]
            if route and route[0] == depot:
                route = route[1:]
            if route and route[-1] == depot:
                route = route[:-1]
            normalized.append(route)
            observed.extend(route)
            unknown.extend(node for node in route if node not in inst.demands)
            route_loads.append(sum(inst.demands.get(node, 0) for node in route))
            sequence = [depot] + route + [depot]
            route_costs.append(
                sum(inst.distances[a][b] for a, b in zip(sequence, sequence[1:]))
                if all(node in inst.distances for node in sequence) else -1
            )
        counts = collections.Counter(observed)
        missing = sorted(customers - set(observed))
        duplicates = sorted(node for node, count in counts.items() if count > 1)
        extra = sorted(set(observed) - customers)
        cost = sum(route_costs) if all(value >= 0 for value in route_costs) else -1
        audit = {
            "label_convention": convention,
            "route_label_shift": shift,
            "route_count": len(normalized),
            "normalized_routes": normalized,
            "route_loads": route_loads,
            "route_costs": route_costs,
            "computed_cost": cost,
            "declared_cost": solution.declared_cost,
            "declared_cost_matches": solution.declared_cost is None or solution.declared_cost == cost,
            "capacity": inst.capacity,
            "capacity_feasible": all(value <= inst.capacity for value in route_loads),
            "missing_customers": missing,
            "duplicate_customers": duplicates,
            "extra_or_depot_customers": extra,
            "unknown_nodes": sorted(set(unknown)),
            "customer_cover_exact": not missing and not duplicates and not extra,
        }
        audit["canonical_solution_verified"] = bool(
            audit["customer_cover_exact"] and audit["capacity_feasible"]
            and audit["declared_cost_matches"] and not audit["unknown_nodes"]
        )
        return normalized, audit

    candidates = [
        evaluate(0, "TSPLIB_NODE_LABELS"),
        evaluate(1, "CVRPLIB_ZERO_BASED_CUSTOMERS_SHIFTED_PLUS_ONE"),
    ]
    verified = [candidate for candidate in candidates
                if candidate[1]["canonical_solution_verified"]]
    normalized, audit = verified[0] if len(verified) == 1 else candidates[0]
    audit["label_convention_verified"] = len(verified) == 1
    audit["candidate_label_conventions"] = [
        {
            "label_convention": candidate_audit["label_convention"],
            "route_label_shift": candidate_audit["route_label_shift"],
            "computed_cost": candidate_audit["computed_cost"],
            "customer_cover_exact": candidate_audit["customer_cover_exact"],
            "capacity_feasible": candidate_audit["capacity_feasible"],
            "declared_cost_matches": candidate_audit["declared_cost_matches"],
            "verified": candidate_audit["canonical_solution_verified"],
        }
        for _, candidate_audit in candidates
    ]
    audit["parser_notes"] = solution.parser_notes
    audit["canonical_solution_verified"] &= len(verified) == 1
    return normalized, audit


# ---------------------------------------------------------------------------
# Gurobi model extraction
# ---------------------------------------------------------------------------

@dataclass
class LinearRow:
    name: str
    sense: str
    rhs: float
    terms: list[tuple[gp.Var, float]]


@dataclass
class IndicatorRecord:
    name: str
    binvar: gp.Var
    binval: int
    sense: str
    rhs: float
    terms: list[tuple[gp.Var, float]]


def load_model_read_only(path: Path) -> gp.Model:
    env = gp.Env(empty=True)
    env.setParam("OutputFlag", 0)
    env.start()
    model = gp.read(str(path), env=env)
    model.update()
    return model


def extract_linear_rows(model: gp.Model) -> list[LinearRow]:
    rows: list[LinearRow] = []
    for constr in model.getConstrs():
        expr = model.getRow(constr)
        terms = [(expr.getVar(i), float(expr.getCoeff(i)))
                 for i in range(expr.size())]
        rows.append(
            LinearRow(
                name=constr.ConstrName,
                sense=constr.Sense,
                rhs=float(constr.RHS),
                terms=terms,
            )
        )
    return rows


def extract_indicators(
    model: gp.Model,
) -> tuple[list[IndicatorRecord], dict[str, int], list[str]]:
    indicators: list[IndicatorRecord] = []
    type_counts: collections.Counter[str] = collections.Counter()
    errors: list[str] = []

    type_names = {
        getattr(GRB, "GENCONSTR_MAX", -100): "MAX",
        getattr(GRB, "GENCONSTR_MIN", -101): "MIN",
        getattr(GRB, "GENCONSTR_ABS", -102): "ABS",
        getattr(GRB, "GENCONSTR_AND", -103): "AND",
        getattr(GRB, "GENCONSTR_OR", -104): "OR",
        getattr(GRB, "GENCONSTR_INDICATOR", -105): "INDICATOR",
        getattr(GRB, "GENCONSTR_PWL", -106): "PWL",
        getattr(GRB, "GENCONSTR_POLY", -107): "POLY",
        getattr(GRB, "GENCONSTR_EXP", -108): "EXP",
        getattr(GRB, "GENCONSTR_EXPA", -109): "EXPA",
        getattr(GRB, "GENCONSTR_LOG", -110): "LOG",
        getattr(GRB, "GENCONSTR_LOGA", -111): "LOGA",
        getattr(GRB, "GENCONSTR_POW", -112): "POW",
        getattr(GRB, "GENCONSTR_SIN", -113): "SIN",
        getattr(GRB, "GENCONSTR_COS", -114): "COS",
        getattr(GRB, "GENCONSTR_TAN", -115): "TAN",
        getattr(GRB, "GENCONSTR_LOGISTIC", -116): "LOGISTIC",
        getattr(GRB, "GENCONSTR_NL", -117): "NL",
    }

    indicator_type = getattr(GRB, "GENCONSTR_INDICATOR", None)

    for gc in model.getGenConstrs():
        try:
            gtype = int(gc.GenConstrType)
        except Exception:
            gtype = -999
        tname = type_names.get(gtype, f"TYPE_{gtype}")
        type_counts[tname] += 1

        if indicator_type is None or gtype != indicator_type:
            continue

        try:
            binvar, binval, expr, sense, rhs = model.getGenConstrIndicator(gc)
            terms = [
                (expr.getVar(i), float(expr.getCoeff(i)))
                for i in range(expr.size())
            ]
            indicators.append(
                IndicatorRecord(
                    name=gc.GenConstrName,
                    binvar=binvar,
                    binval=int(binval),
                    sense=sense,
                    rhs=float(rhs),
                    terms=terms,
                )
            )
        except Exception as exc:
            errors.append(f"{gc.GenConstrName}: {type(exc).__name__}: {exc}")

    return indicators, dict(type_counts), errors


# ---------------------------------------------------------------------------
# Cost-row recognition and canonical matching
# ---------------------------------------------------------------------------

@dataclass
class CostRowCandidate:
    row_name: str
    output_var: gp.Var
    selectors: list[tuple[gp.Var, int]]
    raw_row: LinearRow


def recognize_cost_rows(
    rows: list[LinearRow],
    expected_customers: int,
) -> tuple[list[CostRowCandidate], list[dict[str, Any]]]:
    candidates: list[CostRowCandidate] = []
    rejected_near_matches: list[dict[str, Any]] = []

    expected_degree = expected_customers + 1

    for row in rows:
        if row.sense != "=" or abs(row.rhs) > TOL:
            continue
        if len(row.terms) != expected_degree:
            continue

        negative_units = [
            (v, c) for v, c in row.terms if abs(c + 1.0) <= TOL
        ]
        positive_integer_terms = [
            (v, c) for v, c in row.terms
            if c > TOL and near_int(c)
        ]

        if len(negative_units) == 1 and len(positive_integer_terms) == expected_customers:
            output = negative_units[0][0]
            selectors = [
                (v, int(round(c))) for v, c in positive_integer_terms
            ]
            if all(has_unit_interval(v) for v, _ in selectors):
                candidates.append(
                    CostRowCandidate(row.name, output, selectors, row)
                )
            else:
                rejected_near_matches.append({
                    "row": row.name,
                    "reason": "positive coefficient variables not all bounded in [0,1]",
                    "invalid_selector_domains": [
                        {
                            "name": v.VarName,
                            "type": v.VType,
                            "lb": v.LB,
                            "ub": v.UB,
                        }
                        for v, _ in selectors if not has_unit_interval(v)
                    ][:10],
                })

    return candidates, rejected_near_matches


def canonical_customer_signatures(
    inst: CVRPInstance,
) -> dict[int, tuple[int, ...]]:
    depot = inst.depots[0]
    customers = sorted(set(inst.distances) - {depot})
    signatures: dict[int, tuple[int, ...]] = {}
    all_nodes = sorted(inst.distances)
    for i in customers:
        signatures[i] = tuple(sorted(
            inst.distances[i][j] for j in all_nodes if j != i
        ))
    return signatures


def bipartite_perfect_matching(
    left: list[Any],
    adjacency: dict[Any, set[Any]],
) -> Optional[dict[Any, Any]]:
    order = sorted(left, key=lambda x: (len(adjacency.get(x, set())), str(x)))
    match_right: dict[Any, Any] = {}

    def augment(u: Any, seen: set[Any]) -> bool:
        for v in sorted(adjacency.get(u, set()), key=str):
            if v in seen:
                continue
            seen.add(v)
            if v not in match_right or augment(match_right[v], seen):
                match_right[v] = u
                return True
        return False

    for u in order:
        if not augment(u, set()):
            return None
    return {u: v for v, u in match_right.items()}


def matching_is_unique(
    left: list[Any],
    adjacency: dict[Any, set[Any]],
    matching: dict[Any, Any],
) -> bool:
    for u, v in matching.items():
        reduced = {x: set(ys) for x, ys in adjacency.items()}
        reduced[u].discard(v)
        if bipartite_perfect_matching(left, reduced) is not None:
            return False
    return True


def match_cost_rows_to_origins(
    inst: CVRPInstance,
    cost_rows: list[CostRowCandidate],
) -> dict[str, Any]:
    canonical = canonical_customer_signatures(inst)
    adjacency: dict[str, set[int]] = {}

    for row in cost_rows:
        signature = tuple(sorted(cost for _, cost in row.selectors))
        adjacency[row.row_name] = {
            node for node, sig in canonical.items() if sig == signature
        }

    left = [row.row_name for row in cost_rows]
    matching = None
    unique = False
    if len(left) == len(canonical) and all(adjacency.get(x) for x in left):
        matching = bipartite_perfect_matching(left, adjacency)
        if matching is not None:
            unique = matching_is_unique(left, adjacency, matching)

    return {
        "candidate_origins": {
            name: sorted(nodes) for name, nodes in adjacency.items()
        },
        "perfect_matching_exists": matching is not None,
        "matching_unique": unique,
        "row_to_canonical_origin": matching or {},
        "certified": bool(matching is not None and unique),
    }


# ---------------------------------------------------------------------------
# Indicator-label extraction and destination matching
# ---------------------------------------------------------------------------

def extract_selector_labels(
    indicators: list[IndicatorRecord],
    selector_names: set[str],
) -> tuple[dict[str, set[int]], dict[str, list[dict[str, Any]]]]:
    """
    A label k is accepted only from an active implication of the exact form

        selector == 1  ->  (+/-) index_variable == rhs

    where the implied index value is integral. The index variable identity is
    retained as evidence. Labels are not yet interpreted as node IDs.
    """
    labels: dict[str, set[int]] = collections.defaultdict(set)
    evidence: dict[str, list[dict[str, Any]]] = collections.defaultdict(list)

    for ind in indicators:
        if ind.binvar.VarName not in selector_names or ind.binval != 1:
            continue
        if ind.sense != "=" or len(ind.terms) != 1:
            continue

        ivar, coef = ind.terms[0]
        if abs(coef) <= TOL:
            continue
        value = ind.rhs / coef
        if not near_int(value):
            continue

        k = int(round(value))
        labels[ind.binvar.VarName].add(k)
        evidence[ind.binvar.VarName].append({
            "indicator": ind.name,
            "index_variable": ivar.VarName,
            "coefficient": stable_number(coef),
            "rhs": stable_number(ind.rhs),
            "implied_value": k,
        })

    return dict(labels), dict(evidence)


def match_labels_to_destinations(
    inst: CVRPInstance,
    cost_rows: list[CostRowCandidate],
    row_origin_match: dict[str, Any],
    selector_labels: dict[str, set[int]],
) -> dict[str, Any]:
    if not row_origin_match.get("certified"):
        return {
            "certified": False,
            "reason": "row-to-origin matching is not unique and certified",
            "label_to_canonical_destination": {},
        }

    row_to_origin: dict[str, int] = {
        str(k): int(v)
        for k, v in row_origin_match["row_to_canonical_origin"].items()
    }

    observations: dict[int, list[tuple[int, int, str]]] = collections.defaultdict(list)
    ambiguous_selector_labels: dict[str, list[int]] = {}
    unlabeled_selectors: list[str] = []

    for row in cost_rows:
        origin = row_to_origin[row.row_name]
        for selector, cost in row.selectors:
            labs = selector_labels.get(selector.VarName, set())
            if len(labs) == 1:
                label = next(iter(labs))
                observations[label].append((origin, cost, selector.VarName))
            elif len(labs) == 0:
                unlabeled_selectors.append(selector.VarName)
            else:
                ambiguous_selector_labels[selector.VarName] = sorted(labs)

    all_nodes = sorted(inst.distances)
    adjacency: dict[int, set[int]] = {}

    for label, obs in observations.items():
        compatible: set[int] = set()
        for destination in all_nodes:
            good = True
            for origin, cost, _ in obs:
                if destination == origin:
                    good = False
                    break
                if inst.distances[origin][destination] != cost:
                    good = False
                    break
            if good:
                compatible.add(destination)
        adjacency[label] = compatible

    labels = sorted(observations)
    matching = None
    unique = False

    if (
        len(labels) == inst.dimension
        and all(adjacency.get(label) for label in labels)
    ):
        matching = bipartite_perfect_matching(labels, adjacency)
        if matching is not None:
            unique = matching_is_unique(labels, adjacency, matching)

    selector_to_destination: dict[str, int] = {}
    if matching is not None and unique:
        for selector_name, labs in selector_labels.items():
            if len(labs) == 1:
                label = next(iter(labs))
                if label in matching:
                    selector_to_destination[selector_name] = matching[label]

    complete_selector_mapping = (
        matching is not None
        and unique
        and not ambiguous_selector_labels
        and all(
            selector.VarName in selector_to_destination
            for row in cost_rows
            for selector, _ in row.selectors
        )
    )

    return {
        "labels_observed": labels,
        "label_count": len(labels),
        "candidate_destinations": {
            str(k): sorted(v) for k, v in adjacency.items()
        },
        "perfect_matching_exists": matching is not None,
        "matching_unique": unique,
        "label_to_canonical_destination": (
            {str(k): int(v) for k, v in matching.items()}
            if matching is not None else {}
        ),
        "ambiguous_selector_labels": ambiguous_selector_labels,
        "unlabeled_selector_count": len(set(unlabeled_selectors)),
        "unlabeled_selector_examples": sorted(set(unlabeled_selectors))[:50],
        "selector_to_canonical_destination": selector_to_destination,
        "all_cost_selectors_mapped": complete_selector_mapping,
        "depot_label": (
            next(
                (int(label) for label, node in (matching or {}).items()
                 if node == inst.depots[0]),
                None,
            )
        ),
        "certified": complete_selector_mapping,
    }


def direct_destination_candidates(
    inst: CVRPInstance,
    cost_rows: list[CostRowCandidate],
    row_origin_match: dict[str, Any],
) -> dict[str, list[int]]:
    result: dict[str, list[int]] = {}
    if not row_origin_match.get("certified"):
        return result

    row_to_origin = row_origin_match["row_to_canonical_origin"]
    all_nodes = sorted(inst.distances)
    for row in cost_rows:
        origin = int(row_to_origin[row.row_name])
        for selector, cost in row.selectors:
            result[selector.VarName] = [
                j for j in all_nodes
                if j != origin and inst.distances[origin][j] == cost
            ]
    return result


# ---------------------------------------------------------------------------
# Objective, demand/capacity, and vehicle-convention evidence
# ---------------------------------------------------------------------------

def objective_definition_audit(
    model: gp.Model,
    rows: list[LinearRow],
) -> dict[str, Any]:
    objective_vars = [
        v for v in model.getVars() if abs(v.Obj) > TOL
    ]
    result: dict[str, Any] = {
        "objective_constant": stable_number(model.ObjCon),
        "objective_sense": "min" if model.ModelSense == GRB.MINIMIZE else "max",
        "objective_variables": [
            {
                "name": v.VarName,
                "coefficient": stable_number(v.Obj),
                "type": v.VType,
                "lb": stable_number(v.LB),
                "ub": stable_number(v.UB),
            }
            for v in objective_vars
        ],
        "definition_rows": {},
        "single_objective_variable": len(objective_vars) == 1,
    }

    for ov in objective_vars:
        incidents = []
        for row in rows:
            coeff = next((c for v, c in row.terms if v.VarName == ov.VarName), None)
            if coeff is not None:
                incidents.append({
                    "row": row.name,
                    "sense": row.sense,
                    "rhs": stable_number(row.rhs),
                    "objective_coefficient_in_row": stable_number(coeff),
                    "degree": len(row.terms),
                    "terms": [
                        [v.VarName, stable_number(c)] for v, c in row.terms
                    ],
                })
        result["definition_rows"][ov.VarName] = incidents

    result["affine_cvrp_objective_verified"] = False
    result["reason"] = (
        "raw objective definition is reported, but an affine projection to "
        "canonical arc cost is not asserted without complete symbolic elimination"
    )
    return result


def demand_capacity_evidence(
    inst: CVRPInstance,
    rows: list[LinearRow],
    indicators: list[IndicatorRecord],
    model: gp.Model,
) -> dict[str, Any]:
    depot = inst.depots[0]
    canonical_demands = [
        inst.demands[i] for i in sorted(inst.demands) if i != depot
    ]
    demand_multiset = collections.Counter(canonical_demands)

    exact_weight_rows = []
    subset_weight_rows = []

    for row in rows:
        coeffs = [
            abs(int(round(c)))
            for _, c in row.terms
            if near_int(c) and abs(c) > TOL
        ]
        counter = collections.Counter(coeffs)

        if counter == demand_multiset:
            exact_weight_rows.append(row.name)
        elif sum((counter & demand_multiset).values()) >= max(
            5, len(canonical_demands) // 2
        ):
            subset_weight_rows.append({
                "row": row.name,
                "degree": len(row.terms),
                "matching_demand_coefficients": sum(
                    (counter & demand_multiset).values()
                ),
            })

    capacity = inst.capacity
    cap_rhs_linear = [
        row.name for row in rows
        if near_int(row.rhs) and abs(int(round(row.rhs))) == capacity
    ]
    cap_rhs_indicators = [
        ind.name for ind in indicators
        if near_int(ind.rhs) and abs(int(round(ind.rhs))) == capacity
    ]

    cap_bound_vars = [
        {
            "name": v.VarName,
            "type": v.VType,
            "lb": stable_number(v.LB),
            "ub": stable_number(v.UB),
        }
        for v in model.getVars()
        if (
            (math.isfinite(v.UB) and near_int(v.UB) and int(round(v.UB)) == capacity)
            or (math.isfinite(v.LB) and near_int(v.LB)
                and abs(int(round(v.LB))) == capacity)
        )
    ]

    verified = bool(
        exact_weight_rows
        and (cap_rhs_linear or cap_rhs_indicators or cap_bound_vars)
    )

    return {
        "canonical_capacity": capacity,
        "canonical_demands_by_node": {
            str(k): v for k, v in sorted(inst.demands.items())
        },
        "canonical_customer_demand_multiset": dict(sorted(demand_multiset.items())),
        "exact_demand_multiset_linear_rows": exact_weight_rows,
        "partial_demand_pattern_rows": subset_weight_rows[:100],
        "linear_rows_with_capacity_rhs": cap_rhs_linear,
        "indicator_constraints_with_capacity_rhs": cap_rhs_indicators,
        "variables_with_capacity_bound": cap_bound_vars[:100],
        "raw_mps_demand_capacity_recovery_verified": verified,
        "interpretation": (
            "verified coefficient and capacity signatures found"
            if verified else
            "canonical data are not claimed recovered from raw MPS; evidence is insufficient"
        ),
    }


def vehicle_convention_evidence(
    rows: list[LinearRow],
    indicators: list[IndicatorRecord],
    expected_vehicles: int,
) -> dict[str, Any]:
    exact_sum_equalities = []
    rhs_rows = []

    for row in rows:
        if near_int(row.rhs) and abs(int(round(row.rhs))) == expected_vehicles:
            rhs_rows.append({
                "row": row.name,
                "sense": row.sense,
                "degree": len(row.terms),
                "coefficients": sorted(stable_number(c) for _, c in row.terms),
            })
        if (
            row.sense == "="
            and abs(row.rhs - expected_vehicles) <= TOL
            and row.terms
            and all(abs(c - 1.0) <= TOL and is_binary_var(v)
                    for v, c in row.terms)
        ):
            exact_sum_equalities.append({
                "row": row.name,
                "variables": [v.VarName for v, _ in row.terms],
            })

    indicator_rhs = [
        {
            "name": ind.name,
            "binvar": ind.binvar.VarName,
            "binval": ind.binval,
            "sense": ind.sense,
            "degree": len(ind.terms),
        }
        for ind in indicators
        if near_int(ind.rhs) and abs(int(round(ind.rhs))) == expected_vehicles
    ]

    return {
        "expected_from_canonical_name_and_solution": expected_vehicles,
        "exact_binary_sum_equalities": exact_sum_equalities,
        "other_linear_rows_with_abs_rhs_5": rhs_rows[:100],
        "indicators_with_abs_rhs_5": indicator_rhs[:100],
        "exactly_five_nonempty_routes_verified_from_raw_mps": bool(
            exact_sum_equalities
        ),
        "warning": (
            None if exact_sum_equalities else
            "no direct exactly-five binary sum was certified; the convention may "
            "be encoded indirectly through sequence separators or fixed labels"
        ),
    }


# ---------------------------------------------------------------------------
# Public incumbent parsing and feasibility audit
# ---------------------------------------------------------------------------

def parse_gurobi_solution(path: Path) -> dict[str, Any]:
    values: dict[str, float] = {}
    objective: Optional[float] = None
    duplicate_names: list[str] = []
    format_name = "unknown"
    implicit_zero = False

    with open_text(path) as fh:
        text = fh.read()

    if "<solution" in text.lower() or "<variables" in text.lower():
        format_name = "gurobi_xml"
        obj_match = re.search(
            r'objectiveValue\s*=\s*"([^"]+)"', text, re.I
        )
        if obj_match:
            objective = float(obj_match.group(1))

        for m in re.finditer(
            r'<variable\b[^>]*\bname\s*=\s*"([^"]+)"[^>]*\bvalue\s*=\s*"([^"]+)"',
            text,
            re.I,
        ):
            name, raw = m.group(1), m.group(2)
            if name in values:
                duplicate_names.append(name)
            values[name] = float(raw)
    else:
        format_name = "gurobi_text_or_sparse"
        for raw in text.splitlines():
            line = raw.strip()
            if not line:
                continue
            metadata = re.match(
                r"^\s*=(?:obj|objective)=\s*([+\-0-9.eE]+)\s*$", line, re.I
            )
            if metadata:
                objective = float(metadata.group(1))
                implicit_zero = True
                format_name = "official_sparse_solution"
                continue
            if line.startswith("#"):
                m = re.search(r"objective value\s*=\s*([+\-0-9.eE]+)", line, re.I)
                if m:
                    objective = float(m.group(1))
                continue
            parts = line.split()
            if len(parts) < 2:
                continue
            try:
                value = float(parts[1])
            except ValueError:
                continue
            name = parts[0]
            if name in values:
                duplicate_names.append(name)
            values[name] = value

    return {
        "values": values,
        "declared_objective": objective,
        "format": format_name,
        "implicit_zero_for_omitted_variables": implicit_zero,
        "duplicate_names": sorted(set(duplicate_names)),
    }


def audit_assignment(
    model: gp.Model,
    rows: list[LinearRow],
    indicators: list[IndicatorRecord],
    parsed_solution: dict[str, Any],
) -> dict[str, Any]:
    supplied: dict[str, float] = parsed_solution["values"]
    model_vars = {v.VarName: v for v in model.getVars()}
    unknown_names = sorted(set(supplied) - set(model_vars))
    missing_names = sorted(set(model_vars) - set(supplied))
    implicit_zero = bool(parsed_solution.get("implicit_zero_for_omitted_variables"))
    complete = not missing_names or implicit_zero
    assigned = {name: supplied.get(name, 0.0) for name in model_vars}

    result: dict[str, Any] = {
        "format": parsed_solution["format"],
        "declared_objective": parsed_solution["declared_objective"],
        "supplied_variable_count": len(supplied),
        "model_variable_count": len(model_vars),
        "assignment_complete": complete,
        "missing_variable_count": len(missing_names),
        "missing_variable_examples": missing_names[:50],
        "unknown_solution_names": unknown_names[:50],
        "duplicate_solution_names": parsed_solution["duplicate_names"],
        "unspecified_values_treated_as_zero": implicit_zero,
    }

    if not complete:
        result.update({
            "linear_feasibility_verified": False,
            "indicator_feasibility_verified": False,
            "objective_verified": False,
            "audit_status": "incomplete_assignment_fail_closed",
        })
        return result

    bound_violations = []
    integrality_violations = []
    for name, var in model_vars.items():
        x = assigned[name]
        viol = max(0.0, var.LB - x, x - var.UB)
        if viol > TOL:
            bound_violations.append((viol, name, x, var.LB, var.UB))
        if var.VType in (GRB.INTEGER, GRB.BINARY) and not near_int(x):
            integrality_violations.append((abs(x - round(x)), name, x))

    linear_violations = []
    max_linear = 0.0
    for row in rows:
        lhs = sum(c * assigned[v.VarName] for v, c in row.terms)
        viol = constraint_violation(lhs, row.sense, row.rhs)
        max_linear = max(max_linear, viol)
        if viol > TOL:
            linear_violations.append((viol, row.name, lhs, row.sense, row.rhs))

    indicator_violations = []
    active_indicators = 0
    for ind in indicators:
        b = assigned[ind.binvar.VarName]
        active = abs(b - ind.binval) <= INT_TOL
        if not active:
            continue
        active_indicators += 1
        lhs = sum(c * assigned[v.VarName] for v, c in ind.terms)
        viol = constraint_violation(lhs, ind.sense, ind.rhs)
        if viol > TOL:
            indicator_violations.append(
                (viol, ind.name, lhs, ind.sense, ind.rhs)
            )

    computed_objective = (
        model.ObjCon
        + sum(v.Obj * assigned[v.VarName] for v in model.getVars())
    )
    declared = parsed_solution["declared_objective"]
    objective_matches_declared = (
        declared is None or abs(computed_objective - declared) <= TOL
    )

    unsupported_count = (
        model.NumGenConstrs - len(indicators)
    )

    result.update({
        "computed_objective": stable_number(computed_objective),
        "objective_matches_declared": objective_matches_declared,
        "objective_is_775": abs(computed_objective - 775.0) <= TOL,
        "max_bound_violation": max(
            (x[0] for x in bound_violations), default=0.0
        ),
        "bound_violation_count": len(bound_violations),
        "bound_violation_examples": [
            {
                "violation": v,
                "variable": n,
                "value": x,
                "lb": lb,
                "ub": ub,
            }
            for v, n, x, lb, ub in sorted(bound_violations, reverse=True)[:20]
        ],
        "integrality_violation_count": len(integrality_violations),
        "integrality_violation_examples": [
            {"violation": v, "variable": n, "value": x}
            for v, n, x in sorted(integrality_violations, reverse=True)[:20]
        ],
        "max_linear_violation": max_linear,
        "linear_violation_count": len(linear_violations),
        "linear_violation_examples": [
            {
                "violation": v,
                "row": n,
                "lhs": lhs,
                "sense": sense,
                "rhs": rhs,
            }
            for v, n, lhs, sense, rhs
            in sorted(linear_violations, reverse=True)[:20]
        ],
        "active_indicator_count": active_indicators,
        "indicator_violation_count": len(indicator_violations),
        "indicator_violation_examples": [
            {
                "violation": v,
                "indicator": n,
                "lhs": lhs,
                "sense": sense,
                "rhs": rhs,
            }
            for v, n, lhs, sense, rhs
            in sorted(indicator_violations, reverse=True)[:20]
        ],
        "unsupported_general_constraint_count": unsupported_count,
        "linear_feasibility_verified": (
            not bound_violations
            and not integrality_violations
            and not linear_violations
        ),
        "indicator_feasibility_verified": not indicator_violations,
        "all_general_constraints_verified": (
            not indicator_violations and unsupported_count == 0
        ),
        "objective_verified": objective_matches_declared,
        "audit_status": (
            "fully_verified"
            if (
                not bound_violations
                and not integrality_violations
                and not linear_violations
                and not indicator_violations
                and unsupported_count == 0
                and objective_matches_declared
            )
            else "partially_verified_or_violated"
        ),
    })
    return result


# ---------------------------------------------------------------------------
# Route-selector lifting and deterministic propagation
# ---------------------------------------------------------------------------

def route_arc_maps(
    inst: CVRPInstance,
    routes: list[list[int]],
) -> tuple[dict[int, int], dict[int, int], list[tuple[int, int]]]:
    depot = inst.depots[0]
    successor: dict[int, int] = {}
    predecessor: dict[int, int] = {}
    arcs: list[tuple[int, int]] = []

    for route in routes:
        seq = [depot] + route + [depot]
        for a, b in zip(seq, seq[1:]):
            arcs.append((a, b))
            if a != depot:
                if a in successor and successor[a] != b:
                    raise ValueError(f"multiple successors for customer {a}")
                successor[a] = b
            if b != depot:
                if b in predecessor and predecessor[b] != a:
                    raise ValueError(f"multiple predecessors for customer {b}")
                predecessor[b] = a

    return successor, predecessor, arcs


def seed_route_selectors(
    inst: CVRPInstance,
    routes: list[list[int]],
    cost_rows: list[CostRowCandidate],
    row_origin_match: dict[str, Any],
    selector_to_destination: dict[str, int],
    direct_candidates: dict[str, list[int]],
) -> dict[str, Any]:
    """
    Construct only those route-selector assignments whose semantic meaning is
    certified by a unique cost-row origin and a unique selector destination.

    No value is guessed for an unresolved selector. A selector is seeded to zero
    only when it belongs to a certified cost row and the complete destination
    map for that row is known; otherwise the entire row is left unresolved.
    """
    result: dict[str, Any] = {
        "status": "not_attempted",
        "known_values": {},
        "known_selector_count": 0,
        "unresolved_rows": [],
        "unresolved_selectors": [],
        "selected_arcs": [],
        "route_arc_count": 0,
        "semantic_projection_verified": False,
        "warnings": [],
    }

    if not row_origin_match.get("certified", False):
        result["status"] = "blocked"
        result["warnings"].append(
            "cost-row origins are not uniquely matched to canonical customers"
        )
        return result

    try:
        successor, predecessor, arcs = route_arc_maps(inst, routes)
    except Exception as exc:
        result["status"] = "blocked"
        result["warnings"].append(f"route structure invalid: {exc}")
        return result

    result["selected_arcs"] = [[int(a), int(b)] for a, b in arcs]
    result["route_arc_count"] = len(arcs)

    row_to_origin = {
        str(k): int(v)
        for k, v in row_origin_match["row_to_canonical_origin"].items()
    }
    selected_arc_set = set(arcs)
    known: dict[str, float] = {}
    unresolved_rows: list[str] = []
    unresolved_selectors: set[str] = set()
    row_records: list[dict[str, Any]] = []

    for row in cost_rows:
        origin = row_to_origin.get(row.row_name)
        if origin is None:
            unresolved_rows.append(row.row_name)
            continue

        row_selector_destinations: dict[str, int] = {}
        row_unresolved = False

        for selector, cost in row.selectors:
            name = selector.VarName
            destination: Optional[int] = None

            if name in selector_to_destination:
                destination = int(selector_to_destination[name])
            else:
                candidates = direct_candidates.get(name, [])
                if len(candidates) == 1:
                    destination = int(candidates[0])

            # A destination is usable only if it is uniquely inferred and
            # exactly reproduces this selector's coefficient.
            if destination is None:
                row_unresolved = True
                unresolved_selectors.add(name)
                continue
            if destination == origin or inst.distances[origin][destination] != cost:
                row_unresolved = True
                unresolved_selectors.add(name)
                continue
            row_selector_destinations[name] = destination

        if row_unresolved:
            unresolved_rows.append(row.row_name)
            continue

        # A complete, certified row can be seeded: exactly one selector
        # corresponding to each possible destination receives value one iff the
        # route uses that arc; all other selectors receive zero.
        selected_in_row = 0
        for selector, _ in row.selectors:
            destination = row_selector_destinations[selector.VarName]
            value = 1.0 if (origin, destination) in selected_arc_set else 0.0
            known[selector.VarName] = value
            selected_in_row += int(value)

        # A route solution must choose precisely one outgoing successor for
        # every customer represented by a cost row.
        if origin != inst.depots[0] and selected_in_row != 1:
            result["warnings"].append(
                f"route does not induce one selected outgoing arc for origin {origin}"
            )
        row_records.append({
            "row": row.row_name,
            "origin": origin,
            "selected_count": selected_in_row,
            "complete": True,
        })

    # Do not claim a complete semantic lift unless every cost row was certified
    # and every customer has exactly one outgoing route arc.
    customers = set(inst.demands) - {inst.depots[0]}
    outgoing_ok = all(
        sum(1 for a, _ in arcs if a == customer) == 1
        for customer in customers
    )
    incoming_ok = all(
        sum(1 for _, b in arcs if b == customer) == 1
        for customer in customers
    )

    result["known_values"] = known
    result["known_selector_count"] = len(known)
    result["unresolved_rows"] = sorted(set(unresolved_rows))
    result["unresolved_selectors"] = sorted(unresolved_selectors)
    result["row_records"] = row_records
    result["route_outgoing_exact"] = outgoing_ok
    result["route_incoming_exact"] = incoming_ok
    result["all_cost_rows_seeded"] = not unresolved_rows
    result["semantic_projection_verified"] = bool(
        not unresolved_rows and outgoing_ok and incoming_ok
    )
    result["status"] = (
        "certified_semantic_selector_seed"
        if result["semantic_projection_verified"]
        else "partial_seed_fail_closed"
    )
    if not result["semantic_projection_verified"]:
        result["warnings"].append(
            "unresolved flattened variables or incomplete semantic channeling; "
            "no full lift is claimed"
        )
    return result


def write_partial_mst(
    path: Path,
    values: dict[str, float],
) -> None:
    """
    Write a sparse Gurobi MIP start. Only certified values are emitted.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        fh.write("# certified partial route-selector seed\n")
        for name in sorted(values):
            value = values[name]
            fh.write(f"{name} {value:.17g}\n")


def write_known_values(
    path: Path,
    values: dict[str, float],
) -> None:
    write_json(
        path,
        {
            "value_count": len(values),
            "values": {
                name: stable_number(value)
                for name, value in sorted(values.items())
            },
        },
    )


def bounded_completion(
    model: gp.Model,
    known_values: dict[str, float],
    objective_value: int,
    time_limit: float,
) -> dict[str, Any]:
    """
    Optional numerical feasibility validation.

    This intentionally operates on a copy and does not optimize the original
    model. It is not a proof certificate: UNKNOWN/TIME_LIMIT and even FEASIBLE
    are reported only as numerical results.
    """
    result: dict[str, Any] = {
        "requested": True,
        "status": "not_run",
        "proof_status": "not_a_structural_proof",
        "known_values_fixed": len(known_values),
        "objective_fixed": objective_value,
        "time_limit_seconds": time_limit,
    }

    try:
        work = model.copy()
        work.update()
        work.Params.OutputFlag = 0
        work.Params.TimeLimit = max(0.0, float(time_limit))
        work.Params.MIPGap = 0.0
        work.Params.MIPGapAbs = 0.0

        variables = {v.VarName: v for v in work.getVars()}
        missing = sorted(set(known_values) - set(variables))
        if missing:
            result["status"] = "blocked_unknown_variables"
            result["unknown_known_value_names"] = missing[:100]
            return result

        fixed_count = 0
        for name, value in known_values.items():
            v = variables[name]
            if value < v.LB - TOL or value > v.UB + TOL:
                result["status"] = "blocked_bound_conflict"
                result["bound_conflict"] = {
                    "name": name,
                    "value": value,
                    "lb": v.LB,
                    "ub": v.UB,
                }
                return result
            v.LB = value
            v.UB = value
            fixed_count += 1

        objective_vars = [v for v in work.getVars() if abs(v.Obj) > TOL]
        objective_expr = gp.LinExpr(work.ObjCon)
        for v in objective_vars:
            objective_expr.add(v, v.Obj)

        work.addConstr(objective_expr == float(objective_value),
                       name="forensic_fixed_objective")
        work.setObjective(0.0, GRB.MINIMIZE)
        work.update()

        started = time.time()
        work.optimize()
        elapsed = time.time() - started

        status_code = work.Status
        status_name = {
            GRB.LOADED: "LOADED",
            GRB.OPTIMAL: "FEASIBLE",
            GRB.INFEASIBLE: "INFEASIBLE",
            GRB.INF_OR_UNBD: "INF_OR_UNBD",
            GRB.UNBOUNDED: "UNBOUNDED",
            GRB.CUTOFF: "CUTOFF",
            GRB.ITERATION_LIMIT: "ITERATION_LIMIT",
            GRB.NODE_LIMIT: "NODE_LIMIT",
            GRB.TIME_LIMIT: "TIME_LIMIT",
            GRB.SOLUTION_LIMIT: "SOLUTION_LIMIT",
            GRB.INTERRUPTED: "INTERRUPTED",
            GRB.NUMERIC: "NUMERIC",
            GRB.SUBOPTIMAL: "SUBOPTIMAL",
            GRB.INPROGRESS: "INPROGRESS",
            GRB.USER_OBJ_LIMIT: "USER_OBJ_LIMIT",
        }.get(status_code, f"STATUS_{status_code}")

        result.update({
            "status": status_name,
            "elapsed_seconds": elapsed,
            "fixed_count": fixed_count,
            "work_model_variables": work.NumVars,
            "work_model_linear_constraints": work.NumConstrs,
            "work_model_general_constraints": work.NumGenConstrs,
            "has_solution": work.SolCount > 0,
        })

        if work.SolCount > 0:
            result["completion_candidate"] = True
            result["candidate_objective"] = stable_number(
                work.ObjCon + sum(v.Obj * v.X for v in work.getVars())
            )
            result["note"] = (
                "A feasible completion was found numerically; this does not "
                "prove formulation equivalence or optimality."
            )
        else:
            result["completion_candidate"] = False
            result["note"] = (
                "No completion was found within the bounded run; this does not "
                "prove infeasibility."
            )
        return result

    except Exception as exc:
        result["status"] = "error"
        result["error"] = f"{type(exc).__name__}: {exc}"
        return result


def summarize_model(
    model: gp.Model,
    rows: list[LinearRow],
    indicators: list[IndicatorRecord],
    indicator_types: dict[str, int],
) -> dict[str, Any]:
    type_counts = collections.Counter(v.VType for v in model.getVars())
    sense_counts = collections.Counter(c.Sense for c in model.getConstrs())
    objective_variables = [
        {
            "name": v.VarName,
            "type": v.VType,
            "lb": stable_number(v.LB),
            "ub": stable_number(v.UB),
            "objective": stable_number(v.Obj),
        }
        for v in model.getVars() if abs(v.Obj) > TOL
    ]

    return {
        "model_name": model.ModelName,
        "variables": model.NumVars,
        "linear_constraints": model.NumConstrs,
        "general_constraints": model.NumGenConstrs,
        "indicator_constraints_extracted": len(indicators),
        "variable_type_counts": dict(type_counts),
        "linear_constraint_sense_counts": dict(sense_counts),
        "objective_constant": stable_number(model.ObjCon),
        "objective_variables": objective_variables,
        "general_constraint_type_counts": indicator_types,
        "raw_rows_extracted": len(rows),
    }


def build_report(args: argparse.Namespace) -> dict[str, Any]:
    paths = {
        "mps": Path(args.mps),
        "public_incumbent": Path(args.public_incumbent),
        "canonical_vrp": Path(args.canonical_vrp),
        "canonical_solution": Path(args.canonical_solution),
    }

    for key, path in paths.items():
        if not path.exists():
            raise FileNotFoundError(f"{key}: {path}")

    inst = parse_vrplib(paths["canonical_vrp"])
    canonical_solution = parse_route_solution(paths["canonical_solution"])
    canonical_routes, canonical_route_audit = normalize_and_audit_routes(
        inst, canonical_solution
    )

    model = load_model_read_only(paths["mps"])
    rows = extract_linear_rows(model)
    indicators, indicator_types, indicator_errors = extract_indicators(model)

    cost_rows, rejected_cost_rows = recognize_cost_rows(
        rows, expected_customers=inst.dimension - 1
    )
    row_origin_match = match_cost_rows_to_origins(inst, cost_rows)
    direct_candidates = direct_destination_candidates(
        inst, cost_rows, row_origin_match
    )

    # Labels are extracted only from exact singleton indicator equalities.
    selector_names = {
        selector.VarName
        for row in cost_rows
        for selector, _ in row.selectors
    }
    selector_labels, selector_label_evidence = extract_selector_labels(
        indicators, selector_names
    )
    label_match = match_labels_to_destinations(
        inst,
        cost_rows,
        row_origin_match,
        selector_labels,
    )

    selector_to_destination = label_match.get(
        "selector_to_canonical_destination", {}
    )

    # Direct cost equality is accepted only for singleton candidates. If a
    # selector has a unique direct destination, it is structurally safer than
    # interpreting an opaque integer label.
    for name, candidates in direct_candidates.items():
        if len(candidates) == 1:
            selector_to_destination.setdefault(name, int(candidates[0]))

    objective_audit = objective_definition_audit(model, rows)
    demand_capacity = demand_capacity_evidence(
        inst, rows, indicators, model
    )
    vehicle_convention = vehicle_convention_evidence(
        rows, indicators, expected_vehicles=5
    )

    incumbent_parsed = parse_gurobi_solution(paths["public_incumbent"])
    incumbent_audit = audit_assignment(
        model, rows, indicators, incumbent_parsed
    )

    lifting = seed_route_selectors(
        inst=inst,
        routes=canonical_routes,
        cost_rows=cost_rows,
        row_origin_match=row_origin_match,
        selector_to_destination=selector_to_destination,
        direct_candidates=direct_candidates,
    )

    output_mst = Path(args.output_mst)
    output_known = Path(args.output_known_values)
    write_partial_mst(output_mst, lifting["known_values"])
    write_known_values(output_known, lifting["known_values"])

    completion = {
        "requested": False,
        "status": "not_requested",
        "proof_status": "not_a_structural_proof",
    }
    if args.complete:
        if lifting["semantic_projection_verified"]:
            completion = bounded_completion(
                model=model,
                known_values=lifting["known_values"],
                objective_value=751,
                time_limit=args.completion_time_limit,
            )
        else:
            completion = {
                "requested": True,
                "status": "blocked_structural_seed_incomplete",
                "proof_status": "not_a_structural_proof",
                "reason": (
                    "bounded completion is not attempted when route-selector "
                    "semantics are not certified"
                ),
            }

    canonical_distance_matrix = {
        str(i): {
            str(j): inst.distances[i][j]
            for j in sorted(inst.distances)
        }
        for i in sorted(inst.distances)
    }

    identity = {
        "name_match_only": inst.name.upper() == "B-N45-K5",
        "dimension_matches_45": inst.dimension == 45,
        "single_depot": len(inst.depots) == 1,
        "canonical_depot": inst.depots[0],
        "capacity_from_canonical_file": inst.capacity,
        "five_route_file_routes": len(canonical_routes) == 5,
        "canonical_route_solution_verified": canonical_route_audit[
            "canonical_solution_verified"
        ],
        "cost_row_candidate_count": len(cost_rows),
        "cost_row_origin_matching": row_origin_match,
        "selector_destination_matching": label_match,
        "full_matrix_recovered_from_mps": False,
        "coordinate_or_matrix_identity_verified": False,
        "demand_identity_verified": False,
        "capacity_identity_verified_from_mps": demand_capacity[
            "raw_mps_demand_capacity_recovery_verified"
        ],
        "five_vehicle_convention_verified_from_mps": vehicle_convention[
            "exactly_five_nonempty_routes_verified_from_raw_mps"
        ],
        "objective_offset_verified": False,
        "formulation_equivalence_verified": False,
        "identity_claim": False,
        "identity_reason": (
            "The program reports exact evidence only. It does not infer "
            "identity from the filename, coefficient signatures, or a "
            "successful numerical completion."
        ),
    }

    report = {
        "program": "forensic-reconstruction-and-lifting",
        "version": 1,
        "inputs": {
            key: {
                "path": str(path),
                "sha256": sha256_file(path),
            }
            for key, path in paths.items()
        },
        "canonical_instance": {
            "name": inst.name,
            "dimension": inst.dimension,
            "capacity": inst.capacity,
            "edge_weight_type": inst.edge_weight_type,
            "depot": inst.depots[0],
            "headers": inst.headers,
            "demands": {
                str(k): v for k, v in sorted(inst.demands.items())
            },
            "distance_matrix": canonical_distance_matrix,
        },
        "canonical_solution_audit": canonical_route_audit,
        "model_summary": summarize_model(
            model, rows, indicators, indicator_types
        ),
        "indicator_extraction_errors": indicator_errors,
        "cost_row_reconstruction": {
            "candidate_count": len(cost_rows),
            "rows": [
                {
                    "row": row.row_name,
                    "output": row.output_var.VarName,
                    "selectors": [
                        [v.VarName, stable_number(c)]
                        for v, c in row.selectors
                    ],
                }
                for row in cost_rows
            ],
            "rejected_near_matches": rejected_cost_rows,
            "direct_selector_destination_candidates": {
                name: values
                for name, values in sorted(direct_candidates.items())
            },
            "selector_label_evidence": selector_label_evidence,
        },
        "identity_tests": identity,
        "objective_audit": objective_audit,
        "demand_capacity_evidence": demand_capacity,
        "vehicle_convention_evidence": vehicle_convention,
        "public_incumbent_audit": incumbent_audit,
        "lifting": {
            key: value for key, value in lifting.items()
            if key != "known_values"
        },
        "output_files": {
            "partial_mst": str(output_mst),
            "known_values": str(output_known),
        },
        "bounded_completion": completion,
        "proof_status": {
            "cost_751_candidate": bool(
                canonical_route_audit["computed_cost"] == 751
            ),
            "lifted_candidate_structurally_seeded": bool(
                lifting["semantic_projection_verified"]
            ),
            "bounded_feasibility_validation": completion["status"],
            "optimality_proof": "none",
            "lower_bound_750_proof": "none",
            "statement": (
                "Neither a candidate lift nor bounded feasibility validation "
                "constitutes an optimality proof. A lower-bound proof at 750 "
                "requires a separate exact certificate or a proven semantic "
                "formulation equivalence."
            ),
        },
    }

    return report


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Read-only forensic audit and conservative route lifting"
    )
    parser.add_argument(
        "--mps",
        default="input/cvrpb-n45k5vrpi.mps.gz",
    )
    parser.add_argument(
        "--public-incumbent",
        default="input/cvrpb-n45k5vrpi-public-2.sol.gz",
    )
    parser.add_argument(
        "--canonical-vrp",
        default="input/B-n45-k5.vrp",
    )
    parser.add_argument(
        "--canonical-solution",
        default="input/B-n45-k5.sol",
    )
    parser.add_argument(
        "--output-report",
        default="forensic-report.json",
    )
    parser.add_argument(
        "--output-mst",
        default="lifted-751.partial.mst",
    )
    parser.add_argument(
        "--output-known-values",
        default="lifted-751-known-values.json",
    )
    parser.add_argument(
        "--complete",
        action="store_true",
        help=(
            "perform optional bounded numerical general-constraint "
            "feasibility completion on a model copy"
        ),
    )
    parser.add_argument(
        "--completion-time-limit",
        type=float,
        default=300.0,
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    try:
        report = build_report(args)
        write_json(Path(args.output_report), report)

        # Compact terminal status; the machine-readable report is authoritative.
        print(json.dumps({
            "report": args.output_report,
            "incumbent_audit": report["public_incumbent_audit"]["audit_status"],
            "canonical_cost": report["canonical_solution_audit"]["computed_cost"],
            "canonical_solution_verified": report[
                "canonical_solution_audit"
            ]["canonical_solution_verified"],
            "candidate_seed_status": report["lifting"]["status"],
            "candidate_seed_values": report["lifting"]["known_selector_count"],
            "bounded_completion": report["bounded_completion"]["status"],
            "identity_claim": report["identity_tests"]["identity_claim"],
            "optimality_proof": report["proof_status"]["optimality_proof"],
        }, sort_keys=True))
        return 0

    except Exception as exc:
        traceback.print_exc()
        error = {
            "program": "forensic-reconstruction-and-lifting",
            "status": "fatal_error",
            "error_type": type(exc).__name__,
            "error": str(exc),
            "identity_claim": False,
            "optimality_proof": "none",
        }
        try:
            write_json(Path(args.output_report), error)
        except Exception:
            pass
        print(json.dumps(error, sort_keys=True), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
