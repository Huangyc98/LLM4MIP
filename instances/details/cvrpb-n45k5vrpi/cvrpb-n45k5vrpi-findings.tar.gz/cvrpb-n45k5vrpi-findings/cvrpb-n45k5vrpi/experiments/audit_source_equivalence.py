#!/usr/bin/env python3
"""Check every data-level link from B-n45-k5 to cvrpb-n45k5vrpi."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
from pathlib import Path


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parse_vrp(path: Path):
    text = path.read_text(encoding="utf-8")
    dimension = int(re.search(r"DIMENSION\s*:\s*(\d+)", text).group(1))
    capacity = int(re.search(r"CAPACITY\s*:\s*(\d+)", text).group(1))
    coord_part = text.split("NODE_COORD_SECTION", 1)[1].split("DEMAND_SECTION", 1)[0]
    demand_part = text.split("DEMAND_SECTION", 1)[1].split("DEPOT_SECTION", 1)[0]
    coords = {}
    demands = {}
    for line in coord_part.splitlines():
        tok = line.split()
        if len(tok) == 3:
            coords[int(tok[0])] = (int(tok[1]), int(tok[2]))
    for line in demand_part.splitlines():
        tok = line.split()
        if len(tok) == 2:
            demands[int(tok[0])] = int(tok[1])
    return dimension, capacity, coords, demands


def parse_dzn(path: Path):
    text = path.read_text(encoding="utf-8")
    n = int(re.search(r"\bN\s*=\s*(\d+)\s*;", text).group(1))
    capacity = int(re.search(r"\bCapacity\s*=\s*(\d+)\s*;", text).group(1))
    d = [int(x) for x in re.findall(r"-?\d+", re.search(r"Demand\s*=\s*\[(.*?)\]\s*;", text, re.S).group(1))]
    matrix = []
    raw_matrix = re.search(r"Distance\s*=\s*\[\|(.*?)\|\]\s*;", text, re.S).group(1)
    for row in raw_matrix.split("|"):
        values = [int(x) for x in re.findall(r"-?\d+", row)]
        if values:
            matrix.append(values)
    return n, capacity, d, matrix


def parse_routes(path: Path):
    routes = []
    stated = None
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.startswith("Route #"):
            routes.append([int(x) for x in line.split(":", 1)[1].split()])
        elif line.startswith("Cost "):
            stated = int(line.split()[1])
    return routes, stated


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("vrp", type=Path)
    ap.add_argument("dzn", type=Path)
    ap.add_argument("routes", type=Path)
    ap.add_argument("mzn", type=Path)
    ap.add_argument("--json", type=Path, required=True)
    args = ap.parse_args()

    dimension, vrp_capacity, coords, vrp_demands = parse_vrp(args.vrp)
    n, dzn_capacity, demand, distance = parse_dzn(args.dzn)
    routes, stated_cost = parse_routes(args.routes)
    rounded = []
    for i in range(1, dimension + 1):
        row = []
        for j in range(1, dimension + 1):
            dx = coords[i][0] - coords[j][0]
            dy = coords[i][1] - coords[j][1]
            # TSPLIB EUC_2D: nint(sqrt(dx^2+dy^2)).
            row.append(math.floor(math.sqrt(dx * dx + dy * dy) + 0.5))
        rounded.append(row)
    demand_expected = [vrp_demands[i] for i in range(2, dimension + 1)]
    distance_mismatches = [
        [i, j, rounded[i][j], distance[i][j]]
        for i in range(dimension)
        for j in range(dimension)
        if rounded[i][j] != distance[i][j]
    ]
    customer_point_mapping = [
        {
            "minizinc_customer": customer,
            "cvrplib_node": customer + 1,
            "coordinate": list(coords[customer + 1]),
            "demand_vrp": vrp_demands[customer + 1],
            "demand_dzn": demand[customer - 1],
        }
        for customer in range(1, n + 1)
    ]

    flat = [customer for route in routes for customer in route]
    route_loads = [sum(demand[c - 1] for c in route) for route in routes]
    route_costs = []
    for route in routes:
        chain = [0, *route, 0]
        route_costs.append(sum(distance[a][b] for a, b in zip(chain, chain[1:])))

    # The MiniZinc model bounds every arrival time by timeBudget.  Check that
    # this is redundant for this data set rather than silently deleting CVRP
    # routes.  A capacity-feasible route can contain at most the maximum
    # number of smallest positive demands that fit in one vehicle.  Multiplying
    # its number of depot/customer arcs by the largest matrix entry is a safe
    # (deliberately crude) upper bound on its travel time.
    time_budget = sum(max(distance[i][j] for j in range(n)) for i in range(n))
    demand_sum = 0
    max_customers_per_route = 0
    for value in sorted(demand):
        if demand_sum + value > dzn_capacity:
            break
        demand_sum += value
        max_customers_per_route += 1
    maximum_distance_entry = max(max(row) for row in distance)
    route_time_safe_upper_bound = (max_customers_per_route + 1) * maximum_distance_entry

    model_text = args.mzn.read_text(encoding="utf-8")
    required_model_fragments = {
        "free_fleet_maximum_N": "int: nbVehicles = N;",
        "three_N_giant_tour_nodes": "set of int: NODES = 1..nbCustomers+2*nbVehicles;",
        "fixed_end_to_next_start_connectors": "successor[n] = n-nbVehicles+1",
        "last_end_to_first_start_connector": "successor[nbCustomers+2*nbVehicles] = nbCustomers+1;",
        "start_vehicle_labels": "vehicle[n] = n-nbCustomers",
        "end_vehicle_labels": "vehicle[n] = n-nbCustomers-nbVehicles",
        "start_time_zero": "arrivalTime[n] = 0",
        "successor_circuit": "circuit(successor)",
        "successor_vehicle_propagation": "vehicle[successor[n]] = vehicle[n]",
        "customer_time_accumulation": "arrivalTime[n] + distance[n,successor[n]] <= arrivalTime[successor[n]]",
        "customer_load_accumulation": "load[n] + demand[n] = load[successor[n]]",
        "start_load_propagation": "load[n] = load[successor[n]]",
        "objective_is_sum_of_end_arrivals": "objective = sum (depot in END_DEPOT_NODES) (arrivalTime[depot]);",
    }
    model_fragment_checks = {name: fragment in model_text for name, fragment in required_model_fragments.items()}

    report = {
        "source_sha256": {"vrp": sha(args.vrp), "dzn": sha(args.dzn), "routes": sha(args.routes), "mzn": sha(args.mzn)},
        "dimension_original_points_including_depot": dimension,
        "minizinc_customers": n,
        "node_mapping": (
            f"MiniZinc customer c in 1..{n} equals TSPLIB/CVRPLIB node c+1; "
            "DZN matrix index 0 is depot node 1."
        ),
        "depot": {"cvrplib_node": 1, "dzn_matrix_index": 0, "coordinate": list(coords[1]), "demand": vrp_demands[1]},
        "customer_point_mapping": customer_point_mapping,
        "capacity_vrp": vrp_capacity,
        "capacity_dzn": dzn_capacity,
        "demand_entries_checked": len(demand),
        "demand_mismatches": [
            [i + 1, a, b] for i, (a, b) in enumerate(zip(demand_expected, demand)) if a != b
        ],
        "distance_entries_checked": dimension * dimension,
        "distance_rule": "TSPLIB EUC_2D = floor(sqrt(dx^2+dy^2)+0.5)",
        "distance_mismatches": distance_mismatches,
        "all_customer_demands_positive": all(value > 0 for value in demand),
        "time_budget": time_budget,
        "maximum_distance_entry": maximum_distance_entry,
        "maximum_customers_per_capacity_feasible_route": max_customers_per_route,
        "route_time_safe_upper_bound": route_time_safe_upper_bound,
        "time_budget_is_redundant_for_capacity_feasible_routes": route_time_safe_upper_bound <= time_budget,
        "routes": routes,
        "route_count": len(routes),
        "route_loads": route_loads,
        "route_costs": route_costs,
        "route_coverage_count": len(flat),
        "route_coverage_exactly_1_to_N": (
            sorted(flat) == list(range(1, n + 1)) and len(set(flat)) == n
        ),
        "all_route_loads_at_most_capacity": all(x <= dzn_capacity for x in route_loads),
        "stated_cost": stated_cost,
        "recomputed_cost": sum(route_costs),
        "total_demand": sum(demand),
        "minimum_route_count_from_total_demand": math.ceil(sum(demand) / dzn_capacity),
        "model_fragment_checks": model_fragment_checks,
        "all_data_checks_pass": (
            dimension == n + 1 and vrp_capacity == dzn_capacity
            and demand_expected == demand and all(value > 0 for value in demand) and not distance_mismatches
            and route_time_safe_upper_bound <= time_budget
            and sorted(flat) == list(range(1, n + 1)) and len(set(flat)) == n
            and all(x <= dzn_capacity for x in route_loads)
            and stated_cost is not None and sum(route_costs) == stated_cost
            and all(model_fragment_checks.values())
        ),
    }
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))
    if not report["all_data_checks_pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
