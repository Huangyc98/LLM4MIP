#!/usr/bin/env python3
"""Lift the published B-n45-k5 routes into the anonymous indicator MPS.

The first 5*132 variables of the MPS are the MiniZinc arrays successor,
predecessor, vehicle, load, and arrivalTime, in declaration order.  Fixing
those semantic variables leaves only compiler-introduced auxiliaries.  COPT is
used on CPU to complete these deterministic auxiliaries and write a full MPS
solution.
"""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

import coptpy as cp
from coptpy import COPT


N = 44
NODE_COUNT = 3 * N


def parse_dzn(path: Path) -> tuple[list[int], list[list[int]]]:
    text = path.read_text(encoding="utf-8")
    n = int(re.search(r"\bN\s*=\s*(\d+)\s*;", text).group(1))
    if n != N:
        raise ValueError(f"expected N={N}, got {n}")
    demand_text = re.search(r"Demand\s*=\s*\[(.*?)\]\s*;", text, re.S).group(1)
    demands = [int(x) for x in re.findall(r"-?\d+", demand_text)]
    distance_text = re.search(r"Distance\s*=\s*\[\|(.*?)\|\]\s*;", text, re.S).group(1)
    rows = []
    for raw in distance_text.split("|"):
        values = [int(x) for x in re.findall(r"-?\d+", raw)]
        if values:
            rows.append(values)
    if len(demands) != N or len(rows) != N + 1 or any(len(row) != N + 1 for row in rows):
        raise ValueError("unexpected DZN dimensions")
    return demands, rows


def parse_routes(path: Path) -> tuple[list[list[int]], int]:
    routes = []
    cost = None
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.startswith("Route #"):
            routes.append([int(x) for x in line.split(":", 1)[1].split()])
        elif line.startswith("Cost "):
            cost = int(line.split()[1])
    if cost is None:
        raise ValueError("route file has no Cost line")
    return routes, cost


def build_semantic_values(demands: list[int], distance: list[list[int]], routes: list[list[int]]):
    successor = [0] * NODE_COUNT
    predecessor = [0] * NODE_COUNT
    vehicle = [0] * NODE_COUNT
    load = [0] * NODE_COUNT
    arrival = [0] * NODE_COUNT

    # Node labels are 1-based in MiniZinc. Customers are 1..44, starts
    # 45..88, ends 89..132.  The CVRPLIB solution labels customers 1..44,
    # exactly matching the shifted MiniZinc customer labels.
    assigned = set()
    route_costs = []
    route_loads = []
    for k in range(1, N + 1):
        start = N + k
        end = 2 * N + k
        route = routes[k - 1] if k <= len(routes) else []
        chain = [start, *route, end]
        for a, b in zip(chain, chain[1:]):
            successor[a - 1] = b
        for c in route:
            if c in assigned or not 1 <= c <= N:
                raise ValueError(f"bad or duplicated customer {c}")
            assigned.add(c)
            vehicle[c - 1] = k
        vehicle[start - 1] = vehicle[end - 1] = k

        cumulative_load = 0
        cumulative_distance = 0
        arrival[start - 1] = 0
        load[start - 1] = 0
        previous = None  # None denotes the original depot (DZN index 0).
        for c in route:
            load[c - 1] = cumulative_load
            cumulative_load += demands[c - 1]
            dzn_c = c  # customer c maps to DZN node c (0 is the depot)
            cumulative_distance += distance[0 if previous is None else previous][dzn_c]
            arrival[c - 1] = cumulative_distance
            previous = dzn_c
        if previous is not None:
            cumulative_distance += distance[previous][0]
        arrival[end - 1] = cumulative_distance
        load[end - 1] = cumulative_load
        route_costs.append(cumulative_distance)
        route_loads.append(cumulative_load)

    if assigned != set(range(1, N + 1)):
        raise ValueError(f"customers missing: {sorted(set(range(1, N + 1)) - assigned)}")

    # Fixed links end(k)->start(k+1), wrapping around, form the giant circuit.
    for k in range(1, N + 1):
        end = 2 * N + k
        next_start = N + (k % N) + 1
        successor[end - 1] = next_start
    for a, b in enumerate(successor, start=1):
        if not 1 <= b <= NODE_COUNT or predecessor[b - 1] != 0:
            raise ValueError(f"successor is not a permutation at {a}->{b}")
        predecessor[b - 1] = a

    semantic = successor + predecessor + vehicle + load + arrival
    return semantic, {
        "successor": successor,
        "predecessor": predecessor,
        "vehicle": vehicle,
        "load": load,
        "arrival_time": arrival,
        "route_costs": route_costs,
        "route_loads": route_loads,
        "objective": sum(route_costs),
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("mps", type=Path)
    ap.add_argument("dzn", type=Path)
    ap.add_argument("routes", type=Path)
    ap.add_argument("out", type=Path)
    ap.add_argument("--seconds", type=float, default=600)
    ap.add_argument("--threads", type=int, default=32)
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    demands, distance = parse_dzn(args.dzn)
    routes, stated_cost = parse_routes(args.routes)
    semantic, decoded = build_semantic_values(demands, distance, routes)
    if decoded["objective"] != stated_cost:
        raise ValueError(f"recomputed {decoded['objective']} != stated {stated_cost}")
    (args.out / "semantic-witness.json").write_text(
        json.dumps(decoded, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )

    model = cp.Envr().createModel("cvrpb-route-lift")
    model.read(str(args.mps))
    variables_obj = model.getVars()
    variables = variables_obj.getAll() if hasattr(variables_obj, "getAll") else list(variables_obj)
    by_name = {v.name: v for v in variables}
    missing = []
    fixed_semantic = 0
    for i, value in enumerate(semantic):
        name = f"X_INTRODUCED_{i}_"
        variable = by_name.get(name)
        if variable is None:
            missing.append(name)
            # The compiler substitutes source variables fixed by the model's
            # initialization equations, so their numeric IDs are absent from
            # the final MPS COLUMNS section.
            continue
        variable.setInfo(COPT.Info.LB, value)
        variable.setInfo(COPT.Info.UB, value)
        fixed_semantic += 1
    objective = by_name["objective"]
    objective.setInfo(COPT.Info.LB, stated_cost)
    objective.setInfo(COPT.Info.UB, stated_cost)

    model.setParam(COPT.Param.Logging, 1)
    model.setLogFile(str(args.out / "copt-route-lift.log"))
    model.setParam(COPT.Param.Threads, args.threads)
    model.setParam(COPT.Param.TimeLimit, args.seconds)
    model.setParam(COPT.Param.RelGap, 0.0)
    try:
        model.setParam(COPT.Param.GPUMode, 0)
    except Exception:
        pass
    model.solve()
    result = {
        "copt_version": [COPT.VERSION_MAJOR, COPT.VERSION_MINOR, COPT.VERSION_TECHNICAL],
        "cpu_only_gpu_mode": 0,
        "model_variables_after_copt_read": len(variables),
        "model_rows_after_copt_read": len(model.getConstrs()),
        "semantic_variables_fixed": fixed_semantic + 1,
        "source_array_ids_substituted_by_compiler": missing,
        "route_count_nonempty": len(routes),
        "stated_and_recomputed_objective": stated_cost,
        "status": int(model.status),
        "has_mip_solution": int(model.hasmipsol),
    }
    for key, attr in (
        ("objective", "objval"),
        ("best_bound", "bestbnd"),
        ("relative_gap", "mipgap"),
        ("node_count", "nodecnt"),
        ("runtime", "solvingtime"),
    ):
        try:
            result[key] = float(getattr(model, attr))
        except Exception:
            pass
    if model.hasmipsol:
        model.writeSol(str(args.out / "cvrpb-751-full.sol"))
    (args.out / "copt-route-lift-summary.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print("RESULT_JSON=" + json.dumps(result, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
