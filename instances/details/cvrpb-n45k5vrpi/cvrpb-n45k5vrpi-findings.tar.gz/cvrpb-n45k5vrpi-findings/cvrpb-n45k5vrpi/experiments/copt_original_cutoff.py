#!/usr/bin/env python3
"""Test feasibility of the original indicator MPS below an objective cutoff.

This deliberately keeps every row, bound, integrality declaration, and
indicator from the downloaded MPS.  The only model changes are an upper bound
on the existing variable named ``objective`` and replacement of the objective
function by the constant zero.  Therefore an INFEASIBLE terminal status is a
direct certificate for the original MPS, independent of source recovery.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import time
from pathlib import Path

import coptpy as cp
from coptpy import COPT


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        while block := stream.read(1 << 20):
            h.update(block)
    return h.hexdigest()


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("mps", type=Path)
    ap.add_argument("out", type=Path)
    ap.add_argument("--maximum-objective", type=float, default=750.0)
    ap.add_argument("--seconds", type=float, default=3600.0)
    ap.add_argument("--threads", type=int, default=32)
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    model = cp.Envr().createModel("cvrpb-original-cutoff")
    model.read(str(args.mps))
    variables_obj = model.getVars()
    variables = variables_obj.getAll() if hasattr(variables_obj, "getAll") else list(variables_obj)
    by_name = {variable.name: variable for variable in variables}
    objective = by_name["objective"]
    original_lb = float(objective.getInfo(COPT.Info.LB))
    original_ub = float(objective.getInfo(COPT.Info.UB))
    objective.setInfo(COPT.Info.UB, args.maximum_objective)
    model.setObjective(0.0, COPT.MINIMIZE)

    model.setParam(COPT.Param.Logging, 1)
    model.setLogFile(str(args.out / "copt-original-cutoff.log"))
    model.setParam(COPT.Param.Threads, args.threads)
    model.setParam(COPT.Param.TimeLimit, args.seconds)
    model.setParam(COPT.Param.RelGap, 0.0)
    try:
        model.setParam(COPT.Param.GPUMode, 0)
    except Exception:
        pass

    started = time.time()
    model.solve()
    elapsed = time.time() - started
    result = {
        "schema": "cvrpb-original-cutoff-v1",
        "copt_version": [COPT.VERSION_MAJOR, COPT.VERSION_MINOR, COPT.VERSION_TECHNICAL],
        "mps": str(args.mps),
        "mps_sha256": sha256(args.mps),
        "model_variables": len(variables),
        "model_rows": len(model.getConstrs()),
        "objective_variable": "objective",
        "objective_original_lower_bound": original_lb,
        "objective_original_upper_bound": original_ub,
        "objective_upper_bound_enforced": args.maximum_objective,
        "solve_objective": "constant zero (feasibility)",
        "all_original_constraints_retained": True,
        "status": int(model.status),
        "has_mip_solution": int(model.hasmipsol),
        "threads": args.threads,
        "time_limit_seconds": args.seconds,
        "cpu_only_gpu_mode": 0,
        "runtime_wall": elapsed,
        "script_sha256": sha256(Path(__file__).resolve()),
    }
    for key, attr in (
        ("node_count", "nodecnt"),
        ("runtime_reported", "solvingtime"),
        ("best_bound_for_zero_objective", "bestbnd"),
    ):
        try:
            result[key] = float(getattr(model, attr))
        except Exception:
            pass
    if model.hasmipsol:
        model.writeSol(str(args.out / "cutoff-feasible.sol"))
    if int(model.status) == int(COPT.INFEASIBLE):
        result["proof_statement"] = (
            f"The exact downloaded indicator MPS has no feasible solution with objective <= "
            f"{args.maximum_objective:g}."
        )
    (args.out / "copt-original-cutoff-summary.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print("RESULT_JSON=" + json.dumps(result, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
