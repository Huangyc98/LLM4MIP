#!/usr/bin/env python3
"""Record whether the euler4 restricted license permits original optimization."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import gurobipy as gp


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("mps", type=Path)
    ap.add_argument("out", type=Path)
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    model = gp.read(str(args.mps))
    model.Params.Threads = 32
    model.Params.TimeLimit = 60
    model.Params.LogFile = str(args.out / "gurobi-original-optimize-probe.log")
    result = {
        "gurobi_version": list(gp.gurobi.version()),
        "variables": model.NumVars,
        "linear_constraints": model.NumConstrs,
        "general_constraints": model.NumGenConstrs,
        "cpu_only": True,
        "attempt": "optimize original indicator MIP for at most 60 seconds",
    }
    try:
        model.optimize()
        result.update({"optimization_call_permitted": True, "status": int(model.Status)})
    except gp.GurobiError as exc:
        result.update({
            "optimization_call_permitted": False,
            "gurobi_error_code": int(exc.errno),
            "gurobi_error": str(exc),
        })
    (args.out / "gurobi-original-optimize-probe.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
