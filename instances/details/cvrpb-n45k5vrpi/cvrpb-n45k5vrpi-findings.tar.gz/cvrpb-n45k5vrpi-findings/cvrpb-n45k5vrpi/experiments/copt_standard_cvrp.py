#!/usr/bin/env python3
"""Solve the free-fleet B-n45-k5 CVRP with a compact flow formulation.

This is an independent semantic model, not the large MiniZinc compilation.
Single-commodity load flow enforces capacity and eliminates customer subtours.
The number of routes is not fixed; only the valid demand lower bound is used.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
from pathlib import Path

import coptpy as cp
from coptpy import COPT


def parse_dzn(path: Path):
    text = path.read_text(encoding="utf-8")
    n = int(re.search(r"\bN\s*=\s*(\d+)\s*;", text).group(1))
    demand_text = re.search(r"Demand\s*=\s*\[(.*?)\]\s*;", text, re.S).group(1)
    demands = [0] + [int(x) for x in re.findall(r"-?\d+", demand_text)]
    distance_text = re.search(r"Distance\s*=\s*\[\|(.*?)\|\]\s*;", text, re.S).group(1)
    distance = []
    for raw in distance_text.split("|"):
        row = [int(x) for x in re.findall(r"-?\d+", raw)]
        if row:
            distance.append(row)
    if n != 44 or len(demands) != 45 or len(distance) != 45 or any(len(r) != 45 for r in distance):
        raise ValueError("unexpected instance dimensions")
    return demands, distance


def parse_routes(path: Path):
    routes = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.startswith("Route #"):
            routes.append([int(x) for x in line.split(":", 1)[1].split()])
    return routes


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("dzn", type=Path)
    ap.add_argument("routes", type=Path)
    ap.add_argument("out", type=Path)
    ap.add_argument("--seconds", type=float, default=1200)
    ap.add_argument("--threads", type=int, default=32)
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    demand, distance = parse_dzn(args.dzn)
    routes = parse_routes(args.routes)
    nodes = range(45)
    customers = range(1, 45)
    arcs = [(i, j) for i in nodes for j in nodes if i != j]

    model = cp.Envr().createModel("B-n45-k5-free-fleet-flow")
    model.setParam(COPT.Param.Logging, 1)
    model.setLogFile(str(args.out / "copt-standard-cvrp.log"))
    model.setParam(COPT.Param.Threads, args.threads)
    model.setParam(COPT.Param.TimeLimit, args.seconds)
    model.setParam(COPT.Param.RelGap, 0.0)
    try:
        model.setParam(COPT.Param.GPUMode, 0)
    except Exception:
        pass

    x = {(i, j): model.addVar(lb=0, ub=1, vtype=COPT.BINARY, name=f"x_{i}_{j}") for i, j in arcs}
    flow = {(i, j): model.addVar(lb=0, ub=100, vtype=COPT.CONTINUOUS, name=f"f_{i}_{j}") for i, j in arcs}
    for j in customers:
        model.addConstr(cp.quicksum(x[i, j] for i in nodes if i != j) == 1, name=f"in_{j}")
        model.addConstr(cp.quicksum(x[j, k] for k in nodes if k != j) == 1, name=f"out_{j}")
        model.addConstr(
            cp.quicksum(flow[i, j] for i in nodes if i != j)
            - cp.quicksum(flow[j, k] for k in nodes if k != j)
            == demand[j],
            name=f"flow_balance_{j}",
        )
    # Arc-specific valid bounds: flow is undelivered demand on the truck.
    for i, j in arcs:
        model.addConstr(flow[i, j] <= (100 if i == 0 else 100 - demand[i]) * x[i, j], name=f"flow_ub_{i}_{j}")
        if j != 0:
            model.addConstr(flow[i, j] >= demand[j] * x[i, j], name=f"flow_lb_{i}_{j}")
        else:
            model.addConstr(flow[i, j] == 0, name=f"return_empty_{i}")
    min_routes = math.ceil(sum(demand) / 100)
    model.addConstr(cp.quicksum(x[0, j] for j in customers) >= min_routes, name="min_route_count")
    model.setObjective(cp.quicksum(distance[i][j] * x[i, j] for i, j in arcs), COPT.MINIMIZE)

    x_start = {arc: 0.0 for arc in arcs}
    f_start = {arc: 0.0 for arc in arcs}
    for route in routes:
        remaining = sum(demand[j] for j in route)
        previous = 0
        for j in route:
            x_start[previous, j] = 1.0
            f_start[previous, j] = float(remaining)
            remaining -= demand[j]
            previous = j
        x_start[previous, 0] = 1.0
        f_start[previous, 0] = 0.0
    start_vars = [x[a] for a in arcs] + [flow[a] for a in arcs]
    start_vals = [x_start[a] for a in arcs] + [f_start[a] for a in arcs]
    model.setMipStart(start_vars, start_vals)
    model.loadMipStart()
    model.solve()

    result = {
        "copt_version": [COPT.VERSION_MAJOR, COPT.VERSION_MINOR, COPT.VERSION_TECHNICAL],
        "status": int(model.status),
        "has_mip_solution": int(model.hasmipsol),
        "variables": len(arcs) * 2,
        "binary_arc_variables": len(arcs),
        "continuous_flow_variables": len(arcs),
        "route_count_fixed": False,
        "minimum_routes_by_total_demand": min_routes,
        "total_demand": sum(demand),
        "capacity": 100,
        "cpu_only_gpu_mode": 0,
        "dzn_sha256": hashlib.sha256(args.dzn.read_bytes()).hexdigest(),
        "route_sha256": hashlib.sha256(args.routes.read_bytes()).hexdigest(),
    }
    for key, attr in (
        ("objective", "objval"), ("best_bound", "bestbnd"), ("gap", "mipgap"),
        ("node_count", "nodecnt"), ("runtime", "solvingtime"),
    ):
        try:
            result[key] = float(getattr(model, attr))
        except Exception:
            pass
    if model.hasmipsol:
        model.writeSol(str(args.out / "standard-cvrp-flow.sol"))
    (args.out / "copt-standard-cvrp-summary.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print("RESULT_JSON=" + json.dumps(result, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
