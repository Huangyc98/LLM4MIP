#!/usr/bin/env python3
"""Exact small-exchange audit and iterated local search for ``sorrell7``.

The exact phase tests every improving exchange that removes at most three
vertices from the supplied independent set.  The heuristic phase repeatedly
destroys and greedily repairs larger neighborhoods while preserving
independence at every accepted point.
"""

from __future__ import annotations

import argparse
import gzip
import itertools
import json
import random
import time
from decimal import Decimal
from pathlib import Path


BITS = 11
N = 1 << BITS


def open_text(path: Path):
    if path.suffix.lower() == ".gz":
        return gzip.open(path, "rt", encoding="utf-8")
    return path.open("r", encoding="utf-8")


def graph() -> list[set[int]]:
    adjacency = [set() for _ in range(N)]
    for word in range(N):
        for bit in range(BITS):
            adjacency[word].add(word ^ (1 << bit))
        ones = [bit for bit in range(BITS) if word & (1 << bit)]
        zeros = [bit for bit in range(BITS) if not word & (1 << bit)]
        for one in ones:
            for zero in zeros:
                adjacency[word].add(word ^ (1 << one) ^ (1 << zero))
    return adjacency


def read_selected(path: Path) -> set[int]:
    selected: set[int] = set()
    with open_text(path) as handle:
        for raw in handle:
            tokens = raw.split()
            if len(tokens) == 2 and tokens[0].startswith("x_"):
                if Decimal(tokens[1]) == 1:
                    selected.add(int(tokens[0].split("_", 1)[1]) - 1)
    return selected


def validate(selected: set[int], adjacency: list[set[int]]) -> None:
    assert all(not (adjacency[word] & selected) for word in selected)


def find_independent_subset(
    vertices: list[int], target: int, adjacency: list[set[int]]
) -> list[int] | None:
    """Return an independent subset of the requested size, if one exists."""
    ordered = sorted(set(vertices), key=lambda v: len(adjacency[v] & set(vertices)))

    def visit(candidates: list[int], chosen: list[int]) -> list[int] | None:
        if len(chosen) == target:
            return chosen
        if len(chosen) + len(candidates) < target:
            return None
        while candidates:
            vertex = candidates.pop()
            compatible = [other for other in candidates if other not in adjacency[vertex]]
            result = visit(compatible, chosen + [vertex])
            if result is not None:
                return result
            if len(chosen) + len(candidates) < target:
                return None
        return None

    return visit(ordered, [])


def exact_exchange_audit(
    selected: set[int], adjacency: list[set[int]], max_removed: int
) -> tuple[dict, set[int] | None]:
    selected_list = sorted(selected)
    selected_position = {vertex: index for index, vertex in enumerate(selected_list)}
    outside = sorted(set(range(N)) - selected)
    conflicts = {
        vertex: frozenset(selected_position[u] for u in adjacency[vertex] & selected)
        for vertex in outside
    }
    conflict_histogram: dict[int, int] = {}
    for conflict_set in conflicts.values():
        conflict_histogram[len(conflict_set)] = conflict_histogram.get(len(conflict_set), 0) + 1

    audit = {
        "start_size": len(selected),
        "outside_conflict_histogram": dict(sorted(conflict_histogram.items())),
        "radii": [],
    }
    for removed_count in range(1, max_removed + 1):
        groups: dict[tuple[int, ...], list[int]] = {}
        for vertex, conflict_set in conflicts.items():
            if not conflict_set or len(conflict_set) > removed_count:
                continue
            remaining = [
                index for index in range(len(selected_list)) if index not in conflict_set
            ]
            for extra in itertools.combinations(
                remaining, removed_count - len(conflict_set)
            ):
                removed_positions = tuple(sorted((*conflict_set, *extra)))
                groups.setdefault(removed_positions, []).append(vertex)

        tested_groups = 0
        possible_groups = 0
        for removed_positions, candidates in groups.items():
            if len(candidates) < removed_count + 1:
                continue
            possible_groups += 1
            tested_groups += 1
            additions = find_independent_subset(
                candidates, removed_count + 1, adjacency
            )
            if additions is not None:
                removed = {selected_list[index] for index in removed_positions}
                improved = (selected - removed) | set(additions)
                validate(improved, adjacency)
                audit["radii"].append(
                    {
                        "removed": removed_count,
                        "candidate_groups": len(groups),
                        "groups_with_enough_candidates": possible_groups,
                        "result": "improving exchange found",
                        "removed_vertices": sorted(v + 1 for v in removed),
                        "added_vertices": sorted(v + 1 for v in additions),
                    }
                )
                return audit, improved
        audit["radii"].append(
            {
                "removed": removed_count,
                "candidate_groups": len(groups),
                "groups_with_enough_candidates": possible_groups,
                "groups_searched": tested_groups,
                "result": "no improving exchange",
            }
        )
    return audit, None


def greedy_repair(
    seed_set: set[int], adjacency: list[set[int]], rng: random.Random
) -> set[int]:
    selected = set(seed_set)
    eligible = {
        vertex
        for vertex in range(N)
        if vertex not in selected and not (adjacency[vertex] & selected)
    }
    while eligible:
        sample = rng.sample(sorted(eligible), min(32, len(eligible)))
        best_degree = min(len(adjacency[v] & eligible) for v in sample)
        restricted = [v for v in sample if len(adjacency[v] & eligible) <= best_degree + 1]
        vertex = rng.choice(restricted)
        selected.add(vertex)
        eligible.discard(vertex)
        eligible.difference_update(adjacency[vertex])
    return selected


def iterated_local_search(
    start: set[int], adjacency: list[set[int]], seconds: float, seed: int
) -> tuple[set[int], dict]:
    rng = random.Random(seed)
    best = set(start)
    current = set(start)
    deadline = time.monotonic() + seconds
    iterations = 0
    accepted = 0
    size_histogram: dict[int, int] = {}
    while time.monotonic() < deadline:
        iterations += 1
        destroy = rng.randint(4, min(30, len(current)))
        removed = set(rng.sample(sorted(current), destroy))
        candidate = greedy_repair(current - removed, adjacency, rng)
        size_histogram[len(candidate)] = size_histogram.get(len(candidate), 0) + 1
        if len(candidate) > len(best):
            best = set(candidate)
            print(f"iteration {iterations}: new best size {len(best)}")
        if len(candidate) >= len(current) or rng.random() < 0.02:
            current = candidate
            accepted += 1
        elif len(current) + 8 < len(best):
            current = set(best)
    validate(best, adjacency)
    return best, {
        "seconds": seconds,
        "seed": seed,
        "iterations": iterations,
        "accepted": accepted,
        "size_histogram": dict(sorted(size_histogram.items())),
        "best_size": len(best),
    }


def write_solution(path: Path, selected: set[int]) -> None:
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write(f"=obj= {-len(selected)}\n")
        for vertex in sorted(selected):
            handle.write(f"x_{vertex + 1} 1\n")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--max-removed", type=int, default=3, choices=range(1, 4))
    parser.add_argument("--seconds", type=float, default=60.0)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()

    adjacency = graph()
    selected = read_selected(args.solution)
    validate(selected, adjacency)
    audit, exchange_solution = exact_exchange_audit(
        selected, adjacency, args.max_removed
    )
    heuristic_start = exchange_solution if exchange_solution is not None else selected
    best, heuristic = iterated_local_search(
        heuristic_start, adjacency, args.seconds, args.seed
    )
    report = {
        "instance": "sorrell7",
        "exact_exchange_audit": audit,
        "iterated_local_search": heuristic,
    }
    print(json.dumps(report, indent=2))
    if args.output:
        write_solution(args.output, best)
    if args.json:
        args.json.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
