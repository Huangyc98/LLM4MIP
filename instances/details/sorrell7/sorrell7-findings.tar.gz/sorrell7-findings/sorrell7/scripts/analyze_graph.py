#!/usr/bin/env python3
"""Recover and exactly audit the graph encoded by ``sorrell7``.

The script uses only the Python standard library.  It verifies every MPS row,
deduplicates the repeated edge inequalities, recognizes the binary
single-asymmetric-error (Z-channel) confusability graph, and checks a supplied
independent-set solution exactly.
"""

from __future__ import annotations

import argparse
import gzip
import json
import math
import re
from collections import Counter, defaultdict, deque
from decimal import Decimal
from pathlib import Path


EDGE_NAME = re.compile(r"con_(\d+)_(\d+)$")
VARIABLE_NAME = re.compile(r"x_(\d+)$")


def open_text(path: Path, encoding: str = "latin-1"):
    if path.suffix.lower() == ".gz":
        return gzip.open(path, "rt", encoding=encoding)
    return path.open("r", encoding=encoding)


def number(text: str) -> Decimal:
    return Decimal(text.replace("D", "E").replace("d", "e"))


def read_solution(path: Path) -> dict[str, Decimal]:
    values: dict[str, Decimal] = {}
    with open_text(path, "utf-8") as handle:
        for raw in handle:
            line = raw.strip()
            if not line or line.startswith("#") or line.startswith("=obj="):
                continue
            tokens = line.split()
            if len(tokens) >= 2:
                values[tokens[0]] = number(tokens[1])
    return values


def parse_mps(path: Path):
    section = ""
    objective_row = ""
    row_types: dict[str, str] = {}
    rhs: dict[str, Decimal] = defaultdict(Decimal)
    row_entries: dict[str, list[tuple[str, Decimal]]] = defaultdict(list)
    objective: dict[str, Decimal] = defaultdict(Decimal)
    variables: set[str] = set()
    integer_variables: set[str] = set()
    upper_bounds: dict[str, Decimal] = {}
    integer_mode = False

    with open_text(path) as handle:
        for raw in handle:
            tokens = raw.split()
            if not tokens or tokens[0].startswith("*"):
                continue
            if tokens[0] in {
                "NAME",
                "ROWS",
                "COLUMNS",
                "RHS",
                "RANGES",
                "BOUNDS",
                "ENDATA",
            }:
                section = tokens[0]
                continue
            if section == "ROWS":
                kind, row = tokens[0], tokens[1]
                row_types[row] = kind
                if kind == "N":
                    objective_row = row
            elif section == "COLUMNS":
                if "'MARKER'" in tokens:
                    if "'INTORG'" in tokens:
                        integer_mode = True
                    elif "'INTEND'" in tokens:
                        integer_mode = False
                    continue
                variable = tokens[0]
                variables.add(variable)
                if integer_mode:
                    integer_variables.add(variable)
                for row, coefficient_text in zip(tokens[1::2], tokens[2::2]):
                    coefficient = number(coefficient_text)
                    if row == objective_row:
                        objective[variable] += coefficient
                    else:
                        row_entries[row].append((variable, coefficient))
            elif section == "RHS":
                for row, value_text in zip(tokens[1::2], tokens[2::2]):
                    rhs[row] += number(value_text)
            elif section == "RANGES":
                raise ValueError("unexpected RANGES section")
            elif section == "BOUNDS":
                kind, variable = tokens[0], tokens[2]
                if kind != "UP":
                    raise ValueError(f"unexpected bound type {kind}")
                upper_bounds[variable] = number(tokens[3])

    return {
        "row_types": row_types,
        "rhs": rhs,
        "row_entries": row_entries,
        "objective": objective,
        "variables": variables,
        "integer_variables": integer_variables,
        "upper_bounds": upper_bounds,
    }


def expected_z_channel_edges(bits: int) -> set[tuple[int, int]]:
    """Edges for one asymmetric-error confusability on all binary words."""
    n = 1 << bits
    edges: set[tuple[int, int]] = set()
    for word in range(n):
        for bit in range(bits):
            other = word ^ (1 << bit)
            edges.add((min(word, other), max(word, other)))
        ones = [bit for bit in range(bits) if word & (1 << bit)]
        zeros = [bit for bit in range(bits) if not word & (1 << bit)]
        for one in ones:
            for zero in zeros:
                other = word ^ (1 << one) ^ (1 << zero)
                edges.add((min(word, other), max(word, other)))
    return edges


def components(adjacency: list[set[int]]) -> list[int]:
    unseen = set(range(len(adjacency)))
    sizes: list[int] = []
    while unseen:
        start = unseen.pop()
        queue = deque([start])
        size = 0
        while queue:
            vertex = queue.popleft()
            size += 1
            for neighbor in adjacency[vertex]:
                if neighbor in unseen:
                    unseen.remove(neighbor)
                    queue.append(neighbor)
        sizes.append(size)
    return sorted(sizes, reverse=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("--solution", type=Path)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()

    model = parse_mps(args.mps)
    variables = model["variables"]
    n = len(variables)
    bits = int(math.log2(n))
    assert 1 << bits == n
    expected_variables = {f"x_{index}" for index in range(1, n + 1)}
    assert variables == expected_variables
    assert model["integer_variables"] == expected_variables
    assert model["upper_bounds"] == {variable: Decimal(1) for variable in variables}
    assert model["objective"] == {variable: Decimal(-1) for variable in variables}

    edge_multiplicity: Counter[tuple[int, int]] = Counter()
    row_checks = Counter()
    for row, kind in model["row_types"].items():
        if kind == "N":
            continue
        entries = model["row_entries"][row]
        match = EDGE_NAME.fullmatch(row)
        assert match and kind == "G" and model["rhs"][row] == -1
        endpoints = (int(match.group(1)), int(match.group(2)))
        assert entries == [
            (entries[0][0], Decimal(-1)),
            (entries[1][0], Decimal(-1)),
        ]
        entry_endpoints = tuple(int(VARIABLE_NAME.fullmatch(v).group(1)) for v, _ in entries)
        assert set(entry_endpoints) == set(endpoints)
        edge = tuple(sorted((endpoints[0] - 1, endpoints[1] - 1)))
        edge_multiplicity[edge] += 1
        row_checks["valid_edge_rows"] += 1

    unique_edges = set(edge_multiplicity)
    expected_edges = expected_z_channel_edges(bits)
    assert unique_edges == expected_edges

    adjacency = [set() for _ in range(n)]
    for left, right in unique_edges:
        adjacency[left].add(right)
        adjacency[right].add(left)

    selected: set[int] = set()
    objective = None
    conflicts: list[tuple[int, int]] = []
    selected_weight_histogram: Counter[int] = Counter()
    if args.solution:
        solution = read_solution(args.solution)
        selected = {
            int(VARIABLE_NAME.fullmatch(variable).group(1)) - 1
            for variable, value in solution.items()
            if VARIABLE_NAME.fullmatch(variable) and value == 1
        }
        assert all(value in (0, 1) for value in solution.values())
        conflicts = sorted(edge for edge in unique_edges if edge[0] in selected and edge[1] in selected)
        objective = -len(selected)
        selected_weight_histogram = Counter(word.bit_count() for word in selected)

    degree_histogram = Counter(len(neighbors) for neighbors in adjacency)
    degree_by_weight = {
        weight: sorted({len(adjacency[word]) for word in range(n) if word.bit_count() == weight})
        for weight in range(bits + 1)
    }
    expected_degree_by_weight = {
        weight: bits + weight * (bits - weight) for weight in range(bits + 1)
    }
    assert all(degree_by_weight[w] == [expected_degree_by_weight[w]] for w in range(bits + 1))

    down_ball_sizes = Counter(bits + 1 - word.bit_count() for word in range(n))
    report = {
        "instance": "sorrell7",
        "variables": n,
        "bits": bits,
        "mps_rows": row_checks["valid_edge_rows"],
        "unique_edges": len(unique_edges),
        "edge_multiplicity_histogram": dict(sorted(Counter(edge_multiplicity.values()).items())),
        "components": components(adjacency),
        "degree_histogram": dict(sorted(degree_histogram.items())),
        "degree_by_hamming_weight": degree_by_weight,
        "recognized_graph": (
            "binary length-11 single-asymmetric-error (Z-channel) confusability graph"
        ),
        "adjacency_rule": (
            "Hamming distance 1, or Hamming distance 2 with equal Hamming weight"
        ),
        "down_ball_clique_size_histogram": dict(sorted(down_ball_sizes.items())),
        "official_solution": {
            "selected_vertices": len(selected),
            "objective": objective,
            "edge_conflicts": len(conflicts),
            "weight_histogram": dict(sorted(selected_weight_histogram.items())),
            "weighted_down_ball_count": sum(word.bit_count() + 1 for word in selected),
            "weighted_up_ball_count": sum(bits + 1 - word.bit_count() for word in selected),
        }
        if args.solution
        else None,
        "checks": {
            "all_mps_rows_are_duplicate_edge_inequalities": (
                len(edge_multiplicity) * 2 == row_checks["valid_edge_rows"]
                and set(edge_multiplicity.values()) == {2}
            ),
            "exact_z_channel_graph_match": unique_edges == expected_edges,
            "official_solution_is_independent": not conflicts if args.solution else None,
        },
    }
    text = json.dumps(report, indent=2, sort_keys=False)
    print(text)
    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(text + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
