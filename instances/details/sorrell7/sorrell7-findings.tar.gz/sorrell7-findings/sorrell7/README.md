# `sorrell7`

2026-09-14 independent dual-bound review: [adopted bound, proof chain, checks, and limitations](../../docs/dual-bound-audit-2026-09-14/cases/sorrell7.zh.md). Reviewed lower bound: **-210**. This review distinguishes exact, literature, and numerical evidence; historical statements below remain dated records.

## Result

The official MPS objective **-198**, representing an independent set/code of
size 198, is independently verified with exact decimal arithmetic.  This study
found no 199-point code and did not prove global optimality.  The best currently
published code range is

```text
198 <= alpha(G) <= 210,
```

or, in the minimization sign used by the MPS, `-210 <= OPT <= -198`.  The upper
bound 210 comes from the coding-theory literature recorded by OEIS; it is not a
new certificate from this repository.  The strongest global solver bound
obtained here was `alpha(G) <= 216` from the compact Gurobi model.

The main new result is a strict local certificate.  No independent set of size
at least 199 can retain 186 or more of the 198 official vertices.  Therefore
any improvement must remove at least **13** official vertices, add at least 14,
and lie at binary Hamming distance at least **27** from the official solution.

## Input and provenance

- MPS SHA-256: `11B427BDAF61E4D7B54268B26BDF37707A446DF82E6E7CBCCE88751AD1997B45`
- Official compressed solution SHA-256: `E87BADF103705A6743522CD4C9A6BFEA6339A2C74CED2B78EA09856ACF8E4AB5`
- [MIPLIB instance page](https://miplib.zib.de/instance_details_sorrell7.html)
- [OEIS A010101: binary asymmetric-distance-two codes](https://oeis.org/A010101)
- [Sloane's independent-set challenge page](https://oeis.org/A265032/a265032.html)

MIPLIB still marks the instance open.  It reports that Mars Davletshin found
the size-198 solution in 2023 with the Huawei OptVerse neural heuristic.

## Recovered structure

The 2,048 variables are the 11-bit words in numeric order: `x_(word+1)`.  The
MPS minimizes `-sum(x)`.  Every one of its 78,848 rows is a two-variable edge
inequality, and every edge occurs exactly twice.  Deduplication leaves 39,424
unique edges.  Two words are adjacent exactly when

- their Hamming distance is one; or
- their Hamming distance is two and their Hamming weights are equal.

Thus the instance is the length-11 single-asymmetric-error, or Z-channel,
confusability graph `1zc.2048`.  An independent set is a binary code with
asymmetric distance two.  The graph is connected, and a word of weight `w` has
degree `11 + w(11-w)`.

## Exact compact formulation

For every word `y`, both of the following sets are cliques:

```text
{y} union {one-bit supersets of y}
{y} union {one-bit subsets of y}.
```

The resulting 4,096 clique inequalities imply every original edge row and are
exact for binary feasibility.  They replace 78,848 duplicated rows.  The model
also adds valid constant-weight distance-four packing caps

```text
weight: 0  1  2   3   4   5   6   7   8  9 10 11
cap:    1  1  5  17  35  66  66  35  17  5  1  1
```

Pair/subset counting proves all caps.  For weight three, parity rules out the
naive value 18; for weight four, linking at a coordinate and using the degree
bound for triple packings gives `4*A_4 <= 11*13`, hence `A_4 <= 35`.
Complementation supplies the symmetric caps.

The compact LP value is `233.333333`, below the original root LP value
`238.72955` and the historical Lovasz-theta value `237.4`.  Gurobi cuts reduced
the compact global upper bound further to 216.

## Official solution audit

The selected-word histogram by Hamming weight is

| weight | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| selected | 1 | 0 | 5 | 15 | 31 | 47 | 47 | 31 | 15 | 5 | 0 | 1 |

Both the recovered graph checker and the shared decimal MPS checker report zero
conflicts, zero row/bound violations, and zero integrality violations.  Every
outside vertex conflicts with between one and six selected vertices, so the
198 set is maximal.  The conflict-count histogram is
`{1: 2, 2: 107, 3: 407, 4: 629, 5: 549, 6: 156}`.

Exhaustive exchange enumeration independently rules out every improvement that
removes at most three selected vertices.  Two 45-second destroy/repair searches
performed 48,303 total iterations and also retained 198.  Both output solutions
pass the exact MPS checker.

## Solver experiments

| Method | Threads | Limit / time | Result |
|---|---:|---:|---|
| Gurobi 13.0.1, original MPS, official start | 64 | 180 s | `-198`; MPS bound `-221` |
| COPT 8.0.4, original MPS, official start | 64 | 180 s | `-198`; raw MPS bound `-232.650724638` |
| Gurobi, compact global model | 64 | 600 s | size 198; code upper bound 216; 4,602 nodes |
| COPT, compact global model | 64 | 600 s | size 198; code upper bound 233.333333332 |
| exact exchange enumeration | 1 | — | no improvement after removing at most 3 |
| destroy/repair ILS, seeds 7 and 198 | 1 | 90 s total | 48,303 iterations; best 198 |
| Gurobi / COPT, target 199, remove at most 4 | 32 | 0.39 / 1.51 s | both infeasible |
| Gurobi / COPT, target 199, remove at most 6 | 32 | 92.25 / 109.76 s | both infeasible |
| Gurobi / COPT, target 199, remove at most 8 | 32 | 238.39 / 110.92 s | both infeasible |
| Gurobi, target 199, remove at most 10 | 32 | 300 s | no solution; timed out, not a proof |
| COPT, target 199, remove at most 10 | 32 | 128.47 s | infeasible; 670 nodes |
| COPT, target 199, remove at most 12 | 32 | 222.36 s | **infeasible**; 3,924 nodes |

All COPT work on `altman` used CPU only; **GPU0 was not used**.  The Gurobi
license identifier and private installation paths have been removed from the
archived logs.

## Interpretation and next algorithm

The known 198 code is not globally certified: the published upper bound is
still 210.  Longer unchanged edge-MIP runs are unlikely to close that gap.  The
local certificate also shows why one- and two-exchange heuristics have stalled:
an improving code must make a coordinated change involving at least 27 bits.

For the lower-bound search, the next useful method is large-neighborhood
destroy/repair that removes at least 13 codewords, followed by exact MIP/CP-SAT
repair, combined with coordinate-permutation and complement canonicalization.
Reimplementing the weighting local search used for earlier MIPLIB improvements
is another reasonable route.  For a global proof, the promising direction is
an SDP/association-scheme bound with symmetry-reduced branch-and-bound, not a
plain continuation of the compact LP tree.

## Reproduction

The structural audit, exchange enumeration, and exact solution checks use only
the Python standard library:

```powershell
python .\instances\sorrell7\scripts\analyze_graph.py `
  .\instances\sorrell7\input\sorrell7.mps.gz `
  --solution .\instances\sorrell7\solutions\official-198.sol `
  --json .\instances\sorrell7\artifacts\structure-and-solution-audit.json

python .\instances\sorrell7\scripts\exchange_and_ils.py `
  .\instances\sorrell7\solutions\official-198.sol `
  --max-removed 3 --seconds 45 --seed 7 `
  --output .\instances\sorrell7\solutions\ils-best.sol `
  --json .\instances\sorrell7\artifacts\exchange-and-ils.json

python .\common\exact_mps_solution_check.py `
  .\instances\sorrell7\input\sorrell7.mps.gz `
  .\instances\sorrell7\solutions\official-198.sol --tolerance 0

python .\instances\sorrell7\scripts\make_compact_model.py `
  --lp .\instances\sorrell7\artifacts\sorrell7-target199-r12.lp `
  --solution .\instances\sorrell7\solutions\official-198.sol `
  --target 199 --max-removed 12
```

Generate the compact or local model with
[`make_compact_model.py`](scripts/make_compact_model.py).  See the
[Chinese study report](reports/sorrell7-study-zh.md),
[`artifacts/`](artifacts/), and [`logs/`](logs/).
