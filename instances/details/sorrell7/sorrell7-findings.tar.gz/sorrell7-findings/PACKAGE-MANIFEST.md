# Package manifest: sorrell7

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 34
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/exchange-and-ils-seed198.json`
- `artifacts/exchange-and-ils.json`
- `artifacts/solver-summary.json`
- `artifacts/sorrell7-compact.lp`
- `artifacts/sorrell7-target199-r10.lp`
- `artifacts/sorrell7-target199-r12.lp`
- `artifacts/sorrell7-target199-r4.lp`
- `artifacts/sorrell7-target199-r6.lp`
- `artifacts/sorrell7-target199-r8.lp`
- `artifacts/sorrell7-target199.lp`
- `artifacts/structure-and-solution-audit.json`
- `logs/copt-compact-600s.log`
- `logs/copt-original-180s.log`
- `logs/copt-r10-300s.log`
- `logs/copt-r12-300s.log`
- `logs/copt-r4-300s.log`
- `logs/copt-r6-300s.log`
- `logs/copt-r8-300s.log`
- `logs/gurobi-compact-600s.log`
- `logs/gurobi-original-180s.log`
- `logs/gurobi-r10-300s.log`
- `logs/gurobi-r4-300s.log`
- `logs/gurobi-r6-300s.log`
- `logs/gurobi-r8-300s.log`
- `reports/sorrell7-study-zh.md`
- `scripts/analyze_graph.py`
- `scripts/exchange_and_ils.py`
- `scripts/make_compact_model.py`
- `solutions/ils-best.sol`
- `solutions/ils-seed198-best.sol`
- `solutions/official-198.mst`
- `solutions/official-198.sol`
- `solutions/official-198.sol.gz`

## Excluded files

- `input/sorrell7.mps.gz (1520287 bytes; raw benchmark input; sha256 11b427bdaf61e4d7b54268b26bdf37707a446df82e6e7cbcce88751ad1997b45)`
