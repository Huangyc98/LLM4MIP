# `fastxgemm-n3r21s3t6` 续研报告

日期：2026-09-09

## 严格结论与归属

```text
旧项目区间：[90,2168]
新严格区间：[93,2147]
```

上界 2147 由 BILR 2018 的外部 `S_Lader-Z3` 构造派生：删除其两个 singleton
固定 A 项，得到 `R=21,S=3,T=6` 的 `E=2,K=49` 构造。它按保守口径归类为
**external-derived**，计入项目基于外部成果的 primal 改进（2026-09-16 更新口径），不主张母构造原创权。Laurent Sorber 2017 的 2168 start
仍保留为历史基线，但已被 2147 严格改进。

下界 93 是本项目的新全局证明。当前仍未闭合 `93<2147`，所以不能声称本题
optimal。

## external-derived UB 2147

删除 BILR parent 的两个 singleton A 项后，精确张量展开给出

```text
E = 2
K = 49
full UVW support = 147
objective = 1000*2 + 147 = 2147
```

两处误差恰是缺失的单位 tensor entries `(4,4,4)` 与 `(8,8,8)`。五个固定 A
项中删除两个共有 10 种组合，完整枚举表明 2147 是该有限集合中的唯一最优值；
对论文中三个显式 S5T6 构造的 30 个二项删除 children 做同样审计，三个 parent
各自的最好值为 2147、14174、2180。

严格解固定了官方 MPS 的全部 378 个 POS/NEG 整数编码。Gurobi 13.0.2 对固定
pattern 返回 objective/bound 2147，随后 Decimal checker 对 219,368 条官方约束
逐行精确重放，行、边界和整数性违约均为 0；独立整数 tensor expansion 也复现
`E=2,K=49`。因此 2147 是严格可行上界，但 fixed-pattern `OPTIMAL` 不等于完整
MIP 的 global optimality。

## global LB 93

对 exact 构造，每个 factor row 因对应 rank-3 target slice 而 degree 至少为 3；
同一 mode 的 degree-3 tight rows 使用互异 rank positions。旧 LB90 已排除
`K<=29`。若 `K=30`，度数分拆共有

```text
(6,3,3,3,3,3,3,3,3),
(5,4,3,3,3,3,3,3,3),
(4,4,4,3,3,3,3,3,3).
```

第一型有八个 tight rows，需要 `8*3=24>21` 个 rank columns，因此不可能。
第二型的七个 tight rows 用尽 21 个 rank columns；跨三个 mode 的交集条件会迫使
每个 factor column 都是 singleton，继而得到 `K=21` 而非 30。故只剩第三型。

六个 tight rows 占据 18 个互异 core vectors，剩余三个 deficient vectors 必须
在三个 degree-4 high rows 上提供 12 次 incidence。逐 orbit 的上界表明，达到
12 只能使用三个不同的、各缺一个 tight coordinate 的 B/C/D orbit；每个等号
情形在 high rows 上的 multiplicity 为 `(2,1,1)`。三个 doubled points 必须各不
相同，才能让总和成为 `(4,4,4)`。

最后的有限分类检查全部 `C(9,3)=84` 个 high-row sets，并在 S3 同时重标号与
transpose 下压缩为 12 个对称类。每个 high-row set 至多允许一个 doubled point，
与上面的三个互异 doubled points 矛盾。因此 exact `K=30` 不存在，exact 分支有
`K>=31`，raw support 至少 93。

第二个完全不调用求解器的 bitmask DP 对 12 个对称代表逐个测试，覆盖全部 84
个 high-row sets，12 个代表均不可达；canonical payload SHA-256 为
`aa8b34948c205703f78ab4a8a0a291bf4b37e374a666e59dbd2f8e20dd811917`。

结合 inexact 点的官方 support floor 84 和 residual sum 至少 1，得到全局整数
有效 cut：

```text
sum(ABS_ALT) + 9*sum(RESIDUAL) >= 93.
```

增强 MPS 的该行含 567 个系数 1、729 个系数 9，RHS 93，不增加变量。Gurobi
复读后 LP optimum 为 93.00000000000038，root bound 为 93.00000000000003。
数值 probe 验证实现，数学有效性来自上述证明与有限审计。

## 继续改进搜索

围绕 2147 core 的有限实验结果如下：

| 搜索域 | 结果 | 可允许的结论 |
|---|---|---|
| 全部 `21*3^9=413,343` 个单完整向量替换 | 无低于 2147 | 单向量局部最优 |
| coefficient Hamming radius 1/2 | 378 / 71,064 个 nominal moves，无改进 | radius-2 局部结果 |
| 同 49 个 support locations 内任意删除/换号，目标 `<=2146` | Gurobi 完整 `INFEASIBLE` | 固定-support 证书 |
| 上述自由度再允许最多一个新 support location | 300 秒、47,178 nodes、无 incumbent，`TIME_LIMIT` | 无全局结论 |
| 480 个 ternary-admissible 有界 conjugates 的 4,800 个双 A 删除 | 最好 2147 | 仅覆盖该有限 orbit |

support-only necessary-condition MIP 在 `K=30` infeasible，而 `K=31` 仅在该
support relaxation 中 feasible；这并不是一个 exact tensor decomposition。
因此继续提高下界不能只重复当前 line-support 论证；需要加入符号兼容性或更直接
的 tensor equations。继续降低上界则应优先研究至少两个新 support locations、
多向量/orbit 同时替换，或超出已审计小系数盒的 gauge transformations。

## 可发布口径

可以声称官方整数 MIP 的严格区间 `[93,2147]`，其中 LB93 是项目证明，UB2147
是通过官方 MPS 和精确 tensor audit 的 external-derived 构造。不能声称 2147
由 GPT 从零构造，也不能声称本题 optimal。所有 TIME_LIMIT 分支只保留为明确
范围的负搜索证据。
