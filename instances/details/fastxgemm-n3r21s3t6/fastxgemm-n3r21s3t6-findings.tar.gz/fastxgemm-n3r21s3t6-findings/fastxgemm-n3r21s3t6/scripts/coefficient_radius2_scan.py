#!/usr/bin/env python3
"""Exact scan of all ternary coefficient changes at Hamming radius <= 2."""

from __future__ import annotations

import argparse
import itertools
import json
import time
from pathlib import Path

import numpy as np

import exact_semantic_audit as semantic
from one_vector_scan import cyclic_group, target_tensor, tensor_from_factors


def component_key(letter: str, column: int):
    return ("A", column) if letter == "A" else ("G", column)


def component_tensor(blocks, key):
    kind, column = key
    if kind == "A":
        vector = blocks["A"][:, column]
        return np.einsum("i,j,k->ijk", vector, vector, vector, dtype=np.int16)
    return cyclic_group(
        blocks["B"][:, column], blocks["C"][:, column], blocks["D"][:, column]
    )


def valid_structure(blocks, k_support):
    if k_support < 28:
        return False
    row_coverage = sum(np.count_nonzero(blocks[x], axis=1) for x in "ABCD")
    if np.any(row_coverage < 1):
        return False
    for letter in "ABCD":
        if np.any(np.count_nonzero(blocks[letter], axis=0) < 1):
            return False
    return True


def score_tensor(tensor, target, k_support):
    difference = target - tensor
    if int(np.max(np.abs(difference))) > 1:
        return None
    e_value = int(np.abs(difference).sum())
    return e_value, 1000 * e_value + 3 * k_support


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    started = time.perf_counter()

    values, _ = semantic.read_solution(args.solution)
    raw_blocks = semantic.reconstruct_blocks(values, tolerance=1e-6)
    blocks = {x: np.asarray(raw_blocks[x], dtype=np.int8) for x in "ABCD"}
    u, v, w = semantic.factors_from_blocks(raw_blocks)
    incumbent_tensor = tensor_from_factors(
        np.asarray(u, dtype=np.int8), np.asarray(v, dtype=np.int8), np.asarray(w, dtype=np.int8)
    )
    target = target_tensor()
    incumbent_k = sum(np.count_nonzero(blocks[x]) for x in "ABCD")
    incumbent_e, incumbent_objective = score_tensor(incumbent_tensor, target, incumbent_k)

    component_incumbent = {
        key: component_tensor(blocks, key)
        for key in [("A", col) for col in range(3)] + [("G", col) for col in range(6)]
    }

    moves = []
    coefficient_id = 0
    for letter in "ABCD":
        for column in range(semantic.BLOCK_WIDTHS[letter]):
            for row in range(9):
                old_value = int(blocks[letter][row, column])
                for new_value in (-1, 0, 1):
                    if new_value == old_value:
                        continue
                    modified = {x: blocks[x].copy() for x in "ABCD"}
                    modified[letter][row, column] = new_value
                    key = component_key(letter, column)
                    delta_tensor = component_tensor(modified, key) - component_incumbent[key]
                    moves.append(
                        {
                            "coefficient_id": coefficient_id,
                            "letter": letter,
                            "row": row,
                            "column": column,
                            "old": old_value,
                            "new": new_value,
                            "component": key,
                            "support_delta": int(new_value != 0) - int(old_value != 0),
                            "tensor_delta": delta_tensor,
                        }
                    )
                coefficient_id += 1

    best = {
        "radius": 0,
        "E": incumbent_e,
        "K": incumbent_k,
        "objective": incumbent_objective,
        "moves": [],
    }
    radius_counts = {
        "1": {"nominal": len(moves), "structurally_valid": 0, "exactly_feasible": 0},
        "2": {"nominal": 0, "structurally_valid": 0, "exactly_feasible": 0},
    }
    strict_improvements = []

    def evaluate(selected, radius):
        nonlocal best
        modified = {x: blocks[x].copy() for x in "ABCD"}
        k_value = incumbent_k
        touched = set()
        for move in selected:
            modified[move["letter"]][move["row"], move["column"]] = move["new"]
            k_value += move["support_delta"]
            touched.add(move["component"])
        if not valid_structure(modified, k_value):
            return
        radius_counts[str(radius)]["structurally_valid"] += 1

        if len(touched) == len(selected):
            tensor = incumbent_tensor.copy()
            for move in selected:
                tensor += move["tensor_delta"]
        else:
            tensor = incumbent_tensor.copy()
            for key in touched:
                tensor += component_tensor(modified, key) - component_incumbent[key]
        scored = score_tensor(tensor, target, k_value)
        if scored is None:
            return
        radius_counts[str(radius)]["exactly_feasible"] += 1
        e_value, objective = scored
        description = [
            {
                key: move[key]
                for key in ("letter", "row", "column", "old", "new")
            }
            for move in selected
        ]
        if objective < best["objective"]:
            best = {
                "radius": radius,
                "E": e_value,
                "K": k_value,
                "objective": objective,
                "moves": description,
            }
        if objective < incumbent_objective and len(strict_improvements) < 100:
            strict_improvements.append(
                {"radius": radius, "E": e_value, "K": k_value, "objective": objective, "moves": description}
            )

    for move in moves:
        evaluate((move,), 1)

    # A radius-two point changes two distinct underlying coefficients.  Each
    # coefficient has exactly two alternative values, hence 4*C(189,2).
    for left in range(len(moves)):
        first = moves[left]
        for right in range(left + 1, len(moves)):
            second = moves[right]
            if first["coefficient_id"] == second["coefficient_id"]:
                continue
            radius_counts["2"]["nominal"] += 1
            evaluate((first, second), 2)

    result = {
        "instance": "fastxgemm-n3r21s3t6",
        "method": "exact exhaustive coefficient-Hamming scan",
        "coefficient_count": 189,
        "alternatives_per_coefficient": 2,
        "incumbent": {"E": incumbent_e, "K": incumbent_k, "objective": incumbent_objective},
        "radius_counts": radius_counts,
        "best": best,
        "strict_improvement_found": bool(strict_improvements),
        "strict_improvements": strict_improvements,
        "elapsed_seconds": time.perf_counter() - started,
    }
    rendered = json.dumps(result, indent=2)
    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(rendered + "\n", encoding="utf-8")
    print(rendered)


if __name__ == "__main__":
    main()
