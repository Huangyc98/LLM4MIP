#!/usr/bin/env python3
"""Exact two-vector neighborhood search around the strict 2168 solution.

For every unordered pair among the 21 underlying A/B/C/D column vectors, each
vector may independently change at coefficient-Hamming radius at most two.
Thus the search includes 5,579,490 nominal paired replacements and reaches
total coefficient radius four.  All arithmetic is integral and all
interactions between B/C/D vectors in the same cyclic group are recomputed.

Only final tensors with E <= 2 need be retained: an objective below 2168 is
equivalent to E <= 1, or E == 2 and K <= 55.  Cyclic symmetry means every
non-diagonal error orbit has weight three, so all E <= 2 errors are supported
on the nine diagonal orbits.  This permits exact hash matching for vector
pairs in different tensor components.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import time
from pathlib import Path

import numpy as np

import exact_semantic_audit as semantic


LETTERS = "ABCD"


def candidates_radius_two(vector: np.ndarray) -> np.ndarray:
    candidates = [vector.copy()]
    for radius in (1, 2):
        for positions in itertools.combinations(range(9), radius):
            alternatives = [tuple(value for value in (-1, 0, 1) if value != vector[p]) for p in positions]
            for replacement in itertools.product(*alternatives):
                candidate = vector.copy()
                for position, value in zip(positions, replacement):
                    candidate[position] = value
                candidates.append(candidate)
    result = np.asarray(candidates, dtype=np.int16)
    if result.shape != (163, 9) or len({row.tobytes() for row in result}) != 163:
        raise RuntimeError(f"unexpected candidate set shape/uniqueness: {result.shape}")
    return result


def orbit_representatives() -> tuple[np.ndarray, np.ndarray]:
    representatives = []
    for i in range(9):
        for j in range(9):
            for k in range(9):
                rotations = ((i, j, k), (j, k, i), (k, i, j))
                if (i, j, k) == min(rotations):
                    representatives.append((i, j, k))
    reps = np.asarray(representatives, dtype=np.int16)
    weights = np.asarray([1 if i == j == k else 3 for i, j, k in representatives], dtype=np.int16)
    if reps.shape != (249, 3) or int(np.sum(weights)) != 729:
        raise RuntimeError("cyclic orbit construction failed")
    return reps, weights


def target_on_orbits(reps: np.ndarray) -> np.ndarray:
    return np.asarray(
        [semantic.target_value(int(i), int(j), int(k)) for i, j, k in reps],
        dtype=np.int16,
    )


def group_component(blocks: dict[str, np.ndarray], column: int, reps: np.ndarray) -> np.ndarray:
    i, j, k = reps[:, 0], reps[:, 1], reps[:, 2]
    b, c, d = (blocks[letter][:, column] for letter in "BCD")
    return (
        b[i] * d[j] * c[k]
        + c[i] * b[j] * d[k]
        + d[i] * c[j] * b[k]
    ).astype(np.int16)


def component(blocks: dict[str, np.ndarray], key: tuple[str, int], reps: np.ndarray) -> np.ndarray:
    kind, column = key
    i, j, k = reps[:, 0], reps[:, 1], reps[:, 2]
    if kind == "A":
        vector = blocks["A"][:, column]
        return (vector[i] * vector[j] * vector[k]).astype(np.int16)
    return group_component(blocks, column, reps)


def component_key(letter: str, column: int) -> tuple[str, int]:
    return ("A", column) if letter == "A" else ("G", column)


def candidate_component_deltas(
    blocks: dict[str, np.ndarray],
    letter: str,
    column: int,
    candidates: np.ndarray,
    reps: np.ndarray,
) -> np.ndarray:
    i, j, k = reps[:, 0], reps[:, 1], reps[:, 2]
    old = component(blocks, component_key(letter, column), reps)
    if letter == "A":
        values = candidates[:, i] * candidates[:, j] * candidates[:, k]
    else:
        b, c, d = (blocks[x][:, column] for x in "BCD")
        if letter == "B":
            values = (
                candidates[:, i] * d[j][None, :] * c[k][None, :]
                + c[i][None, :] * candidates[:, j] * d[k][None, :]
                + d[i][None, :] * c[j][None, :] * candidates[:, k]
            )
        elif letter == "C":
            values = (
                b[i][None, :] * d[j][None, :] * candidates[:, k]
                + candidates[:, i] * b[j][None, :] * d[k][None, :]
                + d[i][None, :] * candidates[:, j] * b[k][None, :]
            )
        else:
            values = (
                b[i][None, :] * candidates[:, j] * c[k][None, :]
                + c[i][None, :] * b[j][None, :] * candidates[:, k]
                + candidates[:, i] * c[j][None, :] * b[k][None, :]
            )
    return (values - old[None, :]).astype(np.int16)


def joint_group_components(
    blocks: dict[str, np.ndarray],
    column: int,
    left_letter: str,
    right_letter: str,
    left_vector: np.ndarray,
    right_candidates: np.ndarray,
    reps: np.ndarray,
) -> np.ndarray:
    i, j, k = reps[:, 0], reps[:, 1], reps[:, 2]
    count = len(right_candidates)

    def values(letter: str, indexes: np.ndarray) -> np.ndarray:
        if letter == left_letter:
            return left_vector[indexes][None, :]
        if letter == right_letter:
            return right_candidates[:, indexes]
        return blocks[letter][:, column][indexes][None, :]

    result = (
        values("B", i) * values("D", j) * values("C", k)
        + values("C", i) * values("B", j) * values("D", k)
        + values("D", i) * values("C", j) * values("B", k)
    )
    if result.shape != (count, len(reps)):
        result = np.broadcast_to(result, (count, len(reps)))
    return result.astype(np.int16)


def allowed_final_errors(reps: np.ndarray) -> list[tuple[np.ndarray, int]]:
    diagonal_indexes = [idx for idx, (i, j, k) in enumerate(reps) if i == j == k]
    patterns: list[tuple[np.ndarray, int]] = [(np.zeros(len(reps), dtype=np.int16), 0)]
    for index in diagonal_indexes:
        for sign in (-1, 1):
            error = np.zeros(len(reps), dtype=np.int16)
            error[index] = sign
            patterns.append((error, 1))
    for left, right in itertools.combinations(diagonal_indexes, 2):
        for left_sign, right_sign in itertools.product((-1, 1), repeat=2):
            error = np.zeros(len(reps), dtype=np.int16)
            error[left], error[right] = left_sign, right_sign
            patterns.append((error, 2))
    if len(patterns) != 163:
        raise RuntimeError(f"expected 163 E<=2 patterns, got {len(patterns)}")
    return patterns


def pair_structure_valid(
    base_row_coverage: np.ndarray,
    incumbent_k: int,
    left_old: np.ndarray,
    right_old: np.ndarray,
    left_new: np.ndarray,
    right_new: np.ndarray,
) -> tuple[bool, int]:
    left_support = int(np.count_nonzero(left_new))
    right_support = int(np.count_nonzero(right_new))
    if left_support == 0 or right_support == 0:
        return False, 0
    k_value = (
        incumbent_k
        - int(np.count_nonzero(left_old))
        - int(np.count_nonzero(right_old))
        + left_support
        + right_support
    )
    if k_value < 28:
        return False, k_value
    coverage = (
        base_row_coverage
        - (left_old != 0).astype(np.int16)
        - (right_old != 0).astype(np.int16)
        + (left_new != 0).astype(np.int16)
        + (right_new != 0).astype(np.int16)
    )
    return bool(np.all(coverage >= 1)), k_value


def describe(vector_id: tuple[str, int], candidate: np.ndarray, old: np.ndarray) -> dict:
    return {
        "vector": f"{vector_id[0]}{vector_id[1]}",
        "hamming_distance": int(np.count_nonzero(candidate != old)),
        "old": old.astype(int).tolist(),
        "new": candidate.astype(int).tolist(),
    }


def full_tensor_crosscheck(
    blocks: dict[str, np.ndarray],
    left_id: tuple[str, int],
    right_id: tuple[str, int],
    left_new: np.ndarray,
    right_new: np.ndarray,
) -> tuple[int, int, int]:
    """Recompute all 729 entries independently of the orbit search."""
    trial = {letter: matrix.copy() for letter, matrix in blocks.items()}
    trial[left_id[0]][:, left_id[1]] = left_new
    trial[right_id[0]][:, right_id[1]] = right_new
    a, b, c, d = (trial[letter] for letter in LETTERS)
    u = np.hstack((a, b, c, d)).astype(np.int16)
    v = np.hstack((a, d, b, c)).astype(np.int16)
    w = np.hstack((a, c, d, b)).astype(np.int16)
    expansion = np.einsum("ir,jr,kr->ijk", u, v, w, optimize=True)
    target = np.asarray(
        [
            semantic.target_value(i, j, k)
            for i in range(9)
            for j in range(9)
            for k in range(9)
        ],
        dtype=np.int16,
    ).reshape(9, 9, 9)
    errors = target - expansion
    e_value = int(np.sum(np.abs(errors)))
    k_value = int(sum(np.count_nonzero(trial[letter]) for letter in LETTERS))
    return e_value, k_value, int(np.max(np.abs(errors)))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    args = parser.parse_args()
    started = time.perf_counter()

    supplied, _ = semantic.read_solution(args.solution)
    raw = semantic.reconstruct_blocks(supplied, tolerance=0.0)
    blocks = {letter: np.asarray(raw[letter], dtype=np.int16) for letter in LETTERS}
    reps, weights = orbit_representatives()
    target = target_on_orbits(reps)
    components = {
        key: component(blocks, key, reps)
        for key in [("A", column) for column in range(3)]
        + [("G", column) for column in range(6)]
    }
    incumbent_tensor = sum(components.values(), np.zeros(len(reps), dtype=np.int16))
    incumbent_error = target - incumbent_tensor
    incumbent_e = int(np.abs(incumbent_error) @ weights)
    incumbent_k = int(sum(np.count_nonzero(blocks[x]) for x in LETTERS))
    incumbent_objective = 1000 * incumbent_e + 3 * incumbent_k
    if (incumbent_e, incumbent_k, incumbent_objective) != (2, 56, 2168):
        raise RuntimeError("unexpected incumbent semantics")

    vector_ids = [("A", column) for column in range(3)] + [
        (letter, column) for letter in "BCD" for column in range(6)
    ]
    candidate_sets = {
        vector_id: candidates_radius_two(blocks[vector_id[0]][:, vector_id[1]])
        for vector_id in vector_ids
    }
    deltas = {
        vector_id: candidate_component_deltas(
            blocks,
            vector_id[0],
            vector_id[1],
            candidate_sets[vector_id],
            reps,
        )
        for vector_id in vector_ids
    }
    base_row_coverage = sum(np.count_nonzero(blocks[x], axis=1) for x in LETTERS).astype(np.int16)
    allowed_errors = allowed_final_errors(reps)

    best = {
        "objective": incumbent_objective,
        "E": incumbent_e,
        "K": incumbent_k,
        "pair": None,
        "replacements": [],
    }
    strict_improvements = []
    pair_reports = []
    different_component_pairs = 0
    same_component_pairs = 0
    total_low_error_matches = 0
    total_structurally_valid_matches = 0
    full_tensor_crosschecks = 0

    for left_position, left_id in enumerate(vector_ids):
        for right_id in vector_ids[left_position + 1 :]:
            left_candidates = candidate_sets[left_id]
            right_candidates = candidate_sets[right_id]
            left_old = blocks[left_id[0]][:, left_id[1]]
            right_old = blocks[right_id[0]][:, right_id[1]]
            same_component = component_key(*left_id) == component_key(*right_id)
            low_error_matches = 0
            structurally_valid_matches = 0
            pair_best = None

            if not same_component:
                different_component_pairs += 1
                right_map: dict[bytes, list[int]] = {}
                for right_index, delta in enumerate(deltas[right_id]):
                    right_map.setdefault(delta.tobytes(), []).append(right_index)
                for left_index, left_delta in enumerate(deltas[left_id]):
                    for final_error, e_value in allowed_errors:
                        needed = (incumbent_error - final_error - left_delta).astype(np.int16)
                        for right_index in right_map.get(needed.tobytes(), ()):
                            low_error_matches += 1
                            valid, k_value = pair_structure_valid(
                                base_row_coverage,
                                incumbent_k,
                                left_old,
                                right_old,
                                left_candidates[left_index],
                                right_candidates[right_index],
                            )
                            if not valid:
                                continue
                            structurally_valid_matches += 1
                            checked_e, checked_k, checked_max = full_tensor_crosscheck(
                                blocks,
                                left_id,
                                right_id,
                                left_candidates[left_index],
                                right_candidates[right_index],
                            )
                            if (checked_e, checked_k) != (e_value, k_value) or checked_max > 1:
                                raise RuntimeError(
                                    "orbit/full-tensor cross-check failed for "
                                    f"{left_id}, {right_id}: orbit={(e_value, k_value)}, "
                                    f"full={(checked_e, checked_k, checked_max)}"
                                )
                            full_tensor_crosschecks += 1
                            objective = 1000 * e_value + 3 * k_value
                            if pair_best is None or objective < pair_best:
                                pair_best = objective
                            if objective < best["objective"]:
                                best = {
                                    "objective": objective,
                                    "E": e_value,
                                    "K": k_value,
                                    "pair": [f"{left_id[0]}{left_id[1]}", f"{right_id[0]}{right_id[1]}"],
                                    "replacements": [
                                        describe(left_id, left_candidates[left_index], left_old),
                                        describe(right_id, right_candidates[right_index], right_old),
                                    ],
                                }
                            if objective < incumbent_objective and len(strict_improvements) < 100:
                                strict_improvements.append(
                                    {
                                        "objective": objective,
                                        "E": e_value,
                                        "K": k_value,
                                        "pair": [f"{left_id[0]}{left_id[1]}", f"{right_id[0]}{right_id[1]}"],
                                        "replacements": [
                                            describe(left_id, left_candidates[left_index], left_old),
                                            describe(right_id, right_candidates[right_index], right_old),
                                        ],
                                    }
                                )
            else:
                same_component_pairs += 1
                old_component = components[component_key(*left_id)]
                for left_index, left_candidate in enumerate(left_candidates):
                    new_components = joint_group_components(
                        blocks,
                        left_id[1],
                        left_id[0],
                        right_id[0],
                        left_candidate,
                        right_candidates,
                        reps,
                    )
                    final_errors = incumbent_error[None, :] - (new_components - old_component[None, :])
                    allowed_mask = np.all(np.abs(final_errors) <= 1, axis=1)
                    e_values = np.abs(final_errors) @ weights
                    allowed_mask &= e_values <= 2
                    for right_index in np.flatnonzero(allowed_mask):
                        low_error_matches += 1
                        valid, k_value = pair_structure_valid(
                            base_row_coverage,
                            incumbent_k,
                            left_old,
                            right_old,
                            left_candidate,
                            right_candidates[right_index],
                        )
                        if not valid:
                            continue
                        structurally_valid_matches += 1
                        e_value = int(e_values[right_index])
                        checked_e, checked_k, checked_max = full_tensor_crosscheck(
                            blocks,
                            left_id,
                            right_id,
                            left_candidate,
                            right_candidates[right_index],
                        )
                        if (checked_e, checked_k) != (e_value, k_value) or checked_max > 1:
                            raise RuntimeError(
                                "orbit/full-tensor cross-check failed for "
                                f"{left_id}, {right_id}: orbit={(e_value, k_value)}, "
                                f"full={(checked_e, checked_k, checked_max)}"
                            )
                        full_tensor_crosschecks += 1
                        objective = 1000 * e_value + 3 * k_value
                        if pair_best is None or objective < pair_best:
                            pair_best = objective
                        if objective < best["objective"]:
                            best = {
                                "objective": objective,
                                "E": e_value,
                                "K": k_value,
                                "pair": [f"{left_id[0]}{left_id[1]}", f"{right_id[0]}{right_id[1]}"],
                                "replacements": [
                                    describe(left_id, left_candidate, left_old),
                                    describe(right_id, right_candidates[right_index], right_old),
                                ],
                            }
                        if objective < incumbent_objective and len(strict_improvements) < 100:
                            strict_improvements.append(
                                {
                                    "objective": objective,
                                    "E": e_value,
                                    "K": k_value,
                                    "pair": [f"{left_id[0]}{left_id[1]}", f"{right_id[0]}{right_id[1]}"],
                                    "replacements": [
                                        describe(left_id, left_candidate, left_old),
                                        describe(right_id, right_candidates[right_index], right_old),
                                    ],
                                }
                            )

            total_low_error_matches += low_error_matches
            total_structurally_valid_matches += structurally_valid_matches
            pair_reports.append(
                {
                    "pair": [f"{left_id[0]}{left_id[1]}", f"{right_id[0]}{right_id[1]}"],
                    "same_cyclic_component": same_component,
                    "nominal_candidates": len(left_candidates) * len(right_candidates),
                    "low_error_matches_E_le_2": low_error_matches,
                    "structurally_valid_low_error_matches": structurally_valid_matches,
                    "best_objective_among_low_error_matches": pair_best,
                }
            )

    nominal = len(pair_reports) * 163 * 163
    if len(pair_reports) != 210 or nominal != 5_579_490:
        raise RuntimeError("pair enumeration count mismatch")
    if full_tensor_crosschecks != total_structurally_valid_matches:
        raise RuntimeError("not every structurally valid low-error match was cross-checked")
    result = {
        "instance": "fastxgemm-n3r21s3t6",
        "method": (
            "exact replacement of every unordered pair of underlying vectors, "
            "coefficient-Hamming radius at most 2 per vector"
        ),
        "input_solution": "artifacts/exact_2168.sol",
        "input_solution_sha256": hashlib.sha256(args.solution.read_bytes()).hexdigest(),
        "arithmetic": "integer orbit arithmetic; no solver tolerances",
        "incumbent": {"E": incumbent_e, "K": incumbent_k, "objective": incumbent_objective},
        "scope": {
            "underlying_vectors": len(vector_ids),
            "unordered_vector_pairs": len(pair_reports),
            "candidates_per_vector": 163,
            "nominal_paired_replacements": nominal,
            "maximum_hamming_radius_per_vector": 2,
            "maximum_total_coefficient_hamming_radius": 4,
            "cyclic_tensor_orbits": len(reps),
            "diagonal_orbits": 9,
            "allowed_final_error_patterns_E_le_2": len(allowed_errors),
            "different_component_pairs": different_component_pairs,
            "same_cyclic_component_pairs_recomputed_jointly": same_component_pairs,
        },
        "search_counts": {
            "paired_replacements_with_E_le_2_before_structure_checks": total_low_error_matches,
            "original_model_structurally_valid_paired_replacements_with_E_le_2": (
                total_structurally_valid_matches
            ),
            "independent_full_729_entry_crosschecks": full_tensor_crosschecks,
        },
        "best": best,
        "strict_improvement_found": bool(strict_improvements),
        "strict_improvements_saved": strict_improvements,
        "certificate_scope": (
            "No objective below 2168 exists among points whose changes are confined "
            "to at most two distinct A/B/C/D column vectors, with at most two changed "
            "coefficients in each. This is a local exhaustive certificate, not a "
            "global optimality proof."
        ),
        "elapsed_seconds": time.perf_counter() - started,
        "pair_results": pair_reports,
    }
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(
        json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    print(
        json.dumps(
            {
                "best": best,
                "strict_improvement_found": bool(strict_improvements),
                "nominal": nominal,
                "low_error_matches": total_low_error_matches,
                "structurally_valid_low_error_matches": total_structurally_valid_matches,
                "elapsed_seconds": result["elapsed_seconds"],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
