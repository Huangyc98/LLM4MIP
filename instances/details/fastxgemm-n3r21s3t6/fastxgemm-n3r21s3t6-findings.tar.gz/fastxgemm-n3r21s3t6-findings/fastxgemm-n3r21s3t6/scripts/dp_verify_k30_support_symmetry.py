#!/usr/bin/env python3
"""Solver-free DP check of the 12 symmetry classes in the R21 K=30 proof."""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import dp_verify_k30_support as base


def transform(point: int, permutation: tuple[int, int, int], transpose: bool) -> int:
    a, b = divmod(point, 3)
    if transpose:
        a, b = b, a
    return 3 * permutation[a] + permutation[b]


def canonical(high: tuple[int, int, int]) -> tuple[int, int, int]:
    images = []
    for permutation in itertools.permutations(range(3)):
        for transpose in (False, True):
            images.append(tuple(sorted(transform(point, permutation, transpose) for point in high)))
    return min(images)


def compute(high: tuple[int, int, int]) -> dict:
    high_mask = sum(1 << row for row in high)
    target = tuple(4 if row in high else 3 for row in base.ROWS)
    a_patterns = base.a_patterns(high_mask)
    bcd_patterns = base.bcd_patterns(high_mask)
    reachable, state_counts = base.reachable_target(target, a_patterns, bcd_patterns)
    return {
        "representative_high_rows": list(high),
        "representative_coordinates": [list(divmod(row, 3)) for row in high],
        "a_pattern_count": len(a_patterns),
        "bcd_pattern_count": len(bcd_patterns),
        "reachable": reachable,
        "dp_state_counts": state_counts,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    args = parser.parse_args()
    started = time.perf_counter()

    members: dict[tuple[int, int, int], list[tuple[int, int, int]]] = {}
    for high in itertools.combinations(range(9), 3):
        members.setdefault(canonical(high), []).append(high)
    representatives = sorted(members)
    if len(representatives) != 12 or sum(map(len, members.values())) != 84:
        raise AssertionError((len(representatives), sum(map(len, members.values()))))

    if args.workers == 1:
        reports = [compute(representative) for representative in representatives]
    else:
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            reports = list(pool.map(compute, representatives))
    for report in reports:
        key = tuple(report["representative_high_rows"])
        report["symmetry_orbit_size"] = len(members[key])

    payload = json.dumps(reports, sort_keys=True, separators=(",", ":")).encode()
    result = {
        "instance": "fastxgemm-n3r21s3t6",
        "method": "pure-Python bitmask orbit enumeration and finite-set DP; no solver",
        "scope": "support-only necessary conditions in the sole K=30 degree pattern",
        "symmetry_group": "simultaneous S3 grid relabeling and transpose",
        "representative_count": len(reports),
        "covered_high_sets": sum(report["symmetry_orbit_size"] for report in reports),
        "reachable_representative_count": sum(report["reachable"] for report in reports),
        "all_84_high_sets_unreachable": not any(report["reachable"] for report in reports),
        "elapsed_seconds": time.perf_counter() - started,
        "reports_sha256": hashlib.sha256(payload).hexdigest(),
        "reports": reports,
        "interpretation": (
            "Unreachability of all 12 symmetry representatives independently confirms "
            "the finite support obstruction used to exclude exact K=30."
        ),
    }
    if not result["all_84_high_sets_unreachable"]:
        raise RuntimeError("a K=30 support pattern survived the DP audit")
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({key: result[key] for key in (
        "representative_count", "covered_high_sets", "reachable_representative_count",
        "all_84_high_sets_unreachable", "elapsed_seconds", "reports_sha256"
    )}, indent=2))


if __name__ == "__main__":
    main()
