#!/usr/bin/env python3
"""Complete an external-derived R21 core on the official MIPLIB MPS."""

from __future__ import annotations

import argparse
import json
import math
import re
from collections import Counter, defaultdict
from pathlib import Path

import gurobipy as gp
import numpy as np


WIDTHS = {"A": 3, "B": 6, "C": 6, "D": 6}
ENCODING = re.compile(r"^(POS|NEG)_([ABCD])_(\d+)_(\d+)$")


def row_violations(model: gp.Model, x: np.ndarray) -> np.ndarray:
    activity = model.getA().tocsr().dot(x)
    violation = np.zeros(model.NumConstrs)
    for index, constraint in enumerate(model.getConstrs()):
        if constraint.Sense == "<":
            violation[index] = max(0.0, activity[index] - constraint.RHS)
        elif constraint.Sense == ">":
            violation[index] = max(0.0, constraint.RHS - activity[index])
        else:
            violation[index] = abs(activity[index] - constraint.RHS)
    return violation


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("candidate_core", type=Path)
    parser.add_argument("--solution", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--time-limit", type=float, default=120.0)
    parser.add_argument("--threads", type=int, default=8)
    args = parser.parse_args()
    for path in (args.solution, args.report, args.log):
        path.parent.mkdir(parents=True, exist_ok=True)

    source = json.loads(args.candidate_core.read_text(encoding="utf-8"))
    blocks = source["fastxgemm_core_mapping"]
    expected_semantics = {
        "E": int(source["exact_integer_tensor_audit"]["residual_l1"]),
        "K": int(source["support"]["core_K"]),
        "full_factor_support": int(source["support"]["full_factor_support"]),
        "objective": int(source["support"]["candidate_fastxgemm_objective_if_mapped"]),
    }

    expected: dict[str, int] = {}
    for letter, width in WIDTHS.items():
        columns = blocks[letter]
        if len(columns) != width or any(len(column) != 9 for column in columns):
            raise ValueError(f"bad {letter} dimensions")
        for column, vector in enumerate(columns):
            for row, value in enumerate(vector):
                if value not in (-1, 0, 1):
                    raise ValueError(f"non-ternary {letter}[{row},{column}]={value}")
                expected[f"POS_{letter}_{row}_{column}"] = int(value == 1)
                expected[f"NEG_{letter}_{row}_{column}"] = int(value == -1)

    model = gp.read(str(args.mps))
    variables = model.getVars()
    integer_names = {
        variable.VarName
        for variable in variables
        if variable.VType in {gp.GRB.BINARY, gp.GRB.INTEGER}
    }
    missing = sorted(set(expected) - integer_names)
    unexpected = sorted(integer_names - set(expected))
    if missing or unexpected:
        raise ValueError(f"integer encoding mismatch: missing={missing[:10]}, unexpected={unexpected[:10]}")

    for variable in variables:
        if variable.VarName in expected:
            value = expected[variable.VarName]
            variable.LB = value
            variable.UB = value
            variable.Start = value
    model.update()
    model.Params.FeasibilityTol = 1e-9
    model.Params.IntFeasTol = 1e-9
    model.Params.OptimalityTol = 1e-9
    model.Params.NumericFocus = 3
    model.Params.Presolve = 2
    model.Params.Method = 1
    model.Params.Threads = args.threads
    model.Params.TimeLimit = args.time_limit
    model.Params.LogFile = str(args.log)
    model.optimize()
    if model.Status != gp.GRB.OPTIMAL or model.SolCount < 1:
        raise RuntimeError(f"fixed-pattern completion failed: status={model.Status}, solutions={model.SolCount}")
    model.write(str(args.solution))

    x = np.array([variable.X for variable in variables])
    rounded = np.rint(x)
    violations = row_violations(model, x)
    rounded_violations = row_violations(model, rounded)
    family_sums: dict[str, float] = defaultdict(float)
    prefixes = (
        "ABS_ALT_U", "ABS_ALT_V", "ABS_ALT_W",
        "ABS_DIFF_U", "ABS_DIFF_V", "ABS_DIFF_W", "RESIDUAL",
    )
    nonzero_residuals = []
    for variable, value in zip(variables, x):
        for prefix in prefixes:
            if variable.VarName.startswith(prefix + "_"):
                family_sums[prefix] += float(value)
                if prefix == "RESIDUAL" and abs(value) > 1e-12:
                    nonzero_residuals.append({"name": variable.VarName, "value": float(value)})
                break

    objective_rounded = float(
        sum(variable.Obj * rounded[index] for index, variable in enumerate(variables)) + model.ObjCon
    )
    report = {
        "claim_scope": "strict feasible external-derived upper bound; fixed-pattern OPTIMAL is not full-MIP optimality",
        "attribution": source["attribution"],
        "gurobi_version": ".".join(map(str, gp.gurobi.version())),
        "inputs": {"mps": str(args.mps.resolve()), "candidate_core": str(args.candidate_core.resolve())},
        "outputs": {"solution": str(args.solution.resolve()), "log": str(args.log.resolve())},
        "model": {
            "fingerprint": "0x%08x" % (model.Fingerprint & 0xFFFFFFFF),
            "variables": model.NumVars,
            "constraints": model.NumConstrs,
            "nonzeros": model.NumNZs,
            "variable_types": dict(Counter(variable.VType for variable in variables)),
        },
        "encoding": {
            "fixed_integer_count": len(expected),
            "fixed_integer_ones": sum(expected.values()),
            "missing_expected_count": len(missing),
            "unexpected_integer_count": len(unexpected),
        },
        "solve": {
            "status": int(model.Status),
            "status_name": "OPTIMAL",
            "runtime_seconds": float(model.Runtime),
            "work": float(model.Work),
            "objective": float(model.ObjVal),
            "objective_bound": float(model.ObjBound),
            "solution_count": int(model.SolCount),
        },
        "strict_numeric_audit": {
            "max_constraint_violation": float(np.max(violations)),
            "violated_rows_gt_1e-9": int(np.sum(violations > 1e-9)),
            "max_distance_to_integer_all_variables": float(np.max(np.abs(x - rounded))),
            "max_constraint_violation_after_rounding_all_values": float(np.max(rounded_violations)),
            "objective_after_rounding_all_values": objective_rounded,
            "family_sums": dict(sorted(family_sums.items())),
            "nonzero_residuals": nonzero_residuals,
        },
        "expected_semantics": expected_semantics,
        "expected_matches_solver": {
            "objective": math.isclose(model.ObjVal, expected_semantics["objective"], abs_tol=1e-9),
            "E": math.isclose(family_sums["RESIDUAL"], expected_semantics["E"], abs_tol=1e-9),
            "K_each_factor": all(
                math.isclose(family_sums[prefix], expected_semantics["K"], abs_tol=1e-9)
                for prefix in ("ABS_ALT_U", "ABS_ALT_V", "ABS_ALT_W")
            ),
        },
    }
    args.report.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
