#!/usr/bin/env python3
"""Search the complete residual orbit needed to improve the strict 2168 incumbent."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import gurobipy as gp


def finite(value: float) -> float | None:
    return float(value) if math.isfinite(float(value)) else None


def residual_index(name: str) -> tuple[int, int, int]:
    prefix = "RESIDUAL_"
    if not name.startswith(prefix):
        raise ValueError(name)
    i, j, k = name[len(prefix) :].split("_")
    return int(i), int(j), int(k)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "mode",
        choices=("target-pair", "diagonal-e-le1", "diagonal-e2-k55"),
    )
    parser.add_argument("mps", type=Path)
    parser.add_argument("mst", type=Path)
    parser.add_argument("--time-limit", type=float, default=600.0)
    parser.add_argument("--threads", type=int, default=8)
    parser.add_argument("--output-model", type=Path, required=True)
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--output-solution", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    args = parser.parse_args()
    for path in (args.output_model, args.output_json, args.output_solution, args.log):
        path.parent.mkdir(parents=True, exist_ok=True)

    model = gp.read(str(args.mps))
    model.read(str(args.mst))
    residuals = [v for v in model.getVars() if v.VarName.startswith("RESIDUAL_")]
    diagonal = [v for v in residuals if len(set(residual_index(v.VarName))) == 1]
    if len(residuals) != 729 or len(diagonal) != 9:
        raise RuntimeError(f"unexpected residual dimensions: all={len(residuals)}, diag={len(diagonal)}")

    if args.mode == "target-pair":
        allowed_names = {"RESIDUAL_0_0_0", "RESIDUAL_4_4_4"}
    else:
        allowed_names = {v.VarName for v in diagonal}
    forbidden = [v for v in residuals if v.VarName not in allowed_names]
    for variable in forbidden:
        variable.UB = 0.0
    allowed = [v for v in residuals if v.VarName in allowed_names]
    if args.mode == "diagonal-e-le1":
        model.addConstr(gp.quicksum(allowed) <= 1, name="RESIDUAL_DIAGONAL_SUM_LE_1")
        residual_sum_sense = "<=1"
    elif args.mode == "diagonal-e2-k55":
        model.addConstr(gp.quicksum(allowed) == 2, name="RESIDUAL_DIAGONAL_SUM_EQ_2")
        residual_sum_sense = "=2"
    else:
        model.addConstr(gp.quicksum(allowed) <= 2, name="RESIDUAL_DIAGONAL_SUM_LE_2")
        residual_sum_sense = "<=2"

    # Any integral strict improvement over 2168 has objective at most 2165:
    # E is integral and expanded cyclic sparsity is a multiple of three.
    model.addConstr(model.getObjective() <= 2165, name="STRICT_IMPROVEMENT_OBJ_LE_2165")

    if args.mode in {"target-pair", "diagonal-e2-k55"}:
        abs_alt_u = [v for v in model.getVars() if v.VarName.startswith("ABS_ALT_U_")]
        if len(abs_alt_u) != 189:
            raise RuntimeError(f"unexpected ABS_ALT_U count: {len(abs_alt_u)}")
        model.addConstr(gp.quicksum(abs_alt_u) <= 55, name="CYCLIC_CORE_K_LE_55")
    model.update()
    model.write(str(args.output_model))

    model.Params.TimeLimit = args.time_limit
    model.Params.Threads = args.threads
    model.Params.Presolve = 2
    model.Params.FeasibilityTol = 1e-9
    model.Params.IntFeasTol = 1e-9
    model.Params.OptimalityTol = 1e-9
    model.Params.NumericFocus = 3
    model.Params.MIPFocus = 1
    model.Params.Heuristics = 0.75
    model.Params.Symmetry = 2
    model.Params.StartNodeLimit = 250
    model.Params.NoRelHeurTime = min(30.0, args.time_limit / 4)
    model.Params.Cuts = 1
    model.Params.SolutionLimit = 1
    model.Params.LogFile = str(args.log)
    model.optimize()

    if model.SolCount:
        model.write(str(args.output_solution))

    report = {
        "mode": args.mode,
        "gurobi_version": ".".join(map(str, gp.gurobi.version())),
        "inputs": {"mps": str(args.mps), "author_mst": str(args.mst)},
        "outputs": {
            "model": str(args.output_model),
            "solution": str(args.output_solution) if model.SolCount else None,
            "log": str(args.log),
        },
        "formulation": {
            "total_residuals": len(residuals),
            "diagonal_residuals": len(diagonal),
            "allowed_residual_names": sorted(allowed_names),
            "fixed_zero_residual_count": len(forbidden),
            "allowed_residual_sum_condition": residual_sum_sense,
            "objective_upper_bound": 2165,
            "cyclic_core_k_upper_bound": (
                55 if args.mode in {"target-pair", "diagonal-e2-k55"} else None
            ),
            "completeness_note": (
                "For an integral cyclic solution, every non-diagonal residual orbit has size 3. "
                "Therefore any objective below 2168 (hence E<=2) has zero non-diagonal residuals. "
                "The expanded sparsity is three times the cyclic-core sparsity, so the next strict "
                "objective below 2168 is at most 2165."
            ),
        },
        "dimensions": {
            "variables": model.NumVars,
            "constraints": model.NumConstrs,
            "nonzeros": model.NumNZs,
            "integer_variables": sum(
                v.VType in {gp.GRB.BINARY, gp.GRB.INTEGER} for v in model.getVars()
            ),
        },
        "parameters": {
            "TimeLimit": args.time_limit,
            "Threads": args.threads,
            "Presolve": 2,
            "FeasibilityTol": 1e-9,
            "IntFeasTol": 1e-9,
            "OptimalityTol": 1e-9,
            "NumericFocus": 3,
            "MIPFocus": 1,
            "Heuristics": 0.75,
            "Symmetry": 2,
            "StartNodeLimit": 250,
            "NoRelHeurTime": min(30.0, args.time_limit / 4),
            "Cuts": 1,
            "SolutionLimit": 1,
        },
        "solve": {
            "status": int(model.Status),
            "runtime_seconds": float(model.Runtime),
            "work": float(model.Work),
            "node_count": float(model.NodeCount),
            "simplex_iterations": float(model.IterCount),
            "solution_count": int(model.SolCount),
            "objective": finite(model.ObjVal) if model.SolCount else None,
            "objective_bound": finite(model.ObjBound),
            "mip_gap": finite(model.MIPGap) if model.SolCount else None,
        },
    }
    args.output_json.write_text(
        json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
