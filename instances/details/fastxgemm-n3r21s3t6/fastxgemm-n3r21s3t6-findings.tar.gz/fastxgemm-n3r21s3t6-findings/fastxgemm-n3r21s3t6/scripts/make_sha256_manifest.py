#!/usr/bin/env python3
"""Write deterministic SHA256 hashes for continuation artifacts."""

from __future__ import annotations

import argparse
import hashlib
import subprocess
from pathlib import Path


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def git_output(repository: Path, *args: str) -> bytes:
    return subprocess.run(
        ["git", *args],
        cwd=repository,
        check=True,
        stdout=subprocess.PIPE,
    ).stdout


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "--git-index",
        action="store_true",
        help="hash the staged Git blobs, avoiding checkout line-ending differences",
    )
    args = parser.parse_args()
    directory = args.directory.resolve()
    output = args.output.resolve()
    if args.git_index:
        repository = Path(
            git_output(directory, "rev-parse", "--show-toplevel")
            .decode("utf-8")
            .strip()
        ).resolve()
        directory_relative = directory.relative_to(repository).as_posix()
        output_relative = output.relative_to(repository).as_posix()
        tracked = git_output(
            repository, "ls-files", "-z", "--", directory_relative
        ).decode("utf-8").split("\0")
        tracked = sorted(
            path for path in tracked
            if path and path != output_relative and "__pycache__" not in Path(path).parts
        )
        lines = []
        for repository_relative in tracked:
            display = Path(repository_relative).relative_to(directory_relative).as_posix()
            data = git_output(repository, "show", f":{repository_relative}")
            lines.append(f"{sha256_bytes(data)}  {display}")
        file_count = len(tracked)
    else:
        files = sorted(
            (
                path
                for path in directory.rglob("*")
                if path.is_file()
                and path.resolve() != output
                and "__pycache__" not in path.parts
            ),
            key=lambda path: path.relative_to(directory).as_posix(),
        )
        lines = [
            f"{sha256(path)}  {path.relative_to(directory).as_posix()}"
            for path in files
        ]
        file_count = len(files)
    output.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    print(f"files={file_count} source={'git-index' if args.git_index else 'working-tree'} output={output}")


if __name__ == "__main__":
    main()
