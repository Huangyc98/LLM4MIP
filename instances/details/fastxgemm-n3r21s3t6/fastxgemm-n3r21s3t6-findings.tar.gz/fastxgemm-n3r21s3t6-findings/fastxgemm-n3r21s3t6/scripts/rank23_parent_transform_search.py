#!/usr/bin/env python3
"""Search rank-21 S=3,T=6 children of published cyclic rank-23 schemes.

For a cyclic rank-23 parent with S=2 fixed cubes and T=7 cyclic triples,
remove one triple and add one arbitrary ternary cube.  The result has exactly
the S=3,T=6 structure of fastxgemm-n3r21s3t6.  All 7*3^9 children are checked
with exact integer tensor arithmetic.

The first parent below is equations (12)--(20), section 2.4, of:
  Ballard, Ikenmeyer, Landsberg, Ryder,
  "The geometry of rank decompositions of matrix multiplication II:
   3 x 3 matrices", arXiv:1801.00843.
"""

from __future__ import annotations

import argparse
import itertools
import json
import time
from pathlib import Path

import numpy as np

from one_vector_scan import cyclic_group, target_tensor


def matrix(rows):
    value = np.asarray(rows, dtype=np.int8)
    assert value.shape == (3, 3)
    return value.reshape(9)


def section_2_4_parent():
    cubes = [
        matrix([[1, 0, 0], [0, 0, 1], [0, 0, 1]]),
        matrix([[0, 0, 0], [0, 1, -1], [0, 0, 0]]),
    ]
    # Each tuple is (X,Y,Z) in X tensor Y tensor Z plus its two cyclic shifts.
    triples = [
        (
            matrix([[0, 1, 0], [0, 0, 1], [0, 0, 0]]),
            matrix([[0, 0, 0], [0, 1, -1], [0, 1, -1]]),
            matrix([[0, 0, 0], [1, 0, -1], [0, 0, 0]]),
        ),
        (
            matrix([[0, -1, 1], [0, 0, 0], [0, 0, 0]]),
            matrix([[0, 0, 0], [0, 0, 0], [0, 0, 1]]),
            matrix([[0, 0, 0], [0, 0, 0], [1, 0, 0]]),
        ),
        (
            matrix([[1, 0, 0], [1, 0, 0], [0, 0, 0]]),
            matrix([[0, -1, 1], [0, 0, 0], [0, 0, 0]]),
            matrix([[0, 0, 0], [0, 0, 0], [0, 1, 0]]),
        ),
        (
            matrix([[1, 0, 0], [0, 0, 1], [0, 0, 0]]),
            matrix([[0, 1, 0], [0, 0, 1], [0, 0, 1]]),
            matrix([[0, 0, 0], [1, 0, -1], [0, 1, -1]]),
        ),
        (
            matrix([[1, 0, 0], [0, 0, 0], [0, 0, 0]]),
            matrix([[0, 0, 1], [0, 0, 1], [0, 0, 1]]),
            matrix([[0, 0, 0], [0, 0, 0], [1, -1, 0]]),
        ),
        (
            matrix([[0, 0, 0], [0, 0, 1], [0, 0, 0]]),
            matrix([[0, 1, 0], [0, 1, 0], [0, 1, 0]]),
            matrix([[0, 0, 0], [-1, 1, 0], [0, 0, 0]]),
        ),
        (
            matrix([[0, 0, 0], [0, 0, 1], [0, 0, 1]]),
            matrix([[1, 0, 0], [1, 0, 0], [1, 0, 0]]),
            matrix([[-1, 1, 0], [0, 0, 0], [0, 0, 0]]),
        ),
    ]
    return cubes, triples


def appendix_a_3_parent():
    """Appendix A.3, equations (61)--(68), another S=2,T=7 parent."""
    cubes = [
        matrix([[0, 0, 0], [0, 1, 0], [0, 0, 1]]),
        matrix([[1, 0, 0], [0, 0, 0], [0, 0, 0]]),
    ]
    triples = [
        (
            matrix([[0, 0, 0], [0, 0, 0], [0, 0, 1]]),
            matrix([[0, 0, 0], [0, -1, 0], [0, 1, 0]]),
            matrix([[0, 0, 0], [0, 1, 1], [0, 0, 0]]),
        ),
        (
            matrix([[0, 0, 0], [1, 1, 0], [0, 0, 0]]),
            matrix([[-1, 0, -1], [0, 0, 0], [0, 0, 0]]),
            matrix([[0, -1, 0], [0, 0, 0], [0, 0, 0]]),
        ),
        (
            matrix([[0, 0, 0], [0, 0, 0], [-1, 0, 0]]),
            matrix([[0, 1, 0], [0, 0, 0], [0, 0, 0]]),
            matrix([[0, 0, 0], [0, -1, -1], [0, 0, 0]]),
        ),
        (
            matrix([[0, 0, -1], [0, 0, 0], [0, 0, 0]]),
            matrix([[0, 1, 0], [0, 0, 0], [-1, -1, 0]]),
            matrix([[0, 0, 0], [1, 0, 0], [-1, 0, 0]]),
        ),
        (
            matrix([[0, 1, 1], [0, 0, 0], [0, -1, -1]]),
            matrix([[0, 0, 0], [0, 0, 0], [1, 0, 0]]),
            matrix([[1, 0, 0], [-1, 0, 0], [1, 0, 0]]),
        ),
        (
            matrix([[0, 0, 0], [0, 0, 0], [0, 1, 1]]),
            matrix([[0, 0, 0], [0, 1, 0], [0, 0, 0]]),
            matrix([[-1, 0, -1], [1, 0, 1], [-1, 0, -1]]),
        ),
        (
            matrix([[0, 0, 0], [0, -1, 0], [-1, 0, 0]]),
            matrix([[1, 0, 1], [-1, 0, 0], [1, 0, 0]]),
            matrix([[0, 1, 0], [0, 0, 0], [0, -1, -1]]),
        ),
    ]
    return cubes, triples


def cube(vector):
    return np.einsum("i,j,k->ijk", vector, vector, vector, dtype=np.int16)


def orbit(x, y, z):
    # cyclic_group(B,C,D) = BxDxC + CxBxD + DxCxB.
    # B=X, D=Y, C=Z therefore gives XxYxZ and cyclic shifts.
    return cyclic_group(x, z, y)


def parent_tensor(cubes, triples):
    result = np.zeros((9, 9, 9), dtype=np.int16)
    for vector in cubes:
        result += cube(vector)
    for x, y, z in triples:
        result += orbit(x, y, z)
    return result


def structural_valid(cubes, triples):
    if any(np.count_nonzero(vector) == 0 for vector in cubes):
        return False
    if any(np.count_nonzero(vector) == 0 for triple in triples for vector in triple):
        return False
    row_coverage = np.zeros(9, dtype=np.int16)
    for vector in cubes:
        row_coverage += vector != 0
    for triple in triples:
        for vector in triple:
            row_coverage += vector != 0
    return bool(np.all(row_coverage >= 1))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    started = time.perf_counter()

    target = target_tensor()
    vectors = np.asarray(list(itertools.product((-1, 0, 1), repeat=9)), dtype=np.int8)
    vector_support = np.count_nonzero(vectors, axis=1)
    best = None
    parent_results = []

    parents = [
        ("Section 2.4, equations (12)-(20)", section_2_4_parent()),
        ("Appendix A.3, equations (61)-(68)", appendix_a_3_parent()),
    ]
    for parent_name, (parent_cubes, parent_triples) in parents:
        reconstructed_parent = parent_tensor(parent_cubes, parent_triples)
        parent_difference = target - reconstructed_parent
        if np.any(parent_difference):
            nonzero = np.argwhere(parent_difference)
            raise RuntimeError(
                f"transcribed published parent {parent_name} is not exact: "
                f"L1={np.abs(parent_difference).sum()}, nonzero={nonzero[:10].tolist()}"
            )
        parent_k = sum(np.count_nonzero(v) for v in parent_cubes) + sum(
            np.count_nonzero(v) for triple in parent_triples for v in triple
        )
        scans = []

        for removed_index, removed_triple in enumerate(parent_triples):
            remaining_triples = [
                triple for index, triple in enumerate(parent_triples) if index != removed_index
            ]
            removed_tensor = orbit(*removed_triple)
            removed_support = sum(np.count_nonzero(v) for v in removed_triple)
            remainder = target - removed_tensor
            feasible = 0
            local_best = None
            local_examples = []
            for first in range(0, len(vectors), 256):
                batch = vectors[first:first + 256]
                cubes = np.einsum(
                    "bi,bj,bk->bijk", batch, batch, batch,
                    optimize=True, dtype=np.int16
                )
                candidate_tensors = remainder[None, :, :, :] + cubes
                differences = target[None, :, :, :] - candidate_tensors
                max_error = np.max(np.abs(differences), axis=(1, 2, 3))
                e_values = np.sum(np.abs(differences), axis=(1, 2, 3))
                k_values = parent_k - removed_support + vector_support[first:first + len(batch)]
                objectives = 1000 * e_values + 3 * k_values

                for index in range(len(batch)):
                    if vector_support[first + index] == 0 or max_error[index] > 1 or k_values[index] < 28:
                        continue
                    child_cubes = parent_cubes + [batch[index]]
                    if not structural_valid(child_cubes, remaining_triples):
                        continue
                    feasible += 1
                    record = {
                        "parent": parent_name,
                        "removed_triple": removed_index,
                        "added_cube": batch[index].astype(int).tolist(),
                        "E": int(e_values[index]),
                        "K": int(k_values[index]),
                        "objective": int(objectives[index]),
                    }
                    if local_best is None or record["objective"] < local_best:
                        local_best = record["objective"]
                        local_examples = [record]
                    elif record["objective"] == local_best and len(local_examples) < 20:
                        local_examples.append(record)
                    if best is None or record["objective"] < best["objective"]:
                        best = record

            scans.append(
                {
                    "removed_triple": removed_index,
                    "removed_support": int(removed_support),
                    "children_enumerated": len(vectors),
                    "original_model_integer_feasible": feasible,
                    "best_objective": local_best,
                    "best_examples": local_examples,
                }
            )
            print(
                f"{parent_name}, triple {removed_index}: feasible={feasible}, best={local_best}",
                flush=True,
            )
        parent_results.append(
            {
                "parent": parent_name,
                "S": 2,
                "T": 7,
                "R": 23,
                "K": int(parent_k),
                "exact": True,
                "scans": scans,
            }
        )

    result = {
        "instance": "fastxgemm-n3r21s3t6",
        "source": {
            "paper": "Ballard et al., arXiv:1801.00843",
            "parents": [name for name, _ in parents],
            "url": "https://arxiv.org/abs/1801.00843",
        },
        "method": "remove one cyclic triple and add one arbitrary ternary cube",
        "child": {"S": 3, "T": 6, "R": 21},
        "total_children": len(parents) * 7 * len(vectors),
        "best": best,
        "elapsed_seconds": time.perf_counter() - started,
        "parent_results": parent_results,
    }
    rendered = json.dumps(result, indent=2)
    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(rendered + "\n", encoding="utf-8")
    print(rendered)


if __name__ == "__main__":
    main()
