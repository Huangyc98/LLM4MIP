#!/usr/bin/env python3
"""Normalize the upstream author's full R21 MIP start into an exact solution."""

from __future__ import annotations

import argparse
import json
from decimal import Decimal
from pathlib import Path

import gurobipy as gp

from repair_and_audit_incumbent import (
    audit,
    decompressed_sha256,
    exact_decimal_audit,
    exact_integer_audit,
    parse_value_tokens,
    parse_values,
    sha256,
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("author_mst", type=Path)
    parser.add_argument("exact_solution", type=Path)
    parser.add_argument("audit_json", type=Path)
    parser.add_argument("audit_log", type=Path)
    parser.add_argument("--source-commit", required=True)
    parser.add_argument("--source-file-commit", required=True)
    parser.add_argument("--source-git-blob", required=True)
    parser.add_argument("--source-url", required=True)
    args = parser.parse_args()

    source_lines = args.author_mst.read_text(encoding="utf-8").splitlines()
    source_tokens = parse_value_tokens([line + "\n" for line in source_lines])
    source_names = list(source_tokens)
    if len(source_names) != len(set(source_names)):
        raise RuntimeError("the author MST contains duplicate variable names")

    nonintegral_source = {
        name: token
        for name, token in source_tokens.items()
        if Decimal(token) != Decimal(token).to_integral_value()
    }
    if nonintegral_source:
        raise RuntimeError(f"author MST has nonintegral values: {nonintegral_source}")

    solution_lines = [
        "=obj= 2168",
        "# Exact full solution normalized from the upstream author's R21 MIP start.",
        f"# Source: {args.source_url}",
        f"# Source commit: {args.source_commit}",
        f"# Source MST SHA-256: {sha256(args.author_mst)}",
        "# Every source value was already integral; decimal formatting only was normalized.",
    ]
    for name, token in source_tokens.items():
        solution_lines.append(f"{name} {int(Decimal(token))}")
    args.exact_solution.parent.mkdir(parents=True, exist_ok=True)
    args.exact_solution.write_text("\n".join(solution_lines) + "\n", encoding="utf-8")

    exact_lines = args.exact_solution.read_text(encoding="utf-8").splitlines(keepends=True)
    declared, exact_values = parse_values(exact_lines)
    exact_tokens = parse_value_tokens(exact_lines)

    model = gp.read(str(args.mps))
    model.Params.OutputFlag = 0
    model_names = [variable.VarName for variable in model.getVars()]
    missing = sorted(set(model_names) - set(source_names))
    unknown = sorted(set(source_names) - set(model_names))
    duplicates = len(source_names) - len(set(source_names))
    if missing or unknown or duplicates or len(source_names) != model.NumVars:
        raise RuntimeError(
            f"MST/MPS mismatch: missing={len(missing)} unknown={len(unknown)} "
            f"duplicates={duplicates} supplied={len(source_names)} model={model.NumVars}"
        )

    float_audit = audit(model, exact_values)
    decimal_audit = exact_decimal_audit(model, exact_tokens)
    integer_audit = exact_integer_audit(model, exact_values)
    if (
        decimal_audit["violated_constraint_count"]
        or decimal_audit["violated_bound_count"]
        or integer_audit["violated_constraint_count"]
        or integer_audit["violated_bound_count"]
        or declared != 2168
        or float_audit["recomputed_objective_float"] != 2168
    ):
        raise RuntimeError("normalized author solution did not pass strict audit")

    residuals = {
        name: int(value)
        for name, value in exact_values.items()
        if name.startswith("RESIDUAL_") and value != 0
    }
    contribution = float_audit["objective_contributions_by_coefficient"]
    report = {
        "instance": "fastxgemm-n3r21s3t6",
        "result": {
            "strict_feasible_upper_bound": 2168,
            "global_optimality_proved": False,
            "improves_miplib_tolerance_incumbent_4110_99800117485": True,
            "improves_previous_strict_upper_bound_4111": True,
        },
        "provenance": {
            "source_repository": args.source_url,
            "source_commit": args.source_commit,
            "source_file_introduction_commit": args.source_file_commit,
            "source_git_blob": args.source_git_blob,
            "source_path": "instances/fastxgemm-N3-R21-S3-T6.lp.mst",
            "source_mst_sha256": sha256(args.author_mst),
            "source_values_were_already_integral": not nonintegral_source,
            "normalization": "decimal integer tokens such as 1.000000 were written as 1",
        },
        "inputs": {
            "mps": "input/fastxgemm-n3r21s3t6.mps.gz",
            "author_mst": (
                "source/fast-matrix-multiplication/instances/"
                "fastxgemm-N3-R21-S3-T6.lp.mst"
            ),
        },
        "outputs": {"exact_solution": "artifacts/exact_2168.sol"},
        "sha256": {
            "mps_gzip": sha256(args.mps),
            "mps_decompressed": decompressed_sha256(args.mps),
            "source_mst": sha256(args.author_mst),
            "exact_solution": sha256(args.exact_solution),
        },
        "variable_matching": {
            "mps_variable_count": model.NumVars,
            "mst_supplied_variable_count": len(source_names),
            "unique_mst_variable_count": len(set(source_names)),
            "missing_mps_variable_count": len(missing),
            "missing_mps_variables": missing,
            "unknown_mst_variable_count": len(unknown),
            "unknown_mst_variables": unknown,
            "duplicate_mst_variable_count": duplicates,
            "name_sets_match_exactly": not missing and not unknown and not duplicates,
            "mst_order_retained_in_exact_solution": (
                source_names == list(exact_tokens)
            ),
            "mst_order_equals_mps_column_order": source_names == model_names,
            "first_order_difference": next(
                (
                    {
                        "index_zero_based": i,
                        "mst_variable": source_name,
                        "mps_variable": model_name,
                    }
                    for i, (source_name, model_name) in enumerate(
                        zip(source_names, model_names)
                    )
                    if source_name != model_name
                ),
                None,
            ),
        },
        "objective_decomposition": {
            "nonzero_residual_count": len(residuals),
            "residual_sum": sum(residuals.values()),
            "nonzero_residuals": residuals,
            "residual_penalty": int(contribution["1000"]),
            "full_uvw_factor_support": int(contribution["1"]),
            "underlying_abcd_factor_support": int(contribution["1"] // 3),
            "abs_diff_contribution": contribution["0.001"],
            "identity": "1000*2 + 3*56 = 2168",
        },
        "float_matrix_audit": float_audit,
        "exact_decimal_matrix_audit": decimal_audit,
        "exact_integer_matrix_audit": integer_audit,
        "conclusion": (
            "All 18,684 MPS variables are supplied exactly once. The normalized "
            "integral assignment has zero row and bound violations under both exact "
            "decimal and integer-matrix evaluation, and exact objective 2168."
        ),
    }

    args.audit_json.parent.mkdir(parents=True, exist_ok=True)
    args.audit_json.write_text(
        json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )

    log_lines = [
        "fastxgemm-n3r21s3t6 strict 2168 audit",
        "",
        f"Source repository: {args.source_url}",
        f"Source commit: {args.source_commit}",
        f"Source file introduction commit: {args.source_file_commit}",
        f"Source Git blob: {args.source_git_blob}",
        "Source path: instances/fastxgemm-N3-R21-S3-T6.lp.mst",
        f"Source MST SHA-256: {report['sha256']['source_mst']}",
        f"Exact solution SHA-256: {report['sha256']['exact_solution']}",
        f"Official MPS gzip SHA-256: {report['sha256']['mps_gzip']}",
        f"Official MPS decompressed SHA-256: {report['sha256']['mps_decompressed']}",
        "",
        f"MPS variables: {model.NumVars}",
        f"MST values supplied: {len(source_names)}",
        f"Missing MPS variables: {len(missing)}",
        f"Unknown MST variables: {len(unknown)}",
        f"Duplicate MST variables: {duplicates}",
        "Name sets match exactly: yes",
        "MST variable order retained: yes",
        "MST order equals MPS column order: no (order is irrelevant because names match)",
        "",
        "All source MST values are exact integers represented with six decimals.",
        "Normalization changed formatting only; no numerical value was changed.",
        f"Declared/recomputed objective: {declared:g} / "
        f"{float_audit['recomputed_objective_float']:g}",
        f"Floating matrix row violations: {float_audit['violated_rows_gt_1e_12']}",
        f"Floating maximum row violation: {float_audit['max_constraint_violation_float']:.17g}",
        f"Floating bound violations: {float_audit['violated_bounds_gt_1e_12']}",
        f"Exact-decimal row violations: {decimal_audit['violated_constraint_count']}",
        f"Exact-decimal bound violations: {decimal_audit['violated_bound_count']}",
        f"Exact-integer row violations: {integer_audit['violated_constraint_count']}",
        f"Exact-integer bound violations: {integer_audit['violated_bound_count']}",
        "",
        "Objective decomposition:",
        "  residuals: RESIDUAL_0_0_0 = 1, RESIDUAL_4_4_4 = 1",
        "  residual penalty: 1000*2 = 2000",
        "  full U/V/W support: 168 = 3*56",
        "  ABS_DIFF contribution: 0",
        "  exact objective: 2000 + 168 = 2168",
        "",
        "Conclusion: strict feasible upper bound 2168; global optimality remains open.",
    ]
    args.audit_log.parent.mkdir(parents=True, exist_ok=True)
    args.audit_log.write_text("\n".join(log_lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
