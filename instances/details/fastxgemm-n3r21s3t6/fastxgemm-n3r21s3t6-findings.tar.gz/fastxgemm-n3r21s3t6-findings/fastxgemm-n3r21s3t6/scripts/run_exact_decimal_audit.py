#!/usr/bin/env python3
"""Run the repository Decimal MPS checker and preserve a machine-readable audit."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("checker", type=Path)
    parser.add_argument("mps", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--tolerance", default="1e-9")
    args = parser.parse_args()
    args.output_json.parent.mkdir(parents=True, exist_ok=True)

    command = [
        sys.executable,
        str(args.checker),
        str(args.mps),
        str(args.solution),
        "--tolerance",
        args.tolerance,
    ]
    completed = subprocess.run(command, check=False, text=True, capture_output=True)
    stdout = completed.stdout.strip()
    stderr = completed.stderr.strip()

    objective_match = re.search(r"^objective=(\S+)$", stdout, re.MULTILINE)
    row_match = re.search(
        r"^rows=(\d+) exact_row_violations=(\d+) row_violations_above_\S+=(\d+) max_row_violation=(\S+)$",
        stdout,
        re.MULTILINE,
    )
    domain_match = re.search(
        r"^bound_violations_above_\S+=(\d+) exact_integrality_violations=(\d+) "
        r"integrality_violations_above_\S+=(\d+) max_integrality_violation=(\S+)$",
        stdout,
        re.MULTILINE,
    )
    if completed.returncode or not (objective_match and row_match and domain_match):
        raise RuntimeError({"returncode": completed.returncode, "stdout": stdout, "stderr": stderr})

    result = {
        "method": "Repository common/exact_mps_solution_check.py using Decimal arithmetic (precision 80).",
        "checker": str(args.checker),
        "mps": str(args.mps),
        "solution": str(args.solution),
        "sha256": {
            "checker": sha256(args.checker),
            "mps": sha256(args.mps),
            "solution": sha256(args.solution),
        },
        "tolerance": args.tolerance,
        "returncode": completed.returncode,
        "parsed": {
            "objective_decimal": objective_match.group(1),
            "rows": int(row_match.group(1)),
            "exact_row_violations": int(row_match.group(2)),
            "row_violations_above_tolerance": int(row_match.group(3)),
            "max_row_violation_decimal": row_match.group(4),
            "bound_violations_above_tolerance": int(domain_match.group(1)),
            "exact_integrality_violations": int(domain_match.group(2)),
            "integrality_violations_above_tolerance": int(domain_match.group(3)),
            "max_integrality_violation_decimal": domain_match.group(4),
        },
        "stdout": stdout,
        "stderr": stderr,
    }
    if result["parsed"] != {
        "objective_decimal": "2147.000",
        "rows": 219368,
        "exact_row_violations": 0,
        "row_violations_above_tolerance": 0,
        "max_row_violation_decimal": "0",
        "bound_violations_above_tolerance": 0,
        "exact_integrality_violations": 0,
        "integrality_violations_above_tolerance": 0,
        "max_integrality_violation_decimal": "0",
    }:
        raise AssertionError(result["parsed"])
    args.output_json.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result["parsed"], indent=2))


if __name__ == "__main__":
    main()
