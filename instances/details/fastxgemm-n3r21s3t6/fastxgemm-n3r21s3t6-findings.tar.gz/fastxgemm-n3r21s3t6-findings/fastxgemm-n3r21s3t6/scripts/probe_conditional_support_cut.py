#!/usr/bin/env python3
"""Compare LP relaxations of the E=1 diagonal branch with/without the conditional cut."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import gurobipy as gp


def residual_index(name: str) -> tuple[int, int, int]:
    return tuple(map(int, name.removeprefix("RESIDUAL_").split("_")))  # type: ignore[return-value]


def finite(value: float) -> float | None:
    return float(value) if math.isfinite(float(value)) else None


def solve_lp(model: gp.Model, seconds: float, threads: int, log: Path) -> dict:
    relaxed = model.relax()
    relaxed.Params.TimeLimit = seconds
    relaxed.Params.Threads = threads
    relaxed.Params.Presolve = 2
    relaxed.Params.Method = 1
    relaxed.Params.FeasibilityTol = 1e-9
    relaxed.Params.OptimalityTol = 1e-9
    relaxed.Params.LogFile = str(log)
    relaxed.optimize()
    return {
        "status": int(relaxed.Status),
        "runtime_seconds": float(relaxed.Runtime),
        "simplex_iterations": float(relaxed.IterCount),
        "objective": finite(relaxed.ObjVal) if relaxed.SolCount else None,
        "dimensions": {
            "variables": relaxed.NumVars,
            "constraints": relaxed.NumConstrs,
            "nonzeros": relaxed.NumNZs,
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--baseline-log", type=Path, required=True)
    parser.add_argument("--cut-log", type=Path, required=True)
    parser.add_argument("--time-limit", type=float, default=60.0)
    parser.add_argument("--threads", type=int, default=4)
    args = parser.parse_args()
    for path in (args.output_json, args.baseline_log, args.cut_log):
        path.parent.mkdir(parents=True, exist_ok=True)

    base = gp.read(str(args.mps))
    residuals = [v for v in base.getVars() if v.VarName.startswith("RESIDUAL_")]
    diagonal = [v for v in residuals if len(set(residual_index(v.VarName))) == 1]
    diagonal_names = {v.VarName for v in diagonal}
    for variable in residuals:
        if variable.VarName not in diagonal_names:
            variable.UB = 0.0
    base.addConstr(gp.quicksum(diagonal) == 1, name="ACTUAL_ERROR_BRANCH_E1")
    base.update()

    cut_model = base.copy()
    abs_alt = [v for v in cut_model.getVars() if v.VarName.startswith("ABS_ALT_")]
    positive_cut = [
        cut_model.getVarByName(f"RESIDUAL_{x}_{x}_{x}")
        for x in (0, 4, 8)
    ]
    cut_model.addConstr(
        gp.quicksum(abs_alt) + 3 * gp.quicksum(positive_cut) >= 90,
        name="CONDITIONAL_SUPPORT_E_LE_2",
    )
    cut_model.update()

    report = {
        "scope": "LP relaxation only; non-diagonal residuals fixed to zero and diagonal residual sum fixed to one",
        "gurobi_version": ".".join(map(str, gp.gurobi.version())),
        "input_mps": str(args.mps),
        "cut": "sum ABS_ALT + 3*(RESIDUAL_000+RESIDUAL_444+RESIDUAL_888) >= 90",
        "baseline": solve_lp(base, args.time_limit, args.threads, args.baseline_log),
        "with_conditional_cut": solve_lp(cut_model, args.time_limit, args.threads, args.cut_log),
    }
    args.output_json.write_text(
        json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
