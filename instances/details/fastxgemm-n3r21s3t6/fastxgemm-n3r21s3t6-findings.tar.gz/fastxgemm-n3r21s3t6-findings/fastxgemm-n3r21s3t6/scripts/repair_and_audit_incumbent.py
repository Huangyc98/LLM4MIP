#!/usr/bin/env python3
"""Repair MIPLIB's incumbent and audit it as an exact decimal assignment.

The output solution retains the source solution's variable order.  Apart from
the objective metadata, six negative ``RESIDUAL_*`` entries are replaced by
zeroes and three ``VALUE_*`` strings equal to ``0.9999999999999998`` are
normalized to exact ones.  The latter are recorded separately as serialization
normalizations, because leaving them unchanged would retain three violations
of exactly 2e-16 in decimal arithmetic.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
from decimal import Decimal, getcontext
from pathlib import Path

import gurobipy as gp
import numpy as np


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def decompressed_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_values(lines: list[str]) -> tuple[float | None, dict[str, float]]:
    declared = None
    values: dict[str, float] = {}
    for raw in lines:
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        fields = line.split()
        if fields[0].lower() in {"=obj=", "=best=", "=opt="}:
            declared = float(fields[1])
        elif len(fields) >= 2:
            values[fields[0]] = float(fields[1])
    return declared, values


def parse_value_tokens(lines: list[str]) -> dict[str, str]:
    values: dict[str, str] = {}
    for raw in lines:
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        fields = line.split()
        if fields[0].lower() not in {"=obj=", "=best=", "=opt="} and len(fields) >= 2:
            values[fields[0]] = fields[1]
    return values


def exact_decimal_audit(model: gp.Model, value_tokens: dict[str, str]) -> dict:
    """Evaluate every row and bound using the decimal strings in the solution."""
    getcontext().prec = 50
    variables = model.getVars()
    constraints = model.getConstrs()
    matrix = model.getA().tocsr()
    if not np.all(matrix.data == np.rint(matrix.data)):
        return {"applicable": False, "reason": "nonintegral matrix coefficient"}
    rhs_float = np.array([constraint.RHS for constraint in constraints])
    if not np.all(rhs_float == np.rint(rhs_float)):
        return {"applicable": False, "reason": "nonintegral row RHS"}

    decimal_values = [Decimal(value_tokens[variable.VarName]) for variable in variables]
    violated_rows = []
    for row_index, constraint in enumerate(constraints):
        start, end = matrix.indptr[row_index], matrix.indptr[row_index + 1]
        activity = sum(
            Decimal(int(matrix.data[p])) * decimal_values[int(matrix.indices[p])]
            for p in range(start, end)
        )
        rhs = Decimal(int(round(constraint.RHS)))
        if constraint.Sense == "<":
            violation = max(activity - rhs, Decimal(0))
        elif constraint.Sense == ">":
            violation = max(rhs - activity, Decimal(0))
        else:
            violation = abs(activity - rhs)
        if violation > 0:
            violated_rows.append(
                {
                    "row": constraint.ConstrName,
                    "sense": constraint.Sense,
                    "rhs": str(rhs),
                    "activity": str(activity),
                    "violation": str(violation),
                }
            )
    violated_rows.sort(key=lambda item: (-Decimal(item["violation"]), item["row"]))

    violated_bounds = []
    for variable, value in zip(variables, decimal_values):
        lb = Decimal(str(variable.LB))
        ub = Decimal(str(variable.UB))
        violation = max(lb - value, value - ub, Decimal(0))
        if violation > 0:
            violated_bounds.append(
                {
                    "variable": variable.VarName,
                    "value": str(value),
                    "lower_bound": str(lb),
                    "upper_bound": str(ub),
                    "violation": str(violation),
                }
            )
    violated_bounds.sort(key=lambda item: (-Decimal(item["violation"]), item["variable"]))

    objective = sum(
        Decimal(str(variable.Obj)) * value
        for variable, value in zip(variables, decimal_values)
    ) + Decimal(str(model.ObjCon))
    nonintegral = [
        {"variable": variable.VarName, "value": str(value)}
        for variable, value in zip(variables, decimal_values)
        if value != value.to_integral_value()
    ]
    return {
        "applicable": True,
        "recomputed_objective": str(objective),
        "violated_constraint_count": len(violated_rows),
        "violated_constraints": violated_rows,
        "violated_bound_count": len(violated_bounds),
        "violated_bounds": violated_bounds,
        "nonintegral_value_count": len(nonintegral),
        "nonintegral_values": nonintegral,
    }


def audit(model: gp.Model, values: dict[str, float]) -> dict:
    variables = model.getVars()
    constraints = model.getConstrs()
    variable_names = {variable.VarName for variable in variables}
    missing = [variable.VarName for variable in variables if variable.VarName not in values]
    unknown = sorted(set(values) - variable_names)
    x = np.array([values.get(variable.VarName, math.nan) for variable in variables])
    matrix = model.getA().tocsr()
    activity = matrix @ x
    rhs = np.array([constraint.RHS for constraint in constraints])
    senses = np.array([constraint.Sense for constraint in constraints])
    violations = np.where(
        senses == "<",
        np.maximum(activity - rhs, 0.0),
        np.where(senses == ">", np.maximum(rhs - activity, 0.0), np.abs(activity - rhs)),
    )
    lb = np.array([variable.LB for variable in variables])
    ub = np.array([variable.UB for variable in variables])
    bound_violations = np.maximum(np.maximum(lb - x, 0.0), np.maximum(x - ub, 0.0))
    integer_indices = np.array(
        [i for i, variable in enumerate(variables) if variable.VType != gp.GRB.CONTINUOUS]
    )
    integrality_violations = np.abs(x[integer_indices] - np.rint(x[integer_indices]))
    objective = float(np.array([variable.Obj for variable in variables]) @ x + model.ObjCon)

    violated_rows = []
    for i in np.flatnonzero(violations > 1e-12):
        violated_rows.append(
            {
                "row": constraints[int(i)].ConstrName,
                "sense": constraints[int(i)].Sense,
                "rhs": float(rhs[i]),
                "activity": float(activity[i]),
                "violation": float(violations[i]),
            }
        )
    violated_rows.sort(key=lambda item: (-item["violation"], item["row"]))

    violated_bounds = []
    for i in np.flatnonzero(bound_violations > 1e-12):
        violated_bounds.append(
            {
                "variable": variables[int(i)].VarName,
                "value": float(x[i]),
                "lower_bound": float(lb[i]),
                "upper_bound": float(ub[i]),
                "violation": float(bound_violations[i]),
            }
        )
    violated_bounds.sort(key=lambda item: (-item["violation"], item["variable"]))

    residual_values = {
        variable.VarName: float(x[i])
        for i, variable in enumerate(variables)
        if variable.VarName.startswith("RESIDUAL_") and x[i] != 0
    }
    objective_parts: dict[str, float] = {}
    for coefficient in (1000.0, 1.0, 0.001):
        objective_parts[format(coefficient, "g")] = float(
            sum(
                variable.Obj * x[i]
                for i, variable in enumerate(variables)
                if variable.Obj == coefficient
            )
        )

    return {
        "recomputed_objective_float": objective,
        "supplied_variable_count": len(values),
        "missing_variable_count": len(missing),
        "missing_variable_examples": missing[:20],
        "unknown_variable_count": len(unknown),
        "unknown_variable_examples": unknown[:20],
        "max_constraint_violation_float": float(np.max(violations)),
        "violated_rows_gt_1e_12": int(np.sum(violations > 1e-12)),
        "violated_rows_gt_1e_9": int(np.sum(violations > 1e-9)),
        "violated_rows_gt_1e_7": int(np.sum(violations > 1e-7)),
        "violated_rows_gt_1e_6": int(np.sum(violations > 1e-6)),
        "violated_rows": violated_rows,
        "max_bound_violation_float": float(np.max(bound_violations)),
        "violated_bounds_gt_1e_12": int(np.sum(bound_violations > 1e-12)),
        "violated_bounds": violated_bounds,
        "max_integrality_violation_float": float(np.max(integrality_violations)),
        "fractional_integer_variables_gt_1e_12": int(
            np.sum(integrality_violations > 1e-12)
        ),
        "nonintegral_values_all_variables_gt_1e_12": int(
            np.sum(np.abs(x - np.rint(x)) > 1e-12)
        ),
        "objective_contributions_by_coefficient": objective_parts,
        "nonzero_residual_values": residual_values,
    }


def exact_integer_audit(model: gp.Model, values: dict[str, float]) -> dict:
    """Audit feasibility with integer arithmetic when the data are integral."""
    variables = model.getVars()
    constraints = model.getConstrs()
    matrix = model.getA().tocsr()
    x_float = np.array([values[variable.VarName] for variable in variables])
    matrix_integral = bool(np.all(matrix.data == np.rint(matrix.data)))
    rhs_float = np.array([constraint.RHS for constraint in constraints])
    rhs_integral = bool(np.all(rhs_float == np.rint(rhs_float)))
    x_integral = bool(np.all(x_float == np.rint(x_float)))
    if not (matrix_integral and rhs_integral and x_integral):
        return {
            "applicable": False,
            "matrix_integral": matrix_integral,
            "rhs_integral": rhs_integral,
            "solution_integral": x_integral,
        }

    matrix_integer = matrix.astype(np.int64)
    x_integer = np.rint(x_float).astype(np.int64)
    rhs_integer = np.rint(rhs_float).astype(np.int64)
    activity = matrix_integer @ x_integer
    violations = []
    for i, constraint in enumerate(constraints):
        infeasible = (
            (constraint.Sense == "<" and activity[i] > rhs_integer[i])
            or (constraint.Sense == ">" and activity[i] < rhs_integer[i])
            or (constraint.Sense == "=" and activity[i] != rhs_integer[i])
        )
        if infeasible:
            violations.append(
                {
                    "row": constraint.ConstrName,
                    "sense": constraint.Sense,
                    "rhs": int(rhs_integer[i]),
                    "activity": int(activity[i]),
                }
            )

    bound_violations = []
    for i, variable in enumerate(variables):
        if x_integer[i] < variable.LB or x_integer[i] > variable.UB:
            bound_violations.append(
                {
                    "variable": variable.VarName,
                    "value": int(x_integer[i]),
                    "lower_bound": float(variable.LB),
                    "upper_bound": float(variable.UB),
                }
            )
    return {
        "applicable": True,
        "matrix_integral": True,
        "rhs_integral": True,
        "solution_integral": True,
        "violated_constraint_count": len(violations),
        "violated_constraints": violations,
        "violated_bound_count": len(bound_violations),
        "violated_bounds": bound_violations,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("source_solution", type=Path)
    parser.add_argument("exact_solution", type=Path)
    parser.add_argument("audit_json", type=Path)
    parser.add_argument("audit_log", type=Path)
    args = parser.parse_args()

    source_lines = args.source_solution.read_text(encoding="utf-8").splitlines(keepends=True)
    source_declared, source_values = parse_values(source_lines)
    residual_repairs = [
        name
        for name, value in source_values.items()
        if name.startswith("RESIDUAL_") and value < 0
    ]
    decimal_normalizations = [
        name
        for name, value in source_values.items()
        if name.startswith("VALUE_")
        and value != round(value)
        and abs(value - round(value)) <= 1e-12
    ]
    if len(residual_repairs) != 6:
        raise RuntimeError(
            f"expected six negative residuals, found {len(residual_repairs)}"
        )
    if len(decimal_normalizations) != 3:
        raise RuntimeError(
            "expected three near-integral VALUE serializations, found "
            f"{len(decimal_normalizations)}"
        )
    changed = residual_repairs + decimal_normalizations

    repaired_lines = []
    changed_details = []
    for raw in source_lines:
        stripped = raw.strip()
        fields = stripped.split()
        if fields and fields[0].lower() in {"=obj=", "=best=", "=opt="}:
            repaired_lines.append(f"{fields[0]} 4111\n")
        elif stripped.startswith("# Objective value ="):
            repaired_lines.append("# Objective value = 4.1110000000000000e+03\n")
        elif len(fields) >= 2 and fields[0] in residual_repairs:
            changed_details.append(
                {
                    "variable": fields[0],
                    "change_type": "negative_residual_feasibility_repair",
                    "source_value": float(fields[1]),
                    "repaired_value": 0,
                }
            )
            repaired_lines.append(f"{fields[0]} 0\n")
        elif len(fields) >= 2 and fields[0] in decimal_normalizations:
            repaired_value = int(round(float(fields[1])))
            changed_details.append(
                {
                    "variable": fields[0],
                    "change_type": "near_integer_decimal_normalization",
                    "source_value": float(fields[1]),
                    "source_token": fields[1],
                    "repaired_value": repaired_value,
                }
            )
            repaired_lines.append(f"{fields[0]} {repaired_value}\n")
        else:
            repaired_lines.append(raw)

    args.exact_solution.parent.mkdir(parents=True, exist_ok=True)
    args.exact_solution.write_text("".join(repaired_lines), encoding="utf-8")
    repaired_declared, repaired_values = parse_values(repaired_lines)

    model = gp.read(str(args.mps))
    model.Params.OutputFlag = 0
    source_audit = audit(model, source_values)
    repaired_audit = audit(model, repaired_values)
    exact_audit = exact_integer_audit(model, repaired_values)
    source_decimal_audit = exact_decimal_audit(model, parse_value_tokens(source_lines))
    repaired_decimal_audit = exact_decimal_audit(model, parse_value_tokens(repaired_lines))

    positive_residuals = {
        name: value
        for name, value in repaired_audit["nonzero_residual_values"].items()
        if value > 0
    }
    support_contribution = repaired_audit["objective_contributions_by_coefficient"]["1"]
    report = {
        "instance": "fastxgemm-n3r21s3t6",
        "tool": {"gurobi_version": ".".join(map(str, gp.gurobi.version()))},
        "inputs": {
            "mps": "input/fastxgemm-n3r21s3t6.mps.gz",
            "source_solution": "input/fastxgemm-n3r21s3t6-best.sol",
        },
        "outputs": {"exact_solution": "artifacts/exact_4111.sol"},
        "sha256": {
            "mps_gzip": sha256(args.mps),
            "mps_decompressed": decompressed_sha256(args.mps),
            "source_solution": sha256(args.source_solution),
            "exact_solution": sha256(args.exact_solution),
        },
        "model": {
            "variables": model.NumVars,
            "constraints": model.NumConstrs,
            "nonzeros": model.NumNZs,
            "general_integer_variables": model.NumIntVars,
            "binary_variables": model.NumBinVars,
            "continuous_variables": model.NumVars - model.NumIntVars - model.NumBinVars,
        },
        "repair": {
            "source_declared_objective": source_declared,
            "repaired_declared_objective": repaired_declared,
            "changed_variable_count": len(changed_details),
            "negative_residual_repair_count": len(residual_repairs),
            "near_integer_decimal_normalization_count": len(decimal_normalizations),
            "changed_variables": changed_details,
            "variable_order_preserved": list(source_values) == list(repaired_values),
            "unchanged_variable_values_except_listed": all(
                repaired_values[name]
                == (
                    0
                    if name in residual_repairs
                    else round(value)
                    if name in decimal_normalizations
                    else value
                )
                for name, value in source_values.items()
            ),
        },
        "source_solution_audit": source_audit,
        "source_solution_exact_decimal_audit": source_decimal_audit,
        "repaired_solution_audit": repaired_audit,
        "repaired_solution_exact_decimal_audit": repaired_decimal_audit,
        "repaired_solution_exact_integer_audit": exact_audit,
        "exact_objective_decomposition": {
            "positive_residual_count": len(positive_residuals),
            "positive_residual_sum": int(sum(positive_residuals.values())),
            "positive_residuals": positive_residuals,
            "residual_penalty": int(1000 * sum(positive_residuals.values())),
            "factor_support_objective_contribution": int(support_contribution),
            "underlying_factor_support": int(support_contribution // 3),
            "abs_diff_contribution": 0,
            "objective": 4111,
            "identity": "1000*4 + 3*37 = 4111",
        },
        "conclusion": (
            "The repaired 18,684-value assignment is exactly feasible for all integral "
            "rows and bounds, and has exact objective 4111. This is a strict global "
            "upper bound, not an optimality proof."
        ),
    }

    args.audit_json.parent.mkdir(parents=True, exist_ok=True)
    args.audit_json.write_text(
        json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )

    source_rows = source_decimal_audit["violated_constraints"]
    source_bounds = source_decimal_audit["violated_bounds"]
    log_lines = [
        "fastxgemm-n3r21s3t6 strict feasibility audit",
        "",
        f"MPS: input/fastxgemm-n3r21s3t6.mps.gz",
        f"Source solution: input/fastxgemm-n3r21s3t6-best.sol",
        f"Repaired solution: artifacts/exact_4111.sol",
        "",
        f"Source declared/recomputed objective: {source_declared!r} / "
        f"{source_audit['recomputed_objective_float']!r}",
        f"Source maximum floating row violation: "
        f"{source_audit['max_constraint_violation_float']:.17g}",
        f"Source exact-decimal violated rows (>0): {len(source_rows)}",
    ]
    for row in source_rows:
        log_lines.append(
            "  {row}: sense={sense} rhs={rhs} activity={activity} "
            "violation={violation}".format(**row)
        )
    log_lines.append(f"Source exact-decimal violated bounds (>0): {len(source_bounds)}")
    for item in source_bounds:
        log_lines.append(
            "  {variable}: value={value} lb={lower_bound} "
            "ub={upper_bound} violation={violation}".format(**item)
        )
    log_lines.extend(
        [
            "",
            "Changed variable values (and no others):",
            "  Six negative residuals are feasibility repairs; three VALUE edits are",
            "  near-integer decimal normalizations required for literal zero violation.",
        ]
    )
    for item in changed_details:
        log_lines.append(
            f"  {item['variable']} [{item['change_type']}]: "
            f"{item['source_value']:.17g} -> {item['repaired_value']}"
        )
    log_lines.extend(
        [
            "",
            f"Repaired declared/recomputed objective: {repaired_declared!r} / "
            f"{repaired_audit['recomputed_objective_float']!r}",
            f"Repaired maximum floating row violation: "
            f"{repaired_audit['max_constraint_violation_float']:.17g}",
            f"Repaired violated rows (>1e-12): "
            f"{repaired_audit['violated_rows_gt_1e_12']}",
            f"Repaired maximum bound violation: "
            f"{repaired_audit['max_bound_violation_float']:.17g}",
            f"Repaired maximum integrality violation: "
            f"{repaired_audit['max_integrality_violation_float']:.17g}",
            f"Exact integer row violations: {exact_audit['violated_constraint_count']}",
            f"Exact integer bound violations: {exact_audit['violated_bound_count']}",
            "Exact decimal row violations: "
            f"{repaired_decimal_audit['violated_constraint_count']}",
            "Exact decimal bound violations: "
            f"{repaired_decimal_audit['violated_bound_count']}",
            "Exact objective: 1000*4 + 3*37 = 4111",
            "Conclusion: strict feasible upper bound 4111; no global optimality claim.",
            "",
            "SHA-256:",
            f"  MPS gzip: {report['sha256']['mps_gzip']}",
            f"  MPS decompressed: {report['sha256']['mps_decompressed']}",
            f"  source solution: {report['sha256']['source_solution']}",
            f"  exact solution: {report['sha256']['exact_solution']}",
        ]
    )
    args.audit_log.parent.mkdir(parents=True, exist_ok=True)
    args.audit_log.write_text("\n".join(log_lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
