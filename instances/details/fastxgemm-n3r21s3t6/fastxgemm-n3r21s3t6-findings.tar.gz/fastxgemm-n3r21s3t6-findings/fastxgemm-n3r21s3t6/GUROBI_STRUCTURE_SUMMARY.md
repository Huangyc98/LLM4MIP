# `fastxgemm-n3r21s3t6`: Gurobi structure and search audit

Initial structure audit: 2026-09-08
Current bounds refresh: 2026-09-09

## Current headline

```text
93 <= OPT <= 2147
```

UB 2147 is a strictly verified external-derived BILR truncation and is not a
project/GPT primal contribution. LB93 is a project mathematical proof. The
older Sorber 2168 start and LB90 artifacts remain useful historical evidence,
but they are no longer the current bounds.

## Input and model structure

- Official MPS: `input/fastxgemm-n3r21s3t6.mps.gz`, SHA-256
  `210E76E09285AB346C1AE92155D5FC88EFEEAAFE96A4B5944B54011FA0103FBA`.
- Original model: 18,684 variables, 219,368 rows, 718,146 nonzeros.
- Integer core: 378 bounded integer indicators encoding 189 ternary entries in
  the cyclic `[A B C D]` core; all other variables are continuous auxiliaries.
- Main continuous families include 15,309 `VALUE`, 729 `RESIDUAL`, and the
  factor/absolute-value variables.
- The integral-pattern objective is

  ```text
  1000*E + 3*K,
  ```

  where `E` is integer tensor L1 error and `K` is underlying cyclic-core
  support.
- The official decomposition has 21 term blocks plus a master coupling the
  tensor reconstruction, sign links, support variables, and residuals.

Detailed counts and row signatures are in `artifacts/gurobi-structure-audit.json`.

## Incumbent history and current upper bound

The public MIPLIB floating solution repairs to strict objective 4111. Laurent
Sorber's 2017 start is strictly feasible at 2168 (`E=2,K=56`); it is archived
as an external historical baseline.

The current 2147 pattern deletes the two singleton fixed-A terms from the
external BILR 2018 `S_Lader-Z3` exact R23 decomposition:

```text
E=2, K=49, raw factor support=147, objective=2147.
```

Its only tensor errors are `(4,4,4)` and `(8,8,8)`. Gurobi completes the fixed
integer pattern on the official MPS, and an independent Decimal checker replays
all 219,368 rows with zero row, bound, or integrality violation. See
`solutions/external-bilr-derived-strict-2147.sol` and the
`artifacts/bilr_*_2147.json` audits.

The fixed-pattern status `OPTIMAL` concerns only the continuous completion and
does not prove the complete MIP optimal.

## Current lower-bound row

The current globally integer-valid inequality is

```text
sum(567 ABS_ALT variables) + 9*sum(729 RESIDUAL variables) >= 93.
```

The proof excludes exact `K=30`, so exact patterns have support at least 93.
For an inexact integer pattern, the official support floor 84 plus residual
sum at least 1 also makes the row valid. Re-reading the augmented MPS confirms
567 coefficients 1, 729 coefficients 9, RHS93, and no new variables. Its LP
optimum and root bound are both 93.

The proof is in `artifacts/LB93_PROOF.md`. Direct finite classification checks
all 84 high-row sets; an independent solver-free bitmask DP checks 12 symmetry
representatives covering all 84, with none reachable. The older
`support+6E>=90` model is retained only as an earlier valid but dominated cut.

## Search results and exact scope

Around the current 2147 core:

- all 413,343 single-complete-vector replacements: no improvement;
- coefficient Hamming radius 1/2: no improvement;
- arbitrary deletion/re-signing on the same 49 support locations with
  objective `<=2146`: complete Gurobi `INFEASIBLE`;
- the same freedom plus at most one of 140 new locations: no solution in
  300 seconds / 47,178 nodes, but status `TIME_LIMIT`, hence unresolved;
- 4,800 fixed-A deletions across 480 bounded ternary conjugates: best 2147.

Historical searches around Sorber 2168 are preserved under their original
artifact names. They remain valid statements about that older neighborhood but
must not be read as searches around the current incumbent.

Any strict improvement over 2147 must satisfy one of:

```text
E=0, with any K allowed below the objective cap;
E=1, with any model-domain K (the arithmetic cap 382 exceeds K<=189);
E=2, with K<=48.
```

Because error 3 already costs 3000, no `E>=3` pattern can improve 2147.

## Recommended next exact approach

For a better UB, enlarge support-expansion searches to at least two new
locations, replace multiple vectors/orbits jointly, or explore gauge transforms
outside the audited small coefficient box. For a better LB, K31 is feasible
only in the current support relaxation—not as an exact tensor decomposition—so
new constraints must encode sign compatibility or direct tensor equations.

## Reproduction entry points

- `REPRODUCE.md`
- `scripts/complete_external_r21_candidate.py`
- `scripts/classify_k30_high_sets.py`
- `scripts/dp_verify_k30_support_symmetry.py`
- `scripts/build_and_probe_lb93.py`
- `result_summary.json`
