# `fastxgemm-n3r21s3t6`

Continuation date: **2026-09-09**.

## Strict result

```text
93 <= OPT <= 2147
```

Both endpoints improve the previous project interval `[90,2168]`, but their
provenance differs:

- **UB 2147 is external-derived and counts as a project primal
  improvement based on external work (counting policy updated 2026-09-16).** Delete the two singleton fixed-A terms from the BILR 2018
  cyclic rank-23 `S_Lader-Z3` construction. The child has `E=2`, `K=49`, raw
  factor support 147, and objective `2000+147=2147`.
- **LB 93 is a new project theorem.** The proof excludes exact `K=30`, so an
  exact R21 construction has `K>=31`. Together with the inexact branch it gives
  the globally integer-valid cut

  ```text
  sum(ABS_ALT) + 9*sum(RESIDUAL) >= 93.
  ```

The problem remains open. A fixed-pattern Gurobi status `OPTIMAL` certifies
only the completion of that external-derived factor pattern, not the global
MIP.

## Verification

The 2147 pattern was completed on the unmodified official MPS. An independent
Decimal replay checked all 219,368 rows exactly; row, bound, and integrality
violations are all zero. The semantic cross-check has zero mismatch with the
official formulation, and an independent tensor expansion confirms `E=2`: the
only tensor errors are the two missing diagonal unit entries `(4,4,4)` and
`(8,8,8)`.

The LB proof is independently audited twice: direct classification checks all
`C(9,3)=84` high-row sets, and a solver-free bitmask dynamic program checks 12
symmetry representatives covering all 84 sets. All representatives are
unreachable. The augmented official MPS has LP optimum and root bound 93.

## Scoped negative searches

No improvement was found by all single-vector replacements, coefficient
Hamming radius 1/2, or the 4,800 bounded-conjugation fixed-A truncations. On
the same 49 support locations, arbitrary deletion/re-signing with objective
at most 2146 is completely `INFEASIBLE`. Allowing at most one new support
location ended at `TIME_LIMIT` after 300 seconds and is explicitly unresolved.

## Main files

- [Full report](REPORT.md) and [reproduction guide](REPRODUCE.md)
- [External-derived strict solution 2147](solutions/external-bilr-derived-strict-2147.sol)
- [LB93 proof](artifacts/LB93_PROOF.md)
- [Solver-free DP audit](artifacts/dp_verify_k30_support_symmetry.json)
- [Direct finite classification](artifacts/classify_k30_high_sets.json)
- [Official-MPS cut probe](artifacts/gurobi-lb93-probe.json)
- [Machine-readable summary](result_summary.json)

`3K` is raw factor support, not the optimized CSE/SLP addition count.
