# Package manifest: dws012-02

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 28
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/alternate/audit.json`
- `artifacts/anonymous_blocks.json`
- `artifacts/dws012_block_audit.json`
- `artifacts/dws012_dec_audit.json`
- `artifacts/public_solution_audit.json`
- `artifacts/relaxations/results.json`
- `artifacts/relaxations/upper_solution_audit.json`
- `artifacts/sibling_design_comparison.json`
- `artifacts/transplant/audit.json`
- `artifacts/transplant/independent_audit.json`
- `input/dws012-02.dec`
- `input/dws012-02.presolved.dec`
- `logs/effort_ledger.md`
- `reports/final_report.md`
- `scripts/audit_dws012_blocks.py`
- `scripts/compare_sibling_design.py`
- `scripts/dws012_alternate.py`
- `scripts/dws012_dec_audit.py`
- `scripts/dws012_relaxations.py`
- `scripts/dws012_transplant.py`
- `scripts/recover_anonymous_blocks.py`
- `solutions/dws012-02-public.sol.gz`
- `solutions/new_primal_119443.31072434435.sol`
- `sources/background_and_sources.md`
- `structure/structure-summary.md`
- `structure/structure.compact.json`
- `structure/structure.json`

## Excluded files

- `input/dws012-02.mps.gz (1639122 bytes; raw benchmark input; sha256 aec69cb2fa916183f17b6537bac60c8b1bcd84169b5d93da812f2d4806c66d66)`
