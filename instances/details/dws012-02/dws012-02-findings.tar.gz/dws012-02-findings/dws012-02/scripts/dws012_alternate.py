#!/usr/bin/env python3
"""
dws012-02 alternating design/recourse experiment.

This is a model-derived coordinate method, not a parameter sweep.

For each supplied validated solution:
  1. Fix every non-design variable and optimize the 264 objective-supported
     integer variables.
  2. Validate the resulting full vector on the original MPS.
  3. Fix the best design, release all other variables, and search for a
     strictly better recourse solution.
  4. Repeat a small number of alternating rounds until no accepted
     improvement remains or the total budget is exhausted.

The design variables are identified structurally as all integer variables with
nonzero objective coefficient. Their ordering is the original MPS column
ordering restricted to that set.

Usage:
    python dws012_alternate.py \
      --mps dws012-02.mps.gz \
      --official-sol dws012-02.sol.gz \
      --improved-sol artifacts/dws012_transplant/best.sol \
      --out-dir artifacts/dws012_alternate \
      --total-time-limit 900 \
      --per-solve-limit 120 \
      --max-rounds 4

No result is treated as globally optimal. Conditional solver bounds are
reported separately from validated incumbent objectives.
"""

import argparse
import collections
import hashlib
import gzip
import json
import math
import os
import time

import gurobipy as gp


# ---------------------------------------------------------------------------
# Input and basic utilities
# ---------------------------------------------------------------------------

def open_text(path):
    if path.endswith(".gz"):
        return gzip.open(path, "rt", errors="replace")
    return open(path, "rt", errors="replace")


def read_solution(path):
    values = {}

    with open_text(path) as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("<") or line.startswith(">"):
                continue

            fields = line.split()
            if len(fields) < 2:
                continue

            try:
                value = float(fields[1])
            except Exception:
                continue

            name = fields[0]
            if name.lower() in {
                "objective",
                "objective_value",
                "status",
                "solution",
                "solution_status",
                "solstatus",
            }:
                continue

            values[name] = value

    return values


def canon_float(x):
    x = float(x)
    if x == 0.0:
        return "0"
    return format(x, ".17g")


def digest(value):
    return hashlib.sha1(repr(value).encode("utf-8")).hexdigest()[:16]


def load_model(path):
    model = gp.read(path)
    model.update()
    return model


def read_vector(model, solution):
    x = [0.0] * model.NumVars
    recognized = 0

    for v in model.getVars():
        if v.VarName in solution:
            x[v.index] = solution[v.VarName]
            recognized += 1

    return x, recognized


def write_solution(path, model, x):
    with open(path, "w") as f:
        f.write("# dws012-02 alternating research solution\n")
        for v in model.getVars():
            value = float(x[v.index])
            if abs(value) > 1e-12:
                f.write("{} {:.17g}\n".format(v.VarName, value))


# ---------------------------------------------------------------------------
# Structural model extraction
# ---------------------------------------------------------------------------

def identify_design_variables(model):
    """
    Design layer:
      * integer or binary;
      * nonzero objective coefficient.

    The experiment refuses to continue unless this recovers exactly 264
    variables, matching the established structural audit.
    """
    design = [
        v for v in model.getVars()
        if v.VType in ("B", "I") and abs(float(v.Obj)) > 0.0
    ]

    if len(design) != 264:
        raise RuntimeError(
            "Expected 264 objective-supported integer design variables; "
            "recovered {}".format(len(design))
        )

    return design


def extract_rows(model):
    rows = []

    for i, con in enumerate(model.getConstrs()):
        expr = model.getRow(con)
        entries = []

        for k in range(expr.size()):
            v = expr.getVar(k)
            entries.append((v.index, float(expr.getCoeff(k))))

        entries.sort()

        rows.append({
            "index": i,
            "name": con.ConstrName,
            "sense": con.Sense,
            "rhs": float(con.RHS),
            "entries": entries,
        })

    return rows


def validate_vector(model, x, tolerance):
    max_integrality = 0.0
    max_bound = 0.0
    max_row = 0.0
    bad_rows = []

    for v in model.getVars():
        value = float(x[v.index])

        if v.VType in ("B", "I"):
            max_integrality = max(
                max_integrality,
                abs(value - round(value)),
            )

        max_bound = max(
            max_bound,
            max(float(v.LB) - value, 0.0),
            value - float(v.UB),
        )

    for row in extract_rows(model):
        activity = sum(
            coefficient * x[column]
            for column, coefficient in row["entries"]
        )
        residual = activity - row["rhs"]

        if row["sense"] == "=":
            violation = abs(residual)
        elif row["sense"] == "<":
            violation = max(residual, 0.0)
        else:
            violation = max(-residual, 0.0)

        max_row = max(max_row, violation)

        if violation > tolerance and len(bad_rows) < 30:
            bad_rows.append({
                "row_index": row["index"],
                "row_name": row["name"],
                "sense": row["sense"],
                "rhs": row["rhs"],
                "activity": activity,
                "residual": residual,
                "violation": violation,
            })

    objective = sum(
        float(v.Obj) * x[v.index]
        for v in model.getVars()
    )

    return {
        "objective": objective,
        "max_integrality_violation": max_integrality,
        "max_bound_violation": max_bound,
        "max_row_violation": max_row,
        "accepted_at_tolerance": (
            max_integrality <= tolerance
            and max_bound <= tolerance
            and max_row <= tolerance
        ),
        "bad_row_examples": bad_rows,
    }


def design_pattern(design_vars, x):
    return tuple(
        1 if x[v.index] >= 0.5 else 0
        for v in design_vars
    )


def design_positions(pattern):
    return [
        position + 1
        for position, value in enumerate(pattern)
        if value
    ]


def design_differences(old_pattern, new_pattern):
    return [
        {
            "position": position + 1,
            "old": int(old_pattern[position]),
            "new": int(new_pattern[position]),
        }
        for position in range(len(old_pattern))
        if old_pattern[position] != new_pattern[position]
    ]


# ---------------------------------------------------------------------------
# Exact design-incident row family audit
# ---------------------------------------------------------------------------

def row_family(row, design_set):
    """
    Exact family key for rows affected by the design layer.

    This retains:
      * row sense;
      * RHS;
      * total row degree;
      * ordered design coefficient list;
      * ordered non-design coefficient list.

    The complete key is exact for the current MPS row representation. A
    secondary compact family key is also emitted for aggregation.
    """
    design_terms = tuple(
        (column, canon_float(coefficient))
        for column, coefficient in row["entries"]
        if column in design_set
    )

    compact_design_terms = tuple(
        canon_float(coefficient)
        for column, coefficient in row["entries"]
        if column in design_set
    )

    compact = (
        row["sense"],
        canon_float(row["rhs"]),
        len(row["entries"]),
        len(design_terms),
        compact_design_terms,
    )

    exact = (
        row["sense"],
        canon_float(row["rhs"]),
        len(row["entries"]),
        design_terms,
        tuple(
            (column, canon_float(coefficient))
            for column, coefficient in row["entries"]
            if column not in design_set
        ),
    )

    return exact, compact


def build_design_row_audit(model, rows, design_vars, x):
    design_set = {v.index for v in design_vars}
    families = collections.defaultdict(list)
    compact_families = collections.defaultdict(list)
    incident_rows = []

    for row in rows:
        exact, compact = row_family(row, design_set)
        design_terms = [
            (column, coefficient)
            for column, coefficient in row["entries"]
            if column in design_set
        ]

        if not design_terms:
            continue

        incident_rows.append(row["index"])
        families[exact].append(row)
        compact_families[compact].append(row)

    family_records = []

    for key, group in compact_families.items():
        representative = group[0]
        design_terms = [
            {
                "column": column,
                "coefficient": coefficient,
            }
            for column, coefficient in representative["entries"]
            if column in design_set
        ]

        family_records.append({
            "family_digest": digest(key),
            "count": len(group),
            "sense": representative["sense"],
            "rhs": representative["rhs"],
            "row_degree": len(representative["entries"]),
            "design_term_count": len(design_terms),
            "design_terms_sample": design_terms[:20],
            "row_names_sample": [
                row["name"] for row in group[:20]
            ],
        })

    family_records.sort(
        key=lambda record: (-record["count"], record["family_digest"])
    )

    # Residuals of every design-incident row under the supplied operation
    # vector. This identifies rows that are close to an active bound and
    # therefore likely to reject a design exchange.
    residual_records = []

    for row in rows:
        if not any(column in design_set for column, coefficient in row["entries"]):
            continue

        activity = sum(
            coefficient * x[column]
            for column, coefficient in row["entries"]
        )
        residual = activity - row["rhs"]

        if row["sense"] == "=":
            slack = abs(residual)
        elif row["sense"] == "<":
            slack = row["rhs"] - activity
        else:
            slack = activity - row["rhs"]

        exact, compact = row_family(row, design_set)

        residual_records.append({
            "row_index": row["index"],
            "row_name": row["name"],
            "sense": row["sense"],
            "rhs": row["rhs"],
            "activity": activity,
            "signed_residual": residual,
            "slack_in_feasibility_direction": slack,
            "family_digest": digest(compact),
            "near_active_at_1e-7": abs(slack) <= 1e-7,
            "near_active_at_1e-5": abs(slack) <= 1e-5,
        })

    residual_records.sort(
        key=lambda record: (
            abs(record["slack_in_feasibility_direction"]),
            record["row_index"],
        )
    )

    return {
        "design_incident_row_count": len(incident_rows),
        "exact_family_count": len(families),
        "compact_family_count": len(compact_families),
        "family_counts": family_records[:200],
        "closest_design_incident_rows": residual_records[:200],
        "rows": rows,
    }


def evaluate_hamming2_exchanges(rows, design_vars, base_x, base_pattern,
                                tolerance, max_examples=40):
    """
    Evaluate all cardinality-preserving one-for-one exchanges against fixed
    operations.

    This does not optimize. It calculates the exact row activity change caused
    by each design exchange while retaining every non-design variable from
    base_x.
    """
    design_set = {v.index for v in design_vars}
    selected = [
        position for position, value in enumerate(base_pattern)
        if value == 1
    ]
    unselected = [
        position for position, value in enumerate(base_pattern)
        if value == 0
    ]

    base_activities = []
    base_slacks = []

    for row in rows:
        activity = sum(
            coefficient * base_x[column]
            for column, coefficient in row["entries"]
        )
        base_activities.append(activity)

        if row["sense"] == "=":
            slack = abs(activity - row["rhs"])
        elif row["sense"] == "<":
            slack = row["rhs"] - activity
        else:
            slack = activity - row["rhs"]

        base_slacks.append(slack)

    tested = 0
    feasible = 0
    infeasible = 0
    infeasible_by_family = collections.defaultdict(lambda: {
        "count": 0,
        "row_names": [],
        "worst_violation": 0.0,
        "example_exchange": None,
    })

    best_margin = []
    family_lookup = {}

    for row in rows:
        if not any(column in design_set for column, coefficient in row["entries"]):
            continue
        exact, compact = row_family(row, design_set)
        family_lookup[row["index"]] = compact

    for off_position in selected:
        for on_position in unselected:
            tested += 1

            off_column = design_vars[off_position].index
            on_column = design_vars[on_position].index

            delta_by_row = collections.defaultdict(float)

            for row in rows:
                contribution = 0.0
                for column, coefficient in row["entries"]:
                    if column == off_column:
                        contribution -= coefficient
                    elif column == on_column:
                        contribution += coefficient

                if contribution != 0.0:
                    delta_by_row[row["index"]] = contribution

            worst_violation = 0.0
            responsible = []

            for row_index, delta in delta_by_row.items():
                row = rows[row_index]
                new_activity = base_activities[row_index] + delta

                if row["sense"] == "=":
                    violation = abs(new_activity - row["rhs"])
                elif row["sense"] == "<":
                    violation = max(new_activity - row["rhs"], 0.0)
                else:
                    violation = max(row["rhs"] - new_activity, 0.0)

                if violation > tolerance:
                    worst_violation = max(worst_violation, violation)
                    compact = family_lookup.get(row_index, ("unclassified",))
                    rec = infeasible_by_family[compact]
                    rec["count"] += 1
                    rec["worst_violation"] = max(
                        rec["worst_violation"], violation
                    )
                    if len(rec["row_names"]) < max_examples:
                        rec["row_names"].append(row["name"])
                    if rec["example_exchange"] is None:
                        rec["example_exchange"] = {
                            "off_position": off_position + 1,
                            "on_position": on_position + 1,
                            "row_index": row_index,
                            "row_name": row["name"],
                            "violation": violation,
                            "delta": delta,
                        }
                    responsible.append({
                        "row_index": row_index,
                        "row_name": row["name"],
                        "violation": violation,
                    })

            if worst_violation <= tolerance:
                feasible += 1
            else:
                infeasible += 1

            if len(best_margin) < max_examples:
                best_margin.append({
                    "off_position": off_position + 1,
                    "on_position": on_position + 1,
                    "worst_violation": worst_violation,
                    "responsible_rows": responsible[:10],
                })
            else:
                current_max = max(
                    x["worst_violation"] for x in best_margin
                )
                if worst_violation < current_max:
                    worst_item = max(
                        best_margin,
                        key=lambda x: x["worst_violation"]
                    )
                    best_margin.remove(worst_item)
                    best_margin.append({
                        "off_position": off_position + 1,
                        "on_position": on_position + 1,
                        "worst_violation": worst_violation,
                        "responsible_rows": responsible[:10],
                    })

    family_output = []
    for family, record in sorted(
        infeasible_by_family.items(),
        key=lambda item: (-item[1]["count"], repr(item[0]))
    ):
        family_output.append({
            "family_digest": digest(family),
            **record,
        })

    return {
        "selected_count": len(selected),
        "unselected_count": len(unselected),
        "total_exchanges_tested": tested,
        "fixed_operation_feasible_exchanges": feasible,
        "fixed_operation_infeasible_exchanges": infeasible,
        "infeasible_exchange_family_summary": family_output[:200],
        "least_violating_exchange_examples": sorted(
            best_margin,
            key=lambda x: x["worst_violation"]
        ),
    }


# ---------------------------------------------------------------------------
# Conditional optimization
# ---------------------------------------------------------------------------

def set_warm_start(model, x):
    for v in model.getVars():
        v.Start = float(x[v.index])


def optimize_design_given_operations(
    model,
    design_vars,
    base_x,
    tolerance,
    time_limit,
):
    """
    Fix every non-design variable and optimize only the design layer.
    """
    design_set = {v.index for v in design_vars}
    saved = []

    try:
        for v in model.getVars():
            if v.index in design_set:
                saved.append((v, float(v.LB), float(v.UB)))
            else:
                saved.append((v, float(v.LB), float(v.UB)))
                value = float(base_x[v.index])
                v.LB = value
                v.UB = value

        set_warm_start(model, base_x)
        model.Params.OutputFlag = 0
        model.Params.TimeLimit = max(0.0, time_limit)
        # Search the entire restricted design problem.  SolutionLimit=1 in
        # the API draft contradicted the requested restricted-optimality test
        # by stopping at the warm start.
        model.Params.SolutionLimit = 2_000_000_000
        model.Params.Cutoff = gp.GRB.INFINITY
        model.update()

        started = time.monotonic()
        model.optimize()
        runtime = time.monotonic() - started

        result = {
            "operation": "design_given_operations",
            "status_code": int(model.Status),
            "status": {
                gp.GRB.OPTIMAL: "optimal",
                gp.GRB.TIME_LIMIT: "time_limit",
                gp.GRB.INFEASIBLE: "infeasible",
                gp.GRB.SUBOPTIMAL: "suboptimal",
                gp.GRB.INTERRUPTED: "interrupted",
            }.get(model.Status, "other"),
            "runtime": runtime,
            "solution_count": int(model.SolCount),
            "objective": None,
            "conditional_bound": None,
            "mip_gap": None,
            "vector": None,
        }

        try:
            result["conditional_bound"] = float(model.ObjBound)
        except Exception:
            pass

        try:
            if model.MIPGap < 1e100:
                result["mip_gap"] = float(model.MIPGap)
        except Exception:
            pass

        if model.SolCount > 0:
            result["objective"] = float(model.ObjVal)
            result["vector"] = [
                float(v.X) for v in model.getVars()
            ]

        return result

    finally:
        for v, lb, ub in saved:
            v.LB = lb
            v.UB = ub
        model.update()


def optimize_recours_given_design(
    model,
    design_vars,
    design_pattern,
    incumbent_x,
    incumbent_objective,
    tolerance,
    time_limit,
):
    """
    Fix all design variables and release all other variables.

    The objective cutoff is strict relative to the current validated
    incumbent. A returned vector is still independently checked afterward.
    """
    saved = []

    try:
        for v in model.getVars():
            saved.append((v, float(v.LB), float(v.UB)))

        for p, v in enumerate(design_vars):
            value = float(design_pattern[p])
            v.LB = value
            v.UB = value

        set_warm_start(model, incumbent_x)

        # Strict improvement cutoff. The small subtraction is only a solver
        # feasibility margin; acceptance is decided by raw-MPS validation.
        cutoff = incumbent_objective - max(tolerance, 1e-7)
        model.Params.Cutoff = cutoff
        model.Params.OutputFlag = 0
        model.Params.TimeLimit = max(0.0, time_limit)
        # Gurobi's minimum valid SolutionLimit is 1; use the effective maximum
        # so the recourse phase can keep improving until its time limit.
        model.Params.SolutionLimit = 2_000_000_000
        model.update()

        started = time.monotonic()
        model.optimize()
        runtime = time.monotonic() - started

        result = {
            "operation": "recourse_given_design",
            "status_code": int(model.Status),
            "status": {
                gp.GRB.OPTIMAL: "optimal",
                gp.GRB.TIME_LIMIT: "time_limit",
                gp.GRB.INFEASIBLE: "infeasible",
                gp.GRB.SUBOPTIMAL: "suboptimal",
                gp.GRB.INTERRUPTED: "interrupted",
            }.get(model.Status, "other"),
            "runtime": runtime,
            "solution_count": int(model.SolCount),
            "objective": None,
            "conditional_bound": None,
            "mip_gap": None,
            "vector": None,
            "cutoff": cutoff,
        }

        try:
            result["conditional_bound"] = float(model.ObjBound)
        except Exception:
            pass

        try:
            if model.MIPGap < 1e100:
                result["mip_gap"] = float(model.MIPGap)
        except Exception:
            pass

        if model.SolCount > 0:
            result["objective"] = float(model.ObjVal)
            result["vector"] = [
                float(v.X) for v in model.getVars()
            ]

        return result

    finally:
        for v, lb, ub in saved:
            v.LB = lb
            v.UB = ub

        model.Params.Cutoff = gp.GRB.INFINITY
        model.update()


def accepted_candidate(model, candidate, incumbent_objective, tolerance):
    if candidate is None or candidate.get("vector") is None:
        return None

    x = candidate["vector"]
    audit = validate_vector(model, x, tolerance)

    if not audit["accepted_at_tolerance"]:
        return {
            "accepted": False,
            "reason": "raw_mps_validation_failed",
            "audit": audit,
        }

    if audit["objective"] >= incumbent_objective - tolerance:
        return {
            "accepted": False,
            "reason": "not_strictly_better",
            "audit": audit,
        }

    return {
        "accepted": True,
        "audit": audit,
        "vector": x,
    }


# ---------------------------------------------------------------------------
# Alternating loop
# ---------------------------------------------------------------------------

def run_alternation(
    model,
    rows,
    design_vars,
    initial_x,
    label,
    total_deadline,
    per_solve_limit,
    max_rounds,
    tolerance,
):
    current_x = list(initial_x)
    current_audit = validate_vector(model, current_x, tolerance)

    if not current_audit["accepted_at_tolerance"]:
        raise RuntimeError(
            "{} is not feasible on the original MPS".format(label)
        )

    current_pattern = design_pattern(design_vars, current_x)
    records = []
    accepted_rounds = 0

    for round_index in range(1, max_rounds + 1):
        if time.monotonic() >= total_deadline:
            break

        remaining = total_deadline - time.monotonic()
        limit = min(per_solve_limit, remaining)

        design_result = optimize_design_given_operations(
            model=model,
            design_vars=design_vars,
            base_x=current_x,
            tolerance=tolerance,
            time_limit=limit,
        )

        round_record = {
            "round": round_index,
            "starting_objective": current_audit["objective"],
            "starting_design_positions": design_positions(
                current_pattern
            ),
            "design_step": {
                k: v for k, v in design_result.items()
                if k != "vector"
            },
            "accepted_steps": [],
        }

        design_acceptance = accepted_candidate(
            model,
            design_result,
            current_audit["objective"],
            tolerance,
        )

        if design_acceptance is not None and design_acceptance["accepted"]:
            current_x = list(design_acceptance["vector"])
            current_audit = design_acceptance["audit"]
            current_pattern = design_pattern(design_vars, current_x)
            accepted_rounds += 1

            round_record["accepted_steps"].append({
                "type": "design",
                "objective": current_audit["objective"],
                "design_positions": design_positions(current_pattern),
                "differences_from_previous": design_differences(
                    round_record["starting_design_positions"],
                    design_positions(current_pattern),
                ),
            })

        if time.monotonic() >= total_deadline:
            records.append(round_record)
            break

        remaining = total_deadline - time.monotonic()
        limit = min(per_solve_limit, remaining)

        recourse_result = optimize_recours_given_design(
            model=model,
            design_vars=design_vars,
            design_pattern=current_pattern,
            incumbent_x=current_x,
            incumbent_objective=current_audit["objective"],
            tolerance=tolerance,
            time_limit=limit,
        )

        round_record["recourse_step"] = {
            k: v for k, v in recourse_result.items()
            if k != "vector"
        }

        recourse_acceptance = accepted_candidate(
            model,
            recourse_result,
            current_audit["objective"],
            tolerance,
        )

        improved_this_round = False

        if recourse_acceptance is not None and recourse_acceptance["accepted"]:
            previous_pattern = current_pattern
            current_x = list(recourse_acceptance["vector"])
            current_audit = recourse_acceptance["audit"]
            current_pattern = design_pattern(design_vars, current_x)
            accepted_rounds += 1
            improved_this_round = True

            round_record["accepted_steps"].append({
                "type": "recourse",
                "objective": current_audit["objective"],
                "design_positions": design_positions(current_pattern),
                "differences_from_previous": design_differences(
                    previous_pattern,
                    current_pattern,
                ),
            })

        records.append(round_record)

        if not improved_this_round and not (
            design_acceptance is not None
            and design_acceptance.get("accepted", False)
        ):
            break

    return {
        "label": label,
        "final_vector": current_x,
        "final_audit": current_audit,
        "final_pattern": current_pattern,
        "accepted_rounds": accepted_rounds,
        "rounds": records,
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", required=True)
    parser.add_argument("--official-sol", required=True)
    parser.add_argument("--improved-sol", required=True)
    parser.add_argument("--out-dir", required=True)
    parser.add_argument("--total-time-limit", type=float, default=900.0)
    parser.add_argument("--per-solve-limit", type=float, default=120.0)
    parser.add_argument("--max-rounds", type=int, default=4)
    parser.add_argument("--tolerance", type=float, default=1e-6)
    args = parser.parse_args()

    if args.total_time_limit > 900.0 + 1e-9:
        raise RuntimeError("Total solver budget must not exceed 900 seconds")

    os.makedirs(args.out_dir, exist_ok=True)

    model = load_model(args.mps)
    rows = extract_rows(model)
    design_vars = identify_design_variables(model)
    design_set = {v.index for v in design_vars}

    official_solution = read_solution(args.official_sol)
    improved_solution = read_solution(args.improved_sol)

    official_x, official_recognized = read_vector(
        model, official_solution
    )
    improved_x, improved_recognized = read_vector(
        model, improved_solution
    )

    official_audit = validate_vector(
        model, official_x, args.tolerance
    )
    improved_audit = validate_vector(
        model, improved_x, args.tolerance
    )

    if not official_audit["accepted_at_tolerance"]:
        raise RuntimeError("Official solution failed validation")

    if not improved_audit["accepted_at_tolerance"]:
        raise RuntimeError("Improved solution failed validation")

    official_pattern = design_pattern(design_vars, official_x)
    improved_pattern = design_pattern(design_vars, improved_x)

    # The row audit is performed for both validated operation vectors.
    official_row_audit = build_design_row_audit(
        model, rows, design_vars, official_x
    )
    improved_row_audit = build_design_row_audit(
        model, rows, design_vars, improved_x
    )

    official_hamming_audit = evaluate_hamming2_exchanges(
        rows,
        design_vars,
        official_x,
        official_pattern,
        args.tolerance,
    )

    improved_hamming_audit = evaluate_hamming2_exchanges(
        rows,
        design_vars,
        improved_x,
        improved_pattern,
        args.tolerance,
    )

    deadline = time.monotonic() + args.total_time_limit
    runs = []

    if time.monotonic() < deadline:
        runs.append(
            run_alternation(
                model=model,
                rows=rows,
                design_vars=design_vars,
                initial_x=official_x,
                label="official_start",
                total_deadline=deadline,
                per_solve_limit=args.per_solve_limit,
                max_rounds=args.max_rounds,
                tolerance=args.tolerance,
            )
        )

    if time.monotonic() < deadline:
        runs.append(
            run_alternation(
                model=model,
                rows=rows,
                design_vars=design_vars,
                initial_x=improved_x,
                label="improved_start",
                total_deadline=deadline,
                per_solve_limit=args.per_solve_limit,
                max_rounds=args.max_rounds,
                tolerance=args.tolerance,
            )
        )

    best_x = official_x
    best_audit = official_audit
    best_label = "official_start"

    if improved_audit["objective"] < best_audit["objective"]:
        best_x = improved_x
        best_audit = improved_audit
        best_label = "improved_input"

    for run in runs:
        if (
            run["final_audit"]["accepted_at_tolerance"]
            and run["final_audit"]["objective"]
            < best_audit["objective"] - args.tolerance
        ):
            best_x = run["final_vector"]
            best_audit = run["final_audit"]
            best_label = run["label"]

    best_pattern = design_pattern(design_vars, best_x)
    best_path = os.path.join(args.out_dir, "best.sol")
    write_solution(best_path, model, best_x)

    reread = read_solution(best_path)
    reread_x, reread_recognized = read_vector(model, reread)
    reread_audit = validate_vector(model, reread_x, args.tolerance)

    # Remove row lists from the large internal structures before JSON output.
    def compact_row_audit(audit):
        return {
            key: value
            for key, value in audit.items()
            if key != "rows"
        }

    output = {
        "instance": "dws012-02",
        "method": (
            "alternating exact conditional design optimization and bounded "
            "fixed-design recourse improvement"
        ),
        "inputs": {
            "mps": os.path.abspath(args.mps),
            "official_solution": os.path.abspath(args.official_sol),
            "improved_solution": os.path.abspath(args.improved_sol),
            "total_time_limit": args.total_time_limit,
            "per_solve_limit": args.per_solve_limit,
            "max_rounds": args.max_rounds,
            "tolerance": args.tolerance,
        },
        "model": {
            "variables": model.NumVars,
            "constraints": model.NumConstrs,
            "design_variable_count": len(design_vars),
            "design_columns": [v.index for v in design_vars],
            "design_names": [v.VarName for v in design_vars],
        },
        "input_solution_audits": {
            "official": {
                "recognized_variables": official_recognized,
                **official_audit,
            },
            "improved": {
                "recognized_variables": improved_recognized,
                **improved_audit,
            },
        },
        "input_designs": {
            "official_selected_positions": design_positions(
                official_pattern
            ),
            "improved_selected_positions": design_positions(
                improved_pattern
            ),
            "improved_vs_official": design_differences(
                official_pattern,
                improved_pattern,
            ),
        },
        "design_incident_row_audit": {
            "official": compact_row_audit(official_row_audit),
            "improved": compact_row_audit(improved_row_audit),
        },
        "fixed_operation_hamming2_audit": {
            "official": official_hamming_audit,
            "improved": improved_hamming_audit,
        },
        "alternating_runs": [
            {
                key: value
                for key, value in run.items()
                if key not in ("final_vector",)
            }
            for run in runs
        ],
        "best": {
            "source": best_label,
            "objective": best_audit["objective"],
            "selected_design_positions": design_positions(best_pattern),
            "differences_from_official": design_differences(
                official_pattern,
                best_pattern,
            ),
            "validated_audit": best_audit,
            "solution_file": os.path.abspath(best_path),
        },
        "saved_solution_audit": {
            "recognized_variables": reread_recognized,
            **reread_audit,
        },
        "conditional_bound_warning": (
            "All reported solver bounds are conditional on fixed operations "
            "or fixed design variables. None is a global lower bound for the "
            "unrestricted original MIP."
        ),
    }

    with open(os.path.join(args.out_dir, "audit.json"), "w") as f:
        json.dump(output, f, indent=2, sort_keys=True)

    print(json.dumps({
        "audit": os.path.abspath(
            os.path.join(args.out_dir, "audit.json")
        ),
        "best_solution": os.path.abspath(best_path),
        "best_source": best_label,
        "best_objective": best_audit["objective"],
        "official_objective": official_audit["objective"],
        "strict_improvement": (
            best_audit["objective"]
            < official_audit["objective"] - args.tolerance
        ),
        "best_design_positions": design_positions(best_pattern),
    }, indent=2))


if __name__ == "__main__":
    main()
