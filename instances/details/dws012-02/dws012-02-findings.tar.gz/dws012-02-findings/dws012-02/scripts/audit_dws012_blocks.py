#!/usr/bin/env python3
"""
dws012-02 structural translation / separator audit.

No optimization is performed.

Usage:
    python audit_dws012_blocks.py \
        --mps dws012-02.mps.gz \
        --sol dws012-02.sol.gz \
        --out dws012_block_audit.json

Optional:
    --max-examples 30
    --max-components 20

The output is deliberately bounded JSON.
"""

import argparse
import collections
import gzip
import hashlib
import json
import math
import os
import re
import sys
from array import array

import gurobipy as gp


# ---------------------------------------------------------------------------
# Basic utilities
# ---------------------------------------------------------------------------

def canon_float(x):
    """Stable coefficient/RHS representation for exact-in-MPS comparisons."""
    x = float(x)
    if x == 0.0:
        return "0"
    return format(x, ".17g")


def safe_name(x):
    return str(x)


def gcd_list(vals):
    g = 0
    for x in vals:
        x = abs(int(x))
        if x:
            g = math.gcd(g, x)
    return g


def bounded_list(seq, n):
    return list(seq[:n])


def percentile(vals, q):
    if not vals:
        return None
    a = sorted(vals)
    k = int(round((len(a) - 1) * q))
    return a[max(0, min(len(a) - 1, k))]


def json_key_tuple(t):
    return "|".join(map(str, t))


# ---------------------------------------------------------------------------
# Official solution parser and validation
# ---------------------------------------------------------------------------

def read_solution_file(path):
    """
    Reads ordinary Gurobi .sol files and common whitespace variants.

    Accepted data lines have:
        variable_name value

    Header, comment, XML-like, and objective lines are ignored.
    """
    if path is None:
        return {}

    opener = gzip.open if path.endswith(".gz") else open
    ans = {}

    with opener(path, "rt", errors="replace") as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("<") or line.startswith(">"):
                continue

            fields = line.split()
            if len(fields) < 2:
                continue

            name = fields[0]
            try:
                val = float(fields[1])
            except Exception:
                continue

            # Gurobi solution files sometimes have metadata lines such as
            # "objective value ..." or "solution status ...".
            if name.lower() in {
                "objective", "objective_value", "solution",
                "status", "solstatus", "solution_status"
            }:
                continue

            ans[name] = val

    return ans


def validate_solution(model, sol_by_name, row_data):
    vals = [0.0] * model.NumVars
    supplied = 0

    for j, v in enumerate(model.getVars()):
        if v.VarName in sol_by_name:
            vals[j] = sol_by_name[v.VarName]
            supplied += 1

    max_int = 0.0
    max_bound = 0.0
    objective = 0.0
    nonzero = 0

    for j, v in enumerate(model.getVars()):
        x = vals[j]
        if abs(x) > 1e-9:
            nonzero += 1
        objective += float(v.Obj) * x

        if v.VType in ("B", "I"):
            max_int = max(max_int, abs(x - round(x)))
        max_bound = max(max_bound, max(float(v.LB) - x, 0.0))
        max_bound = max(max_bound, max(x - float(v.UB), 0.0))

    max_row_violation = 0.0
    violated_rows = []
    row_residuals = []

    for i, (sense, rhs, entries) in enumerate(row_data):
        activity = 0.0
        for j, a in entries:
            activity += a * vals[j]

        residual = activity - rhs
        violation = 0.0
        if sense == "=":
            violation = abs(residual)
        elif sense == "<":
            violation = max(residual, 0.0)
        elif sense == ">":
            violation = max(-residual, 0.0)

        max_row_violation = max(max_row_violation, violation)
        if violation > 1e-6 and len(violated_rows) < 30:
            violated_rows.append({
                "row_index": i,
                "sense": sense,
                "rhs": rhs,
                "activity": activity,
                "violation": violation,
            })

        if len(row_residuals) < 30:
            row_residuals.append({
                "row_index": i,
                "sense": sense,
                "rhs": rhs,
                "activity": activity,
                "residual": residual,
                "violation": violation,
            })

    return {
        "solution_variables_recognized": supplied,
        "solution_file_variables": len(sol_by_name),
        "nonzero_variables": nonzero,
        "objective_recomputed": objective,
        "max_integrality_violation": max_int,
        "max_bound_violation": max_bound,
        "max_row_violation": max_row_violation,
        "rows_above_1e-6": len(violated_rows),
        "violated_row_examples": violated_rows,
        "row_residual_examples": row_residuals,
        "values": vals,
    }


# ---------------------------------------------------------------------------
# Matrix extraction
# ---------------------------------------------------------------------------

def extract_model(model):
    vars_ = model.getVars()
    rows = []
    col_incidence = [[] for _ in range(model.NumVars)]

    for i in range(model.NumConstrs):
        con = model.getConstrs()[i]
        expr = model.getRow(con)
        entries = []

        for k in range(expr.size()):
            var = expr.getVar(k)
            j = var.index
            a = float(expr.getCoeff(k))
            if abs(a) == 0.0:
                continue
            entries.append((j, a))
            col_incidence[j].append(i)

        entries.sort()
        sense = con.Sense
        if sense == "<":
            sense2 = "<"
        elif sense == ">":
            sense2 = ">"
        else:
            sense2 = "="

        rows.append((sense2, float(con.RHS), entries))

    return vars_, rows, col_incidence


def row_signature(row):
    sense, rhs, entries = row
    if entries:
        mn = min(j for j, a in entries)
    else:
        mn = 0

    normalized = tuple(
        (j - mn, canon_float(a))
        for j, a in entries
    )
    return (
        sense,
        canon_float(rhs),
        len(entries),
        normalized,
    )


def signature_digest(sig):
    return hashlib.sha1(repr(sig).encode("utf-8")).hexdigest()[:16]


# ---------------------------------------------------------------------------
# Exact translated copies and shift evidence
# ---------------------------------------------------------------------------

def analyze_translations(row_data, max_examples):
    groups = collections.defaultdict(list)
    row_mins = []

    for i, row in enumerate(row_data):
        sig = row_signature(row)
        groups[sig].append(i)
        if row[2]:
            row_mins.append(min(j for j, a in row[2]))
        else:
            row_mins.append(0)

    repeated = []
    all_shift_counts = collections.Counter()
    gcd_inputs = []

    for sig, ids in groups.items():
        if len(ids) < 2:
            continue

        mins = [row_mins[i] for i in ids]
        sorted_mins = sorted(mins)

        # Adjacent differences avoid an O(rows^2) all-pairs comparison.
        diffs = [
            sorted_mins[k + 1] - sorted_mins[k]
            for k in range(len(sorted_mins) - 1)
            if sorted_mins[k + 1] > sorted_mins[k]
        ]

        # Also use a bounded number of short lags to detect repeated
        # 18/50/66/173/... periodicities when adjacent copies are absent.
        for lag in range(1, min(8, len(sorted_mins) - 1) + 1):
            for k in range(len(sorted_mins) - lag):
                d = sorted_mins[k + lag] - sorted_mins[k]
                if d > 0:
                    all_shift_counts[d] += 1

        for d in diffs:
            all_shift_counts[d] += 1

        if diffs:
            gcd_inputs.extend(diffs)

        # Verify the translation term by term for representative pairs.
        # Since the canonical signatures match, this is an explicit check
        # rather than an assumption about variable numbering.
        examples = []
        base = ids[0]
        base_entries = row_data[base][2]
        base_min = min(j for j, a in base_entries) if base_entries else 0
        base_map = {(j - base_min): canon_float(a) for j, a in base_entries}

        for other in ids[1:min(len(ids), max_examples + 1)]:
            other_entries = row_data[other][2]
            other_min = min(j for j, a in other_entries) if other_entries else 0
            other_map = {
                (j - other_min): canon_float(a)
                for j, a in other_entries
            }
            exact = (base_map == other_map)
            examples.append({
                "row_a": base,
                "row_b": other,
                "column_shift_b_minus_a": other_min - base_min,
                "term_by_term_equal_after_shift": exact,
            })

        repeated.append({
            "signature_digest": signature_digest(sig),
            "sense": sig[0],
            "rhs": sig[1],
            "degree": sig[2],
            "copies": len(ids),
            "row_indices_sample": bounded_list(ids, max_examples),
            "minimum_column_sample": bounded_list(mins, max_examples),
            "adjacent_min_column_shifts_sample": bounded_list(diffs, max_examples),
            "shift_gcd": gcd_list(diffs),
            "translation_examples": examples,
        })

    frequent_shifts = [
        {"shift": int(d), "frequency": int(n)}
        for d, n in all_shift_counts.most_common(100)
        if d > 0
    ]

    # Robust evidence: retain shifts occurring repeatedly, then report GCDs
    # of the strongly repeated shift family.
    strong = [d for d, n in all_shift_counts.items() if n >= 5]
    robust_gcd = gcd_list(strong)

    return {
        "number_of_exact_row_signatures": len(groups),
        "number_of_repeated_signatures": sum(
            1 for x in groups.values() if len(x) >= 2
        ),
        "exact_translation_groups": sorted(
            repeated,
            key=lambda z: (-z["copies"], -z["degree"], z["signature_digest"])
        )[:200],
        "frequent_positive_column_shifts": frequent_shifts,
        "strong_shift_values_at_frequency_at_least_5": sorted(strong)[:200],
        "gcd_of_strong_shifts": robust_gcd,
        "signature_groups": groups,
        "row_mins": row_mins,
    }


# ---------------------------------------------------------------------------
# Variable descriptors and evidence-derived candidate periods
# ---------------------------------------------------------------------------

def variable_descriptors(vars_, col_incidence):
    desc = []
    for j, v in enumerate(vars_):
        desc.append((
            str(v.VType),
            canon_float(v.LB),
            canon_float(v.UB),
            len(col_incidence[j]),
        ))
    return desc


def descriptor_runs(desc, max_examples):
    runs = []
    start = 0
    for j in range(1, len(desc) + 1):
        if j == len(desc) or desc[j] != desc[start]:
            if j - start >= 2:
                runs.append({
                    "start_column": start,
                    "end_column": j - 1,
                    "length": j - start,
                    "descriptor": desc[start],
                })
            start = j
    return sorted(runs, key=lambda z: -z["length"])[:max_examples]


def candidate_periods(translation_info, desc_runs, row_data):
    scores = collections.Counter()

    # Strong exact-copy shifts.
    for x in translation_info["frequent_positive_column_shifts"]:
        d = x["shift"]
        f = x["frequency"]
        if d <= 2000:
            scores[d] += 3 * f

    # Descriptor-run evidence explicitly includes the observed 18-column
    # motif if present, but does not assume it semantically.
    for r in desc_runs:
        if r["length"] in (18, 50, 66, 173, 175, 273):
            scores[r["length"]] += 2 * r["length"]

    # Row minimum-column differences from all rows, using adjacent sorted
    # values only.
    mins = sorted(set(
        min((j for j, a in row[2]), default=0)
        for row in row_data
    ))
    for k in range(len(mins) - 1):
        d = mins[k + 1] - mins[k]
        if 1 <= d <= 2000:
            scores[d] += 1

    return [
        {
            "period": int(p),
            "evidence_score": int(s),
            "is_explicitly_observed": p in (18, 50, 66, 173, 175, 273),
        }
        for p, s in scores.most_common(30)
    ]


# ---------------------------------------------------------------------------
# Block linkage and incumbent mapping
# ---------------------------------------------------------------------------

def row_block(row, period, first_operational_col=660):
    """
    Evidence-derived coarse block coordinate.

    This is not asserted to be a semantic floor index. It is a falsifiable
    partition used to test whether objective variables separate translated
    operational regions.
    """
    entries = row[2]
    if not entries:
        return None
    mn = min(j for j, a in entries)
    return int((mn - first_operational_col) // period)


def objective_linkage(vars_, rows, col_incidence, periods, incumbent_vals,
                      max_examples):
    objective_cols = [
        j for j, v in enumerate(vars_)
        if abs(float(v.Obj)) > 0.0
    ]

    result = {
        "objective_column_count": len(objective_cols),
        "objective_columns": bounded_list(objective_cols, max_examples),
        "by_period": [],
    }

    for pinfo in periods[:12]:
        p = pinfo["period"]
        row_blocks = [row_block(r, p) for r in rows]

        records = []
        block_hist = collections.Counter()

        for j in objective_cols:
            blocks = sorted({
                row_blocks[i]
                for i in col_incidence[j]
                if row_blocks[i] is not None
            })
            for b in blocks:
                block_hist[b] += 1

            records.append({
                "column": j,
                "objective": float(vars_[j].Obj),
                "incidence": len(col_incidence[j]),
                "block_count": len(blocks),
                "blocks_sample": blocks[:max_examples],
                "links_multiple_blocks": len(blocks) >= 2,
            })

        multi = [r for r in records if r["links_multiple_blocks"]]
        counts = [r["block_count"] for r in records]

        result["by_period"].append({
            "period": p,
            "objective_variables": len(records),
            "variables_linking_at_least_two_blocks": len(multi),
            "variables_linking_at_least_three_blocks": sum(
                r["block_count"] >= 3 for r in records
            ),
            "block_count_min": min(counts) if counts else 0,
            "block_count_median": percentile(counts, .5),
            "block_count_max": max(counts) if counts else 0,
            "block_histogram_top": [
                {"block": int(b), "objective_variables": int(n)}
                for b, n in block_hist.most_common(20)
            ],
            "most_cross_block_objective_variables": sorted(
                records,
                key=lambda r: (-r["block_count"], -r["incidence"], r["column"])
            )[:max_examples],
        })

    # Incumbent support mapped using the best-supported candidate period.
    return result


def incumbent_block_map(vars_, rows, col_incidence, vals, period,
                        max_examples):
    row_blocks = [row_block(r, period) for r in rows]
    block_stats = collections.defaultdict(lambda: {
        "nonzero_variables": 0,
        "absolute_value": 0.0,
        "objective_contribution": 0.0,
        "columns_sample": [],
    })

    for j, x in enumerate(vals):
        if abs(x) <= 1e-8:
            continue

        blocks = sorted({
            row_blocks[i]
            for i in col_incidence[j]
            if row_blocks[i] is not None
        })

        # Variables not incident to a row get a special bucket.
        if not blocks:
            blocks = ["unincident"]

        for b in blocks:
            z = block_stats[b]
            z["nonzero_variables"] += 1
            z["absolute_value"] += abs(x)
            z["objective_contribution"] += float(vars_[j].Obj) * x
            if len(z["columns_sample"]) < max_examples:
                z["columns_sample"].append(j)

    out = []
    for b, z in block_stats.items():
        q = dict(z)
        q["block"] = b
        out.append(q)

    return sorted(out, key=lambda z: str(z["block"]))


# ---------------------------------------------------------------------------
# Connected components after separator removal
# ---------------------------------------------------------------------------

class DSU:
    def __init__(self, n):
        self.p = list(range(n))
        self.sz = [1] * n

    def find(self, x):
        while self.p[x] != x:
            self.p[x] = self.p[self.p[x]]
            x = self.p[x]
        return x

    def union(self, a, b):
        a = self.find(a)
        b = self.find(b)
        if a == b:
            return
        if self.sz[a] < self.sz[b]:
            a, b = b, a
        self.p[b] = a
        self.sz[a] += self.sz[b]


def components_after_removing(rows, nvars, removed, max_components):
    """
    Components of the remaining row-variable incidence graph.

    Removed variables are deleted. Rows remain as nodes, including rows that
    become isolated. This makes separator effects visible and reproducible.
    """
    nrows = len(rows)
    dsu = DSU(nrows + nvars)

    for i, (sense, rhs, entries) in enumerate(rows):
        for j, a in entries:
            if j not in removed:
                dsu.union(i, nrows + j)

    comps = collections.defaultdict(lambda: {
        "rows": 0,
        "variables": 0,
        "row_sample": [],
        "variable_sample": [],
    })

    for i in range(nrows):
        root = dsu.find(i)
        z = comps[root]
        z["rows"] += 1
        if len(z["row_sample"]) < 10:
            z["row_sample"].append(i)

    for j in range(nvars):
        if j in removed:
            continue
        root = dsu.find(nrows + j)
        z = comps[root]
        z["variables"] += 1
        if len(z["variable_sample"]) < 10:
            z["variable_sample"].append(j)

    sizes = sorted(
        comps.values(),
        key=lambda z: (-z["rows"] - z["variables"], -z["rows"])
    )

    return {
        "removed_variables": len(removed),
        "component_count": len(sizes),
        "largest_components": sizes[:max_components],
        "isolated_row_count": sum(
            1 for z in sizes if z["rows"] == 1 and z["variables"] == 0
        ),
    }


def separator_experiments(vars_, rows, col_incidence, linkage, max_components):
    objective = {
        j for j, v in enumerate(vars_)
        if abs(float(v.Obj)) > 0.0
    }

    experiments = [{
        "name": "all_objective_nonzero_variables",
        "definition": "all columns with nonzero objective coefficient",
        "columns": objective,
    }]

    for q in linkage["by_period"][:8]:
        p = q["period"]
        # Recompute block counts exactly, using this period.
        rb = [row_block(r, p) for r in rows]
        link2 = set()
        link3 = set()

        for j in objective:
            b = {
                rb[i] for i in col_incidence[j]
                if rb[i] is not None
            }
            if len(b) >= 2:
                link2.add(j)
            if len(b) >= 3:
                link3.add(j)

        experiments.append({
            "name": "objective_linking_2plus_blocks_p{}".format(p),
            "definition": "objective columns incident to at least two coarse "
                          "translated-row blocks at period {}".format(p),
            "columns": link2,
        })
        experiments.append({
            "name": "objective_linking_3plus_blocks_p{}".format(p),
            "definition": "objective columns incident to at least three coarse "
                          "translated-row blocks at period {}".format(p),
            "columns": link3,
        })

    out = []
    for e in experiments:
        c = components_after_removing(
            rows, len(vars_), e["columns"], max_components
        )
        out.append({
            "name": e["name"],
            "definition": e["definition"],
            "removed_column_count": len(e["columns"]),
            "component_result": c,
        })
    return out


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mps", required=True)
    ap.add_argument("--sol", default=None)
    ap.add_argument("--out", default="dws012_block_audit.json")
    ap.add_argument("--max-examples", type=int, default=30)
    ap.add_argument("--max-components", type=int, default=20)
    args = ap.parse_args()

    model = gp.read(args.mps)
    model.update()

    vars_, rows, col_incidence = extract_model(model)

    desc = variable_descriptors(vars_, col_incidence)
    druns = descriptor_runs(desc, args.max_examples)
    trans = analyze_translations(rows, args.max_examples)
    periods = candidate_periods(trans, druns, rows)

    sol_by_name = read_solution_file(args.sol)
    validation = validate_solution(model, sol_by_name, rows)

    vals = validation.pop("values")
    linkage = objective_linkage(
        vars_, rows, col_incidence, periods, vals, args.max_examples
    )

    # Select a period using evidence, not a hard-coded semantic assertion.
    # Prefer a period with many exact-copy shift occurrences and nontrivial
    # objective cross-block statistics. Otherwise use the top shift candidate.
    selected_period = None
    for q in linkage["by_period"]:
        if q["variables_linking_at_least_two_blocks"] > 0:
            selected_period = q["period"]
            break
    if selected_period is None and periods:
        selected_period = periods[0]["period"]
    if selected_period is None:
        selected_period = 18

    incumbent_blocks = incumbent_block_map(
        vars_, rows, col_incidence, vals, selected_period, args.max_examples
    )

    separators = separator_experiments(
        vars_, rows, col_incidence, linkage, args.max_components
    )

    # A conservative recommendation. It is based on observed component
    # separation, not on the mere existence of periodic row signatures.
    best_sep = None
    for x in separators:
        cr = x["component_result"]
        score = cr["component_count"]
        if best_sep is None or score > best_sep[0]:
            best_sep = (score, x)

    if best_sep is not None and best_sep[0] >= 3:
        recommendation = (
            "Investigate exact block decomposition / logic-based Benders. "
            "The tested evidence-derived separator creates multiple remaining "
            "incidence components; next verify cross-component rows and solve "
            "small recourse blocks independently."
        )
    elif trans["number_of_repeated_signatures"] > 0:
        recommendation = (
            "Do not yet assume a separator. Enumerate feasible local "
            "configurations for the strongest translated row family, then test "
            "a configuration master or dynamic program. Exact translations "
            "exist, but the current separator experiment did not prove "
            "independence."
        )
    else:
        recommendation = (
            "No reliable repeated block structure was recovered. Perform a "
            "variable-role audit around the 660 objective columns and use "
            "incumbent-centered exact neighborhoods rather than a block DP."
        )

    # Remove potentially huge internal fields before serialization.
    output = {
        "instance": "dws012-02",
        "input": {
            "mps": os.path.abspath(args.mps),
            "solution": os.path.abspath(args.sol) if args.sol else None,
            "num_variables": model.NumVars,
            "num_constraints": model.NumConstrs,
        },
        "official_solution_audit": validation,
        "matrix_summary": {
            "row_degree_min": min((len(r[2]) for r in rows), default=0),
            "row_degree_median": percentile([len(r[2]) for r in rows], .5),
            "row_degree_max": max((len(r[2]) for r in rows), default=0),
            "column_incidence_min": min(map(len, col_incidence), default=0),
            "column_incidence_median": percentile(list(map(len, col_incidence)), .5),
            "column_incidence_max": max(map(len, col_incidence), default=0),
            "objective_nonzero_columns": sum(
                abs(float(v.Obj)) > 0.0 for v in vars_
            ),
            "binary_columns": sum(v.VType == "B" for v in vars_),
            "continuous_columns": sum(v.VType == "C" for v in vars_),
            "integer_columns": sum(v.VType == "I" for v in vars_),
        },
        "descriptor_runs": druns,
        "translation_analysis": {
            k: v for k, v in trans.items()
            if k not in ("signature_groups", "row_mins")
        },
        "candidate_periods": periods,
        "selected_coarse_period": selected_period,
        "objective_separator_linkage": linkage,
        "official_incumbent_support_by_selected_block": incumbent_blocks,
        "separator_component_experiments": separators,
        "recommendation": recommendation,
        "falsification_tests": [
            "A purported translated pair must have identical normalized "
            "coefficient/support signatures; inspect translation_examples.",
            "A proposed period is weak if its shift frequency is low or if "
            "objective block linkage changes substantially across nearby "
            "period candidates.",
            "A first-stage separator is unsupported if removing it leaves one "
            "large connected incidence component.",
            "A decomposition candidate must additionally verify that no "
            "remaining row contains variables from multiple claimed "
            "components after separator removal.",
            "The official incumbent is usable only if all reported raw-MPS "
            "violations are within the chosen validation tolerance."
        ],
    }

    with open(args.out, "w") as f:
        json.dump(output, f, indent=2, sort_keys=True)

    print(json.dumps({
        "output": os.path.abspath(args.out),
        "selected_period": selected_period,
        "objective_value": validation["objective_recomputed"],
        "max_row_violation": validation["max_row_violation"],
        "max_bound_violation": validation["max_bound_violation"],
        "max_integrality_violation": validation["max_integrality_violation"],
        "exact_row_signatures": trans["number_of_exact_row_signatures"],
        "repeated_translation_groups": trans["number_of_repeated_signatures"],
        "top_periods": periods[:10],
        "recommendation": recommendation,
    }, indent=2))


if __name__ == "__main__":
    main()
