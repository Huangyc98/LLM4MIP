# dws012-02 Research Report

## Result

This investigation found a new, independently validated incumbent:

| item | value |
|---|---:|
| public incumbent | 119893.31070966377 |
| new incumbent | **119443.31072434435** |
| improvement | **449.99998531942** |
| strongest globally valid lower bound obtained | 23459.58492171858 |

The instance remains **open**. No optimality certificate was obtained.

The accepted solution is
[`../solutions/new_primal_119443.31072434435.sol`](../solutions/new_primal_119443.31072434435.sol),
SHA-256

```text
579A7A30F195B6E37389086195F736A4646EDB9ACDD7D5BB2E7FDFBA53DCD533
```

Independent evaluation on the original MPS gives maximum row violation
`1.2505552149377763e-12`, zero bound violation, and zero integrality violation.

## Background and recovered structure

`dws012-02` is a decentralized drinking-water-system design model with
first-stage layout decisions and second-stage operation decisions represented
by an aggregated convex-combination formulation. The original MPS has 51,108
variables, 26,382 rows, 261,120 nonzeros, 30,096 bounded integer variables,
21,012 continuous variables, and 660 objective-supported columns. It has no
quadratic, SOS, or general constraints.

The official DEC assigns every row without conflict: a 2,771-row master, a
4,256-row block 1, and 395 repeated 49-row blocks. The small blocks have 121
variables each but no private variables; all 121 are linking variables. Thus,
the initially proposed local-configuration/Dantzig-Wolfe route was rejected:
these are shared extended-formulation constraint groups, not independent
recourse subproblems.

The sibling instances `dws012-01` and `dws012-02` have 264 positionally
corresponding objective-supported integer design variables with the same cost
sequence. Each public solution selects 19 positions and 18 positions coincide.
Their only differing selections suggested the target exchange (one-based)
`245: 1 -> 0`, `250: 0 -> 1`.

## Attempts

1. **Anonymous periodicity recovery.** Exact translated row signatures exposed
   shifts 373, 746, 1119, 1492, and 1865, plus a secondary period 18. Removing
   all objective-supported columns still left one giant component, so the
   periodicity was retained as structural evidence but not treated as a valid
   decomposition.
2. **Official DEC audit.** All 26,382 rows were assigned. The absence of any
   local variables in the 395 small blocks falsified the API's first proposed
   per-block enumeration method before it could be misused.
3. **Sibling-design transplant.** The `dws012-01` design difference was moved
   positionally into the target model and continuous recourse was reoptimized.
   This produced the new validated incumbent `119443.31072434435`.
4. **Conditional design search.** With operations fixed, all 4,655
   cardinality-preserving Hamming-2 exchanges were tested for each of the
   public and new operation vectors; all were infeasible. Fixed-design recourse
   also closed for both designs, and alternating design/recourse optimization
   found no further accepted improvement.
5. **Globally valid relaxation hierarchy.** Three complete copies of the
   original model retained every row, variable, bound, and objective term and
   relaxed only selected integrality restrictions.

The Hamming-2 and alternating results are only local or conditional. They do
not exclude an improvement requiring simultaneous design and operation changes.

## Global lower bounds

| relaxation | retained integers | status | dual bound | runtime |
|---|---:|---|---:|---:|
| LP | 0 | optimal | 1469.6000000000006 | 0.134 s |
| design-integral | 264 | optimal | **23459.58492171858** | 426.303 s |
| layout-core | 1,188 | time limit | 18860.788752538334 | 173.942 s |

For minimization, these are globally valid because the relaxation feasible set
contains the original feasible set. The layout-core primal was
24218.935277171644, but it is not an original-MIP upper bound. Its time-limited
dual bound being weaker than the solved design-integral bound is not a
contradiction: the exact relaxation optimum is nested, while a time-limited
search need not reach it.

The strongest defensible interval from this work is

```text
23459.58492171858 <= z* <= 119443.31072434435.
```

No incumbent-derived cut or objective cutoff was used to justify the lower
bound.

## Effort and next route

Research lasted 72 minutes 42 seconds. Accepted generic-solver optimization
was about 10 minutes 4 seconds for the relaxation hierarchy plus only seconds
for fixed-design recourse, within the 30-minute limit.

The next high-value route is exact recognition and projection of the repeated
pump extended formulation, with equivalence checked in both directions. For
primal work, neighborhoods should coordinate a few design, pump-switching,
convex-combination, and incident hydraulic variables rather than changing the
design while freezing every operational variable.
