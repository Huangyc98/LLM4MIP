# Background and authoritative sources

## Official MIPLIB record

- Instance page: https://miplib.zib.de/instance_details_dws012-02.html
- Original model: https://miplib.zib.de/WebData/instances/dws012-02.mps.gz
- Best public solution (submission 5): https://miplib.zib.de/downloads/solutions/dws012-02/5/dws012-02.sol.gz
- Status at retrieval (2026-09-09): open, minimization, public incumbent `119893.3107095763` (the page displays an asterisk because optimality is not established).
- Submitter: Philipp Leise. MIPLIB group: `dws`.

MIPLIB describes a MILP for designing a decentralized drinking-water supply
system in skyscrapers. Pump nonlinearities are represented with aggregated
convex combinations. Instances vary by number of floors and water-demand load
scenarios. First-stage variables select the physical layout; second-stage
variables describe operation, including continuous pump speed and binary pump
switching.

The page cites:

L. C. Altherr, J. Wolf, T. Ederer, P. Leise, and P. F. Pelz,
"Algorithmic Design of an Optimal Water Supply System with TOR," 3rd
International Rotating Equipment Conference, 2016.

## Public incumbent history

The official page lists objectives 126211.9 (2018), 122894.9 (2024), 122074.2
(2024), 121112.1 (2024), and 119893.3 (BigMIP, 2025). The latest submitted
solution is downloaded here and must be checked against the original MPS before
being used as an incumbent.

## Read-only structural facts recovered with Gurobi

- 51,108 variables, 26,382 linear constraints, 261,120 nonzeros.
- 30,096 integer variables, all expected to be binary from the bounds; 21,012
  continuous variables.
- 2,270 equality, 22,176 <=, and 1,936 >= rows.
- Only 660 objective-nonzero variables. Row degree has median 4 and maximum 73;
  column incidence has median 4 and maximum 28.
- Dominant exact templates include 9,900 seven-term <=0 rows, 7,920 four-term
  <=0 rows, 1,518 two-term <=0 rows, and repeated 50- and 73-term equalities.
- Names are anonymized (`VAR...`, `c...`), so semantic indices must be recovered
  from repeated coefficient/adjacency patterns rather than assumed.

The full evidence is in `structure/structure.json`; the compact copy is
`structure/structure.compact.json`. Gurobi was used only to parse the model for
this step; no optimization or presolve was called.

## Initial hypotheses, not established facts

The repeated row templates and the official two-stage description make a
layout/operation decomposition plausible. Candidate methods include recovering
scenario/floor blocks, enumerating canonical local pump configurations,
logic-based Benders or Dantzig-Wolfe decomposition, and a chain-state dynamic
program if the floor interface is narrow. These are questions for matrix audit,
not assumptions to encode without proof.
