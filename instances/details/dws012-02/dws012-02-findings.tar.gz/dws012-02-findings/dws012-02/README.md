# `dws012-02`

## Result

Status: **open; improved primal bound**.

This study found and independently checked a new feasible solution:

```text
public incumbent:  119893.31070966377
new incumbent:     119443.31072434435
improvement:          449.99998531942
verified lower bound: 23459.58492171858
```

The new solution has maximum original-row violation
`1.2505552149377763e-12`, zero bound violation, and zero integrality
violation. No optimality certificate was obtained, so the defensible interval
from this study is

```text
23459.58492171858 <= OPT <= 119443.31072434435.
```

[MIPLIB instance page](https://miplib.zib.de/instance_details_dws012-02.html)

## Structure and method

The original model has 51,108 variables, 26,382 rows, and 261,120 nonzeros.
It represents a two-stage decentralized drinking-water-system design problem.
An exact audit of the official decomposition showed that its 395 repeated
49-row groups contain linking variables but no private variables; therefore
they are not independent recourse blocks.

The successful primal route compared the sibling `dws012-01` design with the
public `dws012-02` design. Their 264 objective-supported design positions have
the same cost sequence and differ at only one selected position. Transplanting
that exchange and reoptimizing continuous recourse yielded the new incumbent.
All 4,655 single exchanges around each fixed operation vector were then tested
without another accepted improvement; this is local evidence only.

The lower bound is the optimum of a globally valid relaxation retaining all
original rows, bounds, and objective terms while keeping only the 264 design
variables integral. The generic-solver time used by the accepted experiments
was about 10 minutes, below the 30-minute cap.

## Evidence

- [`solutions/new_primal_119443.31072434435.sol`](solutions/new_primal_119443.31072434435.sol)
  is the improved solution.
- [`artifacts/transplant/independent_audit.json`](artifacts/transplant/independent_audit.json)
  and [`artifacts/relaxations/upper_solution_audit.json`](artifacts/relaxations/upper_solution_audit.json)
  record independent checks.
- [`artifacts/relaxations/results.json`](artifacts/relaxations/results.json)
  records the relaxation bounds.
- [`reports/final_report.md`](reports/final_report.md) contains the full study;
  [`sources/background_and_sources.md`](sources/background_and_sources.md)
  records provenance.

Large relaxation MPS files, the regenerable manifest, search-result HTML, and
raw API prompts/responses are intentionally omitted. The retained scripts
reconstruct the relevant experiments from the original compressed MPS.

SHA-256:

- MPS: `AEC69CB2FA916183F17B6537BAC60C8B1BCD84169B5D93DA812F2D4806C66D66`
- public solution: `84ACBC7996E579C7FA6DD5323499D7C1115F648599467DA89B730649DBBBB8CE`
- new solution: `579A7A30F195B6E37389086195F736A4646EDB9ACDD7D5BB2E7FDFBA53DCD533`
