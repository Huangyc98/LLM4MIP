# Effort ledger

- Research start: 2026-09-09 01:31:00 +08:00
- Minimum required wall-clock effort: 60 minutes unless a strict optimality
  certificate is obtained earlier.
- Generic full/subproblem solver optimization budget: at most 30 minutes total.
- 01:31-01:34: official input and incumbent retrieval; read-only Gurobi
  structure extraction and compacting.
- 01:34 onward: authoritative background recovery and first API research
  segment preparation.
- 01:34-01:43: API method design and exact anonymous block-signature recovery.
- 01:43-01:50: API-generated official DEC audit; all 26,382 rows assigned to
  396 blocks plus the master. The 395 repeated 49-row blocks contain no local
  variables, so the initially proposed local-configuration enumeration route
  was rejected on evidence.
- 01:50-01:57: sibling `dws012-01`/`dws012-02` structural comparison. The 264
  objective-supported design columns match positionally and the public
  designs share 18 of 19 selected positions.
- 01:57-02:05: API-generated sibling-transplant experiment. Re-optimizing only
  continuous recourse after the one-position design exchange produced a new
  candidate objective 119443.31072434435.
- 02:05-02:12: independent original-MPS validation and conditional-coordinate
  experiments. The candidate has maximum row violation 1.251e-12 and zero
  bound/integrality violation. Both fixed-design recourse problems close, and
  all 4,655 Hamming-2 designs are infeasible with either fixed operation
  vector; these are local/conditional facts, not global certificates.
- 02:12-02:32: API designed a globally valid lower-bound hierarchy and supplied
  auditable construction code; parser and cutoff defects exposed by execution
  feedback were corrected before the accepted run.
- 02:33-02:43: 602-second relaxation run. LP closes at 1469.6; retaining the
  264 design integers closes at 23459.58492171858; retaining an additional 924
  layout-core integers reaches certified bound 18860.788752538334 before the
  limit. All relaxations retain every original row, bound, and objective term.
- Research end: 2026-09-09 02:43:42 +08:00 (72 minutes 42 seconds).
- Solver optimization used in accepted experiments: about 10 minutes 4 seconds
  for the global relaxation hierarchy, plus only seconds for fixed-design
  recourse checks; total is below 30 minutes.
