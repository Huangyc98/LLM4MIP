# fhnw-binschedule2

Status: **global optimum proved**.

Exact optimum: **2,428**.

[MIPLIB instance page](https://miplib.zib.de/instance_details_fhnw-binschedule2.html)

## Reconstructed structure

The original anonymized MPS is a six-machine makespan model with 497
set-partition items and 114 ordered bins. The bins are distributed
39/9/9/9/9/39. Exactly 76 items can use only the two 39-position endpoint
machines; each has 39 choices at either endpoint. The remaining 421 items have
nine choices on every machine. The model also contains 1,614 bin-local OR
variables, 1,908 selector windows, and 228 difference indicators. All 6,503
rows are accounted for by these blocks.

## Exact certificate

For each of the 76 endpoint-only items, its assignment coefficient plus every
OR cost forced by selecting it is independent of its endpoint and position.
Summing these fixed item costs gives 4,546.

Both endpoint sequences share an explicit set `Q` of 35 item intervals whose
interiors contain 11/2. These intervals are pairwise incomparable. If endpoint
`k` receives `n_k` mandatory items and has `D_k` active difference indicators,
deleting its `39-n_k` nonmandatory positions and cutting at the active
differences covers the selected intervals with at most `40-n_k+D_k` chains.
Every chain contains at most one selected member of `Q`, so

```text
D_k >= q_k + n_k - 40.
D_0 + D_5 >= 35 + 76 - 80 = 31.
```

Every endpoint difference costs 10, hence the endpoint-load sum is at least
`4546 + 10*31 = 4856`. Every endpoint load is an even integer. If the objective
were strictly below 2,428, both endpoint loads would be at most 2,426 and their
sum at most 4,852, contradicting 4,856. The public solution is exactly feasible
and has both endpoint loads equal to 2,428. Therefore the global optimum is
2,428.

## Reproduce

The final verifier imports no solver. It parses the compressed MPS and public
solution directly with exact `Fraction` arithmetic, verifies the file hashes
and every structural assumption above, checks all 6,503 original rows, and
fails closed unless the certificate is complete:

```powershell
python .\instances\fhnw-binschedule2\scripts\verify_fhnw_binschedule2.py `
  .\instances\fhnw-binschedule2\input\fhnw-binschedule2.mps.gz `
  .\instances\fhnw-binschedule2\solutions\fhnw-binschedule2-public.sol.gz
```

The exploratory scripts that recovered and tested the endpoint structure are
also retained under `scripts/`. Their final independent output is archived in
`logs/verify-fhnw-binschedule2.log`; recovered structural metadata is under
`artifacts/`.

## Provenance

This result was produced in a four-turn direct-API investigation using 139,499
tokens. A 76-variable derived LP/MIP was used only as an exploratory oracle; the
final proof above is solver-independent. Raw API responses and machine-specific
runtime metadata are deliberately not included.

SHA-256:

- MPS: `F3F816C31A5AFCB288BD0AA84F9CCE205D36890A5E46A6F2175C2FA35C8DAC5F`
- public solution: `FAAC8E4E4C8D8DD76C276FF7E9A4B2D96133117EF7214DF8A6341AF7F6D721C9`
