#!/usr/bin/env python3
"""
Exact structural reconstruction and endpoint-load certificate attempt for
fhnw-binschedule2.

Gurobi is used only to read the MPS. No optimize(), presolve(), relaxation,
or parameter tuning is called.

The program:
  * recovers the 497 items and 114 bins;
  * recovers ownership by the six load expressions;
  * classifies every row into one of six formulation blocks;
  * reconstructs the 1,908 value-window selectors;
  * verifies bin and item invariance;
  * derives an additive lower bound from endpoint OR costs;
  * runs an exact 0/1 knapsack DP over the aggregate inner-bin capacity;
  * combines the bound with the endpoint load lattices.
"""

import sys
import gzip
import re
import math
from collections import Counter, defaultdict
from fractions import Fraction

import gurobipy as gp
from gurobipy import GRB


def F(x):
    if isinstance(x, Fraction):
        return x
    if isinstance(x, int):
        return Fraction(x)
    return Fraction(str(float(x)))


def fs(x):
    x = F(x)
    if x.denominator == 1:
        return str(x.numerator)
    return f"{x.numerator}/{x.denominator}"


def lcm(a, b):
    return abs(a * b) // math.gcd(a, b)


def rational_gcd(values):
    values = [abs(F(x)) for x in values if x]
    if not values:
        return Fraction(0)
    den = 1
    for x in values:
        den = lcm(den, x.denominator)
    nums = [x.numerator * (den // x.denominator) for x in values]
    g = 0
    for x in nums:
        g = math.gcd(g, abs(x))
    return Fraction(g, den)


def compact_counter(c, limit=16):
    if not c:
        return "{}"
    z = sorted(c.items(), key=lambda p: (-p[1], str(p[0])))
    shown = z[:limit]
    text = ", ".join(f"{k}:{v}" for k, v in shown)
    if len(z) > limit:
        text += f", ... ({len(z)} distinct)"
    return "{" + text + "}"


def open_text(path):
    if path.endswith(".gz"):
        return gzip.open(path, "rt", encoding="utf-8", errors="replace")
    return open(path, "rt", encoding="utf-8", errors="replace")


def parse_solution(path, name_to_idx):
    vals = {}
    header = None
    with open_text(path) as f:
        text = f.read()

    m = re.search(
        r'objectiveValue\s*=\s*["\']([^"\']+)["\']',
        text, re.I
    )
    if m:
        header = Fraction(m.group(1))

    for m in re.finditer(
        r'<variable\b[^>]*\bname\s*=\s*["\']([^"\']+)["\']'
        r'[^>]*\bvalue\s*=\s*["\']([^"\']+)["\']',
        text, re.I
    ):
        if m.group(1) in name_to_idx:
            vals[name_to_idx[m.group(1)]] = Fraction(m.group(2))

    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or line.startswith("*"):
            continue
        mo = re.match(r"^=obj=\s+(\S+)", line, re.I)
        if mo:
            header = Fraction(mo.group(1))
            continue
        fields = line.split()
        if len(fields) >= 2 and fields[0] in name_to_idx:
            try:
                vals[name_to_idx[fields[0]]] = Fraction(fields[1])
            except Exception:
                pass

    return vals, header


def strict_lattice_predecessor(target, step):
    """Largest multiple of positive step strictly below target."""
    target = F(target)
    step = F(step)
    q = target / step
    if q.denominator == 1:
        return target - step
    return Fraction(q.numerator // q.denominator) * step


def main():
    if len(sys.argv) != 3:
        print(
            "usage: python endpoint_certificate.py "
            "instance.mps.gz incumbent.sol.gz",
            file=sys.stderr
        )
        return 2

    mps_path, sol_path = sys.argv[1], sys.argv[2]

    model = gp.read(mps_path)
    variables = model.getVars()
    constraints = model.getConstrs()
    n = len(variables)

    name_to_idx = {v.VarName: i for i, v in enumerate(variables)}

    rows = []
    incidence = [[] for _ in variables]
    for ri, con in enumerate(constraints):
        expr = model.getRow(con)
        terms = []
        for p in range(expr.size()):
            v = expr.getVar(p)
            j = v.index
            a = F(expr.getCoeff(p))
            terms.append((j, a))
            incidence[j].append(ri)
        rows.append((con.Sense, F(con.RHS), terms))

    # ------------------------------------------------------------------
    # Set-partition items
    # ------------------------------------------------------------------

    item_rows = []
    items = []
    item_of = {}

    for ri, (sense, rhs, terms) in enumerate(rows):
        if (
            sense == "="
            and rhs == 1
            and terms
            and all(
                a == 1 and variables[j].VType == GRB.BINARY
                for j, a in terms
            )
        ):
            item_rows.append(ri)
            item = len(items)
            opts = [j for j, _ in terms]
            items.append(opts)
            for j in opts:
                if j in item_of:
                    raise RuntimeError(
                        f"{variables[j].VarName} occurs in two item rows"
                    )
                item_of[j] = item

    assignment = set(item_of)

    # ------------------------------------------------------------------
    # Six normalized epigraph expressions
    # ------------------------------------------------------------------

    objective_vars = [
        i for i, v in enumerate(variables) if F(v.Obj) != 0
    ]
    if len(objective_vars) != 1:
        raise RuntimeError("Expected exactly one objective variable")

    objective_var = objective_vars[0]
    epigraph_rows = list(incidence[objective_var])
    loads = []

    for ri in epigraph_rows:
        sense, rhs, terms = rows[ri]
        coeff = dict(terms)
        ao = coeff[objective_var]

        if sense == ">":
            sign = Fraction(1)
        elif sense == "<":
            sign = Fraction(-1)
        else:
            raise RuntimeError("Objective variable occurs in an equality")

        A = sign * ao
        if A <= 0:
            raise RuntimeError("Not a lower epigraph inequality")

        beta = sign * rhs / A
        c = {}
        for j, a in terms:
            if j == objective_var:
                continue
            z = -sign * a / A
            if z:
                c[j] = z
        loads.append((ri, beta, c))

    if len(loads) != 6:
        raise RuntimeError(f"Expected six loads, found {len(loads)}")

    load_coeff = [
        [loads[k][2].get(j, Fraction(0)) for k in range(6)]
        for j in range(n)
    ]

    def owners(j):
        return tuple(k for k in range(6) if load_coeff[j][k] != 0)

    # ------------------------------------------------------------------
    # Recover the 114 capacity rows
    # ------------------------------------------------------------------

    capacity_rows = []
    for ri, (sense, rhs, terms) in enumerate(rows):
        if ri in item_rows or not terms:
            continue
        if all(j in assignment for j, _ in terms):
            capacity_rows.append(ri)

    bins = []
    bin_of = {}
    cap_coeff = {}

    for b, ri in enumerate(capacity_rows):
        sense, rhs, terms = rows[ri]
        opts = [j for j, _ in terms]
        bins.append(opts)
        for j, a in terms:
            if j in bin_of:
                raise RuntimeError(
                    f"Assignment {variables[j].VarName} occurs in "
                    "multiple capacity rows"
                )
            bin_of[j] = b
            cap_coeff[j] = a

    # Bin owner: all options in a bin should belong to one load.
    bin_owner = {}
    inconsistent_bins = []

    for b, opts in enumerate(bins):
        os = {owners(j) for j in opts}
        if len(os) == 1:
            own = next(iter(os))
            if len(own) == 1:
                bin_owner[b] = own[0]
            else:
                inconsistent_bins.append((b, os))
        else:
            inconsistent_bins.append((b, os))

    # ------------------------------------------------------------------
    # OR definitions M*q - sum x >= 0
    # ------------------------------------------------------------------

    or_rows = []
    or_support = {}
    or_var = set()

    for ri, (sense, rhs, terms) in enumerate(rows):
        if sense != ">" or rhs != 0:
            continue

        positive = [(j, a) for j, a in terms if a > 0]
        negative = [(j, a) for j, a in terms if a < 0]

        if len(positive) != 1 or not negative:
            continue

        q, aq = positive[0]
        if variables[q].VType != GRB.BINARY or q in assignment:
            continue
        if not all(j in assignment and a == -1 for j, a in negative):
            continue
        if aq != len(negative):
            continue

        support = tuple(j for j, _ in negative)
        if len({item_of[j] for j in support}) != len(support):
            raise RuntimeError(
                f"OR support in row {constraints[ri].ConstrName} "
                "contains two choices of one item"
            )

        or_rows.append(ri)
        or_var.add(q)
        or_support[q] = support

    # ------------------------------------------------------------------
    # Recover all paired window inequalities:
    #
    #   t_u + (20-h)s <= 20
    #   t_v - h s      >= 0
    #
    # At h=0 or h=20 one selector coefficient disappears.
    # ------------------------------------------------------------------

    integer_vars = {
        i for i, v in enumerate(variables)
        if v.VType == GRB.INTEGER
    }

    windows = []
    window_rows = set()

    for ri in range(len(rows) - 1):
        s1, r1, t1 = rows[ri]
        s2, r2, t2 = rows[ri + 1]

        if s1 != "<" or r1 != 20 or s2 != ">" or r2 != 0:
            continue

        i1 = [(j, a) for j, a in t1 if j in integer_vars]
        i2 = [(j, a) for j, a in t2 if j in integer_vars]
        o1 = [(j, a) for j, a in t1 if j not in integer_vars]
        o2 = [(j, a) for j, a in t2 if j not in integer_vars]

        if len(i1) != 1 or i1[0][1] != 1:
            continue
        if len(i2) != 1 or i2[0][1] != 1:
            continue
        if len(o1) > 1 or len(o2) > 1:
            continue

        if o1:
            selector1, a1 = o1[0]
            if a1 <= 0 or a1 > 20:
                continue
            h1 = 20 - a1
        else:
            selector1 = None
            h1 = Fraction(20)

        if o2:
            selector2, a2 = o2[0]
            if a2 >= 0 or a2 < -20:
                continue
            h2 = -a2
        else:
            selector2 = None
            h2 = Fraction(0)

        if h1 != h2:
            continue

        h = h1
        if selector1 is not None and selector2 is not None:
            if selector1 != selector2:
                continue
            selector = selector1
        elif selector1 is not None:
            selector = selector1
        elif selector2 is not None:
            selector = selector2
        else:
            continue

        if selector not in assignment and selector not in or_var:
            continue

        u = i1[0][0]
        v = i2[0][0]
        windows.append((ri, ri + 1, selector, h, u, v))
        window_rows.add(ri)
        window_rows.add(ri + 1)

    # ------------------------------------------------------------------
    # Difference indicators:
    #
    #   -t_u + t_v + 20z >= 0
    #   -t_u + t_v - 20z <= 0
    # ------------------------------------------------------------------

    diff_groups = defaultdict(list)

    for ri, (sense, rhs, terms) in enumerate(rows):
        if rhs != 0 or len(terms) != 3:
            continue

        ints = [(j, a) for j, a in terms if j in integer_vars]
        bins_here = [
            (j, a) for j, a in terms
            if variables[j].VType == GRB.BINARY and j not in assignment
        ]

        if len(ints) != 2 or len(bins_here) != 1:
            continue
        if sorted(a for _, a in ints) != [Fraction(-1), Fraction(1)]:
            continue

        z, az = bins_here[0]
        if abs(az) != 20:
            continue

        key = (tuple(sorted(j for j, _ in ints)), z)
        diff_groups[key].append(ri)

    diff_rows = set()
    diff_vars = set()
    differences = []

    for (uv, z), rr in diff_groups.items():
        if len(rr) == 2:
            differences.append((uv[0], uv[1], z, tuple(rr)))
            diff_vars.add(z)
            diff_rows.update(rr)

    # ------------------------------------------------------------------
    # Complete row classification
    # ------------------------------------------------------------------

    epigraph_row_set = {ri for ri, _, _ in loads}
    classified = (
        set(item_rows)
        | set(capacity_rows)
        | set(or_rows)
        | window_rows
        | diff_rows
        | epigraph_row_set
    )
    unmatched = sorted(set(range(len(rows))) - classified)

    print("\nEXACT ROW DECOMPOSITION")
    print(" set-partition rows:", len(item_rows))
    print(" capacity rows:", len(capacity_rows))
    print(" OR-definition rows:", len(or_rows))
    print(" window inequality pairs:", len(windows),
          "rows:", len(window_rows))
    print(" difference indicators:", len(differences),
          "rows:", len(diff_rows))
    print(" objective epigraph rows:", len(epigraph_row_set))
    print(" classified rows:", len(classified), "/", len(rows))
    print(" unmatched rows:", len(unmatched))
    if unmatched:
        print(" first unmatched:",
              [constraints[r].ConstrName for r in unmatched[:20]])

    # ------------------------------------------------------------------
    # Machine/bin structure
    # ------------------------------------------------------------------

    print("\nMACHINE/BIN RECONSTRUCTION")
    print(" item-option histogram:",
          compact_counter(Counter(len(x) for x in items)))
    print(" assignment variables:", len(assignment))
    print(" assignment variables with a capacity row:", len(bin_of))
    print(" inconsistent-owner bins:", len(inconsistent_bins))

    bins_per_machine = Counter(bin_owner.values())
    print(" bins per machine:",
          [bins_per_machine[k] for k in range(6)])

    for k in range(6):
        bs = [b for b in range(len(bins)) if bin_owner.get(b) == k]
        degree_hist = Counter(len(bins[b]) for b in bs)
        rhs_hist = Counter(fs(rows[capacity_rows[b]][1]) for b in bs)
        sense_hist = Counter(rows[capacity_rows[b]][0] for b in bs)
        print(
            f" machine {k}: bins={len(bs)}, "
            f"degree_hist={compact_counter(degree_hist)}, "
            f"sense_hist={compact_counter(sense_hist)}, "
            f"rhs_hist={compact_counter(rhs_hist)}"
        )

    item_owner_patterns = Counter()
    option_count_patterns = Counter()

    for opts in items:
        by_owner = Counter()
        for j in opts:
            o = owners(j)
            if len(o) == 1:
                by_owner[o[0]] += 1
        item_owner_patterns[tuple(sorted(by_owner))] += 1
        option_count_patterns[
            tuple(by_owner.get(k, 0) for k in range(6))
        ] += 1

    print(" item owner-set histogram:",
          compact_counter(item_owner_patterns))
    print(" options-per-machine histogram:",
          compact_counter(option_count_patterns))

    # ------------------------------------------------------------------
    # Item invariance
    # ------------------------------------------------------------------

    weight_invariant = True
    objective_invariant = True
    bad_weights = []
    bad_processing = []

    item_weight = {}
    item_processing = {}

    for i, opts in enumerate(items):
        ws = {cap_coeff[j] for j in opts if j in cap_coeff}
        if len(ws) != 1:
            weight_invariant = False
            bad_weights.append((i, tuple(sorted(ws))))
        else:
            item_weight[i] = next(iter(ws))

        p = {}
        for k in range(6):
            vals = {
                load_coeff[j][k]
                for j in opts
                if owners(j) == (k,)
            }
            if vals:
                if len(vals) != 1:
                    objective_invariant = False
                    bad_processing.append((i, k, tuple(sorted(vals))))
                else:
                    p[k] = next(iter(vals))
        item_processing[i] = p

    print("\nINVARIANCE TESTS")
    print(" item capacity coefficient invariant over all bins:",
          weight_invariant)
    print(" item processing coefficient invariant within each machine:",
          objective_invariant)
    print(" bad-weight items:", len(bad_weights))
    print(" bad-processing item/machine pairs:", len(bad_processing))
    if bad_weights:
        print(" first bad weights:",
              [(i, tuple(fs(x) for x in z))
               for i, z in bad_weights[:10]])
    if bad_processing:
        print(" first bad processing:",
              [(i, k, tuple(fs(x) for x in z))
               for i, k, z in bad_processing[:10]])

    if weight_invariant:
        print(" item-weight histogram:",
              compact_counter(Counter(fs(w) for w in item_weight.values())))

    # ------------------------------------------------------------------
    # Window graph
    # ------------------------------------------------------------------

    int_start = min(integer_vars)

    def int_coord(j):
        r = j - int_start
        return r // 6, r % 6

    endpoint_pairs = Counter()
    endpoint_nodes = Counter()
    support_bin_counts = Counter()
    mixed_support_windows = []

    for _, _, selector, h, u, v in windows:
        cu, cv = int_coord(u), int_coord(v)
        endpoint_pairs[(cu, cv)] += 1
        endpoint_nodes[(cu[0], cv[0], cu[1], cv[1])] += 1

        if selector in assignment:
            support = (selector,)
        else:
            support = or_support[selector]

        bs = {bin_of[j] for j in support if j in bin_of}
        support_bin_counts[len(bs)] += 1
        if len(bs) != 1:
            mixed_support_windows.append(
                (selector, h, u, v, tuple(sorted(bs)))
            )

    unique_uv = {(u, v) for _, _, _, _, u, v in windows}
    print("\nWINDOW/NETWORK RECONSTRUCTION")
    print(" selectors:", len(windows))
    print(" OR selectors:", sum(1 for x in windows if x[2] in or_var))
    print(" singleton assignment selectors:",
          sum(1 for x in windows if x[2] in assignment))
    print(" unique directed integer pairs:", len(unique_uv))
    print(" support distinct-bin histogram:",
          compact_counter(support_bin_counts))
    print(" mixed-bin supports:", len(mixed_support_windows))

    feature_pairs = Counter()
    node_offsets = Counter()
    values_per_uv = defaultdict(set)

    for _, _, _, h, u, v in windows:
        nu, fu = int_coord(u)
        nv, fv = int_coord(v)
        feature_pairs[(fu, fv)] += 1
        node_offsets[nv - nu] += 1
        values_per_uv[(u, v)].add(h)

    print(" endpoint feature-pair histogram:",
          compact_counter(feature_pairs))
    print(" endpoint node-offset histogram:",
          compact_counter(node_offsets))
    print(" values-per-directed-pair histogram:",
          compact_counter(Counter(len(z) for z in values_per_uv.values())))

    # ------------------------------------------------------------------
    # Objective ownership and lattice
    # ------------------------------------------------------------------

    role_sets = {
        "assignment": assignment,
        "OR": or_var,
        "difference": diff_vars,
    }

    print("\nLOAD OWNERSHIP")
    for role, index_set in role_sets.items():
        owner_count = Counter()
        coeff_count = Counter()
        multiple = 0
        for j in index_set:
            o = owners(j)
            owner_count[o] += 1
            if len(o) != 1:
                multiple += 1
            for k in o:
                coeff_count[(k, fs(load_coeff[j][k]))] += 1
        print(f" {role}: variables={len(index_set)}, "
              f"multiple/no-owner={multiple}")
        print("   owner histogram:", compact_counter(owner_count))
        print("   coefficient histogram:",
              compact_counter(coeff_count, 24))

    load_steps = []
    for k in range(6):
        vals = list(loads[k][2].values())
        step = rational_gcd(vals)
        load_steps.append(step)
        print(f" load {k} lattice step:", fs(step))

    # ------------------------------------------------------------------
    # Public solution decomposition
    # ------------------------------------------------------------------

    sol, objective_header = parse_solution(sol_path, name_to_idx)
    if objective_var not in sol and objective_header is not None:
        sol[objective_var] = (
            objective_header - F(model.ObjCon)
        ) / F(variables[objective_var].Obj)

    xval = [sol.get(i, Fraction(0)) for i in range(n)]

    print("\nPUBLIC SOLUTION DECOMPOSITION")
    for k in range(6):
        base = sum(
            load_coeff[j][k] * xval[j] for j in assignment
        )
        or_cost = sum(
            load_coeff[j][k] * xval[j] for j in or_var
        )
        diff_cost = sum(
            load_coeff[j][k] * xval[j] for j in diff_vars
        )
        total = loads[k][1] + base + or_cost + diff_cost
        assigned_items = sum(
            xval[j] for j in assignment if owners(j) == (k,)
        )
        print(
            f" load {k}: items={fs(assigned_items)}, "
            f"base={fs(base)}, OR={fs(or_cost)}, "
            f"difference={fs(diff_cost)}, total={fs(total)}"
        )

    # Check whether public OR variables are minimal.
    extra_or = 0
    missing_or = 0
    active_or_by_machine = Counter()

    for q, support in or_support.items():
        required = any(xval[j] == 1 for j in support)
        actual = xval[q] == 1
        if required and not actual:
            missing_or += 1
        if actual and not required:
            extra_or += 1
        if actual and len(owners(q)) == 1:
            active_or_by_machine[owners(q)[0]] += 1

    print(" active OR variables by machine:",
          [active_or_by_machine[k] for k in range(6)])
    print(" missing required OR variables:", missing_or)
    print(" unnecessary active OR variables:", extra_or)

    # ------------------------------------------------------------------
    # Endpoint additive charging
    # ------------------------------------------------------------------

    endpoint_machines = {0, 5}
    inner_machines = {1, 2, 3, 4}

    base_endpoint_charge = {
        j: load_coeff[j][0] + load_coeff[j][5]
        for j in assignment
    }
    charged_endpoint_charge = dict(base_endpoint_charge)

    allocation_total = Fraction(0)
    endpoint_or_total_coeff = Fraction(0)
    endpoint_or_count = 0

    for q, support in or_support.items():
        cq = load_coeff[q][0] + load_coeff[q][5]
        if cq < 0:
            raise RuntimeError("Negative endpoint OR coefficient")
        if cq == 0:
            continue

        endpoint_or_count += 1
        endpoint_or_total_coeff += cq
        share = cq / len(support)
        allocation_total += share * len(support)

        for j in support:
            charged_endpoint_charge[j] += share

    print("\nENDPOINT OR CHARGING")
    print(" endpoint-owned OR variables:", endpoint_or_count)
    print(" sum of their objective coefficients:",
          fs(endpoint_or_total_coeff))
    print(" total distributed coefficient:", fs(allocation_total))
    print(" allocation conservation:",
          allocation_total == endpoint_or_total_coeff)

    # ------------------------------------------------------------------
    # Aggregate-inner-capacity knapsack lower bound
    # ------------------------------------------------------------------

    inner_bins = [
        b for b in range(len(bins))
        if bin_owner.get(b) in inner_machines
    ]

    inner_capacity = Fraction(0)
    valid_inner_capacity = True

    for b in inner_bins:
        ri = capacity_rows[b]
        sense, rhs, terms = rows[ri]
        if sense != "<":
            valid_inner_capacity = False
        if any(a < 0 for _, a in terms):
            valid_inner_capacity = False
        inner_capacity += rhs

    print("\nAGGREGATE ENDPOINT LOWER BOUND")
    print(" inner bins:", len(inner_bins))
    print(" aggregate inner capacity:", fs(inner_capacity))
    print(" capacity rows valid for aggregation:", valid_inner_capacity)

    def endpoint_dp(option_charge, label):
        if not weight_invariant:
            print(f" {label}: skipped; item weights are not invariant")
            return None
        if not valid_inner_capacity:
            print(f" {label}: skipped; invalid inner capacity rows")
            return None
        if inner_capacity.denominator != 1:
            print(f" {label}: skipped; fractional aggregate capacity")
            return None
        if any(w.denominator != 1 for w in item_weight.values()):
            print(f" {label}: skipped; fractional item weights")
            return None

        forced_cost = Fraction(0)
        flexible = []
        class_hist = Counter()

        for i, opts in enumerate(items):
            opts_by_machine = defaultdict(list)
            for j in opts:
                o = owners(j)
                if len(o) == 1:
                    opts_by_machine[o[0]].append(j)

            allowed = frozenset(opts_by_machine)
            class_hist[tuple(sorted(allowed))] += 1

            endpoint_opts = [
                j for k in endpoint_machines
                for j in opts_by_machine.get(k, [])
            ]
            inner_opts = [
                j for k in inner_machines
                for j in opts_by_machine.get(k, [])
            ]

            if not endpoint_opts:
                raise RuntimeError(f"Item {i} has no endpoint alternative")

            e = min(option_charge[j] for j in endpoint_opts)

            if not inner_opts:
                forced_cost += e
            else:
                d = min(option_charge[j] for j in inner_opts)
                flexible.append((int(item_weight[i]), e, d, i))

        C = int(inner_capacity)

        # dp[w] = minimum endpoint charge when flexible items processed
        # and exactly w aggregate inner capacity has been used.
        dp = [None] * (C + 1)
        dp[0] = Fraction(0)

        for weight, endpoint_cost, inner_cost, item in flexible:
            ndp = [None] * (C + 1)
            for used, val in enumerate(dp):
                if val is None:
                    continue

                # Put item on an endpoint machine.
                z = val + endpoint_cost
                if ndp[used] is None or z < ndp[used]:
                    ndp[used] = z

                # Put item on one of the inner machines.
                if used + weight <= C:
                    z = val + inner_cost
                    if (
                        ndp[used + weight] is None
                        or z < ndp[used + weight]
                    ):
                        ndp[used + weight] = z
            dp = ndp

        flex_cost = min(z for z in dp if z is not None)
        best_weight = min(
            w for w, z in enumerate(dp) if z == flex_cost
        )
        lb = forced_cost + flex_cost

        print(f" {label}:")
        print("   forced endpoint items:",
              len(items) - len(flexible))
        print("   flexible items:", len(flexible))
        print("   forced contribution:", fs(forced_cost))
        print("   flexible DP contribution:", fs(flex_cost))
        print("   one minimizing aggregate inner weight:", best_weight)
        print("   endpoint-sum lower bound:", fs(lb))
        return lb

    base_lb = endpoint_dp(
        base_endpoint_charge,
        "assignment-cost-only bound"
    )
    charged_lb = endpoint_dp(
        charged_endpoint_charge,
        "assignment plus distributed OR-cost bound"
    )

    # ------------------------------------------------------------------
    # Lattice certificate
    # ------------------------------------------------------------------

    target = Fraction(2428)
    pred0 = strict_lattice_predecessor(target, load_steps[0])
    pred5 = strict_lattice_predecessor(target, load_steps[5])
    strict_endpoint_sum_cap = pred0 + pred5

    print("\nLATTICE CERTIFICATE TEST")
    print(" target:", fs(target))
    print(" largest load-0 lattice value strictly below target:",
          fs(pred0))
    print(" largest load-5 lattice value strictly below target:",
          fs(pred5))
    print(" endpoint-sum upper bound if objective < 2428:",
          fs(strict_endpoint_sum_cap))

    if charged_lb is not None:
        print(" charged endpoint-sum lower bound:", fs(charged_lb))
        if charged_lb > strict_endpoint_sum_cap:
            print(" PROVED: no feasible solution has objective < 2428.")
            print(" Together with the validated public solution, "
                  "the exact optimum is 2428.")
        else:
            print(" Remaining endpoint-sum gap:",
                  fs(strict_endpoint_sum_cap - charged_lb))
            print(" This is the amount that must be supplied by a "
                  "stronger OR allocation, individual-bin packing, "
                  "or difference-indicator reasoning.")
    else:
        print(" Charged lower bound unavailable; no certificate.")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
