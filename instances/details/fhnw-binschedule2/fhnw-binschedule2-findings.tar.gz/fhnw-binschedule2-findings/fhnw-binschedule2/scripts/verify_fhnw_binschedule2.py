#!/usr/bin/env python3
"""
Independent exact certificate verifier for fhnw-binschedule2.

No solver library is imported. The MPS and public solution are parsed
directly, and all arithmetic is exact Fraction arithmetic.

Certificate:
    mandatory endpoint base-plus-forced-OR cost = 4546
    common interval clique size                 = 35
    mandatory endpoint items                    = 76
    endpoint positions per side                 = 39

For endpoint k:
    D_k >= q_k + n_k - 40.

Therefore:
    D_0 + D_5 >= 35 + 76 - 80 = 31,
    L_0 + L_5 >= 4546 + 10*31 = 4856.

Every endpoint load is even. Thus objective < 2428 would imply
L_0 + L_5 <= 2426 + 2426 = 4852, a contradiction.
"""

import sys
import gzip
import re
import hashlib
from collections import defaultdict
from fractions import Fraction


EXPECTED_MPS_SHA256 = (
    "f3f816c31a5afcb288bd0aa84f9cce205d36890a5e46a6f2175c2fa35c8dac5f"
)
EXPECTED_SOL_SHA256 = (
    "faac8e4e4c8d8dd76c276ff7e9a4b2d96133117ef7214df8a6341af7f6d721c9"
)

EXPECTED_Q = (
    3, 4, 6, 7, 8, 9, 10, 11, 12, 14,
    17, 18, 19, 20, 21, 22, 23, 24, 25,
    28, 29, 30, 31, 32, 33, 34, 37, 38,
    39, 40, 41, 42, 43, 46, 48,
)
CLIQUE_WITNESS = Fraction(11, 2)


def fail(message):
    raise AssertionError(message)


def require(condition, message):
    if not condition:
        fail(message)


def number(token):
    token = token.strip().replace("D", "E").replace("d", "e")
    return Fraction(token)


def fs(value):
    value = Fraction(value)
    if value.denominator == 1:
        return str(value.numerator)
    return f"{value.numerator}/{value.denominator}"


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            block = f.read(1 << 20)
            if not block:
                break
            h.update(block)
    return h.hexdigest()


def open_text(path):
    if path.endswith(".gz"):
        return gzip.open(path, "rt", encoding="utf-8", errors="strict")
    return open(path, "rt", encoding="utf-8", errors="strict")


class MPS:
    pass


def parse_mps(path):
    """
    Parse the linear MPS features used by this instance.

    Supported:
      NAME, OBJSENSE, OBJNAME, ROWS, COLUMNS, RHS, BOUNDS, ENDATA.

    RANGES, semicontinuous variables, multiple RHS vectors and multiple
    bound vectors are rejected.
    """
    m = MPS()
    m.name = None
    m.objective_sense = "MIN"
    m.objective_name_hint = None

    m.row_order = []
    m.row_type = {}
    m.col_order = []
    m.coeff = defaultdict(lambda: defaultdict(Fraction))
    m.rhs = defaultdict(Fraction)

    m.integer = set()
    m.lower = {}
    m.upper = {}

    section = None
    integer_marker = False
    rhs_vector = None
    bound_vector = None

    known_sections = {
        "NAME", "OBJSENSE", "OBJNAME", "ROWS", "COLUMNS",
        "RHS", "RANGES", "BOUNDS", "ENDATA",
    }

    with open_text(path) as f:
        for line_number, raw in enumerate(f, 1):
            if not raw.strip() or raw.startswith("*"):
                continue

            fields = raw.split()
            first = fields[0].upper()

            if first in known_sections:
                section = first

                if first == "NAME":
                    if len(fields) >= 2:
                        m.name = fields[1]
                    continue

                if first == "ENDATA":
                    break

                if first == "RANGES":
                    fail("RANGES section is unsupported and was encountered")

                if first == "OBJSENSE" and len(fields) >= 2:
                    m.objective_sense = fields[1].upper()
                elif first == "OBJNAME" and len(fields) >= 2:
                    m.objective_name_hint = fields[1]
                continue

            if section == "OBJSENSE":
                require(len(fields) == 1,
                        f"Malformed OBJSENSE line {line_number}")
                m.objective_sense = fields[0].upper()
                continue

            if section == "OBJNAME":
                require(len(fields) == 1,
                        f"Malformed OBJNAME line {line_number}")
                m.objective_name_hint = fields[0]
                continue

            if section == "ROWS":
                require(len(fields) == 2,
                        f"Malformed ROWS line {line_number}")
                typ, row = fields[0].upper(), fields[1]
                require(typ in {"N", "E", "L", "G"},
                        f"Unsupported row type {typ}")
                require(row not in m.row_type,
                        f"Duplicate row name {row}")
                m.row_type[row] = typ
                m.row_order.append(row)
                continue

            if section == "COLUMNS":
                require(len(fields) >= 3,
                        f"Malformed COLUMNS line {line_number}")

                if (
                    len(fields) >= 3
                    and fields[1].strip("'\"").upper() == "MARKER"
                ):
                    marker = fields[2].strip("'\"").upper()
                    require(marker in {"INTORG", "INTEND"},
                            f"Unknown integer marker {marker}")
                    integer_marker = marker == "INTORG"
                    continue

                col = fields[0]
                if col not in m.col_order:
                    m.col_order.append(col)

                if integer_marker:
                    m.integer.add(col)

                rest = fields[1:]
                require(len(rest) % 2 == 0,
                        f"Odd COLUMNS row/value list at line {line_number}")

                for p in range(0, len(rest), 2):
                    row, value = rest[p], number(rest[p + 1])
                    require(row in m.row_type,
                            f"Unknown row {row} in COLUMNS")
                    m.coeff[row][col] += value
                continue

            if section == "RHS":
                require(len(fields) >= 3 and len(fields[1:]) % 2 == 0,
                        f"Malformed RHS line {line_number}")
                vector = fields[0]
                if rhs_vector is None:
                    rhs_vector = vector
                require(vector == rhs_vector,
                        "Multiple RHS vectors are not supported")

                for p in range(1, len(fields), 2):
                    row, value = fields[p], number(fields[p + 1])
                    require(row in m.row_type,
                            f"Unknown RHS row {row}")
                    m.rhs[row] += value
                continue

            if section == "BOUNDS":
                require(len(fields) >= 3,
                        f"Malformed BOUNDS line {line_number}")

                typ = fields[0].upper()
                vector = fields[1]
                col = fields[2]
                value = number(fields[3]) if len(fields) >= 4 else None

                if bound_vector is None:
                    bound_vector = vector
                require(vector == bound_vector,
                        "Multiple bound vectors are not supported")
                require(col in m.col_order,
                        f"Unknown bounded column {col}")

                if typ == "LO":
                    require(value is not None, "LO bound lacks a value")
                    m.lower[col] = value
                elif typ == "UP":
                    require(value is not None, "UP bound lacks a value")
                    m.upper[col] = value
                elif typ == "FX":
                    require(value is not None, "FX bound lacks a value")
                    m.lower[col] = value
                    m.upper[col] = value
                elif typ == "FR":
                    m.lower[col] = None
                    m.upper[col] = None
                elif typ == "MI":
                    m.lower[col] = None
                elif typ == "PL":
                    m.upper[col] = None
                elif typ == "BV":
                    m.integer.add(col)
                    m.lower[col] = Fraction(0)
                    m.upper[col] = Fraction(1)
                elif typ == "LI":
                    require(value is not None, "LI bound lacks a value")
                    m.integer.add(col)
                    m.lower[col] = value
                elif typ == "UI":
                    require(value is not None, "UI bound lacks a value")
                    m.integer.add(col)
                    m.upper[col] = value
                else:
                    fail(f"Unsupported bound type {typ}")
                continue

            fail(
                f"Data outside a recognized MPS section at line "
                f"{line_number}: {raw.rstrip()}"
            )

    # Standard MPS default bounds.
    for col in m.col_order:
        if col not in m.lower:
            m.lower[col] = Fraction(0)
        if col not in m.upper:
            m.upper[col] = None

    n_rows = [r for r in m.row_order if m.row_type[r] == "N"]
    if m.objective_name_hint is not None:
        require(m.objective_name_hint in n_rows,
                "OBJNAME does not name an N row")
        m.objective_row = m.objective_name_hint
    else:
        require(len(n_rows) == 1,
                f"Expected one objective N row, found {len(n_rows)}")
        m.objective_row = n_rows[0]

    require(m.objective_sense in {"MIN", "MINIMIZE"},
            f"Expected minimization, found {m.objective_sense}")

    return m


def parse_solution(path, columns):
    names = set(columns)
    values = {}
    objective_header = None

    with open_text(path) as f:
        text = f.read()

    xml_obj = re.search(
        r'objectiveValue\s*=\s*["\']([^"\']+)["\']',
        text, re.I
    )
    if xml_obj:
        objective_header = number(xml_obj.group(1))

    for match in re.finditer(
        r'<variable\b[^>]*\bname\s*=\s*["\']([^"\']+)["\']'
        r'[^>]*\bvalue\s*=\s*["\']([^"\']+)["\']',
        text, re.I
    ):
        name, value = match.group(1), number(match.group(2))
        require(name in names, f"Unknown solution variable {name}")
        if name in values:
            require(values[name] == value,
                    f"Conflicting values for {name}")
        values[name] = value

    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or line.startswith("*"):
            continue

        match = re.match(r"^=obj=\s+(\S+)", line, re.I)
        if match:
            objective_header = number(match.group(1))
            continue

        fields = line.split()
        if len(fields) >= 2 and fields[0] in names:
            value = number(fields[1])
            if fields[0] in values:
                require(values[fields[0]] == value,
                        f"Conflicting values for {fields[0]}")
            values[fields[0]] = value

    # Standard sparse-solution convention.
    return {col: values.get(col, Fraction(0)) for col in columns}, objective_header


def is_binary(m, col):
    return (
        col in m.integer
        and m.lower[col] == 0
        and m.upper[col] == 1
    )


def check_solution(m, x, objective_header):
    for col in m.col_order:
        value = x[col]
        lb, ub = m.lower[col], m.upper[col]

        if lb is not None:
            require(value >= lb, f"{col} violates lower bound")
        if ub is not None:
            require(value <= ub, f"{col} violates upper bound")
        if col in m.integer:
            require(value.denominator == 1,
                    f"{col} is not integral")

    for row in m.row_order:
        if m.row_type[row] == "N":
            continue

        lhs = sum(
            (a * x[col] for col, a in m.coeff[row].items()),
            Fraction(0)
        )
        rhs = m.rhs[row]
        typ = m.row_type[row]

        if typ == "E":
            require(lhs == rhs,
                    f"Solution violates equality {row}: {fs(lhs)} != {fs(rhs)}")
        elif typ == "L":
            require(lhs <= rhs,
                    f"Solution violates <= row {row}: {fs(lhs)} > {fs(rhs)}")
        elif typ == "G":
            require(lhs >= rhs,
                    f"Solution violates >= row {row}: {fs(lhs)} < {fs(rhs)}")

    objective_constant_rhs = m.rhs[m.objective_row]
    require(objective_constant_rhs == 0,
            "Nonzero objective-row RHS would require an offset convention")

    objective = sum(
        (
            a * x[col]
            for col, a in m.coeff[m.objective_row].items()
        ),
        Fraction(0)
    )

    require(objective == 2428,
            f"Public objective is {fs(objective)}, not 2428")
    if objective_header is not None:
        require(objective_header == objective,
                "Solution objective header disagrees with exact objective")

    return objective


def main():
    if len(sys.argv) != 3:
        print(
            "usage: python verify_fhnw_binschedule2.py "
            "instance.mps.gz public.sol.gz",
            file=sys.stderr
        )
        return 2

    mps_path, sol_path = sys.argv[1], sys.argv[2]

    require(sha256(mps_path) == EXPECTED_MPS_SHA256,
            "MPS SHA-256 does not match the audited instance")
    require(sha256(sol_path) == EXPECTED_SOL_SHA256,
            "solution SHA-256 does not match the audited public solution")

    m = parse_mps(mps_path)

    require(len(m.col_order) == 30973, "Unexpected column count")
    require(
        sum(m.row_type[r] != "N" for r in m.row_order) == 6503,
        "Unexpected constraint count"
    )

    # ------------------------------------------------------------
    # Set-partition items
    # ------------------------------------------------------------

    partition_rows = []
    items = []
    item_of = {}

    for row in m.row_order:
        if m.row_type[row] != "E" or m.rhs[row] != 1:
            continue

        terms = m.coeff[row]
        if terms and all(a == 1 and is_binary(m, col)
                         for col, a in terms.items()):
            item_number = len(items)
            options = tuple(terms)
            partition_rows.append(row)
            items.append(options)

            for col in options:
                require(col not in item_of,
                        f"{col} occurs in two partition rows")
                item_of[col] = item_number

    assignment = set(item_of)

    require(len(items) == 497, "Expected 497 partition items")
    require(
        sorted(len(options) for options in items)
        == [54] * 421 + [78] * 76,
        "Unexpected partition-row size distribution"
    )
    require(len(assignment) == 28662,
            "Expected 28,662 assignment variables")

    mandatory_global = [
        i for i, options in enumerate(items) if len(options) == 78
    ]
    require(len(mandatory_global) == 76,
            "Expected 76 endpoint-only items")

    mandatory_reduced = {
        global_item: reduced
        for reduced, global_item in enumerate(mandatory_global)
    }

    # ------------------------------------------------------------
    # Six objective epigraphs
    # ------------------------------------------------------------

    # The MPS explicitly stores four zero coefficients in the objective
    # row (C29125..C29128).  They are not mathematical objective terms.
    objective_terms = {
        col: value
        for col, value in m.coeff[m.objective_row].items()
        if value != 0
    }
    require(len(objective_terms) == 1,
            "Expected a single objective variable")

    objective_var, objective_coefficient = next(iter(objective_terms.items()))
    require(objective_coefficient == 1,
            "Objective-variable coefficient is not one")
    require(objective_var not in m.integer,
            "Objective variable should be continuous")

    epigraph_rows = [
        row for row in m.row_order
        if row != m.objective_row
        and objective_var in m.coeff[row]
    ]
    require(len(epigraph_rows) == 6,
            "Expected six objective epigraph rows")

    loads = []

    for row in epigraph_rows:
        typ = m.row_type[row]
        require(typ in {"L", "G"},
                f"Epigraph row {row} has wrong sense")

        ao = m.coeff[row][objective_var]
        sign = Fraction(1) if typ == "G" else Fraction(-1)
        A = sign * ao
        require(A > 0, f"{row} is not a lower epigraph")

        beta = sign * m.rhs[row] / A
        coeff = {}

        for col, a in m.coeff[row].items():
            if col == objective_var:
                continue
            value = -sign * a / A
            if value:
                coeff[col] = value

        require(beta == 0, f"{row} has nonzero epigraph constant")
        require(all(value >= 0 for value in coeff.values()),
                f"{row} has a negative load coefficient")
        loads.append((row, beta, coeff))

    def owners(col):
        return tuple(
            k for k in range(6) if loads[k][2].get(col, 0) != 0
        )

    for col in assignment:
        require(len(owners(col)) == 1,
                f"Assignment {col} lacks a unique load owner")

    # ------------------------------------------------------------
    # Capacity bins
    # ------------------------------------------------------------

    capacity_rows = []

    for row in m.row_order:
        if row in partition_rows or m.row_type[row] == "N":
            continue
        terms = m.coeff[row]
        if terms and all(col in assignment for col in terms):
            capacity_rows.append(row)

    require(len(capacity_rows) == 114,
            "Expected 114 capacity rows")

    bins = []
    bin_of = {}

    for b, row in enumerate(capacity_rows):
        options = tuple(m.coeff[row])
        bins.append(options)

        for col in options:
            require(col not in bin_of,
                    f"{col} occurs in two capacity rows")
            bin_of[col] = b

    require(set(bin_of) == assignment,
            "Capacity rows do not partition the assignment variables")

    bin_owner = {}
    for b, options in enumerate(bins):
        owner_sets = {owners(col) for col in options}
        require(len(owner_sets) == 1,
                f"Bin {b} has mixed load ownership")
        owner = next(iter(owner_sets))
        require(len(owner) == 1,
                f"Bin {b} has nonunique owner")
        bin_owner[b] = owner[0]

    bins_per_load = {
        k: sum(bin_owner[b] == k for b in bin_owner)
        for k in range(6)
    }
    endpoint_loads = tuple(
        k for k in range(6) if bins_per_load[k] == 39
    )
    require(len(endpoint_loads) == 2,
            "Expected exactly two 39-bin endpoint loads")
    e0, e1 = endpoint_loads

    require(
        sorted(bins_per_load.values()) == [9, 9, 9, 9, 39, 39],
        "Unexpected bin distribution among loads"
    )

    # Endpoint capacities must be unit set-packing rows.
    for b, row in enumerate(capacity_rows):
        if bin_owner[b] not in endpoint_loads:
            continue
        require(m.row_type[row] == "L" and m.rhs[row] == 1,
                f"Endpoint bin {row} is not a <= 1 row")
        require(all(a == 1 for a in m.coeff[row].values()),
                f"Endpoint bin {row} does not have unit coefficients")

    # Each mandatory item has 39 choices on each endpoint and nowhere else.
    for global_item in mandatory_global:
        counts = defaultdict(int)
        for col in items[global_item]:
            counts[owners(col)[0]] += 1
        require(
            counts == {e0: 39, e1: 39},
            f"Mandatory item {global_item} is not a 39+39 endpoint choice"
        )

    # ------------------------------------------------------------
    # OR variables M q - sum x >= 0
    # ------------------------------------------------------------

    or_support = {}
    or_row = {}
    membership = defaultdict(list)

    for row in m.row_order:
        if m.row_type[row] != "G" or m.rhs[row] != 0:
            continue

        terms = m.coeff[row]
        positive = [(col, a) for col, a in terms.items() if a > 0]
        negative = [(col, a) for col, a in terms.items() if a < 0]

        if len(positive) != 1 or not negative:
            continue

        q, M = positive[0]
        if q in assignment or not is_binary(m, q):
            continue
        if not all(col in assignment and a == -1
                   for col, a in negative):
            continue
        if M != len(negative):
            continue

        require(q not in or_support,
                f"OR variable {q} has multiple definition rows")

        support = tuple(col for col, _ in negative)
        support_bins = {bin_of[col] for col in support}
        require(len(support_bins) == 1,
                f"OR support {q} crosses capacity bins")

        or_support[q] = support
        or_row[q] = row
        for col in support:
            membership[col].append(q)

    require(len(or_support) == 1614,
            "Expected 1,614 OR variables")

    endpoint_or = {
        q for q in or_support if owners(q) in ((e0,), (e1,))
    }
    require(len(endpoint_or) == 1182,
            "Expected 1,182 endpoint-owned OR variables")

    for q in endpoint_or:
        k = owners(q)[0]
        require(loads[k][2][q] == 10,
                f"Endpoint OR variable {q} does not cost 10")

    # ------------------------------------------------------------
    # Window rows and item intervals
    # ------------------------------------------------------------

    window_rows = set()
    windows = []

    for position in range(len(m.row_order) - 1):
        upper_row = m.row_order[position]
        lower_row = m.row_order[position + 1]

        if (
            m.row_type[upper_row] != "L"
            or m.rhs[upper_row] != 20
            or m.row_type[lower_row] != "G"
            or m.rhs[lower_row] != 0
        ):
            continue

        upper_terms = m.coeff[upper_row]
        lower_terms = m.coeff[lower_row]

        upper_integer = [
            (col, a) for col, a in upper_terms.items()
            if col in m.integer
            and not is_binary(m, col)
        ]
        lower_integer = [
            (col, a) for col, a in lower_terms.items()
            if col in m.integer
            and not is_binary(m, col)
        ]

        upper_other = [
            (col, a) for col, a in upper_terms.items()
            if (col, a) not in upper_integer
        ]
        lower_other = [
            (col, a) for col, a in lower_terms.items()
            if (col, a) not in lower_integer
        ]

        if (
            len(upper_integer) != 1
            or upper_integer[0][1] != 1
            or len(lower_integer) != 1
            or lower_integer[0][1] != 1
            or len(upper_other) > 1
            or len(lower_other) > 1
        ):
            continue

        if upper_other:
            selector_upper, au = upper_other[0]
            if not (0 < au <= 20):
                continue
            h_upper = 20 - au
        else:
            selector_upper = None
            h_upper = Fraction(20)

        if lower_other:
            selector_lower, al = lower_other[0]
            if not (-20 <= al < 0):
                continue
            h_lower = -al
        else:
            selector_lower = None
            h_lower = Fraction(0)

        if h_upper != h_lower:
            continue

        if selector_upper is not None and selector_lower is not None:
            if selector_upper != selector_lower:
                continue
            selector = selector_upper
        elif selector_upper is not None:
            selector = selector_upper
        elif selector_lower is not None:
            selector = selector_lower
        else:
            continue

        if selector not in assignment and selector not in or_support:
            continue

        require(upper_row not in window_rows,
                f"Repeated window row {upper_row}")
        require(lower_row not in window_rows,
                f"Repeated window row {lower_row}")

        windows.append((
            selector,
            h_upper,
            upper_integer[0][0],
            lower_integer[0][0],
            upper_row,
            lower_row,
        ))
        window_rows.add(upper_row)
        window_rows.add(lower_row)

    require(len(windows) == 1908,
            "Expected 1,908 selector windows")
    require(len(window_rows) == 3816,
            "Expected 3,816 window rows")

    option_h = defaultdict(list)
    bin_timing_pair = {}

    for selector, h, left, right, upper_row, lower_row in windows:
        support = (
            or_support[selector]
            if selector in or_support
            else (selector,)
        )

        support_bins = {bin_of[col] for col in support}
        require(len(support_bins) == 1,
                f"Window selector {selector} crosses bins")
        b = next(iter(support_bins))

        old = bin_timing_pair.get(b)
        if old is None:
            bin_timing_pair[b] = (left, right)
        else:
            require(old == (left, right),
                    f"Bin {b} has inconsistent timing nodes")

        for col in support:
            option_h[col].append(h)

    # ------------------------------------------------------------
    # Difference indicators and endpoint paths
    # ------------------------------------------------------------

    difference_rows = defaultdict(list)

    for row in m.row_order:
        if m.rhs[row] != 0 or len(m.coeff[row]) != 3:
            continue

        terms = m.coeff[row]
        nonbinary_integer = [
            (col, a) for col, a in terms.items()
            if col in m.integer and not is_binary(m, col)
        ]
        binaries = [
            (col, a) for col, a in terms.items()
            if is_binary(m, col) and col not in assignment
        ]

        if len(nonbinary_integer) != 2 or len(binaries) != 1:
            continue

        minus = [col for col, a in nonbinary_integer if a == -1]
        plus = [col for col, a in nonbinary_integer if a == 1]
        if len(minus) != 1 or len(plus) != 1:
            continue

        z, az = binaries[0]
        if abs(az) != 20:
            continue

        key = (minus[0], plus[0], z)
        difference_rows[key].append(row)

    differences = []
    for (u, v, z), pair_rows in difference_rows.items():
        if len(pair_rows) != 2:
            continue

        signatures = {
            (m.row_type[row], m.coeff[row][z])
            for row in pair_rows
        }
        if signatures != {("G", Fraction(20)), ("L", Fraction(-20))}:
            continue

        differences.append((u, v, z, tuple(pair_rows)))

    require(len(differences) == 228,
            "Expected 228 difference indicators")

    endpoint_path_edges = {e0: [], e1: []}

    for u, v, z, pair_rows in differences:
        owner = owners(z)
        if owner not in ((e0,), (e1,)):
            continue

        k = owner[0]
        require(loads[k][2][z] == 10,
                f"Endpoint difference variable {z} does not cost 10")

        candidates = []
        endpoint_bins = [
            b for b in bin_owner if bin_owner[b] == k
        ]

        for b in endpoint_bins:
            left_b, right_b = bin_timing_pair[b]
            for c in endpoint_bins:
                if b == c:
                    continue
                left_c, right_c = bin_timing_pair[c]

                if right_b == u and left_c == v:
                    candidates.append((b, c))
                elif right_b == v and left_c == u:
                    candidates.append((b, c))

        require(len(candidates) == 1,
                f"Difference variable {z} does not identify one path edge")
        b, c = candidates[0]
        endpoint_path_edges[k].append((b, c, z))

    path_orders = {}
    path_difference_vars = {}

    for k in endpoint_loads:
        endpoint_bins = {
            b for b in bin_owner if bin_owner[b] == k
        }
        edges = endpoint_path_edges[k]

        require(len(endpoint_bins) == 39,
                f"Endpoint {k} does not have 39 bins")
        require(len(edges) == 38,
                f"Endpoint {k} does not have 38 path edges")

        successor = {}
        predecessor = {}
        edge_var = {}

        for b, c, z in edges:
            require(b not in successor,
                    f"Endpoint path branches after bin {b}")
            require(c not in predecessor,
                    f"Endpoint path merges at bin {c}")
            successor[b] = c
            predecessor[c] = b
            edge_var[(b, c)] = z

        starts = endpoint_bins - set(predecessor)
        require(len(starts) == 1,
                f"Endpoint {k} does not have one path start")

        order = []
        b = next(iter(starts))
        while True:
            require(b not in order,
                    f"Endpoint {k} path contains a cycle")
            order.append(b)
            if b not in successor:
                break
            b = successor[b]

        require(len(order) == 39,
                f"Endpoint {k} path does not cover all 39 bins")

        path_orders[k] = tuple(order)
        path_difference_vars[k] = tuple(
            edge_var[(order[p], order[p + 1])]
            for p in range(38)
        )

    # ------------------------------------------------------------
    # Fixed assignment-plus-OR costs and common intervals
    # ------------------------------------------------------------

    item_cost = {}
    item_interval = {}

    for global_item in mandatory_global:
        reduced = mandatory_reduced[global_item]
        option_costs = []
        option_intervals = []

        for col in items[global_item]:
            k = owners(col)[0]
            require(k in endpoint_loads,
                    "Mandatory assignment has a nonendpoint owner")
            require(option_h[col],
                    f"Mandatory option {col} has no active h values")

            # Every OR containing col is forced when col=1.
            forced_or_cost = Fraction(0)
            for q in membership[col]:
                require(owners(q) == (k,),
                        f"OR {q} and supported assignment have different owners")
                forced_or_cost += loads[k][2][q]

            combined_cost = loads[k][2][col] + forced_or_cost
            interval = (min(option_h[col]), max(option_h[col]))

            option_costs.append(combined_cost)
            option_intervals.append(interval)

        require(len(option_costs) == 78,
                "Mandatory item lacks 78 options")
        require(len(set(option_costs)) == 1,
                f"Item {reduced} has position- or endpoint-dependent cost")
        require(len(set(option_intervals)) == 1,
                f"Item {reduced} has position- or endpoint-dependent interval")

        item_cost[reduced] = option_costs[0]
        item_interval[reduced] = option_intervals[0]

    fixed_cost = sum(item_cost.values(), Fraction(0))
    require(fixed_cost == 4546,
            f"Fixed endpoint cost is {fs(fixed_cost)}, not 4546")

    # Check the explicit common clique.
    Q = tuple(EXPECTED_Q)
    require(len(Q) == 35 and len(set(Q)) == 35,
            "Hard-coded clique does not contain 35 distinct items")
    require(all(0 <= i < 76 for i in Q),
            "Clique index is outside 0..75")

    for i in Q:
        lower, upper = item_interval[i]
        require(
            lower < CLIQUE_WITNESS < upper,
            f"Item {i}, interval [{fs(lower)},{fs(upper)}], "
            f"does not contain 11/2 in its interior"
        )

    # ------------------------------------------------------------
    # Endpoint-load parity and exact public feasibility
    # ------------------------------------------------------------

    for k in endpoint_loads:
        beta = loads[k][1]
        require(beta.denominator == 1 and beta.numerator % 2 == 0,
                f"Endpoint load {k} has a noneven constant")

        for col, coefficient in loads[k][2].items():
            require(col in m.integer,
                    f"Endpoint load {k} contains continuous variable {col}")
            require(
                coefficient.denominator == 1
                and coefficient.numerator % 2 == 0,
                f"Endpoint coefficient of {col} is not even"
            )

    solution, objective_header = parse_solution(sol_path, m.col_order)
    objective = check_solution(m, solution, objective_header)

    public_loads = []
    for row, beta, coefficients in loads:
        value = beta + sum(
            (a * solution[col] for col, a in coefficients.items()),
            Fraction(0)
        )
        public_loads.append(value)

    require(all(value <= solution[objective_var]
                for value in public_loads),
            "Public objective variable does not dominate every load")
    require(public_loads[e0] == 2428,
            "First public endpoint load is not 2428")
    require(public_loads[e1] == 2428,
            "Second public endpoint load is not 2428")

    # Optional exact decomposition of the public endpoint loads.
    public_endpoint_decomposition = {}

    for k in endpoint_loads:
        base = sum(
            (
                loads[k][2].get(col, 0) * solution[col]
                for col in assignment
            ),
            Fraction(0)
        )
        or_cost = sum(
            (
                loads[k][2].get(q, 0) * solution[q]
                for q in or_support
            ),
            Fraction(0)
        )
        difference_cost = sum(
            (
                loads[k][2].get(z, 0) * solution[z]
                for z in path_difference_vars[k]
            ),
            Fraction(0)
        )
        public_endpoint_decomposition[k] = (
            base, or_cost, difference_cost
        )

    # ------------------------------------------------------------
    # Print the independently checked certificate
    # ------------------------------------------------------------

    print("INDEPENDENT EXACT AUDIT: PASSED")
    print(" MPS parser: direct text parser; exact Fraction arithmetic")
    print(" solver or presolver calls: 0")
    print(" original rows checked against public solution: 6503")
    print(" public objective:", fs(objective))
    print(" all public bounds, integrality conditions and rows: exact")

    print("\nENDPOINT STRUCTURE")
    print(" endpoint load indices:", e0, e1)
    print(" endpoint positions:", 39, 39)
    print(" mandatory endpoint-only items:", 76)
    print(" endpoint OR variables:", len(endpoint_or))
    print(" endpoint path difference variables:", 38, 38)
    print(" fixed mandatory assignment-plus-forced-OR cost:",
          fs(fixed_cost))

    print("\nEXPLICIT COMMON CLIQUE")
    print(" witness:", fs(CLIQUE_WITNESS))
    print(" reduced item indices:")
    print(" ", list(Q))
    print(" detailed members:")
    for i in Q:
        global_item = mandatory_global[i]
        row = partition_rows[global_item]
        lower, upper = item_interval[i]
        print(
            f"  reduced={i:2d} global_item={global_item:3d} "
            f"partition_row={row} "
            f"interval=[{fs(lower)},{fs(upper)}] "
            f"cost={fs(item_cost[i])}"
        )

    print("\nPUBLIC ENDPOINT LOADS")
    for k in endpoint_loads:
        base, or_cost, diff_cost = public_endpoint_decomposition[k]
        print(
            f" endpoint {k}: base={fs(base)} "
            f"OR={fs(or_cost)} difference={fs(diff_cost)} "
            f"total={fs(public_loads[k])}"
        )

    clique_size = len(Q)
    mandatory_count = len(mandatory_global)
    difference_lb = clique_size + mandatory_count - 2 * 40
    endpoint_sum_lb = fixed_cost + 10 * difference_lb
    strict_endpoint_cap = 2 * 2426

    require(difference_lb == 31,
            "Unexpected difference-indicator lower bound")
    require(endpoint_sum_lb == 4856,
            "Unexpected endpoint-sum lower bound")
    require(strict_endpoint_cap == 4852,
            "Unexpected strict endpoint cap")
    require(endpoint_sum_lb > strict_endpoint_cap,
            "Certificate does not separate the strict target")

    print("\nCERTIFICATE")
    print(
        " For endpoint k, deleting its 39-n_k positions not occupied by"
    )
    print(
        " mandatory items and cutting at its D_k active path differences"
    )
    print(
        " partitions the selected intervals into at most"
        " 40-n_k+D_k chains."
    )
    print(
        " A chain contains at most one member of Q because all Q intervals"
    )
    print(
        " contain 11/2 in their interiors and are therefore pairwise"
        " incomparable."
    )
    print(" Hence D_k >= q_k+n_k-40.")
    print(
        f" Summing: D_0+D_1 >= {clique_size}+{mandatory_count}-80"
        f" = {difference_lb}."
    )
    print(
        f" Endpoint sum >= {fs(fixed_cost)} + 10*{difference_lb}"
        f" = {fs(endpoint_sum_lb)}."
    )
    print(
        " Every endpoint-load coefficient is even, so objective < 2428"
    )
    print(
        f" would imply endpoint sum <= 2426+2426"
        f" = {strict_endpoint_cap}."
    )
    print(
        f" Since {endpoint_sum_lb} > {strict_endpoint_cap}, objective"
        " < 2428 is impossible."
    )
    print(" The exactly feasible public solution has objective 2428.")
    print("\nPROVED EXACT OPTIMUM: 2428")

    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except AssertionError as exc:
        print("AUDIT FAILED:", exc, file=sys.stderr)
        raise SystemExit(1)
