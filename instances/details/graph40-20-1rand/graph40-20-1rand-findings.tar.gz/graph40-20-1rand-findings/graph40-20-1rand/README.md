# `graph40-20-1rand`

## Result

The MPS is reconstructed as a packing of pairwise edge-disjoint nonempty cuts
in a 40-vertex graph. The official packing consists of 14 singleton cuts and
one two-vertex cut. Exact maximum-independent-set enumeration finds an
independent set of size **15**, which yields a simpler verified packing of 15
singleton cuts and objective **-15**.

The associated paper reports 15 as optimal for the intended random graph, but
does not publish the raw graph or a replayable certificate. The byte-level
identity of that graph and this MPS is therefore not established. This
repository records a verified primal value 15, not a local proof of global
optimality.

## Provenance

- Compressed MPS SHA-256: `3B5D4B0A62C884D446ECFB97049DA2FAB81CD949B55189871E9413AF3A0BC649`
- Official compressed solution SHA-256: `00F8746876B69A23856BE9C8B8A3990D4EB4885737715A8353F8A47112AE52A9`
- Canonical unique-graph SHA-256: `7B62185C829BDB6D4837893CCB7A1A60D1B5733B9A32728485577F135821D613`
- [MIPLIB instance page](https://miplib.zib.de/instance_details_graph40-20-1rand.html)

The full reconstruction and evidence boundary are in the
[cross-instance investigation](../../docs/top15-structural-investigation-2026-09-05.md#7-graph40-20-1rand).
