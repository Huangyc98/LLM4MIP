# Package manifest: graph40-20-1rand

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 2
Excluded source files: 1

## Included files

- `README.md`
- `solutions/official-15.sol.gz`

## Excluded files

- `input/graph40-20-1rand.mps.gz (3013954 bytes; raw benchmark input; sha256 3b5d4b0a62c884d446ecfb97049da2fab81cd949b55189871e9413af3a0bc649)`
