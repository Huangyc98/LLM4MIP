# Sources

- MIPLIB official instance page: https://miplib.zib.de/instance_details_fhnw-schedule-pairb200.html
- MIPLIB describes the instance as continuous-time project selection/scheduling with project values, release dates and deadlines, and states that Pair A, Pair B and Slot are three formulations of the same problem.
- The official page reports 40,200 variables, 99,554 constraints and a tolerance-accepted best objective of `-19.24094384259708`.
- MIPLIB provides no bibliographic reference for this submitted industrial instance, so the report does not invent one.
- Matthias Mnich and Andreas Wiese, “Single-Machine Scheduling to Minimize the Number of Tardy Jobs with Release Dates,” IPEC 2024: https://drops.dagstuhl.de/storage/00lipics/lipics-vol321-ipec2024/LIPIcs.IPEC.2024.19/LIPIcs.IPEC.2024.19.pdf . This is a modern reference for the closely related single-machine selection/scheduling class with release dates.
- Claude Le Pape, “Constraint-Based Scheduling”: https://www.math.unipd.it/~mpini/fse-doc/scheduling/lepape.pdf . This supplies background for interval/energetic reasoning; the exact inequalities used here are derived and audited directly from this instance rather than copied from software output.
