from __future__ import annotations

import argparse
import gzip
import json
import math
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def read_solution(path: Path) -> dict[str, float]:
    opener = gzip.open if path.suffix == ".gz" else open
    values: dict[str, float] = {}
    with opener(path, "rt", encoding="utf-8", errors="replace") as stream:
        for raw in stream:
            fields = raw.split()
            if len(fields) < 2 or fields[0].startswith("#"):
                continue
            try:
                values[fields[0]] = float(fields[1])
            except ValueError:
                pass
    return values


def pair_offset(n: int, i: int, j: int) -> int:
    return i * (2 * n - i - 1) // 2 + j - i - 1


def recover_pairb(model: gp.Model, n: int) -> tuple[list[float], list[float], list[float], int]:
    variables = model.getVars()
    constraints = model.getConstrs()
    pairs = n * (n - 1) // 2
    if len(variables) != 2 * n + 2 * pairs:
        raise RuntimeError(f"unexpected Pair-B variable layout: {len(variables)}")
    prefix = len(constraints) - 5 * pairs
    if prefix < 0:
        raise RuntimeError("negative Pair-B row prefix")

    releases = [float(variables[n + i].LB) for i in range(n)]
    latest_starts = [float(variables[n + i].UB) for i in range(n)]
    durations: list[float] = []
    for i in range(n - 1):
        offset = pair_offset(n, i, i + 1)
        durations.append(2.0 - float(constraints[prefix + 5 * offset + 3].RHS))
    offset = pair_offset(n, n - 2, n - 1)
    durations.append(4.0 - float(constraints[prefix + 5 * offset + 4].RHS))
    if min(durations) <= 0.0 or max(durations) >= 1.0:
        raise RuntimeError(f"invalid recovered durations: {min(durations)}..{max(durations)}")
    return releases, durations, latest_starts, prefix


def fixed_selection_rows(model: gp.Model, n: int, prefix: int) -> list[dict[str, float | int | str]]:
    fixed: list[dict[str, float | int | str]] = []
    for constraint in model.getConstrs()[:prefix]:
        row = model.getRow(constraint)
        if row.size() != 1:
            raise RuntimeError(f"unexpected prefix row {constraint.ConstrName} with {row.size()} terms")
        variable = row.getVar(0)
        coefficient = float(row.getCoeff(0))
        if variable.index >= n or constraint.Sense != GRB.EQUAL or coefficient == 0.0:
            raise RuntimeError(f"unexpected fixed row {constraint.ConstrName}")
        fixed.append(
            {
                "row": constraint.ConstrName,
                "job": variable.index,
                "coefficient": coefficient,
                "rhs": float(constraint.RHS),
                "value": float(constraint.RHS) / coefficient,
            }
        )
    return fixed


def audit_solution(model: gp.Model, values: dict[str, float]) -> dict[str, float | int]:
    variables = model.getVars()
    vector = [float(values.get(variable.VarName, 0.0)) for variable in variables]
    max_bound = max_integrality = max_row = 0.0
    bound_count = integrality_count = row_count = 0
    for variable, value in zip(variables, vector):
        violation = max(float(variable.LB) - value, value - float(variable.UB), 0.0)
        max_bound = max(max_bound, violation)
        bound_count += violation > 1e-9
        if variable.VType in (GRB.BINARY, GRB.INTEGER, GRB.SEMIINT):
            violation = abs(value - round(value))
            max_integrality = max(max_integrality, violation)
            integrality_count += violation > 1e-9
    for constraint in model.getConstrs():
        row = model.getRow(constraint)
        activity = math.fsum(float(row.getCoeff(k)) * vector[row.getVar(k).index] for k in range(row.size()))
        if constraint.Sense == GRB.LESS_EQUAL:
            violation = max(activity - float(constraint.RHS), 0.0)
        elif constraint.Sense == GRB.GREATER_EQUAL:
            violation = max(float(constraint.RHS) - activity, 0.0)
        else:
            violation = abs(activity - float(constraint.RHS))
        max_row = max(max_row, violation)
        row_count += violation > 1e-9
    objective = float(model.ObjCon) + math.fsum(float(variable.Obj) * vector[variable.index] for variable in variables)
    return {
        "objective": objective,
        "max_bound_violation": max_bound,
        "bound_violations_over_1e-9": bound_count,
        "max_integrality_violation": max_integrality,
        "integrality_violations_over_1e-9": integrality_count,
        "max_row_violation": max_row,
        "row_violations_over_1e-9": row_count,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("feasible_solution", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("--jobs", type=int, required=True)
    parser.add_argument("--time-limit", type=float, default=1800.0)
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--seed", type=int, default=41)
    parser.add_argument("--deadline-safety", type=float, default=1e-12)
    args = parser.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)
    original = gp.read(str(args.mps))
    original_variables = original.getVars()
    releases, durations, latest_starts, prefix = recover_pairb(original, args.jobs)
    deadlines = [latest_starts[i] + durations[i] for i in range(args.jobs)]
    fixed_rows = fixed_selection_rows(original, args.jobs, prefix)
    fixed_jobs = {int(item["job"]) for item in fixed_rows}
    eligible = [i for i in range(args.jobs) if i not in fixed_jobs]

    # D=max d_i yields a globally valid relaxation even if common deadlines
    # differ by input-rounding noise: every job released at/after t must still
    # place all of its processing inside [t,D].
    recovered_deadline_max = max(deadlines[i] for i in eligible)
    common_deadline = recovered_deadline_max + args.deadline_safety
    deadline_spread = recovered_deadline_max - min(deadlines[i] for i in eligible)

    incumbent = read_solution(args.feasible_solution)
    incumbent_audit = audit_solution(original, incumbent)
    incumbent_objective = float(incumbent_audit["objective"])

    master = gp.Model(f"pairb{args.jobs}_common_deadline_master")
    master.Params.LogFile = str(args.output_dir / "common-deadline-master.log")
    master.Params.Threads = args.threads
    master.Params.Seed = args.seed
    master.Params.TimeLimit = args.time_limit
    master.Params.MIPGap = 0.0
    master.Params.MIPGapAbs = 0.0
    master.Params.FeasibilityTol = 1e-9
    master.Params.IntFeasTol = 1e-9
    master.Params.NumericFocus = 3
    z = [
        master.addVar(vtype=GRB.BINARY, obj=float(original_variables[i].Obj), name=original_variables[i].VarName)
        for i in range(args.jobs)
    ]
    for item in fixed_rows:
        index = int(item["job"])
        master.addConstr(float(item["coefficient"]) * z[index] == float(item["rhs"]), name=f"fixed_{item['row']}")

    thresholds = sorted({releases[i] for i in eligible})
    for cut_index, threshold in enumerate(thresholds):
        master.addConstr(
            gp.quicksum(durations[i] * z[i] for i in eligible if releases[i] >= threshold)
            <= common_deadline - threshold,
            name=f"suffix_capacity_{cut_index}",
        )
    for i in range(args.jobs):
        z[i].Start = round(incumbent.get(original_variables[i].VarName, 0.0))
    master.update()
    proof_model = args.output_dir / "common-deadline-master.mps.gz"
    master.write(str(proof_model))
    master.optimize()

    selected = [i for i in range(args.jobs) if master.SolCount and z[i].X > 0.5]
    selected_deadline_max = max((deadlines[i] for i in selected), default=None)
    report = {
        "instance": original.ModelName,
        "method": "selection relaxation with complete release-suffix capacity inequalities for the common-deadline eligible jobs",
        "proof_logic": "For every threshold t, all selected jobs with r_i >= t must execute inside [t,D_safe], hence sum p_i z_i <= D_safe-t. D_safe is no smaller than every recovered eligible completion deadline, so the master is a relaxation of the official MPS. If its certified lower bound equals an independently audited feasible objective, that objective is globally optimal.",
        "jobs": args.jobs,
        "eligible_jobs": len(eligible),
        "fixed_jobs": len(fixed_jobs),
        "fixed_rows": fixed_rows,
        "completion_deadline_formula": "deadline_i = upper_bound(start_i) + processing_time_i",
        "eligible_deadline_min": min(deadlines[i] for i in eligible),
        "eligible_deadline_max": recovered_deadline_max,
        "eligible_deadline_spread": deadline_spread,
        "deadline_safety_added": args.deadline_safety,
        "safe_common_deadline": common_deadline,
        "solver_parameters": {
            "time_limit_seconds": args.time_limit,
            "threads": args.threads,
            "seed": args.seed,
            "mip_gap": 0.0,
            "mip_gap_abs": 0.0,
            "feasibility_tolerance": 1e-9,
            "integrality_tolerance": 1e-9,
            "numeric_focus": 3,
        },
        "suffix_capacity_constraints": len(thresholds),
        "master_model": str(proof_model.resolve()),
        "status": int(master.Status),
        "status_name": {GRB.OPTIMAL: "OPTIMAL", GRB.TIME_LIMIT: "TIME_LIMIT", GRB.INFEASIBLE: "INFEASIBLE"}.get(master.Status, str(master.Status)),
        "runtime_seconds": master.Runtime,
        "nodes": master.NodeCount,
        "solutions": master.SolCount,
        "master_objective": master.ObjVal if master.SolCount else None,
        "master_bound": master.ObjBound,
        "master_gap": master.MIPGap if master.SolCount else None,
        "master_selected_jobs": selected,
        "master_selected_deadline_max": selected_deadline_max,
        "feasible_solution": str(args.feasible_solution.resolve()),
        "feasible_solution_audit": incumbent_audit,
        "incumbent_objective": incumbent_objective,
        "bound_matches_feasible_objective": abs(master.ObjBound - incumbent_objective) <= 1e-8,
        "global_optimality_proved": bool(
            master.Status == GRB.OPTIMAL
            and abs(master.ObjBound - incumbent_objective) <= 1e-8
            and int(incumbent_audit["row_violations_over_1e-9"]) == 0
            and int(incumbent_audit["bound_violations_over_1e-9"]) == 0
            and int(incumbent_audit["integrality_violations_over_1e-9"]) == 0
        ),
    }
    (args.output_dir / "common-deadline-master-result.json").write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
