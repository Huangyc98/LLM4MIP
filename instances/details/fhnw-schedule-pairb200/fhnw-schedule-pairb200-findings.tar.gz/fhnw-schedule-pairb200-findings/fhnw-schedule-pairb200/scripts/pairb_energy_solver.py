from __future__ import annotations

import argparse
import gzip
import json
import math
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def read_values(path: Path) -> dict[str, float]:
    opener = gzip.open if path.suffix == ".gz" else open
    values: dict[str, float] = {}
    with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
        for raw in handle:
            if not raw.strip() or raw.lstrip().startswith("#"):
                continue
            fields = raw.split()
            if len(fields) >= 2:
                try:
                    values[fields[0]] = float(fields[1])
                except ValueError:
                    pass
    return values


def pair_offset(n: int, i: int, j: int) -> int:
    return i * (2 * n - i - 1) // 2 + (j - i - 1)


def recover_pairb_data(model: gp.Model, n: int) -> tuple[list[float], list[float], list[float]]:
    variables = model.getVars()
    constraints = model.getConstrs()
    pair_count = n * (n - 1) // 2
    if len(variables) != 2 * n + 2 * pair_count:
        raise RuntimeError("unexpected Pair-B layout")
    releases = [variables[n + i].LB for i in range(n)]
    latest = [variables[n + i].UB for i in range(n)]
    durations: list[float] = []
    for i in range(n - 1):
        off = pair_offset(n, i, i + 1)
        rhs = constraints[54 + 5 * off + 3].RHS
        durations.append(2.0 - rhs)
    last_off = pair_offset(n, n - 2, n - 1)
    durations.append(4.0 - constraints[54 + 5 * last_off + 4].RHS)
    if min(durations) <= 0 or max(durations) >= 1:
        raise RuntimeError(f"invalid recovered durations: {min(durations)}, {max(durations)}")
    return releases, durations, latest


def feasible_before(i: int, j: int, releases: list[float], durations: list[float], deadlines: list[float]) -> bool:
    completion_i = releases[i] + durations[i]
    completion_j = max(releases[j], completion_i) + durations[j]
    return completion_i <= deadlines[i] + 1e-12 and completion_j <= deadlines[j] + 1e-12


def energy_coefficients(a: float, b: float, releases: list[float], durations: list[float], deadlines: list[float]) -> list[float]:
    result = []
    for release, duration, deadline in zip(releases, durations, deadlines):
        outside_left = max(0.0, a - release)
        outside_right = max(0.0, deadline - b)
        result.append(max(0.0, duration - outside_left - outside_right))
    return result


def audit_original(model: gp.Model) -> dict[str, float | int]:
    max_bound = max_integer = max_row = 0.0
    row_count = 0
    for variable in model.getVars():
        max_bound = max(max_bound, variable.LB - variable.X, variable.X - variable.UB, 0.0)
        if variable.VType in (GRB.BINARY, GRB.INTEGER, GRB.SEMIINT):
            max_integer = max(max_integer, abs(variable.X - round(variable.X)))
    for constraint in model.getConstrs():
        row = model.getRow(constraint)
        activity = math.fsum(row.getCoeff(k) * row.getVar(k).X for k in range(row.size()))
        if constraint.Sense == GRB.LESS_EQUAL:
            violation = max(activity - constraint.RHS, 0.0)
        elif constraint.Sense == GRB.GREATER_EQUAL:
            violation = max(constraint.RHS - activity, 0.0)
        else:
            violation = abs(activity - constraint.RHS)
        max_row = max(max_row, violation)
        row_count += violation > 1e-9
    return {
        "max_bound_violation": max_bound,
        "max_integrality_violation": max_integer,
        "max_row_violation": max_row,
        "row_violations_over_1e_9": row_count,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("start", type=Path)
    parser.add_argument("summary", type=Path)
    parser.add_argument("log", type=Path)
    parser.add_argument("solution_out", type=Path)
    parser.add_argument("--time-limit", type=float, default=900.0)
    parser.add_argument("--threads", type=int, default=2)
    parser.add_argument("--max-energy-cuts", type=int, default=6000)
    parser.add_argument("--lp-rounds", type=int, default=4)
    args = parser.parse_args()

    model = gp.read(str(args.mps))
    variables = model.getVars()
    n = 200
    releases, durations, latest = recover_pairb_data(model, n)
    deadlines = [latest[i] + durations[i] for i in range(n)]
    start = read_values(args.start)
    for variable in variables:
        if variable.VarName in start:
            variable.Start = start[variable.VarName]

    conflicts = []
    for i in range(n):
        for j in range(i + 1, n):
            if not feasible_before(i, j, releases, durations, deadlines) and not feasible_before(j, i, releases, durations, deadlines):
                model.addConstr(variables[i] + variables[j] <= 1, name=f"pair_conflict_{i}_{j}")
                conflicts.append((i, j))
    model.update()

    endpoints = sorted(set(releases + deadlines))
    interval_data = []
    for left, a in enumerate(endpoints):
        for b in endpoints[left + 1 :]:
            coeffs = energy_coefficients(a, b, releases, durations, deadlines)
            if sum(value > 1e-12 for value in coeffs) >= 2:
                interval_data.append((a, b, coeffs))

    relaxation = model.relax()
    relaxation.Params.OutputFlag = 0
    relaxation.Params.Method = 1
    relaxation.Params.Threads = args.threads
    added_keys: set[tuple[float, float]] = set()
    energy_records = []
    remaining = args.max_energy_cuts
    for round_index in range(args.lp_rounds):
        relaxation.optimize()
        z = [relaxation.getVars()[i].X for i in range(n)]
        violations = []
        for a, b, coeffs in interval_data:
            key = (a, b)
            if key in added_keys:
                continue
            violation = math.fsum(coeffs[i] * z[i] for i in range(n)) - (b - a)
            if violation > 1e-8:
                norm = math.sqrt(math.fsum(value * value for value in coeffs))
                violations.append((violation / max(norm, 1e-12), violation, a, b, coeffs))
        violations.sort(reverse=True, key=lambda row: row[0])
        take = min(remaining, 1500, len(violations))
        selected = violations[:take]
        for _, violation, a, b, coeffs in selected:
            expression_mip = gp.LinExpr()
            expression_lp = gp.LinExpr()
            for i, coefficient in enumerate(coeffs):
                if coefficient > 1e-12:
                    expression_mip.add(variables[i], coefficient)
                    expression_lp.add(relaxation.getVars()[i], coefficient)
            rhs = (b - a) + 1e-11
            model.addConstr(expression_mip <= rhs, name=f"energy_{len(added_keys)}")
            relaxation.addConstr(expression_lp <= rhs)
            added_keys.add((a, b))
            energy_records.append({"a": a, "b": b, "initial_violation": violation})
        remaining -= take
        if take == 0 or remaining == 0:
            break
    model.update()

    args.log.parent.mkdir(parents=True, exist_ok=True)
    model.Params.LogFile = str(args.log)
    model.Params.TimeLimit = args.time_limit
    model.Params.Threads = args.threads
    model.Params.MIPFocus = 3
    model.Params.Cuts = 3
    model.Params.Heuristics = 0.1
    model.Params.FeasibilityTol = 1e-9
    model.Params.IntFeasTol = 1e-9
    model.Params.MIPGap = 1e-9
    proof_model = args.summary.with_name(args.summary.stem + "-proof.mps.gz")
    model.write(str(proof_model))
    model.optimize()

    report = {
        "instance": "fhnw-schedule-pairb200",
        "method": "Pair-B plus explicit pair conflicts and iteratively separated energetic cuts",
        "recovered": {
            "jobs": n,
            "release_min": min(releases),
            "deadline_max": max(deadlines),
            "duration_sum": sum(durations),
            "duration_min": min(durations),
            "duration_max": max(durations),
        },
        "pair_conflict_cuts": len(conflicts),
        "candidate_intervals": len(interval_data),
        "energetic_cuts": len(added_keys),
        "energy_cut_intervals": energy_records,
        "strongest_lp_violations": sorted(energy_records, key=lambda row: row["initial_violation"], reverse=True)[:30],
        "proof_model": str(proof_model.resolve()),
        "status": int(model.Status),
        "status_name": {GRB.OPTIMAL: "OPTIMAL", GRB.TIME_LIMIT: "TIME_LIMIT", GRB.INFEASIBLE: "INFEASIBLE"}.get(model.Status, str(model.Status)),
        "runtime": model.Runtime,
        "nodes": model.NodeCount,
        "solutions": model.SolCount,
        "objective": model.ObjVal if model.SolCount else None,
        "bound": model.ObjBound,
        "gap": model.MIPGap if model.SolCount else None,
    }
    if model.SolCount:
        report["audit"] = audit_original(model)
        model.write(str(args.solution_out))
    args.summary.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
