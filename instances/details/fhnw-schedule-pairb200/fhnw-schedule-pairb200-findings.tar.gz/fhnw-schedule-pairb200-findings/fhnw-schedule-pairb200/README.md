# fhnw-schedule-pairb200 — solver-verified OPT = -19.3699612046452058100

2026-09-14 independent dual-bound review: [adopted bound, proof chain, checks, and limitations](../../docs/dual-bound-audit-2026-09-14/cases/fhnw-schedule-pairb200.zh.md). Reviewed lower bound: **-19.36996120464520581**. Use this exact certified decimal; superseded floating-point headline digits below are historical. This review distinguishes exact, literature, and numerical evidence; historical statements below remain dated records.

Official MIPLIB page: <https://miplib.zib.de/instance_details_fhnw-schedule-pairb200.html>

## Result

This study finds a new strictly feasible solution and closes the augmented
model globally:

```text
MIPLIB tolerance objective   -19.240943842597080
strict rounded public point  -19.240943297855996
new optimum                  -19.3699612046452058100
improvement vs MIPLIB          0.129017362048127
```

The new solution selects 30 of 200 optional jobs.  Direct substitution into
the untouched Pair-B MPS gives zero bound and integrality violations, maximum
row violation `4.22e-15`, and no violation above `1e-9`.

This is a **solver-verified global conclusion**, not a portable formal MIP
proof.  The lower bound is a zero-gap Gurobi solve after adding independently
audited valid inequalities; no DRAT/LRAT or rational branch-and-bound trace is
claimed.

## Recovered model and strengthening

Gurobi reads 40,200 variables, 99,554 rows and 298,554 nonzeros.  The first 200
binary variables select jobs, the next 200 continuous variables are start
times, and the remaining binaries encode the two possible orders for each of
the `C(200,2)=19,900` job pairs.  MIPLIB describes Pair A, Pair B and Slot as
three formulations of the same continuous-time project selection/scheduling
problem with values, release dates and deadlines.

The original pairwise big-M formulation has a very weak relaxation.  With the
new incumbent loaded, a 600-second original-model run still ended with bound
`-52.84948950967261` and gap `172.84%`.  The successful proof model adds:

- 4,368 conflict inequalities `z_i + z_j <= 1` when neither order of a pair
  fits the two release/deadline windows;
- 1,500 interval energetic inequalities
  `sum_i e_i(a,b) z_i <= b-a`, selected from 31,481 candidate intervals, where
  `e_i(a,b)` is the minimum processing of job `i` forced into `[a,b]`.

The resulting 105,422-row model closes at the root node:

```text
primal = -19.369961204645204
dual   = -19.369961204645204
gap    = 0
nodes  = 1
```

An additional proof path avoids the large pair formulation entirely. All 146
eligible jobs share completion deadline 1. For every release threshold `t`,
the necessary capacity inequality

```text
sum_{i: r_i >= t} p_i z_i <= D_safe-t
```

Here `D_safe = max_i d_i + 1e-12 = 1.000000000001`, so MPS input roundoff
cannot remove an original feasible selection. The inequalities give a
200-binary relaxation with 54 fixed-zero rows and 146 release-suffix rows.
This compact master closes in 0.018 seconds and nine nodes at bound
`-19.369961204645204`, matching the independently audited Pair-B witness up to
floating-point display precision. Every master row is separately checked
against data recovered from the official MPS.

## Independent checks

1. [`energy-cuts-original-mps-audit.json`](artifacts/energy-cuts-original-mps-audit.json)
   evaluates the new solution on the untouched Pair-B MPS.
2. [`energy-cuts-proof-proof.mps.gz`](artifacts/energy-cuts-proof-proof.mps.gz)
   is the frozen augmented model.  A different seed and parameter set again
   closes it in one node; see
   [`proof-model-independent-run.json`](artifacts/proof-model-independent-run.json).
3. [`proof-semantic-audit.json`](artifacts/proof-semantic-audit.json) checks all
   99,500 pair rows, 4,368 conflict cuts and 1,500 energetic cuts against the
   recovered scheduling semantics.  All support, coefficient and RHS checks
   pass.
4. The same 30-job selection is reconstructed in the official Pair-A MPS with
   the same objective and maximum row violation `2.84e-14`; see
   [`paira-cross-formulation-direct-audit.json`](artifacts/paira-cross-formulation-direct-audit.json).
5. [`common-deadline-master/`](artifacts/common-deadline-master/) archives the
   compact release-suffix model, zero-gap log, result and semantic audit. This
   is a second structural lower-bound route independent of the 1,500 selected
   interval cuts.

The new witness is
[`new-optimal-candidate.sol`](solutions/new-optimal-candidate.sol).  A detailed
Chinese report is in
[`deep-study-2026-09-08.zh.md`](reports/deep-study-2026-09-08.zh.md).

## Reproduction

The strengthening requires Gurobi:

```sh
python scripts/pairb_energy_solver.py \
  input/fhnw-schedule-pairb200.mps.gz \
  input/fhnw-schedule-pairb200-public.sol.gz \
  /tmp/pairb-proof.json /tmp/pairb-proof.log /tmp/pairb-proof.sol \
  --max-energy-cuts 1500 --threads 2
```

The semantic audit of the frozen proof model is:

```sh
python scripts/pairb_proof_audit.py \
  input/fhnw-schedule-pairb200.mps.gz \
  artifacts/energy-cuts-proof-proof.mps.gz \
  experiments/energy-cuts-proof.json \
  /tmp/pairb-semantic-audit.json
```

The compact common-deadline master and its row audit can be regenerated with:

```sh
python scripts/pairb_common_deadline_master.py \
  input/fhnw-schedule-pairb200.mps.gz solutions/new-optimal-candidate.sol \
  /tmp/pairb200-master --jobs 200 --threads 1 --seed 41 \
  --deadline-safety 1e-12

python scripts/audit_common_deadline_master.py \
  input/fhnw-schedule-pairb200.mps.gz \
  /tmp/pairb200-master/common-deadline-master.mps.gz \
  /tmp/pairb200-master-audit.json --jobs 200 --deadline-safety 1e-12
```

Input, proof-model and final-witness hashes are recorded in
[`input/SHA256SUMS`](input/SHA256SUMS) and the audit JSON files.

