# Package manifest: sing17

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 98
Excluded source files: 0

## Included files

- `README.md`
- `artifacts/published-solution-replay.json`
- `artifacts/sing17-2018-to-2019-block-diff.json`
- `artifacts/sing17-2019-to-2024-block-diff.json`
- `artifacts/sing17-block-lns-all50-gap0.json`
- `artifacts/sing17-decomposition.json`
- `artifacts/sing17-deep-cuts-sym.json`
- `artifacts/sing17-final-summary-20260908.json`
- `artifacts/sing17-group-lns-fractional-blocks.json`
- `artifacts/sing17-group-lns-historical-core.json`
- `artifacts/sing17-group-lns-historical-coupled.json`
- `artifacts/sing17-group-lns-repeated.json`
- `artifacts/sing17-lp-block-diagnostics.json`
- `artifacts/sing17-public-audit.json`
- `artifacts/sing17-public-fixed-lp-repair.json`
- `artifacts/sing17-root-probe.json`
- `artifacts/sing17-structure.json`
- `input/README.md`
- `input/SHA256SUMS`
- `input/sing17-2018-selection.sol.gz`
- `input/sing17-2019-odh-cplex.sol.gz`
- `input/sing17-public.sol.gz`
- `input/sing17.dec`
- `logs/block-lns-all50-gap0/blocks-1.log`
- `logs/block-lns-all50-gap0/blocks-10.log`
- `logs/block-lns-all50-gap0/blocks-11.log`
- `logs/block-lns-all50-gap0/blocks-12.log`
- `logs/block-lns-all50-gap0/blocks-13.log`
- `logs/block-lns-all50-gap0/blocks-14.log`
- `logs/block-lns-all50-gap0/blocks-15.log`
- `logs/block-lns-all50-gap0/blocks-16.log`
- `logs/block-lns-all50-gap0/blocks-17.log`
- `logs/block-lns-all50-gap0/blocks-18.log`
- `logs/block-lns-all50-gap0/blocks-19.log`
- `logs/block-lns-all50-gap0/blocks-2.log`
- `logs/block-lns-all50-gap0/blocks-20.log`
- `logs/block-lns-all50-gap0/blocks-21.log`
- `logs/block-lns-all50-gap0/blocks-22.log`
- `logs/block-lns-all50-gap0/blocks-23.log`
- `logs/block-lns-all50-gap0/blocks-24.log`
- `logs/block-lns-all50-gap0/blocks-25.log`
- `logs/block-lns-all50-gap0/blocks-26.log`
- `logs/block-lns-all50-gap0/blocks-27.log`
- `logs/block-lns-all50-gap0/blocks-28.log`
- `logs/block-lns-all50-gap0/blocks-29.log`
- `logs/block-lns-all50-gap0/blocks-3.log`
- `logs/block-lns-all50-gap0/blocks-30.log`
- `logs/block-lns-all50-gap0/blocks-31.log`
- `logs/block-lns-all50-gap0/blocks-32.log`
- `logs/block-lns-all50-gap0/blocks-33.log`
- `logs/block-lns-all50-gap0/blocks-34.log`
- `logs/block-lns-all50-gap0/blocks-35.log`
- `logs/block-lns-all50-gap0/blocks-36.log`
- `logs/block-lns-all50-gap0/blocks-37.log`
- `logs/block-lns-all50-gap0/blocks-38.log`
- `logs/block-lns-all50-gap0/blocks-39.log`
- `logs/block-lns-all50-gap0/blocks-4.log`
- `logs/block-lns-all50-gap0/blocks-40.log`
- `logs/block-lns-all50-gap0/blocks-41.log`
- `logs/block-lns-all50-gap0/blocks-42.log`
- `logs/block-lns-all50-gap0/blocks-43.log`
- `logs/block-lns-all50-gap0/blocks-44.log`
- `logs/block-lns-all50-gap0/blocks-45.log`
- `logs/block-lns-all50-gap0/blocks-46.log`
- `logs/block-lns-all50-gap0/blocks-47.log`
- `logs/block-lns-all50-gap0/blocks-48.log`
- `logs/block-lns-all50-gap0/blocks-49.log`
- `logs/block-lns-all50-gap0/blocks-5.log`
- `logs/block-lns-all50-gap0/blocks-50.log`
- `logs/block-lns-all50-gap0/blocks-6.log`
- `logs/block-lns-all50-gap0/blocks-7.log`
- `logs/block-lns-all50-gap0/blocks-8.log`
- `logs/block-lns-all50-gap0/blocks-9.log`
- `logs/group-lns-fractional-blocks/sing17-group-15-16-20.log`
- `logs/group-lns-fractional-blocks/sing17-group-9-10-15-16-20-50.log`
- `logs/group-lns-historical-coupled/sing17-group-2-3-15-16-17-22.log`
- `logs/group-lns-historical-coupled/sing17-group-2-3-15-16.log`
- `logs/group-lns-repeated/sing17-group-12-13-14.log`
- `logs/group-lns-repeated/sing17-group-12-13.log`
- `logs/group-lns-repeated/sing17-group-12-14.log`
- `logs/group-lns-repeated/sing17-group-13-14.log`
- `logs/group-lns-repeated/sing17-group-15-16.log`
- `logs/group-lns-repeated/sing17-group-2-3.log`
- `logs/group-lns-repeated/sing17-group-9-10.log`
- `logs/sing17-deep-cuts-sym.log`
- `logs/sing17-lp-block-diagnostics.log`
- `logs/sing17-public-fixed-lp-repair.log`
- `reports/deep-study-2026-09-08.zh.md`
- `scripts/block_group_lns.py`
- `scripts/common_audit_solution.py`
- `scripts/compare_solutions_by_block.py`
- `scripts/gurobi_probe.py`
- `scripts/repair_fixed_integer_solution.py`
- `scripts/sing17_block_lns.py`
- `scripts/sing17_experiment.py`
- `scripts/sing17_group_lns.py`
- `scripts/sing17_lp_block_diagnostics.py`
- `solutions/sing17-strict-polished.sol`

## Excluded files

- None
