from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import gurobipy as gp

from sing17_block_lns import audit_solution, parse_decomposition, parse_solution


def parse_groups(specification: str) -> list[tuple[int, ...]]:
    groups = []
    for group_text in specification.split(","):
        group = tuple(int(token) for token in group_text.split("+") if token)
        if group:
            groups.append(group)
    return groups


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", type=Path, required=True)
    parser.add_argument("--solution", type=Path, required=True)
    parser.add_argument("--decomposition", type=Path, required=True)
    parser.add_argument("--groups", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--log-dir", type=Path, required=True)
    parser.add_argument("--best-solution", type=Path, required=True)
    parser.add_argument("--time-per-group", type=float, default=180.0)
    parser.add_argument("--threads", type=int, default=2)
    parser.add_argument("--seed", type=int, default=2200)
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.log_dir.mkdir(parents=True, exist_ok=True)
    args.best_solution.parent.mkdir(parents=True, exist_ok=True)
    groups = parse_groups(args.groups)
    started = time.time()

    model = gp.read(str(args.mps))
    model.Params.OutputFlag = 0
    variables = model.getVars()
    constraints_by_name = {constraint.ConstrName: constraint for constraint in model.getConstrs()}
    incumbent, solution_info = parse_solution(model, args.solution)
    initial_audit = audit_solution(model, incumbent)
    original_lb = [variable.LB for variable in variables]
    original_ub = [variable.UB for variable in variables]

    block_count, block_rows, master_row_names = parse_decomposition(args.decomposition)
    block_variables: dict[int, set[int]] = {block: set() for block in range(1, block_count + 1)}
    for block, names in block_rows.items():
        for name in names:
            row = model.getRow(constraints_by_name[name])
            for position in range(row.size()):
                block_variables[block].add(row.getVar(position).index)
    master_variables: set[int] = set()
    for name in master_row_names:
        row = model.getRow(constraints_by_name[name])
        for position in range(row.size()):
            master_variables.add(row.getVar(position).index)
    all_block_variables = set().union(*block_variables.values())
    master_only_variables = master_variables - all_block_variables

    for variable, value in zip(variables, incumbent):
        variable.LB = value
        variable.UB = value
        variable.Start = value
    model.update()

    best_objective = initial_audit["objective"]
    records = []
    for sequence, group in enumerate(groups, start=1):
        unknown = [block for block in group if block not in block_variables]
        if unknown:
            raise ValueError(f"unknown blocks in group {group}: {unknown}")
        free_indices = set(master_only_variables)
        for block in group:
            free_indices.update(block_variables[block])
        for index in free_indices:
            variables[index].LB = original_lb[index]
            variables[index].UB = original_ub[index]
            variables[index].Start = incumbent[index]
        model.update()
        model.reset(0)
        model.Params.TimeLimit = args.time_per_group
        model.Params.Threads = args.threads
        model.Params.Seed = args.seed + sequence
        model.Params.MIPFocus = 1
        model.Params.Cuts = 2
        model.Params.Presolve = 2
        model.Params.Symmetry = 2
        model.Params.Heuristics = 0.25
        tag = "-".join(str(block) for block in group)
        model.Params.LogFile = str(args.log_dir / f"sing17-group-{tag}.log")
        group_started = time.time()
        model.optimize()
        record = {
            "sequence": sequence,
            "blocks": list(group),
            "block_rows": sum(len(block_rows[block]) for block in group),
            "free_variables": len(free_indices),
            "status": int(model.Status),
            "solution_count": int(model.SolCount),
            "objective": float(model.ObjVal) if model.SolCount else None,
            "best_bound": float(model.ObjBound) if model.IsMIP else None,
            "gap": float(model.MIPGap) if model.IsMIP and model.SolCount else None,
            "nodes": float(model.NodeCount),
            "runtime": float(model.Runtime),
            "wall_runtime": time.time() - group_started,
            "improved": False,
        }
        if model.SolCount and model.ObjVal < best_objective - 1e-6:
            incumbent = [float(variable.X) for variable in variables]
            best_objective = float(model.ObjVal)
            record["improved"] = True
            model.write(str(args.best_solution))
        for index in free_indices:
            variables[index].LB = incumbent[index]
            variables[index].UB = incumbent[index]
            variables[index].Start = incumbent[index]
        model.update()
        records.append(record)
        checkpoint = {
            "instance": model.ModelName,
            "method": "official-decomposition multi-block coordinate LNS",
            "solution": solution_info,
            "initial_audit": initial_audit,
            "parameters": {
                "groups": [list(group_value) for group_value in groups],
                "time_per_group": args.time_per_group,
                "threads": args.threads,
                "seed": args.seed,
            },
            "best_objective": best_objective,
            "objective_improvement": initial_audit["objective"] - best_objective,
            "groups_completed": len(records),
            "records": records,
            "wall_runtime": time.time() - started,
        }
        args.output.write_text(json.dumps(checkpoint, indent=2) + "\n", encoding="utf-8")

    checkpoint["final_audit"] = audit_solution(model, incumbent)
    checkpoint["wall_runtime"] = time.time() - started
    args.output.write_text(json.dumps(checkpoint, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(checkpoint, indent=2))


if __name__ == "__main__":
    main()
