from __future__ import annotations

import argparse
import json
import math
import statistics
import time
from collections import defaultdict
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB

from sing17_block_lns import parse_decomposition, parse_solution


def describe(values: list[float]) -> dict | None:
    if not values:
        return None
    return {
        "min": min(values),
        "median": statistics.median(values),
        "mean": statistics.fmean(values),
        "max": max(values),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", type=Path, required=True)
    parser.add_argument("--solution", type=Path, required=True)
    parser.add_argument("--decomposition", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--time-limit", type=float, default=600.0)
    parser.add_argument("--threads", type=int, default=2)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.log.parent.mkdir(parents=True, exist_ok=True)

    started = time.time()
    original = gp.read(str(args.mps))
    original_variables = original.getVars()
    incumbent, incumbent_info = parse_solution(original, args.solution)
    block_count, block_rows, master_names = parse_decomposition(args.decomposition)
    constraints = {constraint.ConstrName: constraint for constraint in original.getConstrs()}

    variable_block: dict[int, int] = {}
    for block, names in block_rows.items():
        for name in names:
            row = original.getRow(constraints[name])
            for position in range(row.size()):
                index = row.getVar(position).index
                previous = variable_block.get(index)
                if previous is not None and previous != block:
                    raise RuntimeError(f"variable {index} occurs in blocks {previous} and {block}")
                variable_block[index] = block
    master_variables: set[int] = set()
    for name in master_names:
        row = original.getRow(constraints[name])
        for position in range(row.size()):
            master_variables.add(row.getVar(position).index)
    master_only = master_variables - set(variable_block)

    relaxation = original.relax()
    relaxation.Params.TimeLimit = args.time_limit
    relaxation.Params.Threads = args.threads
    relaxation.Params.Method = 2
    relaxation.Params.Crossover = 1
    relaxation.Params.Presolve = 2
    relaxation.Params.NumericFocus = 1
    relaxation.Params.LogFile = str(args.log)
    relaxation.optimize()
    if relaxation.SolCount == 0:
        payload = {
            "instance": original.ModelName,
            "status": int(relaxation.Status),
            "solution_count": int(relaxation.SolCount),
            "runtime": float(relaxation.Runtime),
            "wall_runtime": time.time() - started,
        }
        args.output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(payload, indent=2))
        return

    relaxed_variables = relaxation.getVars()
    lp_values = [float(variable.X) for variable in relaxed_variables]
    block_records = []
    for block in range(1, block_count + 1):
        indices = [index for index, assigned in variable_block.items() if assigned == block]
        integer_indices = [index for index in indices if original_variables[index].VType != GRB.CONTINUOUS]
        fractional = [
            min(lp_values[index] - math.floor(lp_values[index]), math.ceil(lp_values[index]) - lp_values[index])
            for index in integer_indices
        ]
        positive_fractionality = [value for value in fractional if value > 1e-7]
        block_records.append(
            {
                "block": block,
                "rows": len(block_rows[block]),
                "variables": len(indices),
                "integer_variables": len(integer_indices),
                "fractional_integer_variables": len(positive_fractionality),
                "fractionality_sum": sum(positive_fractionality),
                "fractionality_stats": describe(positive_fractionality),
                "incumbent_minus_lp_objective_contribution": sum(
                    original_variables[index].Obj * (incumbent[index] - lp_values[index])
                    for index in indices
                ),
                "absolute_value_change_sum": sum(abs(incumbent[index] - lp_values[index]) for index in indices),
            }
        )

    all_integer_indices = [
        variable.index for variable in original_variables if variable.VType != GRB.CONTINUOUS
    ]
    fractionality = [
        (
            min(lp_values[index] - math.floor(lp_values[index]), math.ceil(lp_values[index]) - lp_values[index]),
            index,
        )
        for index in all_integer_indices
    ]
    fractionality.sort(reverse=True)
    payload = {
        "instance": original.ModelName,
        "status": int(relaxation.Status),
        "status_name": "OPTIMAL" if relaxation.Status == GRB.OPTIMAL else "OTHER",
        "solution_count": int(relaxation.SolCount),
        "lp_objective": float(relaxation.ObjVal),
        "incumbent": incumbent_info,
        "absolute_lp_gap": incumbent_info["recomputed_objective"] - float(relaxation.ObjVal),
        "relative_lp_gap": (
            incumbent_info["recomputed_objective"] - float(relaxation.ObjVal)
        ) / abs(incumbent_info["recomputed_objective"]),
        "runtime": float(relaxation.Runtime),
        "barrier_iterations": int(relaxation.BarIterCount),
        "simplex_iterations": float(relaxation.IterCount),
        "work_units": float(relaxation.Work),
        "wall_runtime": time.time() - started,
        "decomposition": {
            "blocks": block_count,
            "master_rows": len(master_names),
            "master_variables": len(master_variables),
            "master_only_variables": len(master_only),
        },
        "fractional_integer_variables": sum(value > 1e-7 for value, _ in fractionality),
        "fractionality_sum": sum(value for value, _ in fractionality if value > 1e-7),
        "top_fractional_variables": [
            {
                "name": original_variables[index].VarName,
                "block": variable_block.get(index, "master-only" if index in master_only else "unassigned"),
                "lp_value": lp_values[index],
                "incumbent_value": incumbent[index],
                "fractionality": value,
                "objective": original_variables[index].Obj,
            }
            for value, index in fractionality[:100]
            if value > 1e-7
        ],
        "blocks_by_fractionality": sorted(
            block_records,
            key=lambda record: (-record["fractionality_sum"], record["block"]),
        ),
        "blocks_by_objective_gap_contribution": sorted(
            block_records,
            key=lambda record: (-record["incumbent_minus_lp_objective_contribution"], record["block"]),
        ),
    }
    args.output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
