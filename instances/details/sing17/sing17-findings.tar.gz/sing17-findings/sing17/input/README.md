# Input provenance

The original model is not duplicated in Git. Download
[`sing17.mps.gz`](https://miplib.zib.de/WebData/instances/sing17.mps.gz) from
MIPLIB and save it in this directory before rerunning the scripts. The expected
SHA-256 is recorded in `SHA256SUMS`.

`sing17.dec` is the official original-model decomposition from
<https://miplib.zib.de/WebData/decomps_orig/sing17.dec>. The compressed solution
files preserve the 2024 public incumbent, 2019 ODH|CPlex solution, and 2018
selection solution used for the integer-pattern and block-difference audits.
