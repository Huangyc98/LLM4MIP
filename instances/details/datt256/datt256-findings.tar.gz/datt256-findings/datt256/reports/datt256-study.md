# `datt256`（Eternity II）实验报告

实验日期：2026-09-01（Asia/Shanghai）

## 结论

本轮**没有找到 `datt256` 的可行解，也没有证明整个实例不可行**。

这不是普通的未解 MIP：MIPLIB 仍把它标为 `open / no_solution`，模型对应官方 Eternity II——256 块拼片填入 16×16 棋盘，使 480 条内部边全部匹配。公开资料称完整的 480/480 棋盘至今未找到，当前 starter-only 公开记录为 470/480。因此，找到本 MPS 的可行点基本等同于解决这个公开难题。

本轮得到的确定性新信息是：

- 已将公开的 Joshua Blackwood 470/480 棋盘机械地映射到本 MPS 的 256 个置一变量，并逐行精确验算；它只违反 20 条颜色平衡等式，正好对应 10 条不匹配的物理边。其余指派、边框、starter clue、0/1 和目标值均完全满足。
- 固定这张 470 棋盘的底部 10 行，只释放包含全部 10 条坏边的顶部 6 行（96 格），Gurobi 在 3.39 秒内证明：不存在能够把整张棋盘补成 480/480 的重填。这是一个严格的**局部不可行证明**，不是整个 `datt256` 不可行的证明。
- 更小的 17、48、75 格缺陷邻域也分别被严格证明无法修成 480/480。
- 释放顶部 8 行（128 格）时，300 秒内没有找到补全，也未闭合证明；有效根下界为 36，即在底部 8 行保持记录棋盘不变的条件下，任何可能的 480/480 补全至少要改变顶部 36 格。
- 完全不固定格子的全局引导模型在约 325 秒内无可行解，根下界为 32：如果完整解存在，它与 Blackwood 470 棋盘至少相差 32 个格子的“piece+rotation”放置。

## 输入与模型结构

- 输入：`datt256.mps.gz`
- SHA-256：`F2BDB0696291DEE491979AE76A98862A1A5C17B305ED9E857485931809571AA1`
- 规模：11,077 行、262,144 个二元变量、1,503,732 个实际读取的非零元。
- 变量含义：256 pieces × 256 cells × 4 rotations。
- 512 条大小为 1024 的集合划分等式：每格恰放一块、每块恰用一次。
- 10,560 条颜色流量/相邻边等式：480 条内部邻接 × 22 种 motif。
- 1 条边框非法放置等式：禁止灰边朝向棋盘内部或彩色边朝向外框。
- 4 条 singleton 等式固定 starter piece；其中 `x141795 = 1`，另外三个旋转为 0。
- 原始目标函数在所有完整指派上恒为 256，所以这个实例实质上是纯可行性问题。

变量编号的恢复结果（均为 0-based）是：

```text
x_index - 1 = piece_id * 1024 + q_position * 4 + mps_rotation
```

其中 MPS 的位置 `q_position` 是按列优先排列，网站棋盘是按行优先排列；二者位置映射为转置。对官方数据的所有 256 块，恢复出的旋转偏移均为 2，因此：

```text
mps_rotation = (2 - website_rotation) mod 4
```

桥接脚本从 MPS 的相邻边约束图和官方 piece motif 数据中恢复位置、颜色置换与旋转偏移，没有手工猜测编号。

## 公开 470 棋盘的复核

使用参考网站开源仓库中的官方 piece set 与 `Joshua_Blackwood_470` board edges，先唯一匹配每个 piece 及旋转，再通过上述桥映射到 MPS。

精确 MPS 验算结果：

```text
objective=256
selected binaries=256
exact row violations=20
maximum row violation=1
bound violations=0
integrality violations=0
assignment/border/clue violations=0
```

10 条不匹配边（网站 row-major 位置；后两列为两侧 motif 编号）：

```text
(21,37,9,12)   (26,42,6,19)   (28,29,12,16)
(41,42,17,22)  (46,47,22,21)  (60,61,15,6)
(61,62,21,17)  (69,70,6,16)   (78,79,19,6)
(78,94,9,15)
```

每条物理坏边在 22 色流量编码中产生两条违反的等式（一种颜色多 1、另一种少 1），所以是 10 × 2 = 20 条 MPS 行违反。该文件是高质量 near-feasible start，**不是** `datt256` 的可行解。

## 求解器基线（CPU only）

| 求解器 / 主机 | 线程 | 时限 | 结果 | 最好界 / 节点 |
|---|---:|---:|---|---|
| Gurobi 13.0.1 / `euler4` | 32 | 120 s | 0 个可行解 | bound 256；1 node |
| COPT 8.0.4 / `altman` | 32 | 120 s | 0 个可行解 | bound 156；1 node |

两次都是冷启动原模型。Gurobi 已把根 LP 做到 256，但整数不可行度仍很大；目标恒为 256，因此这个界不意味着找到了拼图。COPT 在时限内也没有给出整数解。`altman` 只调用了 COPT CPU 求解器，**未使用 GPU0**。

## 围绕 470 棋盘的精确 destroy-and-repair

实验固定释放区外记录棋盘的置一变量；由于每块只能使用一次，释放区只能重新排列/旋转原先位于该区的那些 pieces。模型仍保留原 MPS 的全部 480 条边匹配约束，目标仅用于在可行补全中最小化改变格数，不排除任何 480/480 补全。

`radius1`、`radius2` 使用到 17 个坏边端点的 Manhattan 距离；`top6/top8` 是完整水平带。

| 释放区域 | 释放格 | 固定格 | Gurobi 结果 | 时间 / 界 |
|---|---:|---:|---|---|
| 10 条坏边的端点 | 17 | 239 | **infeasible（已证明）** | 1.28 s |
| Manhattan radius 1 | 48 | 208 | **infeasible（已证明）** | 1.57 s |
| Manhattan radius 2 | 75 | 181 | **infeasible（已证明）** | 1.57 s |
| 顶部 6 行（含全部坏边） | 96 | 160 | **infeasible（已证明）** | 3.39 s |
| 顶部 8 行 | 128 | 128 | 未解决、无可行解 | 300.02 s；bound 36 |
| 全局（只给 470 变量 hints） | 256 | 0 | 未解决、无可行解 | 324.96 s；bound 32 |

另做过一次带 partial MIP start 的 top-8 运行；Gurobi 把全部 300 秒用在单线程 start completion sub-MIP 上，没有进入主树，故该运行仅作诊断，不纳入有效结论。随后上表的 top-8 已移除这个启动值并使用 32 线程重新运行。

局部证明的准确含义是：**在记录棋盘的固定区完全不动时，释放区不存在使全盘达到 480/480 的填法。**它不能推出官方拼图无解，也不能推出释放区不存在把 470 提高到 471–479 的近似填法，因为原始 MPS 只接受 480/480。

## 可复现文件

- `datt256_structure.py`：流式解析 MPS 并统计精确结构。
- `datt256_mps_bridge.py`：恢复 MPS 与官网 piece/cell/rotation 编号桥。
- `datt256-bridge.json`：恢复出的桥接数据。
- `datt256_record_start.py`：解码公开 Blackwood 470 棋盘并生成 MPS start。
- `datt256-blackwood470.sol`：256 个置一变量的稀疏 near-feasible start。
- `datt256-blackwood470.json`：棋盘、坏边和逐位置 MPS 变量元数据。
- `exact_mps_solution_check.py`：用 Decimal 精确检查 MPS 行、边界和整数性。
- `datt256_repair.py`：局部/全局精确修复实验。
- `datt256_copt.in`：COPT 冷启动脚本。
- `datt256-*.log`：上述 Gurobi/COPT 完整日志。
- `eternity2-reference/`：参考网站仓库快照，commit `f961c29c0303141666a79aa8ffb5c60c8b6c489f`。

## 资料

- [MIPLIB：datt256 instance details](https://miplib.zib.de/instance_details_datt256.html)
- [Eternity II：拼图规则、piece set 与公开记录](https://eternity2.dev/puzzle/)
- [Eternity II：records & solvers](https://eternity2.dev/research/records/)
- [Eternity II：The rigidity wall](https://eternity2.dev/research/why/rigidity-wall/)
- [参考网站源代码](https://github.com/raphael-anjou/eternity2)

