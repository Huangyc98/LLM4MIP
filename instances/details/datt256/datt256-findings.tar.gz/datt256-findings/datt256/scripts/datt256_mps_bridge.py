#!/usr/bin/env python3
"""Recover datt256's position permutation and per-piece rotation offsets."""

from __future__ import annotations

import argparse
import gzip
import json
from collections import Counter, deque
from pathlib import Path


def open_text(path: Path):
    if path.suffix == ".gz":
        return gzip.open(path, "rt", encoding="latin-1")
    return path.open(encoding="latin-1")


def rotate(edges: tuple[int, int, int, int], rotation: int) -> tuple[int, int, int, int]:
    r = rotation & 3
    return tuple(edges[(index + 4 - r) % 4] for index in range(4))  # type: ignore[return-value]


def distances(graph: list[set[int]], source: int) -> list[int]:
    result = [-1] * len(graph)
    result[source] = 0
    queue = deque([source])
    while queue:
        here = queue.popleft()
        for other in graph[here]:
            if result[other] < 0:
                result[other] = result[here] + 1
                queue.append(other)
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("official_json", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    official = json.loads(args.official_json.read_text(encoding="utf-8"))
    pieces = [tuple(map(int, piece)) for piece in official["pieces"]]

    edge_positions: list[set[int]] = [set() for _ in range(480)]
    section = ""
    with open_text(args.mps) as handle:
        for raw in handle:
            tokens = raw.split()
            if not tokens or tokens[0].startswith("*"):
                continue
            if tokens[0] in {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}:
                section = tokens[0]
                continue
            if section != "COLUMNS" or "'MARKER'" in tokens:
                continue
            variable_index = int(tokens[0][1:]) - 1
            position = (variable_index % 1024) // 4
            for row in tokens[1::2]:
                if row == "obj":
                    continue
                row_index = int(row[1:])
                if 1 <= row_index <= 10560:
                    edge_positions[(row_index - 1) % 480].add(position)

    if Counter(map(len, edge_positions)) != Counter({2: 480}):
        raise ValueError(f"could not recover 480 two-endpoint edges: {Counter(map(len, edge_positions))}")
    graph = [set() for _ in range(256)]
    edge_for_pair: dict[frozenset[int], int] = {}
    for edge, endpoints in enumerate(edge_positions):
        left, right = tuple(endpoints)
        graph[left].add(right)
        graph[right].add(left)
        edge_for_pair[frozenset((left, right))] = edge
    corners = [position for position, neighbors in enumerate(graph) if len(neighbors) == 2]
    if len(corners) != 4 or 0 not in corners:
        raise ValueError(f"unexpected grid corners: {corners}")

    distance_from_zero = distances(graph, 0)
    opposite = next(corner for corner in corners if distance_from_zero[corner] == 30)
    adjacent = [corner for corner in corners if distance_from_zero[corner] == 15]
    if len(adjacent) != 2:
        raise ValueError(f"unexpected adjacent corners: {adjacent}")

    coordinate_options: list[list[tuple[int, int]]] = []
    for top_right in adjacent:
        distance_from_top_right = distances(graph, top_right)
        coordinates: list[tuple[int, int]] = []
        for position in range(256):
            column_times_two = distance_from_zero[position] - distance_from_top_right[position] + 15
            if column_times_two % 2:
                raise ValueError("grid coordinate parity failure")
            column = column_times_two // 2
            row = distance_from_zero[position] - column
            coordinates.append((row, column))
        if set(coordinates) != {(row, column) for row in range(16) for column in range(16)}:
            raise ValueError("grid embedding is not a 16x16 board")
        coordinate_options.append(coordinates)

    # The mandatory official clue is piece 139 at site row-major position 135.
    # datt256 pins that piece at internal position 120.  This chooses which of
    # the two graph embeddings is row-vs-column rather than guessing it.
    coordinates = next(
        option for option in coordinate_options if option[120] == divmod(135, 16)
    )
    position_at = {coordinate: position for position, coordinate in enumerate(coordinates)}
    sample_position = position_at[(7, 7)]

    mps_base: list[list[int]] = [[0, 0, 0, 0] for _ in range(256)]
    target_variables = {
        piece * 1024 + sample_position * 4 + 1: piece for piece in range(256)
    }
    section = ""
    with open_text(args.mps) as handle:
        for raw in handle:
            tokens = raw.split()
            if not tokens or tokens[0].startswith("*"):
                continue
            if tokens[0] in {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}:
                section = tokens[0]
                continue
            if section != "COLUMNS" or "'MARKER'" in tokens:
                continue
            variable_number = int(tokens[0][1:])
            piece = target_variables.get(variable_number)
            if piece is None:
                continue
            for row_name in tokens[1::2]:
                if row_name == "obj":
                    continue
                row_index = int(row_name[1:])
                if not 1 <= row_index <= 10560:
                    continue
                edge = (row_index - 1) % 480
                color = (row_index - 1) // 480 + 1
                endpoints = edge_positions[edge]
                other = next(position for position in endpoints if position != sample_position)
                here_row, here_column = coordinates[sample_position]
                other_row, other_column = coordinates[other]
                delta = (other_row - here_row, other_column - here_column)
                side = {(-1, 0): 0, (0, 1): 1, (1, 0): 2, (0, -1): 3}[delta]
                mps_base[piece][side] = color

    color_map: dict[int, int] = {0: 0}
    offsets: list[int | None] = [None] * 256
    for piece_id in range(60):
        official_piece = pieces[piece_id]
        target = tuple(mps_base[piece_id])
        candidates = [
            rotation for rotation in range(4)
            if tuple(value == 0 for value in rotate(official_piece, rotation))
            == tuple(value == 0 for value in target)
        ]
        if len(candidates) != 1:
            raise ValueError(f"piece {piece_id + 1}: ambiguous border rotation {candidates}")
        rotation = candidates[0]
        offsets[piece_id] = rotation
        for official_color, mps_color in zip(rotate(official_piece, rotation), target):
            previous = color_map.setdefault(official_color, mps_color)
            if previous != mps_color:
                raise ValueError(
                    f"inconsistent color map for official color {official_color}: {previous} vs {mps_color}"
                )
    if set(color_map) != set(range(23)) or len(set(color_map.values())) != 23:
        raise ValueError(f"boundary pieces did not recover a color permutation: {color_map}")

    for piece_id, official_piece in enumerate(pieces):
        target = tuple(mps_base[piece_id])
        candidates = [
            rotation for rotation in range(4)
            if tuple(color_map[value] for value in rotate(official_piece, rotation)) == target
        ]
        if len(candidates) != 1:
            raise ValueError(f"piece {piece_id + 1}: rotation bridge candidates {candidates}")
        offsets[piece_id] = candidates[0]

    assert all(offset is not None for offset in offsets)
    q_to_site_position = [16 * row + column for row, column in coordinates]
    bridge = {
        "q_to_site_position": q_to_site_position,
        "site_position_to_q": [q_to_site_position.index(position) for position in range(256)],
        "rotation_offset": offsets,
        "official_to_mps_color": {str(key): value for key, value in sorted(color_map.items())},
        "sample_internal_q": sample_position,
        "corners": corners,
        "opposite_of_q0": opposite,
    }
    args.output.write_text(json.dumps(bridge, indent=2) + "\n", encoding="utf-8")

    clue_rotation = (0 - int(offsets[138])) & 3
    print(f"corners={corners} q0_coordinate={coordinates[0]} q120_coordinate={coordinates[120]}")
    print(f"sample_internal_q={sample_position} color_permutation={color_map}")
    print(f"rotation_offset_distribution={dict(Counter(offsets))}")
    print(f"piece139_offset={offsets[138]} predicted_mps_rotation={clue_rotation}")
    print(f"wrote={args.output}")


if __name__ == "__main__":
    main()
