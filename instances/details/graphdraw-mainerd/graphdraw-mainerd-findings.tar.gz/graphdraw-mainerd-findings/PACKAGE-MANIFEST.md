# Package manifest: graphdraw-mainerd

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 21
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/exact-solution-audit.json`
- `artifacts/experiment-summary.json`
- `artifacts/official-38842-info.yaml`
- `artifacts/structure-and-solution-audit.json`
- `logs/copt-global-600s.log`
- `logs/cpsat-global-600s.log`
- `logs/cpsat-local-moved1.log`
- `logs/cpsat-local-moved2.log`
- `logs/cpsat-local-moved3.log`
- `logs/cpsat-local-moved4.log`
- `logs/cpsat-local-moved5.log`
- `logs/cpsat-local-moved6.log`
- `logs/cpsat-local-moved7.log`
- `logs/gurobi-global-600s.log`
- `reports/graphdraw-mainerd-study-zh.md`
- `scripts/analyze_structure.py`
- `scripts/solve_compact_cpsat.py`
- `solutions/cpsat-reconstructed-38842.sol`
- `solutions/official-38842.sol`
- `solutions/official-38842.sol.gz`

## Excluded files

- `input/graphdraw-mainerd.mps.gz (394648 bytes; raw benchmark input; sha256 922559b42529658ad1a1cf2539364cdde65122c2457aed7186d66a344ecf986f)`
