#!/usr/bin/env python3
"""Solve graphdraw-mainerd as a compact 31-rectangle CP-SAT model.

The original MPS uses four one-hot order variables for every rectangle pair
and 17,980 triangle inequalities.  This reconstruction replaces that extended
formulation by one global NoOverlap2D constraint.  All half-integral distances
are scaled by two, so the compact model is an exact integer reformulation.
"""

from __future__ import annotations

import argparse
import collections
import gzip
import math
import re
from pathlib import Path

SECTIONS = {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}


def open_text(path: Path):
    return gzip.open(path, "rt", encoding="latin-1") if path.suffix == ".gz" else path.open("rt", encoding="latin-1")


def scaled2(value: float) -> int:
    result = round(2.0 * value)
    if abs(2.0 * value - result) > 1e-8:
        raise ValueError(f"coefficient is not half-integral: {value}")
    return int(result)


def parse_mps(path: Path):
    row_type: dict[str, str] = {}
    rhs: dict[str, float] = collections.defaultdict(float)
    coefficients: dict[str, dict[str, float]] = collections.defaultdict(dict)
    objective: dict[str, float] = collections.defaultdict(float)
    lower: dict[str, float] = collections.defaultdict(float)
    upper: dict[str, float] = {}
    variables: set[str] = set()
    objective_row = None
    section = None

    with open_text(path) as handle:
        for raw in handle:
            fields = raw.split()
            if not fields or fields[0].startswith("*"):
                continue
            if not raw[0].isspace() and fields[0] in SECTIONS:
                section = fields[0]
                continue
            if section == "ROWS":
                row_type[fields[1]] = fields[0]
                if fields[0] == "N":
                    objective_row = fields[1]
            elif section == "COLUMNS":
                if "'MARKER'" in fields:
                    continue
                variable = fields[0]
                variables.add(variable)
                for offset in range(1, len(fields), 2):
                    row, value = fields[offset], float(fields[offset + 1])
                    if row == objective_row:
                        objective[variable] += value
                    else:
                        coefficients[row][variable] = coefficients[row].get(variable, 0.0) + value
            elif section == "RHS":
                for offset in range(1, len(fields), 2):
                    rhs[fields[offset]] += float(fields[offset + 1])
            elif section == "BOUNDS":
                kind, variable = fields[0], fields[2]
                value = float(fields[3]) if len(fields) > 3 else 0.0
                if kind == "LO":
                    lower[variable] = value
                elif kind == "UP":
                    upper[variable] = value
                elif kind == "FX":
                    lower[variable] = upper[variable] = value
                elif kind == "BV":
                    lower[variable], upper[variable] = 0.0, 1.0
                elif kind == "FR":
                    lower[variable], upper[variable] = -math.inf, math.inf
                elif kind == "MI":
                    lower[variable] = -math.inf
                elif kind == "PL":
                    upper[variable] = math.inf
                elif kind == "LI":
                    lower[variable] = value
                elif kind == "UI":
                    upper[variable] = value
                else:
                    raise ValueError(f"unknown bound type: {kind}")
    return row_type, rhs, coefficients, objective, lower, upper, variables


def read_solution(path: Path) -> dict[str, float]:
    values = {}
    with path.open("rt", encoding="utf-8") as handle:
        for raw in handle:
            fields = raw.split()
            if len(fields) != 2 or fields[0].startswith(("#", "=")):
                continue
            values[fields[0]] = float(fields[1])
    return values


def fmt_half(value2: int) -> str:
    return str(value2 // 2) if value2 % 2 == 0 else f"{value2 / 2:.1f}"


def main() -> None:
    from ortools.sat.python import cp_model

    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("--hint", type=Path)
    parser.add_argument("--time-limit", type=float, default=900.0)
    parser.add_argument("--workers", type=int, default=32)
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument(
        "--objective-upper-bound",
        type=float,
        help="Require an objective no larger than this value (use 38841.5 to search strictly below 38842).",
    )
    parser.add_argument(
        "--max-moved-entities",
        type=int,
        help="Limit how many rectangles may change either coordinate from the hinted layout.",
    )
    parser.add_argument("--solution", type=Path)
    args = parser.parse_args()

    row_type, rhs, rows, objective, lower, upper, variables = parse_mps(args.mps)
    hint = read_solution(args.hint) if args.hint else {}

    x_name: dict[tuple[str, str], str] = {}
    entities: set[str] = set()
    for variable in variables:
        match = re.fullmatch(r"x\[([rc]),([^]]+)\]", variable)
        if match:
            axis, entity = match.groups()
            x_name[axis, entity] = variable
            entities.add(entity)
    if len(entities) != 31 or len(x_name) != 62:
        raise RuntimeError("unexpected coordinate-variable structure")

    pairs = []
    for row in rows:
        match = re.fullmatch(r"choose1\[([^,]+),([^]]+)\]", row)
        if match:
            pairs.append(match.groups())
    if len(pairs) != 465:
        raise RuntimeError("unexpected rectangle-pair count")

    # Recover each rectangle size from the active big-M order inequality.
    sizes: dict[tuple[str, str], int] = {}
    for axis in "rc":
        for first, second in pairs:
            for direction, entity in (("lb", first), ("rt", second)):
                row = f"axisVdif{'LB' if direction == 'lb' else 'RT'}[{axis},{first},{second}]"
                z = f"zV[{axis},{direction},{first},{second}]"
                size = rhs[row] - rows[row][z]
                rounded = round(size)
                if abs(size - rounded) > 1e-8 or rounded <= 0:
                    raise RuntimeError(f"invalid recovered size at {row}: {size}")
                key = axis, entity
                if key in sizes and sizes[key] != rounded:
                    raise RuntimeError(f"inconsistent size for {key}")
                sizes[key] = int(rounded)
    if len(sizes) != 62:
        raise RuntimeError("failed to recover all rectangle dimensions")

    model = cp_model.CpModel()
    x = {}
    intervals = {"r": [], "c": []}
    for axis in "rc":
        for entity in sorted(entities):
            name = x_name[axis, entity]
            lb, ub = round(lower[name]), round(upper[name])
            x[axis, entity] = model.NewIntVar(lb, ub, name)
            intervals[axis].append(model.NewFixedSizeIntervalVar(x[axis, entity], sizes[axis, entity], f"I[{axis},{entity}]"))
            if name in hint:
                model.AddHint(x[axis, entity], round(hint[name]))
    model.AddNoOverlap2D(intervals["r"], intervals["c"])

    edge_rows = []
    for row in rows:
        match = re.fullmatch(r"DistSumLB\[([^,]+),([^]]+)\]", row)
        if match:
            edge_rows.append((match.group(1), match.group(2), row))
    if len(edge_rows) != 33:
        raise RuntimeError("unexpected edge count")

    distance2 = {}
    for first, second, sum_row in edge_rows:
        for axis in "rc":
            original = f"dist[{axis},{first},{second}]"
            ub2 = scaled2(upper[original])
            d2 = model.NewIntVar(0, ub2, f"dist2[{axis},{first},{second}]")
            distance2[axis, first, second] = d2
            if original in hint:
                model.AddHint(d2, scaled2(hint[original]))
            for prefix in ("compDistAxis1", "compDistAxis2"):
                row = f"{prefix}[{axis},{first},{second}]"
                expression = d2
                for variable, coefficient in rows[row].items():
                    if variable == original:
                        if coefficient != 1.0:
                            raise RuntimeError(f"unexpected distance coefficient at {row}")
                        continue
                    match_x = re.fullmatch(r"x\[([rc]),([^]]+)\]", variable)
                    if not match_x or coefficient not in {-1.0, 1.0}:
                        raise RuntimeError(f"unexpected compact distance row {row}")
                    expression += int(2 * coefficient) * x[match_x.group(1), match_x.group(2)]
                model.Add(expression >= scaled2(rhs[row]))
        model.Add(distance2["r", first, second] + distance2["c", first, second] >= scaled2(rhs[sum_row]))

    center2 = {}
    for axis in "rc":
        for entity in sorted(entities):
            original = f"center_dist[{axis},{entity}]"
            # Coordinate bounds and half-integral anchors make 256 a generous,
            # finite valid bound for the absolute deviation.
            d2 = model.NewIntVar(0, 256, f"center2[{axis},{entity}]")
            center2[axis, entity] = d2
            if original in hint:
                model.AddHint(d2, scaled2(hint[original]))
            for prefix in ("centerDistAxis1", "centerDistAxis2"):
                row = f"{prefix}[{axis},{entity}]"
                expression = d2
                for variable, coefficient in rows[row].items():
                    if variable == original:
                        if coefficient != 1.0:
                            raise RuntimeError(f"unexpected center coefficient at {row}")
                        continue
                    if variable != x_name[axis, entity] or coefficient not in {-1.0, 1.0}:
                        raise RuntimeError(f"unexpected center row {row}")
                    expression += int(2 * coefficient) * x[axis, entity]
                model.Add(expression >= scaled2(rhs[row]))
    model.Add(sum(center2.values()) >= scaled2(rhs["CenterDistSumLB"]))

    objective2 = 126 * sum(distance2.values()) + sum(center2.values())
    if args.objective_upper_bound is not None:
        model.Add(objective2 <= scaled2(args.objective_upper_bound))
    if args.max_moved_entities is not None:
        if not args.hint:
            raise ValueError("--max-moved-entities requires --hint")
        moved = []
        for entity in sorted(entities):
            moved_entity = model.NewBoolVar(f"moved[{entity}]")
            moved.append(moved_entity)
            for axis in "rc":
                name = x_name[axis, entity]
                if name not in hint:
                    raise ValueError(f"hint is missing coordinate {name}")
                model.Add(x[axis, entity] == round(hint[name])).OnlyEnforceIf(moved_entity.Not())
        model.Add(sum(moved) <= args.max_moved_entities)
    model.Minimize(objective2)

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = args.time_limit
    solver.parameters.num_search_workers = args.workers
    solver.parameters.random_seed = args.seed
    solver.parameters.log_search_progress = True
    solver.parameters.cp_model_presolve = True
    solver.parameters.linearization_level = 2
    status = solver.Solve(model)
    print(f"FINAL_STATUS {solver.StatusName(status)}")
    if status in {cp_model.OPTIMAL, cp_model.FEASIBLE}:
        best2 = round(solver.ObjectiveValue())
        print(f"FINAL_OBJECTIVE2 {best2}")
        print(f"FINAL_OBJECTIVE {best2 / 2:.17g}")
        print(f"FINAL_BOUND2 {solver.BestObjectiveBound():.17g}")
        print(f"FINAL_BOUND {solver.BestObjectiveBound() / 2:.17g}")
        if args.solution:
            coordinate = {(axis, entity): solver.Value(variable) for (axis, entity), variable in x.items()}
            distance_value2 = {key: solver.Value(variable) for key, variable in distance2.items()}
            center_value2 = {key: solver.Value(variable) for key, variable in center2.items()}
            args.solution.parent.mkdir(parents=True, exist_ok=True)
            with args.solution.open("wt", encoding="utf-8", newline="\n") as handle:
                handle.write(f"=obj= {best2 / 2:.17g}\n")
                for axis in "rc":
                    for entity in sorted(entities):
                        handle.write(f"x[{axis},{entity}] {coordinate[axis, entity]}\n")
                # Select one valid separation, preferring the row axis.  Each
                # selected order is induced by coordinates, hence all triangle
                # inequalities are automatically satisfied.
                for first, second in pairs:
                    selected = None
                    for axis in "rc":
                        if coordinate[axis, first] + sizes[axis, first] <= coordinate[axis, second]:
                            selected = f"zV[{axis},lb,{first},{second}]"
                            break
                        if coordinate[axis, second] + sizes[axis, second] <= coordinate[axis, first]:
                            selected = f"zV[{axis},rt,{first},{second}]"
                            break
                    if selected is None:
                        raise RuntimeError(f"CP solution overlaps: {first}, {second}")
                    handle.write(f"{selected} 1\n")
                for (axis, first, second), value2 in sorted(distance_value2.items()):
                    if value2:
                        handle.write(f"dist[{axis},{first},{second}] {fmt_half(value2)}\n")
                for (axis, entity), value2 in sorted(center_value2.items()):
                    if value2:
                        handle.write(f"center_dist[{axis},{entity}] {fmt_half(value2)}\n")
            print(f"FINAL_SOLUTION {args.solution}")
    else:
        print(f"FINAL_BOUND2 {solver.BestObjectiveBound():.17g}")
        print(f"FINAL_BOUND {solver.BestObjectiveBound() / 2:.17g}")


if __name__ == "__main__":
    main()
