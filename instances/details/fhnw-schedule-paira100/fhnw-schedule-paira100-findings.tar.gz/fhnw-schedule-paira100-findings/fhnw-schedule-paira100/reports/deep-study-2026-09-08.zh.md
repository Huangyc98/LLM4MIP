# fhnw-schedule-paira100 结构增强与最优性审计（2026-09-08）

## 结论

在严格整数语义下，本实例已由增强后的原始 Pair A 模型证明为全局最优：

```text
严格最优目标值  -15.1131165125934
primal bound     -15.1131165125934
dual bound       -15.1131165125934
relative gap       0
```

这是 **solver-verified global optimum**：保留原 MPS 的全部变量、约束和目标，只加入逐条审计为全局有效的冲突不等式与区间能量不等式；Gurobi 两次独立运行均闭合。它不是 DRAT/LRAT 一类形式化证明证书。

MIPLIB 页面显示的名义目标 `-15.1131226682367` 略低，但对应公开解不是严格整数解。公开解有 3 个二进制变量偏离最近整数，其中两个带目标系数的选择变量 `C4`、`C10` 均约为 `5.406e-6`，恰好造成约 `6.15564e-6` 的名义目标差异。将全部二进制变量严格舍入并重新优化连续变量后，目标正好变为上述严格最优值。

## 原模型结构

- 5,150 个变量：5,050 个二进制变量、100 个连续变量。
- 10,000 条约束、29,873 个非零元。
- 前 100 个二进制变量是项目选择变量，100 个连续变量是开始时间，其余 4,950 个二进制变量对应全部无序作业对的先后次序。
- 27 条单变量等式强制 27 个项目不被选择；其余 73 个项目各有一条活动时间窗约束。
- 每个作业对有两条三变量不重叠约束，共 `2*C(100,2)=9,900` 条；全部逐行恢复成功，右端项最大误差为 0。

时间窗的语义尤其重要：活动约束给出的是最晚**开始**时间 `u_i`，能量不等式使用的完成期限必须是

```text
d_i = u_i + p_i,
```

而不能直接把 `u_i` 当完成期限。本轮所有 cuts 与审计均使用修正后的 `d_i`。

## 有效不等式

### 确定性冲突

若根据 release time、processing time 和 completion deadline，`i` 在 `j` 前与 `j` 在 `i` 前都不可能，则加入

```text
z_i + z_j <= 1.
```

本实例共加入 196 条，经独立脚本逐条复算，无无效行。

### 区间能量约束

对区间 `[a,b]`，项目 `i` 无论如何安排都必须落在区间内的最少处理量为

```text
e_i(a,b) = max(0, p_i - max(0,a-r_i) - max(0,d_i-b)).
```

因此任意非重叠排程都满足

```text
sum_i e_i(a,b) z_i <= b-a.
```

从活动项目的 release/deadline 端点得到 4,973 个候选区间；LP 分离两轮分别加入 1,500 和 792 条，共 2,292 条。为避免浮点误伤，每条右端再放宽 `1e-11`。

最终 proof model 有 12,488 条约束，即原始 10,000 条加 196 条冲突约束和 2,292 条能量约束。

## 求解与复核

第一次求解使用 2 线程、严格可行性与整数容差 `1e-9`：

```text
status       OPTIMAL
runtime      0.835 s
nodes        1
objective    -15.113116512593402
bound        -15.113116512593404
gap          0
```

保存 proof MPS 后，以 1 线程、不同 seed、不同 cuts 参数及 `NumericFocus=3` 独立重跑：

```text
status       OPTIMAL
runtime      3.141 s
nodes        8
objective    -15.113116512593402
bound        -15.113116512593402
gap          0
```

最终解选择 23 个项目。将它直接代回未经修改的官方 MPS：

- 最大变量界违反：0；
- 最大整数性违反：0；
- 最大原始约束违反：`6.66e-15`；
- 大于 `1e-9` 的原始约束违反：0。

独立语义审计还确认：

- 原 MPS 的 10,000 条约束在 proof model 中没有缺失或改动；
- 9,900 条 pairwise 行与恢复的处理时间完全一致；
- 196 条冲突不等式全部有效；
- 2,292 条能量不等式全部能匹配使用 `d_i=u_i+p_i` 生成的合法区间约束；
- 没有未知的额外约束。

## 关键文件

- 官方原始实例：[`../input/fhnw-schedule-paira100.mps.gz`](../input/fhnw-schedule-paira100.mps.gz)
- 官方公开解：[`../input/fhnw-schedule-paira100-public.sol.gz`](../input/fhnw-schedule-paira100-public.sol.gz)
- 最优解：[`../solutions/global-optimal.sol`](../solutions/global-optimal.sol)
- proof MPS：[`../artifacts/energy-proof-proof.mps.gz`](../artifacts/energy-proof-proof.mps.gz)
- 第一次闭合结果：[`../artifacts/energy-proof.json`](../artifacts/energy-proof.json)
- 独立语义审计与重跑结果：[`../artifacts/proof-semantic-audit.json`](../artifacts/proof-semantic-audit.json)
- 生成与审计程序：[`../scripts/`](../scripts/)

## 证据边界

可以准确对外表述为：**通过结构恢复和全局有效能量 cuts，Gurobi 对严格整数模型给出了可复现的全局最优证明。**

不应表述为“目标优于 MIPLIB 页面数值”，因为页面数值来自容差内的近整数解；正确说法是：公开解严格化后与本轮最优解具有同一选择集合和同一严格目标，本轮补上了严格可行性与全局最优性证明。
