#!/usr/bin/env python3
"""Audit and exactly bracket fhnw-schedule-paira100 by nested packings.

No optimizer is called.  The script reads decimal MPS coefficients as Decimal,
checks every row of the Pair-A formulation, audits both published solutions,
generates conservative inner/outer common-deadline models, and constructs a
canonical original-model lift of the rounded best published selection.
"""

from __future__ import annotations

import argparse
import collections
from decimal import Decimal, getcontext
import gzip
import hashlib
import json
from pathlib import Path


getcontext().prec = 60
ZERO = Decimal(0)
ONE = Decimal(1)
HUNDRED = Decimal(100)


def open_text(path: Path):
    return gzip.open(path, "rt", encoding="latin-1") if path.suffix == ".gz" else path.open(encoding="latin-1")


def parse_mps(path: Path):
    senses: dict[str, str] = {}
    rhs: dict[str, Decimal] = collections.defaultdict(lambda: ZERO)
    columns: dict[str, dict[str, Decimal]] = collections.defaultdict(dict)
    rows: dict[str, dict[str, Decimal]] = collections.defaultdict(dict)
    objective: dict[str, Decimal] = collections.defaultdict(lambda: ZERO)
    bounds: dict[str, list[Decimal | None]] = collections.defaultdict(lambda: [ZERO, None])
    integer: set[str] = set()
    section = ""
    objective_row = ""
    integer_mode = False
    headers = {"NAME", "OBJSENSE", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "SOS", "INDICATORS", "ENDATA"}
    with open_text(path) as stream:
        for raw in stream:
            fields = raw.split()
            if not fields or fields[0].startswith("*"):
                continue
            if fields[0] in headers and (fields[0] not in {"RHS", "RANGES"} or len(fields) == 1):
                section = fields[0]
                continue
            if section == "ROWS":
                senses[fields[1]] = fields[0]
                if fields[0] == "N":
                    objective_row = fields[1]
            elif section == "COLUMNS":
                if len(fields) >= 3 and fields[1].strip("'") == "MARKER":
                    integer_mode = fields[2].strip("'") == "INTORG"
                    continue
                variable = fields[0]
                if integer_mode:
                    integer.add(variable)
                for pos in range(1, len(fields), 2):
                    row, value = fields[pos], Decimal(fields[pos + 1])
                    if row == objective_row:
                        objective[variable] += value
                    else:
                        columns[variable][row] = columns[variable].get(row, ZERO) + value
                        rows[row][variable] = rows[row].get(variable, ZERO) + value
            elif section == "RHS":
                for pos in range(1, len(fields), 2):
                    rhs[fields[pos]] = Decimal(fields[pos + 1])
            elif section == "BOUNDS":
                kind, variable = fields[0], fields[2]
                value = Decimal(fields[3]) if len(fields) > 3 else ZERO
                lo, up = bounds[variable]
                if kind in {"LO", "LI"}:
                    lo = value
                elif kind in {"UP", "UI"}:
                    up = value
                elif kind == "FX":
                    lo = up = value
                elif kind == "BV":
                    lo, up = ZERO, ONE
                elif kind == "FR":
                    lo = up = None
                elif kind == "MI":
                    lo = None
                elif kind == "PL":
                    up = None
                else:
                    raise ValueError(f"unsupported bound {kind}")
                bounds[variable] = [lo, up]
                if kind in {"LI", "UI", "BV"}:
                    integer.add(variable)
    return senses, rhs, dict(columns), dict(rows), dict(objective), dict(bounds), integer


def read_solution(path: Path):
    values: dict[str, Decimal] = {}
    declared = None
    with open_text(path) as stream:
        for raw in stream:
            fields = raw.split()
            if not fields:
                continue
            if fields[0] == "=obj=":
                declared = Decimal(fields[-1])
            elif raw.startswith("# Objective value ="):
                declared = Decimal(raw.split("=", 1)[1].strip())
            elif not raw.startswith("#") and len(fields) >= 2:
                values[fields[0]] = Decimal(fields[1])
    return values, declared


def audit_solution(values, declared, variables, senses, rhs, rows, objective, bounds, integer):
    recomputed = sum((objective.get(v, ZERO) * values.get(v, ZERO) for v in variables), ZERO)
    max_row_violation = ZERO
    worst_row = None
    nonzero_row_violations = 0
    for row, sense in senses.items():
        if sense == "N":
            continue
        activity = sum((a * values.get(v, ZERO) for v, a in rows[row].items()), ZERO)
        if sense == "L":
            violation = max(ZERO, activity - rhs[row])
        elif sense == "G":
            violation = max(ZERO, rhs[row] - activity)
        else:
            violation = abs(activity - rhs[row])
        if violation:
            nonzero_row_violations += 1
        if violation > max_row_violation:
            max_row_violation, worst_row = violation, row
    max_bound_violation = ZERO
    for v in variables:
        value = values.get(v, ZERO)
        lo, up = bounds.get(v, [ZERO, None])
        if lo is not None:
            max_bound_violation = max(max_bound_violation, lo - value)
        if up is not None:
            max_bound_violation = max(max_bound_violation, value - up)
    max_integer_violation = max((abs(values.get(v, ZERO) - values.get(v, ZERO).to_integral_value()) for v in integer), default=ZERO)
    fractional = sorted(
        ((v, values.get(v, ZERO), abs(values.get(v, ZERO) - values.get(v, ZERO).to_integral_value()))
         for v in integer
         if values.get(v, ZERO) != values.get(v, ZERO).to_integral_value()),
        key=lambda item: item[2], reverse=True,
    )
    return {
        "declared_objective": str(declared) if declared is not None else None,
        "recomputed_objective": str(recomputed),
        "listed_values": len(values),
        "max_row_violation": str(max_row_violation),
        "worst_row": worst_row,
        "nonzero_row_violations": nonzero_row_violations,
        "max_bound_violation": str(max(ZERO, max_bound_violation)),
        "max_integer_violation": str(max_integer_violation),
        "fractional_integer_values": [(v, str(x), str(d)) for v, x, d in fractional],
    }


def dstr(value: Decimal) -> str:
    return format(value, "f")


def write_compact(path: Path, name: str, eligible, release, duration, deadline, objective):
    thresholds = sorted({release[i] for i in eligible})
    with path.open("w", encoding="ascii") as out:
        out.write(f"NAME          {name}\n")
        out.write("ROWS\n N  OBJ\n")
        for k in range(len(thresholds)):
            out.write(f" L  K{k:03d}\n")
        out.write("COLUMNS\n    MARK0000  'MARKER'                 'INTORG'\n")
        for j in eligible:
            variable = f"C{j}"
            out.write(f"    {variable:<8}  OBJ       {dstr(objective[variable])}\n")
            for k, threshold in enumerate(thresholds):
                if release[j] >= threshold:
                    out.write(f"    {variable:<8}  K{k:03d}      {dstr(duration[j])}\n")
        out.write("    MARK0001  'MARKER'                 'INTEND'\nRHS\n")
        for k, threshold in enumerate(thresholds):
            out.write(f"    RHS1      K{k:03d}      {dstr(deadline - threshold)}\n")
        out.write("BOUNDS\n")
        for j in eligible:
            out.write(f" BV BND1      C{j}\n")
        out.write("ENDATA\n")


def suffix_violation(selection, eligible, release, duration, deadline):
    violation = ZERO
    for threshold in sorted({release[i] for i in eligible}):
        load = sum((duration[j] for j in eligible if selection[j] and release[j] >= threshold), ZERO)
        violation = max(violation, load - (deadline - threshold))
    return max(ZERO, violation)


def canonical_lift(selection, n, pairs, xvars, svars, yvars, release, duration_upper, objective):
    selected = sorted((i for i in range(n) if selection[i]), key=lambda i: (release[i], i))
    unselected = sorted((i for i in range(n) if not selection[i]), key=lambda i: (release[i], i))
    order = selected + unselected
    starts = [ZERO] * n
    current = ZERO
    previous = None
    for i in order:
        if previous is None:
            starts[i] = release[i]
        else:
            starts[i] = max(release[i], current)
        current = starts[i] + duration_upper[i]
        previous = i
    selected_completion = (
        starts[selected[-1]] + duration_upper[selected[-1]] if selected else ZERO
    )
    position = {job: pos for pos, job in enumerate(order)}
    values = {xvars[i]: Decimal(selection[i]) for i in range(n)}
    values.update({svars[i]: starts[i] for i in range(n)})
    for k, (i, j) in enumerate(pairs):
        values[yvars[k]] = ZERO if position[i] < position[j] else ONE
    obj = sum((objective.get(v, ZERO) * x for v, x in values.items()), ZERO)
    return values, obj, order, selected_completion, current


def write_solution(path: Path, values, objective):
    with path.open("w", encoding="ascii") as out:
        out.write(f"=obj= {dstr(objective)}\n")
        out.write("# Canonical strict lift of the rounded MIPLIB ID 3 selection.\n")
        for i in range(5150):
            variable = f"C{i}"
            out.write(f"{variable} {dstr(values[variable])}\n")


def main():
    here = Path(__file__).resolve().parent
    instance = here.parents[1]
    replay = instance / "replay" / "common-deadline"
    ap = argparse.ArgumentParser()
    ap.add_argument("--mps", type=Path, default=instance / "input" / "fhnw-schedule-paira100.mps.gz")
    ap.add_argument("--id3", type=Path, default=instance / "input" / "fhnw-schedule-paira100-public.sol.gz")
    ap.add_argument("--id2", type=Path, default=instance / "artifacts" / "common-deadline" / "official-id2.sol.gz")
    ap.add_argument("--output-dir", type=Path, default=replay)
    ap.add_argument("--solved-inner", type=Path, default=replay / "common-deadline-inner.mps")
    ap.add_argument("--solved-outer", type=Path, default=replay / "common-deadline-outer.mps")
    ap.add_argument("--inner-solution", type=Path, default=instance / "artifacts" / "common-deadline" / "inner-strict.sol")
    ap.add_argument("--outer-solution", type=Path, default=instance / "artifacts" / "common-deadline" / "outer-strict.sol")
    ap.add_argument("--lifted-solution", type=Path, default=instance / "solutions" / "global-optimal-exact-decimal.sol")
    args = ap.parse_args()

    senses, rhs, columns, rows, objective, bounds, integer = parse_mps(args.mps)
    variables = set(columns) | set(objective) | set(bounds)
    assert variables == {f"C{i}" for i in range(5150)}
    assert len(senses) == 10001 and senses["OBJ"] == "N"
    assert len(integer) == 5050 and len(variables - integer) == 100
    assert sum(len(rows[r]) for r in rows) == 29873

    n = 100
    xvars = [f"C{i}" for i in range(n)]
    svars = [f"C{100+i}" for i in range(n)]
    pairs = [(i, j) for i in range(n) for j in range(i + 1, n)]
    yvars = [f"C{200+k}" for k in range(len(pairs))]
    assert len(pairs) == 4950
    assert set(integer) == set(xvars) | set(yvars)
    assert set(objective) == set(xvars) and all(objective[v] < ZERO for v in xvars)
    assert all(bounds[v] == [ZERO, ONE] for v in integer)
    assert all(bounds[v][1] == HUNDRED for v in svars)

    duration_samples = [[] for _ in range(n)]
    pair_rows = set()
    for k, (i, j) in enumerate(pairs):
        even, odd, y = f"R{2*k}", f"R{2*k+1}", yvars[k]
        pair_rows.update((even, odd))
        assert senses[even] == senses[odd] == "L"
        assert rows[even] == {svars[i]: ONE, svars[j]: -ONE, y: -HUNDRED}
        assert rows[odd] == {svars[i]: -ONE, svars[j]: ONE, y: HUNDRED}
        duration_samples[i].append(-rhs[even])
        duration_samples[j].append(HUNDRED - rhs[odd])

    duration_lower = [min(sample) for sample in duration_samples]
    duration_upper = [max(sample) for sample in duration_samples]
    duration_spread = [duration_upper[i] - duration_lower[i] for i in range(n)]
    assert all(ZERO < duration_lower[i] <= duration_upper[i] < ONE for i in range(n))
    assert max(duration_spread) < Decimal("1e-12")

    release = [bounds[v][0] if bounds[v][0] is not None else ZERO for v in svars]
    eligible, fixed_zero, latest = [], [], {}
    final_rows = set()
    for i in range(n):
        row = f"R{9900+i}"
        final_rows.add(row)
        if senses[row] == "E":
            assert rows[row] == {xvars[i]: ONE} and rhs[row] == ZERO
            fixed_zero.append(i)
        else:
            assert senses[row] == "L"
            assert rows[row] == {xvars[i]: HUNDRED, svars[i]: ONE}
            latest[i] = rhs[row] - HUNDRED
            eligible.append(i)
    assert len(eligible) == 73 and len(fixed_zero) == 27
    assert set(senses) - {"OBJ"} == pair_rows | final_rows
    assert all(release[i] == ZERO for i in fixed_zero)
    assert len({release[i] for i in eligible}) == len(eligible)

    # Literal-decimal inner and outer common-deadline packings.  The intended
    # data have a common deadline 1, but repeated decimal MPS values differ in
    # their final digits.  These envelopes give rigorous set inclusions.
    inner_deadline = min(latest[i] + duration_upper[i] for i in eligible)
    outer_deadline = max(latest[i] + duration_lower[i] for i in eligible)
    intended_deadline_error = max(
        max(abs(latest[i] + sample - ONE) for sample in duration_samples[i])
        for i in eligible
    )
    assert inner_deadline <= outer_deadline
    assert intended_deadline_error < Decimal("1e-12")
    assert inner_deadline + sum(duration_upper, ZERO) < HUNDRED

    id3_values, id3_declared = read_solution(args.id3)
    id2_values, id2_declared = read_solution(args.id2)
    id3_audit = audit_solution(id3_values, id3_declared, variables, senses, rhs, rows, objective, bounds, integer)
    id2_audit = audit_solution(id2_values, id2_declared, variables, senses, rhs, rows, objective, bounds, integer)
    assert Decimal(id3_audit["max_integer_violation"]) > Decimal("1e-6")
    assert Decimal(id2_audit["max_integer_violation"]) == ZERO
    assert Decimal(id2_audit["max_row_violation"]) < Decimal("1e-12")

    rounded_selection = [int(id3_values.get(xvars[i], ZERO).to_integral_value()) for i in range(n)]
    assert all(not rounded_selection[i] for i in fixed_zero)
    inner_violation = suffix_violation(rounded_selection, eligible, release, duration_upper, inner_deadline)
    outer_violation = suffix_violation(rounded_selection, eligible, release, duration_lower, outer_deadline)
    assert inner_violation == outer_violation == ZERO

    lifted, lifted_objective, lifted_order, selected_completion, lift_end = canonical_lift(
        rounded_selection, n, pairs, xvars, svars, yvars, release, duration_upper, objective
    )
    lifted_audit = audit_solution(lifted, lifted_objective, variables, senses, rhs, rows, objective, bounds, integer)
    assert Decimal(lifted_audit["max_row_violation"]) == ZERO
    assert Decimal(lifted_audit["max_bound_violation"]) == ZERO
    assert Decimal(lifted_audit["max_integer_violation"]) == ZERO

    args.output_dir.mkdir(parents=True, exist_ok=True)
    inner_path = args.output_dir / "compact_inner_exact.mps"
    outer_path = args.output_dir / "compact_outer_exact.mps"
    lift_path = args.output_dir / "rounded_id3_canonical_lift.sol"
    mapping_path = args.output_dir / "exact_bracketing_mapping.json"
    write_compact(inner_path, "fhnw-paira100-inner", eligible, release, duration_upper, inner_deadline, objective)
    write_compact(outer_path, "fhnw-paira100-outer", eligible, release, duration_lower, outer_deadline, objective)
    write_solution(lift_path, lifted, lifted_objective)

    # Read the generated models back through the independent MPS parser.
    for path in (inner_path, outer_path):
        cs, crhs, ccols, crows, cobj, cbounds, cint = parse_mps(path)
        assert len(cs) == 74 and len(ccols) == len(cobj) == len(cbounds) == len(cint) == 73
        assert sum(len(crows[r]) for r in crows) == 2701

    # Independently inspect the separately generated and solved 100-row
    # envelope models.  Their extra 27 rows are duplicate release-zero
    # thresholds, so they are equivalent to the 73-row versions above.
    def check_solved_compact(model_path, solution_path, duration, deadline):
        cs, crhs, ccols, crows, cobj, cbounds, cint = parse_mps(model_path)
        cvariables = set(ccols) | set(cobj) | set(cbounds)
        assert len(cs) == 101 and set(cvariables) == {xvars[i] for i in eligible}
        assert set(cint) == cvariables and all(cbounds[v] == [ZERO, ONE] for v in cvariables)
        assert cobj == {xvars[i]: objective[xvars[i]] for i in eligible}
        for i in range(n):
            row = f"K{i:03d}"
            assert cs[row] == "L" and crhs[row] == deadline - release[i]
            assert crows[row] == {
                xvars[j]: duration[j] for j in eligible if release[j] >= release[i]
            }
        cvalues, cdeclared = read_solution(solution_path)
        caudit = audit_solution(
            cvalues, cdeclared, cvariables, cs, crhs, crows, cobj, cbounds, cint
        )
        assert Decimal(caudit["max_row_violation"]) == ZERO
        assert Decimal(caudit["max_bound_violation"]) == ZERO
        assert Decimal(caudit["max_integer_violation"]) == ZERO
        selection = tuple(i for i in eligible if cvalues.get(xvars[i], ZERO) == ONE)
        return caudit, selection

    solved_inner_audit, solved_inner_selection = check_solved_compact(
        args.solved_inner, args.inner_solution, duration_upper, inner_deadline
    )
    solved_outer_audit, solved_outer_selection = check_solved_compact(
        args.solved_outer, args.outer_solution, duration_lower, outer_deadline
    )
    assert solved_inner_selection == solved_outer_selection
    assert solved_inner_audit["recomputed_objective"] == solved_outer_audit["recomputed_objective"]

    strategy_lift, strategy_lift_declared = read_solution(args.lifted_solution)
    strategy_lift_audit = audit_solution(
        strategy_lift, strategy_lift_declared, variables, senses, rhs, rows,
        objective, bounds, integer
    )
    strategy_lift_selection = tuple(
        i for i in range(n) if strategy_lift.get(xvars[i], ZERO) == ONE
    )
    assert strategy_lift_selection == solved_inner_selection
    assert Decimal(strategy_lift_audit["recomputed_objective"]) == Decimal(
        solved_inner_audit["recomputed_objective"]
    )
    assert Decimal(strategy_lift_audit["max_row_violation"]) == ZERO
    assert Decimal(strategy_lift_audit["max_bound_violation"]) == ZERO
    assert Decimal(strategy_lift_audit["max_integer_violation"]) == ZERO

    mapping = {
        "source_mps": str(args.mps),
        "jobs": n,
        "eligible_jobs": eligible,
        "explicitly_fixed_zero_jobs": fixed_zero,
        "pair_order_variables": len(yvars),
        "pair_disjunction_rows": len(pair_rows),
        "duration_max_spread": dstr(max(duration_spread)),
        "intended_common_deadline_max_error": dstr(intended_deadline_error),
        "inner_deadline": dstr(inner_deadline),
        "outer_deadline": dstr(outer_deadline),
        "deadline_bracket_width": dstr(outer_deadline - inner_deadline),
        "rounded_id3_selection": [i for i in range(n) if rounded_selection[i]],
        "rounded_id3_lifted_objective": dstr(lifted_objective),
        "rounded_id3_selected_completion": dstr(selected_completion),
        "rounded_id3_all_jobs_completion": dstr(lift_end),
        "lifted_order": lifted_order,
        "jobs_data": [
            {
                "job": i,
                "selection": xvars[i],
                "start": svars[i],
                "release": dstr(release[i]),
                "latest_start_if_selected": dstr(latest[i]) if i in latest else None,
                "duration_lower": dstr(duration_lower[i]),
                "duration_upper": dstr(duration_upper[i]),
                "reward": dstr(-objective[xvars[i]]),
            }
            for i in range(n)
        ],
    }
    with mapping_path.open("w", encoding="utf-8") as out:
        json.dump(mapping, out, indent=2)
        out.write("\n")

    report = {
        "status": "PASS",
        "sha256_mps": hashlib.sha256(args.mps.read_bytes()).hexdigest(),
        "sha256_id3": hashlib.sha256(args.id3.read_bytes()).hexdigest(),
        "sha256_id2": hashlib.sha256(args.id2.read_bytes()).hexdigest(),
        "structure": {
            "jobs": n,
            "eligible_selection_binaries": len(eligible),
            "explicitly_fixed_zero_selection_binaries": len(fixed_zero),
            "start_variables": len(svars),
            "pair_order_binaries": len(yvars),
            "pair_disjunction_rows": len(pair_rows),
            "compact_binaries": len(eligible),
            "compact_nested_rows": len(eligible),
            "compact_nonzeros": 2701,
            "duration_max_spread": dstr(max(duration_spread)),
            "inner_deadline": dstr(inner_deadline),
            "outer_deadline": dstr(outer_deadline),
            "deadline_bracket_width": dstr(outer_deadline - inner_deadline),
        },
        "official_id3": id3_audit,
        "official_id2": id2_audit,
        "rounded_id3_canonical_lift": {
            "objective": dstr(lifted_objective),
            "selected_jobs": sum(rounded_selection),
            "inner_packing_violation": dstr(inner_violation),
            "selected_completion": dstr(selected_completion),
            "all_jobs_completion": dstr(lift_end),
            "audit": lifted_audit,
        },
        "solved_exact_sandwich": {
            "inner_solution": solved_inner_audit,
            "outer_solution": solved_outer_audit,
            "same_selected_jobs": list(solved_inner_selection),
            "lifted_original_solution": strategy_lift_audit,
            "certified_original_objective": solved_inner_audit["recomputed_objective"],
        },
        "artifacts": {
            "inner_model": str(inner_path),
            "outer_model": str(outer_path),
            "mapping": str(mapping_path),
            "canonical_lift": str(lift_path),
        },
    }
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
