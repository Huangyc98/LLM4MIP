#!/usr/bin/env python3
"""Run the repository Decimal checker with the indented ``*RHS*`` fix.

The shared checker historically treats every token beginning with ``*`` as an
MPS comment.  In set3-09 the RHS vector itself is legally named ``*RHS*`` and
is indented, so only an asterisk in column one denotes a comment.  This wrapper
applies that one source-level correction in memory and then runs the checker on
the original, unmodified MPS bytes.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("checker", type=Path)
    parser.add_argument("mps", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--tolerance", default="0")
    parser.add_argument("--rounded-output", type=Path)
    args = parser.parse_args()

    source = args.checker.read_text(encoding="utf-8")
    old = 'if not tokens or tokens[0].startswith("*"):'
    new = 'if not tokens or raw.startswith("*"):'
    count = source.count(old)
    if count != 2:
        raise RuntimeError(f"expected two comment guards, found {count}")
    source = source.replace(old, new)
    argv = [str(args.checker), str(args.mps), str(args.solution), "--tolerance", args.tolerance]
    if args.rounded_output:
        argv += ["--rounded-output", str(args.rounded_output)]
    sys.argv = argv
    namespace = {"__name__": "__main__", "__file__": str(args.checker)}
    exec(compile(source, str(args.checker), "exec"), namespace)


if __name__ == "__main__":
    main()
