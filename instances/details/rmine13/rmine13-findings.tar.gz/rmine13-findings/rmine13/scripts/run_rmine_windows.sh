#!/usr/bin/env bash
set -u
base=/home/huangyicheng/miplib-rmine13-set3-09-20260908-agent-rmine_set3
export PYTHONPATH=/home/huangyicheng/copt80/lib/python/310
export LD_LIBRARY_PATH=/home/huangyicheng/copt80/lib:/home/huangyicheng/copt80/lib/python/deps
cd "$base" || exit 2
for window in 0-2 1-3 2-4 3-5 4-6 5-7 6-8 7-9 8-10 9-11 10-12; do
  python3 analysis/copt_structured_search.py \
    --model instances/rmine13.mps.gz \
    --start analysis/rmine13-public-rounded.sol \
    --outdir "analysis/rmine13-extraction-window-$window" \
    --mode rmine-extraction-window --window "$window" \
    --seconds 90 --threads 6 --aggressive || exit $?
done
