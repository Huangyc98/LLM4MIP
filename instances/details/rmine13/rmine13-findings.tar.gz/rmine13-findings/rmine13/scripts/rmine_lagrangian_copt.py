#!/usr/bin/env python3
"""Projected-subgradient Lagrangian relaxation for rmine capacity rows.

The 26 tcap rows are dualized.  What remains is the precedence/order-polytope
LP, i.e. a maximum/minimum closure problem; its LP vertices are integral.
This script is a numerical multiplier search.  A separate replay script turns
a selected finite-decimal multiplier vector into an integer min-cut audit.
"""

from __future__ import annotations

import argparse
import gzip
import json
import math
import time
from collections import defaultdict
from pathlib import Path

import coptpy as cp


def open_text(path: Path):
    return gzip.open(path, "rt", encoding="latin-1") if path.suffix == ".gz" else path.open(encoding="latin-1")


def parse_mps(path: Path):
    section = ""
    objective_row = None
    row_kind = {}
    rhs = defaultdict(float)
    terms = defaultdict(list)
    with open_text(path) as stream:
        for raw in stream:
            fields = raw.split()
            if not fields or raw.startswith("*"):
                continue
            if not raw[0].isspace() and fields[0] in {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}:
                section = fields[0]
                continue
            if section == "ROWS":
                row_kind[fields[1]] = fields[0]
                if fields[0] == "N":
                    objective_row = fields[1]
            elif section == "COLUMNS":
                if "'MARKER'" in fields:
                    continue
                variable = fields[0]
                for row, coefficient in zip(fields[1::2], fields[2::2]):
                    terms[row].append((variable, float(coefficient.replace("D", "E"))))
            elif section == "RHS":
                for row, value in zip(fields[1::2], fields[2::2]):
                    rhs[row] += float(value.replace("D", "E"))
    return objective_row, row_kind, rhs, terms


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--seconds", type=float, default=480.0)
    parser.add_argument("--upper-bound", type=float, required=True)
    parser.add_argument("--threads", type=int, default=2)
    parser.add_argument("--max-iterations", type=int, default=300)
    args = parser.parse_args()
    args.out.parent.mkdir(parents=True, exist_ok=True)

    objective_row, row_kind, rhs, terms = parse_mps(args.mps)
    capacity_names = sorted(name for name in row_kind if name.startswith("tcap_"))

    env = cp.Envr()
    model = env.createModel("rmine13-lagrangian-closure")
    model.read(str(args.mps))
    variables = model.getVars().getAll()
    by_name = {variable.name: variable for variable in variables}
    index = {variable.name: i for i, variable in enumerate(variables)}
    base_objective = [float(variable.getInfo(cp.COPT.Info.Obj)) for variable in variables]
    resources = []
    for name in capacity_names:
        resources.append({
            "name": name,
            "rhs": rhs[name],
            "indices": [index[v] for v, _ in terms[name]],
            "coefficients": [a for _, a in terms[name]],
        })
    for name in capacity_names:
        model.remove(model.getConstrByName(name))
    for variable in variables:
        variable.setType(cp.COPT.CONTINUOUS)
    model.setParam(cp.COPT.Param.Logging, 0)
    model.setParam(cp.COPT.Param.Threads, args.threads)
    model.setParam(cp.COPT.Param.FeasTol, 1e-9)

    lambdas = [0.0] * len(resources)
    best_bound = -math.inf
    best = None
    history = []
    wall_started = time.monotonic()
    scale = 1.8
    nonimproving = 0

    for iteration in range(1, args.max_iterations + 1):
        remaining = args.seconds - (time.monotonic() - wall_started)
        if remaining <= 0.5:
            break
        modified = base_objective.copy()
        constant = 0.0
        for multiplier, resource in zip(lambdas, resources):
            constant -= multiplier * resource["rhs"]
            for i, coefficient in zip(resource["indices"], resource["coefficients"]):
                modified[i] += multiplier * coefficient
        for variable, coefficient in zip(variables, modified):
            variable.setInfo(cp.COPT.Info.Obj, coefficient)
        model.setObjConst(constant)
        model.setParam(cp.COPT.Param.TimeLimit, max(0.5, remaining))
        solve_started = time.monotonic()
        model.solve()
        solve_seconds = time.monotonic() - solve_started
        if model.status != cp.COPT.OPTIMAL:
            history.append({"iteration": iteration, "status": int(model.status), "solve_seconds": solve_seconds})
            break
        values = list(model.getInfo(cp.COPT.Info.Value, model.getVars()))
        qvalue = float(model.objval)
        activities = [
            sum(values[i] * a for i, a in zip(resource["indices"], resource["coefficients"]))
            for resource in resources
        ]
        gradient = [activity - resource["rhs"] for activity, resource in zip(activities, resources)]
        fractionality = max(abs(value - round(value)) for value in values)
        improved = qvalue > best_bound + 1e-9
        if improved:
            best_bound = qvalue
            best = {
                "iteration": iteration,
                "numerical_global_lower_bound": qvalue,
                "multipliers": lambdas.copy(),
                "resource_activities": activities,
                "maximum_fractionality": fractionality,
            }
            nonimproving = 0
        else:
            nonimproving += 1
            if nonimproving >= 5:
                scale *= 0.6
                nonimproving = 0
        norm2 = sum(value * value for value in gradient)
        gap = max(0.0, args.upper_bound - qvalue)
        step = scale * gap / norm2 if norm2 > 1e-20 else 0.0
        record = {
            "iteration": iteration,
            "bound": qvalue,
            "best_bound": best_bound,
            "solve_seconds": solve_seconds,
            "maximum_capacity_excess": max(gradient),
            "minimum_capacity_excess": min(gradient),
            "maximum_fractionality": fractionality,
            "subgradient_norm2": norm2,
            "step": step,
            "scale": scale,
        }
        history.append(record)
        payload = {
            "method": "copt_projected_polyak_subgradient_lagrangian_maximum_closure",
            "classification": "NUMERICAL_GLOBAL_LOWER_BOUND",
            "elapsed_seconds": time.monotonic() - wall_started,
            "upper_bound_used_only_for_step_size": args.upper_bound,
            "resource_rows_dualized": len(resources),
            "capacity_row_names": capacity_names,
            "precedence_rows_retained": len(row_kind) - len(resources) - 1,
            "best": best,
            "history": history,
            "exact_certificate": False,
            "global_optimality_claim": False,
        }
        args.out.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(record), flush=True)
        if step == 0.0:
            break
        lambdas = [max(0.0, old + step * grad) for old, grad in zip(lambdas, gradient)]

    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
