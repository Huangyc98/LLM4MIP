#!/usr/bin/env python3
"""Replay one rmine Lagrangian bound by an exact integer maximum-closure cut.

Floating multipliers from the search are rounded to a requested number of
decimal places.  All resulting objective weights are then finite Decimals,
scaled exactly to integers, and the closure optimum is obtained as an integer
s-t min cut.  The reported rational value is therefore replayable without a
floating-point LP solve.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
import sys
from collections import deque
from collections import defaultdict
from decimal import Decimal, ROUND_FLOOR, getcontext
from pathlib import Path

getcontext().prec = 100
sys.setrecursionlimit(1_000_000)


class Dinic:
    """Sparse arbitrary-precision integer Dinic implementation."""

    def __init__(self, n: int):
        self.graph: list[list[list[int]]] = [[] for _ in range(n)]
        self.original_edges: list[tuple[int, int, int]] = []

    def add_edge(self, u: int, v: int, capacity: int) -> None:
        forward = [v, len(self.graph[v]), capacity]
        reverse = [u, len(self.graph[u]), 0]
        self.graph[u].append(forward)
        self.graph[v].append(reverse)
        self.original_edges.append((u, v, capacity))

    def maximum_flow(self, source: int, sink: int) -> int:
        total = 0
        n = len(self.graph)
        while True:
            level = [-1] * n
            level[source] = 0
            queue = deque([source])
            while queue:
                u = queue.popleft()
                for v, _reverse, capacity in self.graph[u]:
                    if capacity > 0 and level[v] < 0:
                        level[v] = level[u] + 1
                        queue.append(v)
            if level[sink] < 0:
                return total
            cursor = [0] * n

            def send(u: int, available: int) -> int:
                if u == sink:
                    return available
                while cursor[u] < len(self.graph[u]):
                    edge = self.graph[u][cursor[u]]
                    v, reverse, capacity = edge
                    if capacity > 0 and level[v] == level[u] + 1:
                        amount = send(v, min(available, capacity))
                        if amount:
                            edge[2] -= amount
                            self.graph[v][reverse][2] += amount
                            return amount
                    cursor[u] += 1
                return 0

            while True:
                amount = send(source, 10 ** 100)
                if not amount:
                    break
                total += amount

    def reachable(self, source: int) -> set[int]:
        seen = {source}
        queue = deque([source])
        while queue:
            u = queue.popleft()
            for v, _reverse, capacity in self.graph[u]:
                if capacity > 0 and v not in seen:
                    seen.add(v)
                    queue.append(v)
        return seen


def number(text: str) -> Decimal:
    return Decimal(text.replace("D", "E").replace("d", "e"))


def open_text(path: Path):
    return gzip.open(path, "rt", encoding="latin-1") if path.suffix == ".gz" else path.open(encoding="latin-1")


def parse_mps(path: Path):
    section = ""
    objective_row = None
    row_kind = {}
    rhs = defaultdict(Decimal)
    terms = defaultdict(list)
    variable_order = []
    seen = set()
    with open_text(path) as stream:
        for raw in stream:
            fields = raw.split()
            if not fields or raw.startswith("*"):
                continue
            if not raw[0].isspace() and fields[0] in {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}:
                section = fields[0]
                continue
            if section == "ROWS":
                row_kind[fields[1]] = fields[0]
                if fields[0] == "N":
                    objective_row = fields[1]
            elif section == "COLUMNS":
                if "'MARKER'" in fields:
                    continue
                variable = fields[0]
                if variable not in seen:
                    seen.add(variable)
                    variable_order.append(variable)
                for row, coefficient in zip(fields[1::2], fields[2::2]):
                    terms[row].append((variable, number(coefficient)))
            elif section == "RHS":
                for row, value in zip(fields[1::2], fields[2::2]):
                    rhs[row] += number(value)
    return objective_row, row_kind, rhs, terms, variable_order


def decimal_places(value: Decimal) -> int:
    return max(0, -value.as_tuple().exponent)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", type=Path, required=True)
    parser.add_argument("--search-result", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--multiplier-places", type=int, default=6)
    parser.add_argument("--weight-places", type=int, default=9)
    args = parser.parse_args()
    args.out.parent.mkdir(parents=True, exist_ok=True)

    objective_row, row_kind, rhs, terms, variables = parse_mps(args.mps)
    index = {name: i for i, name in enumerate(variables)}
    search = json.loads(args.search_result.read_text(encoding="utf-8"))
    capacity_names = search["capacity_row_names"]
    raw_lambdas = search["best"]["multipliers"]
    quantum = Decimal(1).scaleb(-args.multiplier_places)
    lambdas = [Decimal(str(value)).quantize(quantum) for value in raw_lambdas]
    if any(value < 0 for value in lambdas):
        raise RuntimeError("negative multiplier after quantization")

    weights = [Decimal(0)] * len(variables)
    for variable, coefficient in terms[objective_row]:
        weights[index[variable]] += coefficient
    constant = Decimal(0)
    for name, multiplier in zip(capacity_names, lambdas):
        constant -= multiplier * rhs[name]
        for variable, coefficient in terms[name]:
            weights[index[variable]] += multiplier * coefficient

    arcs = set()
    precedence_names = []
    for row, kind in row_kind.items():
        if kind == "N" or row in capacity_names:
            continue
        row_terms = [(index[v], a) for v, a in terms[row] if a]
        if rhs[row] != 0 or len(row_terms) != 2:
            raise RuntimeError(f"non-closure row {row}: kind={kind}, rhs={rhs[row]}, terms={row_terms}")
        if kind == "G":
            row_terms = [(i, -a) for i, a in row_terms]
            kind = "L"
        if kind != "L":
            raise RuntimeError(f"non-inequality closure row {row}: {kind}")
        positive = [i for i, a in row_terms if a == 1]
        negative = [i for i, a in row_terms if a == -1]
        if len(positive) != 1 or len(negative) != 1:
            raise RuntimeError(f"unexpected closure coefficients in {row}: {row_terms}")
        arcs.add((positive[0], negative[0]))
        precedence_names.append(row)

    # MPS objective numbers retain long decimal spellings, which would overflow
    # int64 if scaled literally.  Round every variable weight *downward* to a
    # common grid.  Since 0 <= x <= 1, this produces a pointwise lower objective
    # and hence a conservative, still rigorous lower bound after minimization.
    weight_quantum = Decimal(1).scaleb(-args.weight_places)
    rounded_weights = [value.quantize(weight_quantum, rounding=ROUND_FLOOR) for value in weights]
    rounding_losses = [value - rounded for value, rounded in zip(weights, rounded_weights)]
    if any(loss < 0 for loss in rounding_losses):
        raise RuntimeError("downward weight rounding invariant failed")
    scale = 10 ** args.weight_places
    int_weights = [int(value * scale) for value in rounded_weights]

    n = len(variables)
    source, sink = n, n + 1
    profits = [-value for value in int_weights]
    total_positive_profit = sum(max(0, value) for value in profits)
    infinity = total_positive_profit + 1
    network = Dinic(n + 2)
    for i, profit in enumerate(profits):
        if profit > 0:
            network.add_edge(source, i, profit)
        elif profit < 0:
            network.add_edge(i, sink, -profit)
    for u, v in arcs:
        network.add_edge(u, v, infinity)
    flow_value = network.maximum_flow(source, sink)
    reachable = network.reachable(source)
    cut_capacity = sum(capacity for u, v, capacity in network.original_edges if u in reachable and v not in reachable)
    if cut_capacity != flow_value:
        raise RuntimeError(f"max-flow/min-cut mismatch: cut={cut_capacity}, flow={flow_value}")
    selected_indices = sorted(i for i in range(n) if i in reachable)
    selected = [variables[i] for i in selected_indices]
    closure_violations = [(variables[u], variables[v]) for u, v in arcs if u in reachable and v not in reachable]
    selected_weight = sum(int_weights[i] for i in selected_indices)
    min_weight_from_flow = flow_value - total_positive_profit
    if selected_weight != min_weight_from_flow:
        raise RuntimeError(
            f"cut/flow mismatch: selected weight {selected_weight}, flow-derived {min_weight_from_flow}"
        )
    if closure_violations:
        raise RuntimeError(f"closure violations: {closure_violations[:10]}")
    exact_decimal = constant + Decimal(selected_weight) / Decimal(scale)
    exact_numerator, exact_denominator = exact_decimal.as_integer_ratio()
    signature = hashlib.sha256("\n".join(selected).encode("utf-8")).hexdigest()
    payload = {
        "method": "finite_decimal_lagrangian_integer_maximum_closure_min_cut",
        "classification": "EXACT_REPLAYABLE_GLOBAL_LOWER_BOUND",
        "model": str(args.mps),
        "source_search": str(args.search_result),
        "resource_rows_dualized": len(capacity_names),
        "capacity_row_names": capacity_names,
        "multipliers": [str(value) for value in lambdas],
        "multiplier_decimal_places": args.multiplier_places,
        "precedence_rows": len(precedence_names),
        "unique_precedence_arcs": len(arcs),
        "variables": n,
        "integer_weight_scale": str(scale),
        "weight_decimal_places": args.weight_places,
        "exact_lagrangian_constant": str(constant),
        "maximum_downward_weight_rounding": str(max(rounding_losses, default=Decimal(0))),
        "total_downward_weight_rounding": str(sum(rounding_losses, Decimal(0))),
        "total_positive_profit": str(total_positive_profit),
        "infinite_arc_capacity": str(infinity),
        "integer_max_flow_min_cut": str(flow_value),
        "integer_cut_capacity_recomputed": str(cut_capacity),
        "integer_selected_weight": str(selected_weight),
        "exact_bound_numerator": str(exact_numerator),
        "exact_bound_denominator": str(exact_denominator),
        "exact_bound_decimal": str(exact_decimal),
        "selected_variable_count": len(selected),
        "selected_variable_signature_sha256": signature,
        "selected_variables": selected,
        "closure_violation_count": len(closure_violations),
        "flow_cut_equality_verified": True,
        "nonnegative_multipliers_verified": True,
        "global_optimality_claim_for_original_mip": False,
        "interpretation": "The exact number is a global lower bound for the original minimization MIP, not a proof of optimality.",
    }
    args.out.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in payload.items() if key != "selected_variables"}, indent=2))


if __name__ == "__main__":
    main()
