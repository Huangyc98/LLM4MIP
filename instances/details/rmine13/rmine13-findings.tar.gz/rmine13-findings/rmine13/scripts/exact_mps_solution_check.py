#!/usr/bin/env python3
"""Evaluate an MPS solution with exact decimal arithmetic.

This intentionally implements the small free-MPS subset used by the studied
MIPLIB instances.  Missing solution entries are interpreted as zero.
"""

from __future__ import annotations

import argparse
import gzip
from collections import defaultdict
from decimal import Decimal, getcontext
from pathlib import Path


getcontext().prec = 80


def number(text: str) -> Decimal:
    return Decimal(text.replace("D", "E").replace("d", "e"))


def open_text(path: Path):
    if path.suffix == ".gz":
        return gzip.open(path, "rt", encoding="latin-1")
    return path.open(encoding="latin-1")


def read_solution(path: Path) -> dict[str, Decimal]:
    values: dict[str, Decimal] = {}
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8") as handle:
        for raw in handle:
            tokens = raw.split()
            if len(tokens) < 2 or tokens[0].startswith(("#", "=")):
                continue
            try:
                values[tokens[0]] = number(tokens[1])
            except Exception:
                continue
    return values


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--tolerance", type=Decimal, default=Decimal("1e-6"))
    parser.add_argument("--rounded-output", type=Path)
    args = parser.parse_args()
    values = read_solution(args.solution)

    section = ""
    row_types: dict[str, str] = {}
    rhs: dict[str, Decimal] = defaultdict(Decimal)
    ranges: dict[str, Decimal] = defaultdict(Decimal)
    variables: set[str] = set()
    integer_variables: set[str] = set()
    bound_records: list[list[str]] = []
    integer_mode = False
    with open_text(args.mps) as handle:
        for raw in handle:
            tokens = raw.split()
            if not tokens or tokens[0].startswith("*"):
                continue
            # Section headers start in column one.  An RHS data record may use
            # the literal vector name "RHS", so token matching alone would
            # incorrectly discard every such record.
            if not raw[0].isspace() and tokens[0] in {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}:
                section = tokens[0]
                continue
            if section == "ROWS":
                row_types[tokens[1]] = tokens[0]
            elif section == "COLUMNS":
                if "'MARKER'" in tokens:
                    integer_mode = "'INTORG'" in tokens
                    continue
                variable = tokens[0]
                variables.add(variable)
                if integer_mode:
                    integer_variables.add(variable)
            elif section == "RHS":
                for row, value in zip(tokens[1::2], tokens[2::2]):
                    rhs[row] += number(value)
            elif section == "RANGES":
                for row, value in zip(tokens[1::2], tokens[2::2]):
                    ranges[row] += number(value)
            elif section == "BOUNDS":
                bound_records.append(tokens)

    lower = {variable: Decimal(0) for variable in variables}
    upper: dict[str, Decimal | None] = {variable: None for variable in variables}
    for tokens in bound_records:
        kind, variable = tokens[0], tokens[2]
        value = number(tokens[3]) if len(tokens) > 3 else Decimal(0)
        if kind == "LO":
            lower[variable] = value
        elif kind == "UP":
            upper[variable] = value
        elif kind == "FX":
            lower[variable] = upper[variable] = value
        elif kind == "FR":
            lower[variable], upper[variable] = Decimal("-Infinity"), None
        elif kind == "MI":
            lower[variable] = Decimal("-Infinity")
        elif kind == "PL":
            upper[variable] = None
        elif kind == "BV":
            lower[variable], upper[variable] = Decimal(0), Decimal(1)
            integer_variables.add(variable)
        elif kind == "LI":
            lower[variable] = value
            integer_variables.add(variable)
        elif kind == "UI":
            upper[variable] = value
            integer_variables.add(variable)
        else:
            raise ValueError(f"unsupported MPS bound type {kind}")

    objective_rows = {row for row, kind in row_types.items() if kind == "N"}
    activity: dict[str, Decimal] = defaultdict(Decimal)
    objective = Decimal(0)
    section = ""
    with open_text(args.mps) as handle:
        for raw in handle:
            tokens = raw.split()
            if not tokens or tokens[0].startswith("*"):
                continue
            if not raw[0].isspace() and tokens[0] in {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}:
                section = tokens[0]
                continue
            if section != "COLUMNS" or "'MARKER'" in tokens:
                continue
            variable = tokens[0]
            x = values.get(variable, Decimal(0))
            for row, coefficient in zip(tokens[1::2], tokens[2::2]):
                term = number(coefficient) * x
                if row in objective_rows:
                    objective += term
                else:
                    activity[row] += term

    violations: list[tuple[Decimal, str, Decimal, Decimal, str]] = []
    for row, kind in row_types.items():
        if kind == "N":
            continue
        lhs, row_rhs = activity[row], rhs[row]
        row_range = ranges.get(row, Decimal(0))
        if row_range:
            width = abs(row_range)
            if kind == "G":
                row_lower, row_upper = row_rhs, row_rhs + width
            elif kind == "L":
                row_lower, row_upper = row_rhs - width, row_rhs
            elif row_range > 0:
                row_lower, row_upper = row_rhs, row_rhs + width
            else:
                row_lower, row_upper = row_rhs - width, row_rhs
            violation = max(Decimal(0), row_lower - lhs, lhs - row_upper)
        elif kind == "E":
            violation = abs(lhs - row_rhs)
        elif kind == "L":
            violation = max(Decimal(0), lhs - row_rhs)
        elif kind == "G":
            violation = max(Decimal(0), row_rhs - lhs)
        else:
            raise ValueError(f"unsupported MPS row type {kind}")
        if violation:
            violations.append((violation, row, lhs, row_rhs, kind))

    bound_violations: list[tuple[Decimal, str]] = []
    for variable in variables:
        x = values.get(variable, Decimal(0))
        violation = max(Decimal(0), lower[variable] - x)
        if upper[variable] is not None:
            violation = max(violation, x - upper[variable])
        if violation:
            bound_violations.append((violation, variable))
    integrality = [
        (abs(values.get(variable, Decimal(0)) - values.get(variable, Decimal(0)).to_integral_value()), variable)
        for variable in integer_variables
        if values.get(variable, Decimal(0)) != values.get(variable, Decimal(0)).to_integral_value()
    ]

    violations.sort(reverse=True)
    bound_violations.sort(reverse=True)
    integrality.sort(reverse=True)
    if args.rounded_output:
        with args.rounded_output.open("w", encoding="utf-8") as handle:
            handle.write("# Integer variables rounded to their nearest exact value\n")
            for variable in sorted(variables):
                value = values.get(variable, Decimal(0))
                if variable in integer_variables:
                    value = value.to_integral_value()
                if value:
                    handle.write(f"{variable} {value}\n")
        print(f"rounded_output={args.rounded_output}")
    tol = args.tolerance
    print(f"objective={objective}")
    print(
        f"rows={len(row_types)-len(objective_rows)} exact_row_violations={len(violations)} "
        f"row_violations_above_{tol}={sum(v[0] > tol for v in violations)} "
        f"max_row_violation={violations[0][0] if violations else 0}"
    )
    print(
        f"bound_violations_above_{tol}={sum(v[0] > tol for v in bound_violations)} "
        f"exact_integrality_violations={len(integrality)} "
        f"integrality_violations_above_{tol}={sum(v[0] > tol for v in integrality)} "
        f"max_integrality_violation={integrality[0][0] if integrality else 0}"
    )
    for violation, row, lhs, row_rhs, kind in violations[:10]:
        print(f"row={row} sense={kind} lhs={lhs} rhs={row_rhs} violation={violation}")


if __name__ == "__main__":
    main()
