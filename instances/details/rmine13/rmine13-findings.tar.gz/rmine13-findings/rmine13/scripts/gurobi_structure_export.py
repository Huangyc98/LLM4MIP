#!/usr/bin/env python3
"""Read-only Gurobi structural audit for cvrpb-n45k5vrpi.

This script deliberately never calls optimize().  It records the linear matrix,
general constraints, exact coefficient histograms, and repeated row/column
signatures from the original MPS as seen by Gurobi.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import platform
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

import gurobipy as gp


def stable_number(x: float) -> str:
    return format(float(x), ".17g")


def counter_json(counter: Counter, limit: int | None = None):
    items = sorted(counter.items(), key=lambda kv: (-kv[1], str(kv[0])))
    if limit is not None:
        items = items[:limit]
    return [[str(k), int(v)] for k, v in items]


def name_shape(name: str) -> str:
    return re.sub(r"\d+", "#", name)


class UnionFind:
    def __init__(self, n: int):
        self.parent = list(range(n))
        self.size = [1] * n

    def find(self, x: int) -> int:
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x

    def union(self, a: int, b: int):
        a, b = self.find(a), self.find(b)
        if a == b:
            return
        if self.size[a] < self.size[b]:
            a, b = b, a
        self.parent[b] = a
        self.size[a] += self.size[b]


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while chunk := f.read(1 << 20):
            h.update(chunk)
    return h.hexdigest()


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("mps", type=Path)
    ap.add_argument("output", type=Path)
    args = ap.parse_args()

    mps = args.mps.resolve()
    print(f"reading={mps}", flush=True)
    model = gp.read(str(mps))
    model.update()
    print(
        f"read_complete vars={model.NumVars} linear_rows={model.NumConstrs} "
        f"genconstrs={model.NumGenConstrs} nz={model.NumNZs}",
        flush=True,
    )

    vars_ = model.getVars()
    rows = model.getConstrs()
    gens = model.getGenConstrs()
    var_index = {v.VarName: i for i, v in enumerate(vars_)}
    A = model.getA().tocsr()
    Ac = A.tocsc()

    vtypes = Counter(v.VType for v in vars_)
    lb_hist = Counter(stable_number(v.LB) for v in vars_)
    ub_hist = Counter(stable_number(v.UB) for v in vars_)
    obj_hist = Counter(stable_number(v.Obj) for v in vars_)
    var_shapes = Counter(name_shape(v.VarName) for v in vars_)

    senses = Counter(r.Sense for r in rows)
    rhs_hist = Counter(stable_number(r.RHS) for r in rows)
    row_degree_hist = Counter(int(A.indptr[i + 1] - A.indptr[i]) for i in range(A.shape[0]))
    col_degree_hist = Counter(int(Ac.indptr[j + 1] - Ac.indptr[j]) for j in range(A.shape[1]))
    coeff_hist = Counter(stable_number(x) for x in A.data)
    row_shapes = Counter(name_shape(r.ConstrName) for r in rows)

    row_sig_groups = defaultdict(list)
    for i, r in enumerate(rows):
        lo, hi = A.indptr[i], A.indptr[i + 1]
        payload = [r.Sense, stable_number(r.RHS)]
        payload.extend(
            f"{int(j)}:{stable_number(x)}"
            for j, x in zip(A.indices[lo:hi], A.data[lo:hi])
        )
        digest = hashlib.sha256("|".join(payload).encode()).hexdigest()[:24]
        row_sig_groups[digest].append(i)

    col_sig_groups = defaultdict(list)
    for j, v in enumerate(vars_):
        lo, hi = Ac.indptr[j], Ac.indptr[j + 1]
        payload = [v.VType, stable_number(v.LB), stable_number(v.UB), stable_number(v.Obj)]
        payload.extend(
            f"{int(i)}:{stable_number(x)}"
            for i, x in zip(Ac.indices[lo:hi], Ac.data[lo:hi])
        )
        digest = hashlib.sha256("|".join(payload).encode()).hexdigest()[:24]
        col_sig_groups[digest].append(j)

    # Connected components of the linear row-column incidence graph.
    uf = UnionFind(len(vars_) + len(rows))
    offset = len(vars_)
    for i in range(A.shape[0]):
        for j in A.indices[A.indptr[i] : A.indptr[i + 1]]:
            uf.union(int(j), offset + i)
    comp_sizes = Counter(uf.find(i) for i in range(len(vars_) + len(rows)))

    gen_types = Counter()
    indicator_binvars = Counter()
    indicator_binvals = Counter()
    indicator_senses = Counter()
    indicator_rhs = Counter()
    indicator_degrees = Counter()
    indicator_coeffs = Counter()
    indicator_name_shapes = Counter()
    indicator_samples = []
    indicator_signature = Counter()
    other_gen_samples = []
    for gc in gens:
        typ = int(gc.GenConstrType)
        gen_types[typ] += 1
        if typ == int(gp.GRB.GENCONSTR_INDICATOR):
            binvar, binval, expr, sense, rhs = model.getGenConstrIndicator(gc)
            indicator_binvars[binvar.VType] += 1
            indicator_binvals[int(binval)] += 1
            indicator_senses[sense] += 1
            indicator_rhs[stable_number(rhs)] += 1
            terms = [(var_index[expr.getVar(k).VarName], stable_number(expr.getCoeff(k))) for k in range(expr.size())]
            indicator_degrees[len(terms)] += 1
            indicator_coeffs.update(c for _, c in terms)
            indicator_name_shapes[name_shape(gc.GenConstrName)] += 1
            signature = (
                int(binval), sense, stable_number(rhs),
                tuple(c for _, c in terms),
                tuple(vars_[j].VType for j, _ in terms),
            )
            indicator_signature[repr(signature)] += 1
            if len(indicator_samples) < 30:
                indicator_samples.append({
                    "name": gc.GenConstrName,
                    "binvar": binvar.VarName,
                    "binval": int(binval),
                    "sense": sense,
                    "rhs": stable_number(rhs),
                    "terms": [[vars_[j].VarName, c] for j, c in terms[:20]],
                    "term_count": len(terms),
                })
        elif len(other_gen_samples) < 20:
            other_gen_samples.append({"name": gc.GenConstrName, "type": typ})

    exact_row_class_sizes = Counter(len(v) for v in row_sig_groups.values())
    exact_col_class_sizes = Counter(len(v) for v in col_sig_groups.values())
    repeated_rows = sorted((v for v in row_sig_groups.values() if len(v) > 1), key=len, reverse=True)
    repeated_cols = sorted((v for v in col_sig_groups.values() if len(v) > 1), key=len, reverse=True)

    report = {
        "provenance": {
            "script": Path(__file__).name,
            "read_only_no_optimize": True,
            "mps_path": str(mps),
            "mps_sha256_compressed": sha256_file(mps),
            "python": sys.version,
            "platform": platform.platform(),
            "gurobi_version": list(gp.gurobi.version()),
        },
        "model": {
            "name": model.ModelName,
            "sense": "min" if model.ModelSense == gp.GRB.MINIMIZE else "max",
            "objective_constant": stable_number(model.ObjCon),
            "variables": model.NumVars,
            "linear_constraints": model.NumConstrs,
            "general_constraints": model.NumGenConstrs,
            "linear_nonzeros": model.NumNZs,
            "sos": model.NumSOS,
            "quadratic_constraints": model.NumQConstrs,
            "quadratic_objective_nonzeros": model.NumQNZs,
        },
        "variables": {
            "types": counter_json(vtypes),
            "lower_bounds": counter_json(lb_hist, 30),
            "upper_bounds": counter_json(ub_hist, 30),
            "objective_coefficients": counter_json(obj_hist, 50),
            "objective_nonzero_count": sum(v.Obj != 0 for v in vars_),
            "name_shapes": counter_json(var_shapes, 30),
            "linear_degree_histogram": counter_json(col_degree_hist, 50),
            "first": [
                {"index": i, "name": v.VarName, "type": v.VType, "lb": stable_number(v.LB),
                 "ub": stable_number(v.UB), "obj": stable_number(v.Obj),
                 "linear_degree": int(Ac.indptr[i + 1] - Ac.indptr[i])}
                for i, v in list(enumerate(vars_))[:30]
            ],
        },
        "linear_matrix": {
            "senses": counter_json(senses),
            "rhs": counter_json(rhs_hist, 50),
            "coefficient_histogram": counter_json(coeff_hist, 100),
            "row_degree_histogram": counter_json(row_degree_hist, 100),
            "row_name_shapes": counter_json(row_shapes, 30),
            "connected_component_count": len(comp_sizes),
            "component_size_histogram": counter_json(Counter(comp_sizes.values()), 50),
            "largest_component_sizes": sorted(comp_sizes.values(), reverse=True)[:30],
            "first_rows": [
                {
                    "index": i,
                    "name": r.ConstrName,
                    "sense": r.Sense,
                    "rhs": stable_number(r.RHS),
                    "terms": [
                        [vars_[int(j)].VarName, stable_number(x)]
                        for j, x in zip(
                            A.indices[A.indptr[i] : A.indptr[i + 1]],
                            A.data[A.indptr[i] : A.indptr[i + 1]],
                        )
                    ][:30],
                    "term_count": int(A.indptr[i + 1] - A.indptr[i]),
                }
                for i, r in list(enumerate(rows))[:30]
            ],
        },
        "general_constraints": {
            "types": counter_json(gen_types),
            "indicator_binvar_types": counter_json(indicator_binvars),
            "indicator_binvals": counter_json(indicator_binvals),
            "indicator_senses": counter_json(indicator_senses),
            "indicator_rhs": counter_json(indicator_rhs, 50),
            "indicator_degrees": counter_json(indicator_degrees, 100),
            "indicator_coefficients": counter_json(indicator_coeffs, 100),
            "indicator_name_shapes": counter_json(indicator_name_shapes, 30),
            "indicator_algebraic_signature_counts": counter_json(indicator_signature, 100),
            "indicator_samples": indicator_samples,
            "other_samples": other_gen_samples,
        },
        "exact_repetition": {
            "row_signature_class_size_histogram": counter_json(exact_row_class_sizes, 50),
            "column_signature_class_size_histogram": counter_json(exact_col_class_sizes, 50),
            "largest_identical_row_classes": [
                {"size": len(g), "names": [rows[i].ConstrName for i in g[:20]]}
                for g in repeated_rows[:20]
            ],
            "largest_identical_column_classes": [
                {"size": len(g), "names": [vars_[j].VarName for j in g[:20]]}
                for g in repeated_cols[:20]
            ],
            "scope_note": "Exact signatures include absolute linear row/column indices; general-constraint roles are reported separately.",
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"wrote={args.output} bytes={args.output.stat().st_size}", flush=True)


if __name__ == "__main__":
    main()
