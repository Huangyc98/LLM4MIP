# `rmine13`：严格修复解、精确 closure 下界与历史实验归档

研究日期：2026-09-08。

官方 MIPLIB 页面：<https://miplib.zib.de/instance_details_rmine13.html>

官方 MPS：[下载 `rmine13.mps.gz`](https://miplib.zib.de/WebData/instances/rmine13.mps.gz)

## 当前结论

`rmine13` 的全局最优值仍然 **open**。本目录中的 primal 搜索、有限 cut 筛选和
受限邻域证书均没有证明原问题最优。当前证据按等级分列如下：

| bound | value | evidence status |
|---|---:|---|
| strict feasible UB | `-3495.3706609999999806509` | 将公开 tolerance 解逐变量取整后，在原始 MPS 上按有限十进制精确回放 |
| strongest recorded numerical LB | `-3496.99083` | COPT 10 小时浮点 dual bound；没有 portable proof trace |
| portable exact global LB | `-3504.689959073912780` | 有理数 Lagrangian maximum-closure 证书，保留可行整数 max-flow 与同容量 cut |

因此，对这个最小化问题，当前可独立检查的严格区间是

```text
-3504.689959073912780 <= OPT <= -3495.3706609999999806509.
```

区间宽度为 `9.3192980739127993491`，即 strict UB 绝对值的 `0.266618%`。
COPT 数值界更强，其相对 strict UB 的数值 gap 为
`1.6201690000000193491`（`0.046352%`），但它不能替代 portable exact 证书。

早期归档中的 exact LB
`-3508.946737452 = -877236684363 / 250000000` 仍作为当次实验的可回放结果保留；
当前证书的 `-3504.689959073912780` 更大、因而对最小化问题更强，已经取代旧值
成为 canonical portable exact LB。两个结果都没有与 strict UB 闭合，均不是
最优性证明。

## 问题背景与模型结构

`rmine13` 属于 MineLib 露天矿生产调度实例。背景可参见
[MineLib 论文](https://doi.org/10.1007/s10479-012-1258-3)。原模型有 23,980 个
`[0,1]` 整数变量、197,155 行和 485,784 个非零元，表示 2,197（`13^3`）个
矿块和 13 个时期。

| row family | count | meaning |
|---|---:|---|
| spatial precedence `gprec` | 175,346 | 三维边坡/空间先后关系 |
| temporal precedence `tprec` | 21,783 | 同一矿块的累计时间链 |
| capacity `tcap` | 26 | 每期两个资源容量约束 |

去掉 26 条容量行后，其余 197,129 行都是 RHS 为 0、系数为 `+1/-1` 的二元
precedence；固定容量乘子后的子问题因此是 maximum closure / minimum cut。

原始 MPS SHA-256 为
`b99d1c9a31d724fade70872d02518e48b1ca60880b21206872303a0d147e4b95`。
当前结构清单见 [`artifacts/structure.json`](artifacts/structure.json)，早期结构读取
记录继续保存在
[`analysis/gurobi-13.0.1-structure.json`](analysis/gurobi-13.0.1-structure.json)。

## 严格 primal 证据

MIPLIB ID 2 的公开向量目标为 `-3495.3706624382535`，但它不是严格整数点：
3 个变量偏离整数，最大偏差约 `5.8576e-6`，并有两条 precedence 行各违反
`5e-9`。原始公开解和逐字审计分别见
[`input/rmine13-public.sol.gz`](input/rmine13-public.sol.gz) 与
[`logs/public-solution-exact.log`](logs/public-solution-exact.log)。

逐变量取整只损失 `0.0000014382534443491` 的目标值，并得到 strict UB
`-3495.3706609999999806509`。当前 canonical 解是
[`solutions/rmine13-strict-rounded.sol`](solutions/rmine13-strict-rounded.sol)，
独立 Decimal-60 记录见
[`artifacts/strict-ub-exact-audit.json`](artifacts/strict-ub-exact-audit.json)：

```text
exact row violations             0 / 197155
exact bound violations           0
exact integrality violations     0
```

origin/main 的早期严格候选格式
[`solutions/rmine13-public-rounded-strict.sol`](solutions/rmine13-public-rounded-strict.sol)
及其审计
[`logs/public-rounded-strict-exact.log`](logs/public-rounded-strict-exact.log) 继续保留，
以保证原实验入口与哈希记录可追溯。

## 当前 portable exact lower bound

26 个有理化容量乘子保存在
[`artifacts/exact-lb-lambda.json`](artifacts/exact-lb-lambda.json)。整数 max-flow、
同容量 cut 和完整有理数 witness 保存在
[`artifacts/exact-lb-cert.json.gz`](artifacts/exact-lb-cert.json.gz)，其 SHA-256 为
`cdcb5882d1ee03817746325465a7ca473576cff06f5b21aa7f84aef0ba33290b`。

独立 replay 返回 `verified=true`，scaled flow 与 cut 均为
`1231971994479658124406100329`，并给出

```text
-876172489768478194996176911 / 250000000000000000000000
  = -3504.689959073912780.
```

保留的输出见
[`artifacts/exact-lb-verification.json`](artifacts/exact-lb-verification.json)。验证器
不调用 Gurobi/COPT，也不重新求 max-flow；它检查模型 SHA、乘子非负性、网络
容量、flow 容量与守恒、`flow=cut` 及最终有理下界。

## 当前结构化负结果

以下结果只排除明确限定的候选集或邻域，不能外推成全局最优证明：

- 有限 `K=80` pair-conflict 筛选没有加入 cut；
- 600 秒 triple-cover 筛选覆盖 periods 0--8，检查 881,568 个 triples，其中
  866,619 个满足 root LP sum 大于 2，未找到 exact minimal triple cover；
- 非局部一对一交换扫描 1,454,216 个 pair，三期 cycle 扫描 33,628 个，未得到
  同时满足 precedence 和两个资源的严格改善；
- 4,800-column、18,434-row multi-cone restricted master 在 480.108 秒内搜索
  2,616,228 个节点，未找到 incumbent；这不是完整 master 的 infeasibility proof；
- 12 个单边界子问题各自使用该边界全部 193--277 个生成列，均在 root 证明
  严格改善不可行，但不覆盖跨多个边界组合。

详细说明与机器记录见
[`reports/structured-search.md`](reports/structured-search.md)、
[`artifacts/multi-cone/`](artifacts/multi-cone/)、
[`artifacts/triple-cover-screen-result.json`](artifacts/triple-cover-screen-result.json) 和
[`artifacts/triple-cover-screen-validation.json`](artifacts/triple-cover-screen-validation.json)。

## origin/main 早期实验归档

以下入口全部继续保留。它们仍有校准和复现价值，但旧下界已被上面的 10 小时
数值界和新 exact certificate 取代。

### 全模型短跑

| 运行 | 时限 | 状态 | incumbent | numerical bound | nodes |
|---|---:|---|---:|---:|---:|
| 无 start 的协调冷启动 | 600 s | TIME_LIMIT | `-3475.085457` | `-3502.2642471768054` | 544 |
| 严格候选 warm start | 600 s | TIME_LIMIT | `-3495.3706610000013` | `-3503.6206933022077` | 1 |

warm-start 的结果与日志位于
[`experiments/full-rounded-start/`](experiments/full-rounded-start/)。冷启动原始目录
未收入该归档；两行都是浮点数值，且均弱于当前 COPT 10 小时数值界。

### 连续三期与五期窗口

三期窗口固定窗口外开采进度。11 个窗口中 9 个由 COPT 数值闭合，`[1,3]` 和
`[2,4]` 在 90 秒限时；所有严格 incumbent 均未改善。各 `result.json`、
`solver.log` 和输出解保存在 [`experiments/`](experiments/) 下的
`extraction-window-*` 目录。

`[10,12]` 曾显示 `-3495.3706614869925`，但原始输出有 23 个非整数值及一条极小
容量残差；取整后回到 strict UB。因此约 `4.87e-7` 的表面改善只是容差效应：

- [`solutions/rmine13-window10-12-raw-copt.sol`](solutions/rmine13-window10-12-raw-copt.sol)
- [`logs/window10-12-raw-copt-exact.log`](logs/window10-12-raw-copt-exact.log)
- [`solutions/rmine13-window10-12-rounded.sol`](solutions/rmine13-window10-12-rounded.sol)
- [`logs/window10-12-rounded-exact.log`](logs/window10-12-rounded-exact.log)

四个五期窗口 `[0,4]`、`[3,7]`、`[6,10]`、`[8,12]` 也全部限时且 incumbent
不变；完整材料位于 `experiments/extraction-window5-*`。

### 已被取代的早期 closure 证书

早期 300 次 closure-oracle 搜索的最好浮点值是 `-3508.929020352369`，记录见
[`analysis/lagrangian-search.json`](analysis/lagrangian-search.json)。旧的大整数
replay 证书
[`analysis/lagrangian-exact-replay.json`](analysis/lagrangian-exact-replay.json)
给出：

```text
integer max-flow = recomputed cut    2302599098935
integer selected weight             -2016583787452
closure violations                  0
old exact lower bound               -877236684363 / 250000000
                                    = -3508.946737452
```

该值仍是有效严格全局下界，但已被 `-3504.689959073912780` 严格加强。

### 求解环境与许可证纠正

早期正式优化主要使用 altman 上的 COPT 8.0.4。旧文曾把 euler4 的 Gurobi
许可证描述成 size-limited；该判断不正确。2026-09-08 已现场验证 euler4 使用
**full Gurobi 13.0.1 license**，能够读取并优化该规模模型。归档继续保留当时的
COPT 运行事实，但不能把 solver 选择解释成 Gurobi license size limit。

## 复现

在 `instances/rmine13/` 下检查旧归档与当前关键文件哈希：

```sh
sha256sum -c SHA256SUMS
sha256sum -c input/SHA256SUMS
```

复核当前 strict UB：

```sh
python scripts/exact_decimal_audit.py \
  --mps input/rmine13.mps.gz \
  --solution solutions/rmine13-strict-rounded.sol \
  --out /tmp/rmine13-strict-ub-audit.json
```

重放当前 portable exact LB：

```sh
python scripts/exact_lagrangian_certificate.py verify \
  input/rmine13.mps.gz \
  artifacts/exact-lb-cert.json.gz
```

从保留乘子重建新证书：

```sh
python scripts/exact_lagrangian_certificate.py make \
  input/rmine13.mps.gz \
  artifacts/exact-lb-lambda.json \
  /tmp/rmine13-exact-lb-cert.json.gz
```

重放旧 closure 证书：

```sh
python scripts/rmine_lagrangian_exact_replay.py \
  --mps input/rmine13.mps.gz \
  --search-result analysis/lagrangian-search.json \
  --out replay.json \
  --multiplier-places 6 \
  --weight-places 9
```

旧 replay 的预期结果是 `exact_bound_decimal = -3508.946737452` 且
`flow_cut_equality_verified = true`。早期 exact checker、COPT 搜索和窗口实验入口
仍保存在 [`scripts/`](scripts/) 与 [`experiments/`](experiments/)；它们不改变
当前“未证明 optimal”的结论。
