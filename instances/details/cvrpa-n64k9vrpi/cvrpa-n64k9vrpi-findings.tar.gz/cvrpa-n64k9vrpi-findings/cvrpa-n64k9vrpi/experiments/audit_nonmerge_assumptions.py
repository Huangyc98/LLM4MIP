#!/usr/bin/env python3
"""Audit every data-dependent premise used by the k=10 nonmerge model."""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
import re
from pathlib import Path


def parse_dzn(path: Path) -> tuple[int, int, list[int], list[list[int]]]:
    text = path.read_text(encoding="utf-8")
    n = int(re.search(r"\bN\s*=\s*(\d+)\s*;", text).group(1))
    capacity = int(re.search(r"\bCapacity\s*=\s*(\d+)\s*;", text).group(1))
    demand = [0] + [
        int(value)
        for value in re.findall(
            r"-?\d+", re.search(r"Demand\s*=\s*\[(.*?)\]\s*;", text, re.S).group(1)
        )
    ]
    matrix_text = re.search(r"Distance\s*=\s*\[\|(.*?)\|\]\s*;", text, re.S).group(1)
    distance = [
        [int(value) for value in re.findall(r"-?\d+", row)]
        for row in matrix_text.split("|")
        if re.findall(r"-?\d+", row)
    ]
    if len(demand) != n + 1 or len(distance) != n + 1:
        raise ValueError("unexpected DZN dimensions")
    return n, capacity, demand, distance


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("dzn", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--routes", type=int, default=10)
    args = parser.parse_args()

    n, capacity, demand, distance = parse_dzn(args.dzn)
    customers = range(1, n + 1)
    total = sum(demand)
    depot_slacks = [
        distance[0][i] + distance[0][j] - distance[i][j]
        for i, j in itertools.combinations(customers, 2)
    ]
    triangle_violations = []
    for i in range(n + 1):
        for middle in range(n + 1):
            if middle == i:
                continue
            for j in range(n + 1):
                if j == i or j == middle:
                    continue
                slack = distance[i][middle] + distance[middle][j] - distance[i][j]
                if slack < 0:
                    triangle_violations.append((i, middle, j, slack))

    routes = args.routes
    numerator = (routes - 1) * (capacity + 1) - total
    denominator = routes - 2
    minimum_route_load = math.ceil(numerator / denominator)
    small_subset_counts = {}
    small_subsets = []
    for size in range(1, n + 1):
        if sum(sorted(demand[1:])[:size]) >= minimum_route_load:
            break
        count = 0
        for subset in itertools.combinations(customers, size):
            subset_demand = sum(demand[i] for i in subset)
            if subset_demand < minimum_route_load:
                count += 1
                small_subsets.append({"customers": list(subset), "demand": subset_demand})
        small_subset_counts[str(size)] = count

    two_largest_demands = sorted(demand[1:], reverse=True)[:2]
    output = {
        "schema": "cvrpa-k10-nonmerge-premises-v1",
        "dzn_sha256": hashlib.sha256(args.dzn.read_bytes()).hexdigest(),
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "customers": n,
        "capacity": capacity,
        "total_demand": total,
        "fixed_route_count": routes,
        "distance_matrix_symmetric": all(
            distance[i][j] == distance[j][i]
            for i in range(n + 1)
            for j in range(n + 1)
        ),
        "general_ordered_triangle_inequalities_checked": (n + 1) * n * (n - 1),
        "general_ordered_triangle_violation_count": len(triangle_violations),
        "maximum_general_triangle_violation": max(
            (-row[3] for row in triangle_violations), default=0
        ),
        "customer_pair_depot_triangle_inequalities_checked": len(depot_slacks),
        "customer_pair_depot_triangle_violation_count": sum(s < 0 for s in depot_slacks),
        "minimum_customer_pair_depot_triangle_slack": min(depot_slacks),
        "merge_argument_uses_only_depot_triangle_inequalities": True,
        "minimum_route_load_derivation": {
            "inequality": (
                f"{total} >= L + {routes - 1}*({capacity + 1}-L), "
                f"so L >= ceil({numerator}/{denominator})"
            ),
            "minimum_integer_load": minimum_route_load,
        },
        "two_largest_customer_demands": two_largest_demands,
        "maximum_sum_of_two_singleton_loads": sum(two_largest_demands),
        "at_most_one_singleton_route": sum(two_largest_demands) < capacity + 1,
        "customers_forbidden_as_singletons_by_minimum_load": [
            i for i in customers if demand[i] < minimum_route_load
        ],
        "eligible_singleton_customers": [
            i for i in customers if demand[i] >= minimum_route_load
        ],
        "minimum_load_subset_cut_counts_by_cardinality": small_subset_counts,
        "minimum_load_subset_cut_count": len(small_subsets),
        "minimum_load_subsets": small_subsets,
    }
    if output["customer_pair_depot_triangle_violation_count"]:
        raise AssertionError("a depot-triangle inequality required for route merging fails")
    if not output["distance_matrix_symmetric"]:
        raise AssertionError("route reversal in the merge argument requires symmetry")
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(output, sort_keys=True))


if __name__ == "__main__":
    main()
