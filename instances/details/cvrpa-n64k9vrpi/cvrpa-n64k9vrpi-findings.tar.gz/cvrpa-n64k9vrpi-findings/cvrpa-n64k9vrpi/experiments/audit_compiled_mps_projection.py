#!/usr/bin/env python3
"""Run the repository's generic exact compiled-MPS-to-CVRP projection audit."""

from pathlib import Path
import runpy

runpy.run_path(
    str(
        Path(__file__).resolve().parents[2]
        / "cvrpb-n45k5vrpi"
        / "experiments"
        / "audit_compiled_mps_projection.py"
    ),
    run_name="__main__",
)
