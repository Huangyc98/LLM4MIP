#!/usr/bin/env python3
"""Lift a CVRPLIB route solution into the anonymous indicator MPS.

The first five source arrays in the compiled MiniZinc model are successor,
predecessor, vehicle, load, and arrivalTime.  They each have length ``3*N``.
After these semantic values are fixed, COPT is used only to complete the
compiler-introduced auxiliary variables.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path

import coptpy as cp
from coptpy import COPT


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1 << 20):
            digest.update(chunk)
    return digest.hexdigest()


def parse_dzn(path: Path) -> tuple[int, int, list[int], list[list[int]]]:
    text = path.read_text(encoding="utf-8")
    n = int(re.search(r"\bN\s*=\s*(\d+)\s*;", text).group(1))
    capacity = int(re.search(r"\bCapacity\s*=\s*(\d+)\s*;", text).group(1))
    demand_text = re.search(r"Demand\s*=\s*\[(.*?)\]\s*;", text, re.S).group(1)
    demands = [int(value) for value in re.findall(r"-?\d+", demand_text)]
    distance_text = re.search(r"Distance\s*=\s*\[\|(.*?)\|\]\s*;", text, re.S).group(1)
    distance = []
    for raw_row in distance_text.split("|"):
        row = [int(value) for value in re.findall(r"-?\d+", raw_row)]
        if row:
            distance.append(row)
    if len(demands) != n or len(distance) != n + 1:
        raise ValueError("unexpected DZN dimensions")
    if any(len(row) != n + 1 for row in distance):
        raise ValueError("distance matrix is not square")
    return n, capacity, demands, distance


def parse_routes(path: Path) -> tuple[list[list[int]], int]:
    routes = []
    cost = None
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.startswith("Route #"):
            routes.append([int(value) for value in line.split(":", 1)[1].split()])
        elif line.startswith("Cost "):
            cost = int(line.split()[1])
    if cost is None:
        raise ValueError("route file has no Cost line")
    return routes, cost


def build_semantic_values(
    n: int,
    capacity: int,
    demands: list[int],
    distance: list[list[int]],
    routes: list[list[int]],
) -> tuple[list[int], dict[str, object]]:
    node_count = 3 * n
    successor = [0] * node_count
    predecessor = [0] * node_count
    vehicle = [0] * node_count
    load = [0] * node_count
    arrival = [0] * node_count

    assigned = set()
    route_costs = []
    route_loads = []
    for vehicle_index in range(1, n + 1):
        start = n + vehicle_index
        end = 2 * n + vehicle_index
        route = routes[vehicle_index - 1] if vehicle_index <= len(routes) else []
        chain = [start, *route, end]
        for tail, head in zip(chain, chain[1:]):
            successor[tail - 1] = head
        for customer in route:
            if customer in assigned or not 1 <= customer <= n:
                raise ValueError(f"bad or duplicated customer {customer}")
            assigned.add(customer)
            vehicle[customer - 1] = vehicle_index
        vehicle[start - 1] = vehicle[end - 1] = vehicle_index

        cumulative_load = 0
        cumulative_distance = 0
        previous = 0
        for customer in route:
            load[customer - 1] = cumulative_load
            cumulative_load += demands[customer - 1]
            cumulative_distance += distance[previous][customer]
            arrival[customer - 1] = cumulative_distance
            previous = customer
        cumulative_distance += distance[previous][0]
        arrival[end - 1] = cumulative_distance
        load[end - 1] = cumulative_load
        route_costs.append(cumulative_distance)
        route_loads.append(cumulative_load)

    expected_customers = set(range(1, n + 1))
    if assigned != expected_customers:
        raise ValueError(f"customers missing: {sorted(expected_customers - assigned)}")
    if any(route_load > capacity for route_load in route_loads):
        raise ValueError("route exceeds capacity")

    for vehicle_index in range(1, n + 1):
        end = 2 * n + vehicle_index
        next_start = n + (vehicle_index % n) + 1
        successor[end - 1] = next_start
    for tail, head in enumerate(successor, start=1):
        if not 1 <= head <= node_count or predecessor[head - 1] != 0:
            raise ValueError(f"successor is not a permutation at {tail}->{head}")
        predecessor[head - 1] = tail

    semantic = successor + predecessor + vehicle + load + arrival
    decoded = {
        "n_customers": n,
        "node_count": node_count,
        "capacity": capacity,
        "successor": successor,
        "predecessor": predecessor,
        "vehicle": vehicle,
        "load": load,
        "arrival_time": arrival,
        "route_count_nonempty": len(routes),
        "route_costs": route_costs,
        "route_loads": route_loads,
        "objective": sum(route_costs),
    }
    return semantic, decoded


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("dzn", type=Path)
    parser.add_argument("routes", type=Path)
    parser.add_argument("out", type=Path)
    parser.add_argument("--seconds", type=float, default=900)
    parser.add_argument("--threads", type=int, default=32)
    parser.add_argument("--solution-name", default="cvrpa-1401-full.sol")
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    n, capacity, demands, distance = parse_dzn(args.dzn)
    routes, stated_cost = parse_routes(args.routes)
    semantic, decoded = build_semantic_values(n, capacity, demands, distance, routes)
    if decoded["objective"] != stated_cost:
        raise ValueError(f"recomputed {decoded['objective']} != stated {stated_cost}")
    (args.out / "semantic-witness.json").write_text(
        json.dumps(decoded, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )

    model = cp.Envr().createModel("cvrpa-route-lift")
    model.read(str(args.mps))
    variables_object = model.getVars()
    variables = (
        variables_object.getAll()
        if hasattr(variables_object, "getAll")
        else list(variables_object)
    )
    by_name = {variable.name: variable for variable in variables}
    missing = []
    fixed_semantic = 0
    for index, value in enumerate(semantic):
        name = f"X_INTRODUCED_{index}_"
        variable = by_name.get(name)
        if variable is None:
            missing.append(name)
            continue
        variable.setInfo(COPT.Info.LB, value)
        variable.setInfo(COPT.Info.UB, value)
        fixed_semantic += 1
    objective = by_name["objective"]
    objective.setInfo(COPT.Info.LB, stated_cost)
    objective.setInfo(COPT.Info.UB, stated_cost)

    model.setParam(COPT.Param.Logging, 1)
    model.setLogFile(str(args.out / "copt-route-lift.log"))
    model.setParam(COPT.Param.Threads, args.threads)
    model.setParam(COPT.Param.TimeLimit, args.seconds)
    model.setParam(COPT.Param.RelGap, 0.0)
    try:
        model.setParam(COPT.Param.GPUMode, 0)
    except Exception:
        pass
    model.solve()

    result = {
        "provenance": {
            "mps_sha256": sha256(args.mps),
            "dzn_sha256": sha256(args.dzn),
            "routes_sha256": sha256(args.routes),
            "copt_version": [
                COPT.VERSION_MAJOR,
                COPT.VERSION_MINOR,
                COPT.VERSION_TECHNICAL,
            ],
            "cpu_only_gpu_mode": 0,
        },
        "model_variables_after_copt_read": len(variables),
        "model_rows_after_copt_read": len(model.getConstrs()),
        "semantic_variables_fixed": fixed_semantic + 1,
        "source_array_ids_substituted_by_compiler": missing,
        "route_count_nonempty": len(routes),
        "stated_and_recomputed_objective": stated_cost,
        "status": int(model.status),
        "has_mip_solution": int(model.hasmipsol),
    }
    for key, attribute in (
        ("objective", "objval"),
        ("best_bound", "bestbnd"),
        ("relative_gap", "mipgap"),
        ("node_count", "nodecnt"),
        ("runtime", "solvingtime"),
    ):
        try:
            result[key] = float(getattr(model, attribute))
        except Exception:
            pass
    if model.hasmipsol:
        model.writeSol(str(args.out / args.solution_name))
    (args.out / "copt-route-lift-summary.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print("RESULT_JSON=" + json.dumps(result, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
