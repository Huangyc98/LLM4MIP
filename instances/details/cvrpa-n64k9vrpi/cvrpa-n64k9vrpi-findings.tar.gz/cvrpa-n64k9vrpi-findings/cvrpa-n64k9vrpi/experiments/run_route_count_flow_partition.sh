#!/usr/bin/env bash
# Independent directed-flow formulation for the five hard route-count cases.
set -euo pipefail

root="${1:-/home/yicheng/miplib-cvrpa-20260908}"
seconds="${2:-1200}"
threads="${3:-4}"
python_bin="${PYTHON_BIN:-/home/wyc/miniconda3/envs/milp-ps/bin/python}"
solver_script="$root/gurobi_standard_cvrp_flow.py"
dzn="$root/experiments/A-n64-k9.vrp.dzn"
routes="$root/experiments/A-n64-k9.sol"
run_root="$root/route-count-flow-partition"

mkdir -p "$run_root"
: > "$run_root/pids.tsv"
pids=()
for route_count in $(seq 10 14); do
  out="$run_root/k${route_count}"
  mkdir -p "$out"
  "$python_bin" "$solver_script" "$dzn" "$routes" "$out" \
    --seconds "$seconds" --threads "$threads" \
    --minimum-routes "$route_count" --maximum-routes "$route_count" \
    --maximum-objective 1400 > "$out/stdout.log" 2>&1 &
  pid=$!
  pids+=("$pid")
  printf '%s\t%s\n' "$route_count" "$pid" >> "$run_root/pids.tsv"
done

status=0
for pid in "${pids[@]}"; do
  if ! wait "$pid"; then
    status=1
  fi
done
date --iso-8601=seconds > "$run_root/completed-at.txt"
exit "$status"
