#!/usr/bin/env python3
"""Exact demand-only screening for singleton branches of the k=10 cutoff.

If a target-1400 ten-route solution existed while the published nine-route
optimum is 1401, no two routes could have combined load at most 100: merging
such a pair is cost-nonincreasing for a symmetric metric CVRP.  Consequently,
if customer ``s`` is a singleton of demand ``d``, each of the other nine route
loads must lie in ``[101-d, 100]``.  This program exhaustively tests whether the
remaining demand multiset admits such a nine-bin partition.

The search uses only integer arithmetic.  Equal partial bin loads are
canonicalized, so a completed INFEASIBLE run is an exact exhaustive result,
although it is not a standalone proof trace.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from functools import lru_cache
from pathlib import Path


def parse_demands(path: Path) -> tuple[int, list[int]]:
    text = path.read_text(encoding="utf-8")
    capacity = int(re.search(r"\bCapacity\s*=\s*(\d+)\s*;", text).group(1))
    raw = re.search(r"Demand\s*=\s*\[(.*?)\]\s*;", text, re.S).group(1)
    return capacity, [int(value) for value in re.findall(r"-?\d+", raw)]


def exact_partition(
    indexed_demands: list[tuple[int, int]],
    bins: int,
    lower: int,
    capacity: int,
) -> tuple[list[list[int]] | None, int]:
    items = sorted(indexed_demands, key=lambda pair: (-pair[1], pair[0]))
    suffix = [0] * (len(items) + 1)
    for pos in range(len(items) - 1, -1, -1):
        suffix[pos] = suffix[pos + 1] + items[pos][1]
    decisions: dict[tuple[int, tuple[int, ...]], tuple[int, tuple[int, ...]]] = {}

    @lru_cache(maxsize=None)
    def search(pos: int, loads: tuple[int, ...]) -> bool:
        if suffix[pos] < sum(max(0, lower - load) for load in loads):
            return False
        if suffix[pos] > sum(capacity - load for load in loads):
            return False
        if pos == len(items):
            return loads[0] >= lower

        _, demand = items[pos]
        tried_loads: set[int] = set()
        # Prefer fuller bins; this tends to find a witness quickly while the
        # cache still makes an infeasibility conclusion exhaustive.
        for slot in range(bins - 1, -1, -1):
            old = loads[slot]
            if old in tried_loads or old + demand > capacity:
                continue
            tried_loads.add(old)
            updated = list(loads)
            updated[slot] += demand
            updated.sort()
            next_loads = tuple(updated)
            if search(pos + 1, next_loads):
                decisions[(pos, loads)] = (old + demand, next_loads)
                return True
        return False

    initial = (0,) * bins
    feasible = search(0, initial)
    states = search.cache_info().currsize
    if not feasible:
        return None, states

    # Replay the canonical state decisions.  Bin identities are reconstructed
    # solely to emit a human-checkable demand partition.
    assignment: list[list[int]] = [[] for _ in range(bins)]
    loads_with_ids = [(0, slot) for slot in range(bins)]
    loads = initial
    for pos, (customer, demand) in enumerate(items):
        chosen_new_load, next_loads = decisions[(pos, loads)]
        for idx in range(len(loads_with_ids) - 1, -1, -1):
            old, bin_id = loads_with_ids[idx]
            if old + demand == chosen_new_load:
                assignment[bin_id].append(customer)
                loads_with_ids[idx] = (chosen_new_load, bin_id)
                loads_with_ids.sort()
                break
        else:  # pragma: no cover - internal consistency guard
            raise AssertionError("failed to replay cached partition")
        loads = next_loads
    if tuple(load for load, _ in loads_with_ids) != loads:
        raise AssertionError("replayed load vector differs from cached state")
    return assignment, states


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("dzn", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    capacity, demands = parse_demands(args.dzn)
    total = sum(demands)
    maximum_pair = sum(sorted(demands, reverse=True)[:2])
    implied_minimum_route_load = (9 * (capacity + 1) - total + 7) // 8
    results = []
    for singleton_demand in sorted(set(demands)):
        customer = demands.index(singleton_demand) + 1
        lower = capacity + 1 - singleton_demand
        if singleton_demand < 1:
            continue
        if lower > capacity:
            feasible, assignment, states = False, None, 0
            reason = "nonmerge lower load exceeds capacity"
        else:
            remaining = [
                (index, demand)
                for index, demand in enumerate(demands, start=1)
                if index != customer
            ]
            assignment, states = exact_partition(remaining, 9, lower, capacity)
            feasible = assignment is not None
            reason = "exact exhaustive load partition search"
        row = {
            "singleton_demand": singleton_demand,
            "representative_customer": customer,
            "other_route_load_interval": [lower, capacity],
            "feasible": feasible,
            "states": states,
            "reason": reason,
        }
        if assignment is not None:
            row["route_customers"] = assignment
            row["route_loads"] = [sum(demands[i - 1] for i in route) for route in assignment]
            flattened = [customer for route in assignment for customer in route]
            if sorted(flattened) != [i for i in range(1, len(demands) + 1) if i != customer]:
                raise AssertionError("partition does not cover exactly the remaining customers")
            if sum(row["route_loads"]) != total - singleton_demand:
                raise AssertionError("partition load sum is inconsistent")
            if not all(lower <= load <= capacity for load in row["route_loads"]):
                raise AssertionError("partition violates a route-load interval")
        results.append(row)

    output = {
        "schema": "cvrpa-k10-singleton-load-partition-v1",
        "dzn_sha256": hashlib.sha256(args.dzn.read_bytes()).hexdigest(),
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "capacity": capacity,
        "total_demand": total,
        "maximum_sum_of_two_customer_demands": maximum_pair,
        "at_most_one_singleton_under_nonmerge": maximum_pair < capacity + 1,
        "implied_minimum_route_load": implied_minimum_route_load,
        "customers_below_minimum_route_load": [
            index
            for index, demand in enumerate(demands, start=1)
            if demand < implied_minimum_route_load
        ],
        "eligible_singleton_customers": [
            index
            for index, demand in enumerate(demands, start=1)
            if demand >= implied_minimum_route_load
        ],
        "results_by_singleton_demand": results,
    }
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(output, sort_keys=True))


if __name__ == "__main__":
    main()
