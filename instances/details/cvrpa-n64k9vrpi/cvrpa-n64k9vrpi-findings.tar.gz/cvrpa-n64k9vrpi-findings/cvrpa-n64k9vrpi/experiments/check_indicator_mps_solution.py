#!/usr/bin/env python3
"""Run the solver-independent exact indicator-MPS solution checker."""

from pathlib import Path
import runpy

runpy.run_path(
    str(
        Path(__file__).resolve().parents[2]
        / "cvrpb-n45k5vrpi"
        / "experiments"
        / "check_indicator_mps_solution.py"
    ),
    run_name="__main__",
)
