# Route-count analysis for cvrpa-n64k9vrpi

## Scope and claim

This note records the lower-bound work for the downloaded MPS with compressed
SHA-256
`725230241fe30c12913e054214190f0551e66f191835fba6bdca11c13e8bfbd8`.
Together with the full feasible MPS solution of objective 1401, the mixed
database/computational argument below establishes **OPT = 1401**.  The lower
bound is not a single portable formal certificate: it uses CVRPLIB's external
fixed-nine `Opt=yes` status and terminal commercial-solver results, in addition
to the coefficient audit and an exact rational certificate.

All cutoff models in this note ask whether a solution of integer route cost at
most 1400 exists.  Their terminal results, together with the fixed-nine status
and rational large-fleet certificate, establish the lower bound 1401 that
matches the incumbent.

## 1. Why route counts describe every relevant MPS solution

The recovered MiniZinc instance has 63 customers, 63 start-depot copies, and
63 end-depot copies.  The coefficient-level audit in
[`compiled-mps-projection.json`](compiled-mps-projection.json) proves directly
from the anonymous MPS that:

1. the effective 189-entry successor vector is a permutation;
2. the 63 end-to-next-start connector arcs have their required fixed values;
3. deleting those connector arcs leaves start-to-end paths and possible
   customer-only cycles;
4. positive customer demand and exact load propagation exclude every
   customer-only cycle;
5. every remaining path has total demand at most 100; and
6. the sum of end arrival times, which is the MPS objective, is at least the
   total integer length of the projected routes.

Thus every feasible MPS point projects to a capacity-feasible CVRP solution
with no greater objective.  Empty depot paths are ignored.  A nonempty path
contains at least one customer, so the number `K` of nonempty routes is at most
63.

The 63 positive demands sum to 848.  Since route capacity is 100,

`K >= ceil(848/100) = 9`.

Consequently `K=9,...,63` is an exhaustive disjunction for the lower-bound
argument.

The audit is intentionally one-way.  It need not establish that every abstract
CVRP solution lifts into the compiler auxiliaries to transfer a CVRP lower
bound to the MPS.  A reverse construction was performed separately for the
specific 1401 incumbent and then checked against every original MPS row.

## 2. The fixed-nine result is external evidence

The data audit in [`source-equivalence.json`](source-equivalence.json) matches
all demands, the capacity, coordinates, and all 4,096 rounded distances to
CVRPLIB `A-n64-k9`.  CVRPLIB's A-set table reports upper bound 1401 and
`Opt=yes` for the historical fixed-nine instance.  Its downloaded routes have
loads

`[99, 56, 100, 99, 98, 100, 97, 99, 100]`

and recomputed costs

`[184, 47, 236, 138, 152, 165, 118, 98, 263]`,

which sum to 1401.

This identifies the fixed-nine optimum according to the authoritative
database.  The repository does not contain an independently replayable proof
trace for CVRPLIB's `Opt=yes` status, so this layer must be described as an
external fixed-fleet result rather than an in-repository exact certificate.

## 3. Exact directed-flow cutoff formulation

[`../experiments/copt_standard_cvrp.py`](../experiments/copt_standard_cvrp.py)
uses a directed binary arc variable `x[i,j]` and a continuous remaining-load
flow `f[i,j]` for every distinct pair of depot/customer nodes.  It imposes:

- exactly one incoming and one outgoing selected arc at every customer;
- customer flow balance `inflow - outflow = demand[i]`;
- `f[i,j] <= (Q-demand[i])*x[i,j]` after leaving customer `i`, and
  `f[0,j] <= Q*x[0,j]` out of the depot;
- `f[i,j] >= demand[j]*x[i,j]` when entering customer `j`;
- zero flow on every return-to-depot arc;
- an exact route-count bound using `sum_j x[0,j]`; and
- the exact directed distance objective, optionally bounded above by 1400.

No explicit depot in-degree equation is needed: summing all customer in-degree
and out-degree equations makes depot in-degree equal depot out-degree.  A
customer-only component would contradict the sum of its strictly positive
flow balances.  The selected arcs therefore decompose into depot-to-depot
routes, and each route's outbound depot flow bounds its total load by 100.  The
formulation is an exact free-fleet CVRP model for this data, not a relaxation.

The terminal fixed-route runs used COPT 8.0.4 in CPU mode.  The executed
plain-model script recorded SHA-256
`79c71c7b586c0f25e9beaa73763daf58126eb740c825fa7ed061bd4f287a52b8`.
The current local script contains additional valid redundant strengthening,
so the executed hash—not a later source hash—is the identifier of these runs.

## 4. Exact customer-edge cutoff formulation

[`../experiments/gurobi_customer_edge_cutoff.py`](../experiments/gurobi_customer_edge_cutoff.py)
eliminates explicit depot edges and retains the 1,953 binary undirected
customer-customer edges.  For customer `i`, define its omitted depot-edge
multiplicity by

`d_i = 2 - degree_customer(i)`.

The model enforces `degree_customer(i) <= 2`, so `d_i` is an integer in
`0,1,2`; value two represents a singleton route.  If `E` is the number of
selected customer edges, the route count is exactly

`K = 63 - E`.

For every customer subset `S`, the rounded-capacity inequality becomes

`x(E(S)) <= |S| - ceil(demand(S)/100)`.

At every integer callback solution, the script applies this inequality to
each customer component.  That is complete at integrality: a degree-at-most-two
component is an isolated vertex, a path, or a cycle; a cycle violates the cut,
and a path whose load exceeds 100 also violates it.  Fractional min-cut
separation and the 53 pre-added three-customer cuts in the current script are
valid strengthening but are not required for logical completeness.

Symmetry of the distance matrix gives the exact eliminated-depot objective

`C = 2*sum_i c[0,i] + sum_{i<j}(c[i,j]-c[0,i]-c[0,j])*x[i,j]`.

The terminal runs below used Gurobi 13.0.1 in CPU mode and recorded executed
script SHA-256
`e1149aab6b44d5e0e2705d5cff3f81b43e459e06bfd243a5d60ce66232bf88dd`.
The current script additionally pre-adds 53 valid triple capacity cuts by
default; that strengthening does not change the represented integer CVRP.

## 5. Terminal exclusions for 12 through 16 routes

The following runs fixed `K`, imposed objective at most 1400, found no
incumbent, and reached a terminal infeasibility status.  COPT status 2 is
`INFEASIBLE`; Gurobi status 3 is `INFEASIBLE`.

| `K` | exact formulation and solver | terminal evidence | runtime | nodes |
|---:|---|---|---:|---:|
| 12 | directed flow, COPT 8.0.4 | status 2, no MIP solution | 3.929 s | 1 |
| 13 | directed flow, COPT 8.0.4 | status 2, no MIP solution | 1.647 s | 1 |
| 14 | directed flow, COPT 8.0.4 | status 2, no MIP solution | 1.316 s | 1 |
| 14 | customer edge, Gurobi 13.0.1 | `INFEASIBLE`, 102 distinct lazy sets and 198 fractional user cuts proposed | 41.177 s | 4,774 |
| 15 | customer edge, Gurobi 13.0.1 | `INFEASIBLE`, 17 distinct lazy sets proposed | 0.212 s | 1 |
| 16 | customer edge, Gurobi 13.0.1 | `INFEASIBLE`, 12 distinct lazy sets proposed | 0.115 s | 1 |

The selected terminal summaries, complete solver logs, and captured stdout are
archived under [`../logs/route-count/`](../logs/route-count/): COPT `k12`,
`k13`, and `k14`, plus Gurobi `k14`, `k15`, and `k16`.  The exact source files
executed in those historical runs are retained under
[`../logs/executed-scripts/`](../logs/executed-scripts/) so that the script
hashes embedded in the summaries resolve to bytes in this repository.

These are exhaustive terminal runs of exact integer formulations, not
heuristic failures to find a solution.  They are nevertheless
solver-certified computational exclusions rather than standalone formal proof
traces: neither commercial solver emitted an independently checkable
branch-and-bound proof object.

## 6. Route merging and the 11-route implication

The rounded `EUC_2D` matrix is symmetric.  The audit enumerates all 1,953
unordered distinct customer pairs (equivalently, all 3,906 orientations) and
verifies the particular depot-triangle inequality needed for route merging,

`c[i,j] <= c[i,0] + c[0,j]`.

The minimum slack over those pairs is 3.  This check is narrower than assuming
the entire rounded matrix is metric and is exactly what the following argument
uses.

Take any two routes whose integer loads sum to at most 100.  Reverse either
route if necessary, delete the two depot edges joining their chosen endpoints
to the depot, and join the endpoints directly.  Capacity remains valid, and
the verified depot-triangle inequality makes the merged route at least 3
units cheaper.  The number of routes decreases by one.

Therefore, **if every 10-route solution of cost at most 1400 has first been
excluded**, any 11-route solution of cost at most 1400 must have every pair of
route loads summing to at least 101.  The COPT option
`--forbid-mergeable-route-pairs` encodes exactly those integer pairwise load
inequalities.  Its fixed-11 run returned status 2 after 90.363 seconds and 912
nodes, using executed script SHA-256
`ba5fd1fbca64b376d836f57480c13ba87e845c1c614f030e3bec7203569597b0`.

That terminal run proves the implication

`no improving 10-route solution  =>  no improving 11-route solution`.

The fixed-10 argument in Section 8 now supplies its prerequisite.  Both layers
ultimately depend on accepting the external fixed-nine optimum.  The summary
itself correctly records
`mergeability_prerequisite = "all improving solutions with 10 routes excluded"`.

## 7. Exact rational exclusion for 17 or more routes

For `K>=17`, the customer-edge identity gives at most `63-17=46` selected
customer edges.  Write the nonnegative edge saving as

`s[i,j] = c[0,i] + c[0,j] - c[i,j]`.

Every represented CVRP solution is feasible for the following relaxation:

- `0 <= x[i,j] <= 1`;
- `sum_{j != i} x[i,j] <= 2` for every customer `i`;
- `sum_{i<j} x[i,j] <= 46`.

Maximizing total saving over this relaxation gives an upper bound on the
saving of every 17-or-more-route solution.  The certificate in
[`degree-relaxation-kge17-dual.json`](degree-relaxation-kge17-dual.json)
contains nonnegative half-integral customer multipliers, cardinality
multiplier 87, and the implied nonnegative upper-bound multipliers.  Its exact
dual value is

`saving <= 12341/2 = 6170.5`.

The eliminated-depot objective constant is

`2*sum_i c[0,i] = 7642`,

so every `K>=17` solution has

`C >= 7642 - 12341/2 = 2943/2 = 1471.5 > 1400`.

[`../experiments/check_degree_relaxation_dual.py`](../experiments/check_degree_relaxation_dual.py)
replays the certificate with Python `Fraction` and no optimization library.  It
checks all 1,953 dual inequalities, nonnegative multipliers, the DZN SHA-256,
the exact objective arithmetic, and the `>1400` conclusion.  Its report is
[`degree-relaxation-kge17-dual.validation.json`](degree-relaxation-kge17-dual.validation.json).

Unlike the 12--16 branch-and-bound statuses, this layer has a compact,
independently checkable rational certificate.

## 8. Terminal fixed-10 nonmerge exclusion

Accept CVRPLIB's fixed-nine optimum and suppose a 10-route solution of cost at
most 1400 exists.  If two of its route loads sum to at most 100, Section 6's
construction merges them into a nine-route solution of no greater cost (in
fact at least 3 lower on this data), contradicting the fixed-nine optimum.
Every candidate that still needs consideration therefore satisfies

`load[r] + load[s] >= 101` for every distinct pair of routes.

This condition yields several exact, redundant strengthenings.  If `L` is the
smallest of ten integer route loads, then the other nine loads are at least
`101-L`, so

`848 >= L + 9*(101-L)`, and hence `L >= ceil(61/8) = 8`.

The two largest distinct customer demands are 54 and 26.  Thus two singleton
routes would have combined load at most 80 and violate pairwise nonmergeability;
there can be at most one singleton.

The executed Gurobi model contains 1,999 binary variables: the 1,953 customer
edges from Section 4 and 46 singleton indicators, one for every customer whose
demand is at least 8.  For such a customer `i`, the two links

`degree(i) <= 2*(1-singleton[i])`

and

`degree(i) >= 1-singleton[i]`

make the indicator equal to one exactly when its integral customer degree is
zero.  The 17 customers of demand below 8 instead receive `degree(i)>=1`, and
the model imposes `sum_i singleton[i] <= 1`.  `BranchPriority` values only
control search order; there is no symmetry fixing or manual branch restriction.

The model also pre-adds all 110 customer subsets `S` with `demand(S)<8`:

`x(I(S)) >= |S|`,

where `I(S)` is the set of customer edges having at least one endpoint in `S`.
No complete route can lie in such an `S`.  On any route path that intersects
`S` in `t` vertices but is not wholly contained in `S`, at least `t` selected
customer edges are incident to those vertices.  Summing by route proves the
inequality.  Positive demands show that every set with demand below 8 has at
most four customers, so the enumerated family is complete (17 singletons, 63
pairs, 29 triples, and one quadruple).

Finally, the integer callback adds a nonmerge inequality for unions `U` of
candidate components whose combined demand is at most 100:

`x(I(U)) >= |U|-1`.

This inequality is valid for every pairwise-nonmergeable route collection.
At most one complete route can be wholly contained in such a `U`; it contributes
`|R|-1` incident customer edges.  Every route only partly intersecting `U`
contributes at least as many incident customer edges as its number of vertices
in `U`.  Their sum is therefore at least `|U|-1`.

The callback is complete at integer points when combined with the ordinary
rounded-capacity component cuts.  Those cuts eliminate every customer cycle
and every over-capacity path.  If all components are valid route paths but two
are mergeable, their union has exactly `|U|-2` incident customer edges and
violates the displayed nonmerge inequality.  Thus any surviving integer point
is exactly a capacity-feasible, fixed-10, pairwise-nonmergeable CVRP solution.

The archived run fixed `K=10`, imposed objective at most 1400, and enabled this
nonmerge family.  Gurobi 13.0.1 returned terminal `INFEASIBLE` after 380.254
seconds and 333,634 nodes, with no incumbent.  The model had 339 initial rows
and 1,999 binaries; it proposed 345 ordinary lazy cuts, 1,630 nonmerge lazy
cuts, and 202 fractional user cuts.  The summary's executed-script SHA-256
`ab77e1e0b5f878b886975427346dcf8abef944dd06d71a34b0df1d9dd3966378`
matches the archived bytes.  The complete artifacts are:

- [`../logs/route-count/gurobi-k10-nonmerge/gurobi-customer-edge-cutoff-summary.json`](../logs/route-count/gurobi-k10-nonmerge/gurobi-customer-edge-cutoff-summary.json);
- [`../logs/route-count/gurobi-k10-nonmerge/gurobi-customer-edge-cutoff.log`](../logs/route-count/gurobi-k10-nonmerge/gurobi-customer-edge-cutoff.log);
- [`../logs/route-count/gurobi-k10-nonmerge/stdout.log`](../logs/route-count/gurobi-k10-nonmerge/stdout.log); and
- [`../logs/executed-scripts/gurobi_customer_edge_nonmerge_k10.py`](../logs/executed-scripts/gurobi_customer_edge_nonmerge_k10.py).

The data-dependent premises are independently enumerated in
[`k10-nonmerge-premises.json`](k10-nonmerge-premises.json).  One wording caveat
matters: the summary's generated `proof_statement` sounds unconditional when
read alone.  Because `forbid_mergeable_route_pairs=true`, the solver run by
itself proves infeasibility of the nonmerge submodel.  CVRPLIB's fixed-nine
result and the verified merge lemma are what make that submodel exhaustive for
an improving 10-route solution.  With those premises, fixed 10 is excluded and
the fixed-11 implication in Section 6 is activated.

## 9. Complete route-count conclusion

Suppose an MPS solution of objective at most 1400 existed.  The coefficient
audit would project it to a CVRP solution of cost at most 1400 and route count
`K` between 9 and 63.

- `K=9` conflicts with the external CVRPLIB `Opt=yes, 1401` result, if that
  authoritative status is accepted.
- `K=10` conflicts with the terminal nonmerge run, because the fixed-nine
  result and merge lemma make every improving candidate nonmergeable.
- `K=11` conflicts with the terminal COPT nonmerge run, whose fixed-10
  prerequisite is now satisfied.
- `K=12,...,16` conflict with the terminal exact-model solver runs.
- `K>=17` conflicts with the exact rational lower bound 1471.5.

All `K=9,...,63` are therefore excluded at cost at most 1400.  Since projected
route costs are integral, this also excludes an MPS objective strictly below
1401.  The full checked MPS solution supplies the matching upper bound, so the
mixed evidence establishes

> **OPT = 1401.**

This is not a wholly portable formal proof.  Replacing CVRPLIB's database flag
and the Gurobi/COPT terminal statuses with independently replayable proof
objects would be required for that stronger claim.  In particular, the route
lift's `best_bound=1401` is the bound of a subproblem whose objective and route
variables were already fixed; it plays no role in this global lower bound.
