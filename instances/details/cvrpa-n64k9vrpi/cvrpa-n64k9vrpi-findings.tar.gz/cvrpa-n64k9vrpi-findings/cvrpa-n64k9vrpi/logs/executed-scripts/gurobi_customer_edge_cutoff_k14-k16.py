#!/usr/bin/env python3
"""Proof-oriented cutoff model for a metric CVRP under 2,000 variables.

Only customer-customer undirected edges are explicit.  For customer ``i``,
the two-regular CVRP degree equation defines the omitted depot multiplicity as
``d_i = 2 - degree_customer(i)``.  This leaves ``N*(N-1)/2`` binaries (1,953
for A-n64-k9), fitting the restricted Gurobi license.  Rounded-capacity cuts
become ``x(E(S)) <= |S| - ceil(demand(S)/capacity)``.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import time
from collections import deque
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


DEPOT = 0


def parse_dzn(path: Path) -> tuple[int, int, list[int], list[list[int]]]:
    text = path.read_text(encoding="utf-8")
    n = int(re.search(r"\bN\s*=\s*(\d+)\s*;", text).group(1))
    capacity = int(re.search(r"\bCapacity\s*=\s*(\d+)\s*;", text).group(1))
    demand_text = re.search(r"Demand\s*=\s*\[(.*?)\]\s*;", text, re.S).group(1)
    demands = [0] + [int(value) for value in re.findall(r"-?\d+", demand_text)]
    distance_text = re.search(r"Distance\s*=\s*\[\|(.*?)\|\]\s*;", text, re.S).group(1)
    distance = []
    for raw_row in distance_text.split("|"):
        row = [int(value) for value in re.findall(r"-?\d+", raw_row)]
        if row:
            distance.append(row)
    if (
        len(demands) != n + 1
        or len(distance) != n + 1
        or any(len(row) != n + 1 for row in distance)
    ):
        raise ValueError("unexpected DZN dimensions")
    if any(distance[i][j] != distance[j][i] for i in range(n + 1) for j in range(n + 1)):
        raise ValueError("distance matrix is not symmetric")
    return n, capacity, demands, distance


def parse_routes(path: Path) -> tuple[list[list[int]], int | None]:
    routes = []
    stated_cost = None
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.startswith("Route #"):
            routes.append([int(value) for value in line.split(":", 1)[1].split()])
        elif line.startswith("Cost "):
            stated_cost = int(line.split()[1])
    return routes, stated_cost


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class Dinic:
    def __init__(self, n: int):
        self.n = n
        self.graph = [[] for _ in range(n)]

    def add_directed(self, tail: int, head: int, capacity: float) -> None:
        forward = [head, capacity, None]
        reverse = [tail, 0.0, forward]
        forward[2] = reverse
        self.graph[tail].append(forward)
        self.graph[head].append(reverse)

    def add_undirected_capacity(self, left: int, right: int, capacity: float) -> None:
        self.add_directed(left, right, capacity)
        self.add_directed(right, left, capacity)

    def maxflow_cut(self, source: int, sink: int) -> tuple[float, set[int]]:
        total = 0.0
        epsilon = 1e-10
        while True:
            level = [-1] * self.n
            level[source] = 0
            queue = deque([source])
            while queue:
                node = queue.popleft()
                for edge in self.graph[node]:
                    if edge[1] > epsilon and level[edge[0]] < 0:
                        level[edge[0]] = level[node] + 1
                        queue.append(edge[0])
            if level[sink] < 0:
                break
            pointer = [0] * self.n

            def dfs(node: int, flow: float) -> float:
                if node == sink:
                    return flow
                while pointer[node] < len(self.graph[node]):
                    edge = self.graph[node][pointer[node]]
                    if edge[1] > epsilon and level[edge[0]] == level[node] + 1:
                        sent = dfs(edge[0], min(flow, edge[1]))
                        if sent > epsilon:
                            edge[1] -= sent
                            edge[2][1] += sent
                            return sent
                    pointer[node] += 1
                return 0.0

            while True:
                sent = dfs(source, float("inf"))
                if sent <= epsilon:
                    break
                total += sent
        reachable = {source}
        queue = deque([source])
        while queue:
            node = queue.popleft()
            for edge in self.graph[node]:
                if edge[1] > epsilon and edge[0] not in reachable:
                    reachable.add(edge[0])
                    queue.append(edge[0])
        return total, reachable


def customer_components(edge_values: dict[tuple[int, int], float], customers: list[int]) -> list[set[int]]:
    adjacency = {customer: [] for customer in customers}
    for (left, right), value in edge_values.items():
        if value > 0.5:
            adjacency[left].append(right)
            adjacency[right].append(left)
    unseen = set(customers)
    components = []
    while unseen:
        seed = min(unseen)
        unseen.remove(seed)
        component = {seed}
        stack = [seed]
        while stack:
            node = stack.pop()
            for neighbor in adjacency[node]:
                if neighbor in unseen:
                    unseen.remove(neighbor)
                    component.add(neighbor)
                    stack.append(neighbor)
        components.append(component)
    return components


def internal_edge_expr(model: gp.Model, subset: set[int]) -> gp.LinExpr:
    return gp.quicksum(
        variable
        for (left, right), variable in model._edge_vars.items()
        if left in subset and right in subset
    )


def callback(model: gp.Model, where: int) -> None:
    if where == GRB.Callback.MIPSOL:
        model._integer_solutions_checked += 1
        values = {
            edge: model.cbGetSolution(variable)
            for edge, variable in model._edge_vars.items()
        }
        violations = 0
        for subset in customer_components(values, model._customers):
            demand = sum(model._demands[customer] for customer in subset)
            rhs = len(subset) - math.ceil(demand / model._capacity)
            internal = sum(
                value
                for (left, right), value in values.items()
                if left in subset and right in subset
            )
            if internal > rhs + 1e-6:
                model.cbLazy(internal_edge_expr(model, subset) <= rhs)
                model._lazy_cuts += 1
                model._lazy_sets.add(tuple(sorted(subset)))
                model._minimum_lazy_rhs = min(model._minimum_lazy_rhs, rhs)
                violations += 1
        if violations:
            model._invalid_integer_solutions_cut += 1
        else:
            model._valid_integer_solutions_seen += 1

    elif where == GRB.Callback.MIPNODE:
        if model.cbGet(GRB.Callback.MIPNODE_STATUS) != GRB.OPTIMAL:
            return
        if model._node_separation_calls >= model._node_separation_limit:
            return
        model._node_separation_calls += 1
        values = {
            edge: max(0.0, model.cbGetNodeRel(variable))
            for edge, variable in model._edge_vars.items()
        }
        depot_values = {}
        for customer in model._customers:
            degree = sum(
                value
                for (left, right), value in values.items()
                if left == customer or right == customer
            )
            depot_values[customer] = max(0.0, 2.0 - degree)

        candidates = {}
        all_nodes = set(range(model._customer_count + 1))
        for sink in model._customers:
            flow = Dinic(model._customer_count + 1)
            for (left, right), value in values.items():
                if value > 1e-9:
                    flow.add_undirected_capacity(left, right, value)
            for customer, value in depot_values.items():
                if value > 1e-9:
                    flow.add_undirected_capacity(DEPOT, customer, value)
            _, depot_side = flow.maxflow_cut(DEPOT, sink)
            subset = frozenset(all_nodes - depot_side)
            if not subset or DEPOT in subset:
                continue
            demand = sum(model._demands[customer] for customer in subset)
            rhs = len(subset) - math.ceil(demand / model._capacity)
            internal = sum(
                value
                for (left, right), value in values.items()
                if left in subset and right in subset
            )
            if internal > rhs + 1e-6:
                candidates[subset] = (internal - rhs, rhs)
        for subset, (_, rhs) in sorted(candidates.items(), key=lambda item: -item[1][0])[:20]:
            key = tuple(sorted(subset))
            if key not in model._user_sets:
                model.cbCut(internal_edge_expr(model, set(subset)) <= rhs)
                model._user_sets.add(key)
                model._user_cuts += 1


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("dzn", type=Path)
    parser.add_argument("routes", type=Path)
    parser.add_argument("out", type=Path)
    parser.add_argument("--seconds", type=float, default=3600)
    parser.add_argument("--threads", type=int, default=32)
    parser.add_argument("--minimum-routes", type=int)
    parser.add_argument("--maximum-routes", type=int)
    parser.add_argument("--maximum-objective", type=int)
    parser.add_argument("--node-separation-limit", type=int, default=400)
    parser.add_argument(
        "--capacity-relaxation",
        action="store_true",
        help="omit all connectivity/capacity cuts and solve the cardinality-constrained degree relaxation",
    )
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    n, capacity, demands, distance = parse_dzn(args.dzn)
    routes, stated_cost = parse_routes(args.routes)
    customers = list(range(1, n + 1))
    model = gp.Model(f"customer-edge-CVRP-{n}")
    edge_vars = {
        (left, right): model.addVar(vtype=GRB.BINARY, name=f"e_{left}_{right}")
        for left in customers
        for right in range(left + 1, n + 1)
    }
    model.update()

    degree_expr = {}
    for customer in customers:
        degree_expr[customer] = gp.quicksum(
            variable
            for (left, right), variable in edge_vars.items()
            if left == customer or right == customer
        )
        model.addConstr(degree_expr[customer] <= 2, name=f"customer_degree_{customer}")

    demand_minimum_routes = math.ceil(sum(demands) / capacity)
    minimum_routes = args.minimum_routes or demand_minimum_routes
    if minimum_routes < demand_minimum_routes:
        raise ValueError("minimum route count weakens the demand lower bound")
    maximum_routes = args.maximum_routes or n
    if maximum_routes < minimum_routes or maximum_routes > n:
        raise ValueError("invalid route-count interval")
    edge_count = gp.quicksum(edge_vars.values())
    model.addConstr(edge_count <= n - minimum_routes, name="minimum_route_count")
    if maximum_routes < n:
        model.addConstr(edge_count >= n - maximum_routes, name="maximum_route_count")

    objective_constant = 2 * sum(distance[DEPOT][customer] for customer in customers)
    objective = gp.LinExpr(objective_constant)
    for (left, right), variable in edge_vars.items():
        objective += (
            distance[left][right] - distance[DEPOT][left] - distance[DEPOT][right]
        ) * variable
    model.setObjective(objective, GRB.MINIMIZE)
    if args.maximum_objective is not None:
        model.addConstr(objective <= args.maximum_objective, name="objective_ceiling")

    if minimum_routes <= len(routes) <= maximum_routes and (
        args.maximum_objective is None or stated_cost is None or stated_cost <= args.maximum_objective
    ):
        route_edges = set()
        for route in routes:
            for left, right in zip(route, route[1:]):
                route_edges.add(tuple(sorted((left, right))))
        for edge, variable in edge_vars.items():
            variable.Start = 1 if edge in route_edges else 0

    model._edge_vars = edge_vars
    model._customers = customers
    model._customer_count = n
    model._demands = demands
    model._capacity = capacity
    model._lazy_cuts = 0
    model._user_cuts = 0
    model._lazy_sets = set()
    model._user_sets = set()
    model._node_separation_calls = 0
    model._node_separation_limit = args.node_separation_limit
    model._integer_solutions_checked = 0
    model._invalid_integer_solutions_cut = 0
    model._valid_integer_solutions_seen = 0
    model._minimum_lazy_rhs = n

    model.Params.Threads = args.threads
    model.Params.TimeLimit = args.seconds
    model.Params.MIPGap = 0
    model.Params.LazyConstraints = 0 if args.capacity_relaxation else 1
    model.Params.PreCrush = 0 if args.capacity_relaxation else 1
    model.Params.MIPFocus = 3
    model.Params.LogFile = str(args.out / "gurobi-customer-edge-cutoff.log")
    started = time.time()
    model.optimize(None if args.capacity_relaxation else callback)
    elapsed = time.time() - started

    result = {
        "gurobi_version": list(gp.gurobi.version()),
        "status": int(model.Status),
        "status_name": {
            GRB.OPTIMAL: "OPTIMAL",
            GRB.TIME_LIMIT: "TIME_LIMIT",
            GRB.INFEASIBLE: "INFEASIBLE",
            GRB.CUTOFF: "CUTOFF",
        }.get(model.Status, str(model.Status)),
        "formulation": (
            "cardinality-constrained degree relaxation with implicit depot multiplicities"
            if args.capacity_relaxation
            else "customer-customer undirected edges with implicit depot multiplicities"
        ),
        "capacity_relaxation": args.capacity_relaxation,
        "implicit_depot_formula": "d_i = 2 - degree_customer(i)",
        "capacity_cut_formula": "x(E(S)) <= |S| - ceil(demand(S)/capacity)",
        "variables": model.NumVars,
        "initial_constraints": model.NumConstrs,
        "customers": n,
        "total_demand": sum(demands),
        "capacity": capacity,
        "minimum_routes_by_total_demand": demand_minimum_routes,
        "minimum_routes_enforced": minimum_routes,
        "maximum_routes_enforced": maximum_routes,
        "maximum_objective_enforced": args.maximum_objective,
        "objective_constant_before_edge_adjustments": objective_constant,
        "lazy_cuts_added": model._lazy_cuts,
        "distinct_lazy_sets": len(model._lazy_sets),
        "fractional_user_cuts_added": model._user_cuts,
        "node_separation_calls": model._node_separation_calls,
        "integer_solutions_checked_by_callback": model._integer_solutions_checked,
        "invalid_integer_solutions_cut": model._invalid_integer_solutions_cut,
        "valid_integer_solutions_seen": model._valid_integer_solutions_seen,
        "nodes_explored": float(model.NodeCount),
        "runtime_reported": float(model.Runtime),
        "runtime_wall": elapsed,
        "dzn_sha256": sha256(args.dzn),
        "known_routes_sha256": sha256(args.routes),
        "script_sha256": sha256(Path(__file__).resolve()),
        "cpu_only": True,
    }
    try:
        if math.isfinite(float(model.ObjBound)):
            result["best_bound"] = float(model.ObjBound)
        if math.isfinite(float(model.MIPGap)):
            result["gap"] = float(model.MIPGap)
    except Exception:
        pass
    if model.SolCount:
        result["objective"] = float(model.ObjVal)
        values = {edge: variable.X for edge, variable in edge_vars.items()}
        components = customer_components(values, customers)
        result["integer_components"] = [
            {
                "customers": sorted(component),
                "demand": sum(demands[customer] for customer in component),
            }
            for component in components
        ]
        model.write(str(args.out / "customer-edge-cvrp.sol"))
    if model.Status == GRB.INFEASIBLE and args.maximum_objective is not None:
        result["proof_statement"] = (
            f"No capacity-feasible CVRP solution with {minimum_routes} through "
            f"{maximum_routes} routes "
            f"and objective at most {args.maximum_objective} exists."
        )
    (args.out / "gurobi-customer-edge-cutoff-summary.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print("RESULT_JSON=" + json.dumps(result, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
