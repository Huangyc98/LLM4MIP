# Package manifest: graph40-80-1rand

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 3
Excluded source files: 1

## Included files

- `README.md`
- `solutions/official-best.sol.gz`
- `solutions/official-best.validation.json`

## Excluded files

- `input/graph40-80-1rand.mps.gz (24417989 bytes; raw benchmark input; sha256 4a1243b6d5b81367c9d6ae6512be8dc79974a1115e2aa40d5e5393928a67ee33)`
