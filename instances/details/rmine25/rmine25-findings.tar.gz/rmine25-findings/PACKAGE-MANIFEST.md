# Package manifest: rmine25

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 11
Excluded source files: 0

## Included files

- `README.md`
- `artifacts/rmine25-best-rounded-exact-audit.json`
- `artifacts/rmine25-best-tolerance-exact-audit.json`
- `artifacts/rmine25-lp-cert-verification.json`
- `artifacts/rmine25-lp-cert.json.gz`
- `artifacts/rmine25-lp-lambda.json`
- `input/README.md`
- `input/SHA256SUMS`
- `scripts/exact_decimal_audit.py`
- `scripts/exact_lagrangian_certificate.py`
- `solutions/rmine25-best-rounded.sol`

## Excluded files

- None
