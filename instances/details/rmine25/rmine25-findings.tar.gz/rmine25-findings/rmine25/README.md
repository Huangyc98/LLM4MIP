# rmine25 — strict rounded incumbent and exact Lagrangian lower bound

Official MIPLIB page: <https://miplib.zib.de/instance_details_rmine25.html>

Official MPS: [download `rmine25.mps.gz`](https://miplib.zib.de/WebData/instances/rmine25.mps.gz)

## Status and bounds

`rmine25` is a minimization problem.  Its global optimum remains **open**: no
experiment reported here proves that the primal and lower bounds meet.

| evidence | value | claim supported |
|---|---:|---|
| strict feasible upper bound | `-15541.66927699999998289011` | exact original-MPS feasibility of the rounded solution |
| COPT 10-hour-table numeric lower bound | `-15667.8428` | strongest available floating-point global bound |
| portable exact global lower bound | `-15667.918862520611901` | independently replayable rational Lagrangian/closure certificate |

For a minimization problem, `LB <= OPT <= UB`; because the values are negative,
a larger lower bound and a smaller upper bound are stronger.  The COPT numeric
gap is `126.17352300000001710989` (about `0.811840%`).  Using only portable
exact evidence gives the certified interval

```text
-15667.918862520611901 <= OPT <= -15541.66927699999998289011
```

of width `126.24958552061191810989` (about `0.812330%`).  The COPT number is
tighter numerically, but it is deliberately not promoted to a portable exact
bound: the archived solver result has no independently checkable proof trace.
The row in the nominal 10-hour comparison table records 24,484.9 seconds and
zero processed nodes, rather than a complete 36,000-second run.

## Recovered structure

The original MPS has 326,599 binary variables, 2,953,849 rows, and 7,182,744
nonzeros.  It represents 15,625 mine blocks over 25 periods with cumulative
variables: `x_Bb_t = 1` means that block `b` has been extracted by the end of
period `t`.

The rows consist of 2,642,825 spatial precedence implications, 310,974
temporal monotonicity implications, and only 50 side constraints: two resource
capacities in each period.  Removing those 50 capacity rows leaves a binary
precedence-closure problem.  This is the structure used by the exact lower-bound
certificate rather than by a long generic branch-and-bound run.

The original MPS is not duplicated in this package.  Download it from the
[official MIPLIB link](https://miplib.zib.de/WebData/instances/rmine25.mps.gz)
and save it as `input/rmine25.mps.gz`.  Its expected SHA-256 is
`71c035cacfa43273061f3f850cd7e0eb0e121695bb6e22358c2ea953e5341072`.
The same value is recorded in [`input/SHA256SUMS`](input/SHA256SUMS).

## Strict rounded upper bound

The best public MIPLIB vector is a tolerance solution, not a mathematical 0/1
vector.  Direct 60-digit `Decimal` replay gives objective
`-15541.66928749972639211497512999621788920637`, but finds 18 nonintegral
entries, with maximum integrality error
`0.0000086409698211079362`.  It also has 21 exact row violations, each tiny;
the maximum is `5.0000000000008E-9`.  Therefore this tolerance vector cannot by
itself support a strict upper bound.

Every listed value was rounded to its nearest binary value and unlisted
variables were set to zero.  Rounding alone is not a feasibility proof.  The
result was subsequently substituted into all 2,953,849 rows of the original
MPS using 60-digit `Decimal` arithmetic.  The independent audit found:

| check | exact result |
|---|---:|
| row violations | `0` |
| bound violations | `0` |
| integrality violations | `0` |
| recomputed objective | `-15541.66927699999998289011` |

The rounding cost relative to the tolerance vector is only
`0.00001049972640922486512999621789`.  The rounded point also improves the
previous exactly audited public incumbent by
`5.114768000000006832`.

The strict solution is
[`solutions/rmine25-best-rounded.sol`](solutions/rmine25-best-rounded.sol),
with SHA-256
`90eb24e1dc81c6885c9d6d45a47c838a39172b0e51693d21271a5a19b09b492f`.
The two relevant audits are
[`artifacts/rmine25-best-tolerance-exact-audit.json`](artifacts/rmine25-best-tolerance-exact-audit.json)
and
[`artifacts/rmine25-best-rounded-exact-audit.json`](artifacts/rmine25-best-rounded-exact-audit.json).

## Portable exact lower bound

The 50 capacity rows were relaxed with nonnegative rational multipliers.  For
that fixed multiplier vector, the remaining binary problem is a minimum-weight
closure problem.  All finite MPS decimals and multipliers were converted to
exact fractions and then to one common integer scale.  The certificate stores
both a feasible integral maximum flow and a cut of exactly the same capacity,
thereby proving the closure-oracle value.  Combining that value with the exact
Lagrangian constant yields the global lower bound
`-15667.918862520611901`.

This claim does not depend on COPT or Gurobi tolerances.  The verifier checks the
MPS hash, multiplier signs, reconstructed network capacities, flow capacity and
conservation, flow/cut equality, and the final rational bound.  The archived
verification result has `verified: true`; the same certificate was replayed on
both `euler4` and Windows.

Evidence files:

- [`artifacts/rmine25-lp-lambda.json`](artifacts/rmine25-lp-lambda.json): the
  rationalized capacity multipliers;
- [`artifacts/rmine25-lp-cert.json.gz`](artifacts/rmine25-lp-cert.json.gz): the
  complete flow/cut witness and exact bound;
- [`artifacts/rmine25-lp-cert-verification.json`](artifacts/rmine25-lp-cert-verification.json):
  the compact replay result;
- [`scripts/exact_lagrangian_certificate.py`](scripts/exact_lagrangian_certificate.py):
  the solver-free generator and verifier.

To replay the existing certificate:

```sh
python scripts/exact_lagrangian_certificate.py verify \
  input/rmine25.mps.gz \
  artifacts/rmine25-lp-cert.json.gz
```

The strict rounded solution proves only the upper bound, and the exact
Lagrangian certificate proves only the lower bound.  Their remaining separation
is why no global-optimality claim is made.
