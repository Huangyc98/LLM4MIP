#!/usr/bin/env python3
"""Independent exact-rational checker for an ns2122698 row-dual candidate."""

from __future__ import annotations

import argparse
import gzip
import json
from collections import OrderedDict, defaultdict
from decimal import Decimal, localcontext
from fractions import Fraction
from pathlib import Path


def q(text: str) -> Fraction:
    return Fraction(text.replace("D", "E").replace("d", "e"))


def parse_mps(path: Path):
    rows = OrderedDict()
    variables = OrderedDict()
    rhs = defaultdict(Fraction)
    section = ""
    integer_mode = False
    with gzip.open(path, "rt", encoding="latin-1") as stream:
        for raw in stream:
            tokens = raw.split()
            if not tokens or tokens[0].startswith("*"):
                continue
            if not raw[0].isspace() and tokens[0] in {
                "NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"
            }:
                section = tokens[0]
                continue
            if section == "ROWS":
                rows[tokens[1]] = tokens[0]
            elif section == "COLUMNS":
                if "'MARKER'" in tokens:
                    integer_mode = "'INTORG'" in tokens
                    continue
                info = variables.setdefault(tokens[0], {
                    "integer": integer_mode,
                    "objective": Fraction(0),
                    "terms": [],
                    "lb": Fraction(0),
                    # In MPS, an integer-marker column without an explicit
                    # bound has the default binary domain [0, 1].
                    "ub": Fraction(1) if integer_mode else None,
                })
                info["integer"] = info["integer"] or integer_mode
                for row, value in zip(tokens[1::2], tokens[2::2]):
                    coefficient = q(value)
                    if rows[row] == "N":
                        info["objective"] += coefficient
                    else:
                        info["terms"].append((row, coefficient))
            elif section == "RHS":
                for row, value in zip(tokens[1::2], tokens[2::2]):
                    if rows[row] != "N":
                        rhs[row] += q(value)
            elif section == "RANGES":
                raise ValueError("RANGES are unsupported")
            elif section == "BOUNDS":
                kind, variable = tokens[0], tokens[2]
                value = q(tokens[3]) if len(tokens) > 3 else Fraction(0)
                info = variables[variable]
                if kind == "UP":
                    info["ub"] = value
                elif kind == "LO":
                    info["lb"] = value
                elif kind == "FX":
                    info["lb"] = info["ub"] = value
                elif kind == "FR":
                    info["lb"], info["ub"] = None, None
                elif kind == "MI":
                    info["lb"] = None
                elif kind == "PL":
                    info["ub"] = None
                elif kind == "BV":
                    info["lb"], info["ub"], info["integer"] = Fraction(0), Fraction(1), True
                elif kind == "LI":
                    info["lb"], info["integer"] = value, True
                elif kind == "UI":
                    info["ub"], info["integer"] = value, True
                else:
                    raise ValueError(f"unsupported bound kind {kind}")
    return rows, variables, rhs


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("duals", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--limit-denominator", type=int)
    parser.add_argument(
        "--grid-denominator",
        type=int,
        help="round every multiplier to the nearest multiple of 1/D",
    )
    parser.add_argument("--write-normalized-duals", type=Path)
    args = parser.parse_args()

    rows, variables, rhs = parse_mps(args.model)
    multipliers = defaultdict(Fraction)
    for line in args.duals.read_text(encoding="ascii").splitlines():
        pieces = line.split()
        if len(pieces) == 2 and not pieces[0].startswith("#"):
            value = q(pieces[1])
            if args.limit_denominator:
                value = value.limit_denominator(args.limit_denominator)
            if args.grid_denominator:
                value = Fraction(round(value * args.grid_denominator), args.grid_denominator)
            multipliers[pieces[0]] += value

    if args.write_normalized_duals:
        args.write_normalized_duals.parent.mkdir(parents=True, exist_ok=True)
        with args.write_normalized_duals.open("w", encoding="ascii") as stream:
            stream.write("# Exact rational row multipliers; values are numerator/denominator.\n")
            for row in rows:
                value = multipliers[row]
                if value:
                    stream.write(f"{row} {value}\n")

    unknown = sorted(set(multipliers) - set(rows))
    sign_violations = []
    for row, value in multipliers.items():
        sense = rows.get(row)
        if (sense == "L" and value > 0) or (sense == "G" and value < 0):
            sign_violations.append([row, sense, str(value)])

    reduced_cost_violations = []
    bound_contribution = Fraction(0)
    minimum_unbounded_reduced_cost = None
    reduced_cost_abs_sum = Fraction(0)
    for variable, info in variables.items():
        reduced = info["objective"] - sum(
            coefficient * multipliers[row] for row, coefficient in info["terms"]
        )
        reduced_cost_abs_sum += abs(reduced)
        if reduced >= 0:
            if info["lb"] is None:
                reduced_cost_violations.append([variable, "no lower bound", str(reduced)])
            else:
                bound_contribution += reduced * info["lb"]
        else:
            if info["ub"] is None:
                reduced_cost_violations.append([variable, "no upper bound", str(reduced)])
                if minimum_unbounded_reduced_cost is None or reduced < minimum_unbounded_reduced_cost:
                    minimum_unbounded_reduced_cost = reduced
            else:
                bound_contribution += reduced * info["ub"]

    row_contribution = sum(rhs[row] * value for row, value in multipliers.items())
    bound = row_contribution + bound_contribution
    valid = not unknown and not sign_violations and not reduced_cost_violations
    with localcontext() as context:
        context.prec = 50
        bound_decimal = Decimal(bound.numerator) / Decimal(bound.denominator)
    report = {
        "schema": "ns2122698-exact-lp-dual-check-v1",
        "valid": valid,
        "model": str(args.model),
        "duals": str(args.duals),
        "limit_denominator": args.limit_denominator,
        "grid_denominator": args.grid_denominator,
        "normalized_duals": str(args.write_normalized_duals) if args.write_normalized_duals else None,
        "rows": len(rows) - sum(sense == "N" for sense in rows.values()),
        "variables": len(variables),
        "nonzero_multipliers": sum(value != 0 for value in multipliers.values()),
        "unknown_multiplier_rows": unknown[:20],
        "sign_violation_count": len(sign_violations),
        "sign_violation_sample": sign_violations[:20],
        "unbounded_reduced_cost_violation_count": len(reduced_cost_violations),
        "unbounded_reduced_cost_violation_sample": reduced_cost_violations[:20],
        "minimum_unbounded_reduced_cost": str(minimum_unbounded_reduced_cost) if minimum_unbounded_reduced_cost is not None else None,
        "row_contribution": str(row_contribution),
        "bound_contribution": str(bound_contribution),
        "exact_bound_fraction": str(bound) if valid else None,
        # Avoid a binary-float round trip in the human-readable rendering; the
        # exact Fraction immediately above remains the authoritative value.
        "exact_bound_decimal_50": format(bound_decimal, "f") if valid else None,
        "evidence": "Exact Fraction reconstruction from the original compressed MPS.",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
