#!/usr/bin/env python3
"""Build the exact C-prefix integer-choice interaction graph from ns2122698."""

from __future__ import annotations

import argparse
import gzip
import itertools
import json
import re
from collections import Counter, defaultdict
from pathlib import Path


CHOICE = re.compile(r"^C(\d{2})R\d+D\d{4}$")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cluster-size", type=int, default=8)
    args = parser.parse_args()

    row_groups: dict[str, set[int]] = defaultdict(set)
    section = ""
    integer_mode = False
    with gzip.open(args.model, "rt", encoding="latin-1") as stream:
        for raw in stream:
            tokens = raw.split()
            if not tokens or tokens[0].startswith("*"):
                continue
            if not raw[0].isspace() and tokens[0] in {
                "NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"
            }:
                section = tokens[0]
                continue
            if section != "COLUMNS":
                continue
            if "'MARKER'" in tokens:
                integer_mode = "'INTORG'" in tokens
                continue
            match = CHOICE.fullmatch(tokens[0])
            if not integer_mode or not match:
                continue
            group = int(match.group(1))
            for row in tokens[1::2]:
                row_groups[row].add(group)

    edge_weights = Counter()
    group_row_counts = Counter()
    cardinality = Counter()
    for groups in row_groups.values():
        cardinality[len(groups)] += 1
        for group in groups:
            group_row_counts[group] += 1
        for left, right in itertools.combinations(sorted(groups), 2):
            edge_weights[(left, right)] += 1

    groups = sorted(group_row_counts)
    remaining = set(groups)
    clusters: list[list[int]] = []
    # Deterministic weighted greedy partition.  It is only a neighborhood
    # generator, not a claim that these are the official decomposition blocks.
    while remaining:
        seed = max(
            remaining,
            key=lambda group: (
                sum(weight for edge, weight in edge_weights.items() if group in edge),
                -group,
            ),
        )
        cluster = [seed]
        remaining.remove(seed)
        while remaining and len(cluster) < args.cluster_size:
            candidate = max(
                remaining,
                key=lambda group: (
                    sum(edge_weights[tuple(sorted((group, member)))] for member in cluster),
                    group_row_counts[group],
                    -group,
                ),
            )
            cluster.append(candidate)
            remaining.remove(candidate)
        clusters.append(sorted(cluster))

    weighted_degrees = {
        group: sum(weight for edge, weight in edge_weights.items() if group in edge)
        for group in groups
    }
    report = {
        "schema": "ns2122698-integer-group-graph-v1",
        "group_count": len(groups),
        "row_count_touching_integer_choices": len(row_groups),
        "groups_per_row_histogram": [[key, value] for key, value in sorted(cardinality.items())],
        "edge_count": len(edge_weights),
        "weighted_degrees": [[group, weighted_degrees[group]] for group in groups],
        "group_row_counts": [[group, group_row_counts[group]] for group in groups],
        "top_edges": [
            [left, right, weight]
            for (left, right), weight in sorted(
                edge_weights.items(), key=lambda item: (-item[1], item[0])
            )[:300]
        ],
        "greedy_weighted_neighborhoods": clusters,
        "neighborhood_note": (
            "Deterministic weighted graph partition for incumbent-centred LNS; "
            "not the official MIPLIB decomposition."
        ),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: report[key] for key in (
        "group_count", "row_count_touching_integer_choices", "groups_per_row_histogram",
        "edge_count", "greedy_weighted_neighborhoods"
    )}, indent=2))


if __name__ == "__main__":
    main()
