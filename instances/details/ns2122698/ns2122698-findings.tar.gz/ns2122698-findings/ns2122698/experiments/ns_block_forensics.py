#!/usr/bin/env python3
"""Recover the named linking/recourse structure of ns2122698.

Unlike the anonymous nj instances, ns2122698 retains structured names.  This
script treats names as hypotheses, then checks every proposed block against the
actual nonzero matrix.  It distinguishes 64 C-prefix choice groups from the
much finer connected-component decomposition recorded by MIPLIB's .dec file;
the separate 30-block count comes from MIPLIB's presolved decomposition.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import re
from collections import Counter, OrderedDict, defaultdict
from decimal import Decimal, getcontext
from pathlib import Path


getcontext().prec = 80
INTEGER_CHOICE = re.compile(r"^C(\d{2})R(\d+)D(\d{2})(\d{2})$")
LEADING_C = re.compile(r"^C(\d{2})")
LEADING_L = re.compile(r"^L(\d+)")
DAY_SLOT = re.compile(r"D([1-7])([1-4])(?:B)?$")


def number(text: str) -> Decimal:
    return Decimal(text.replace("D", "E").replace("d", "e"))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def normalized_pattern(name: str) -> str:
    return re.sub(r"\d+", "#", name)


def parse_mps(path: Path) -> dict:
    rows: OrderedDict[str, dict] = OrderedDict()
    variables: OrderedDict[str, dict] = OrderedDict()
    rhs: dict[str, Decimal] = defaultdict(Decimal)
    section = ""
    integer_mode = False
    with gzip.open(path, "rt", encoding="latin-1") as handle:
        for raw in handle:
            tokens = raw.split()
            if not tokens or tokens[0].startswith("*"):
                continue
            if not raw[0].isspace() and tokens[0] in {
                "NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"
            }:
                section = tokens[0]
                continue
            if section == "ROWS":
                rows[tokens[1]] = {"sense": tokens[0], "terms": []}
            elif section == "COLUMNS":
                if "'MARKER'" in tokens:
                    integer_mode = "'INTORG'" in tokens
                    continue
                variable = tokens[0]
                info = variables.setdefault(variable, {
                    "integer": integer_mode,
                    "lower": Decimal(0), "upper": None, "rows": [],
                })
                info["integer"] = info["integer"] or integer_mode
                for row, text in zip(tokens[1::2], tokens[2::2]):
                    value = number(text)
                    rows[row]["terms"].append((variable, value))
                    info["rows"].append((row, value))
            elif section == "RHS":
                for row, text in zip(tokens[1::2], tokens[2::2]):
                    rhs[row] += number(text)
            elif section == "BOUNDS":
                kind, variable = tokens[0], tokens[2]
                value = number(tokens[3]) if len(tokens) > 3 else Decimal(0)
                info = variables[variable]
                if kind == "UP":
                    info["upper"] = value
                elif kind == "LO":
                    info["lower"] = value
                elif kind == "FX":
                    info["lower"] = info["upper"] = value
                elif kind == "FR":
                    info["lower"], info["upper"] = Decimal("-Infinity"), None
                elif kind == "MI":
                    info["lower"] = Decimal("-Infinity")
                elif kind == "PL":
                    info["upper"] = None
                elif kind == "BV":
                    info["lower"], info["upper"], info["integer"] = Decimal(0), Decimal(1), True
                elif kind == "LI":
                    info["lower"], info["integer"] = value, True
                elif kind == "UI":
                    info["upper"], info["integer"] = value, True
                else:
                    raise ValueError(f"unsupported bound kind {kind}")
    return {"rows": rows, "variables": variables, "rhs": rhs}


def parse_dec(path: Path) -> dict:
    block_of_row: dict[str, int] = {}
    master: list[str] = []
    state = ""
    block = None
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        token = line.strip()
        if token.startswith("BLOCK "):
            block = int(token.split()[1])
            state = "block"
        elif token == "MASTERCONSS":
            state = "master"
            block = None
        elif token and not token.startswith("\\") and state == "block":
            block_of_row[token] = int(block)
        elif token and not token.startswith("\\") and state == "master":
            master.append(token)
    return {"block_of_row": block_of_row, "master_rows": master}


def row_record(row: str, model: dict) -> dict:
    info = model["rows"][row]
    return {
        "row": row,
        "sense": info["sense"],
        "rhs": str(model["rhs"].get(row, Decimal(0))),
        "nonzeros": len(info["terms"]),
        "integer_terms": sum(model["variables"][var]["integer"] for var, _ in info["terms"]),
        "terms": [(var, str(value)) for var, value in info["terms"][:20]],
        "terms_truncated": len(info["terms"]) > 20,
    }


def decomposition_audit(model: dict, dec: dict, source: Path) -> dict:
    rows = model["rows"]
    variables = model["variables"]
    block_ids = sorted(set(dec["block_of_row"].values()))
    listed_rows = set(dec["block_of_row"]) | set(dec["master_rows"])
    unknown_rows = sorted(listed_rows - set(rows))
    objective_rows = {row for row, info in rows.items() if info["sense"] == "N"}
    omitted_rows = sorted(set(rows) - objective_rows - listed_rows)

    touched_blocks_by_variable: dict[str, set[int]] = defaultdict(set)
    for variable, info in variables.items():
        for row, _ in info["rows"]:
            if row in dec["block_of_row"]:
                touched_blocks_by_variable[variable].add(dec["block_of_row"][row])
    exclusive_variables: dict[int, list[str]] = defaultdict(list)
    cross_block_variables = []
    retained_master_only_variables = []
    no_retained_row_variables = []
    master_set = set(dec["master_rows"])
    for variable, info in variables.items():
        blocks = touched_blocks_by_variable[variable]
        touches_master = any(row in master_set for row, _ in info["rows"])
        if len(blocks) == 1:
            exclusive_variables[next(iter(blocks))].append(variable)
        elif len(blocks) > 1:
            cross_block_variables.append(variable)
        elif touches_master:
            retained_master_only_variables.append(variable)
        else:
            no_retained_row_variables.append(variable)

    by_block_rows: dict[int, list[str]] = defaultdict(list)
    for row, block in dec["block_of_row"].items():
        by_block_rows[block].append(row)
    blocks = []
    for block in block_ids:
        block_rows = by_block_rows[block]
        block_vars = exclusive_variables[block]
        l_indices = sorted({int(match.group(1)) for row in block_rows if (match := LEADING_L.match(row))})
        day_slots = sorted({
            f"{match.group(1)}{match.group(2)}"
            for row in block_rows if (match := DAY_SLOT.search(row))
        })
        blocks.append({
            "block": block,
            "rows": len(block_rows),
            "exclusive_variables": len(block_vars),
            "exclusive_integer_variables": sum(variables[var]["integer"] for var in block_vars),
            "exclusive_continuous_variables": sum(not variables[var]["integer"] for var in block_vars),
            "row_pattern_histogram": dict(Counter(normalized_pattern(row) for row in block_rows)),
            "l_indices": l_indices,
            "day_slot_codes": day_slots,
            "representative_rows": [row_record(row, model) for row in block_rows[:3]],
        })
    repeated: dict[tuple[int, ...], list[dict]] = defaultdict(list)
    for block in blocks:
        repeated[tuple(block["l_indices"])].append({
            "block": block["block"],
            "rows": block["rows"],
            "exclusive_variables": block["exclusive_variables"],
            "day_slot_codes": block["day_slot_codes"],
        })
    repeated_component_families = [
        {
            "family": index,
            "l_indices": list(signature),
            "block_count": len(members),
            "members": members,
        }
        for index, (signature, members) in enumerate(
            sorted(repeated.items(), key=lambda pair: min(item["block"] for item in pair[1])), start=1
        )
    ]
    return {
        "source": str(source.as_posix()),
        "sha256": sha256(source),
        "block_count": len(block_ids),
        "block_rows": len(dec["block_of_row"]),
        "master_rows": len(dec["master_rows"]),
        "listed_row_count": len(listed_rows),
        "unknown_listed_row_count": len(unknown_rows),
        "unknown_listed_row_sample": unknown_rows[:20],
        "original_rows_omitted_by_this_decomposition": len(omitted_rows),
        "master_row_pattern_histogram": dict(Counter(normalized_pattern(row) for row in dec["master_rows"])),
        "exclusive_block_variable_count": sum(len(value) for value in exclusive_variables.values()),
        "cross_block_variable_count": len(cross_block_variables),
        "cross_block_variable_pattern_histogram": dict(Counter(normalized_pattern(var) for var in cross_block_variables)),
        "cross_block_variable_sample": cross_block_variables[:30],
        "retained_master_only_variable_count": len(retained_master_only_variables),
        "retained_master_only_variable_pattern_histogram": dict(
            Counter(normalized_pattern(var) for var in retained_master_only_variables)
        ),
        "no_retained_row_variable_count": len(no_retained_row_variables),
        "repeated_component_family_count": len(repeated_component_families),
        "repeated_component_families": repeated_component_families,
        "blocks": blocks,
    }


def analyze(mps_path: Path, dec_path: Path, coarse_dec_path: Path | None) -> dict:
    model = parse_mps(mps_path)
    dec = parse_dec(dec_path)
    rows = model["rows"]
    variables = model["variables"]
    objective_rows = [row for row, info in rows.items() if info["sense"] == "N"]

    row_patterns = Counter(normalized_pattern(row) for row in rows if row not in objective_rows)
    variable_patterns = Counter(normalized_pattern(var) for var in variables)
    integer_choices = {}
    malformed_integer_choices = []
    for variable, info in variables.items():
        if not info["integer"]:
            continue
        match = INTEGER_CHOICE.fullmatch(variable)
        if not match:
            malformed_integer_choices.append(variable)
            continue
        c_group, resource, day, option = map(int, match.groups())
        integer_choices[variable] = {
            "c_group": c_group, "resource": resource, "day": day, "option": option,
        }

    c_groups = sorted({record["c_group"] for record in integer_choices.values()})
    choices_by_c = Counter(record["c_group"] for record in integer_choices.values())
    resources_by_c: dict[int, set[int]] = defaultdict(set)
    days_by_c: dict[int, set[int]] = defaultdict(set)
    options_by_c: dict[int, set[int]] = defaultdict(set)
    for record in integer_choices.values():
        group = record["c_group"]
        resources_by_c[group].add(record["resource"])
        days_by_c[group].add(record["day"])
        options_by_c[group].add(record["option"])

    # Rows touched by multiple C groups are the exact top-level linking rows.
    row_c_groups: dict[str, set[int]] = defaultdict(set)
    for row, info in rows.items():
        for variable, _ in info["terms"]:
            if variable in integer_choices:
                row_c_groups[row].add(integer_choices[variable]["c_group"])
    c_linking_rows = [row for row, groups in row_c_groups.items() if len(groups) > 1]
    c_local_rows = [row for row, groups in row_c_groups.items() if len(groups) == 1]
    rows_without_integer_choice = [
        row for row in rows if row not in objective_rows and not row_c_groups.get(row)
    ]

    # Assign every variable to a C group when all integer neighbours in its
    # incident rows agree.  Variables not so assignable form linking/recourse
    # infrastructure and are reported, never silently forced into a block.
    variable_c_groups: dict[str, set[int]] = defaultdict(set)
    for variable, info in variables.items():
        if variable in integer_choices:
            variable_c_groups[variable].add(integer_choices[variable]["c_group"])
        for row, _ in info["rows"]:
            variable_c_groups[variable].update(row_c_groups.get(row, set()))
    unambiguous_by_c = Counter()
    multi_c_variables = []
    no_c_variables = []
    for variable in variables:
        groups = variable_c_groups[variable]
        if len(groups) == 1:
            unambiguous_by_c[next(iter(groups))] += 1
        elif len(groups) > 1:
            multi_c_variables.append(variable)
        else:
            no_c_variables.append(variable)

    # The retained L/R/D names expose a fine recourse grid.  Summarize all L
    # indices and cross-reference it with the official connected components.
    l_indices = Counter()
    for name in list(rows) + list(variables):
        match = LEADING_L.match(name)
        if match:
            l_indices[int(match.group(1))] += 1
    dec_block_sizes = Counter(dec["block_of_row"].values())

    coarse_decomposition = None
    if coarse_dec_path is not None:
        coarse_decomposition = decomposition_audit(model, parse_dec(coarse_dec_path), coarse_dec_path)

    representative_names = []
    for pattern, _ in row_patterns.most_common(16):
        row = next(name for name in rows if normalized_pattern(name) == pattern)
        representative_names.append(row_record(row, model))

    return {
        "evidence_level": "exact original-MPS incidence audit; labels based on names are explicit inferences",
        "input": {
            "mps": str(mps_path.as_posix()), "mps_sha256": sha256(mps_path),
            "dec": str(dec_path.as_posix()), "dec_sha256": sha256(dec_path),
        },
        "dimensions": {
            "variables": len(variables),
            "binary_or_integer_variables": sum(info["integer"] for info in variables.values()),
            "continuous_variables": sum(not info["integer"] for info in variables.values()),
            "algebraic_rows": len(rows) - len(objective_rows),
            "objective_rows": objective_rows,
        },
        "name_patterns": {
            "rows": dict(row_patterns.most_common()),
            "variables": dict(variable_patterns.most_common()),
            "representative_rows": representative_names,
        },
        "integer_choice_groups": {
            "integer_choice_pattern": "C{group:02}R{resource}D{day:02}{option:02}",
            "malformed_integer_choice_count": len(malformed_integer_choices),
            "malformed_integer_choice_sample": malformed_integer_choices[:20],
            "c_groups": c_groups,
            "c_group_count": len(c_groups),
            "integer_choices_by_c_group": {str(key): choices_by_c[key] for key in c_groups},
            "resources_by_c_group": {str(key): sorted(resources_by_c[key]) for key in c_groups},
            "days_by_c_group": {str(key): sorted(days_by_c[key]) for key in c_groups},
            "options_by_c_group": {str(key): sorted(options_by_c[key]) for key in c_groups},
            "rows_touching_multiple_c_groups": len(c_linking_rows),
            "rows_touching_one_c_group": len(c_local_rows),
            "rows_touching_no_integer_choice": len(rows_without_integer_choice),
            "linking_row_pattern_histogram": dict(Counter(normalized_pattern(row) for row in c_linking_rows)),
            "linking_row_sample": [row_record(row, model) for row in c_linking_rows[:20]],
            "unambiguous_variables_by_c_group": {str(key): unambiguous_by_c[key] for key in c_groups},
            "variables_touching_multiple_c_groups": len(multi_c_variables),
            "multi_c_variable_sample": multi_c_variables[:30],
            "variables_touching_no_c_group": len(no_c_variables),
            "no_c_variable_pattern_histogram": dict(Counter(normalized_pattern(v) for v in no_c_variables)),
        },
        "fine_recourse_structure": {
            "l_index_count": len(l_indices),
            "l_indices": sorted(l_indices),
            "records_by_l_index": {str(key): l_indices[key] for key in sorted(l_indices)},
            "official_dec_block_count": len(dec_block_sizes),
            "official_dec_master_row_count": len(dec["master_rows"]),
            "official_dec_block_size_histogram": dict(Counter(dec_block_sizes.values())),
            "official_dec_rows_partitioned": len(dec["block_of_row"]),
        },
        "thirty_block_presolved_decomposition": coarse_decomposition,
        "interpretation": {
            "known": "MIPLIB labels the application unknown; no domain claim is made.",
            "inferred": (
                "There are 64 C-prefix integer-choice groups, not 30.  The 30-block fact comes from the "
                "official presolved decomposition.  L/R/D names expose the recourse grid; the exact "
                "master rows and cross-block variables are reported from matrix incidence."
            ),
            "solution_status": "No new incumbent, dual bound, or optimality claim is made by this audit.",
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("dec", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--coarse-dec", type=Path)
    args = parser.parse_args()
    result = analyze(args.mps, args.dec, args.coarse_dec)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({
        "c_groups": result["integer_choice_groups"]["c_group_count"],
        "malformed_integer_choices": result["integer_choice_groups"]["malformed_integer_choice_count"],
        "c_linking_rows": result["integer_choice_groups"]["rows_touching_multiple_c_groups"],
        "multi_c_variables": result["integer_choice_groups"]["variables_touching_multiple_c_groups"],
        "fine_dec_blocks": result["fine_recourse_structure"]["official_dec_block_count"],
        "presolved_dec_blocks": (
            result["thirty_block_presolved_decomposition"]["block_count"]
            if result["thirty_block_presolved_decomposition"] else None
        ),
    }, indent=2))


if __name__ == "__main__":
    main()
