#!/usr/bin/env python3
"""Solve the continuous relaxation with COPT and export original-row duals."""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import time
from collections import Counter
from pathlib import Path

import coptpy as cp


def attr(model, attribute, default=None):
    try:
        return model.getAttr(attribute)
    except Exception:
        return default


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--outdir", type=Path, required=True)
    parser.add_argument("--threads", type=int, default=16)
    parser.add_argument("--time-limit", type=float, default=300.0)
    parser.add_argument(
        "--zero-cost-unbounded-penalty",
        type=float,
        default=0.0,
        help="subtract this amount from zero-cost columns without a finite upper bound to create dual slack",
    )
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)

    environment = cp.Envr()
    model = environment.createModel("ns2122698-lp-relaxation")
    model.read(str(args.model))
    variables = model.getVars().getAll()
    rows = model.getConstrs().getAll()
    perturbed_columns = 0
    for variable in variables:
        variable.setType(cp.COPT.CONTINUOUS)
        if (
            args.zero_cost_unbounded_penalty
            and variable.obj == 0
            and variable.ub >= cp.COPT.INFINITY * 0.9
        ):
            variable.obj = -args.zero_cost_unbounded_penalty
            perturbed_columns += 1
    model.setLogFile(str(args.outdir / "solver.log"))
    model.setParam(cp.COPT.Param.Threads, args.threads)
    model.setParam(cp.COPT.Param.TimeLimit, args.time_limit)
    model.setParam(cp.COPT.Param.GPUMode, 0)

    started = time.time()
    model.solve()
    elapsed = time.time() - started
    has_lp_solution = bool(attr(model, cp.COPT.Attr.HasLpSol, False))
    if not has_lp_solution:
        raise RuntimeError("COPT did not return an LP solution")

    duals = model.getInfo(cp.COPT.Info.Dual, model.getConstrs())
    reduced_costs = model.getInfo(cp.COPT.Info.RedCost, model.getVars())
    with (args.outdir / "row-duals.sol").open("w", encoding="ascii") as stream:
        stream.write("# Original-row LP dual multipliers exported by COPT 8.0.4.\n")
        for row, value in zip(rows, duals):
            if value:
                stream.write(f"{row.name} {value:.17g}\n")

    unbounded_above_reduced_costs = [
        value for variable, value in zip(variables, reduced_costs)
        if variable.ub >= cp.COPT.INFINITY * 0.9
    ]
    result = {
        "schema": "ns2122698-copt-lp-dual-export-v1",
        "solver": "COPT",
        "solver_version": [cp.COPT.VERSION_MAJOR, cp.COPT.VERSION_MINOR, cp.COPT.VERSION_TECHNICAL],
        "host": platform.node(),
        "model_sha256": hashlib.sha256(args.model.read_bytes()).hexdigest(),
        "variables": len(variables),
        "rows": len(rows),
        "relaxed_integer_variables": 16447,
        "zero_cost_unbounded_penalty": args.zero_cost_unbounded_penalty,
        "perturbed_columns": perturbed_columns,
        "parameters": {"threads": args.threads, "time_limit": args.time_limit, "gpu_mode": 0},
        "wall_seconds": elapsed,
        "lp_status": attr(model, cp.COPT.Attr.LpStatus),
        "lp_objective": attr(model, cp.COPT.Attr.LpObjVal),
        "nonzero_row_duals": sum(value != 0 for value in duals),
        "dual_signs": dict(Counter("positive" if value > 0 else "negative" if value < 0 else "zero" for value in duals)),
        "unbounded_above_columns": len(unbounded_above_reduced_costs),
        "minimum_solver_reduced_cost_on_unbounded_above_column": min(unbounded_above_reduced_costs),
        "maximum_solver_reduced_cost_violation_on_unbounded_above_column": max(
            0.0, -min(unbounded_above_reduced_costs)
        ),
        "dual_artifact": "row-duals.sol",
        "evidence_note": "Floating-point dual candidate only; use verify_exact_lp_dual.py before claiming a strict bound.",
    }
    (args.outdir / "result.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
