#!/usr/bin/env python3
"""Reproducible COPT searches and incumbent-centred neighborhoods for ns2122698."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import re
import time
from pathlib import Path

import coptpy as cp


C_GROUP = re.compile(r"^C(\d{2})R")


def file_hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def get_attr(model, attribute, default=None):
    try:
        return model.getAttr(attribute)
    except Exception:
        try:
            return getattr(model, attribute)
        except Exception:
            return default


def read_sparse_solution(path: Path) -> dict[str, float]:
    values: dict[str, float] = {}
    for line in path.read_text(encoding="ascii").splitlines():
        pieces = line.split()
        if len(pieces) == 2 and not pieces[0].startswith("#"):
            values[pieces[0]] = float(pieces[1])
    return values


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--start", type=Path)
    parser.add_argument("--outdir", type=Path, required=True)
    parser.add_argument("--time-limit", type=float, default=300.0)
    parser.add_argument("--threads", type=int, default=16)
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument("--mode", choices=("default", "aggressive", "bound"), default="default")
    parser.add_argument(
        "--free-groups",
        help="comma-separated C-prefix groups to leave free; all other integer choices are fixed to the start",
    )
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)

    sparse = read_sparse_solution(args.start) if args.start else {}
    free_groups = (
        {int(token) for token in args.free_groups.split(",") if token}
        if args.free_groups
        else None
    )

    environment = cp.Envr()
    model = environment.createModel("ns2122698-search")
    model.read(str(args.model))
    variables = model.getVars().getAll()
    original_objective = [variable.obj for variable in variables]

    start_values = None
    load_return = None
    if args.start:
        start_values = [sparse.get(variable.name, 0.0) for variable in variables]
        model.setMipStart(variables, start_values)
        load_return = model.loadMipStart()

    fixed_integer_variables = 0
    free_integer_variables = 0
    unparsed_integer_variables = 0
    if free_groups is not None:
        if not args.start:
            raise ValueError("--free-groups requires --start")
        for variable in variables:
            if variable.vtype == cp.COPT.CONTINUOUS:
                continue
            match = C_GROUP.match(variable.name)
            if not match:
                unparsed_integer_variables += 1
                continue
            if int(match.group(1)) in free_groups:
                free_integer_variables += 1
            else:
                value = sparse.get(variable.name, 0.0)
                variable.lb = value
                variable.ub = value
                fixed_integer_variables += 1

    model.setLogFile(str(args.outdir / "solver.log"))
    parameters: dict[str, int | float] = {
        "Threads": args.threads,
        "TimeLimit": args.time_limit,
        "GPUMode": 0,
        "RelGap": 0.0,
        "RandomSeed": args.seed,
    }
    model.setParam(cp.COPT.Param.Threads, args.threads)
    model.setParam(cp.COPT.Param.TimeLimit, args.time_limit)
    model.setParam(cp.COPT.Param.GPUMode, 0)
    model.setParam(cp.COPT.Param.RelGap, 0.0)
    try:
        model.setParam("RandomSeed", args.seed)
    except Exception:
        parameters.pop("RandomSeed")

    if args.mode == "aggressive":
        settings = (
            (cp.COPT.Param.HeurLevel, 3),
            (cp.COPT.Param.PreRootHeurLevel, 3),
            (cp.COPT.Param.RoundingHeurLevel, 3),
            (cp.COPT.Param.DivingHeurLevel, 3),
            (cp.COPT.Param.FAPHeurLevel, 4),
            (cp.COPT.Param.SubMipHeurLevel, 3),
            (cp.COPT.Param.MipRepair, 3),
        )
    elif args.mode == "bound":
        settings = (
            (cp.COPT.Param.HeurLevel, 0),
            (cp.COPT.Param.PreRootHeurLevel, 0),
            (cp.COPT.Param.CutLevel, 3),
            (cp.COPT.Param.RootCutLevel, 3),
            (cp.COPT.Param.RootCutRounds, 20),
            (cp.COPT.Param.StrongBranching, 2),
        )
    else:
        settings = ()
    for parameter, value in settings:
        try:
            model.setParam(parameter, value)
            parameters[str(parameter)] = value
        except Exception as error:
            parameters[str(parameter)] = f"unsupported: {error}"

    started = time.time()
    model.solve()
    wall_seconds = time.time() - started
    has_solution = bool(get_attr(model, cp.COPT.Attr.HasMipSol, False))
    result = {
        "schema": "ns2122698-copt-search-v1",
        "solver": "COPT",
        "solver_version": [
            cp.COPT.VERSION_MAJOR,
            cp.COPT.VERSION_MINOR,
            cp.COPT.VERSION_TECHNICAL,
        ],
        "host": platform.node(),
        "cpu_only": True,
        "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES", ""),
        "model_sha256": file_hash(args.model),
        "start_sha256": file_hash(args.start) if args.start else None,
        "mip_start_sparse_values": len(sparse),
        "mip_start_dense_values": len(start_values) if start_values is not None else 0,
        "load_mip_start_return": repr(load_return),
        "mode": args.mode,
        "free_groups": sorted(free_groups) if free_groups is not None else None,
        "fixed_integer_variables": fixed_integer_variables,
        "free_integer_variables": free_integer_variables,
        "unparsed_integer_variables": unparsed_integer_variables,
        "parameters": parameters,
        "wall_seconds": wall_seconds,
        "mip_status": get_attr(model, cp.COPT.Attr.MipStatus),
        "node_count": get_attr(model, cp.COPT.Attr.NodeCnt),
        "has_mip_solution": has_solution,
        "best_bound_solver_objective": get_attr(model, cp.COPT.Attr.BestBnd),
        "best_objective_solver_objective": get_attr(model, cp.COPT.Attr.BestObj),
    }
    if has_solution:
        values = model.getInfo(cp.COPT.Info.Value, model.getVars())
        result["recomputed_original_objective"] = sum(
            coefficient * value
            for coefficient, value in zip(original_objective, values)
        )
        model.writeSol(str(args.outdir / "incumbent.sol"))

    (args.outdir / "result.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print("RESULT_JSON=" + json.dumps(result, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
