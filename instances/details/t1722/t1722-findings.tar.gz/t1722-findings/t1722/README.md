# t1722

Official MIPLIB status: open. This study reproduced the public feasible
objective `108953`; it found no new upper or lower bound.

## Structure and method

The model is a 338-row, 36,630-column binary set-partitioning formulation from
Berlin's Telebus dial-a-ride planning problem. Exact duplicate-support
compression reduced it to 6,581 supports and identified 10,550 dominated
same-support columns.

Without invoking MIP optimization, an exact exchange program exhaustively
ruled out all improving connected incumbent exchanges of cardinality at most
five: 7,068,620 combinations and 8,343,973 completion nodes. A separate
30-minute association-guided heuristic evaluated 292,807,348 moves and made 84
exact 6--12-block repairs, also without improvement.

## Evidence boundary

The public solution is proved locally optimal only against connected exchanges
of at most five incumbent blocks in the reduced-support interaction graph.
This is not a global-optimality proof.

Sources: [MIPLIB instance page](https://miplib.zib.de/instance_details_t1722.html),
[Telebus optimization project](https://www.zib.de/research/projects/optimization-berlins-telebus-dial-ride-service-handicapped-people-0).

