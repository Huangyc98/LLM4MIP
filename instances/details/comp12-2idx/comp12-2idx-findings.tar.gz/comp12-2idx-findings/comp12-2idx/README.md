# `comp12-2idx`

## Result

The best verified feasible objective remains **277**; the latest global lower
bound is **165** (2026-09-05, original model plus 1,852 conflict-clique cuts).
This is a floating-point solver bound, not an independently checked exact tree.
It improves the earlier repository bound 131. Global optimality remains open.
See the [latest report](../../docs/ten-instance-results-2026-09-06.zh.md)
and [run evidence](../../studies/ten-instance-2026-09-06/hour-pass/runs/20260905-2h/comp12-2idx/).

## Earlier local certificates

The strongest exact local result is:

- no solution with objective at most 276 exists within Hamming radius 10 of the 277 timetable;
- because course-period assignment distances are even, any improving solution must change at least 12 binary positions, corresponding to at least six reassigned teaching periods;
- curriculum-directed neighborhoods containing 36 and 50 courses were also solved exactly with optimum 277.

Larger neighborhoods and directed searches found no improvement but did not close their bounds.

## Input

- SHA-256: `5C3B597C3D999D4298DFB52FD6589838445752A59590B10C0CC20744453643CE`
- Original model: 11,863 variables and 16,803 constraints.
- Verified solution: all rows, bounds, and integrality conditions satisfied exactly; objective 277.

## Reproduce the radius-10 proof

Requires Gurobi:

```powershell
python .\instances\comp12-2idx\scripts\comp12_strengthened_solve.py `
  .\instances\comp12-2idx\input\comp12-2idx.mps.gz `
  .\instances\comp12-2idx\solutions\comp12-2idx-verified277.sol `
  --seconds 600 --threads 40 --focus 3 --replace-pairwise `
  --local-branching 10 --target 276 `
  --result comp12-lb10.sol --log comp12-lb10.log
```

See the [continuation study](reports/comp12-continuation-study.md) and [proof log](logs/comp12-lb10-long.log).
