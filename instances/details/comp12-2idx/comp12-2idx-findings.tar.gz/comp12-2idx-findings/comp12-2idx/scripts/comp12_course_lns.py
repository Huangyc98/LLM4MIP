#!/usr/bin/env python3
"""Course-level large-neighborhood search for comp12-2idx."""

from __future__ import annotations

import argparse
import random
import re
from pathlib import Path

import gurobipy as gp


def read_solution(path: Path) -> dict[str, float]:
    values: dict[str, float] = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        tokens = raw.split()
        if len(tokens) == 2 and tokens[0] != "=obj=" and not tokens[0].startswith("#"):
            values[tokens[0]] = float(tokens[1])
    return values


def course_of_y(name: str) -> str | None:
    if not name.startswith("y") or "(" not in name:
        return None
    return name[1:].split("(", 1)[0]


def violated_course(name: str) -> str | None:
    prefix = "DaysBelowVio"
    if not name.startswith(prefix):
        return None
    return re.sub(r"\d+$", "", name[len(prefix) :])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--iterations", type=int, default=6)
    parser.add_argument("--seconds", type=float, default=30.0)
    parser.add_argument("--threads", type=int, default=32)
    parser.add_argument("--seed", type=int, default=20260831)
    parser.add_argument("--result", type=Path, required=True)
    parser.add_argument("--log", type=Path)
    args = parser.parse_args()

    rng = random.Random(args.seed)
    model = gp.read(str(args.mps))
    model.update()
    variables = model.getVars()
    initial = read_solution(args.solution)
    incumbent = {variable.VarName: initial.get(variable.VarName, 0.0) for variable in variables}
    incumbent_objective = sum(variable.Obj * incumbent[variable.VarName] for variable in variables)

    y_by_course: dict[str, list[gp.Var]] = {}
    for variable in variables:
        course = course_of_y(variable.VarName)
        if course is not None:
            y_by_course.setdefault(course, []).append(variable)
    courses = sorted(y_by_course)
    y_variables = [variable for group in y_by_course.values() for variable in group]
    original_bounds = {variable.VarName: (variable.LB, variable.UB) for variable in y_variables}

    print(
        f"courses={len(courses)} assignment_variables={len(y_variables)} "
        f"initial_objective={incumbent_objective:.15g}"
    )
    if args.log:
        model.Params.LogFile = str(args.log)
    model.Params.Threads = args.threads
    model.Params.MIPFocus = 1
    model.Params.NoRelHeurTime = min(5.0, args.seconds / 4)
    model.Params.OutputFlag = 1

    sizes = [25, 40, 60, 80, 110, len(courses)]
    for iteration in range(args.iterations):
        for variable in y_variables:
            variable.LB, variable.UB = original_bounds[variable.VarName]

        penalized = {
            course
            for variable in variables
            if incumbent[variable.VarName] > 0.5
            for course in [violated_course(variable.VarName)]
            if course in y_by_course
        }
        target_size = min(sizes[iteration % len(sizes)], len(courses))
        selected = set(penalized)
        remaining = [course for course in courses if course not in selected]
        rng.shuffle(remaining)
        selected.update(remaining[: max(0, target_size - len(selected))])

        fixed = 0
        for course, group in y_by_course.items():
            if course in selected:
                continue
            for variable in group:
                value = round(incumbent[variable.VarName])
                variable.LB = variable.UB = value
                fixed += 1

        model.Params.TimeLimit = args.seconds
        model.Params.BestObjStop = incumbent_objective - 0.5
        model.reset(0)
        for variable in variables:
            variable.Start = incumbent[variable.VarName]
        print(
            f"iteration={iteration+1} selected_courses={len(selected)} "
            f"penalized_courses={len(penalized)} fixed_y={fixed}"
        )
        model.optimize()

        if model.SolCount and model.ObjVal < incumbent_objective - 1e-6:
            incumbent_objective = model.ObjVal
            incumbent = {variable.VarName: variable.X for variable in variables}
            model.write(str(args.result))
            print(f"IMPROVED objective={incumbent_objective:.15g}")
        else:
            print(
                f"no_improvement status={model.Status} sol_count={model.SolCount} "
                f"best={(model.ObjVal if model.SolCount else float('inf')):.15g}"
            )

    if not args.result.exists():
        # Preserve the verified starting solution if no neighborhood improves it.
        for variable in y_variables:
            variable.LB, variable.UB = original_bounds[variable.VarName]
        model.Params.TimeLimit = 1
        model.Params.BestObjStop = -gp.GRB.INFINITY
        model.reset(0)
        for variable in variables:
            variable.Start = incumbent[variable.VarName]
        model.optimize()
        if model.SolCount:
            model.write(str(args.result))
    print(f"final_objective={incumbent_objective:.15g} result={args.result}")


if __name__ == "__main__":
    main()
