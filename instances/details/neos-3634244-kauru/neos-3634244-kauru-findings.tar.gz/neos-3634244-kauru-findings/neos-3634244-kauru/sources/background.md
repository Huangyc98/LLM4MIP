# Background notes: neos-3634244-kauru

Retrieved 2026-09-09.

## Authoritative instance record

- MIPLIB detail page: https://miplib.zib.de/instance_details_neos-3634244-kauru.html
- Official MPS: https://miplib.zib.de/WebData/instances/neos-3634244-kauru.mps.gz
- MIPLIB status: open; minimization; displayed incumbent `1398.014670518538*`.
- Submitter: Jeff Linderoth; group `neos-pseudoapplication-110`.
- Original size: 4,376 variables (4,375 binary, one continuous), 761,450
  constraints, 2,292,500 nonzeros.  MIPLIB classifies 175 rows as set
  partitioning, 25 as invariant knapsack, and 761,250 as mixed-binary.
- The page supplies no bibliographic reference.  The two public solutions have
  exact objective 1398.016 after validation; the numerically lower 2022 record
  has a 7e-7 integrality violation.

## Additional authoritative/technical evidence

- The MIPLIB download page documents the official solution archive and solution
  checker conventions: https://miplib.zib.de/download.html
- A TU Darmstadt symmetry census reports full variable participation in a
  wreath-product-style `M(S25, 4375)` symmetry for this instance, consistent
  with arbitrary permutation of 25 cluster labels:
  https://wwwopt.mathematik.tu-darmstadt.de/~pfetsch/symmetries/miplib2017-presol-symmetries.pdf
- The Matrix/Instance Collection entry labels the application only as
  `neos-pseudoapplication-110`; no substantive application description is
  public: https://mic.optimatorlab.org/instances/index.html

## Structure recovered from the original MPS

Read-only Gurobi 13.0.2 parsing (no presolve or optimization) verifies:

- binaries form a 175 x 25 matrix `x[i,k]`;
- 175 equalities enforce `sum_k x[i,k] = 1`;
- 25 inequalities enforce `sum_i x[i,k] <= 7`; because all 175 entities must
  be assigned, each cluster in every feasible solution has exactly seven;
- each of 761,250 epigraph rows has the form
  `-t + d*x[i,k] + d*x[j,k] <= d`, hence if `i,j` share a cluster then
  `t >= d`;
- there are two such rows per unordered entity pair and cluster, so only the
  larger of the two directed pair costs matters;
- therefore threshold feasibility is an equitable/capacitated 25-coloring of a
  175-vertex conflict graph, or equivalently an exact cover by 25 independent
  7-sets;
- cluster labels are completely symmetric.

The public exact incumbent corresponds to pair-cost value `1398.0156859`.
The immediately preceding distinct pair-cost value is `1397.4872804`.
Consequently, a machine-checkable infeasibility certificate for the threshold
`1397.4872804` plus a strictly feasible partition at `1398.0156859` would prove
global optimality for the original MPS (up to exact decimal interpretation).

Files `structure/gurobi_structure.json` and
`structure/recovered_model.json` contain the auditable extraction.
