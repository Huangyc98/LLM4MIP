#!/usr/bin/env python3
"""
Exact threshold decision search for neos-3634244-kauru.

Gurobi is used only as an MPS parser. No optimization is performed here.

Semantic binary:
    integral variable with bounds exactly [0,1], regardless of whether
    Gurobi reports VType 'B' or 'I'.

Search:
    canonical restricted-growth coloring of the 175-vertex threshold graph
    into 25 independent classes of size 7.

Proof:
    complete deterministic search tree, independently replayed by verify mode.

Proof records:
    B <vertex> <color>...
        The deterministic branch vertex and all legal canonical colors.
    P <reason>
        A sound prune. The verifier recomputes the specified reason.

Prune reasons:
    COMPLETE   Complete assignment is not a valid 25 x 7 partition.
    CAPACITY   Total residual cluster capacity is too small.
    CLUSTER c  Existing cluster c lacks enough individually compatible vertices.
    DOMAIN v   Unassigned vertex v has no possible existing/new cluster.
    MATCHING   Residual vertex-to-cluster capacitated bipartite matching fails.

The MATCHING test is a relaxation because it ignores conflicts between pairs
of vertices newly placed in the same cluster. Therefore matching failure is a
sound infeasibility prune.
"""

import argparse
import hashlib
import json
import os
import sys
import time
from collections import deque

import gurobipy as gp
from gurobipy import GRB


DEFAULT_THRESHOLD = 1397.4872804
N = 175
K = 25
CAP = 7
ALL = (1 << N) - 1

BOUND_TOL = 1e-9
ROW_TOL = 1e-8
COEFF_TOL = 1e-7
THRESHOLD_AUDIT_TOL = 1e-7


def bit_vertices(mask):
    while mask:
        b = mask & -mask
        yield b.bit_length() - 1
        mask ^= b


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            block = f.read(1 << 20)
            if not block:
                break
            h.update(block)
    return h.hexdigest()


def graph_sha256(adj):
    h = hashlib.sha256()
    for a in adj:
        h.update(int(a).to_bytes((N + 7) // 8, "little", signed=False))
    return h.hexdigest()


def near(a, b, tol=ROW_TOL):
    return abs(a - b) <= tol


def is_integral_type(vtype):
    return vtype in (GRB.BINARY, GRB.INTEGER, "B", "I")


def is_continuous_type(vtype):
    return vtype in (GRB.CONTINUOUS, "C")


def is_semantic_binary(var):
    return (
        is_integral_type(var.VType)
        and near(var.LB, 0.0, BOUND_TOL)
        and near(var.UB, 1.0, BOUND_TOL)
    )


def recover(mps_path, threshold):
    print("[recover] reading:", mps_path, flush=True)
    model = gp.read(mps_path)
    model.update()

    variables = model.getVars()
    constraints = model.getConstrs()

    print(
        "[recover] variables:",
        len(variables),
        "constraints:",
        len(constraints),
        flush=True,
    )

    type_counts = {}
    for var in variables:
        type_counts[var.VType] = type_counts.get(var.VType, 0) + 1
    print("[recover] Gurobi variable types:", type_counts, flush=True)

    semantic_binary_indices = {
        var.index for var in variables if is_semantic_binary(var)
    }
    if len(semantic_binary_indices) != 4375:
        examples = [
            (v.VarName, v.VType, v.LB, v.UB)
            for v in variables
            if v.index not in semantic_binary_indices
        ][:10]
        raise RuntimeError(
            "expected 4375 integral [0,1] variables, got %d; "
            "first excluded variables: %r"
            % (len(semantic_binary_indices), examples)
        )

    nonbinary_indices = [
        v.index for v in variables if v.index not in semantic_binary_indices
    ]
    if len(nonbinary_indices) != 1:
        raise RuntimeError(
            "expected exactly one non-assignment variable, got %d"
            % len(nonbinary_indices)
        )

    t_index = nonbinary_indices[0]
    tvar = variables[t_index]

    if not is_continuous_type(tvar.VType):
        raise RuntimeError(
            "the unique non-semantic-binary variable is not continuous: "
            "%s type=%s bounds=[%r,%r]"
            % (tvar.VarName, tvar.VType, tvar.LB, tvar.UB)
        )

    objective_nonzero = [
        (v.index, v.VarName, v.Obj)
        for v in variables
        if abs(v.Obj) > ROW_TOL
    ]
    if len(objective_nonzero) != 1 or objective_nonzero[0][0] != t_index:
        raise RuntimeError(
            "expected objective to involve only the continuous variable; got %r"
            % objective_nonzero
        )
    if tvar.Obj <= 0:
        raise RuntimeError(
            "expected positive minimization coefficient on epigraph variable"
        )
    if model.ModelSense != GRB.MINIMIZE:
        raise RuntimeError("expected a minimization model")

    print(
        "[recover] semantic binaries:",
        len(semantic_binary_indices),
        "(integral variables bounded [0,1])",
        flush=True,
    )
    print(
        "[recover] objective variable:",
        tvar.VarName,
        "type=",
        tvar.VType,
        "bounds=[%r,%r]" % (tvar.LB, tvar.UB),
        "obj=",
        tvar.Obj,
        flush=True,
    )

    assignment_groups = []
    capacity_groups = []

    for constr in constraints:
        row = model.getRow(constr)
        terms = [
            (row.getVar(pos).index, row.getCoeff(pos))
            for pos in range(row.size())
        ]

        if (
            constr.Sense == GRB.EQUAL
            and len(terms) == K
            and near(constr.RHS, 1.0)
            and all(
                idx in semantic_binary_indices and near(coef, 1.0)
                for idx, coef in terms
            )
        ):
            group = sorted(idx for idx, _ in terms)
            if len(set(group)) != K:
                raise RuntimeError(
                    "duplicate variable in assignment row %s"
                    % constr.ConstrName
                )
            assignment_groups.append(group)

        elif (
            constr.Sense == GRB.LESS_EQUAL
            and len(terms) == N
            and near(constr.RHS, float(CAP))
            and all(
                idx in semantic_binary_indices and near(coef, 1.0)
                for idx, coef in terms
            )
        ):
            group = sorted(idx for idx, _ in terms)
            if len(set(group)) != N:
                raise RuntimeError(
                    "duplicate variable in capacity row %s"
                    % constr.ConstrName
                )
            capacity_groups.append(group)

    if len(assignment_groups) != N:
        raise RuntimeError(
            "expected %d assignment equalities, got %d"
            % (N, len(assignment_groups))
        )
    if len(capacity_groups) != K:
        raise RuntimeError(
            "expected %d capacity inequalities, got %d"
            % (K, len(capacity_groups))
        )

    assignment_groups.sort(key=lambda group: tuple(group))
    capacity_groups.sort(key=lambda group: tuple(group))

    entity_of_index = {}
    for entity, group in enumerate(assignment_groups):
        for idx in group:
            if idx in entity_of_index:
                raise RuntimeError(
                    "variable column %d occurs in multiple assignment rows" % idx
                )
            entity_of_index[idx] = entity

    color_of_index = {}
    for color, group in enumerate(capacity_groups):
        for idx in group:
            if idx in color_of_index:
                raise RuntimeError(
                    "variable column %d occurs in multiple capacity rows" % idx
                )
            color_of_index[idx] = color

    if set(entity_of_index) != semantic_binary_indices:
        missing = sorted(semantic_binary_indices - set(entity_of_index))
        extra = sorted(set(entity_of_index) - semantic_binary_indices)
        raise RuntimeError(
            "assignment rows do not partition semantic binaries; "
            "missing=%r extra=%r" % (missing[:10], extra[:10])
        )

    if set(color_of_index) != semantic_binary_indices:
        missing = sorted(semantic_binary_indices - set(color_of_index))
        extra = sorted(set(color_of_index) - semantic_binary_indices)
        raise RuntimeError(
            "capacity rows do not partition semantic binaries; "
            "missing=%r extra=%r" % (missing[:10], extra[:10])
        )

    x_index = [[None] * K for _ in range(N)]
    for idx in sorted(semantic_binary_indices):
        entity = entity_of_index[idx]
        color = color_of_index[idx]
        if x_index[entity][color] is not None:
            raise RuntimeError(
                "two columns map to entity/color cell (%d,%d)"
                % (entity, color)
            )
        x_index[entity][color] = idx

    missing_cells = [
        (i, k)
        for i in range(N)
        for k in range(K)
        if x_index[i][k] is None
    ]
    if missing_cells:
        raise RuntimeError(
            "incomplete 175 x 25 assignment matrix; first missing cells %r"
            % missing_cells[:10]
        )

    pair_cost = [[float("-inf")] * N for _ in range(N)]
    epigraph_rows = 0
    nearest = None

    for constr in constraints:
        row = model.getRow(constr)
        if row.size() != 3 or constr.Sense != GRB.LESS_EQUAL:
            continue

        t_coefficients = []
        binary_terms = []

        for pos in range(row.size()):
            var = row.getVar(pos)
            idx = var.index
            coef = row.getCoeff(pos)

            if idx == t_index:
                t_coefficients.append(coef)
            elif idx in semantic_binary_indices:
                binary_terms.append((idx, coef))
            else:
                binary_terms = []
                break

        if len(t_coefficients) != 1 or len(binary_terms) != 2:
            continue

        tcoef = t_coefficients[0]
        if not near(tcoef, -1.0):
            raise RuntimeError(
                "three-term row %s contains t with coefficient %r, not -1"
                % (constr.ConstrName, tcoef)
            )

        idx1, coef1 = binary_terms[0]
        idx2, coef2 = binary_terms[1]
        i = entity_of_index[idx1]
        j = entity_of_index[idx2]
        k1 = color_of_index[idx1]
        k2 = color_of_index[idx2]

        if i == j or k1 != k2:
            raise RuntimeError(
                "malformed epigraph row %s: entities=(%d,%d), colors=(%d,%d)"
                % (constr.ConstrName, i, j, k1, k2)
            )

        if (
            abs(coef1 - coef2) > COEFF_TOL
            or abs(coef1 - constr.RHS) > COEFF_TOL
            or abs(coef2 - constr.RHS) > COEFF_TOL
        ):
            raise RuntimeError(
                "malformed epigraph coefficients in %s: "
                "coef1=%r coef2=%r rhs=%r"
                % (constr.ConstrName, coef1, coef2, constr.RHS)
            )

        # They should agree. max is conservative against tiny parser differences.
        d = max(coef1, coef2, constr.RHS)

        if i > j:
            i, j = j, i
        if d > pair_cost[i][j]:
            pair_cost[i][j] = d

        epigraph_rows += 1
        gap = abs(d - threshold)
        candidate = (gap, d, constr.ConstrName)
        if nearest is None or candidate < nearest:
            nearest = candidate

    expected_epigraph_rows = 2 * (N * (N - 1) // 2) * K
    if epigraph_rows != expected_epigraph_rows:
        raise RuntimeError(
            "expected %d epigraph rows, got %d"
            % (expected_epigraph_rows, epigraph_rows)
        )

    missing_pairs = [
        (i, j)
        for i in range(N)
        for j in range(i + 1, N)
        if pair_cost[i][j] == float("-inf")
    ]
    if missing_pairs:
        raise RuntimeError(
            "missing effective costs for %d pairs; first %r"
            % (len(missing_pairs), missing_pairs[:10])
        )

    print("[recover] assignment rows:", len(assignment_groups), flush=True)
    print("[recover] capacity rows:", len(capacity_groups), flush=True)
    print("[recover] epigraph rows:", epigraph_rows, flush=True)
    print(
        "[recover] nearest parsed row cost to threshold:",
        nearest,
        flush=True,
    )

    if (
        nearest is not None
        and 0.0 < nearest[0] < THRESHOLD_AUDIT_TOL
    ):
        raise RuntimeError(
            "a parsed coefficient lies within %.1e of the threshold but is "
            "not equal. Audit the original MPS decimal tokens before using "
            "a strict threshold comparison. Nearest=%r"
            % (THRESHOLD_AUDIT_TOL, nearest)
        )

    adj = [0] * N
    edges = 0
    greatest_allowed = float("-inf")
    least_forbidden = float("inf")
    maximum_cost = float("-inf")

    for i in range(N):
        for j in range(i + 1, N):
            d = pair_cost[i][j]
            maximum_cost = max(maximum_cost, d)
            if d <= threshold:
                greatest_allowed = max(greatest_allowed, d)
            else:
                least_forbidden = min(least_forbidden, d)
                adj[i] |= 1 << j
                adj[j] |= 1 << i
                edges += 1

    degrees = [mask.bit_count() for mask in adj]
    print("[graph] threshold:", repr(threshold), flush=True)
    print(
        "[graph] conflict edges:",
        edges,
        "density:",
        2.0 * edges / (N * (N - 1)),
        flush=True,
    )
    print(
        "[graph] greatest allowed effective cost:",
        repr(greatest_allowed),
        flush=True,
    )
    print(
        "[graph] least forbidden effective cost:",
        repr(least_forbidden),
        flush=True,
    )
    print("[graph] maximum effective cost:", repr(maximum_cost), flush=True)
    print(
        "[graph] degree min/avg/max:",
        min(degrees),
        sum(degrees) / N,
        max(degrees),
        flush=True,
    )
    print("[graph] SHA256:", graph_sha256(adj), flush=True)

    variable_names = [
        [variables[x_index[i][k]].VarName for k in range(K)]
        for i in range(N)
    ]

    return model, tvar.VarName, variable_names, adj


class Dinic:
    def __init__(self, n):
        self.n = n
        self.graph = [[] for _ in range(n)]

    def add_edge(self, u, v, capacity):
        forward = [v, capacity, None]
        reverse = [u, 0, forward]
        forward[2] = reverse
        self.graph[u].append(forward)
        self.graph[v].append(reverse)

    def max_flow(self, source, sink, limit):
        total = 0

        while total < limit:
            level = [-1] * self.n
            level[source] = 0
            queue = deque([source])

            while queue:
                u = queue.popleft()
                for edge in self.graph[u]:
                    v, capacity, _ = edge
                    if capacity > 0 and level[v] < 0:
                        level[v] = level[u] + 1
                        queue.append(v)

            if level[sink] < 0:
                break

            next_edge = [0] * self.n

            def send(u, amount):
                if u == sink:
                    return amount
                while next_edge[u] < len(self.graph[u]):
                    edge = self.graph[u][next_edge[u]]
                    v, capacity, reverse = edge
                    if capacity > 0 and level[v] == level[u] + 1:
                        pushed = send(v, min(amount, capacity))
                        if pushed:
                            edge[1] -= pushed
                            reverse[1] += pushed
                            return pushed
                    next_edge[u] += 1
                return 0

            while total < limit:
                pushed = send(source, limit - total)
                if not pushed:
                    break
                total += pushed

        return total


class CanonicalSearch:
    def __init__(
        self,
        adj,
        proof_file=None,
        progress_every=100000,
        matching_frequency=1,
    ):
        self.adj = adj
        self.degree = [mask.bit_count() for mask in adj]

        self.assignment = [-1] * N
        self.cluster_mask = [0] * K
        self.cluster_size = [0] * K
        self.used = 0
        self.unassigned = ALL

        self.nodes = 0
        self.started = time.time()
        self.proof_file = proof_file
        self.progress_every = max(1, progress_every)
        self.matching_frequency = max(1, matching_frequency)
        self.solution = None

        self.prune_counts = {
            "COMPLETE": 0,
            "CAPACITY": 0,
            "CLUSTER": 0,
            "DOMAIN": 0,
            "MATCHING": 0,
        }

    def can_join_existing(self, vertex, color):
        return (
            color < self.used
            and self.cluster_size[color] < CAP
            and not (self.cluster_mask[color] & self.adj[vertex])
        )

    def legal_colors(self, vertex):
        colors = [
            color
            for color in range(self.used)
            if self.can_join_existing(vertex, color)
        ]

        # Restricted-growth canonical naming:
        # only the next unused color may be introduced.
        if self.used < K:
            colors.append(self.used)

        return colors

    def saturation(self, vertex):
        adjacent_colors = 0
        neighbors = self.adj[vertex]
        for color in range(self.used):
            if self.cluster_mask[color] & neighbors:
                adjacent_colors += 1
        return adjacent_colors

    def choose_vertex(self):
        best_key = None
        best_vertex = None
        best_legal = None

        for vertex in bit_vertices(self.unassigned):
            legal = self.legal_colors(vertex)
            key = (
                len(legal),
                -self.saturation(vertex),
                -self.degree[vertex],
                vertex,
            )
            if best_key is None or key < best_key:
                best_key = key
                best_vertex = vertex
                best_legal = legal

        return best_vertex, best_legal

    def compatible_with_cluster_mask(self, color):
        compatible = self.unassigned
        members = self.cluster_mask[color]
        for vertex in bit_vertices(members):
            compatible &= ~self.adj[vertex]
        return compatible & ALL

    def matching_possible(self):
        """
        Exact bipartite b-matching relaxation.

        Left side: every unassigned vertex, demand 1.
        Right side: all 25 clusters, residual capacities.

        For an existing cluster, a vertex is adjacent if it conflicts with no
        current member. Every unassigned vertex is adjacent to every unused
        cluster, since those clusters are empty.

        Pairwise conflicts among newly assigned vertices are ignored. Hence
        this is a relaxation; max flow < number of unassigned vertices is a
        sound infeasibility certificate.
        """
        vertices = list(bit_vertices(self.unassigned))
        remaining = len(vertices)
        if remaining == 0:
            return True

        source = 0
        vertex_base = 1
        color_base = vertex_base + remaining
        sink = color_base + K

        flow = Dinic(sink + 1)

        for pos, vertex in enumerate(vertices):
            vnode = vertex_base + pos
            flow.add_edge(source, vnode, 1)

            for color in range(self.used):
                if self.can_join_existing(vertex, color):
                    flow.add_edge(vnode, color_base + color, 1)

            for color in range(self.used, K):
                flow.add_edge(vnode, color_base + color, 1)

        for color in range(K):
            residual = (
                CAP - self.cluster_size[color]
                if color < self.used
                else CAP
            )
            if residual > 0:
                flow.add_edge(color_base + color, sink, residual)

        return flow.max_flow(source, sink, remaining) == remaining

    def prune_reason(self, run_matching=True):
        remaining = self.unassigned.bit_count()

        if remaining == 0:
            if self.used == K and all(
                size == CAP for size in self.cluster_size
            ):
                return None
            return ("COMPLETE",)

        residual_capacity = sum(
            CAP - self.cluster_size[color]
            for color in range(self.used)
        )
        residual_capacity += (K - self.used) * CAP
        if residual_capacity < remaining:
            return ("CAPACITY",)

        # Every current cluster must eventually reach size seven. If fewer
        # than its deficit vertices are individually compatible with all of
        # its present members, completion is impossible.
        for color in range(self.used):
            deficit = CAP - self.cluster_size[color]
            if deficit > 0:
                compatible = self.compatible_with_cluster_mask(color)
                if compatible.bit_count() < deficit:
                    return ("CLUSTER", color)

        # Test every domain, not just the eventual branch vertex.
        for vertex in bit_vertices(self.unassigned):
            if not self.legal_colors(vertex):
                return ("DOMAIN", vertex)

        if run_matching and not self.matching_possible():
            return ("MATCHING",)

        return None

    def write_prune(self, reason):
        self.prune_counts[reason[0]] += 1
        if self.proof_file is None:
            return
        self.proof_file.write("P " + " ".join(map(str, reason)) + "\n")

    def put(self, vertex, color):
        is_new = color == self.used

        if color > self.used:
            raise AssertionError("noncanonical color introduction")
        if color < self.used and not self.can_join_existing(vertex, color):
            raise AssertionError("illegal existing-color assignment")
        if is_new:
            if self.used >= K:
                raise AssertionError("too many colors")
            self.used += 1

        self.assignment[vertex] = color
        self.cluster_mask[color] |= 1 << vertex
        self.cluster_size[color] += 1
        self.unassigned &= ~(1 << vertex)
        return is_new

    def undo(self, vertex, color, is_new):
        self.unassigned |= 1 << vertex
        self.cluster_size[color] -= 1
        self.cluster_mask[color] &= ~(1 << vertex)
        self.assignment[vertex] = -1

        if is_new:
            if color != self.used - 1 or self.cluster_size[color] != 0:
                raise AssertionError("invalid canonical undo")
            self.used -= 1

    def validate_complete_solution(self):
        if self.unassigned:
            return False
        if self.used != K:
            return False
        if any(size != CAP for size in self.cluster_size):
            return False

        for color in range(K):
            members = list(bit_vertices(self.cluster_mask[color]))
            if len(members) != CAP:
                return False
            for pos, u in enumerate(members):
                for v in members[pos + 1:]:
                    if self.adj[u] & (1 << v):
                        return False
        return True

    def dfs(self):
        self.nodes += 1

        if self.nodes % self.progress_every == 0:
            elapsed = time.time() - self.started
            print(
                "[search] nodes=%d elapsed=%.1fs rate=%.1f/s "
                "assigned=%d used=%d prunes=%s"
                % (
                    self.nodes,
                    elapsed,
                    self.nodes / max(elapsed, 1e-9),
                    N - self.unassigned.bit_count(),
                    self.used,
                    self.prune_counts,
                ),
                flush=True,
            )

        if not self.unassigned:
            if self.validate_complete_solution():
                self.solution = self.assignment[:]
                return True
            reason = ("COMPLETE",)
            self.write_prune(reason)
            return False

        run_matching = (self.nodes % self.matching_frequency == 0)
        reason = self.prune_reason(run_matching=run_matching)
        if reason is not None:
            self.write_prune(reason)
            return False

        vertex, legal = self.choose_vertex()
        if vertex is None or not legal:
            # This should have been caught by DOMAIN.
            raise AssertionError("branch selection has no legal branch")

        if self.proof_file is not None:
            self.proof_file.write(
                "B %d %s\n"
                % (vertex, " ".join(map(str, legal)))
            )

        for color in legal:
            is_new = self.put(vertex, color)
            if self.dfs():
                return True
            self.undo(vertex, color, is_new)

        return False


def write_solution(path, t_name, variable_names, assignment, threshold):
    with open(path, "w", newline="\n") as output:
        output.write(
            "# integral feasible threshold candidate generated by "
            "kauru_exact.py\n"
        )
        output.write("%s %.17g\n" % (t_name, threshold))

        for entity in range(N):
            chosen = assignment[entity]
            for color in range(K):
                output.write(
                    "%s %d\n"
                    % (
                        variable_names[entity][color],
                        1 if color == chosen else 0,
                    )
                )

    print("[result] wrote candidate:", path, flush=True)


class ProofVerifier(CanonicalSearch):
    def __init__(self, adj, proof_file):
        super().__init__(
            adj,
            proof_file=None,
            progress_every=10**18,
            matching_frequency=1,
        )
        self.input = proof_file
        self.records = 0

    def get_record(self):
        line = self.input.readline()
        if not line:
            raise RuntimeError("unexpected end of proof")

        self.records += 1
        if self.records % 100000 == 0:
            print(
                "[verify] proof records:",
                self.records,
                flush=True,
            )

        line = line.strip()
        if not line:
            raise RuntimeError(
                "blank proof record at record %d" % self.records
            )
        return line

    def verify_prune(self, tokens):
        if len(tokens) < 2:
            raise RuntimeError(
                "missing prune reason at proof record %d" % self.records
            )

        claimed = tuple(
            [tokens[1]]
            + [int(token) for token in tokens[2:]]
        )

        # Verify the claimed condition itself. Do not require it to be the
        # first available prune: proof generation frequency may defer matching.
        kind = claimed[0]

        if kind == "COMPLETE":
            if len(claimed) != 1:
                raise RuntimeError("bad COMPLETE record")
            valid = (
                not self.unassigned
                and not self.validate_complete_solution()
            )

        elif kind == "CAPACITY":
            if len(claimed) != 1:
                raise RuntimeError("bad CAPACITY record")
            remaining = self.unassigned.bit_count()
            residual = sum(
                CAP - self.cluster_size[c] for c in range(self.used)
            ) + (K - self.used) * CAP
            valid = residual < remaining

        elif kind == "CLUSTER":
            if len(claimed) != 2:
                raise RuntimeError("bad CLUSTER record")
            color = claimed[1]
            valid = False
            if 0 <= color < self.used:
                deficit = CAP - self.cluster_size[color]
                compatible = self.compatible_with_cluster_mask(color)
                valid = (
                    deficit > 0
                    and compatible.bit_count() < deficit
                )

        elif kind == "DOMAIN":
            if len(claimed) != 2:
                raise RuntimeError("bad DOMAIN record")
            vertex = claimed[1]
            valid = (
                0 <= vertex < N
                and bool(self.unassigned & (1 << vertex))
                and not self.legal_colors(vertex)
            )

        elif kind == "MATCHING":
            if len(claimed) != 1:
                raise RuntimeError("bad MATCHING record")
            valid = bool(self.unassigned) and not self.matching_possible()

        else:
            raise RuntimeError(
                "unknown prune reason %r at proof record %d"
                % (kind, self.records)
            )

        if not valid:
            raise RuntimeError(
                "invalid %s prune at proof record %d"
                % (kind, self.records)
            )

    def verify_node(self):
        line = self.get_record()
        tokens = line.split()

        if tokens[0] == "P":
            self.verify_prune(tokens)
            return

        if tokens[0] != "B":
            raise RuntimeError(
                "unknown proof record at record %d: %s"
                % (self.records, line)
            )

        if not self.unassigned:
            raise RuntimeError(
                "branch below complete state at proof record %d"
                % self.records
            )

        # Any cheap deterministic prune should have been represented by P.
        cheap_reason = self.prune_reason(run_matching=False)
        if cheap_reason is not None:
            raise RuntimeError(
                "branch where cheap prune %r is valid at proof record %d"
                % (cheap_reason, self.records)
            )

        if len(tokens) < 3:
            raise RuntimeError(
                "branch has no colors at proof record %d" % self.records
            )

        expected_vertex, expected_legal = self.choose_vertex()
        claimed_vertex = int(tokens[1])
        claimed_legal = [int(token) for token in tokens[2:]]

        if (
            claimed_vertex != expected_vertex
            or claimed_legal != expected_legal
        ):
            raise RuntimeError(
                "branch mismatch at record %d: expected B %d %s; got %s"
                % (
                    self.records,
                    expected_vertex,
                    " ".join(map(str, expected_legal)),
                    line,
                )
            )

        for color in expected_legal:
            is_new = self.put(expected_vertex, color)
            self.verify_node()
            self.undo(expected_vertex, color, is_new)


def solve(args):
    model, t_name, variable_names, adj = recover(
        args.mps, args.threshold
    )
    del model

    metadata = {
        "format": "kauru-canonical-tree-v2",
        "mps_sha256": sha256_file(args.mps),
        "graph_sha256": graph_sha256(adj),
        "threshold": args.threshold,
        "vertices": N,
        "colors": K,
        "capacity": CAP,
        "matching_frequency": args.matching_frequency,
    }

    temporary_proof = args.proof + ".tmp"

    try:
        with open(
            temporary_proof,
            "w",
            buffering=1,
            newline="\n",
        ) as proof_file:
            proof_file.write(
                "# " + json.dumps(metadata, sort_keys=True) + "\n"
            )

            search = CanonicalSearch(
                adj,
                proof_file=proof_file,
                progress_every=args.progress_every,
                matching_frequency=args.matching_frequency,
            )
            feasible = search.dfs()

        elapsed = time.time() - search.started
        print(
            "[search] finished nodes=%d elapsed=%.3fs prunes=%s"
            % (search.nodes, elapsed, search.prune_counts),
            flush=True,
        )

        if feasible:
            os.remove(temporary_proof)
            write_solution(
                args.solution,
                t_name,
                variable_names,
                search.solution,
                args.threshold,
            )
            print(
                "[result] FEASIBLE at threshold",
                repr(args.threshold),
                flush=True,
            )
            print(
                "[result] validate the candidate against the untouched MPS",
                flush=True,
            )
            return 0

        os.replace(temporary_proof, args.proof)
        print(
            "[result] INFEASIBLE by complete canonical search",
            flush=True,
        )
        print("[result] proof:", args.proof, flush=True)
        print(
            "[result] run verify mode before accepting infeasibility",
            flush=True,
        )
        return 0

    except BaseException:
        # A partial proof must never be mistaken for a finished certificate.
        if os.path.exists(temporary_proof):
            print(
                "[result] interrupted; partial proof retained only as:",
                temporary_proof,
                flush=True,
            )
        raise


def verify(args):
    model, _, _, adj = recover(args.mps, args.threshold)
    del model

    with open(args.proof, "r", newline="") as proof_file:
        header = proof_file.readline()
        if not header.startswith("# "):
            raise RuntimeError("missing proof metadata header")

        metadata = json.loads(header[2:])

        expected = {
            "format": "kauru-canonical-tree-v2",
            "mps_sha256": sha256_file(args.mps),
            "graph_sha256": graph_sha256(adj),
            "threshold": args.threshold,
            "vertices": N,
            "colors": K,
            "capacity": CAP,
        }

        for key, value in expected.items():
            if metadata.get(key) != value:
                raise RuntimeError(
                    "proof metadata mismatch for %s: expected %r, got %r"
                    % (key, value, metadata.get(key))
                )

        verifier = ProofVerifier(adj, proof_file)
        verifier.verify_node()

        trailing = proof_file.read().strip()
        if trailing:
            raise RuntimeError(
                "trailing data after complete proof tree"
            )

    print(
        "[verify] VALID complete infeasibility proof",
        flush=True,
    )
    print(
        "[verify] no partition into 25 independent sets of size 7 exists "
        "at threshold",
        repr(args.threshold),
        flush=True,
    )
    return 0


def main():
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="mode", required=True)

    solve_parser = subparsers.add_parser("solve")
    solve_parser.add_argument("mps")
    solve_parser.add_argument(
        "--threshold",
        type=float,
        default=DEFAULT_THRESHOLD,
    )
    solve_parser.add_argument(
        "--proof",
        default="kauru_unsat.proof",
    )
    solve_parser.add_argument(
        "--solution",
        default="kauru_candidate.sol",
    )
    solve_parser.add_argument(
        "--progress-every",
        type=int,
        default=100000,
    )
    solve_parser.add_argument(
        "--matching-frequency",
        type=int,
        default=1,
        help=(
            "run the exact residual b-matching prune every this many nodes; "
            "1 is strongest and deterministic"
        ),
    )

    verify_parser = subparsers.add_parser("verify")
    verify_parser.add_argument("mps")
    verify_parser.add_argument("proof")
    verify_parser.add_argument(
        "--threshold",
        type=float,
        default=DEFAULT_THRESHOLD,
    )

    args = parser.parse_args()

    if args.mode == "solve":
        return solve(args)
    return verify(args)


if __name__ == "__main__":
    sys.exit(main())
