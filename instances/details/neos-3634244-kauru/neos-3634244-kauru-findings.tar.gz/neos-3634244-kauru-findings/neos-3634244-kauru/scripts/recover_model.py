"""Recover the compact combinatorial structure of neos-3634244-kauru.

The script reads the original MPS but never optimizes it.  It verifies the row
pattern, reconstructs the 175-by-25 assignment matrix, and exports the directed
pair costs underlying the epigraph rows.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import gurobipy as gp


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("mps", type=Path)
    ap.add_argument("out", type=Path)
    args = ap.parse_args()

    env = gp.Env(empty=True)
    env.setParam("OutputFlag", 0)
    env.start()
    m = gp.read(str(args.mps), env)
    vars_ = m.getVars()
    cons = m.getConstrs()

    t = vars_[0]
    xvars = vars_[1:]
    assert len(xvars) == 175 * 25
    x_index = {v.index: divmod(k, 25) for k, v in enumerate(xvars)}

    assignment_rows: list[dict] = []
    capacity_rows: list[dict] = []
    epigraph_rows: list[dict] = []
    malformed: list[str] = []
    costs: dict[tuple[int, int], float] = {}
    cluster_consistent = True

    for c in cons:
        row = m.getRow(c)
        terms = [(row.getVar(k), row.getCoeff(k)) for k in range(row.size())]
        if c.Sense == "=" and row.size() == 25:
            indices = [x_index[v.index] for v, a in terms]
            assignment_rows.append(
                {"name": c.ConstrName, "rhs": c.RHS, "indices": indices}
            )
        elif c.Sense == "<" and row.size() == 175 and all(v.index != t.index for v, a in terms):
            indices = [x_index[v.index] for v, a in terms]
            capacity_rows.append(
                {"name": c.ConstrName, "rhs": c.RHS, "indices": indices}
            )
        elif c.Sense == "<" and row.size() == 3 and any(v.index == t.index for v, a in terms):
            tcoef = next(a for v, a in terms if v.index == t.index)
            bins = [(x_index[v.index], a) for v, a in terms if v.index != t.index]
            if len(bins) != 2:
                malformed.append(c.ConstrName)
                continue
            (i, k1), a1 = bins[0]
            (j, k2), a2 = bins[1]
            cluster_consistent &= k1 == k2
            if abs(tcoef + 1.0) > 1e-10 or abs(a1 - a2) > 1e-8 or abs(c.RHS - a1) > 1e-8:
                malformed.append(c.ConstrName)
            costs[(i, j)] = float(max(a1, costs.get((i, j), float("-inf"))))
            epigraph_rows.append(
                {"name": c.ConstrName, "i": i, "j": j, "cluster": k1, "cost": a1}
            )
        else:
            malformed.append(c.ConstrName)

    assignment_ok = (
        len(assignment_rows) == 175
        and all(abs(r["rhs"] - 1.0) <= 1e-10 for r in assignment_rows)
        and all(len({i for i, k in r["indices"]}) == 1 for r in assignment_rows)
        and {next(iter({i for i, k in r["indices"]})) for r in assignment_rows} == set(range(175))
    )
    capacity_ok = (
        len(capacity_rows) == 25
        and all(abs(r["rhs"] - 7.0) <= 1e-10 for r in capacity_rows)
        and all(len({k for i, k in r["indices"]}) == 1 for r in capacity_rows)
        and {next(iter({k for i, k in r["indices"]})) for r in capacity_rows} == set(range(25))
    )
    values = sorted(set(costs.values()))
    payload = {
        "source": str(args.mps),
        "entities": 175,
        "clusters": 25,
        "cluster_capacity": 7,
        "assignment_rows": len(assignment_rows),
        "capacity_rows": len(capacity_rows),
        "epigraph_rows": len(epigraph_rows),
        "directed_pairs": len(costs),
        "distinct_costs": len(values),
        "cost_min": values[0],
        "cost_max": values[-1],
        "assignment_pattern_verified": assignment_ok,
        "capacity_pattern_verified": capacity_ok,
        "same_cluster_index_in_epigraph_rows": cluster_consistent,
        "malformed_rows": malformed[:100],
        "interpretation": (
            "Partition 175 entities into 25 labelled clusters of exactly 7. "
            "Minimize the maximum directed pair cost among entities assigned "
            "to the same cluster. At a threshold T, an unordered pair is "
            "incompatible if either directed cost exceeds T; feasibility is "
            "a capacitated 25-coloring/equal-size independent-set partition."
        ),
        "directed_costs": [
            {"i": i, "j": j, "cost": value}
            for (i, j), value in sorted(costs.items())
        ],
        "distinct_cost_values": values,
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
