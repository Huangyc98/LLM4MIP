"""Round the official near-integral solution and raise its epigraph value.

The output is intentionally complete so an independent original-MPS checker
can reproduce the feasibility result without relying on defaults.
"""
from __future__ import annotations

import argparse
import gzip
from pathlib import Path

import gurobipy as gp


def read_values(path: Path) -> dict[str, float]:
    values: dict[str, float] = {}
    with gzip.open(path, "rt", encoding="utf-8", errors="replace") as handle:
        for line in handle:
            parts = line.split()
            if len(parts) >= 2:
                try:
                    values[parts[0]] = float(parts[1])
                except ValueError:
                    pass
    return values


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--mps", type=Path, required=True)
    ap.add_argument("--input", type=Path, required=True)
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--epigraph", type=float, required=True)
    args = ap.parse_args()

    env = gp.Env(empty=True)
    env.setParam("OutputFlag", 0)
    env.start()
    model = gp.read(str(args.mps), env)
    published = read_values(args.input)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8", newline="\n") as out:
        out.write(f"=obj= {args.epigraph:.16g}\n")
        out.write("# Rounded official ID 2 assignment; epigraph raised to exact pair cost.\n")
        for var in model.getVars():
            value = published.get(var.VarName, 0.0)
            if var.VarName == "C0001":
                value = args.epigraph
            elif var.VType in ("B", "I"):
                value = float(round(value))
            out.write(f"{var.VarName} {value:.16g}\n")


if __name__ == "__main__":
    main()
