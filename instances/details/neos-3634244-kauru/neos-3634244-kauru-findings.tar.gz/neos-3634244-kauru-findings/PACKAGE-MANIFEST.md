# Package manifest: neos-3634244-kauru

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 17
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/rounded-public-strict.audit.json`
- `logs/effort_ledger.json`
- `logs/run-summary.md`
- `reports/final_report.md`
- `scripts/kauru_exact.py`
- `scripts/kauru_exact_v2.py`
- `scripts/kauru_sat.py`
- `scripts/normalize_public_solution.py`
- `scripts/recover_model.py`
- `solutions/public-id1.sol.gz`
- `solutions/public-id2.sol.gz`
- `solutions/rounded-public-strict.sol`
- `sources/background.md`
- `structure/compact_structure.json`
- `structure/gurobi_structure.json`
- `structure/recovered_model.json`

## Excluded files

- `input/neos-3634244-kauru.mps.gz (15573466 bytes; raw benchmark input; sha256 e805d533f2216a6ba683e186b730c517cbd22425f730077d51269ca9c03ad87f)`
