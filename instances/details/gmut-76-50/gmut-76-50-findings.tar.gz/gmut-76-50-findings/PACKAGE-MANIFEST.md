# Package manifest: gmut-76-50

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 24
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/api_local_exchange.json`
- `artifacts/api_spatial_beam.json`
- `artifacts/api_support_difference.json`
- `artifacts/audit_public2_repaired.json`
- `artifacts/audit_public_1.json`
- `artifacts/audit_public_2.json`
- `artifacts/audit_public_2_rounded.json`
- `artifacts/fractional_diagnostics.json`
- `input/gmut-76-50-public-1.sol.gz`
- `input/gmut-76-50-public-2.sol.gz`
- `reports/effort_ledger.md`
- `reports/final_report.md`
- `scripts/api_local_exchange.py`
- `scripts/api_spatial_beam.py`
- `scripts/api_support_difference.py`
- `scripts/forensic_structure.py`
- `scripts/fractional_diagnostics.py`
- `scripts/repair_public_incumbent.py`
- `solutions/public2-rounded-recomputed.sol`
- `sources/official_background.md`
- `structure/compact_structure.json`
- `structure/forensic_structure.json`
- `structure/gurobi_structure.json`

## Excluded files

- `input/gmut-76-50.mps.gz (3035037 bytes; raw benchmark input; sha256 cc5a3eb49c5c896b819424770c19d7e4aba0f31dd89abd170eb9bafce047aede)`
