"""Round the public near-integral incumbent and recompute aggregate H values.

No optimization is performed.  The output is a candidate that must be audited
independently against the original model.
"""
from __future__ import annotations

import argparse
import gzip
import math
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def read_solution(path: Path) -> dict[str, float]:
    values: dict[str, float] = {}
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8", errors="replace") as stream:
        for line in stream:
            if not line.strip() or line.lstrip().startswith("#"):
                continue
            fields = line.split()
            if len(fields) >= 2:
                try:
                    values[fields[0]] = float(fields[1])
                except ValueError:
                    pass
    return values


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", type=Path, required=True)
    parser.add_argument("--solution", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    environment = gp.Env(empty=True)
    environment.setParam("OutputFlag", 0)
    environment.start()
    model = gp.read(str(args.mps), environment)
    source = read_solution(args.solution)
    values: dict[str, float] = {}
    for var in model.getVars():
        value = source.get(var.VarName, 0.0)
        if var.VType in (GRB.BINARY, GRB.INTEGER, GRB.SEMIINT):
            value = float(round(value))
        values[var.VarName] = value

    # Each Sawti_H row is sum(volume*x) - H_t = 0.  Derive H_t from the
    # rounded discrete choices rather than carrying over an inconsistent
    # floating-point aggregate from the public file.
    for period in range(1, 7):
        row = model.getConstrByName(f"Sawti_H{period}")
        expression = model.getRow(row)
        h_name = f"H_{period}"
        other = math.fsum(
            expression.getCoeff(pos) * values[expression.getVar(pos).VarName]
            for pos in range(expression.size())
            if expression.getVar(pos).VarName != h_name
        )
        h_coeff = next(
            expression.getCoeff(pos)
            for pos in range(expression.size())
            if expression.getVar(pos).VarName == h_name
        )
        values[h_name] = -other / h_coeff

    objective = model.ObjCon + math.fsum(var.Obj * values[var.VarName] for var in model.getVars())
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8", newline="\n") as stream:
        stream.write(f"# Objective value = {objective:.15g}\n")
        for var in model.getVars():
            value = values[var.VarName]
            if abs(value) > 1e-15:
                stream.write(f"{var.VarName} {value:.17g}\n")
    print(f"objective={objective:.15g}")
    print(f"nonzero_entries={sum(abs(value) > 1e-15 for value in values.values())}")


if __name__ == "__main__":
    main()
