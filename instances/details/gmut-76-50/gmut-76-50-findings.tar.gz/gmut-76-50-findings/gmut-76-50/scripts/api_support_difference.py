#!/usr/bin/env python3
"""
Exact support-difference and ejection-chain analysis.

Usage:
    python support_difference.py \
        gmut-76-50.mps \
        solution1.sol \
        solution2.sol.gz \
        support_difference.json

The .sol files are parsed directly as Gurobi XML solution files.
No Gurobi optimization is called.

The analysis:
  1. rounds x variables in both solutions;
  2. computes the symmetric support difference;
  3. builds connected components through shared AA/Adj/other rows;
  4. computes objective, harvest, age, and row effects;
  5. tests the complete rounded solution-2 support;
  6. exactly enumerates subsets of small support-difference components;
  7. reports bounded feasible partial exchanges.

The exact component enumeration is deliberately bounded. It never copies a
68,865-entry assignment and never rescans all 470,045 nonzeros per candidate.
"""

import sys
import os
import json
import gzip
import math
import itertools
import xml.etree.ElementTree as ET
from collections import defaultdict, deque

import gurobipy as gp
from gurobipy import GRB


# ----------------------------- configuration -----------------------------

ROUND_TOL = 2.0e-5
FEAS_TOL = 1.0e-7
MAX_COMPONENT_EXACT = 18
MAX_COMPONENT_CANDIDATES = 40
MAX_COMPONENTS_OUTPUT = 80
MAX_DIFF_OUTPUT = 250
MAX_ROW_OUTPUT = 100
MAX_FEASIBLE_OUTPUT = 100


# ----------------------------- solution parsing ---------------------------

def read_solution(path):
    """
    Read a Gurobi .sol XML file, optionally gzip-compressed.

    Returns:
        dict variable_name -> float
    """
    if path.endswith(".gz"):
        with gzip.open(path, "rb") as f:
            data = f.read()
    else:
        with open(path, "rb") as f:
            data = f.read()

    # Standard Gurobi .sol format is XML:
    # <variable name="x..." value="..."/>
    try:
        root = ET.fromstring(data)
        ans = {}
        for elem in root.iter():
            name = elem.attrib.get("name")
            value = elem.attrib.get("value")
            if name is not None and value is not None:
                try:
                    ans[name] = float(value)
                except ValueError:
                    pass
        if ans:
            return ans
    except ET.ParseError:
        pass

    # Conservative fallback for simple whitespace solution formats.
    ans = {}
    text = data.decode("utf-8", errors="replace")
    for line in text.splitlines():
        tok = line.strip().replace(",", " ").split()
        if len(tok) >= 2:
            try:
                ans[tok[0]] = float(tok[1])
            except ValueError:
                continue
    return ans


def parse_x(name):
    if not name.startswith("x") or "_" not in name:
        return None
    try:
        a, t = name[1:].rsplit("_", 1)
        return int(a), int(t)
    except Exception:
        return None


def is_x(v):
    return parse_x(v.VarName) is not None


# ----------------------------- model utilities ----------------------------

def row_violation(sense, lhs, rhs):
    if sense == GRB.LESS_EQUAL:
        return max(0.0, lhs - rhs)
    if sense == GRB.GREATER_EQUAL:
        return max(0.0, rhs - lhs)
    if sense == GRB.EQUAL:
        return abs(lhs - rhs)
    return float("inf")


def main():
    if len(sys.argv) != 5:
        print(
            "usage: support_difference.py instance.mps sol1.sol "
            "sol2.sol[.gz] output.json",
            file=sys.stderr,
        )
        sys.exit(2)

    mps_path, sol1_path, sol2_path, out_path = sys.argv[1:]

    sol1 = read_solution(sol1_path)
    sol2 = read_solution(sol2_path)

    env = gp.Env(empty=True)
    env.setParam("OutputFlag", 0)
    env.start()

    # Parsing only. No optimize().
    model = gp.read(mps_path, env=env)

    variables = model.getVars()
    constraints = model.getConstrs()

    var_by_name = {v.VarName: v for v in variables}
    row_by_name = {r.ConstrName: r for r in constraints}

    # Sparse incidence is built once.
    col_rows = defaultdict(list)       # variable -> [(row, coefficient)]
    row_cols = defaultdict(list)       # row -> [(variable, coefficient)]

    for v in variables:
        col = model.getCol(v)
        for pos in range(col.size()):
            r = col.getConstr(pos)
            c = col.getCoeff(pos)
            rn = r.ConstrName
            cc = float(c)
            col_rows[v.VarName].append((rn, cc))
            row_cols[rn].append((v.VarName, cc))

    # Values needed only for x support and for baseline row/objective data.
    # No complete copied assignment is maintained.
    value1 = defaultdict(float, sol1)
    value2 = defaultdict(float, sol2)

    x_names = [v.VarName for v in variables if is_x(v)]

    support1 = set()
    support2 = set()

    near_integral_2 = []
    for n in x_names:
        a = value1[n]
        b = value2[n]
        r1 = 1 if a >= 0.5 else 0
        r2 = 1 if b >= 0.5 else 0

        if 0.0 < abs(b - round(b)) <= ROUND_TOL:
            near_integral_2.append({
                "name": n,
                "value_solution2": b,
                "rounded": int(round(b)),
                "distance_to_integer": abs(b - round(b)),
            })

        if r1:
            support1.add(n)
        if r2:
            support2.add(n)

    additions = sorted(support2 - support1)
    removals = sorted(support1 - support2)

    # Each support-difference column has a prescribed delta relative to sol1.
    # +1 means add it; -1 means remove it.
    diff_names = removals + additions
    prescribed_delta = {}
    for n in removals:
        prescribed_delta[n] = -1.0
    for n in additions:
        prescribed_delta[n] = +1.0

    # Baseline row lhs for solution 1 is computed once.
    # This is the only full row/nonzero evaluation.
    base_lhs = {}
    for r in constraints:
        lhs = 0.0
        for n, c in row_cols[r.ConstrName]:
            lhs += c * value1[n]
        base_lhs[r.ConstrName] = lhs

    base_obj = 0.0
    for v in variables:
        base_obj += float(v.Obj) * value1[v.VarName]

    # H coefficients and Sawti rows. H is reconstructed from x changes.
    h_names = {f"H_{t}" for t in range(1, 7)}
    h_row_for_t = {t: f"Sawti_H{t}" for t in range(1, 7)}
    h_coeff = {}
    harvest_coeff = defaultdict(dict)  # t -> xname -> coefficient

    for t in range(1, 7):
        rn = h_row_for_t[t]
        for n, c in row_cols.get(rn, []):
            if n == f"H_{t}":
                h_coeff[t] = c
            else:
                p = parse_x(n)
                if p is not None:
                    harvest_coeff[t][n] = c

    # Effect of each support-difference move on every affected row.
    #
    # A move changes one x by +/-1 and changes H_t exactly enough to preserve
    # Sawti_Ht. We incorporate the induced H_t effect into every row containing
    # H_t. Thus candidate evaluation touches only rows affected by the move.
    move_effect = {}
    move_rows = {}

    for n in diff_names:
        dx = prescribed_delta[n]
        effects = defaultdict(float)

        for rn, c in col_rows[n]:
            effects[rn] += dx * c

        p = parse_x(n)
        if p is not None:
            t = p[1]
            if t in h_coeff and h_coeff[t] != 0.0:
                dh = -(harvest_coeff[t].get(n, 0.0) * dx) / h_coeff[t]

                hn = f"H_{t}"
                for rn, c in col_rows.get(hn, []):
                    effects[rn] += dh * c

                # Store explicit harvest delta for reporting.
                effects[f"__DH_{t}"] += dh

        # Remove numerical zeros.
        clean = {
            rn: val for rn, val in effects.items()
            if abs(val) > 1.0e-12
        }
        move_effect[n] = clean
        move_rows[n] = {
            rn for rn in clean
            if not rn.startswith("__DH_")
        }

    # Build the support-difference conflict graph.
    # Two moves are adjacent if they affect a common original row.
    row_to_diff = defaultdict(list)
    for n in diff_names:
        for rn in move_rows[n]:
            row_to_diff[rn].append(n)

    graph = {n: set() for n in diff_names}
    for rn, names in row_to_diff.items():
        for a, b in itertools.combinations(names, 2):
            graph[a].add(b)
            graph[b].add(a)

    components = []
    unseen = set(diff_names)
    while unseen:
        root = next(iter(unseen))
        unseen.remove(root)
        comp = []
        q = deque([root])
        while q:
            n = q.popleft()
            comp.append(n)
            for z in graph[n]:
                if z in unseen:
                    unseen.remove(z)
                    q.append(z)
        components.append(sorted(comp))

    components.sort(key=lambda c: (-len(c), c))

    def metadata(names):
        units = set()
        adjs = set()
        rows = set()
        for n in names:
            for rn in move_rows[n]:
                rows.add(rn)
                if rn.startswith("AA_"):
                    units.add(rn)
                elif rn.startswith("Adj_"):
                    adjs.add(rn)
        return sorted(units), sorted(adjs), sorted(rows)

    def aggregate_effect(names):
        """
        Aggregate sparse row effects and harvest deltas.
        Only affected rows are visited.
        """
        eff = defaultdict(float)
        dh = {f"H_{t}": 0.0 for t in range(1, 7)}
        obj_delta = 0.0

        for n in names:
            obj_delta += float(var_by_name[n].Obj) * prescribed_delta[n]
            for rn, val in move_effect[n].items():
                if rn.startswith("__DH_"):
                    t = int(rn.split("_")[-1])
                    dh[f"H_{t}"] += val
                else:
                    eff[rn] += val

        return eff, dh, obj_delta

    def check_effect(eff):
        """
        Check only rows affected by this exchange.

        All unaffected rows equal their feasible solution-1 values.
        """
        bad = []
        for rn, delta in eff.items():
            r = row_by_name[rn]
            lhs = base_lhs[rn] + delta
            viol = row_violation(r.Sense, lhs, float(r.RHS))
            if viol > FEAS_TOL:
                bad.append({
                    "row": rn,
                    "lhs": lhs,
                    "rhs": float(r.RHS),
                    "sense": r.Sense,
                    "violation": viol,
                })
        return bad

    def flow_slacks(dh):
        out = {}
        # H values in solution 1 are taken from the supplied solution.
        hs = {t: value1[f"H_{t}"] for t in range(1, 7)}
        for t in range(1, 7):
            hs[t] += dh[f"H_{t}"]

        for t in range(1, 6):
            out[f"Flct_{t}"] = {
                "lower_slack": hs[t + 1] - 0.95 * hs[t],
                "upper_slack": 1.10 * hs[t] - hs[t + 1],
            }
        return hs, out

    def summarize_exchange(names, include_columns=True):
        eff, dh, dobj = aggregate_effect(names)
        bad = check_effect(eff)
        hs, fs = flow_slacks(dh)
        units, adjs, affected = metadata(names)

        result = {
            "columns": list(names) if include_columns else len(names),
            "affected_base_units": units,
            "affected_adjacency_rows": adjs,
            "affected_row_count": len(affected),
            "harvest_deltas": dh,
            "new_H": hs,
            "flow_slacks": fs,
            "objective_delta": dobj,
            "new_objective": base_obj + dobj,
            "feasible_against_original_rows": not bad,
            "max_reported_violation": (
                max((z["violation"] for z in bad), default=0.0)
            ),
            "bad_rows": bad[:MAX_ROW_OUTPUT],
        }
        return result

    # Complete rounded support-2 target.
    full_target = summarize_exchange(diff_names)

    # Exact bounded enumeration for small connected components.
    component_results = []
    feasible_partial = []

    for cid, comp in enumerate(components[:MAX_COMPONENTS_OUTPUT]):
        record = {
            "component_id": cid,
            "size": len(comp),
            "columns": comp[:MAX_DIFF_OUTPUT],
            "exact_enumeration": len(comp) <= MAX_COMPONENT_EXACT,
            "candidate_count": 0,
            "best_feasible": [],
        }

        if len(comp) <= MAX_COMPONENT_EXACT:
            local = []
            # Exclude the empty subset: it is just solution 1.
            for k in range(1, len(comp) + 1):
                for subset in itertools.combinations(comp, k):
                    record["candidate_count"] += 1
                    ans = summarize_exchange(list(subset))
                    ans["component_id"] = cid
                    local.append(ans)

            feasible = [
                z for z in local
                if z["feasible_against_original_rows"]
            ]
            feasible.sort(key=lambda z: (
                z["objective_delta"],
                -z["flow_slacks"]["Flct_1"]["lower_slack"],
                len(z["columns"]),
            ))
            record["best_feasible"] = feasible[:MAX_COMPONENT_CANDIDATES]
            feasible_partial.extend(feasible[:MAX_COMPONENT_CANDIDATES])
        else:
            # For a large component, enumerate only singleton moves. This is
            # diagnostic, not a claim of exactness.
            record["exact_enumeration"] = False
            for n in comp[:MAX_COMPONENT_CANDIDATES]:
                record["candidate_count"] += 1
                ans = summarize_exchange([n])
                ans["component_id"] = cid
                if ans["feasible_against_original_rows"]:
                    record["best_feasible"].append(ans)

        component_results.append(record)

    feasible_partial.sort(key=lambda z: (
        z["objective_delta"],
        -z["flow_slacks"]["Flct_1"]["lower_slack"],
        len(z["columns"]),
    ))

    # Compact per-column summaries for the symmetric difference.
    diff_summary = []
    for n in diff_names[:MAX_DIFF_OUTPUT]:
        p = parse_x(n)
        eff, dh, dobj = aggregate_effect([n])
        units, adjs, affected = metadata([n])
        diff_summary.append({
            "name": n,
            "direction_relative_to_solution1": (
                "remove" if prescribed_delta[n] < 0 else "add"
            ),
            "configuration_id": p[0] if p else None,
            "period": p[1] if p else None,
            "objective_delta": dobj,
            "harvest_deltas": dh,
            "affected_base_units": units,
            "affected_adjacency_rows": adjs,
            "affected_row_count": len(affected),
        })

    # Geometric-chain diagnostics based on solution 1 H values.
    h1 = [value1[f"H_{t}"] for t in range(1, 7)]
    lower_slacks = [
        h1[t] - 0.95 * h1[t - 1] for t in range(1, 6)
    ]
    ratios = [
        h1[t] / h1[t - 1] if h1[t - 1] else None
        for t in range(1, 6)
    ]

    # A falsifiable method-selection signal.
    # Small components plus feasible improving partial exchanges imply that
    # component ejection chains are promising. Otherwise the spatial graph
    # and projected clique route becomes the next experiment.
    small_components = [
        c for c in components if len(c) <= MAX_COMPONENT_EXACT
    ]
    improving_feasible = [
        z for z in feasible_partial if z["objective_delta"] < -1.0e-6
    ]

    if improving_feasible:
        next_method = (
            "continue_component_ejection_chains: "
            "a feasible improving support-difference exchange exists"
        )
    elif small_components and len(components) <= 25:
        next_method = (
            "expand_exact_temporal_ejection_chains: "
            "support difference is localized but no improving partial "
            "exchange was found"
        )
    else:
        next_method = (
            "switch_to_spatial_graph_projection_and_clique_separation: "
            "support difference is too broad or not locally repairable"
        )

    output = {
        "model_shape": {
            "rows": model.NumConstrs,
            "columns": model.NumVars,
            "nonzeros": model.NumNZs,
        },
        "solutions": {
            "solution1_path": sol1_path,
            "solution2_path": sol2_path,
            "solution1_variables_read": len(sol1),
            "solution2_variables_read": len(sol2),
        },
        "solution1_objective_from_file_values": base_obj,
        "support_sizes": {
            "solution1_rounded_x_support": len(support1),
            "solution2_rounded_x_support": len(support2),
            "additions_solution2_minus_solution1": len(additions),
            "removals_solution1_minus_solution2": len(removals),
            "symmetric_difference": len(diff_names),
        },
        "solution2_near_integral_variables": {
            "count": len(near_integral_2),
            "examples": near_integral_2[:MAX_DIFF_OUTPUT],
        },
        "solution1_H": h1,
        "solution1_flow_lower_slacks": lower_slacks,
        "solution1_successive_H_ratios": ratios,
        "complete_rounded_solution2_support": full_target,
        "support_difference_columns": diff_summary,
        "components": component_results[:MAX_COMPONENTS_OUTPUT],
        "best_feasible_partial_exchanges": feasible_partial[
            :MAX_FEASIBLE_OUTPUT
        ],
        "decision": {
            "small_component_count": len(small_components),
            "component_count": len(components),
            "improving_feasible_partial_exchange_count": len(
                improving_feasible
            ),
            "next_method": next_method,
            "falsification_rule": (
                "If no feasible improving partial exchange is reported and "
                "the support difference has large components, abandon local "
                "support ejection as the primary route and recover the "
                "300-unit spatial conflict graph for projected clique/path "
                "cuts. If a feasible improving exchange is reported, "
                "continue exact component ejection chains."
            ),
        },
    }

    with open(out_path, "w") as f:
        json.dump(output, f, indent=2, sort_keys=True)

    print(json.dumps({
        "output": out_path,
        "symmetric_difference": len(diff_names),
        "components": len(components),
        "small_components": len(small_components),
        "rounded_solution2_feasible": (
            full_target["feasible_against_original_rows"]
        ),
        "best_partial_objective_delta": (
            feasible_partial[0]["objective_delta"]
            if feasible_partial else None
        ),
        "next_method": next_method,
    }, indent=2))


if __name__ == "__main__":
    main()
