#!/usr/bin/env python3
"""
Local exact exchange analysis for MIPLIB gmut-76-50.

Usage:
    python local_exchange.py instance.mps solution2.sol.gz exchanges.json

solution2.json must be a JSON object:
    {"x1942_2": 0.999990498675, ..., "H_1": 1234.5, ...}

The script uses gurobipy only for MPS reading and row/column inspection.
It never calls Model.optimize().
"""

import sys
import json
import itertools
import math
import gzip
from collections import defaultdict

import gurobipy as gp
from gurobipy import GRB


# The supplied fractional diagnostic.
DIAG = [
    ("x51_2", 0, 51, 2),
    ("x183_2", 0, 183, 2),
    ("x183_4", 1, 183, 4),
    ("x198_2", 1, 198, 2),
    ("x198_3", 0, 198, 3),
    ("x206_1", 0, 206, 1),
    ("x1942_2", 1, 1942, 2),
    ("x2590_1", 1, 2590, 1),
    ("x2590_2", 0, 2590, 2),
    ("x2816_2", 0, 2816, 2),
    ("x2816_3", 1, 2816, 3),
]

MAX_POOL = 12
MAX_EXCHANGES = 3000
MAX_OUTPUT = 60
TOL = 1e-7
FEAS_TOL = 1e-6


def is_x(v):
    return v.VarName.startswith("x") and "_" in v.VarName


def parse_x_name(name):
    # Expected format x<i>_<t>
    if not name.startswith("x"):
        return None
    try:
        left, right = name[1:].rsplit("_", 1)
        return int(left), int(right)
    except Exception:
        return None


def row_violation(row, lhs):
    """Violation of a MIP row, using the original sense and RHS."""
    rhs = row.RHS
    if row.Sense == GRB.LESS_EQUAL:
        return max(0.0, lhs - rhs)
    if row.Sense == GRB.GREATER_EQUAL:
        return max(0.0, rhs - lhs)
    if row.Sense == GRB.EQUAL:
        return abs(lhs - rhs)
    return float("inf")


def main():
    if len(sys.argv) != 4:
        print("usage: local_exchange.py instance.mps solution2.sol.gz output.json",
              file=sys.stderr)
        sys.exit(2)

    mps_path = sys.argv[1]
    sol_path = sys.argv[2]
    output_path = sys.argv[3]

    if sol_path.endswith(".json"):
        with open(sol_path, "r", encoding="utf-8") as f:
            supplied = json.load(f)
    else:
        supplied = {}
        opener = gzip.open if sol_path.endswith(".gz") else open
        with opener(sol_path, "rt", encoding="utf-8", errors="replace") as f:
            for line in f:
                fields = line.split()
                if len(fields) >= 2 and not fields[0].startswith("#"):
                    try:
                        supplied[fields[0]] = float(fields[1])
                    except ValueError:
                        pass

    env = gp.Env(empty=True)
    env.setParam("OutputFlag", 0)
    env.start()

    model = gp.read(mps_path, env=env)

    # Name maps and sparse column representation.
    vars_by_name = {v.VarName: v for v in model.getVars()}
    rows = model.getConstrs()
    row_index = {r.ConstrName: i for i, r in enumerate(rows)}

    col_rows = defaultdict(list)
    row_cols = defaultdict(list)

    for v in model.getVars():
        column = model.getCol(v)
        for pos in range(column.size()):
            r = column.getConstr(pos)
            coef = column.getCoeff(pos)
            col_rows[v.VarName].append((r.ConstrName, float(coef)))
            row_cols[r.ConstrName].append((v.VarName, float(coef)))

    # Use supplied values, defaulting missing variables to zero.
    raw = {}
    for v in model.getVars():
        val = supplied.get(v.VarName, 0.0)
        try:
            raw[v.VarName] = float(val)
        except Exception:
            raw[v.VarName] = 0.0

    # Rounded incumbent: x variables are binary; all other variables initially
    # retain supplied values and are then reconstructed when appropriate.
    incumbent = dict(raw)
    for v in model.getVars():
        if is_x(v):
            incumbent[v.VarName] = 1.0 if raw[v.VarName] >= 0.5 else 0.0

    def reconstruct_h(values):
        """
        Reconstruct H_t from Sawti_Ht equality rows:
            sum harvest_coeff*x + coeff_H*H_t = RHS.
        """
        out = dict(values)
        for t in range(1, 7):
            rn = "Sawti_H%d" % t
            if rn not in row_index:
                continue
            terms = row_cols[rn]
            hterms = [(n, c) for n, c in terms if n == "H_%d" % t]
            if not hterms:
                continue
            hname, hcoef = hterms[0]
            fixed = 0.0
            for n, c in terms:
                if n != hname:
                    fixed += c * out.get(n, 0.0)
            out[hname] = (model.getConstrByName(rn).RHS - fixed) / hcoef
        return out

    incumbent = reconstruct_h(incumbent)

    def evaluate(values, changed=None, base_objective=None, base_values=None):
        """Check all original rows and variable bounds."""
        values = reconstruct_h(values)
        maxviol = 0.0
        badrows = []

        if changed is None:
            rows_to_check = rows
        else:
            affected_names = {
                *("Sawti_H%d" % t for t in range(1, 7)),
                *("Flct_%d" % k for k in range(1, 11)),
                "_EAge_11",
            }
            for n in changed:
                affected_names.update(rn for rn, _ in col_rows[n])
            for t in range(1, 7):
                affected_names.update(rn for rn, _ in col_rows["H_%d" % t])
            rows_to_check = [model.getConstrByName(name) for name in affected_names]
            rows_to_check = [row for row in rows_to_check if row is not None]

        for r in rows_to_check:
            lhs = 0.0
            for n, c in row_cols[r.ConstrName]:
                lhs += c * values.get(n, 0.0)
            viol = row_violation(r, lhs)
            maxviol = max(maxviol, viol)
            if viol > FEAS_TOL:
                badrows.append({
                    "row": r.ConstrName,
                    "sense": r.Sense,
                    "rhs": float(r.RHS),
                    "lhs": lhs,
                    "violation": viol
                })

        badbounds = []
        vars_to_check = model.getVars() if changed is None else [vars_by_name[n] for n in changed] + [vars_by_name["H_%d" % t] for t in range(1, 7)]
        for v in vars_to_check:
            val = values.get(v.VarName, 0.0)
            if val < v.LB - FEAS_TOL or val > v.UB + FEAS_TOL:
                badbounds.append({
                    "var": v.VarName,
                    "value": val,
                    "lb": float(v.LB),
                    "ub": float(v.UB)
                })
            if v.VType in (GRB.BINARY, GRB.INTEGER):
                if abs(val - round(val)) > FEAS_TOL:
                    badbounds.append({
                        "var": v.VarName,
                        "value": val,
                        "integrality_violation": abs(val - round(val))
                    })

        if changed is None:
            obj = sum(v.Obj * values.get(v.VarName, 0.0) for v in model.getVars())
        else:
            obj = base_objective + sum(
                vars_by_name[n].Obj * (values.get(n, 0.0) - base_values.get(n, 0.0))
                for n in changed
            )

        return {
            "feasible": (not badrows and not badbounds),
            "objective": obj,
            "max_row_violation": maxviol,
            "bad_rows": badrows[:25],
            "bad_bounds": badbounds[:25],
            "values": values,
        }

    base_eval = evaluate(incumbent)
    base = base_eval["values"]

    # Diagnostic names that exist in the MPS.
    diag_names = [n for n, _, _, _ in DIAG if n in vars_by_name]

    # Seed neighborhood by rows occupied by diagnostic variables.
    seed_rows = set()
    for n in diag_names:
        for rn, _ in col_rows[n]:
            if rn.startswith("AA_") or rn.startswith("Adj_"):
                seed_rows.add(rn)

    # Candidate pool: variables sharing a diagnostic AA/Adj row, plus all
    # temporal alternatives of the same configuration IDs.
    candidate_names = set(diag_names)
    for rn in seed_rows:
        for n, _ in row_cols[rn]:
            if n in vars_by_name and is_x(vars_by_name[n]):
                candidate_names.add(n)

    ids = set()
    for n in diag_names:
        p = parse_x_name(n)
        if p:
            ids.add(p[0])

    for v in model.getVars():
        p = parse_x_name(v.VarName)
        if p and p[0] in ids:
            candidate_names.add(v.VarName)

    # Split and rank candidates. Keep the pool bounded.
    selected = []
    additions = []

    for n in candidate_names:
        if n not in vars_by_name:
            continue
        v = vars_by_name[n]
        if not is_x(v):
            continue
        val = base.get(n, 0.0)
        # Objective is minimization: more negative is generally attractive.
        score = (abs(v.Obj), -v.Obj, n)
        if val >= 0.5:
            selected.append((score, n))
        else:
            additions.append((score, n))

    selected.sort()
    additions.sort()
    selected = [n for _, n in selected[:MAX_POOL]]
    additions = [n for _, n in additions[:MAX_POOL]]

    # Ensure all diagnostic selected columns are retained.
    for n in diag_names:
        if base.get(n, 0.0) >= 0.5 and n not in selected:
            selected.append(n)
        if base.get(n, 0.0) < 0.5 and n not in additions:
            additions.append(n)

    def changed_metadata(changed):
        units = set()
        adjs = set()
        for n in changed:
            for rn, c in col_rows[n]:
                if rn.startswith("AA_"):
                    units.add(rn)
                elif rn.startswith("Adj_"):
                    adjs.add(rn)
        return sorted(units), sorted(adjs)

    def deltas(old, new, changed):
        dh = {}
        for t in range(1, 7):
            hn = "H_%d" % t
            dh[hn] = new.get(hn, 0.0) - old.get(hn, 0.0)

        age_delta = 0.0
        if "_EAge_11" in row_cols:
            for n, c in row_cols["_EAge_11"]:
                age_delta += c * (new.get(n, 0.0) - old.get(n, 0.0))

        obj_delta = 0.0
        for n in changed:
            obj_delta += vars_by_name[n].Obj * (new.get(n, 0.0)
                                                - old.get(n, 0.0))
        flow_slacks = {}
        for t in range(1, 6):
            # For 0.95 H_t <= H_(t+1) <= 1.10 H_t.
            h1 = new.get("H_%d" % t, 0.0)
            h2 = new.get("H_%d" % (t + 1), 0.0)
            flow_slacks["H%d_to_H%d" % (t, t + 1)] = {
                "lower_slack": h2 - 0.95 * h1,
                "upper_slack": 1.10 * h1 - h2
            }
        return dh, age_delta, obj_delta, flow_slacks

    baseline_units, baseline_adjs = changed_metadata(diag_names)

    results = []
    count = 0

    # Enumerate all exchanges with at most three changed x columns.
    # Unequal removal/addition cardinalities are allowed.
    for nr in range(1, 4):
        for na in range(1, 4):
            if nr + na > 3:
                continue
            for rem in itertools.combinations(selected, nr):
                remset = set(rem)
                for add in itertools.combinations(additions, na):
                    addset = set(add)
                    if remset & addset:
                        continue
                    count += 1
                    if count > MAX_EXCHANGES:
                        break

                    new = dict(base)
                    for n in rem:
                        new[n] = 0.0
                    for n in add:
                        new[n] = 1.0

                    changed = list(rem) + list(add)
                    ev = evaluate(
                        new,
                        changed=changed,
                        base_objective=base_eval["objective"],
                        base_values=base,
                    )
                    units, adjs = changed_metadata(changed)
                    dh, dage, dobj, fslack = deltas(base, ev["values"],
                                                    changed)

                    # Rank feasible moves first, then by objective improvement,
                    # then by repair of the first flow inequality.
                    repair = fslack.get("H1_to_H2", {}).get("lower_slack",
                                                            -1e100)
                    rank = (
                        0 if ev["feasible"] else 1,
                        ev["objective"] - base_eval["objective"],
                        -repair,
                        ev["max_row_violation"]
                    )

                    results.append({
                        "rank_key": rank,
                        "remove": list(rem),
                        "add": list(add),
                        "changed_columns": changed,
                        "affected_base_units": units,
                        "affected_adjacency_rows": adjs,
                        "harvest_deltas": dh,
                        "terminal_age_lhs_delta": dage,
                        "objective_delta": dobj,
                        "new_objective": ev["objective"],
                        "h1_h2_lower_slack": repair,
                        "flow_slacks": fslack,
                        "feasible": ev["feasible"],
                        "max_row_violation": ev["max_row_violation"],
                        "bad_rows": ev["bad_rows"][:8],
                    })
                if count > MAX_EXCHANGES:
                    break
            if count > MAX_EXCHANGES:
                break
        if count > MAX_EXCHANGES:
            break

    results.sort(key=lambda z: z["rank_key"])

    # Remove internal ranking keys before JSON emission.
    for z in results:
        z.pop("rank_key", None)

    output = {
        "instance": mps_path,
        "model_shape": {
            "rows": model.NumConstrs,
            "columns": model.NumVars,
            "nonzeros": model.NumNZs
        },
        "diagnostic_columns_found": diag_names,
        "seed_rows": sorted(seed_rows),
        "candidate_pool": {
            "selected_count": len(selected),
            "addition_count": len(additions),
            "selected": selected,
            "additions": additions
        },
        "rounded_incumbent": {
            "objective": base_eval["objective"],
            "feasible": base_eval["feasible"],
            "max_row_violation": base_eval["max_row_violation"],
            "bad_rows": base_eval["bad_rows"][:20],
            "H": {("H_%d" % t): base.get("H_%d" % t, 0.0)
                  for t in range(1, 7)}
        },
        "enumerated_exchange_count": count,
        "returned_exchange_count": min(MAX_OUTPUT, len(results)),
        "exchanges": results[:MAX_OUTPUT]
    }

    rendered = json.dumps(output, indent=2, sort_keys=True)
    with open(output_path, "w", encoding="utf-8", newline="\n") as stream:
        stream.write(rendered + "\n")
    print(json.dumps({
        "output": output_path,
        "enumerated_exchange_count": count,
        "returned_exchange_count": min(MAX_OUTPUT, len(results)),
    }))


if __name__ == "__main__":
    main()
