"""Describe near-integral entries and local repair alternatives without solving."""
from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def read_solution(path: Path) -> dict[str, float]:
    values: dict[str, float] = {}
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8", errors="replace") as stream:
        for line in stream:
            fields = line.split()
            if len(fields) >= 2 and not fields[0].startswith("#"):
                try:
                    values[fields[0]] = float(fields[1])
                except ValueError:
                    pass
    return values


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mps", type=Path, required=True)
    parser.add_argument("--solution", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    environment = gp.Env(empty=True)
    environment.setParam("OutputFlag", 0)
    environment.start()
    model = gp.read(str(args.mps), environment)
    source = read_solution(args.solution)
    fractional = []
    for var in model.getVars():
        value = source.get(var.VarName, 0.0)
        if var.VType not in (GRB.BINARY, GRB.INTEGER, GRB.SEMIINT):
            continue
        if abs(value - round(value)) <= 1e-12:
            continue
        column = model.getCol(var)
        rows = []
        for pos in range(column.size()):
            con = column.getConstr(pos)
            rows.append({"name": con.ConstrName, "coefficient": column.getCoeff(pos)})
        fractional.append(
            {
                "name": var.VarName,
                "value": value,
                "round": round(value),
                "objective": var.Obj,
                "rows": rows,
            }
        )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps({"fractional": fractional}, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"fractional_count": len(fractional), "names": [x["name"] for x in fractional]}, indent=2))


if __name__ == "__main__":
    main()
