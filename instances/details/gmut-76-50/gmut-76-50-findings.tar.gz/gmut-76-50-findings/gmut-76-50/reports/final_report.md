# gmut-76-50: one-hour direct-API research report

## Outcome

The instance was **not solved to proven optimality**, and this study found no
new strict feasible incumbent or global bound.  The best rigorously validated
integer witness available here remains public solution 1, with recomputed
objective **-14,171,397.8275**.  Public solution 2 has the much better reported
objective -14,171,893.7789212 but contains eleven binary values about
`9.5e-6` away from integers.  Its strict rounded support is not feasible.

This negative result is substantive: three different custom structural tests
falsified the tempting hypothesis that the public near-integral incumbent can
be repaired by a small local exchange.  It also identifies an exact,
MPS-derived projection/clique route for future dual-bound work.

## Reproducibility and validation

- Official MPS SHA-256:
  `cc5a3eb49c5c896b819424770c19d7e4aba0f31dd89abd170eb9bafce047aede`.
- Public solution 1 SHA-256:
  `e6dc271a80a40b8699e743ebe5563ebb59ec7ffc0fe58b7a8a2b6d9a904aec08`.
- Public solution 2 SHA-256:
  `645584f97ae7d271ce6c3c186794f5a69fecf9ad462caf79df7b5fdb62395ab1`.
- Gurobi was used only for read-only parsing and independent row/bound/
  integrality audits.  `optimize()` and `presolve()` were never called.
- Generic solver optimization time: **0 minutes**, below the 30-minute cap.
- Research wall-clock: **60 minutes**, from 01:30 through 02:30 UTC+08:00.
- Four successful stateful `gpt-5.6-sol` calls used 75,932 recorded tokens.

The strict audit of public solution 1 found zero bound or integrality
violations and maximum row residual `7.28e-12`.  The audit of public solution 2
reproduced its declared objective but found 11 integrality violations, with
maximum `9.5013e-6`.  Rounding the binaries and exactly recomputing all six
aggregate harvest variables gives objective `-14171893.5117`; the only material
row violation is

```text
Flct_1: 0.95 H_1 - H_2 = 0.06523499998 > 0.
```

Consequently the starred MIPLIB value must not be described as a strict
integer witness in this report.

## Recovered structure

The Gurobi and custom parsers recover a seven-period generalized management
unit (GMU) area-restriction model:

- 9,837 configuration IDs and seven period labels (`0` through `6`);
- 30,459 active integer columns; 38,400 zero-objective, zero-incidence padded
  columns;
- 300 `AA` rows enforcing that each base management unit is used at most once;
- 2,269 period-specific `Adj` packing rows;
- six harvest-volume equalities defining `H_1,...,H_6`;
- ten inequalities enforcing `0.95 H_t <= H_(t+1) <= 1.10 H_t`;
- one terminal area-weighted-age inequality;
- 28,359 active multi-unit configuration-period columns, after excluding the
  2,100 singleton-period columns;
- maximum recovered cluster cardinality seven;
- a 300-node unit co-occurrence graph with 3,326 edges, degree range 4--42, and
  mean degree 22.17.

This agrees with the official forestry description and the ARM/GMU literature.
The co-occurrence graph is not necessarily the primitive geographic adjacency
map; it is only an exact object induced by the submitted formulation.

## Experiments and measured results

### 1. Fractional-cycle and bounded exchange analysis

The eleven fractional entries form recognizable temporal/configuration pairs,
including `x183_2/x183_4`, `x198_2/x198_3`,
`x2590_1/x2590_2`, and `x2816_2/x2816_3`.  An API-designed incremental
enumerator checked 1,035 one-, two-, and three-column exchanges around the
rounded support against all affected original rows.

It found feasible exchanges only with large objective losses.  The best
reported repair removed `x2590_1` and inserted `x160_0`, yielding objective
`-13,996,685.47`, which is much worse than public solution 1.  Attractive
objective exchanges violated base-unit, adjacency, or downstream flow rows.

### 2. Exact support-difference components

The strict integer supports of public solution 1 and rounded public solution 2
differ by 216 columns: 110 additions and 106 removals.  Every one of these
columns lies in a **single conflict-connected component** through the original
rows.  Rounded solution 2 improves the objective over solution 1 by 495.6842,
but remains infeasible by 0.065235 in the first lower-flow constraint.

This falsifies the hypothesis that the better public objective is caused by an
isolated eleven-column numerical cycle.  It is a broad spatial-temporal
reorganization, and no disconnected component can be accepted independently.

### 3. Spatial projection and bounded ejection-chain beam

The final custom script recovered every configuration's base-unit set,
period-specific `Adj` signature, volume, age contribution, and objective.  The
apparent huge duplicate/dominance counts were traced to inactive padded
columns, so they are not reported as valid reductions.  A bounded one-for-one
packing-preserving beam generated 41 spatial candidates but died after two
states and returned no witness.  This implementation is too restrictive to
exclude multi-remove/multi-add repairs; it does show that legal additions
typically require ejecting several incumbent clusters simultaneously.

## Why no optimality claim is possible

There is no strict feasible witness at the starred public objective and no new
strict incumbent better than public solution 1.  More importantly, this study
did not produce a global lower bound matching any witness or a checkable
branch/cut certificate.  A heuristic failure is not a proof, and the fractional
public solution is not automatically a valid lower bound.

## Recommended next work

1. Build the exact conflict graph on active configuration-period columns from
   shared `AA` and `Adj` capacity rows.  Separate maximal cliques that combine
   several original rows.  Add projected unit-period linking rows and valid
   flow-path/cover cuts based on certified residual packing bounds.  The proof
   target is a reproducible lower bound and, eventually, a checkable exhaustive
   tree matching the strict incumbent.
2. For primal work, redesign the ejection search to permit simultaneous
   multi-remove/multi-add moves.  Use label setting or meet-in-the-middle on the
   six-dimensional harvest-delta vector, while maintaining exact packing and
   age residuals.  Seed it with the 216-column support-difference component.

Primitive geographic adjacency, unit areas, the opening threshold, and the
original cluster-generation rule are not uniquely recoverable from the MPS.
They are not required for an exact MPS-equivalent method: configuration
hyperedges, conflicts, matched period rows, and checkable clique/path cuts can
all be derived directly from the submitted coefficients.

## Artifact index

- `structure/gurobi_structure.json`: complete bounded Gurobi structure report.
- `structure/forensic_structure.json`: recovered periods, rows, and incumbent
  supports.
- `artifacts/audit_public_1.json`, `audit_public_2.json`: strict audits.
- `artifacts/fractional_diagnostics.json`: all eleven fractional columns.
- `artifacts/api_local_exchange.json`: 1--3 column exchange results.
- `artifacts/api_support_difference.json`: exact support-component analysis.
- `artifacts/api_spatial_beam.json`: spatial recovery and beam diagnostics.
- `research/api_01.json` through `api_04.json`: stateful API transcripts and
  usage records.
- `scripts/`: all original and API-generated/repaired executable scripts.
- `solutions/public2-rounded-recomputed.sol`: deliberately retained failed
  repair candidate; its audit documents infeasibility and it must not be used
  as an incumbent.
