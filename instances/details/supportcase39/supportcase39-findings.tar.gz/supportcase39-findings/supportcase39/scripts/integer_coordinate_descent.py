#!/usr/bin/env python3
"""Problem-specific exact coordinate descent for supportcase39.

Each move solves the one-control integer subproblem analytically from the
current row slacks.  Decimal arithmetic is used throughout, so a reported
move is feasible for the serialized MPS rather than only for an idealized
Gaussian kernel.
"""

from __future__ import annotations

import argparse
import gzip
import random
from collections import defaultdict
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR, getcontext
from pathlib import Path


getcontext().prec = 60


def open_text(path: Path):
    if path.suffix == ".gz":
        return gzip.open(path, "rt", encoding="latin-1")
    return path.open("rt", encoding="latin-1")


def parse_mps(path: Path):
    section = None
    row_type: dict[str, str] = {}
    rhs: dict[str, Decimal] = defaultdict(Decimal)
    obj: dict[str, Decimal] = defaultdict(Decimal)
    cols: dict[str, list[tuple[str, Decimal]]] = defaultdict(list)
    lower: dict[str, int] = defaultdict(int)
    upper: dict[str, int] = defaultdict(lambda: 255)
    with open_text(path) as fh:
        for raw in fh:
            fields = raw.split()
            if not fields or fields[0].startswith("*"):
                continue
            if fields[0] in {"NAME", "ROWS", "COLUMNS", "RHS", "BOUNDS", "ENDATA"}:
                section = fields[0]
                continue
            if section == "ROWS":
                row_type[fields[1]] = fields[0]
            elif section == "COLUMNS":
                if len(fields) >= 3 and fields[1].strip("'") == "MARKER":
                    continue
                var = fields[0]
                for k in range(1, len(fields), 2):
                    row, coef = fields[k], Decimal(fields[k + 1])
                    if row == "obj":
                        obj[var] += coef
                    else:
                        cols[var].append((row, coef))
            elif section == "RHS":
                for k in range(1, len(fields), 2):
                    rhs[fields[k]] += Decimal(fields[k + 1])
            elif section == "BOUNDS":
                kind, _name, var = fields[:3]
                val = int(Decimal(fields[3])) if len(fields) == 4 else 0
                if kind == "LO":
                    lower[var] = val
                elif kind == "UP":
                    upper[var] = val
                elif kind == "FX":
                    lower[var] = upper[var] = val
    assert all(row_type[f"c{i}"] == "G" for i in range(1, 16385))
    return rhs, obj, cols, lower, upper


def read_solution(path: Path):
    values: dict[str, int] = defaultdict(int)
    with open_text(path) as fh:
        for raw in fh:
            fields = raw.split()
            if len(fields) == 2 and fields[0].startswith("x"):
                value = Decimal(fields[1])
                if value != value.to_integral_value():
                    raise ValueError(f"nonintegral start value: {raw.strip()}")
                values[fields[0]] = int(value)
    return values


def ceil_dec(value: Decimal) -> int:
    return int(value.to_integral_value(rounding=ROUND_CEILING))


def floor_dec(value: Decimal) -> int:
    return int(value.to_integral_value(rounding=ROUND_FLOOR))


def run_order(values, slacks, obj, cols, lower, upper, order):
    changed = 0
    for var in order:
        current = values[var]
        lo, hi = lower[var], upper[var]
        for row, coef in cols[var]:
            slack = slacks[row]
            if coef > 0:
                lo = max(lo, ceil_dec(Decimal(current) - slack / coef))
            elif coef < 0:
                hi = min(hi, floor_dec(Decimal(current) + slack / (-coef)))
        if lo > current or hi < current or lo > hi:
            raise AssertionError(f"current solution lost feasibility at {var}: {lo}, {current}, {hi}")
        chosen = hi if obj[var] < 0 else lo if obj[var] > 0 else current
        if chosen == current:
            continue
        delta = Decimal(chosen - current)
        for row, coef in cols[var]:
            slacks[row] += coef * delta
            if slacks[row] < 0:
                raise AssertionError(f"negative exact slack after move: {row} {slacks[row]}")
        values[var] = chosen
        changed += 1
    return changed


def objective(values, obj):
    return sum(obj[v] * Decimal(values[v]) for v in values)


def write_solution(path: Path, values, obj_value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="ascii", newline="\n") as fh:
        fh.write(f"=obj= {obj_value}\n")
        fh.write("# Exact integer coordinate-descent solution for supportcase39\n")
        for i in range(1, 1026):
            fh.write(f"x{i} {values[f'x{i}']}\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("model", type=Path)
    ap.add_argument("start", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--passes", type=int, default=100)
    args = ap.parse_args()

    rhs, obj, cols, lower, upper = parse_mps(args.model)
    values = read_solution(args.start)
    rows = [f"c{i}" for i in range(1, 16385)]
    lhs = defaultdict(Decimal)
    for var, entries in cols.items():
        for row, coef in entries:
            lhs[row] += coef * Decimal(values[var])
    slacks = {row: lhs[row] - rhs[row] for row in rows}
    if min(slacks.values()) < 0:
        raise AssertionError("start is infeasible")

    variables = [f"x{i}" for i in range(1, 1025)]
    rng = random.Random(args.seed)
    initial = objective(values, obj)
    print(f"initial_objective={initial}")
    for pass_no in range(1, args.passes + 1):
        if pass_no == 1:
            order = variables[:]
        elif pass_no == 2:
            order = list(reversed(variables))
        else:
            order = variables[:]
            rng.shuffle(order)
        changes = run_order(values, slacks, obj, cols, lower, upper, order)
        current = objective(values, obj)
        print(f"pass={pass_no} changes={changes} objective={current} min_slack={min(slacks.values())}")
        if changes == 0:
            break
    final = objective(values, obj)
    write_solution(args.output, values, final)
    print(f"improvement={initial-final}")
    print(f"output={args.output}")


if __name__ == "__main__":
    main()
