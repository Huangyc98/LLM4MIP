#!/usr/bin/env python3
"""Read-only structural reconstruction helpers for supportcase39.mps.gz."""

from __future__ import annotations

import gzip
import json
import math
import sys
from collections import Counter, defaultdict
from pathlib import Path


def parse_mps(path: Path):
    opener = gzip.open if path.suffix == ".gz" else open
    section = None
    row_type: dict[str, str] = {}
    cols: dict[str, dict[str, float]] = defaultdict(dict)
    rhs: dict[str, float] = {}
    bounds: dict[str, tuple[float, float, str]] = {}
    int_mode = False
    with opener(path, "rt", encoding="latin-1") as fh:
        for raw in fh:
            fields = raw.split()
            if not fields or fields[0].startswith("*"):
                continue
            if fields[0] in {"NAME", "ROWS", "COLUMNS", "RHS", "BOUNDS", "ENDATA"}:
                section = fields[0]
                continue
            if section == "ROWS":
                row_type[fields[1]] = fields[0]
            elif section == "COLUMNS":
                if len(fields) >= 3 and fields[1].strip("'") == "MARKER":
                    int_mode = fields[2].strip("'") == "INTORG"
                    continue
                var = fields[0]
                for k in range(1, len(fields), 2):
                    cols[var][fields[k]] = float(fields[k + 1])
            elif section == "RHS":
                for k in range(1, len(fields), 2):
                    rhs[fields[k]] = float(fields[k + 1])
            elif section == "BOUNDS":
                kind, _bname, var = fields[:3]
                val = float(fields[3]) if len(fields) == 4 else None
                lo, up, _ = bounds.get(var, (0.0, math.inf, ""))
                if kind == "UP":
                    up = val
                elif kind == "LO":
                    lo = val
                elif kind == "FX":
                    lo = up = val
                elif kind == "BV":
                    lo, up = 0.0, 1.0
                bounds[var] = (lo, up, kind)
    return row_type, cols, rhs, bounds


def main() -> None:
    path = Path(sys.argv[1])
    row_type, cols, rhs, bounds = parse_mps(path)
    vars_ = [f"x{i}" for i in range(1, 1025)]
    rows = [f"c{i}" for i in range(1, 16385)]
    obj = [cols[v].get("obj", 0.0) for v in vars_]
    degrees = [len(cols[v]) - ("obj" in cols[v]) for v in vars_]
    # coordinate maxima and coefficient invariance under 4x-grid translations
    max_sites = []
    for vi, v in enumerate(vars_):
        pairs = [(int(r[1:]) - 1, a) for r, a in cols[v].items() if r != "obj"]
        ri, av = max(pairs, key=lambda z: z[1])
        max_sites.append((vi, ri // 128, ri % 128, av))
    row_nnz = Counter()
    row_sum = Counter()
    for v in vars_:
        for r, a in cols[v].items():
            if r != "obj":
                row_nnz[r] += 1
                row_sum[r] += a
    payload = {
        "objective": {
            "min": min(obj),
            "max": max(obj),
            "negative": sum(a < 0 for a in obj),
            "positive": sum(a > 0 for a in obj),
            "zero": sum(a == 0 for a in obj),
            "sum": sum(obj),
        },
        "degrees": dict(sorted(Counter(degrees).items())),
        "row_nnz": dict(sorted(Counter(row_nnz.values()).items())),
        "rhs": dict(Counter(rhs[r] for r in rows)),
        "max_sites_first": max_sites[:40],
        "row_sum_extrema": [min(row_sum.values()), max(row_sum.values())],
        "fixed_constant": {
            "objective_coefficient": cols["x1025"].get("obj"),
            "bounds": bounds["x1025"],
        },
    }
    print(json.dumps(payload, indent=2, sort_keys=True))
    print("OBJECTIVE_GRID")
    for i in range(32):
        print(" ".join(f"{z:8.4f}" for z in obj[32*i:32*(i+1)]))


if __name__ == "__main__":
    main()
