#!/usr/bin/env python3
"""Specialized two-control exchange search for supportcase39.

Candidate pairs are generated from rows that block a one-unit descent move.
For every candidate, the complete two-variable integer subproblem is solved by
enumerating one 8-bit control and deriving the exact feasible interval of the
other. Floating point is used only for screening; accepted moves are checked
with Decimal arithmetic against every serialized MPS row.
"""

from __future__ import annotations

import argparse
import gzip
import json
from collections import defaultdict
from decimal import Decimal, getcontext
from pathlib import Path

import numpy as np


getcontext().prec = 60


def open_text(path: Path):
    return gzip.open(path, "rt", encoding="latin-1") if path.suffix == ".gz" else path.open("rt", encoding="latin-1")


def parse_model(path: Path):
    section = None
    rhs = defaultdict(Decimal)
    obj = defaultdict(Decimal)
    entries = defaultdict(dict)
    with open_text(path) as fh:
        for raw in fh:
            f = raw.split()
            if not f or f[0].startswith("*"):
                continue
            if f[0] in {"NAME", "ROWS", "COLUMNS", "RHS", "BOUNDS", "ENDATA"}:
                section = f[0]
                continue
            if section == "COLUMNS":
                if len(f) >= 3 and f[1].strip("'") == "MARKER":
                    continue
                for k in range(1, len(f), 2):
                    coef = Decimal(f[k + 1])
                    if f[k] == "obj":
                        obj[f[0]] += coef
                    else:
                        entries[f[0]][f[k]] = coef
            elif section == "RHS":
                for k in range(1, len(f), 2):
                    rhs[f[k]] += Decimal(f[k + 1])
    return rhs, obj, entries


def read_solution(path: Path):
    values = defaultdict(int)
    with open_text(path) as fh:
        for raw in fh:
            f = raw.split()
            if len(f) == 2 and f[0].startswith("x"):
                values[f[0]] = int(Decimal(f[1]))
    return values


def calculate_slacks(values, rhs, entries):
    lhs = defaultdict(Decimal)
    for var, column in entries.items():
        xv = Decimal(values[var])
        for row, coef in column.items():
            lhs[row] += coef * xv
    return {row: lhs[row] - rhs[row] for row in rhs}


def generate_pairs(values, slacks, obj, entries, row_vars):
    pairs = set()
    for i in range(1, 1025):
        vi = f"x{i}"
        direction = 1 if obj[vi] < 0 else -1 if obj[vi] > 0 else 0
        if direction == 0 or values[vi] + direction not in range(256):
            continue
        blockers = [
            row for row, coef in entries[vi].items()
            if slacks[row] + coef * direction < 0
        ]
        for row in blockers:
            for vj in row_vars[row]:
                if vj == vi:
                    continue
                a = entries[vj][row]
                can_release = (a > 0 and values[vj] < 255) or (a < 0 and values[vj] > 0)
                if can_release:
                    pairs.add(tuple(sorted((vi, vj), key=lambda v: int(v[1:]))))
    return sorted(pairs, key=lambda p: (int(p[0][1:]), int(p[1][1:])))


def screen_pair(vi, vj, values, slacks_f, obj_f, entries_f):
    xi, xj = values[vi], values[vj]
    ci, cj = obj_f[vi], obj_f[vj]
    rows = sorted(set(entries_f[vi]) | set(entries_f[vj]))
    ai = np.array([entries_f[vi].get(r, 0.0) for r in rows])
    aj = np.array([entries_f[vj].get(r, 0.0) for r in rows])
    slack = np.array([slacks_f[r] for r in rows])
    yi = np.arange(256, dtype=float)
    base = slack[:, None] + ai[:, None] * (yi[None, :] - xi)
    feasible_i = np.ones(256, dtype=bool)
    zero = np.abs(aj) < 1e-30
    if np.any(zero):
        feasible_i &= np.min(base[zero, :], axis=0) >= -1e-9
    lo = np.zeros(256, dtype=int)
    hi = np.full(256, 255, dtype=int)
    pos = aj > 0
    if np.any(pos):
        raw = xj - base[pos, :] / aj[pos, None]
        lo = np.maximum(lo, np.max(np.ceil(raw - 1e-9), axis=0).astype(int))
    neg = aj < 0
    if np.any(neg):
        raw = xj + base[neg, :] / (-aj[neg, None])
        hi = np.minimum(hi, np.min(np.floor(raw + 1e-9), axis=0).astype(int))
    feasible = feasible_i & (lo <= hi) & (hi >= 0) & (lo <= 255)
    if not np.any(feasible):
        return None
    lo = np.clip(lo, 0, 255)
    hi = np.clip(hi, 0, 255)
    yj = hi if cj < 0 else lo if cj > 0 else np.full(256, xj)
    delta = ci * (yi - xi) + cj * (yj - xj)
    delta[~feasible] = np.inf
    k = int(np.argmin(delta))
    if not np.isfinite(delta[k]) or delta[k] >= -1e-10:
        return None
    return int(yi[k]), int(yj[k]), float(delta[k])


def exact_accept(vi, vj, yi, yj, values, slacks, obj, entries):
    di, dj = Decimal(yi - values[vi]), Decimal(yj - values[vj])
    delta_obj = obj[vi] * di + obj[vj] * dj
    if delta_obj >= 0:
        return None
    new_slacks = dict(slacks)
    for row, coef in entries[vi].items():
        new_slacks[row] += coef * di
    for row, coef in entries[vj].items():
        new_slacks[row] += coef * dj
    if min(new_slacks.values()) < 0:
        return None
    return delta_obj, new_slacks


def objective(values, obj):
    return sum(obj[v] * Decimal(values[v]) for v in values)


def write_solution(path, values, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="ascii", newline="\n") as fh:
        fh.write(f"=obj= {value}\n# Exact-checked pair-exchange solution for supportcase39\n")
        for i in range(1, 1026):
            fh.write(f"x{i} {values[f'x{i}']}\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("model", type=Path)
    ap.add_argument("start", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--iterations", type=int, default=3)
    ap.add_argument("--max-pairs", type=int, default=50000)
    args = ap.parse_args()
    rhs, obj, entries = parse_model(args.model)
    values = read_solution(args.start)
    slacks = calculate_slacks(values, rhs, entries)
    if min(slacks.values()) < 0:
        raise AssertionError("infeasible start")
    row_vars = defaultdict(list)
    for v, column in entries.items():
        if v == "x1025":
            continue
        for row in column:
            row_vars[row].append(v)
    initial = objective(values, obj)
    audit = {"initial_objective": str(initial), "iterations": []}
    for iteration in range(1, args.iterations + 1):
        pairs = generate_pairs(values, slacks, obj, entries, row_vars)
        if len(pairs) > args.max_pairs:
            pairs = pairs[:args.max_pairs]
        slacks_f = {r: float(s) for r, s in slacks.items()}
        obj_f = {v: float(c) for v, c in obj.items()}
        entries_f = {v: {r: float(a) for r, a in col.items()} for v, col in entries.items()}
        best = None
        screened = 0
        for vi, vj in pairs:
            candidate = screen_pair(vi, vj, values, slacks_f, obj_f, entries_f)
            if candidate is None:
                continue
            screened += 1
            yi, yj, _ = candidate
            accepted = exact_accept(vi, vj, yi, yj, values, slacks, obj, entries)
            if accepted is None:
                continue
            delta_obj, new_slacks = accepted
            if best is None or delta_obj < best[0]:
                best = (delta_obj, vi, vj, yi, yj, new_slacks)
        record = {"iteration": iteration, "candidate_pairs": len(pairs), "screened_improving": screened}
        if best is None:
            record["accepted"] = None
            audit["iterations"].append(record)
            print(json.dumps(record))
            break
        delta_obj, vi, vj, yi, yj, slacks = best
        old = [values[vi], values[vj]]
        values[vi], values[vj] = yi, yj
        record["accepted"] = {"variables": [vi, vj], "old": old, "new": [yi, yj], "objective_delta": str(delta_obj)}
        audit["iterations"].append(record)
        print(json.dumps(record))
    final = objective(values, obj)
    audit["final_objective"] = str(final)
    audit["improvement"] = str(initial - final)
    audit["minimum_slack"] = str(min(slacks.values()))
    write_solution(args.output, values, final)
    args.output.with_suffix(".json").write_text(json.dumps(audit, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in audit.items() if k != "iterations"}, indent=2))


if __name__ == "__main__":
    main()
