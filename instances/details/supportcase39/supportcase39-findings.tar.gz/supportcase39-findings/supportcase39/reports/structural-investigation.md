# supportcase39 structural investigation

## Disposition

The application can be reconstructed with high confidence.  This is a
gray-scale mask-planning / pixel-blending model for projection-based additive
manufacturing.  A 32 by 32 array of integer projector intensities is blurred
onto a 128 by 128 subpixel image of a dragon slice; the two classes of target
subpixels impose lower/upper exposure thresholds, and the objective maximizes
their aggregate separation.

The reconstruction identifies a very likely primary source: Chi Zhou, Yong
Chen, and Richard A. Waltz, *Optimized Mask Image Projection for Solid
Freeform Fabrication*, Journal of Manufacturing Science and Engineering 131(6),
2009, DOI 10.1115/1.4000416.  That paper describes 0--255 gray-scale projector
pixels, subdivision into smaller pixels, Gaussian light-intensity blending, a
dragon slice, fixed two-threshold constraints, and a second-stage objective
that pushes the two classes apart.  These independently match the MPS.

This is strong semantic identification, not provenance by a source-file hash:
MIPLIB still describes the original as an IBM developerWorks forum instance
with unknown application, and the forum URL encoded by the original file UUID
now redirects to the generic IBM Developer site.

The paper mainly advocates LP variants with normalized gray levels, whereas
this benchmark enforces the physically discrete 8-bit levels as general
integers.  I therefore identify the benchmark with the paper's model family
and dragon data, not with a published claim that this exact MPS was solved.

The instance remains open, but the September 7 structure-specific search found
a new strict incumbent **-1085083.8568205704596390**, improving the public value
by **2.9498856759756400**. The repeated degrees are convolutional regularity,
not exploitable global symmetry: the dragon labels break translations,
reflections, and rotations.

## Exact model reconstruction

Index the 16,384 rows by a fine-grid point `p=(r,c)` in
`{0,...,127}^2`.  Each of the 1,024 integer variables has a unique kernel peak
at a point `(R,C)` in `{0,4,...,124}^2`; this recovers a 32 by 32 control grid
despite the scrambled MPS column order.  Set `K[p,q]=abs(A[p,q])` for stored
nonzeros and zero otherwise.  Every nonzero agrees, to the decimals stored in
the MPS, with

```
K[p,q] = (1 / 6.28) * exp(-((r-R)^2 + (c-C)^2) / 32).
```

The normalization is literally `1/(2*3.14)`, and the exponent is a unit-
standard-deviation isotropic Gaussian after converting four fine-grid steps to
one projector pixel.  Across all 398,774 matrix entries, the largest absolute
residual from this formula is `4.62e-9`, the largest relative residual is
`5.53e-8`, and every coefficient sign agrees with its row class.

There are 8,883 positive rows with RHS 30 and 7,501 negative rows with RHS
-42.  Writing `z[p] = sum_q K[p,q] x[q]`, their constraints are exactly

```
z[p] >= 30  (positive/high-exposure target subpixel),
z[p] <= 42  (negative/low-exposure target subpixel).
```

The controls satisfy `x[q] in {0,...,255}`.  The only continuous variable,
`x1025`, is fixed to 48,552 and has objective coefficient -1; it is only an
objective constant.  Note that

```
30*8883 - 42*7501 = -48552.
```

For every control column, its objective coefficient is minus the sum of its
constraint coefficients, up to a maximum MPS serialization residual of
`7.5697e-14`.  Consequently the serialized objective differs by only
`1.039776666e-9` from the negative sum of all 16,384 constraint slacks.  In the
generating model, minimizing the objective is therefore maximizing total
separation/slack between the two exposure classes.

The RHS bitmap is visibly a dragon slice, and the incumbent control image and
its Gaussian-blended result reconstruct the same geometry:

![Recovered 128 by 128 target](../artifacts/supportcase39_target_128x128.png)

![Recovered 32 by 32 incumbent mask](../artifacts/supportcase39_incumbent_controls_32x32.png)

![Incumbent Gaussian-blended exposure](../artifacts/supportcase39_incumbent_blurred_128x128.png)

## What the apparent symmetry really gives

Exactly 729 columns have degree 421.  They are precisely the 27 by 27
Cartesian block of control coordinates `{2,...,28}^2`; the lower-degree
columns lie near the image boundary.  This is translation regularity of the
Gaussian stencil.  It is not a symmetry of the full optimization model,
because the dragon target changes the row signs and objective under a
translation.  None of the seven nonidentity dihedral transforms of the square
preserves the target bitmap (the mismatch counts range from 5,446 to 8,460
fine pixels).

There is nevertheless a rigorous boundary reduction, directly paralleling the
primary paper's `+-3 sigma` boundary-region idea:

* 105 controls see only positive rows.  Increasing them improves feasibility
  and the objective, so an optimum exists with all 105 fixed to 255.
* 35 controls see only negative rows.  Decreasing them improves feasibility
  and the objective, so an optimum exists with all 35 fixed to zero.
* The remaining 884 controls see both classes and form one connected
  constraint component; they do not decompose into independent pieces.
* After the 140 dominance fixings, interval bounds prove 2,523 rows redundant,
  leaving 13,861 rows.  These counts exactly reproduce MIPLIB's trivial-
  presolve statistics (the additional removed column is fixed `x1025`).

Thus the meaningful combinatorial core is a single, local 2-D boundary-band
problem, not 1,024 interchangeable variables.

## Incumbent and bounded solver probe

The current official solution has reported objective
`-1085080.906934894`.  Decimal arithmetic on the serialized MPS gives
`-1085080.9069348944839990`, with zero row, bound, or integrality violations.
Its minimum row slack is `0.00016138283836405`, so it is not merely feasible by
a loose tolerance.  Among the 1,024 controls, 589 are zero, 276 are 255, and
159 are strictly between the bounds.

A deliberately small Gurobi 13.0.2 probe used one thread, loaded the official
incumbent, and stopped at the root (`NodeLimit=0`).  Presolve took 0.23 seconds,
leaving 884 integers and 13,622 rows.  The root LP bound was
`-1085325.230699`, with 131 fractional controls and a 0.0225% displayed gap;
the entire run took 0.37 seconds.  This is a diagnostic, not a solve.

The current MIPLIB v36 solution file still marks the instance `=best=`, not
`=opt=`.  A recent Smoothie Phase-I report gives the stronger dual bound
`-1085232` (paired there with an older primal value `-1085058`).  Combining
that rounded published bound with the new incumbent suggests only about
148.1 objective units remain, but the bound was not reproduced locally and is
not an exact certificate here.

## Structure-specific primal search, 2026-09-07

The official point was first subjected to an exact-coordinate method. For one
control, all affected inequalities give an integer feasible interval, so the
best coordinate value is obtained analytically from its objective sign. Decimal
arithmetic on the serialized coefficients found zero improving moves.

For two controls, candidate generation used every row that blocks a one-unit
descent direction. Any improving pair must contain at least one control moving
in its descent direction, and the other control must release one of those
blocking rows. This produced 4,220 candidate pairs. For each pair, one 8-bit
control was enumerated and the feasible interval of the other was derived from
all affected rows. Floating point was used only for screening; every accepted
candidate would be rechecked with Decimal arithmetic. No improving pair was
found.

The next neighborhoods were geometric windows recovered from each control's
Gaussian peak. All controls outside a window were fixed to the incumbent, and
the remaining small integer problem was solved as an exact local oracle. This
is not a full-model parameter run. The results were:

| Window | Windows processed | Locally closed | Improvements | Solver seconds |
|---|---:|---:|---:|---:|
| 5x5 | 152 | 152 | 0 | 7.28 |
| 7x7 | 142 | 140 | 0 | 16.73 |
| 9x9 | 131 | 125 | 0 | 44.01 |
| 11x11, first pass | 100 | 85 | **3** | 147.60 |
| 11x11, second pass | 116 | 104 | 0 | 130.61 |
| 13x13 | 47 of 60 | 25 | 0 | 298.12 |

The three 11x11 moves produced objective
`-1085083.8568205704596390`. A new coordinate pass and all 4,188 blocking-row-generated
two-control candidates then found no further improvement. The second 11x11
pass also found none. At 13x13, most windows reached the 10-second subproblem
limit, so the search stopped rather than expanding toward generic full-model
branch-and-bound. The final point changes 30 of the 1,024 controls relative to
the public solution.

The saved solution has minimum exact row slack
`0.00016138283836405`, zero violations, and SHA-256
`c6253a555b8940108be4e404844ce2fb08861d175ef9d477784015c7dc30b4fa`.
Relative to the locally reproduced root bound -1085325.230699, the remaining
numerical gap is about 0.022245%. This is an improved upper bound, not a global
proof.

## Best closure route

1. Reorder the model geometrically and apply the 140 dominance fixings and
   2,523 bound-redundant-row deletions as a checked presolve certificate.
2. Concentrate branching, local branching, and relaxation neighborhoods on the
   159 nonsaturated incumbent controls and the thin target boundary.  The
   source paper's physical boundary model gives the right decomposition, while
   the exact dominance rules keep it rigorous.
3. For a proof, split the 32 by 32 local-stencil grid with nested separators or
   objective-cutoff subproblems, and retain rationalized MPS coefficients in
   every certificate.  A heuristic boundary fixing alone is not sufficient.
4. Use the current incumbent as the cutoff and reproduce or improve the
   Smoothie dual bound with exact/replayable branch-and-bound proof logging.
   Because the objective coefficients are decimal approximations to Gaussian
   sums, a claim based only on the ideal analytic Gaussian is not a certificate
   for the MPS.

## Reproducibility artifacts

* Model SHA-256: `f81ed6f54424a444aa176045b4dcf921f100d696f9d995fba7a2cca9279af406`
* Official solution SHA-256: `fd60906229ee011063b8ec03290d9d57f43579202a674a039c8ac96899b6e785`
* New solution SHA-256: `c6253a555b8940108be4e404844ce2fb08861d175ef9d477784015c7dc30b4fa`
* Structural parser: `supportcase39_reconstruct.py`
* Decimal validator: `supportcase39_exact_validate.py`
* Image exporter: `supportcase39_export_images.py`
* Bounded Gurobi log: `../logs/supportcase39_gurobi_root10s.log`

Validation command:

```
python3 instances/supportcase39/scripts/exact_validate.py \
  instances/supportcase39/input/supportcase39.mps.gz \
  instances/supportcase39/solutions/official.sol.gz
```

Bounded probe command:

```
/usr/local/bin/gurobi_cl Threads=1 TimeLimit=10 NodeLimit=0 \
  InputFile=instances/supportcase39/solutions/official.sol.gz \
  LogFile=instances/supportcase39/logs/gurobi-root-10s.log \
  instances/supportcase39/input/supportcase39.mps.gz
```

## Sources

* Primary application paper (USC-hosted PDF):
  <https://viterbi-web.usc.edu/~yongchen/Papers/2014_Before/MAE061004.pdf>
* Bibliographic record and DOI:
  <https://researchconnect.buffalo.edu/en/publications/optimized-mask-image-projection-for-solid-freeform-fabrication-2/>
* Official MIPLIB instance page:
  <https://miplib.zib.de/instance_details_supportcase39.html>
* Current MIPLIB v36 solution file:
  <https://miplib.zib.de/downloads/miplib2017-v36.solu>
* Smoothie Phase-I report:
  <https://optimization-online.org/wp-content/uploads/2025/10/Smoothie-PhaseI.pdf>
