# `supportcase39`

## Result

**New strict incumbent: -1085083.8568205704596390.** This improves the public
MIPLIB value -1085080.9069348944839990 by **2.9498856759756400**. Decimal
evaluation of the serialized MPS reports zero row, bound, and integrality
violations. A one-thread root-only Gurobi probe reports -1085325.230699, leaving
a 0.022245% local gap; the global optimum remains open.

The model is reconstructed as the dragon-mask pixel-blending instance for
projection-based additive manufacturing: 1,024 integer controls form a 32 by
32 projector mask, and a sparse Gaussian kernel maps them to a 128 by 128
target. The target destroys the apparent translation and dihedral symmetries.

The improvement comes from a structure-specific sliding boundary search. Exact
one-control descent and all 4,220 blocking-row-generated two-control candidates found no
improvement. Windows of size 5x5, 7x7, and 9x9 also found none. At 11x11, three
coordinated moves reduced the objective by 2.9498856759756400. A second complete
11x11 pass found no further move, while 13x13 windows reached the imposed local
time boundary without improving the new point. The final solution differs from
the public one in only 30 of the 1,024 controls.

## Provenance

- Compressed MPS SHA-256: `F81ED6F54424A444AA176045B4DCF921F100D696F9D995FBA7A2CCA9279AF406`
- Official compressed solution SHA-256: `FD60906229EE011063B8EC03290D9D57F43579202A674A039C8AC96899B6E785`
- New solution SHA-256: `C6253A555B8940108BE4E404844CE2FB08861D175EF9D477784015C7DC30B4FA`
- [MIPLIB instance page](https://miplib.zib.de/instance_details_supportcase39.html)

## Reproduction

Use [`scripts/reconstruct.py`](scripts/reconstruct.py) for the model audit and
[`scripts/exact_validate.py`](scripts/exact_validate.py) for decimal solution
validation. The recovered target and incumbent images are in
[`artifacts/`](artifacts/), and the bounded root probe is preserved in
[`logs/gurobi-root-10s.log`](logs/gurobi-root-10s.log).

The new search is reproduced by
[`scripts/integer_coordinate_descent.py`](scripts/integer_coordinate_descent.py),
[`scripts/pair_exchange_search.py`](scripts/pair_exchange_search.py), and
[`scripts/boundary_block_search.py`](scripts/boundary_block_search.py). Per-window
status, objective, exact minimum slack, and runtimes are archived as JSON under
[`artifacts/`](artifacts/). The best point is
[`solutions/improved-1085083.856820570460.sol`](solutions/improved-1085083.856820570460.sol).

See the [full structural report](reports/structural-investigation.md). The new
incumbent is rigorously feasible, but the local-neighborhood closures are not a
global optimality proof.
