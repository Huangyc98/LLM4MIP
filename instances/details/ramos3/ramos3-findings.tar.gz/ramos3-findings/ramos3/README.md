# `ramos3`

2026-09-14 independent dual-bound review: [adopted bound, proof chain, checks, and limitations](../../docs/dual-bound-audit-2026-09-14/cases/ramos3.zh.md). Reviewed lower bound: **156**. This review distinguishes exact, literature, and numerical evidence; historical statements below remain dated records.

## Result

The official objective **186** is independently verified with exact decimal
arithmetic.  This study found no smaller cover, and global optimality remains
open.  The strongest rigorous bounds recorded here are

```text
156 <= OPT <= 186.
```

The lower bound 156 is the published covering-code bound for `K_3(7,1)`;
generic MIP runs were much weaker.  The main new computational result is a
strict local certificate: no cover of size at most 185 lies within bit-Hamming
radius **7** of the official 186-word code.  Radius 9 found no improving cover
in 300 seconds but did not close its tree, so it is not a certificate.

## Input and provenance

- MPS SHA-256: `2D2D27FA5371DEFA54FF0D5899EF84E3A56C79C321815E6BFED5D5E3A16EFFE2`
- Official compressed solution SHA-256: `2854175FFC306B3F1F92E3B70561BEC0F4E40FA8FD9311E534C6F208CFF0606D`
- [MIPLIB instance page](https://miplib.zib.de/instance_details_ramos3.html)
- Kéri, [tables for bounds on covering codes](https://old.sztaki.hu/~keri/codes/index.htm)
- Gijswijt and Polak, [*Semidefinite lower bounds for covering codes*](https://arxiv.org/abs/2504.01932)
- Umetani, [*Exploiting variable associations to configure efficient local search algorithms in large-scale binary integer programs*](https://doi.org/10.1016/j.ejor.2017.05.025)

MIPLIB identifies the instance as open and reports that Yuya Hattori found the
186 solution in 2022 with weighting local search exploiting variable
associations.

## Recovered structure

The MPS is exactly the minimum radius-one covering-code problem in the ternary
Hamming space `F_3^7`.  Index `x_(i+1)` represents the seven-digit base-three
word for `i`.  After reversing the MPS signs, every row is

```text
sum(x_c : HammingDistance(c, point) <= 1) >= 1,
```

and the objective is `min sum(x_c)`.  Every radius-one ball contains
`1 + 7*(3-1) = 15` points.  The script checks all 2,187 row supports and all
2,187 column supports; there are zero mismatches.

The elementary sphere bound is only `ceil(2187/15) = 146`.  The independent
covering-code literature raises this to 156, which explains why the generic LP
bound around 145.8 is not competitive.

## Official-code audit

The 186 selected centers cover the 2,187 points with the following
multiplicities:

| multiplicity | points |
|---:|---:|
| 1 | 1,686 |
| 2 | 444 |
| 3 | 12 |
| 4 | 45 |

The total overlap excess is 603.  Every selected center owns at least four and
at most 13 private points, so the code is inclusion-minimal: deleting any one
center immediately breaks coverage.  The exact MPS audit reports objective
186, zero row or bound violations, and zero integrality violations.

## Experiments

| Method | Threads | Limit | Result |
|---|---:|---:|---|
| Gurobi 13.0.1 global, official start | 64 | 600 s | incumbent 186; bound 147; 23 nodes |
| COPT 8.0.4 global, official start | 64 | 600 s | incumbent 186; bound 145.8; 17 nodes |
| exact 2-for-1 exchange enumeration | 1 | 3.6 s | all 17,205 pairs ruled out; radius 3 certified |
| Gurobi local radius 5, target `<=185` | 16 | 1.73 s | infeasible at root |
| Gurobi local radius 7, target `<=185` | 16 | 47.53 s | **infeasible**, one node |
| Gurobi local radius 9, target `<=185` | 16 | 300 s | no solution; 25 nodes; time limit |

All COPT work on `altman` used CPU only; **GPU0 was not used**.

## Interpretation and next algorithm

Generic branch-and-bound spends most of its effort fighting the very large
automorphism group of the ternary Hamming space.  A better upper-bound search
should therefore use large destroy/repair neighborhoods or the weighting local
search that produced the incumbent.  The radius-seven certificate means a
size-185 code, if one exists, must differ in at least eight original bits from
this incumbent; 1-flip and small exchange searches cannot find it.

For a global proof, the promising direction is a symmetry-reduced
association-scheme/semidefinite relaxation followed by exact branch-and-cut,
not a longer unchanged MIP run.  Coordinate and symbol permutations may be
used to normalize a selected word to `0000000`, and further orbit fixing can
remove much of the duplicated search.

## Reproduction

The structural and local certificates use only the Python standard library:

```powershell
python .\instances\ramos3\scripts\analyze_structure.py `
  .\instances\ramos3\input\ramos3.mps.gz `
  .\instances\ramos3\solutions\official-186.sol `
  --json .\instances\ramos3\artifacts\structure-and-solution-audit.json

python .\instances\ramos3\scripts\prove_radius3.py `
  .\instances\ramos3\solutions\official-186.sol `
  --json .\instances\ramos3\artifacts\radius3-exhaustive-certificate.json

python .\common\exact_mps_solution_check.py `
  .\instances\ramos3\input\ramos3.mps.gz `
  .\instances\ramos3\solutions\official-186.sol --tolerance 1e-9
```

The Gurobi experiments are reproduced by [`gurobi_experiment.py`](scripts/gurobi_experiment.py).
See the [Chinese study report](reports/ramos3-study-zh.md),
[`artifacts/`](artifacts/), and [`logs/`](logs/).
