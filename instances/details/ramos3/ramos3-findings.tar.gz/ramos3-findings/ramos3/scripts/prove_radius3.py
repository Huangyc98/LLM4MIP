#!/usr/bin/env python3
"""Exhaustively rule out every strict improvement within bit radius three.

For a 186-word incumbent, the only nontrivial possibility in this radius is a
2-for-1 exchange.  The program tests all C(186, 2) removed pairs exactly with
integer bit sets; no floating-point arithmetic or solver is involved.
"""

from __future__ import annotations

import argparse
import gzip
import itertools
import json
import re
from pathlib import Path


N, Q, POINTS = 7, 3, 3**7
ALL_CENTERS = (1 << POINTS) - 1


def word(value: int) -> list[int]:
    result = [0] * N
    for position in range(N - 1, -1, -1):
        value, result[position] = divmod(value, Q)
    return result


def number(value: list[int]) -> int:
    result = 0
    for digit in value:
        result = Q * result + digit
    return result


def ball(center: int) -> tuple[int, ...]:
    value = word(center)
    result = [center]
    for position in range(N):
        old = value[position]
        for digit in range(Q):
            if digit != old:
                value[position] = digit
                result.append(number(value))
        value[position] = old
    return tuple(result)


def load_selected(path: Path) -> list[int]:
    opener = gzip.open if path.suffix == ".gz" else open
    selected = []
    with opener(path, "rt") as handle:
        for raw in handle:
            fields = raw.split()
            if len(fields) == 2 and re.fullmatch(r"x\d+", fields[0]) and float(fields[1]) > 0.5:
                selected.append(int(fields[0][1:]) - 1)
    return sorted(selected)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("solution", type=Path)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()

    selected = load_selected(args.solution)
    if len(selected) != 186:
        raise RuntimeError(f"expected 186 centers, found {len(selected)}")
    balls = [ball(center) for center in range(POINTS)]

    # For each covered point, record which incumbent centers cover it using a
    # compact 186-bit mask.
    incumbent_coverers = [0] * POINTS
    for incumbent_index, center in enumerate(selected):
        for point in balls[center]:
            incumbent_coverers[point] |= 1 << incumbent_index

    selected_center_mask = sum(1 << center for center in selected)
    pairs_tested = 0
    feasible_exchanges = []
    minimum_uncovered_after_removing_two = POINTS
    maximum_uncovered_after_removing_two = 0
    smallest_candidate_intersection = POINTS
    largest_candidate_intersection = 0

    for left, right in itertools.combinations(range(len(selected)), 2):
        removed_incumbent_mask = (1 << left) | (1 << right)
        uncovered = [
            point
            for point, coverers in enumerate(incumbent_coverers)
            if coverers & ~removed_incumbent_mask == 0
        ]
        minimum_uncovered_after_removing_two = min(minimum_uncovered_after_removing_two, len(uncovered))
        maximum_uncovered_after_removing_two = max(maximum_uncovered_after_removing_two, len(uncovered))

        # Incidence is symmetric: the centers that cover point p are ball(p).
        candidates = ALL_CENTERS
        for point in uncovered:
            candidates &= sum(1 << center for center in balls[point])
            if not candidates:
                break

        # A final 185-word code must not add a center already retained.
        removed_center_mask = (1 << selected[left]) | (1 << selected[right])
        retained_center_mask = selected_center_mask & ~removed_center_mask
        candidates &= ~retained_center_mask & ALL_CENTERS
        candidate_count = candidates.bit_count()
        smallest_candidate_intersection = min(smallest_candidate_intersection, candidate_count)
        largest_candidate_intersection = max(largest_candidate_intersection, candidate_count)
        if candidates:
            feasible_exchanges.append((selected[left], selected[right], (candidates & -candidates).bit_length() - 1))
        pairs_tested += 1

    result = {
        "incumbent_size": len(selected),
        "target_size_at_most": 185,
        "bit_hamming_radius": 3,
        "removed_pairs_tested": pairs_tested,
        "expected_removed_pairs": len(selected) * (len(selected) - 1) // 2,
        "minimum_uncovered_points_after_removing_two": minimum_uncovered_after_removing_two,
        "maximum_uncovered_points_after_removing_two": maximum_uncovered_after_removing_two,
        "minimum_replacement_candidate_count": smallest_candidate_intersection,
        "maximum_replacement_candidate_count": largest_candidate_intersection,
        "feasible_two_for_one_exchanges": len(feasible_exchanges),
        "certificate": "no strict improvement exists within bit-Hamming radius 3" if not feasible_exchanges else "failed",
    }
    rendered = json.dumps(result, indent=2)
    print(rendered)
    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(rendered + "\n", encoding="utf-8")
    if feasible_exchanges or pairs_tested != result["expected_removed_pairs"]:
        raise SystemExit("radius-three certificate failed")


if __name__ == "__main__":
    main()
