#!/usr/bin/env python3
"""Recover and audit the ternary covering-code structure of ramos3.

This deliberately uses only the Python standard library, so it can be run
without a commercial solver installation.
"""

from __future__ import annotations

import argparse
import collections
import gzip
import json
import math
import re
from pathlib import Path


N = 7
Q = 3
POINTS = Q**N
BALL_SIZE = 1 + N * (Q - 1)


def open_text(path: Path):
    return gzip.open(path, "rt", encoding="ascii") if path.suffix == ".gz" else path.open("rt", encoding="ascii")


def ternary(value: int) -> tuple[int, ...]:
    digits = []
    for _ in range(N):
        value, digit = divmod(value, Q)
        digits.append(digit)
    return tuple(reversed(digits))


def index(digits: tuple[int, ...]) -> int:
    value = 0
    for digit in digits:
        value = Q * value + digit
    return value


def ball(center: int) -> set[int]:
    word = list(ternary(center))
    result = {center}
    for pos in range(N):
        original = word[pos]
        for digit in range(Q):
            if digit != original:
                word[pos] = digit
                result.add(index(tuple(word)))
        word[pos] = original
    return result


def parse_mps(path: Path):
    row_type: dict[str, str] = {}
    rhs: dict[str, float] = {}
    objective_row = None
    objective: dict[int, float] = {}
    row_support: dict[int, set[int]] = collections.defaultdict(set)
    column_support: dict[int, set[int]] = collections.defaultdict(set)
    integer_vars: set[int] = set()
    unit_upper_vars: set[int] = set()
    integer_mode = False
    section = None

    with open_text(path) as handle:
        for raw in handle:
            fields = raw.split()
            if not fields or fields[0].startswith("*"):
                continue
            if not raw[0].isspace() and fields[0] in {"NAME", "ROWS", "COLUMNS", "RHS", "BOUNDS", "RANGES", "ENDATA"}:
                section = fields[0]
                continue
            if section == "ROWS":
                kind, name = fields[:2]
                row_type[name] = kind
                if kind == "N":
                    objective_row = name
            elif section == "COLUMNS":
                if "'MARKER'" in fields:
                    if "'INTORG'" in fields:
                        integer_mode = True
                    elif "'INTEND'" in fields:
                        integer_mode = False
                    continue
                variable = fields[0]
                match = re.fullmatch(r"x(\d+)", variable)
                if not match:
                    raise ValueError(f"unexpected variable name {variable!r}")
                col = int(match.group(1)) - 1
                if integer_mode:
                    integer_vars.add(col)
                for offset in range(1, len(fields), 2):
                    row, coefficient = fields[offset], float(fields[offset + 1])
                    if row == objective_row:
                        objective[col] = coefficient
                    else:
                        match_row = re.fullmatch(r"r_(\d+)", row)
                        if not match_row:
                            raise ValueError(f"unexpected row name {row!r}")
                        point = int(match_row.group(1)) - 1
                        if coefficient != -1.0:
                            raise ValueError(f"unexpected coefficient {coefficient} at {variable}, {row}")
                        row_support[point].add(col)
                        column_support[col].add(point)
            elif section == "RHS":
                for offset in range(1, len(fields), 2):
                    rhs[fields[offset]] = float(fields[offset + 1])
            elif section == "BOUNDS":
                match = re.fullmatch(r"x(\d+)", fields[2])
                if match and (fields[0] == "BV" or (fields[0] == "UP" and float(fields[3]) == 1.0)):
                    unit_upper_vars.add(int(match.group(1)) - 1)

    return row_type, rhs, objective, row_support, column_support, integer_vars & unit_upper_vars


def parse_solution(path: Path) -> tuple[float | None, set[int]]:
    claimed = None
    selected: set[int] = set()
    with open_text(path) as handle:
        for raw in handle:
            fields = raw.split()
            if not fields:
                continue
            if fields[0] == "=obj=":
                claimed = float(fields[1])
                continue
            match = re.fullmatch(r"x(\d+)", fields[0])
            if match and float(fields[1]) > 0.5:
                selected.add(int(match.group(1)) - 1)
    return claimed, selected


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()

    row_type, rhs, objective, rows, cols, binary = parse_mps(args.mps)
    claimed, selected = parse_solution(args.solution)

    constraints = {name for name, kind in row_type.items() if kind != "N"}
    expected_rows = {f"r_{point + 1:06d}" for point in range(POINTS)}
    hamming_mismatches = [point for point in range(POINTS) if rows[point] != ball(point)]
    transpose_mismatches = [point for point in range(POINTS) if cols[point] != ball(point)]
    coverage = [sum(point in ball(center) for center in selected) for point in range(POINTS)]
    private_by_center = {
        center: sum(coverage[point] == 1 for point in ball(center)) for center in selected
    }
    distances = collections.Counter(
        sum(a != b for a, b in zip(ternary(left), ternary(right)))
        for i, left in enumerate(sorted(selected))
        for right in sorted(selected)[i + 1 :]
    )
    coverage_histogram = collections.Counter(coverage)

    checks = {
        "rows_are_exactly_expected": constraints == expected_rows,
        "all_rows_are_L": all(row_type[name] == "L" for name in constraints),
        "all_rhs_are_minus_one": all(rhs.get(name) == -1.0 for name in constraints),
        "all_objective_coefficients_are_one": objective == {i: 1.0 for i in range(POINTS)},
        "all_variables_are_binary": binary == set(range(POINTS)),
        "all_row_degrees_are_15": all(len(rows[i]) == BALL_SIZE for i in range(POINTS)),
        "all_column_degrees_are_15": all(len(cols[i]) == BALL_SIZE for i in range(POINTS)),
        "rows_equal_radius_one_ternary_balls": not hamming_mismatches,
        "columns_equal_radius_one_ternary_balls": not transpose_mismatches,
        "official_solution_is_cover": min(coverage) >= 1,
        "claimed_objective_matches_cardinality": claimed == float(len(selected)),
    }
    result = {
        "instance": "ramos3",
        "interpretation": "minimum radius-1 covering code in ternary Hamming space F_3^7",
        "dimension": N,
        "alphabet_size": Q,
        "points": POINTS,
        "radius_one_ball_size": BALL_SIZE,
        "sphere_covering_lower_bound": math.ceil(POINTS / BALL_SIZE),
        "variables": len(objective),
        "constraints": len(constraints),
        "nonzeros": sum(len(value) for value in rows.values()),
        "official_claimed_objective": claimed,
        "official_selected_centers": len(selected),
        "coverage_histogram": dict(sorted(coverage_histogram.items())),
        "minimum_coverage": min(coverage),
        "maximum_coverage": max(coverage),
        "total_cover_excess": sum(coverage) - POINTS,
        "centers_with_private_points": sum(value > 0 for value in private_by_center.values()),
        "minimum_private_points_per_center": min(private_by_center.values()),
        "maximum_private_points_per_center": max(private_by_center.values()),
        "pairwise_hamming_distance_histogram": dict(sorted(distances.items())),
        "hamming_row_mismatches": len(hamming_mismatches),
        "hamming_column_mismatches": len(transpose_mismatches),
        "checks": checks,
    }

    rendered = json.dumps(result, indent=2, sort_keys=False)
    print(rendered)
    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(rendered + "\n", encoding="utf-8")
    if not all(checks.values()):
        raise SystemExit("one or more structural/audit checks failed")


if __name__ == "__main__":
    main()
