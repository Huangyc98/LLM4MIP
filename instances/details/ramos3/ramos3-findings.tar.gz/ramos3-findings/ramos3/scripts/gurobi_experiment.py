#!/usr/bin/env python3
"""Run a reproducible Gurobi global or local-branching experiment on ramos3."""

from __future__ import annotations

import argparse
import gzip
import re
from pathlib import Path

import gurobipy as gp


def selected_names(path: Path) -> set[str]:
    opener = gzip.open if path.suffix == ".gz" else open
    result = set()
    with opener(path, "rt") as handle:
        for raw in handle:
            fields = raw.split()
            if len(fields) == 2 and re.fullmatch(r"x\d+", fields[0]) and float(fields[1]) > 0.5:
                result.add(fields[0])
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("incumbent", type=Path)
    parser.add_argument("--mode", choices=("global", "local"), default="global")
    parser.add_argument("--radius", type=int)
    parser.add_argument("--cutoff", type=int, default=185)
    parser.add_argument("--time-limit", type=float, default=600.0)
    parser.add_argument("--threads", type=int, default=64)
    parser.add_argument("--log", required=True)
    parser.add_argument("--solution")
    args = parser.parse_args()
    if args.mode == "local" and args.radius is None:
        parser.error("--radius is required in local mode")

    incumbent = selected_names(args.incumbent)
    model = gp.read(str(args.model))
    variables = model.getVars()
    by_name = {variable.VarName: variable for variable in variables}
    if set(by_name) != {f"x{i}" for i in range(1, 2188)}:
        raise RuntimeError("unexpected ramos3 variable set")
    for variable in variables:
        variable.Start = 1.0 if variable.VarName in incumbent else 0.0

    model.Params.Threads = args.threads
    model.Params.TimeLimit = args.time_limit
    model.Params.LogFile = args.log
    model.Params.MIPFocus = 3
    model.Params.Seed = 1
    model.Params.Symmetry = 2
    if args.mode == "local":
        model.addConstr(gp.quicksum(variables) <= args.cutoff, "strict_improvement")
        distance = gp.quicksum(
            1 - variable if variable.VarName in incumbent else variable
            for variable in variables
        )
        model.addConstr(distance <= args.radius, f"local_radius_{args.radius}")
        model.Params.DualReductions = 0

    model.optimize()
    print(f"FINAL_STATUS {model.Status}")
    print(f"FINAL_SOLCOUNT {model.SolCount}")
    if model.SolCount:
        print(f"FINAL_OBJECTIVE {model.ObjVal:.17g}")
        if args.solution:
            model.write(args.solution)
    if model.Status not in {gp.GRB.INFEASIBLE, gp.GRB.INF_OR_UNBD}:
        print(f"FINAL_BOUND {model.ObjBound:.17g}")
        print(f"FINAL_NODES {model.NodeCount:.17g}")


if __name__ == "__main__":
    main()
