# `neos-3603137-hoteo`

## Result

**Feasibility remains unknown.** No feasible original-MPS point and no complete
UNSAT certificate have been obtained. CP and an independent finite-domain SAT
encoding both ended `UNKNOWN` in the final two-hour window.

The corrected comparison/reification model has 54 small-domain integers. The
SAT audit checks all 10,510 original rows and builds 2,005 Boolean variables and
99,814 clauses. Time limits and conflict counts are not infeasibility proofs.

- [Latest report](../../docs/ten-instance-results-2026-09-06.zh.md)
- [CP/SAT results and encoding audits](../../studies/ten-instance-2026-09-06/hour-pass/runs/20260905-2h/neos-3603137-hoteo/)
- [Finite-domain SAT implementation](../../studies/ten-instance-2026-09-06/hour-pass/two_hour_neos_sat.py)
- [Input hash in the publication manifest](../../studies/ten-instance-2026-09-06/publication-manifest.json)
- [MIPLIB metadata](https://miplib.zib.de/instance_details_neos-3603137-hoteo.html)
