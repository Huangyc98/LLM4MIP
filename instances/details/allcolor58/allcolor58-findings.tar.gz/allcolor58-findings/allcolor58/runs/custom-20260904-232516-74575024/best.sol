# Objective value = 0
