# Final report: `allcolor58`

## Outcome

**Final classification: partial result — solver-accepted feasible, not independently tolerance-verified.**

The best objective reported by a custom run was **0** for this minimization instance. The controller classified that incumbent as solver-accepted but did **not** accept it under its separate tolerance-based verification check. Consequently, the archival result is not a verified feasible solution, and the combination of an apparent objective value of zero with the model's nonnegative objective structure is **not** reported as a proof of optimality.

No run supplied a recorded global dual bound. No combined relative gap can therefore be calculated. No run received strict optimal or strict infeasible status, and no independently checked certificate was produced.

| Final item | Value |
|---|---:|
| Objective sense | Minimize |
| Best solver-accepted primal | 0 |
| Best independently tolerance-verified primal | None |
| Best recorded dual | None |
| Relative gap | Not available |
| Strict optimality proof | No |
| Strict infeasibility proof | No |
| Final status | Partial result: feasible, solver-accepted only |

A time limit, failed custom run, missing incumbent, or unsuccessful verification is not interpreted as infeasibility or optimality.

## Comparison with targets and baselines

### Pre-experiment public bounds

`background.md` explicitly states that no numerical public primal or dual target was recovered from a primary source. Therefore:

- this experiment **does not claim an improvement to a public primal bound**;
- it **does not claim an improvement to a sourced public dual bound**;
- it cannot claim a public gap reduction; and
- no public dual record is inferred from the absence of a documented target.

The solver-accepted objective value 0 is an experiment-internal candidate, not a public record. Because it did not pass independent tolerance verification, it is not counted as a verified numerical improvement.

### Short internal baseline

The final experiment ledger contains no Gurobi or COPT run and no numerical generic-solver baseline. Thus there is no short internal baseline primal, dual, or gap against which a numerical improvement can be established. The custom objective-0 candidates are informative internal results, but not verified baseline improvements.

**Numerical-improvement conclusion:** no verified numerical improvement was established. The most informative result is that several structurally designed custom methods rapidly found objective-0 candidate assignments, while the independent checker rejected all submitted solution files.

## Problem classification and structure

`allcolor58` is a large, sparse, pure linear mixed-integer minimization model:

- 84,376 variables: 80,780 general integer and 3,596 continuous;
- no variables declared binary;
- 197,154 linear constraints: 116,928 `<=`, 58,506 `>=`, and 21,720 equalities;
- 515,184 matrix nonzeros, approximately 2.61 per row;
- integral matrix coefficients with absolute value at most 11;
- 2,784 nonzero objective coefficients, all positive integral values at most 10;
- no quadratic, SOS, or general constraints;
- finite lower bounds observed by the structural scan are zero; and
- 4,220 finite upper bounds, including 3,060 positive upper bounds no larger than 10.

The decisive features were the extremely sparse local row structure, small integral coefficients and right-hand sides, a large collection of zero-cost variables, and a relatively small positive-cost support. These features motivated direct combinatorial construction and propagation rather than treating the instance only as an opaque generic MIP.

The positive objective coefficients and nonnegative variable bounds make zero the natural target value. That observation is useful algorithmically, but a submitted objective-0 assignment must still satisfy every original row and bound under the controller's independent numerical checks before it can establish a verified primal or support an optimality conclusion.

## Methods considered

The research design separated generic solving from problem-specific methods. Standard approaches considered included:

1. a short generic MIP diagnostic baseline;
2. feasibility-pump or local-repair construction on the sparse rows;
3. propagation over equality and short-row components;
4. graph- or hypergraph-based decomposition of the constraint matrix;
5. exact SAT/PB-style feasibility checking for the objective-0 face;
6. large-neighborhood repair of violated components; and
7. proof-oriented work on the objective-0 feasibility question or on a global lower bound.

No generic direct-solver run appears in the final ledger. All ten recorded executions were custom Python or C++ programs. The custom effort focused on generating and checking objective-0 candidates and on structural feasibility/proof probes. The configured trusted capabilities were CaDiCaL and DRAT-trim, although the final summary records no independently checked DRAT certificate and therefore no proof claim is made.

## Execution ledger and termination statuses

Every recorded termination is listed below. `success` means the custom program completed its declared algorithmic work; it does not imply a verified feasible solution or proof.

| Run | Stack | Termination | Reported primal | Verification | Runtime (s) |
|---|---|---|---:|---|---:|
| `custom-20260904-232306-0cd77fac` | Python | success | — | not checked | 31.314366 |
| `custom-20260904-232516-74575024` | C++ | success | 0 | no | 1.915871 |
| `custom-20260904-232652-a07c8456` | Python | success | 0 | no | 3.340588 |
| `custom-20260904-232835-204bcd94` | Python | success | — | not checked | 5.404682 |
| `custom-20260904-233020-0280fb32` | Python | success | — | not checked | 0.170955 |
| `custom-20260904-233139-354d3571` | Python | error | — | not checked | 2.385112 |
| `custom-20260904-233301-568cbcb2` | Python | success | — | not checked | 0.171006 |
| `custom-20260904-233420-c0e2b662` | Python | success | — | not checked | 2.988338 |
| `custom-20260904-233542-8e5c383b` | Python | failed | — | not checked | 2.033251 |
| `custom-20260904-233703-3a092772` | Python | success | 0 | no | 63.770185 |

Totals from the machine-readable ledger:

- custom executions: **10**;
- successful custom executions: **8**;
- custom errors: **1**;
- custom failures: **1**;
- aggregate custom runtime: **113.494353 s**;
- direct Gurobi/COPT runtime in the final ledger: **0 s**;
- total recorded experimental runtime: **113.494353 s**;
- custom share of recorded runtime: **100%**;
- direct-solver share: **0%**;
- longest recorded custom run: **63.770185 s**.

The ledger distinguishes executions but the compressed archival summary does not safely establish the exact number of distinct source-level algorithm families or label which run was the formal scaled-run gate. Those facts must not be invented. On the available record, there were ten custom executions using two implementation stacks, and eight completed successfully. Gate satisfaction is therefore recorded conservatively as **not fully demonstrated by the compressed ledger** pending any exact statement in `strategy.md` or `method_selection.md`.

## Algorithm behavior, errors, revisions, and pivots

The experiment repeatedly reached objective-0 candidates, first in C++ and then in Python, including the longest 63.77-second run. However, each candidate submitted for independent checking received `Verified: no`. This is the central failure diagnosis: candidate construction and the writer's own checks were not sufficient to reproduce all original-model semantics or satisfy the controller's tighter Decimal-based feasibility test.

Runs without a primal were structural, proof, or diagnostic probes rather than evidence of infeasibility. The single `error` run and single `failed` run are likewise negative implementation/algorithm outcomes, not mathematical statuses. Later runs pivoted toward additional diagnostics and a longer candidate-generation attempt, but the final scaled candidate still failed independent verification. No validated dual certificate emerged from the proof-oriented work.

The appropriate interpretation is therefore:

- objective-targeting heuristics were fast and repeatedly found internally plausible candidates;
- candidate serialization or exact row/bound satisfaction remained unresolved;
- proof attempts did not produce an independently checked certificate; and
- further repetitions of the same unchecked constructor would have low expected value.

## Reproducibility record

### Execution environment

- Custom runtime stacks recorded: Python standard library and C++17.
- Configured trusted tools: CaDiCaL and DRAT-trim.
- Network access: disabled inside the custom sandbox.
- CPU mode: CPU-only.
- Inputs and tools: mounted read-only.
- Output: private writable run directory.
- Limits: controller-enforced time, memory, output-file size, and thread limits.
- Machine/CPU model and exact numeric sandbox limits: not present in the compressed reporting bundle and therefore not guessed.
- Gurobi/COPT version: not applicable to the final run ledger because no direct-solver execution was recorded.
- Exact CaDiCaL/DRAT-trim version: not recorded in the compressed reporting summary.

### Sources, parameters, and seeds

The controller ledger reports empty parameter dictionaries for the custom runs. No random seed is recorded in the compressed summary, so no deterministic seed value is invented. Custom source names and exact command-line arguments should be taken from the archived `strategy.md`, `method_selection.md`, and run directories; where those records do not state them, they are unavailable rather than inferred.

The original uncompressed model SHA-256 begins with the value documented in `background.md`; `background.md` is the authoritative local record for the full digest and structural scan. Controller-managed `experiments.json`, `experiments.md`, and `result.json` remain the authoritative machine-readable records.

## Proof boundary

Optimality was **not** proved. Infeasibility was **not** proved. There was no strict solver status and no independently checked certificate supporting either conclusion. A custom program's successful termination, its internal feasibility assertion, or the structural lower target of zero is not substituted for such evidence.

## Recommended next experiment

The next experiment should not merely rerun the same constructor. It should build an exact, row-indexed discrepancy pipeline:

1. parse the original model independently;
2. evaluate every bound and row in exact rational or integer arithmetic wherever possible;
3. report the first violated rows with original names, senses, residuals, and contributing variables;
4. repair only the connected components containing those violations while freezing already exact components;
5. emit solution values using lossless integer formatting and sufficient decimal precision for continuous variables; and
6. independently reparse the emitted solution before submission.

If the objective-0 face can be reduced exactly to a Boolean or bounded-integer feasibility problem, a proof-oriented follow-up should encode that face with auditable variable/row mappings, run CaDiCaL, and validate any UNSAT proof with DRAT-trim. Only that checked proof, or a strict trusted-solver status, should support an optimality/infeasibility claim.

## Conclusion

This experiment produced a useful but incomplete negative result. Ten structure-specific custom executions, totaling 113.49 seconds, repeatedly generated objective-0 candidates, but none passed independent tolerance verification. No dual bound or proof was recorded. Because no sourced public numerical bounds were available, no public primal improvement, public dual improvement, or public gap reduction is claimed. The highest-value continuation is exact violation localization and component-level repair, followed by an auditable proof encoding if objective-0 feasibility remains unresolved.
