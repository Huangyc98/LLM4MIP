import json, os
p='/resources/structure_audit.json'
# supplied input is mounted by basename
with open(p,'r',encoding='utf-8') as f: d=json.load(f)
out=[]
out.append('TOP '+repr(list(d.keys())))
for key in d:
 v=d[key]
 if isinstance(v,dict): out.append(f'KEY {key} dict keys={list(v.keys())[:100]}')
 elif isinstance(v,list): out.append(f'KEY {key} list n={len(v)} first={repr(v[:2])[:1000]}')
 else: out.append(f'KEY {key} {repr(v)}')
for fam,info in d.get('variable_families',{}).items():
 out.append('\nVAR '+fam+' '+json.dumps(info,separators=(',',':'))[:12000])
# Dump manageable row/template-related sections recursively only as concise type summaries and selected samples.
for key in d:
 if any(w in key.lower() for w in ('row','constraint','template','block','prefix')):
  v=d[key]
  out.append('\nSECTION '+key)
  if isinstance(v,dict):
   for k,z in v.items():
    if isinstance(z,list): out.append(f'{k}: list n={len(z)} sample='+json.dumps(z[:3],separators=(',',':'))[:12000])
    elif isinstance(z,dict): out.append(f'{k}: dict n={len(z)} sample='+json.dumps(dict(list(z.items())[:5]),separators=(',',':'))[:16000])
    else: out.append(f'{k}: {z!r}')
  else: out.append(json.dumps(v,separators=(',',':'))[:30000])
open('audit_digest.txt','w',encoding='utf-8').write('\n'.join(out))
open('method_result.json','w').write(json.dumps({'algorithm_family':'structural audit extraction','algorithm_role':'diagnostic','hypothesis':'the audit contains enough indexed templates to derive a compact core','positive_work_units':1,'termination_reason':'completed','status':'completed'}))
