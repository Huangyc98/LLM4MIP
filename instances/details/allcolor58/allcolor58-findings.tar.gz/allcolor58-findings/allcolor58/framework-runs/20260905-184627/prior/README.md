# `allcolor58` experiment archive

## Latest trial: research-agent-v3 (2026-09-05)

The [new structure-only campaign](../../20260905-151556/operator-audit.md)
reproduced the public incumbent 258, with a fresh zero-tolerance check finding
no violations. It did not improve the incumbent, establish a new dual bound,
or prove optimality. It used 191,290 of 200,000 tokens in about seven minutes;
92.9% were input tokens. Only a reproduction program and a structural audit
ran (9.808 seconds combined); no new optimization algorithm was executed.
The audit's custom parser skipped indented `rhs` records and its reported
violations are invalid. Gurobi/COPT performed no optimization. Full logs,
sources, and the post-run diagnosis are preserved in the linked archive.

The older report below is retained as history: its objective-0 candidates
are invalid, and the accepted incumbent is 258, as explained in the audit correction.

> **Post-run audit correction (2026-09-04):** the official public solution with
> objective **258** was downloaded and independently checked against all
> 197,154 original rows, bounds, and integrality conditions with zero
> violations. The objective-0 candidates generated in this run remain invalid;
> they do not improve the verified public incumbent. No optimality proof was
> obtained.

## Result at a glance

This archive records a **partial result** for the MIPLIB instance `allcolor58`.

- Objective sense: minimization.
- Best solver-accepted objective: **0**.
- Independently tolerance-verified incumbent: **none**.
- Recorded dual bound: **none**.
- Relative gap: **not available**.
- Optimality proved: **no**.
- Infeasibility proved: **no**.

The objective-0 solution files produced by custom methods were rejected by the controller's separate tolerance-based verification. They must not be treated as verified feasible solutions or as optimality proofs.

## Numerical comparison

The reconstructed background record contains no sourced public numerical primal or dual target. Accordingly, this experiment claims:

- no verified public primal-bound improvement;
- no sourced public dual-bound improvement;
- no public gap reduction; and
- no verified experiment-internal numerical improvement over a generic baseline.

No Gurobi or COPT run appears in the final experiment ledger, so there is no numerical short internal generic-solver baseline. The objective-0 candidates are experiment-internal, solver-accepted candidates only.

## Model

The instance is a sparse linear mixed-integer minimization problem with 84,376 variables, 197,154 constraints, and 515,184 nonzeros. It has 80,780 general integer and 3,596 continuous variables, no declared binaries, and no quadratic, SOS, or general constraints. All nonzero objective coefficients are positive integers. The sparse short-row structure, small integral coefficients, and large zero-cost support motivated custom constructive, propagation, repair, and proof-oriented methods.

## Experiment summary

The final ledger contains ten custom executions:

- 9 Python runs and 1 C++ run;
- 8 successful program terminations, 1 error, and 1 failure;
- 113.494353 seconds of aggregate custom runtime;
- 0 seconds of recorded direct Gurobi/COPT runtime;
- 100% custom and 0% direct-solver share of recorded compute; and
- 63.770185 seconds for the longest custom run.

A successful custom-program termination is only evidence that declared algorithmic work completed. It is not evidence of feasibility, optimality, or infeasibility. Three runs reported objective 0; all three failed independent verification. No run reported a usable dual bound or independently checked certificate.

The compressed summary does not safely identify the exact number of distinct algorithm families or whether the formal scaled-run gate was met. Those values are not guessed; consult `method_selection.md`, `strategy.md`, and the archived run records for any more specific controller-recorded designation.

## Reproducibility

Custom programs ran CPU-only in a network-disabled sandbox using Python's standard library or C++17. Inputs and configured tools were mounted read-only, with private writable output and controller-enforced time, memory, file-size, and thread limits. CaDiCaL and DRAT-trim were configured capabilities; no checked proof from them is part of the final result. Exact machine hardware, tool versions, random seeds, and numeric sandbox limits were not present in the compressed reporting summary and are not invented here. The ledger records empty custom parameter dictionaries.

See:

- [`final_report.md`](final_report.md) for the full interpretation, run table, failure diagnosis, compute accounting, and recommended next experiment;
- [`background.md`](../background.md) for model structure and the public-bound sourcing boundary;
- [`method_selection.md`](../method_selection.md) and [`strategy.md`](../strategy.md) for algorithm design records, where available;
- [`experiments.md`](../experiments.md) for the controller-generated human-readable ledger;
- `experiments.json` for the controller-generated machine-readable ledger; and
- `result.json` for the controller-generated final result.

## Recommended continuation

The next useful experiment is an exact row-by-row discrepancy and repair pipeline, not another blind rerun of the same constructor. It should independently parse the original model, locate every violated bound and row using exact arithmetic where possible, repair only affected constraint components, and reparse the serialized solution before submission. A subsequent SAT/PB encoding of the objective-0 face should be used for proof only if its mapping is auditable and any UNSAT certificate is independently checked.
