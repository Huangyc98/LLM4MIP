# Audited prior evidence and open questions

These are operator-supplied research leads, not a proof or an algorithm prescription.

- This is a minimization model. The previously audited public incumbent is 258; its original-MPS check found zero row, bound and integrality violations at tolerance zero. The public solution is under prior/solutions/public. No better primal bound, new dual bound or optimality proof was established by the previous research-agent-v3 run.
- Historical objective-0 candidates are invalid. Older copied README/result sections conflict with later audit corrections and must not be treated as accepted results.
- The previous custom parser skipped indented data records whose RHS vector name is `rhs`. It incorrectly initialized RHS values to zero. Its structural interpretation and reported incumbent violations were consequently unreliable. The new controller supplies a Gurobi-exported model snapshot and tested helper.
- Reference counts: 84,376 variables, 197,154 rows, 515,184 nonzeros, 80,780 general integers and 3,596 continuous variables. Counts alone do not establish a combinatorial equivalence.
- The previous run only reproduced the incumbent and performed a flawed structural diagnostic (9.808 seconds combined). It did not execute a new optimization algorithm. Proposed sequence/assignment-space interpretations remain hypotheses.
- Important unresolved questions include the application and precise combinatorial meaning of variable/row families, whether a smaller equivalent representation exists, and which mathematical property could support a better incumbent or certified lower bound. No particular algorithm or external tool is preferred.

Audit provenance: instances/allcolor58/framework-runs/20260905-151556/operator-audit.md in the results repository, published in commit d367805b308d1519948b039fad528678892d919d. Original compressed model SHA256: cecf7b32c4333a8cf3a838387afb8d00092067c3e56bd72b48b031df66a58397.
