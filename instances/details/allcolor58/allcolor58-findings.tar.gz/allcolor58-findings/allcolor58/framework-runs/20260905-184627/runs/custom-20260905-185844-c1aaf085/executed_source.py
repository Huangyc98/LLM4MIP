from model_access import load_model
from collections import Counter,defaultdict
import re,json
D=load_model(); V=D['variables']; R=D['rows']

def fam(n):
 m=re.match(r'([^\(\[]+)',n); return m.group(1) if m else n
vf=defaultdict(list)
for i,v in enumerate(V): vf[fam(v['name'])].append((i,v))
rf=defaultdict(list)
for i,r in enumerate(R): rf[fam(r['name'])].append((i,r))
print('SIZE',len(V),len(R))
print('\nVARIABLE FAMILIES')
for f,a in sorted(vf.items()):
 print(f,len(a),'types',dict(Counter(v['type'] for _,v in a)),'bounds',Counter((v['lb'],v['ub']) for _,v in a).most_common(6),'obj',Counter(v['obj'] for _,v in a).most_common(6),'samples',[v['name'] for _,v in a[:5]])
print('\nROW FAMILIES')
for f,a in sorted(rf.items()):
 print(f,len(a),'sense/rhs',Counter((r['sense'],r['rhs']) for _,r in a).most_common(8),'nnz',Counter(len(r['terms']) for _,r in a).most_common(8),'samples',[r['name'] for _,r in a[:5]])
print('\nREPRESENTATIVE ROWS')
for f,a in sorted(rf.items()):
 picks=[]
 for j in [0,1,len(a)//2,len(a)-1]:
  if 0<=j<len(a) and j not in picks:picks.append(j)
 for j in picks:
  idx,r=a[j]; terms=[(V[k]['name'],c) for k,c in r['terms']]
  print(json.dumps({'idx':idx,'family':f,'name':r['name'],'sense':r['sense'],'rhs':r['rhs'],'terms':terms},separators=(',',':')))
print('\nUNFIXED BY VARIABLE FAMILY')
for f,a in sorted(vf.items()):
 z=[v for _,v in a if float(v['ub'])>float(v['lb'])]
 if z: print(f,len(z),[v['name'] for v in z[:30]])
print('\nO ALLOWED BY POSITION')
for f,a in vf.items():
 if f=='o':
  by=defaultdict(list)
  for _,v in a:
   if float(v['ub'])>0:
    nums=list(map(int,re.findall(r'\d+',v['name']))); by[nums[0]].append(nums[1])
  for p in sorted(by): print(p,by[p])
