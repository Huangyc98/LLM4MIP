# Method selection

## Decision

Use an **exact structural audit plus incumbent replay** as the first test. Do not yet encode a guessed coloring, sequencing, or permutation problem.

This choice addresses the main diagnosed failure: previous work used a faulty custom RHS parser. The first test therefore uses only the controller-owned snapshot through `model_access`, and candidate acceptance is delegated to the controller's original-MPS checker.

## Concrete first test: `audit_and_replay`

Implement `methods/audit_and_replay.py` with the following bounded tasks.

1. Call `load_model()` and record:
   - all variable names, types, lower/upper bounds, and objective coefficients;
   - objective-support counts by family and index position;
   - row counts by sense, exact decimal RHS, term count, and coefficient pattern;
   - for each row signature, the participating variable families and observed index relationships.
2. Verify that the loaded totals reproduce 84,376 variables, 197,154 rows, and 515,184 nonzeros. A mismatch is an infrastructure failure and should stop the run.
3. Write `structural_audit.json` and a concise `row_templates.md`. Preserve decimal strings when describing exact templates; do not parse the MPS independently.
4. If an explicit historical solution artifact is provided as an input, load it with `read_solution` and evaluate it with `model_access.evaluate` over the complete snapshot.
5. Record missing variables, bound/integrality violations, maximum row violation, violated-row count, recomputed objective, and the first diagnostic violations in `replay_report.json`.
6. Only if the candidate passes `evaluate`, write a normalized `best.sol`. The controller must then check `best.sol` against the original MPS. A snapshot pass alone is not the final feasibility claim.
7. Write `method_result.json` with algorithm family `formulation audit / incumbent replay`, positive work units equal to rows inspected plus candidate values checked, and a factual termination reason.

If no historical solution file exists, the test remains useful as an exact structural audit and must report `no_candidate_available`; it must not fabricate a candidate from the value 258.

## Why this method comes first

- It directly repairs the known infrastructure failure rather than assuming its consequences are mathematical.
- It obtains the missing facts needed to choose an algorithm: domains, objective support, and complete row algebra.
- It creates a trusted baseline assignment if the historical incumbent can be replayed.
- It is linear in model size and is therefore a short, measurable diagnostic rather than an open-ended search.
- It does not invent a semantic mapping from suggestive family dimensions.

## Success criteria

The audit succeeds if all snapshot totals agree and every row is assigned to a reproducible exact template. Replay succeeds only if both of the following occur:

1. `model_access.evaluate` reports no domain, integrality, or row violation for the candidate; and
2. the controller's original-MPS check accepts the emitted `best.sol`.

Only the second event establishes a controller-verified primal bound. Neither event establishes optimality.

## Failure classification

- **Infrastructure failure:** snapshot counts disagree, `model_access` cannot load, candidate syntax cannot be read, or normalized output changes values.
- **Candidate failure:** the supplied historical assignment violates bounds, integrality, or rows under the authoritative snapshot/original MPS.
- **Modeling uncertainty:** audit succeeds but row templates do not support a unique semantic interpretation.
- **Mathematical failure:** only after an exact structure-derived search is implemented and correctly evaluated should inability to improve or prove a bound be classified as mathematical.

## Follow-on method selection rules

After the audit, choose one branch based on established structure:

- If a small set of binary decision families determines the others through equalities, eliminate/propagate auxiliaries and use constructive search plus large-neighborhood repair.
- If rows establish assignment or permutation constraints, use matching/flow relaxations for construction and lower bounds, with exact side-constraint checking.
- If the formulation is a finite-domain sequence model with local transitions, test dynamic programming or CP with explicit global coupling.
- If global rows are covering/packing constraints, derive conflict or set-system bounds before attempting generic local search.
- If blocks couple only through a small master family, test decomposition and independently verify subproblem recombination.

SAT/CP or another external tool should be requested only after the audit yields an exact structure-derived encoding. Tool-generated optimal/UNSAT status is not strict proof unless checked by an operator-registered certificate checker.