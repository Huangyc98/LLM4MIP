from model_access import load_model
from collections import Counter,defaultdict
import re,json
D=load_model(); vs=D['variables']; rs=D['rows']
pat=re.compile(r'^([^\(]+)(?:\((.*)\))?$')
def fam(s):
 m=pat.match(s); return m.group(1) if m else s
def inds(s):
 m=pat.match(s)
 if not m or m.group(2) is None:return ()
 try:return tuple(map(int,m.group(2).split(',')))
 except:return ()
V=defaultdict(list)
for i,v in enumerate(vs): V[fam(v['name'])].append((i,v,inds(v['name'])))
print('OBJ_SENSE',D.get('objective_sense'),D.get('sense'))
for f,a in sorted(V.items()):
 dims=[]
 for z in zip(*[x[2] for x in a]) if a and a[0][2] else []:dims.append((min(z),max(z),len(set(z))))
 print('VAR',f,len(a),'dims',dims,'types',Counter(x[1]['type'] for x in a),'bounds',Counter((x[1]['lb'],x[1]['ub']) for x in a),'obj',Counter(x[1]['obj'] for x in a))
# row-family transition points based on family/coefficient signatures
last=None; start=0
for ri,r in enumerate(rs):
 sig=(r['sense'],r['rhs'],tuple(sorted(Counter(fam(vs[j]['name']) for j,c in r['terms']).items())),tuple(sorted(Counter(c for j,c in r['terms']).items())))
 if sig!=last:
  if last is not None: print('BLOCK',start,ri-1,ri-start,last)
  start=ri;last=sig
print('BLOCK',start,len(rs)-1,len(rs)-start,last)
# print first/last row of manageable early blocks and all rows after 1400
for ri,r in enumerate(rs):
 if ri<100 or ri>=1400:
  terms=' + '.join(f'{c}*{vs[j]["name"]}' for j,c in r['terms'])
  print('ROW',ri,r['name'],terms,r['sense'],r['rhs'])
