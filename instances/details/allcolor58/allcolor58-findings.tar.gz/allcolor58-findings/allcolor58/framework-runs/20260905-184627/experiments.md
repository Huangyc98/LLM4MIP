# Experiment ledger

This file is generated from `runs/*/result.json` by the controller.

| Run | Solver | Status | Primal | Dual | Gap | Verified | Runtime (s) |
|---|---|---|---:|---:|---:|---|---:|
| `custom-20260905-184959-82a62a89` | custom-python | completed | — | — | — | not checked | 6.91828298568726 |
| `custom-20260905-185123-68022426` | custom-python | completed | — | — | — | not checked | 0.624347686767578 |
| `custom-20260905-185213-9bcc21c9` | custom-python | ERROR | — | — | — | not checked | 1.58028793334961 |
| `custom-20260905-185239-0b302e07` | custom-python | COMPLETED | — | — | — | not checked | 3.94660711288452 |
| `custom-20260905-185556-df4a71b2` | custom-python | COMPLETED | — | — | — | not checked | 4.24865674972534 |
| `custom-20260905-185844-c1aaf085` | custom-python | COMPLETED | — | — | — | not checked | 5.90939426422119 |
| `custom-20260905-190131-69bf6b2b` | custom-python | ERROR | — | — | — | not checked | 1.63098883628845 |
| `custom-20260905-190243-e6a65c82` | custom-python | COMPLETED | — | — | — | not checked | 1.4804573059082 |
| `custom-20260905-190318-c0c455bb` | custom-python | ERROR | — | — | — | not checked | 16.9863433837891 |
| `custom-20260905-190605-c0c9c3ad` | custom-python | ERROR | — | — | — | not checked | 2.68806648254395 |
| `custom-20260905-190742-5e7a4d70` | custom-python | ERROR | — | — | — | not checked | 14.9218900203705 |
