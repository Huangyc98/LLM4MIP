## Mathematical abstraction

### Proven from the controller-owned metadata

The instance is a finite-dimensional linear integer minimization model with 84,376 variables, 197,154 rows, and 515,184 nonzeros. Its variables are partitioned by name into eight indexed families:

| Family | Count |
|---|---:|
| `w` | 58,464 |
| `q` | 19,488 |
| `v` | 2,436 |
| `o` | 1,392 |
| `u` | 1,392 |
| `x` | 812 |
| `y` | 336 |
| `t` | 56 |

The rows fall into 15 coefficient/signature classes in the bounded structural summary. Sample equalities have the form

`-o(i,j) + u(i,j) + sum_k q(k,i,j) = r(i,j)`,

with varying nonzero right-hand sides. This displayed relation is established only for the sampled rows; it must not yet be extrapolated to every index. A sampled covering-style row contains 48 positive `o` terms and right-hand side 1.

The exact variable domains, objective support, complete index ranges, and complete row templates have not yet been recorded in the current handoff. They are therefore unknown, despite suggestive factorisations of family counts.

### Hypotheses, not established mappings

The repeated indices and the instance name suggest a construction involving labels, colors, positions, or pair/difference relations. Counts such as 1,392 = 58 x 24 and 19,488 = 58 x 24 x 14 are suggestive but do not prove what any index means. No semantic interpretation should be used in an algorithm until it is checked against every relevant row family and variable domain.

## Problem classification

The safe classification is **large, sparse, highly structured integer linear minimization**. The model appears to contain repeated local linking constraints and a small number of global row templates. It may ultimately reduce to a sequence, assignment, covering, coloring, or permutation construction, but none of these more specific labels is established.

It is also not yet known whether every variable is binary, whether some families are general integer or continuous auxiliaries, or whether the objective is supported on one family or several. Those distinctions determine whether SAT, CP, network/assignment methods, custom branch-and-bound, or constructive local search are appropriate.

## Structural evidence

The following facts come directly from the bounded controller summary:

- Objective sense: minimize.
- Objective offset: zero (reported as `-0.0`).
- Nonzero-right-hand-side rows: 59,708.
- Distinct row signatures: 15.
- The largest families are `w` and `q`, accounting for 77,952 of 84,376 variables.
- `o` and `u` have equal counts, consistent with paired linking roles but not proving them.
- Sample rows show coefficients of magnitude one and indexed repeated equations.
- Sample right-hand sides vary, including 0, 1, 2, 3, 4, and 5.

The dimensions alone suggest repeated blocks and possible decomposition by one or more indices. However, the sample of one 48-term inequality alongside 16-term equations also indicates coupling that may prevent naive independent block solution.

A prior custom parser omitted or mishandled right-hand-side records. Consequently, old row interpretations and all candidates derived from the resulting objective-0 model are unreliable. The controller-owned `model-data.json.gz`, loaded through `model_access.load_model`, is the authoritative structural snapshot for custom work.

## Known results and target bounds

The current controller result reports:

- verified primal bound: none;
- verified dual bound: none;
- strict optimal runs: none;
- strict infeasible runs: none.

Prior notes mention a public or historical incumbent with objective 258 and say it was audited at zero tolerance. That statement is not reflected in the current controller bound fields and is therefore retained only as **unverified provenance pending replay**. It must not be reported as the active primal bound until a candidate file is checked against the original MPS by the controller.

Historical objective-0 candidates are known to be invalid because they relied on the faulty RHS parser. They provide neither a bound nor evidence that zero is attainable.

The immediate numerical target is to recover and independently validate any available 258 candidate. If successful, subsequent targets are either a feasible objective below 258 or a rigorous lower bound approaching 258. If replay is impossible, the first target is simply any controller-verified feasible solution.

## Standard methods for this class

Method choice must follow the exact domains and row templates rather than the instance name.

1. **Exact formulation audit.** Enumerate objective coefficients, domains, bounds, row senses, right-hand sides, support families, and index patterns using `model_access`. This is required before semantic reformulation.
2. **Incumbent replay and validation.** Load an explicit candidate with `read_solution`, evaluate every original snapshot row with `evaluate`, write a normalized `best.sol`, and let the controller check it against the original MPS.
3. **Constraint propagation and constructive search.** If the principal variables are binary or small-domain and the repeated equations determine auxiliaries, eliminate or derive auxiliary families and search only over structural decisions.
4. **Local improvement and repair.** Given a valid incumbent, exploit block structure to perform index-block moves, swaps, or large-neighborhood repair while recomputing all linking variables.
5. **CP or SAT encoding.** Appropriate only after proving that relevant domains and equalities admit an exact finite-domain encoding. Any returned UNSAT/optimal claim requires an operator-recognized proof checker before it is treated as strict proof.
6. **Combinatorial lower bounds.** Covering, packing, assignment, counting, or conflict-graph bounds may become available after the objective and global coupling rows are identified.
7. **Decomposition.** Repeated index blocks invite dynamic programming, Benders-style separation, or branch-and-price only if an exact audit shows that coupling is limited.

A generic custom evaluator should not be introduced initially. The supplied `model_access.evaluate` should remain the reference evaluator; any later specialized incremental evaluator must first reproduce its results on a known assignment and representative modifications.

## Instance-specific opportunities and risks

### Opportunities

- Only 15 row signatures govern nearly 200,000 rows, so a compact algebraic reconstruction may be possible.
- Strong repetition in `w`, `q`, `o`, and `u` may permit auxiliary elimination or fast incremental evaluation.
- Equal family counts and nested count factorisations suggest regular blocks suitable for propagation and large-neighborhood moves.
- If objective coefficients are concentrated on a small family, optimization may be separable from feasibility repair over the large auxiliary families.
- A historical 258 artifact, if actually available, could provide both a useful incumbent and a known assignment for validating future incremental evaluators.

### Risks

- Inferring meanings solely from index counts can produce a mathematically wrong reformulation.
- The prior RHS-parser defect demonstrates that apparently plausible candidates can be artifacts of infrastructure failure.
- Rounded floating-point checks are not exact certificates. Final feasibility must use the original-MPS controller check, and optimality/infeasibility needs an operator-registered checker.
- Symmetry may help search but can also cause enormous redundancy if not identified correctly.
- A 258 value in prose is not a solution artifact and is not an active primal bound.
- Large auxiliary families may hide global consistency conditions; deleting them without a proved projection could admit false candidates.

## Sources

- Controller-provided bounded model data for this handoff: dimensions, family counts, row-signature count, objective sense, RHS count, and sampled rows. This is structural evidence, not an optimality certificate.
- Controller-owned `model-summary.json` and `model-data.json.gz`: authoritative inputs for the next exact audit through `model_access`.
- `prior/final_report.md`, `prior/README.md`, and `prior/result.json`: historical research records. Claims from these files require independent replay or controller verification.
- Prior agent notes supplied in the handoff: useful provenance for the parser failure and the reported value 258, but explicitly not proof.
- No external mathematical source has been established for a semantic identification of `allcolor58`; provenance for any named combinatorial mapping is currently unknown.