"""Archive the finished run without launching API calls or optimization."""
from pathlib import Path
from decimal import Decimal as D
from collections import defaultdict
import gzip, hashlib, json, shutil

campaign = Path(__file__).resolve().parent
run = Path('D:/sufe/code/AI+MIP/allcolor58-research-v3-results/instances/allcolor58/framework-runs/20260905-184627')
state = json.loads((campaign/'allcolor58/state.json').read_text(encoding='utf-8'))
assert state['current_stage'] == 'completed'
controller = run/'controller'
controller.mkdir(exist_ok=True)
for name in ('state.json', 'events', 'jobs'):
    src = campaign/'allcolor58'/name
    if src.is_dir(): shutil.copytree(src, controller/name, dirs_exist_ok=True)
    else: shutil.copy2(src, controller/name)
for name in ('experiment.toml','launch.ps1','CAMPAIGN.md','MONITOR.md','api-smoke.json','controller.stdout.log','controller.stderr.log','framework-source.zip'):
    shutil.copy2(campaign/name, controller/name)

# Independent, narrow original-MPS check: can objective zero satisfy row c1?
obj, row, lower = defaultdict(D), defaultdict(D), defaultdict(D)
section = objective_name = None
rhs = D(0); offset = D(0); row_sense = None
with gzip.open(run/'input/allcolor58.mps.gz','rt') as f:
    for raw in f:
        t=raw.split()
        if not t or t[0].startswith('*'): continue
        if not raw[0].isspace():
            assert t[0] in {'NAME','ROWS','COLUMNS','RHS','BOUNDS','ENDATA'}, t[0]
            section=t[0]; continue
        if section=='ROWS':
            if t[0]=='N':
                assert objective_name is None
                objective_name=t[1]
            if t[1]=='c1': row_sense=t[0]
        elif section=='COLUMNS' and "'MARKER'" not in t:
            for rn, a in zip(t[1::2],t[2::2]):
                if rn==objective_name: obj[t[0]]+=D(a)
                if rn=='c1': row[t[0]]+=D(a)
        elif section=='RHS':
            for rn,a in zip(t[1::2],t[2::2]):
                if rn=='c1': rhs+=D(a)
                if rn==objective_name: offset-=D(a)
        elif section=='BOUNDS':
            kind=t[0]; var=t[2]
            if kind in {'LO','LI','FX'}: lower[var]=D(t[3])
            elif kind in {'FR','MI'}: lower[var]=D('-Infinity')
            else: assert kind in {'UP','UI','BV','PL'},kind
assert row_sense=='G' and rhs==1 and offset==0
assert len(row)==48 and all(a==1 for a in row.values())
assert all(a==1 and obj[v]>=a for v,a in row.items())
assert all(obj[v]-row[v]>=0 and lower[v]>=0 for v in set(obj)|set(row))
obstruction={'original_mps_sha256':hashlib.sha256((run/'input/allcolor58.mps.gz').read_bytes()).hexdigest(),
    'row':'c1','sense':row_sense,'rhs':str(rhs),'term_count':48,
    'objective_dominates_row':True,'objective_offset':str(offset),
    'conclusion':'Objective zero cannot be feasible: objective >= activity(c1) >= 1. This is not optimality or infeasibility of the whole model, nor a claimed improvement over public bounds.'}
(run/'operator-zero-objective-check.json').write_text(json.dumps(obstruction,indent=2)+'\n')
shutil.copy2(Path(__file__),controller/'prepare_audit.py')

jobs=[]
for name, job in state['jobs'].items():
    r=json.loads((run/'runs'/name/'result.json').read_text())
    jobs.append({'id':name,'script':job['script'],'status':r['status'],'runtime_seconds':r['runtime_seconds'],'source_sha256':r['script_sha256']})
search=[a for e in state['events'] for a in e.get('action_results',[]) if a['type']=='search_web']
usage={k:v['usage'] for k,v in state['stages'].items()}
large=[]
for p in run.rglob('*'):
    if p.is_file() and p.stat().st_size>8*1024*1024:
        large.append({'path':p.relative_to(run).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'retention':'retained locally; excluded from Git publication'})
summary={'usage':usage,'jobs':jobs,'total_runtime_seconds':sum(j['runtime_seconds'] for j in jobs),'web_search_attempts':len(search),'web_search_failures':sum(not a['ok'] for a in search),'large_local_artifacts':large}
(run/'operator-audit-data.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
