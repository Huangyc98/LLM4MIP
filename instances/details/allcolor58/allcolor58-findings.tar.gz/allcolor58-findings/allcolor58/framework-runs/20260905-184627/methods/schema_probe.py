from model_access import load_model
D=load_model()
print(type(D), list(D.keys()) if isinstance(D,dict) else dir(D)[:30])
V=D['variables'] if isinstance(D,dict) else D.variables
R=D['rows'] if isinstance(D,dict) else D.rows
print('V/R',type(V),len(V),type(R),len(R))
for x in V[:2]: print('VITEM',type(x),repr(x))
for x in R[:2]: print('RITEM',type(x),repr(x))
