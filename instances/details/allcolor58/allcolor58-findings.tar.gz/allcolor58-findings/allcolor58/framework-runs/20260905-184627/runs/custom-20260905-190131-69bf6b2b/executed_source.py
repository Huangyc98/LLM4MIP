from model_access import load_model
from collections import Counter,defaultdict
import re,json
D=load_model(); V=D.variables; R=D.rows

def fam(name): return name.split('(')[0]
def sig(r):
    fc=Counter(); cc=Counter(); by=defaultdict(Counter)
    for j,a in r.terms:
        f=fam(V[j].name); fc[f]+=1; cc[a]+=1; by[f][a]+=1
    return (r.sense,r.rhs,tuple(sorted(fc.items())),tuple(sorted(cc.items())),tuple((f,tuple(sorted(c.items()))) for f,c in sorted(by.items())))
def expr(r,lim=40):
    z=[]
    for j,a in r.terms[:lim]: z.append(f'{a}*{V[j].name}')
    if len(r.terms)>lim:z.append(f'...({len(r.terms)-lim} more)')
    return ' + '.join(z)+f' {r.sense} {r.rhs}'
g=defaultdict(list)
for i,r in enumerate(R): g[sig(r)].append(i)
# variable family summaries and occurrence signatures
vf=defaultdict(list)
for i,v in enumerate(V): vf[fam(v.name)].append(i)
occ=[Counter() for _ in V]
for r in R:
    fs=tuple(sorted(Counter(fam(V[j].name) for j,a in r.terms).items()))
    for j,a in r.terms: occ[j][(r.sense,r.rhs,a,fs)]+=1
out={'size':[len(V),len(R)],'families':{},'templates':[]}
for f,ids in sorted(vf.items()):
    out['families'][f]={'n':len(ids),'types':dict(Counter(V[i].vtype for i in ids)),'bounds':[[list(k),n] for k,n in Counter((V[i].lb,V[i].ub) for i in ids).most_common()],'obj':[[k,n] for k,n in Counter(V[i].obj for i in ids).most_common()]}
for s,ids in sorted(g.items(),key=lambda kv:(-len(kv[1]),str(kv[0]))):
    reps=ids[:3]
    out['templates'].append({'count':len(ids),'signature':str(s),'row_indices':reps,'row_names':[R[i].name for i in reps],'examples':[expr(R[i]) for i in reps]})
# exact support for unfixed o and rows involving o, compact
os=[]
for i in vf['o']:
    if V[i].ub!='0.0': os.append(V[i].name)
out['o_support']=os
orows=[]
for i,r in enumerate(R):
    if any(fam(V[j].name)=='o' for j,a in r.terms): orows.append({'i':i,'name':r.name,'expr':expr(r,80)})
out['o_rows']=orows
# x/y-only and short coupling rows useful for semantics
special=[]
for i,r in enumerate(R):
    fs=set(fam(V[j].name) for j,a in r.terms)
    if len(r.terms)<=18 and (fs<=set(['x','y','t']) or fs<=set(['o','u']) or fs<=set(['o','y']) or fs<=set(['x','v'])):
        special.append({'i':i,'name':r.name,'expr':expr(r,30)})
out['special_rows']=special[:3000]
with open('templates.json','w') as f: json.dump(out,f,indent=2)
with open('method_result.json','w') as f: json.dump({'algorithm_family':'structural decomposition','algorithm_role':'diagnostic','hypothesis':'Rows collapse to a small number of semantic algebraic templates','positive_work_units':len(R),'termination_reason':'completed','status':'ok'},f)
print('templates',len(g),'o support',len(os),'o rows',len(orows),'special',len(special))
print('TOP')
for z in out['templates'][:40]: print(z['count'],z['signature'],z['examples'][0][:500])
