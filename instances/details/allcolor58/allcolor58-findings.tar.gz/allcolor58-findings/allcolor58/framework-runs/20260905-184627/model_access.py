"""Read-only Gurobi linear-model snapshot access, also shipped to CPU jobs.

This is a diagnostic/search interface, NOT a proof checker: Gurobi stores
floating-point coefficients. Final acceptance always checks the original MPS.
No solver dependency, network, or optimization is used by this module.
"""
from __future__ import annotations

from collections import Counter
from decimal import Decimal, localcontext
import gzip
import json
from pathlib import Path
import re


def load_model(path="/resources/model-data.json.gz"):
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        data = json.load(handle)
    if data.get("schema_version") != 1 or not data.get("supported"):
        raise ValueError("A complete supported linear-model snapshot is required")
    variables, rows = data["variables"], data["rows"]
    if len(variables) != data["counts"]["variables"] or len(rows) != data["counts"]["rows"]:
        raise ValueError("Snapshot count mismatch")
    if sum(len(r["terms"]) for r in rows) != data["counts"]["nonzeros"]:
        raise ValueError("Snapshot nonzero count mismatch")
    for row in rows:
        if row["sense"] not in {"<", ">", "="}:
            raise ValueError("Unsupported row sense")
        for i, coefficient in row["terms"]:
            if not isinstance(i, int) or not 0 <= i < len(variables):
                raise ValueError("Invalid column index")
            if not Decimal(coefficient).is_finite():
                raise ValueError("Nonfinite coefficient")
    return data


def read_solution(path):
    """Sparse name/value .sol; missing entries mean zero. Reject duplicates."""
    values = {}
    opener = gzip.open if str(path).endswith(".gz") else open
    with opener(path, "rt", encoding="utf-8") as handle:
        for line in handle:
            fields = line.split()
            if not fields or fields[0].startswith(("#", "=")):
                continue
            if len(fields) != 2:
                raise ValueError("Expected a name/value solution record")
            name, raw = fields
            value = Decimal(raw.replace("D", "E").replace("d", "e"))
            if name in values or not value.is_finite():
                raise ValueError("Duplicate variable or nonfinite solution value")
            values[name] = value
    return values


def evaluate(data, values, tolerance="0"):
    """Diagnostic evaluation; never authorizes a proof or replaces MPS checking."""
    with localcontext() as context:
        context.prec = 80
        tol = Decimal(tolerance)
        if not tol.is_finite() or tol < 0:
            raise ValueError("Invalid tolerance")
        unknown = set(values) - {v["name"] for v in data["variables"]}
        if unknown:
            raise ValueError("Solution contains unknown variables")
        x = [Decimal(str(values.get(v["name"], 0))) for v in data["variables"]]
        if any(not a.is_finite() for a in x):
            raise ValueError("Nonfinite solution value")
        bounds = integers = rows = 0
        max_row = Decimal(0)
        objective = Decimal(data["objective_offset"])
        for v, value in zip(data["variables"], x):
            objective += Decimal(v["obj"]) * value
            bounds += value < Decimal(v["lb"]) - tol or value > Decimal(v["ub"]) + tol
            integers += v["type"] in {"B", "I"} and abs(value - value.to_integral_value()) > tol
        for row in data["rows"]:
            lhs = sum((Decimal(a) * x[i] for i, a in row["terms"]), Decimal(0))
            delta = lhs - Decimal(row["rhs"])
            violation = abs(delta) if row["sense"] == "=" else max(Decimal(0), delta if row["sense"] == "<" else -delta)
            rows += violation > tol
            max_row = max(max_row, violation)
        return {"diagnostic_only": True, "objective": str(objective),
                "row_violations": rows, "bound_violations": bounds,
                "integrality_violations": integers, "max_row_violation": str(max_row),
                "feasible_in_snapshot": not (rows or bounds or integers)}


def family(name):
    return re.split(r"[([]", name, maxsplit=1)[0]


def query(data, kind="rows", prefix="", offset=0, limit=4, term_limit=24):
    if kind not in {"rows", "variables"}:
        raise ValueError("kind must be rows or variables")
    offset, limit = max(0, int(offset)), max(1, min(8, int(limit)))
    matches = [v for v in data[kind] if v["name"].startswith(prefix)]
    selected = []
    for item in matches[offset:offset + limit]:
        record = dict(item)
        if "terms" in record:
            record["term_count"] = len(item["terms"])
            record["terms"] = [[data["variables"][i]["name"], a] for i, a in item["terms"][:term_limit]]
            record["terms_truncated"] = len(item["terms"]) > term_limit
        selected.append(record)
    return {"kind": kind, "prefix": prefix, "total_matches": len(matches), "items": selected,
            "offset": offset, "next_offset": offset + len(selected),
            "eof": offset + len(selected) >= len(matches)}


def summarize(data):
    families = Counter(family(v["name"]) for v in data["variables"])
    # Sample different equation signatures, not thousands of contiguous blocks.
    seen, samples = set(), []
    for row in data["rows"]:
        signature = (row["sense"], row["rhs"], tuple(sorted(Counter(
            (family(data["variables"][i]["name"]), a) for i, a in row["terms"]
        ).items())))
        if signature in seen:
            continue
        seen.add(signature)
        if len(samples) < 8:
            samples.append({"name": row["name"], "sense": row["sense"], "rhs": row["rhs"],
                            "term_count": len(row["terms"]),
                            "terms": [[data["variables"][i]["name"], a] for i, a in row["terms"][:8]],
                            "terms_truncated": len(row["terms"]) > 8})
    return {"counts": data["counts"], "sense": data["sense"],
            "objective_offset": data["objective_offset"],
            "nonzero_rhs_count": sum(Decimal(r["rhs"]) != 0 for r in data["rows"]),
            "variable_families": families.most_common(30), "family_count": len(families),
            "distinct_row_signatures": len(seen), "row_samples": samples,
            "note": "Bounded diagnostic view. Full coefficients are in model-data.json.gz. Use model_access; do not reimplement MPS parsing. Snapshot numeric data are not an exact proof."}
