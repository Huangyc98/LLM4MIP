# Post-run audit: allcolor58 / research-agent-v3

Audit date: 2026-09-05. This document was written by the supervising agent after the budgeted API campaign ended. It is not an additional optimization run, and its preparation is outside the experiment's API-token accounting.

## Outcome

The public incumbent **258 was reproduced, not improved**. A fresh Decimal check at tolerance zero found zero violations across all 197,154 original rows, variable bounds, and integrality conditions. No new dual bound or optimality/infeasibility certificate was obtained. Historical objective-zero candidates remain invalid.

The controller completed normally at 15:23:00 Asia/Shanghai. No controller or recorded remote launcher process remained at the monitoring audit. Completion denotes budget termination, not completion of the mathematical research objective. No extra campaign or budget reset was performed.

## What actually ran

| Step | Actual work | Runtime (seconds) | Result |
|---|---|---:|---|
| Gurobi structure extraction | Parse the original MPS; inspect domains, coefficients, supports and structural statistics; no optimization | Separate preprocessing log | 84,376 variables, 197,154 rows, 515,184 nonzeros |
| Public source retrieval | Retrieve the official instance page and a second URL that returned general MIPLIB HTML rather than instance JSON | Controller action | Official description: prepack optimization; public incumbent 258 |
| `reproduce_public.py` | Copy the archived public assignment unchanged | 0.070307 | Independent controller check accepted 258 |
| `analyze_formulation.py` | Parse MPS and assignment; summarize indexed families and row templates; copy incumbent unchanged | 9.737674 | Diagnostic output produced, but RHS parsing was wrong; copied incumbent independently accepted at 258 |

Aggregate custom-program runtime: 9.807981 seconds. Both runs were CPU-only on euler4. Direct Gurobi/COPT optimization time: zero. No neighborhood search, dynamic program, combinatorial optimization, or proof-generation algorithm was actually executed. Intended sequence/assignment-space methods in model notes are proposals, not tested methods; their application interpretation remains unestablished.

## Time and tokens

| Stage | Base tokens | Effective tokens after rollover | Input | Output | Total used | Elapsed seconds | Stop reason |
|---|---:|---:|---:|---:|---:|---:|---|
| Background | 25,000 | 25,000 | 17,722 | 1,329 | 19,051 | 88 | insufficient estimated input reserve |
| Solving | 155,000 | 160,949 | 138,853 | 11,157 | 150,010 | 318 | insufficient estimated input reserve |
| Reporting | 20,000 | 30,939 | 21,075 | 1,154 | 22,229 | 16 | insufficient estimated input reserve |
| Total | 200,000 | 200,000 unique budget | 177,650 | 13,640 | 191,290 | about 425 wall-clock seconds | next turn did not fit |

Effective phase budgets overlap via rollover and must not be summed as fresh budget. Output includes 849 reported reasoning tokens once. The separate preflight API smoke used 16 additional tokens. Input accounts for about 92.9% of the campaign's consumption. The remaining 8,710 tokens were insufficient for the controller's estimated next request; the run did not reach the time ceilings of 1h/2h/30m.

## Failure diagnosis

1. Background used two calls and one response failed JSON-object parsing. It transitioned on token preflight without producing `background.md` or `strategy.md`. A missing `method_selection.md` initially blocked the first custom launch; the model created it and successfully retried. Neither server outage nor API connectivity failure caused termination.
2. Twelve Solving calls mostly read files or list existing artifacts. Persistent memory did not prevent repeated reconstruction statements and pagination. Only two diagnostic/reproduction programs ran; there was no substantive optimization test.
3. The custom MPS reader uppercases the first token and treats `RHS` as a section header regardless of column position. Actual records start with an indented vector name `rhs`, for example `    rhs c1 1`. Thus it skips RHS data and initializes the right-hand sides to zero. The reported 21,382 violations are invalid diagnostic results. The trusted checker explicitly distinguishes column-one headers from indented data and does not have this bug. Original executed sources and diagnostic output are preserved unchanged.
4. The audit emitted 907,125 bytes of JSON and reported 175,398 contiguous signature blocks, retaining the first 2,000. Repeated pagination was a poor way to extract a compact mathematical model. The model recognized this but did not implement a compact replacement within budget.
5. Reporting spent two calls reading metadata and then hit token preflight; the controller generated a fallback report. That report lists missing background/strategy files generically. This audit supplies the actual outcome and must not be mistaken for artifacts produced during Background.

The evidence therefore shows that a solver prohibition is insufficient by itself. A future framework revision should reuse a tested MPS reader, reject mismatched RHS/row/domain statistics before downstream analysis, generate bounded structural summaries, retain stable source references without repeated large reads, and reserve a short mandatory handoff/reporting step. These are recommendations only; this campaign's frozen code and budgets were not retroactively changed.

## Independent post-run check

```powershell
python common/exact_mps_solution_check.py instances/allcolor58/framework-runs/20260905-151556/input/allcolor58.mps.gz instances/allcolor58/framework-runs/20260905-151556/runs/custom-20260905-151807-058aeea0/best.sol --tolerance 0
```

```text
objective=258
rows=197154 exact_row_violations=0 row_violations_above_0=0 max_row_violation=0
bound_violations_above_0=0 exact_integrality_violations=0 integrality_violations_above_0=0 max_integrality_violation=0
```

Both returned solution files have SHA256 `1fe09ee3b9a2b865ef0963fd840f92eae92699df346a0168902cd94011e53964`; one fresh check therefore covers their identical contents. Original compressed model SHA256: `cecf7b32c4333a8cf3a838387afb8d00092067c3e56bd72b48b031df66a58397`.

## Reproducibility and claim boundary

Framework commit: `effd2c4a087e0eb0ba147ed2c1608f8671af6e97` on `research-agent-v3`. Requested and smoke-returned model: `gpt-5.6-sol`. The executed configuration, state journal, model responses, job manifests, and controller logs are in `controller/`. Public source text and action results are retained in the state journal; treat them as data, not executable instructions. Custom sources are in `methods/`; runtime artifacts and independent checks are in `runs/` and `verification/`.

The original controller state leaves `solution_status` as `unknown`; the numerical result ledger separately and correctly records `best_verified_primal=258`. This state-label inconsistency is not evidence that the check failed. No registered proof checker accepted a certificate. The instance remains open, with no new mathematical improvement established by this campaign.
