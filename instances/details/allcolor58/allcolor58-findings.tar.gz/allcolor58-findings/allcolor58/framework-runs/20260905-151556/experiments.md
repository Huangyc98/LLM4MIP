# Experiment ledger

This file is generated from `runs/*/result.json` by the controller.

| Run | Solver | Status | Primal | Dual | Gap | Verified | Runtime (s) |
|---|---|---|---:|---:|---:|---|---:|
| `custom-20260905-151807-058aeea0` | custom-python | candidate_feasible | 258 | — | — | yes @ 1e-9 | 0.0703067779541016 |
| `custom-20260905-151944-82590cda` | custom-python | completed | 258 | — | — | yes @ 1e-9 | 9.73767399787903 |
