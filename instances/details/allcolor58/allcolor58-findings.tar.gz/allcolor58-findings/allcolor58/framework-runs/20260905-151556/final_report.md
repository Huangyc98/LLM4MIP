# Final report: allcolor58

> Post-run audit: this was an incomplete research trial, not an optimization success. The public incumbent 258 was reproduced with zero violations, but no improvement, new dual bound, or proof was obtained. The campaign used 191,290 tokens in about 7 minutes, mostly repeated input; only reproduction and a flawed structural diagnostic ran. See [operator-audit.md](operator-audit.md) for the verified outcome, parser bug, missing artifacts, and actual attempts. The generic artifact list below includes `background.md` and `strategy.md`, which were not produced.

This baseline report was generated deterministically by the experiment controller.

## Outcome

- Status: `feasible_verified_at_tolerance`
- Best solver-accepted primal: `258`
- Best tolerance-verified primal: `258`
- Best dual bound: `—`
- Combined relative gap: `—`
- Solvers used: `custom-python`

A solver-accepted feasible point is not described as strictly verified unless the
separate Decimal check succeeded. A time limit is not an optimality or infeasibility proof.

## Budget

| Stage | Base tokens | Effective tokens | Used | Elapsed / limit (s) | Turns | Finish reason |
|---|---:|---:|---:|---:|---:|---|
| background | 25000 | 25000 | 19051 | 88 / 3600 | 2 | insufficient_estimated_input_reserve |
| solving | 155000 | 160949 | 150010 | 318 / 7200 | 12 | insufficient_estimated_input_reserve |
| reporting | 20000 | 30939 | 22229 | 16 / 1800 | 2 | insufficient_estimated_input_reserve |

## Reproducibility

See `experiments.md`, `experiments.json`, `structure.json`, `background.md`,
`strategy.md`, `verification/`, and the individual directories under `runs/`.
