#!/usr/bin/env python3
"""Independent exact audit of an allcolor58 sparse solution.

This checker deliberately does not call the compact-search implementation or
Gurobi.  It performs two separate checks:

1. Stream the original MPS and evaluate every row, bound, integrality
   requirement, and objective coefficient using Decimal arithmetic.
2. Decode only y, x, o, and u from the sparse solution and reconstruct the
   prepack shipments sum_b y[b,i] x[b,s] directly.  This also verifies the
   parity lower bound used to certify objective 42.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import re
from collections import Counter, defaultdict
from decimal import Decimal
from pathlib import Path


NB = 14
NI = 24
NS = 58
CAPACITIES = {4, 6, 8, 10}
INDEXED = re.compile(r"^([a-z])\((\d+),(\d+)\)$")
SECTIONS = {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}


def open_text(path: Path):
    if path.suffix == ".gz":
        return gzip.open(path, "rt", encoding="latin-1")
    return path.open("rt", encoding="latin-1")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def read_sparse_solution(path: Path) -> tuple[Decimal, dict[str, Decimal]]:
    claimed = None
    values: dict[str, Decimal] = {}
    with open_text(path) as stream:
        for raw in stream:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            fields = line.split()
            if fields[0] == "=obj=":
                if claimed is not None:
                    raise AssertionError("duplicate claimed objective")
                claimed = Decimal(fields[1])
                continue
            if len(fields) < 2:
                raise AssertionError(f"malformed solution line: {line}")
            variable, value = fields[0], Decimal(fields[1])
            if variable in values:
                raise AssertionError(f"duplicate solution variable {variable}")
            values[variable] = value
    if claimed is None:
        raise AssertionError("solution has no =obj= line")
    return claimed, values


def audit_original_mps(path: Path, sparse: dict[str, Decimal]) -> dict:
    """Evaluate a sparse solution against the original MPS in one pass."""
    section = None
    name = None
    objective_row = None
    row_sense: dict[str, str] = {}
    rhs: dict[str, Decimal] = {}
    activities: dict[str, Decimal] = defaultdict(Decimal)
    objective = Decimal(0)
    variables: set[str] = set()
    integer_variables: set[str] = set()
    # Missing entries have the ordinary MPS defaults 0 <= variable <= +inf.
    lower: dict[str, Decimal | None] = {}
    upper: dict[str, Decimal | None] = {}
    integer_mode = False
    rhs_vector = None
    saw_ranges = False
    nonzeros = 0

    with open_text(path) as stream:
        for raw in stream:
            line = raw.strip()
            if not line or line.startswith("*"):
                continue
            tokens = line.split()
            head = tokens[0].upper()
            if not raw[0].isspace() and head in SECTIONS:
                section = head
                if head == "NAME":
                    name = tokens[1]
                elif head == "RANGES":
                    saw_ranges = True
                elif head == "ENDATA":
                    break
                continue

            if section == "ROWS":
                sense, row = tokens
                if row in row_sense:
                    raise AssertionError(f"duplicate row {row}")
                row_sense[row] = sense
                if sense == "N":
                    if objective_row is not None:
                        raise AssertionError("multiple objective rows")
                    objective_row = row
                continue

            if section == "COLUMNS":
                clean = [token.strip("'\"") for token in tokens]
                if "MARKER" in clean:
                    if "INTORG" in clean:
                        integer_mode = True
                    elif "INTEND" in clean:
                        integer_mode = False
                    else:
                        raise AssertionError(f"unknown integer marker: {line}")
                    continue
                variable = tokens[0]
                variables.add(variable)
                if integer_mode:
                    integer_variables.add(variable)
                value = sparse.get(variable, Decimal(0))
                for pos in range(1, len(tokens), 2):
                    row, coefficient = tokens[pos], Decimal(tokens[pos + 1])
                    nonzeros += 1
                    if row == objective_row:
                        objective += coefficient * value
                    else:
                        if row not in row_sense:
                            raise AssertionError(f"coefficient for unknown row {row}")
                        if value:
                            activities[row] += coefficient * value
                continue

            if section == "RHS":
                vector = tokens[0]
                if rhs_vector is None:
                    rhs_vector = vector
                if vector != rhs_vector:
                    raise AssertionError("multiple RHS vectors")
                for pos in range(1, len(tokens), 2):
                    row, value = tokens[pos], Decimal(tokens[pos + 1])
                    if row in rhs:
                        raise AssertionError(f"duplicate RHS entry for {row}")
                    rhs[row] = value
                continue

            if section == "BOUNDS":
                kind, _vector, variable, *rest = tokens
                variables.add(variable)
                value = Decimal(rest[0]) if rest else None
                if kind in {"LO", "LI"}:
                    assert value is not None
                    lower[variable] = value
                    if kind == "LI":
                        integer_variables.add(variable)
                elif kind in {"UP", "UI"}:
                    assert value is not None
                    upper[variable] = value
                    if kind == "UI":
                        integer_variables.add(variable)
                elif kind == "FX":
                    assert value is not None
                    lower[variable] = upper[variable] = value
                elif kind == "FR":
                    lower[variable] = upper[variable] = None
                elif kind == "MI":
                    lower[variable] = None
                elif kind == "PL":
                    upper[variable] = None
                elif kind == "BV":
                    lower[variable] = Decimal(0)
                    upper[variable] = Decimal(1)
                    integer_variables.add(variable)
                else:
                    raise AssertionError(f"unsupported bound kind {kind}")

    if saw_ranges:
        raise AssertionError("RANGES section is not supported")
    if name != "allcolor58" or objective_row is None:
        raise AssertionError(f"unexpected model identity: {name}, objective={objective_row}")
    unknown = sorted(set(sparse) - variables)
    if unknown:
        raise AssertionError(f"solution contains unknown variables: {unknown[:5]}")

    max_bound_violation = Decimal(0)
    max_integrality_violation = Decimal(0)
    for variable in variables:
        value = sparse.get(variable, Decimal(0))
        lo = lower.get(variable, Decimal(0))
        hi = upper.get(variable, None)
        if lo is not None:
            max_bound_violation = max(max_bound_violation, lo - value)
        if hi is not None:
            max_bound_violation = max(max_bound_violation, value - hi)
        if variable in integer_variables:
            max_integrality_violation = max(
                max_integrality_violation,
                abs(value - value.to_integral_value()),
            )

    sense_counts = Counter()
    min_slack: Decimal | None = None
    max_equality_residual = Decimal(0)
    violated: list[dict] = []
    for row, sense in row_sense.items():
        if sense == "N":
            continue
        sense_counts[sense] += 1
        activity = activities.get(row, Decimal(0))
        target = rhs.get(row, Decimal(0))
        if sense == "E":
            residual = activity - target
            max_equality_residual = max(max_equality_residual, abs(residual))
            slack = -abs(residual)
            bad = residual != 0
        elif sense == "G":
            slack = activity - target
            bad = slack < 0
        elif sense == "L":
            slack = target - activity
            bad = slack < 0
        else:
            raise AssertionError(f"unknown row sense {sense}")
        min_slack = slack if min_slack is None else min(min_slack, slack)
        if bad and len(violated) < 20:
            violated.append(
                {"row": row, "sense": sense, "activity": str(activity), "rhs": str(target)}
            )

    return {
        "name": name,
        "variables": len(variables),
        "integer_variables": len(integer_variables),
        "rows": sum(sense != "N" for sense in row_sense.values()),
        "row_senses": dict(sorted(sense_counts.items())),
        "matrix_entries": nonzeros,
        "computed_objective": str(objective),
        "max_bound_violation": str(max_bound_violation),
        "max_integrality_violation": str(max_integrality_violation),
        "max_equality_residual": str(max_equality_residual),
        "minimum_signed_slack": str(min_slack),
        "violated_rows": violated,
        # Retain these for the independent semantic check, then remove before JSON.
        "_rhs": rhs,
        "_lower": lower,
        "_upper": upper,
    }


def exact_integer(value: Decimal, variable: str) -> int:
    if value != value.to_integral_value():
        raise AssertionError(f"nonintegral {variable}={value}")
    return int(value)


def semantic_audit(
    sparse: dict[str, Decimal],
    rhs: dict[str, Decimal],
    lower: dict[str, Decimal | None],
    upper: dict[str, Decimal | None],
) -> dict:
    """Reconstruct prepack shipments without using the search implementation."""
    y = [[0] * NI for _ in range(NB)]
    x = [[0] * NS for _ in range(NB)]
    stated_o = [[0] * NS for _ in range(NI)]
    stated_u = [[0] * NS for _ in range(NI)]

    for variable, raw_value in sparse.items():
        match = INDEXED.fullmatch(variable)
        if not match:
            continue
        kind, first_text, second_text = match.groups()
        first, second = int(first_text), int(second_text)
        value = exact_integer(raw_value, variable)
        if kind == "y":
            if not (1 <= first <= NB and 1 <= second <= NI):
                raise AssertionError(f"bad y index {variable}")
            y[first - 1][second - 1] = value
        elif kind == "x":
            if not (1 <= first <= NB and 1 <= second <= NS):
                raise AssertionError(f"bad x index {variable}")
            x[first - 1][second - 1] = value
        elif kind == "o":
            if not (1 <= first <= NI and 1 <= second <= NS):
                raise AssertionError(f"bad o index {variable}")
            stated_o[first - 1][second - 1] = value
        elif kind == "u":
            if not (1 <= first <= NI and 1 <= second <= NS):
                raise AssertionError(f"bad u index {variable}")
            stated_u[first - 1][second - 1] = value

    capacities = [sum(row) for row in y]
    if any(capacity not in CAPACITIES for capacity in capacities):
        raise AssertionError(f"invalid configuration capacities {capacities}")
    if any(value < 0 or value > 10 for row in y for value in row):
        raise AssertionError("y bound violation")
    if any(value < 0 or value > 7 for row in x for value in row):
        raise AssertionError("x bound violation")

    demand = [[0] * NS for _ in range(NI)]
    for product in range(NI):
        for store in range(NS):
            row = f"c{43 + product * NS + store}"
            # An omitted MPS RHS entry is exactly zero.
            value = rhs.get(row, Decimal(0))
            if value != value.to_integral_value():
                raise AssertionError(f"nonintegral demand RHS {row}")
            demand[product][store] = int(value)

    overstock_limits = [[0] * NS for _ in range(NI)]
    for product in range(NI):
        for store in range(NS):
            variable = f"o({product + 1},{store + 1})"
            lo = lower.get(variable, Decimal(0))
            hi = upper.get(variable, None)
            if lo != 0 or hi is None or hi != hi.to_integral_value():
                raise AssertionError(f"unexpected o bounds for {variable}: {lo},{hi}")
            overstock_limits[product][store] = int(hi)

    computed_o = [[0] * NS for _ in range(NI)]
    computed_u = [[0] * NS for _ in range(NI)]
    store_costs = [0] * NS
    store_mismatch_counts = [0] * NS
    semantic_mismatches: list[str] = []
    for product in range(NI):
        for store in range(NS):
            shipped = sum(y[config][product] * x[config][store] for config in range(NB))
            difference = shipped - demand[product][store]
            computed_o[product][store] = max(difference, 0)
            computed_u[product][store] = max(-difference, 0)
            if computed_o[product][store] > overstock_limits[product][store]:
                semantic_mismatches.append(
                    f"overstock limit product {product + 1}, store {store + 1}"
                )
            if computed_o[product][store] != stated_o[product][store]:
                semantic_mismatches.append(
                    f"o mismatch product {product + 1}, store {store + 1}"
                )
            if computed_u[product][store] != stated_u[product][store]:
                semantic_mismatches.append(
                    f"u mismatch product {product + 1}, store {store + 1}"
                )
            if difference:
                store_mismatch_counts[store] += 1
            store_costs[store] += max(difference, 0) + 10 * max(-difference, 0)

    if semantic_mismatches:
        raise AssertionError("; ".join(semantic_mismatches[:10]))

    demand_totals = [sum(demand[p][s] for p in range(NI)) for s in range(NS)]
    shipment_totals = [
        sum(capacities[b] * x[b][s] for b in range(NB)) for s in range(NS)
    ]
    odd_stores = [s + 1 for s, total in enumerate(demand_totals) if total % 2]
    if any(total % 2 for total in shipment_totals):
        raise AssertionError("an achieved shipment total is odd despite even capacities")
    parity_lower_bound = len(odd_stores)
    semantic_objective = sum(store_costs)
    exact_at_parity = sum(
        cost == demand_totals[s] % 2 for s, cost in enumerate(store_costs)
    )
    if exact_at_parity != NS:
        raise AssertionError(f"only {exact_at_parity}/{NS} stores attain parity minimum")

    return {
        "capacities": capacities,
        "odd_demand_stores": len(odd_stores),
        "odd_store_indices": odd_stores,
        "all_shipment_totals_even": True,
        "parity_lower_bound": parity_lower_bound,
        "computed_objective": semantic_objective,
        "computed_overstock": sum(map(sum, computed_o)),
        "computed_understock": sum(map(sum, computed_u)),
        "stores_at_parity_minimum": exact_at_parity,
        "mismatching_product_count_histogram": dict(
            sorted(Counter(store_mismatch_counts).items())
        ),
        "store_cost_histogram": dict(sorted(Counter(store_costs).items())),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    claimed, sparse = read_sparse_solution(args.solution)
    mps_audit = audit_original_mps(args.mps, sparse)
    semantic = semantic_audit(
        sparse,
        mps_audit.pop("_rhs"),
        mps_audit.pop("_lower"),
        mps_audit.pop("_upper"),
    )
    result = {
        "model": str(args.mps),
        "model_sha256": sha256(args.mps),
        "solution": str(args.solution),
        "solution_sha256": sha256(args.solution),
        "claimed_objective": str(claimed),
        "nonzero_solution_entries": sum(value != 0 for value in sparse.values()),
        "original_mps_audit": mps_audit,
        "independent_semantic_audit": semantic,
        "conclusion": (
            "PASS: feasible objective-42 witness and matching parity lower bound"
            if claimed == 42
            and Decimal(mps_audit["computed_objective"]) == 42
            and not mps_audit["violated_rows"]
            and Decimal(mps_audit["max_bound_violation"]) <= 0
            and Decimal(mps_audit["max_integrality_violation"]) == 0
            and semantic["computed_objective"] == semantic["parity_lower_bound"] == 42
            else "FAIL"
        ),
    }
    rendered = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.write_text(rendered, encoding="utf-8")
    print(rendered, end="")
    if not result["conclusion"].startswith("PASS"):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
