import argparse, gzip, json, math, os, random, time
from collections import defaultdict


def open_model(path):
    with open(path, 'rb') as f:
        magic = f.read(2)
    if magic == b'\x1f\x8b':
        return gzip.open(path, 'rt', encoding='utf-8', errors='replace')
    return open(path, 'rt', encoding='utf-8', errors='replace')


def number(s):
    return float(s.replace('D', 'E').replace('d', 'e'))


def parse_mps(path):
    section = None
    obj_sense = 'min'
    row_type = {}
    row_order = []
    objective_rows = []
    col = defaultdict(lambda: defaultdict(float))
    variables = []
    seen_var = set()
    integer_marked = set()
    marker_integer = False
    rhs_sets = defaultdict(dict)
    range_sets = defaultdict(dict)
    chosen_rhs = None
    chosen_range = None
    bounds_records = []
    objective_name = None
    line_count = 0
    with open_model(path) as f:
        for raw in f:
            line_count += 1
            if not raw.strip() or raw.lstrip().startswith('*'):
                continue
            tok = raw.split()
            if not tok:
                continue
            head = tok[0].upper()
            if head in ('NAME','OBJSENSE','OBJNAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA'):
                section = head
                if head == 'ENDATA':
                    break
                if head == 'NAME':
                    section = 'NAME'
                continue
            if section == 'OBJSENSE':
                if head.startswith('MAX'):
                    obj_sense = 'max'
                elif head.startswith('MIN'):
                    obj_sense = 'min'
            elif section == 'OBJNAME':
                objective_name = tok[0]
            elif section == 'ROWS':
                if len(tok) >= 2:
                    typ, name = tok[0].upper(), tok[1]
                    row_type[name] = typ
                    row_order.append(name)
                    if typ == 'N':
                        objective_rows.append(name)
            elif section == 'COLUMNS':
                joined = ' '.join(tok).upper()
                if 'MARKER' in joined:
                    if 'INTORG' in joined:
                        marker_integer = True
                    elif 'INTEND' in joined:
                        marker_integer = False
                    continue
                if len(tok) < 3:
                    continue
                var = tok[0]
                if var not in seen_var:
                    seen_var.add(var); variables.append(var)
                if marker_integer:
                    integer_marked.add(var)
                pairs = tok[1:]
                for k in range(0, len(pairs)-1, 2):
                    r = pairs[k]
                    try:
                        a = number(pairs[k+1])
                    except ValueError:
                        continue
                    col[var][r] += a
            elif section == 'RHS':
                if len(tok) < 3:
                    continue
                setname = tok[0]
                if chosen_rhs is None:
                    chosen_rhs = setname
                if setname != chosen_rhs:
                    continue
                pairs = tok[1:]
                for k in range(0, len(pairs)-1, 2):
                    try:
                        rhs_sets[setname][pairs[k]] = number(pairs[k+1])
                    except ValueError:
                        pass
            elif section == 'RANGES':
                if len(tok) < 3:
                    continue
                setname = tok[0]
                if chosen_range is None:
                    chosen_range = setname
                if setname != chosen_range:
                    continue
                pairs = tok[1:]
                for k in range(0, len(pairs)-1, 2):
                    try:
                        range_sets[setname][pairs[k]] = number(pairs[k+1])
                    except ValueError:
                        pass
            elif section == 'BOUNDS':
                if len(tok) >= 3:
                    typ, setname, var = tok[0].upper(), tok[1], tok[2]
                    val = number(tok[3]) if len(tok) >= 4 else None
                    bounds_records.append((typ, var, val))
                    if var not in seen_var:
                        seen_var.add(var); variables.append(var)
    if objective_name is None and objective_rows:
        objective_name = objective_rows[0]
    rhs = rhs_sets[chosen_rhs] if chosen_rhs is not None else {}
    ranges = range_sets[chosen_range] if chosen_range is not None else {}
    lb = {v: 0.0 for v in variables}
    ub = {v: math.inf for v in variables}
    is_int = {v: (v in integer_marked) for v in variables}
    for typ, v, val in bounds_records:
        if v not in lb:
            lb[v] = 0.0; ub[v] = math.inf; is_int[v] = False; variables.append(v)
        if typ == 'LO': lb[v] = val
        elif typ == 'UP': ub[v] = val
        elif typ == 'FX': lb[v] = val; ub[v] = val
        elif typ == 'FR': lb[v] = -math.inf; ub[v] = math.inf
        elif typ == 'MI': lb[v] = -math.inf
        elif typ == 'PL': ub[v] = math.inf
        elif typ == 'BV': lb[v] = 0.0; ub[v] = 1.0; is_int[v] = True
        elif typ == 'LI': lb[v] = val; is_int[v] = True
        elif typ == 'UI': ub[v] = val; is_int[v] = True
        elif typ in ('SC','SI'):
            if val is not None: ub[v] = val
            if typ == 'SI': is_int[v] = True
    rows = []
    row_index = {}
    for r in row_order:
        typ = row_type[r]
        if typ == 'N':
            continue
        b = rhs.get(r, 0.0)
        lo, hi = -math.inf, math.inf
        if typ == 'L': hi = b
        elif typ == 'G': lo = b
        elif typ == 'E': lo = b; hi = b
        if r in ranges:
            q = ranges[r]
            if typ == 'L': lo = b - abs(q)
            elif typ == 'G': hi = b + abs(q)
            elif typ == 'E':
                if q >= 0: lo, hi = b, b + q
                else: lo, hi = b + q, b
        row_index[r] = len(rows)
        rows.append({'name':r, 'type':typ, 'lo':lo, 'hi':hi, 'terms':[]})
    objective = defaultdict(float)
    entry_count = 0
    unknown_rows = 0
    for j,v in enumerate(variables):
        for r,a in col[v].items():
            if r == objective_name or row_type.get(r) == 'N':
                if r == objective_name:
                    objective[j] += a
            elif r in row_index:
                rows[row_index[r]]['terms'].append((j,a)); entry_count += 1
            else:
                unknown_rows += 1
    return {'variables':variables,'rows':rows,'lb':[lb[v] for v in variables],
            'ub':[ub[v] for v in variables],'integer':[is_int[v] for v in variables],
            'objective':dict(objective),'sense':obj_sense,'line_count':line_count,
            'entry_count':entry_count,'unknown_rows':unknown_rows,'range_count':len(ranges),
            'rhs_count':len(rhs),'objective_name':objective_name}


def row_violation(row, activity):
    if activity < row['lo']:
        return row['lo'] - activity
    if activity > row['hi']:
        return activity - row['hi']
    return 0.0


def clipped_candidate(z, lo, hi, integer):
    if math.isfinite(lo): z = max(z, lo)
    if math.isfinite(hi): z = min(z, hi)
    if integer: z = round(z)
    if math.isfinite(lo): z = max(z, math.ceil(lo) if integer else lo)
    if math.isfinite(hi): z = min(z, math.floor(hi) if integer else hi)
    return float(z)


def solve(model, seed, deadline, max_moves):
    rng = random.Random(seed)
    n = len(model['variables']); rows = model['rows']
    incident = [[] for _ in range(n)]
    for i,r in enumerate(rows):
        for j,a in r['terms']:
            incident[j].append((i,a))
    def initial(restart):
        x=[]
        for j in range(n):
            lo,hi = model['lb'][j],model['ub'][j]
            if restart and model['integer'][j] and lo == 0 and hi == 1:
                z = float(rng.randrange(2))
            elif math.isfinite(lo) and lo <= 0 and (not math.isfinite(hi) or hi >= 0): z=0.0
            elif math.isfinite(lo): z=lo
            elif math.isfinite(hi): z=hi
            else: z=0.0
            x.append(clipped_candidate(z,lo,hi,model['integer'][j]))
        return x
    def activities(x):
        a=[0.0]*len(rows)
        for i,r in enumerate(rows):
            a[i]=sum(c*x[j] for j,c in r['terms'])
        return a
    best_x=None; best_total=math.inf; best_bad=len(rows); moves=0; restarts=0; kicks=0
    x=initial(0); act=activities(x)
    while time.monotonic() < deadline and moves < max_moves:
        viol=[row_violation(rows[i],act[i]) for i in range(len(rows))]
        bad=[i for i,v in enumerate(viol) if v > 1e-8]
        total=sum(viol)
        if total < best_total - 1e-10 or (abs(total-best_total)<=1e-10 and len(bad)<best_bad):
            best_total,total0=total,total
            best_bad=len(bad); best_x=x[:]
        if not bad:
            return x,moves,restarts,kicks,0,0.0,'internally_feasible'
        # Prefer a large normalized violation while retaining seeded diversification.
        sample = bad if len(bad)<=64 else rng.sample(bad,64)
        ri=max(sample,key=lambda i: viol[i]/max(1.0,abs(rows[i]['lo']) if math.isfinite(rows[i]['lo']) else 0.0,abs(rows[i]['hi']) if math.isfinite(rows[i]['hi']) else 0.0))
        r=rows[ri]
        terms=r['terms']
        if not terms:
            return best_x,moves,restarts,kicks,best_bad,best_total,'structurally_empty_violated_row'
        if act[ri] < r['lo']: target=r['lo']
        elif act[ri] > r['hi']: target=r['hi']
        else: target=act[ri]
        cand=[]
        subset=terms if len(terms)<=128 else rng.sample(terms,128)
        for j,c in subset:
            if abs(c)<1e-15: continue
            raw=x[j]+(target-act[ri])/c
            vals={clipped_candidate(raw,model['lb'][j],model['ub'][j],model['integer'][j])}
            if model['integer'][j]:
                vals.add(clipped_candidate(math.floor(raw),model['lb'][j],model['ub'][j],True))
                vals.add(clipped_candidate(math.ceil(raw),model['lb'][j],model['ub'][j],True))
                vals.add(clipped_candidate(x[j]-1,model['lb'][j],model['ub'][j],True))
                vals.add(clipped_candidate(x[j]+1,model['lb'][j],model['ub'][j],True))
            for z in vals:
                if abs(z-x[j])<1e-12: continue
                delta=z-x[j]; old=0.0; new=0.0
                for q,a in incident[j]:
                    old += row_violation(rows[q],act[q])
                    new += row_violation(rows[q],act[q]+a*delta)
                cand.append((old-new,j,z))
        improving=[c for c in cand if c[0]>1e-10]
        if improving:
            gain,j,z=max(improving,key=lambda q:(q[0],rng.random()))
        elif cand:
            # Controlled kick: choose the least damaging move rather than falsely declaring feasibility.
            gain,j,z=max(cand,key=lambda q:(q[0],rng.random())); kicks+=1
        else:
            restarts+=1
            x=initial(restarts); act=activities(x)
            moves+=1
            continue
        d=z-x[j]; x[j]=z
        for q,a in incident[j]: act[q]+=a*d
        moves+=1
        if kicks and kicks % 2000 == 0:
            restarts+=1; x=initial(restarts); act=activities(x)
    return best_x,moves,restarts,kicks,best_bad,best_total,'dry_run_time_or_move_limit'


def full_audit(model,x):
    bad=[]; maxv=0.0
    for r in model['rows']:
        a=sum(c*x[j] for j,c in r['terms'])
        v=row_violation(r,a)
        if v>1e-8: bad.append((r['name'],v,a,r['lo'],r['hi']))
        maxv=max(maxv,v)
    bound_bad=0; int_bad=0
    for j,z in enumerate(x):
        if z < model['lb'][j]-1e-8 or z > model['ub'][j]+1e-8: bound_bad+=1
        if model['integer'][j] and abs(z-round(z))>1e-8: int_bad+=1
    return bad,maxv,bound_bad,int_bad


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--model',required=True); ap.add_argument('--seed',type=int,default=2)
    ap.add_argument('--runtime',type=float,default=100.0); ap.add_argument('--max-moves',type=int,default=2000000)
    args=ap.parse_args(); start=time.monotonic()
    model=parse_mps(args.model)
    parse_elapsed=time.monotonic()-start
    deadline=start+max(1.0,args.runtime)
    x,moves,restarts,kicks,best_bad,best_total,reason=solve(model,args.seed,deadline,args.max_moves)
    if x is None: x=[0.0]*len(model['variables'])
    bad,maxv,bound_bad,int_bad=full_audit(model,x)
    feasible=(not bad and bound_bad==0 and int_bad==0)
    obj=sum(model['objective'].get(j,0.0)*x[j] for j in range(len(x)))
    audit={'variables':len(model['variables']),'rows':len(model['rows']),'matrix_entries':model['entry_count'],
           'integer_variables':sum(model['integer']),'binary_variables':sum(1 for j in range(len(x)) if model['integer'][j] and model['lb'][j]==0 and model['ub'][j]==1),
           'ranged_rows':model['range_count'],'rhs_values':model['rhs_count'],'unknown_matrix_rows':model['unknown_rows'],
           'objective_row':model['objective_name'],'objective_sense':model['sense'],'parse_seconds':parse_elapsed,
           'final_violated_rows':len(bad),'maximum_row_violation':maxv,'total_row_violation':sum(q[1] for q in bad),
           'bound_violations':bound_bad,'integrality_violations':int_bad,'sample_violations':bad[:20],
           'moves':moves,'restarts':restarts,'kicks':kicks,'internally_feasible':feasible}
    with open('parser_audit.json','w') as f: json.dump(audit,f,indent=2)
    if feasible:
        with open('best.sol','w') as f:
            f.write('# Objective value = %.17g\n'%obj)
            for name,z in zip(model['variables'],x): f.write('%s %.17g\n'%(name,z))
    elapsed=time.monotonic()-start
    result={'status':'success','algorithm_family':'range-aware exact-activity MPS repair with diversified coordinate min-conflicts',
            'algorithm_role':'primal','hypothesis':'The previous false feasibility report arose from a representation error; a complete range-aware MPS abstraction and exact incremental activities can reliably identify and repair the sparse allcolor constraint violations.',
            'work_units':max(1,model['entry_count']+moves),'work_unit_name':'parsed matrix entries plus evaluated coordinate moves',
            'termination_reason':reason if not feasible else 'internally_feasible_candidate_emitted_for_independent_check',
            'target_bound':'verified feasibility and improvement of the public minimization primal target recorded in background.md',
            'objective':obj if feasible else None,'solution_artifact':'best.sol' if feasible else None,'certificate_artifact':'parser_audit.json',
            'seed':args.seed,'requested_algorithm_runtime_seconds':args.runtime,'actual_runtime_seconds':elapsed,
            'acceptance_criterion':'Emit a solution only after a complete reconstructed-row, bound, and integrality audit has zero violations at tolerance 1e-8.',
            'pivot_condition':'Pivot from strict best-improvement repair to a least-damaging incident-variable kick when no coordinate strictly reduces total affected-row violation; restart after sustained kicks.',
            'final_violated_rows':len(bad),'final_total_violation':sum(q[1] for q in bad),'maximum_row_violation':maxv}
    with open('method_result.json','w') as f: json.dump(result,f,indent=2)

if __name__=='__main__': main()
