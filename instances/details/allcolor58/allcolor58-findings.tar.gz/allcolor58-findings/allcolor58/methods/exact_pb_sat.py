#!/usr/bin/env python3
import argparse, decimal, fractions, glob, json, math, os, shutil, subprocess, sys, time
from collections import defaultdict

D = decimal.Decimal

def dec(s):
    s=s.replace('D','E').replace('d','e')
    return D(s)

def lcm(a,b):
    return abs(a*b)//math.gcd(a,b) if a and b else 0

def parse_mps(path):
    section=None; objrow=None; sense='min'; rows={}; cols=defaultdict(dict); rhs={}; ranges={}; bounds={}; integer_mode=False
    var_order=[]; seen=set()
    with open(path,'r',errors='replace') as f:
        for raw in f:
            line=raw.strip()
            if not line or line.startswith('*'): continue
            t=line.split(); key=t[0].upper()
            if key in ('NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA','OBJSENSE','OBJNAME'):
                section=key
                if key=='ENDATA': break
                continue
            if section=='OBJSENSE':
                if key.startswith('MAX'): sense='max'
                elif key.startswith('MIN'): sense='min'
            elif section=='ROWS':
                if len(t)>=2:
                    typ=t[0].upper(); name=t[1]; rows[name]=typ
                    if typ=='N' and objrow is None: objrow=name
            elif section=='COLUMNS':
                if any('MARKER' in x.upper() for x in t):
                    joined=' '.join(t).upper()
                    if 'INTORG' in joined: integer_mode=True
                    if 'INTEND' in joined: integer_mode=False
                    continue
                if len(t)<3: continue
                v=t[0]
                if v not in seen: seen.add(v); var_order.append(v)
                if v not in bounds: bounds[v]=[D(0),None,integer_mode]
                elif integer_mode: bounds[v][2]=True
                for j in range(1,len(t)-1,2):
                    r=t[j]
                    try: a=dec(t[j+1])
                    except Exception: continue
                    cols[v][r]=cols[v].get(r,D(0))+a
            elif section=='RHS':
                start=1 if len(t)%2==1 else 0
                for j in range(start,len(t)-1,2): rhs[t[j]]=dec(t[j+1])
            elif section=='RANGES':
                start=1 if len(t)%2==1 else 0
                for j in range(start,len(t)-1,2): ranges[t[j]]=dec(t[j+1])
            elif section=='BOUNDS':
                if len(t)<3: continue
                typ=t[0].upper(); v=t[2]
                if v not in seen: seen.add(v); var_order.append(v)
                b=bounds.setdefault(v,[D(0),None,False]); val=dec(t[3]) if len(t)>3 else D(0)
                if typ=='BV': b[:]=[D(0),D(1),True]
                elif typ=='FX': b[0]=val; b[1]=val
                elif typ in ('LO','LI'): b[0]=val; b[2] = b[2] or typ=='LI'
                elif typ in ('UP','UI'): b[1]=val; b[2] = b[2] or typ=='UI'
                elif typ=='FR': b[0]=None; b[1]=None
                elif typ=='MI': b[0]=None
                elif typ=='PL': b[1]=None
    objective={v:c.get(objrow,D(0)) for v,c in cols.items() if c.get(objrow,D(0))!=0}
    cons=[]
    for r,typ in rows.items():
        if typ=='N': continue
        a={v:c[r] for v,c in cols.items() if r in c and c[r]!=0}; b=rhs.get(r,D(0))
        if r not in ranges:
            cons.append((r,typ,a,b))
        else:
            q=ranges[r]; aq=abs(q)
            if typ=='L': cons.extend([(r+'#lo','G',a,b-aq),(r+'#hi','L',a,b)])
            elif typ=='G': cons.extend([(r+'#lo','G',a,b),(r+'#hi','L',a,b+aq)])
            elif typ=='E':
                lo,hi=(b,b+aq) if q>=0 else (b-aq,b)
                cons.extend([(r+'#lo','G',a,lo),(r+'#hi','L',a,hi)])
    return sense,var_order,bounds,objective,cons

class CNF:
    def __init__(self,n): self.n=n; self.clauses=[]; self.states=0
    def new(self): self.n+=1; return self.n
    def add(self,*lits):
        out=[]; present=set()
        for x in lits:
            if x is True: return
            if x is False or x==0: continue
            x=int(x)
            if -x in present: return
            if x not in present: present.add(x); out.append(x)
        self.clauses.append(out)
    def neg(self,x):
        if x is True: return False
        if x is False: return True
        return -x
    def ite(self,l,h,lw):
        if h is lw or h==lw: return h
        y=self.new(); self.states+=1
        self.add(-y,-l,h); self.add(-y,l,lw)
        self.add(self.neg(l),self.neg(h),y); self.add(l,self.neg(lw),y)
        return y
    def atmost(self,terms,bound,state_cap):
        terms=[(int(w),int(l)) for w,l in terms if w>0]
        total=sum(w for w,_ in terms)
        if bound<0: self.add(); return
        if bound>=total: return
        terms.sort(reverse=True)
        suffix=[0]*(len(terms)+1)
        for i in range(len(terms)-1,-1,-1): suffix[i]=suffix[i+1]+terms[i][0]
        memo={}
        def rec(i,b):
            if b<0: return False
            if i==len(terms) or suffix[i]<=b: return True
            k=(i,b)
            if k in memo: return memo[k]
            if len(memo)>=state_cap: raise RuntimeError('BDD state cap exceeded')
            w,lit=terms[i]
            low=rec(i+1,b); high=rec(i+1,b-w)
            z=self.ite(lit,high,low); memo[k]=z; return z
        self.add(rec(0,int(bound)))

def integerize(coeff,rhs):
    den=1
    vals=list(coeff.values())+[rhs]
    for x in vals:
        den=lcm(den, fractions.Fraction(x).denominator)
        if den>1000000000: raise RuntimeError('excessive rational scale')
    return {v:int(fractions.Fraction(a)*den) for v,a in coeff.items()},int(fractions.Fraction(rhs)*den)

def find_tool():
    candidates=[]
    for root,dirs,files in os.walk('/tools/cadical'):
        for f in files:
            p=os.path.join(root,f)
            if f.lower().startswith('cadical') and os.path.isfile(p) and os.access(p,os.X_OK): candidates.append(p)
    if candidates: return sorted(candidates,key=len)[0]
    return shutil.which('cadical')

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--model',required=True); ap.add_argument('--seed',type=int,default=1); ap.add_argument('--solve-seconds',type=int,default=75); ap.add_argument('--state-cap',type=int,default=3000000); args=ap.parse_args()
    started=time.time(); audit={'seed':args.seed,'acceptance_criterion':'All model rows encoded exactly and either a SAT assignment is independently MIP-checkable or an UNSAT certificate is produced.','pivot_condition':'Revise representation if any nonfixed nonbinary domain, row, or BDD state limit prevents exact encoding.'}
    result={'status':'success','algorithm_family':'exact pseudo-Boolean BDD-to-CNF translation with CDCL','algorithm_role':'proof','hypothesis':'After substituting fixed continuous variables, the allcolor58 formulation is a pure binary sparse pseudo-Boolean system suitable for exact CNF translation.','target_bound':'feasibility of the complete original constraint system','seed':args.seed,'requested_runtime_seconds':args.solve_seconds,'acceptance_criterion':audit['acceptance_criterion'],'pivot_condition':audit['pivot_condition'],'work_units':1,'termination_reason':'initialization'}
    try:
        sense,names,bounds,obj,cons=parse_mps(args.model); idx={v:i+1 for i,v in enumerate(names)}; fixed={}; unsupported=[]
        for v in names:
            lo,up,integ=bounds.get(v,[D(0),None,False])
            if lo is not None and up is not None and lo==up: fixed[v]=lo
            elif not (integ and lo==0 and up==1): unsupported.append({'variable':v,'lower':None if lo is None else str(lo),'upper':None if up is None else str(up),'integer':integ})
        audit.update({'variables':len(names),'constraints':len(cons),'objective_nonzeros':len(obj),'fixed_variables':len(fixed),'unsupported_domains':unsupported[:40]})
        if unsupported: raise RuntimeError('nonfixed nonbinary variables remain: '+str(len(unsupported)))
        cnf=CNF(len(names)); encoded=0; max_arity=0
        for rn,typ,co,b in cons:
            bb=b; live={}
            for v,a in co.items():
                if v in fixed: bb-=a*fixed[v]
                else: live[v]=a
            ci,bi=integerize(live,bb); max_arity=max(max_arity,len(ci))
            def encode_le(c,d):
                terms=[]
                for v,a in c.items():
                    if a>=0: terms.append((a,idx[v]))
                    else:
                        w=-a; terms.append((w,-idx[v])); d+=w
                cnf.atmost(terms,d,args.state_cap)
            if typ=='L': encode_le(ci,bi)
            elif typ=='G': encode_le({v:-a for v,a in ci.items()},-bi)
            elif typ=='E':
                encode_le(ci,bi); encode_le({v:-a for v,a in ci.items()},-bi)
            else: raise RuntimeError('unsupported row type '+typ)
            encoded+=1
        audit.update({'encoded_rows':encoded,'max_row_arity':max_arity,'bdd_states':cnf.states,'cnf_variables':cnf.n,'cnf_clauses':len(cnf.clauses)})
        with open('model.cnf','w') as f:
            f.write('p cnf %d %d\n'%(cnf.n,len(cnf.clauses)))
            for c in cnf.clauses: f.write(' '.join(map(str,c))+' 0\n')
        tool=find_tool()
        if not tool: raise RuntimeError('CaDiCaL executable not found in configured tool directory')
        cmd=[tool,'--seed='+str(args.seed),'model.cnf']; audit['cadical_executable']=tool
        try:
            p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=args.solve_seconds)
            out=p.stdout; rc=p.returncode
        except subprocess.TimeoutExpired as e:
            out=(e.stdout or '') if isinstance(e.stdout,str) else ''; rc=124
        with open('cadical_summary.log','w') as f: f.write(out[-200000:])
        vals={}; sat=(rc==10 or 's SATISFIABLE' in out); unsat=(rc==20 or 's UNSATISFIABLE' in out)
        if sat:
            for line in out.splitlines():
                if line.startswith('v '):
                    for z in line.split()[1:]:
                        q=int(z)
                        if q: vals[abs(q)]=q>0
            objective=D(0)
            with open('best.sol','w') as f:
                f.write('# Exact SAT-derived candidate; independent MIP verification required.\n')
                for v in names:
                    value=fixed[v] if v in fixed else D(1 if vals.get(idx[v],False) else 0)
                    objective+=obj.get(v,D(0))*value
                    f.write('%s %s\n'%(v,str(value)))
            audit['candidate_objective']=str(objective); result['objective']=float(objective); result['solution_artifact']='best.sol'; result['termination_reason']='CaDiCaL returned SAT and a complete candidate was emitted for independent checking'
        elif unsat:
            result['termination_reason']='CaDiCaL returned UNSAT for the exact feasibility encoding; no formal claim is made without independent certificate checking'; result['certificate_status']='not_yet_independently_checked'
        elif rc==124:
            result['termination_reason']='CaDiCaL time limit after exact translation'
        else:
            result['termination_reason']='CaDiCaL ended without SAT or UNSAT status (return code %s)'%rc
        result['work_units']=max(1,encoded+cnf.states+len(cnf.clauses)); audit['cadical_returncode']=rc; audit['sat']=sat; audit['unsat']=unsat
    except Exception as e:
        audit['error']=str(e); result['status']='success'; result['termination_reason']='Exact translation diagnostic stopped: '+str(e); result['work_units']=max(1,int(audit.get('encoded_rows',0))+1)
    result['actual_runtime_seconds']=time.time()-started
    with open('pb_sat_audit.json','w') as f: json.dump(audit,f,indent=2)
    with open('method_result.json','w') as f: json.dump(result,f,indent=2)
if __name__=='__main__': main()
