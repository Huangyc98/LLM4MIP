import argparse, gzip, json, math, os, random, time


def open_text(path):
    with open(path, 'rb') as f:
        magic = f.read(2)
    if magic == b'\x1f\x8b':
        return gzip.open(path, 'rt', encoding='utf-8', errors='replace')
    return open(path, 'rt', encoding='utf-8', errors='replace')


def parse_mps(path):
    section = None
    rows = {}
    row_order = []
    objrows = set()
    coeff = {}
    rhs = {}
    ranges = {}
    bounds = {}
    integer_mode = False
    integer_vars = set()
    variables = []
    seen_vars = set()
    rhs_name = None
    range_name = None
    records = 0
    with open_text(path) as f:
        for raw in f:
            line = raw.rstrip('\r\n')
            if not line or line.lstrip().startswith('*'):
                continue
            tok = line.split()
            if not tok:
                continue
            head = tok[0].upper()
            if head in ('NAME','OBJSENSE','OBJNAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA') and (line[:1] not in (' ', '\t') or head in ('ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA')):
                if head == 'ENDATA':
                    break
                section = head
                continue
            records += 1
            if section == 'ROWS':
                if len(tok) >= 2:
                    typ, name = tok[0].upper(), tok[1]
                    if typ == 'N': objrows.add(name)
                    else:
                        rows[name] = typ
                        row_order.append(name)
            elif section == 'COLUMNS':
                if len(tok) >= 3 and (tok[1].strip("'").upper() == 'MARKER' or tok[0].strip("'").upper() == 'MARKER'):
                    joined = ' '.join(tok).upper()
                    if 'INTORG' in joined: integer_mode = True
                    if 'INTEND' in joined: integer_mode = False
                    continue
                var = tok[0]
                if var not in seen_vars:
                    seen_vars.add(var); variables.append(var)
                if integer_mode: integer_vars.add(var)
                j = 1
                while j + 1 < len(tok):
                    rn = tok[j]
                    try: a = float(tok[j+1].replace('D','E').replace('d','e'))
                    except ValueError:
                        j += 2; continue
                    if rn in rows:
                        coeff.setdefault(rn, {})[var] = coeff.setdefault(rn, {}).get(var, 0.0) + a
                    j += 2
            elif section == 'RHS':
                if len(tok) < 3: continue
                if rhs_name is None: rhs_name = tok[0]
                if tok[0] != rhs_name: continue
                j = 1
                while j + 1 < len(tok):
                    try: rhs[tok[j]] = float(tok[j+1].replace('D','E').replace('d','e'))
                    except ValueError: pass
                    j += 2
            elif section == 'RANGES':
                if len(tok) < 3: continue
                if range_name is None: range_name = tok[0]
                if tok[0] != range_name: continue
                j = 1
                while j + 1 < len(tok):
                    try: ranges[tok[j]] = float(tok[j+1].replace('D','E').replace('d','e'))
                    except ValueError: pass
                    j += 2
            elif section == 'BOUNDS':
                if len(tok) < 3: continue
                typ, var = tok[0].upper(), tok[2]
                val = 0.0
                if len(tok) >= 4:
                    try: val = float(tok[3].replace('D','E').replace('d','e'))
                    except ValueError: val = 0.0
                lo, up, integ = bounds.get(var, (0.0, math.inf, var in integer_vars))
                if typ == 'BV': lo, up, integ = 0.0, 1.0, True
                elif typ in ('LI','LO'): lo = val; integ = integ or typ == 'LI'
                elif typ in ('UI','UP'): up = val; integ = integ or typ == 'UI'
                elif typ == 'FX': lo = up = val
                elif typ == 'FR': lo, up = -math.inf, math.inf
                elif typ == 'MI': lo = -math.inf
                elif typ == 'PL': up = math.inf
                bounds[var] = (lo, up, integ)
    binary = []
    unsupported = []
    for v in variables:
        lo, up, integ = bounds.get(v, (0.0, math.inf, v in integer_vars))
        if integ and lo >= -1e-9 and up <= 1.0 + 1e-9:
            binary.append(v)
        else:
            unsupported.append({'variable':v,'lower':lo,'upper':up,'integer':integ})
    constraints = []
    for rn in row_order:
        typ = rows[rn]
        base = rhs.get(rn, 0.0)
        terms = coeff.get(rn, {})
        if rn in ranges:
            r = abs(ranges[rn])
            if typ == 'L': constraints.append((rn+'__lo','G',base-r,terms))
            elif typ == 'G': constraints.append((rn+'__up','L',base+r,terms))
            else:
                rv = ranges[rn]
                constraints.append((rn+'__a','G',base + min(0.0,rv),terms))
                constraints.append((rn+'__b','L',base + max(0.0,rv),terms))
        else:
            constraints.append((rn,typ,base,terms))
    return variables, binary, unsupported, constraints, records


def violation(typ, value, rhs):
    if typ == 'L': return max(0.0, value-rhs)
    if typ == 'G': return max(0.0, rhs-value)
    return abs(value-rhs)


def write_solution(names, x):
    with open('best.sol','w',encoding='utf-8') as f:
        f.write('# Objective value = 0\n')
        for i,n in enumerate(names): f.write('%s %d\n' % (n, x[i]))


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--model',required=True)
    ap.add_argument('--seed',type=int,default=1)
    ap.add_argument('--duration',type=float,default=90.0)
    ap.add_argument('--candidate-limit',type=int,default=64)
    args=ap.parse_args()
    start=time.monotonic(); rng=random.Random(args.seed)
    names,binary,unsupported,rawcons,records=parse_mps(args.model)
    bset=set(binary)
    parse_ok = len(names)>0 and len(rawcons)>0 and not unsupported and len(binary)==len(names)
    cons=[]
    for rn,typ,b,td in rawcons:
        arr=[]
        for v,a in td.items():
            if v in bset: arr.append((v,a))
        cons.append((rn,typ,b,arr))
    index={v:i for i,v in enumerate(binary)}
    incidence=[[] for _ in binary]
    cterms=[]
    for ci,(rn,typ,b,arr) in enumerate(cons):
        aa=[]
        for v,a in arr:
            j=index[v]; aa.append((j,a)); incidence[j].append((ci,a))
        cterms.append(aa)
    deadline=start+max(0.1,args.duration)
    x=[rng.randrange(2) for _ in binary]
    vals=[sum(a*x[j] for j,a in aa) for aa in cterms]
    weights=[1.0]*len(cons)
    tabu=[0]*len(binary)
    flips=0; evaluations=0; restarts=0; stagnation=0
    bestx=x[:]; bestkey=(10**18,float('inf'))
    feasible=False
    def key_now():
        nv=0; tv=0.0
        for i,c in enumerate(cons):
            z=violation(c[1],vals[i],c[2])
            if z>1e-7: nv+=1; tv+=z
        return nv,tv
    if parse_ok:
        while time.monotonic()<deadline:
            violated=[]; total=0.0
            for i,c in enumerate(cons):
                z=violation(c[1],vals[i],c[2])
                if z>1e-7:
                    score=weights[i]*z
                    violated.append((i,score)); total+=score
            k=(len(violated),sum(s for _,s in violated))
            if k<bestkey:
                bestkey=k; bestx=x[:]; stagnation=0
            else: stagnation+=1
            if not violated:
                feasible=True; bestx=x[:]; bestkey=(0,0.0); break
            r=rng.random()*total; chosen=violated[-1][0]
            for ci,s in violated:
                r-=s
                if r<=0: chosen=ci; break
            cand=[j for j,a in cterms[chosen] if abs(a)>1e-15]
            if len(cand)>args.candidate_limit: cand=rng.sample(cand,args.candidate_limit)
            bestj=None; bestdelta=float('inf')
            for j in cand:
                delta=0.0; sign=1 if x[j]==0 else -1
                for ci,a in incidence[j]:
                    old=violation(cons[ci][1],vals[ci],cons[ci][2])
                    new=violation(cons[ci][1],vals[ci]+sign*a,cons[ci][2])
                    delta += weights[ci]*(new-old)
                evaluations+=len(incidence[j])
                jitter=rng.random()*1e-9
                if (flips>=tabu[j] or delta < -1e-9) and delta+jitter<bestdelta:
                    bestdelta=delta+jitter; bestj=j
            if bestj is None and cand: bestj=rng.choice(cand)
            if bestj is None:
                weights[chosen]+=1.0; continue
            sign=1 if x[bestj]==0 else -1
            x[bestj]^=1
            for ci,a in incidence[bestj]: vals[ci]+=sign*a
            flips+=1; tabu[bestj]=flips+5+rng.randrange(11)
            if bestdelta>=-1e-10: weights[chosen]+=1.0
            if stagnation>max(20000,20*len(binary)):
                x=bestx[:]
                for _ in range(max(1,len(binary)//50)):
                    j=rng.randrange(len(binary)); x[j]^=1
                vals=[sum(a*x[j] for j,a in aa) for aa in cterms]
                weights=[1.0+0.25*(w-1.0) for w in weights]
                restarts+=1; stagnation=0
    else:
        bestkey=(len(cons),float('inf'))
    runtime=time.monotonic()-start
    if feasible: write_solution(binary,bestx)
    report={'status':'success','parse_ok':parse_ok,'parse_records':records,'variables':len(names),'binary_variables':len(binary),'constraints':len(cons),'unsupported_count':len(unsupported),'unsupported_examples':unsupported[:10],'feasible':feasible,'best_violated_rows':bestkey[0],'best_weighted_violation':bestkey[1] if math.isfinite(bestkey[1]) else None,'flips':flips,'constraint_evaluations':evaluations,'restarts':restarts,'seed':args.seed,'runtime_seconds':runtime,'acceptance_criterion':'The gzip-aware MPS parser must recover a pure binary model, and the returned assignment is accepted only if every original row has violation at most 1e-7 under direct incremental evaluation.','pivot_condition':'Scale weighted breakout search if parsing is complete and violations decrease; repair domain handling if nonbinary variables remain; replace the neighborhood if evaluation throughput or diversification is inadequate.','target_bound':'Feasibility objective 0 and reduction of the unresolved proof gap.'}
    with open('pb_breakout_report.json','w',encoding='utf-8') as f: json.dump(report,f,indent=2,sort_keys=True)
    result={'status':'success','algorithm_family':'incremental weighted pseudo-Boolean breakout search','algorithm_role':'primal','hypothesis':'The allcolor58 feasibility formulation is a pure binary sparse row system whose exact constraints can be satisfied by violation-directed flips with breakout weighting and tabu diversification.','work_units':max(1,flips+evaluations),'termination_reason':'feasible_assignment_found' if feasible else ('search_budget_exhausted' if parse_ok else 'representation_obstruction'),'target_bound':'Verified feasibility objective 0; no global dual claim.','objective':0.0 if feasible else None,'solution_artifact':'best.sol' if feasible else None,'certificate_artifact':None,'seed':args.seed,'runtime_seconds':runtime,'acceptance_criterion':report['acceptance_criterion'],'pivot_condition':report['pivot_condition']}
    with open('method_result.json','w',encoding='utf-8') as f: json.dump(result,f,indent=2,sort_keys=True)

if __name__=='__main__': main()
