# Background: allcolor58

## Recovery status

This document was reconstructed at Formal Solving entry because the Background stage ended without writing its required artifacts. It uses the controller-verified `structure.json`. No numerical public bound is asserted without a recovered primary source.

## Verified model facts

- Instance: `allcolor58`.
- Objective sense: minimization.
- Variables: 84,376 total, comprising 80,780 general integer and 3,596 continuous variables; there are no declared binary variables.
- Constraints: 197,154 linear rows: 116,928 less-than rows, 58,506 greater-than rows, and 21,720 equality rows.
- Matrix: 515,184 nonzeros, approximately 2.61 nonzeros per row, with integral coefficients of absolute value at most 11.
- Variable bounds: all 83,564 finite lower bounds reported by the structural scan are zero. There are 4,220 finite upper bounds, of which 3,060 are positive and at most 10.
- Objective: 2,784 nonzero coefficients, all positive, integral, and at most 10; all other objective coefficients are zero.
- Right-hand sides are integral and have absolute value at most 11.
- The model is linear, with no quadratic, SOS, or general constraints.
- The uncompressed model SHA-256 is `6ef819ff0d5e882469cf45d333c2fe1f59c48df7250e3ec28fd68da4187dfc91`.

Source: controller-generated `structure.json`, obtained by parsing the supplied model on euler4. The official MIPLIB instance page is the intended primary source for public status and bounds, but its numerical fields were not present in the retained Background evidence when this recovery was required.

## Objective and immediately valid bound

The problem is a minimization model. Because every objective coefficient is nonnegative and every variable has a nonnegative lower bound, the structural data suggests the elementary lower bound 0, subject to confirmation that the MPS objective constant is zero. A custom parser must verify the objective row, RHS objective offset, bound records, and integrality before reporting 0 as a certified dual bound. This observation does not establish feasibility or optimality.

## Public targets before this experiment

| Quantity | Pre-experiment target | Evidence status |
|---|---:|---|
| Best public primal bound | Unknown | The mandatory Background artifact and its sourced numerical evidence were absent. No value is invented. |
| Best public dual bound | Unknown | The mandatory Background artifact and its sourced numerical evidence were absent. No value is invented. |
| Public relative gap | Unknown | Cannot be computed until both sourced public bounds are recovered. |
| Public solution/proof status | Open-instance context | Supplied by the experiment stage designation, not a numerical proof claim. |

The official MIPLIB page must be checked before describing an experimental value as a public-record improvement. Until then, every comparison will distinguish an experiment-internal verified bound from a public record.

## Diagnostic baseline status

At Formal Solving entry, the controller attempted the fixed 120-second Gurobi/euler4 and COPT/altman diagnostics. Both failed at the remote-launch layer and produced no solver measurement. They must not be duplicated or extended as baselines. Their launch failures provide no information about model feasibility, primal quality, dual quality, or proof difficulty.

## Provisional mathematical classification

The verified facts indicate a huge but exceptionally sparse, bounded-coefficient mixed-integer linear system. The instance name suggests a structured coloring model, but that interpretation is not treated as fact until row and column names and repeated coefficient patterns are decoded from the supplied MPS. The unusually large number of general integer variables, the small coefficients and right-hand sides, and the low average row degree make domain propagation, block recovery, and combinatorial reformulation more promising initial research tools than generic parameter tuning.

## Evidence and verification policy

A candidate primal is valuable only after controller verification against the original model. A dual bound must follow from a globally valid relaxation, exact propagation argument, independently checked certificate, or strict trusted-solver status. A custom claim of optimality or infeasibility is not proof. For this minimization instance, smaller verified primal values and larger valid dual values are improvements.