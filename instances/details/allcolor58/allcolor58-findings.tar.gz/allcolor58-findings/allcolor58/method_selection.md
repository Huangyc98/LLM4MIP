# Method Selection: allcolor58

## Decision context

The model is a minimization MILP with 84,376 variables, 197,154 sparse linear constraints, small integral coefficients, nonnegative variable lower bounds, and only 2,784 positive objective coefficients. Both automatic diagnostic solver launches failed before execution, so there is no measured solver trajectory. The first custom experiment must therefore decode the algebraic structure while performing genuine, sound algorithmic work.

## Candidate comparison

### Candidate A: exact integer-domain propagation and structural decoder

- Role: dual bound and proof infrastructure.
- Abstraction: integer variables with interval domains and sparse linear rows; continuous variables retain rational intervals.
- Method: parse the original MPS independently, canonicalize rows, recover naming/block patterns, apply sound row-wise bound tightening with directed integer rounding, detect contradictions, and compute the objective lower bound implied by tightened domains.
- Hypothesis: low row degree, small coefficients, and small right-hand sides permit many inexpensive domain reductions and expose repeated combinatorial blocks.
- Strength: every accepted bound tightening is globally valid; a contradiction trace can later seed a certificate system. It also supplies the structural information needed to design genuinely problem-specific primal methods.
- Risk: most variables may remain unbounded above and propagation may stall at the elementary lower bound.

### Candidate B: weighted constraint-violation descent with exact feasibility repair

- Role: primal construction.
- Abstraction: bounded or dynamically capped integer assignments, sparse row activities, and lexicographic minimization of total violation followed by objective.
- Method: initialize from propagated lower bounds; use incremental row activities, adaptive row penalties, one-variable and block moves, tabu tenure, deterministic restarts, and a final exact repair pass over violated connected components.
- Hypothesis: the matrix's average row degree near 2.61 means local changes have limited impact and connected violation components can be repaired efficiently.
- Strength: directly targets a verified incumbent without calling a generic MIP solver.
- Risk: equality rows may couple distant blocks; arbitrary caps on formally unbounded variables must never invalidate feasibility search.

### Candidate C: incidence-graph decomposition with large-neighborhood dynamic programming

- Role: primal/hybrid.
- Abstraction: bipartite variable-row graph decomposed into connected components, articulation separators, repeated blocks, or low-width neighborhoods.
- Method: identify exact independent components and near-separators; solve bounded local subproblems by enumeration or dynamic programming while holding separator variables fixed; alternate neighborhoods and use propagation after each pivot.
- Hypothesis: the instance dimensions and repeated small coefficients arise from replicated color-index structures, producing exploitable blocks that generic local moves miss.
- Strength: materially different from single-variable repair and can certify optimality of each enumerated neighborhood.
- Risk: the incidence graph may contain one giant high-width component, falsifying the decomposition hypothesis.

### Candidate D: direct finite-domain SAT encoding for objective cutoffs

- Role: proof and dual-bound strengthening.
- Abstraction: bounded integer variables encoded by order literals; linear rows encoded with propagation-friendly cardinality or pseudo-Boolean constructions; a tested objective cutoff is asserted as an assumption.
- Method: after propagation proves finite relevant domains, emit CNF for `objective <= K`, run configured CaDiCaL, and request/check DRAT evidence with configured drat-trim when UNSAT is claimed.
- Hypothesis: small domains and repeated coefficients permit a compact encoding for a reduced core, allowing certified exclusion of low objective values.
- Strength: an UNSAT result with independently checked DRAT evidence is a reproducible proof and raises the global dual bound.
- Risk: direct encoding of the unreduced full model may be too large, and continuous variables require elimination or a separately justified exact treatment.

### Candidate E: direct post-gate Gurobi/COPT proof attempt

- Role: proof fallback only.
- Decision: deferred. Direct solver work is forbidden until at least four materially distinct custom methods have launched, at least three have completed successfully, successful custom runtime totals at least 3,600 seconds, and one scaled run executes for at least 1,800 seconds. The global solver allowance must also be rechecked because failed baseline launches may or may not have consumed controller-accounted time.

## Selected sequence

1. Candidate A, deterministic dry run, because it simultaneously validates parsing, obtains sound dual information, and identifies the actual combinatorial blocks.
2. Candidate B, deterministic dry run using Candidate A's domains and incidence data, targeting a first verified primal.
3. Candidate C, dry run on measured components or repeated blocks; pivot to a different decomposition if the graph diagnostics falsify low-width structure.
4. Candidate D, reduced-core encoding dry run followed by a proof-oriented scale-up only if all relevant domains and continuous-variable treatment are exact.

Each method will have distinct source logic and a distinct mathematical role. Renaming or merely changing parameters will not count as a new method.

## Tool decision

Python standard library and C++17 are sufficient for MPS parsing, propagation, local search, and decomposition. CaDiCaL and drat-trim are optional only for Candidate D, where their proof capabilities match a mathematically derived SAT encoding. They will not be used as a substitute for understanding the model, and no unrestricted MIP solve will be hidden in custom code.

## Pivot rules

- Parsing failure: repair MPS representation and repeat only the deterministic dry run.
- No propagation beyond input bounds: retain the certified elementary bound, use decoded blocks to prioritize primal construction, and strengthen propagation with congruence and equality substitution rather than extending runtime unchanged.
- Repair stagnation: diagnose caps, equality coupling, move evaluation, and diversification; enlarge to block moves or connected-component repair.
- Giant/high-width incidence core: reject the simple decomposition hypothesis and use repeated-row aggregation, separator-conditioned neighborhoods, or SAT core extraction instead.
- Excessive SAT encoding size: restrict to an exactly justified reduced core or abandon the encoding; never infer a bound from an incomplete encoding.

## Bound comparison rule

For this minimization problem, each decision compares the smallest controller-verified primal and largest globally valid dual against both the sourced public targets and the cumulative experiment record. Public numerical targets are currently unrecovered, so no public-record claim is permitted until primary-source evidence supplies them.