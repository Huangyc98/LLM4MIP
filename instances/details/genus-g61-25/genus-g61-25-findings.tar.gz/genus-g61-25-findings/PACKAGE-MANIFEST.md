# Package manifest: genus-g61-25

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 23
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/genus-g61-25.adjacency.txt`
- `artifacts/genus-g61-25.mc`
- `artifacts/genus-g61-25.north-to-mps.tsv`
- `artifacts/genus-g61-25.official-rotation.txt`
- `artifacts/genus-g61-25.page-official-rotation-adjacency.txt`
- `artifacts/genus-g61-25.source-fingerprint.txt`
- `logs/genus-g61-25.literature-bound-audit.log`
- `logs/genus-g61-25.multi-genus-600s.log`
- `logs/genus-g61-25.multi-genus-decision-gt-9.log`
- `logs/genus-g61-25.multi-genus.log`
- `logs/genus-g61-25.official-solution-validation.log`
- `logs/genus-g61-25.page-low-mem-600s.log`
- `logs/genus-g61-25.page-low-mem-glb8-600s.log`
- `logs/genus-g61-25.page-low-mem-glb8.stderr.log`
- `logs/genus-g61-25.page-low-mem.stderr.log`
- `logs/genus-g61-25.rank15-audit.log`
- `reports/structural-investigation.md`
- `scripts/run_page.py`
- `scripts/verify.py`
- `solutions/official-40.sol.gz`
- `solutions/official-best.sol.gz`
- `solutions/official-best.validation.json`

## Excluded files

- `input/genus-g61-25.mps.gz (1908223 bytes; raw benchmark input; sha256 f601e791f656d3cd6769180cfcbbce22aedbfb411b439d012be90031ff5277b0)`
