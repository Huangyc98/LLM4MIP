# `circ10-3`: exact CIRC10 formulation audit

Audit date: 2026-09-04
Status: **exact row-by-row reconstruction passed; no semantic mismatch found**

## Conclusion

The MIPLIB model is an exact extended binary formulation of the standard
ten-team constrained circular-distance Traveling Tournament Problem (TTP),
including the no-repeater rule. Every one of its 42,620 rows, 307,320 matrix
coefficients, 2,700 binary bounds, and 900 objective coefficients was
reconstructed independently from the semantic indices and compared exactly
with the MPS. The checker found no extra restriction that excludes a valid
standard schedule and no missing standard requirement.

Moreover, for every integer-feasible MPS point, the travel-arc variables are
forced to be *exactly* the nonzero physical arcs traversed by the ten teams;
they cannot omit an arc, double-count a repeated use, or add an unrelated arc.
Consequently, the MPS objective equals the standard TTP travel total pointwise,
not only at an optimum.

The official TTP archive records both a feasible value and lower bound of 242
for constrained CIRC10. Therefore, accepting that published exhaustive-search
result, the formulation audit transfers the lower bound without qualification:

\[
        \operatorname{OPT}(\texttt{circ10-3.mps})
        = \operatorname{OPT}(\text{standard constrained CIRC10}) = 242.
\]

The local `circ10-3-242.sol` is a zero-violation MPS solution of value 242. It
strictly improves the current MIPLIB incumbent of 256.

The only remaining epistemic limitation is external to the formulation: this
audit did not rerun the authors' exhaustive IDA* computation or independently
recreate its lower-bound certificate. The 242 lower bound is supported by the
official benchmark archive, the authors' own results page/file, and the
peer-reviewed paper, rather than by a locally checkable proof artifact.

## Audited artifacts

- Model: `instances/circ10-3/input/circ10-3.mps.gz`
- Exact checker: `instances/circ10-3/scripts/audit_formulation.py`
- Official-schedule translator: `instances/circ10-3/scripts/build_solution_242.py`
- New candidate: `instances/circ10-3/solutions/verified-242.sol`
- Gurobi-written candidate: `instances/circ10-3/solutions/gurobi-242.sol`
- One-second, one-thread quality log:
  `instances/circ10-3/logs/solution-242-quality.log`
- Current official MIPLIB solution:
  `instances/circ10-3/solutions/official-256.sol.gz`

SHA-256:

```text
dacfd0446a8de0e0268b0dc102f37cb8d8ea1220f479d52eeb32f75f4f9eb11  circ10-3.mps.gz
829c8a6b13656a88a682ea96baf0d91d0282261e17bf27fb8a320558b33d0d35  uncompressed MPS byte stream
06d6b50e7b98233d158a0022310fed01364b3e1e95d0da01075dfcb271a0e874  audit_circ10_exact.py
caa7a7d65724388760530af3da9514d2e7716b6e6bcbba3b827572be2df50d31  build_circ10_242.py
225d20f0c59ca9574e84fce000aa2d96136169148bad9374ca8bd13662b55f43  circ10-3-242.sol
9a97311150d982d14558e4d8aecc7a65f6dcf24e75ede1a450d713ff2f988fd7  circ10-3-242-gurobi.sol
cc7b86576d9712599c23f9752ccb9d67d4bef2331120f397709b834642809cab  circ10-3-242_quality.log
6eb5fa72735dceb78cd88179f7392423e306719f709d00fe029ef4eae8ec2cf9  current official circ10-3.sol.gz
```

The official schedule file fetched on 2026-09-04 had SHA-256
`0df5b13a41a84923f45f5213f8ff8d6a3ff05ed66a3efab5b15de7b8d1364573`.
After removing the display-only `T` prefixes, its 18 rows match the schedule
embedded in `build_circ10_242.py` exactly.

## Semantic variables and exact numbering

Let teams and venues be \(V=\{0,\ldots,9\}\), and let the 18 rounds be
\(R=\{0,\ldots,17\}\).

The first 1,800 variables are

\[
 z_{r,i,v}=1 \quad\Longleftrightarrow\quad
 \text{team }i\text{ is at venue }v\text{ in round }r,
\]

with exact MPS number

\[
        x_{1+100r+10i+v} = z_{r,i,v}.
\]

Thus \(z_{r,i,i}=1\) means team \(i\) plays at home, while
\(z_{r,i,v}=1\), \(v\ne i\), means team \(i\) visits team \(v\).

The final 900 variables are

\[
 y_{i,a,b}=1 \quad\Longleftrightarrow\quad
 \text{team }i\text{ uses directed travel arc }a\to b,
 \qquad a\ne b.
\]

Define

\[
 q(a,b)=9a+b-\mathbf 1[b>a].
\]

Then the exact MPS number is

\[
        x_{1801+90i+q(a,b)}=y_{i,a,b}.
\]

The MPS bounds section contains exactly one `BV` bound for each `x1` through
`x2700`, and no other variable or bound.

## Exact row crosswalk

MPS `G` rows use the convention left-hand side \(\ge\) right-hand side.
The following table gives every row family. Within each displayed loop, indices
increase in the order written. The audit script constructs the coefficient map
of every individual `cN`, so this is not a signature-only comparison.

| MPS rows | Count | Exact template and loop order |
|---|---:|---|
| `c0`--`c89` | 90 | For `i`, then `v != i`: \(\sum_r z_{r,i,v}=1\). |
| `c90`--`c1709` | 1,620 | For `i`, `j != i`, then `r`: \(-z_{r,i,j}+z_{r,j,j}\ge0\). |
| `c1710`--`c1889` | 180 | For `v`, then `r`: \(-\sum_{i\ne v}z_{r,i,v}\ge-1\). |
| `c1890`--`c2069` | 180 | For `r`, then `i`: \(\sum_v z_{r,i,v}=1\). |
| `c2070+20s`--`c2079+20s`, `s=0,...,14` | 150 | For `i`: \(-\sum_{r=s}^{s+3}z_{r,i,i}\ge-3\). |
| `c2080+20s`--`c2089+20s`, `s=0,...,14` | 150 | For `i`: \(-\sum_{r=s}^{s+3}\sum_{v\ne i}z_{r,i,v}\ge-3\). |
| `c2370`--`c17669` | 15,300 | For `r=0,...,16`, `i`, `a`, then `b != a`: \(-z_{r,i,a}-z_{r+1,i,b}+y_{i,a,b}\ge-1\). |
| `c17670`--`c17759` | 90 | For `i`, then `b != i`: \(-z_{0,i,b}+y_{i,i,b}\ge0\). |
| `c17760`--`c17849` | 90 | For `i`, then `a != i`: \(-z_{17,i,a}+y_{i,a,i}\ge0\). |
| `c17850`--`c19379` | 1,530 | For `i`, `j != i`, then `r=0,...,16`: \(-z_{r,i,j}-z_{r+1,j,i}\ge-1\). |
| `c19380`--`c19469` | 90 | For `i`, then away venue `v != i`: \(\sum_{a\ne v}y_{i,a,v}=1\). |
| `c19470`--`c19559` | 90 | For `i`, then away venue `v != i`: \(\sum_{b\ne v}y_{i,v,b}=1\). |
| `c19560`--`c19569` | 10 | For `i`: \(\sum_{a\ne i}y_{i,a,i}\ge3\). |
| `c19570`--`c19579` | 10 | For `i`: \(\sum_{b\ne i}y_{i,i,b}\ge3\). |
| `c19580`--`c42619` | 23,040 | The valid away-arc adjacency inequalities detailed below. |

For a fully explicit locator in the largest family, let
\(e_i(v)=v-\mathbf 1[v>i]\), the rank of \(v\) in
\(V\setminus\{i\}\), and let \(e_{i,v}(w)\) be the rank of \(w\) in
the sorted set \(V\setminus\{i,v\}\). For every team \(i\), away
anchor \(v\ne i\), round \(t=0,\ldots,15\), other away venue
\(w\notin\{i,v\}\), and direction flag \(d\in\{0,1\}\), row

\[
  c_{19580+2304i+256e_i(v)+16t+2e_{i,v}(w)+d}
\]

is

\[
 -(16-t)z_{t,i,v}
 -\sum_{s=t+2}^{17}z_{s,i,w}
 -(16-t)y_{i,a,b}\ \ge\ -2(16-t),
\]

where \((a,b)=(v,w)\) for \(d=0\), and \((a,b)=(w,v)\) for
\(d=1\). These are generated in the loop order
`i, v, t, w, d`.

The family counts sum to 42,620. The reconstructed row supports sum to
307,320 nonzeros, exactly matching the decompressed MPS.

## Why the schedule rows are exactly a TTP schedule

The first family gives each team exactly one visit to each of the other nine
venues. The `one_venue_per_team_round` rows give each team exactly one location
in each of 18 rounds, hence exactly nine away and nine home rounds.

It remains to check that the venue representation cannot encode idle teams or
multiple games. In a fixed round, let \(A_r\) and \(H_r\) be the number of
away and home teams. Every away team at venue \(j\) forces team \(j\) to be
home, and the visitor-capacity rows make these forced hosts distinct. Thus
\(A_r\le H_r=10-A_r\), so \(A_r\le5\). Across all rounds there are exactly
\(10\cdot9=90\) away appearances. Since there are 18 rounds and at most five
per round, every round has exactly five away teams and five home teams. The
injection from visitors to hosts is therefore a bijection in every round.
Every team plays exactly one game in every round.

Because team \(i\) visits venue \(j\) exactly once for each \(i\ne j\), every
ordered home/away fixture occurs exactly once. This is precisely a double
round robin.

The two four-round window families forbid four consecutive home games and
four consecutive away games. Since a team has exactly one status in each
round, they are exactly the standard maximum-three constraints.

For a fixed ordered pair \((i,j)\), the no-repeater row forbids an away game
`i at j` immediately followed by `j at i`. The same-orientation fixture cannot
repeat because it occurs only once. Applying the row to both ordered pairs
therefore gives exactly the standard no-repeater condition.

Conversely, assigning `z` from any standard ten-team double-round-robin
schedule satisfies every schedule row above. Hence this part is an equivalence,
not merely a relaxation.

## Why the travel variables and objective are exact

For team \(i\), form its physical route by prepending and appending its home
venue \(i\) to its 18 scheduled venues, and delete zero-length consecutive
steps. Call the resulting directed nonzero arc set \(P_i\).

The between-round, initial-home, and final-home implications force every arc
in \(P_i\) to have its corresponding `y` variable equal to one. A directed
nonzero arc cannot occur twice in the route: if its destination is an away
venue, that destination is visited only once; if its destination is home, its
origin is an away venue and is visited only once.

Every away venue is entered exactly once and left exactly once by the physical
route. The MPS imposes exactly one selected incoming and outgoing `y` arc at
each away venue. Since all physical arcs are already selected, these equalities
leave no room for an extra `y`. Any nonzero arc has at least one away endpoint,
so this argument covers every `y` variable. Thus

\[
             \{(a,b):y_{i,a,b}=1\}=P_i
\]

for every integer-feasible MPS point.

The objective has no coefficient on a `z` variable. For all ten teams and all
ordered \(a\ne b\), the coefficient of \(y_{i,a,b}\) is exactly

\[
       d(a,b)=\min\{|a-b|,10-|a-b|\}.
\]

The coefficient histogram is 200 occurrences each of distances 1, 2, 3, and
4, and 100 occurrences of distance 5. Therefore the MPS objective is exactly
the sum of physical circular travel distances, including departure from home
before the tournament and return home afterward.

## Why the additional travel rows do not restrict standard CIRC10

The minimum-three departure and return rows are valid consequences of the
schedule. Each team plays nine away games, while a road trip has length at
most three, so at least three road trips—and hence at least three departures
and returns—are necessary.

The final 23,040 inequalities are also valid strengthening rows. Write
\(m=16-t\). Their sign-reversed form is

\[
 m z_{t,i,v}+\sum_{s=t+2}^{17}z_{s,i,w}+m y_{i,a,b}\le2m,
\]

where the selected arc joins two different away venues \(v,w\). If both
`z` and `y` in the multiplied terms are one, exact route semantics place the
other endpoint in round \(t-1\) or \(t+1\), so the middle sum is zero. If at
most one multiplied term is one, the middle sum is at most one because away
venue \(w\) occurs only once, and \(m+1\le2m\) for \(m\ge1\). Hence every
standard schedule with its physical arc assignment satisfies every one of
these rows.

These two families are redundant at integer feasibility but strengthen the
linear relaxation. They do not introduce mirroring, a prescribed first round,
or any other nonstandard tournament rule.

## Candidate verification

The official CIRC10 schedule at
https://mat.tepper.cmu.edu/TOURN/circ10-242.txt was translated mechanically.
The exact checker reports:

```text
PASS exact MPS reconstruction
variables=2700 (1800 schedule, 900 directed travel arcs), all binary
rows=42620 nonzeros=307320 objective_terms=900 sense=minimize
PASS solution
objective=242
schedule_ones=180
arc_ones=129
team_distances=[24, 22, 28, 26, 26, 22, 28, 22, 22, 22]
```

Those team totals and the total 242 agree exactly with the archive file.
The same checker validates the current official MIPLIB solution at objective
256, with 131 route arcs.

As a separate implementation check, Gurobi 13.0.2 read the candidate as a MIP
start and reported maximum bound, constraint, and integrality violations all
equal to zero. This check used one thread and a one-second time limit. It is a
feasibility/quality check, not the source of the 242 lower bound.

Reproduction commands from repository root:

```text
python3 instances/circ10-3/scripts/audit_formulation.py \
  instances/circ10-3/input/circ10-3.mps.gz \
  instances/circ10-3/solutions/verified-242.sol

python3 instances/circ10-3/scripts/audit_formulation.py \
  instances/circ10-3/input/circ10-3.mps.gz \
  instances/circ10-3/solutions/official-256.sol.gz
```

The checker uses exact rational arithmetic and has no third-party Python
dependency.

## Primary-source chain and evidence status

1. Michael Trick's official Challenge Traveling Tournament archive defines the
   circular metric, double round robin, maximum-three rule, no-repeaters, and
   start/end-at-home travel convention. For constrained CIRC10 it records a
   feasible 242 schedule (Langford, 2005) and a matching 242 lower bound
   (Uthus, Riddle, and Guesgen, 2009):
   https://mat.tepper.cmu.edu/TOURN/
2. The exact archived 242 schedule is:
   https://mat.tepper.cmu.edu/TOURN/circ10-242.txt
3. David Uthus's author page states that the later IDA* approach solved
   `NL10`, `CIRC10`, and `GALAXY10`, and identifies the Journal of Scheduling
   article:
   http://daviduthus.org/
4. The authors' published optimal-solution file explicitly lists `CIRC10` and
   objective `242`:
   http://daviduthus.org/TTPOptimalSolutions.txt
5. Peer-reviewed paper: David C. Uthus, Patricia J. Riddle, and Hans W.
   Guesgen, “Solving the Traveling Tournament Problem with Iterative-Deepening
   A*,” *Journal of Scheduling* 15(5), 601--614 (2012):
   https://doi.org/10.1007/s10951-011-0237-x
6. The MIPLIB instance page currently labels the instance open and reports
   incumbent 256:
   https://miplib.zib.de/instance_details_circ10-3.html

Evidence classification:

- **Exact local proof:** MPS-to-TTP correspondence, absence of a hidden extra
  restriction, objective identity, and candidate feasibility/value 242.
- **Published computational result:** lower bound 242 for standard constrained
  CIRC10. This is primary-source supported but was not independently rerun.
- **Recommended closure route:** submit the 242 solution immediately; give this
  crosswalk plus the official archive and DOI as the optimality justification.
  If MIPLIB policy requires a machine-checkable lower-bound artifact rather
  than a peer-reviewed exhaustive-search result, request the historical IDA*
  logs/code from the authors or produce a new independent certificate. No
  further generic MIP search is needed to establish the semantic transfer.
