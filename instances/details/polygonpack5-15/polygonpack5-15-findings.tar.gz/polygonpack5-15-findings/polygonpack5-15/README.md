# polygonpack5-15：零容差几何审计与严格可行解

## 当前结论

本目录不声称求得全局最优解，也没有给出新的严格全局下界。
截至 2026-09-08，[MIPLIB 实例页](https://miplib.zib.de/instance_details_polygonpack5-15.html)
仍将该实例标为 `open`，页面 headline 为
`-55494687.6476085*`。

本次研究得到一个对原始 MPS **Decimal-zero 严格可行**的解：

```text
-55494687.647606651289167114364937742743466392774487603790135450562431565816687970
```

对原始 163,429 条约束、所有变量界及所有整数变量逐项使用 80 位
`Decimal` 重放后，违约数均为零。严格解保存在
[`solutions/polygonpack5-15-strict.sol`](solutions/polygonpack5-15-strict.sol)，
复核输出保存在
[`solutions/strict-candidate.validation.log`](solutions/strict-candidate.validation.log)。

这是一个最小化模型。严格点比页面 tolerance headline **差**
`0.000001848710832885635062257256533607225512396209864549437568434183312030`，
所以不能写成页面 incumbent 的改善。不过七个公开 revision 中仅 revision 3
是 Decimal-zero 可行点，其目标为 `-54836088.62253`；本次严格点相对这个唯一的
官方严格基线改善
`658599.025076651289167114364937742743466392774487603790135450562431565816687970`。
因此可以称为“相对已审计官方严格点的新严格 incumbent”，但不能称为
MIPLIB headline 改善，更不能称为 optimal。

## 问题背景

MIPLIB 将问题描述为：从 15 个允许非凸的多边形中选择总面积尽可能大的
子集，将它们无重叠地放入给定矩形，并允许每个多边形采用
0、90、180 或 270 度旋转。多边形没有完全包围的洞，但可以有凹入的
“bays”。官方页面没有给出 bibliography。

原始 MPS 的意大利语行名直接暴露了提交模型的结构：

- `contenimento`：容器内包含约束；
- `vincoli_di_scelta_della_slice`：为对象对及旋转对选择 no-fit slice；
- `vincoli_di_non_sovrapposizione`：激活 slice 后的线性无重叠半空间。

这种结构与 no-fit-polygon 的分片 MIP 建模一致。
[Lastra-Díaz 与 Ortuño 的 vertical-slice NFP 论文](https://arxiv.org/abs/2206.00032)
可作为方法背景，但本文不将它声称为本实例的来源。未找到原始多边形顶点，
所以这里的“几何恢复”是对已提交 decimal MPS 的精确恢复，不是对未知的
MPS 之前几何数据进行独立碰撞验证。

## 必需的 Gurobi 只读结构检查

原始压缩 MPS 先在 `euler4` 上由 Gurobi 13.0.1 读取；没有调用
`presolve()` 或 `optimize()`。完整记录见
[`analysis/gurobi-13.0.1-structure.json`](analysis/gurobi-13.0.1-structure.json)
和 [`logs/gurobi-13.0.1-structure.log`](logs/gurobi-13.0.1-structure.log)。

| 属性 | 数值 |
|---|---:|
| 变量 | 48,163 |
| 约束 | 163,429 |
| 非零元 | 804,740 |
| 连续变量 | 30 |
| `0..1` 整数变量 | 48,133 |
| 非零目标列 | 90：60 个负系数、30 个正系数 |
| 非零矩阵系数绝对值范围 | `1e-5` 至 `44681.07324` |

原始模型还含两条空且平凡满足的 `-Infinity` RHS 行；严格复核保留总行数
163,429，但不会把这两条平凡行误作违约。压缩 MPS SHA-256 为
`b17ab6bd54ec97a9f6d8ae89b22d6890a5a9ae4a6260ad5a8974974796156f12`。
输入文件为 [`input/polygonpack5-15.mps.gz`](input/polygonpack5-15.mps.gz)。

## 从 MPS 恢复的精确块结构

[`analysis/exact-geometry-structure.json`](analysis/exact-geometry-structure.json)
由 MPS 中的有限十进制字符串直接生成。

| 角色 | 数量 |
|---|---:|
| 对象坐标变量 | 30，即 15 对 `(x_i,y_i)` |
| presence/orientation 变量 | 60，即 `15 × 4` |
| no-fit slice 二元变量 | 48,073 |
| containment 行 | 60 |
| orientation-cardinality 行 | 30 |
| slice-choice 行 | 1,680 |
| no-fit 半空间行 | 161,659 |

1,680 个 choice 块恰为
`C(15,2) × 4 × 4`：每个无序对象对及旋转对各有一个。包含约束右端项
恢复出的容器尺寸为 `400 × 200`。目标函数的 60 个 orientation 项为负，
30 个非负坐标变量具有正成本，slice 变量成本为零；这一符号结构也用于后面的
presence-mask 目标层筛选。

大部分对象的包围盒或 orientation 目标数据不同。对象 9 和 10 有相同的包围盒及
坐标成本，但部分旋转目标仍有差别；本目录没有建立 projected no-fit union 的
精确等价证明，因此没有采用对象置换作为可证对称性。

## 全部公开 revision 的严格审计

审计直接读取 MPS 与 solution 文件中的十进制字符串；solution 未列出的变量
按零处理。下表中的“整数违约数”会计入任何非零整数距离，包括小于通常 solver
容差的量。所有 revision 的变量界违约数均为零。

| revision | literal objective | 行违约数 | 最大行违约 | 整数违约数 | Decimal-zero |
|---:|---:|---:|---:|---:|---|
| 1 | `-46870192.423645968399858367376` | 5 | `2.68e-14` | 0 | 否 |
| 2 | `-50940915.37687850269135430680` | 10 | `3.539350e-14` | 0 | 否 |
| 3 | `-54836088.62253` | 0 | `0` | 0 | **是** |
| 4 | `-54950356.265622078516613284742` | 11 | `1.96504234e-12` | 0 | 否 |
| 5 | `-55494653.8357854045779237770972024416` | 17 | `6.6597077934301472e-7` | 9 | 否 |
| 6 | `-55494686.5559903636301614737736` | 17 | `8.2603912e-13` | 0 | 否 |
| 7 | `-55494687.64760849726010661386` | 9 | `5.1602e-13` | 0 | 否 |

逐 revision 的完整证据为
[`analysis/polygonpack5-15-public-1-exact-audit.json`](analysis/polygonpack5-15-public-1-exact-audit.json)
至
[`analysis/polygonpack5-15-public-7-exact-audit.json`](analysis/polygonpack5-15-public-7-exact-audit.json)，
对应的原始公开解保存在 [`input/`](input/) 中。

MIPLIB 页面把若干非常小的违约显示为 `0e+00`，不代表 solution 文件按字面
十进制重放时恰好为零。这里的 Decimal-zero 判定有意比页面的 solver 容差更严格。

## 严格修复点

修复过程先将所有离散变量取整并固定，只对 30 个坐标变量求一个内部可行点；
随后在所有含坐标的不等式上保留至多 `1e-8` 的安全边距，优化坐标目标，并将坐标
有理化到分母不超过 `10^9`。最终再次读取原始 MPS 做全量复核。

严格点选中的对象与旋转为：

```text
{0:r2, 1:r3, 2:r3, 3:r3, 4:r2, 5:r2,
 10:r3, 11:r2, 12:r0, 13:r3, 14:r1}
```

机器可读审计为
[`analysis/strict-candidate-literal-audit.json`](analysis/strict-candidate-literal-audit.json)。
解、审计和第二套 checker 日志的 SHA-256 分别为：

```text
25cd76ec9819d44f798f8395109196f03eacd9a26ad59964ea84872f0d9cacb4  solutions/polygonpack5-15-strict.sol
ba48396dccadc9b47c8c0c847659cf8ad9c7b66ee5118f5feb7401a1507e886d  analysis/strict-candidate-literal-audit.json
3772739510d39fa790dc24554407e3c0ae7980f404da9fc1fd61798d00893935  solutions/strict-candidate.validation.log
```

## 求解实验

### 固定离散布局

COPT 8.0.4 固定全部 48,133 个离散变量，仅重新优化 30 个坐标变量，
在 0.262 秒内以 status 1 返回浮点目标 `-55494687.647608496`。
见 [`experiments/fixed-pattern-summary.json`](experiments/fixed-pattern-summary.json)。
该结果只说明给定离散布局下的数值坐标优化；严格参考值仍是上面的有理安全点。

### orientation/presence 局部分支

坐标与全部 slice 变量保持自由，只限制 60 个 orientation/presence 位相对严格点的
Hamming 距离。

| 半径 | 时限 / 线程 | 节点 | 浮点 incumbent | 浮点 bound | 结果 |
|---:|---:|---:|---:|---:|---|
| 2 | 600 秒 / 12 | 1,715 | `-55494687.647608496` | `-61595755.95874563` | 超时；离散布局未变 |
| 3 | 420 秒 / 10 | 516 | `-55494687.647608496` | `-64580442.63032283` | 超时；离散布局未变 |

摘要分别为 [`experiments/radius2-summary.json`](experiments/radius2-summary.json)
和 [`experiments/radius3-summary.json`](experiments/radius3-summary.json)。执行脚本的
`interpretation` 文本被硬编码成 radius 2；radius 3 文件中的
`radius_on_60_presence_orientation_bits=3` 才是正确参数。这个文字瑕疵不影响数值字段。

### 单/双对象邻域

[`experiments/object-neighborhoods/`](experiments/object-neighborhoods/) 保存 38 个
30 秒、4 线程摘要：15 个单对象自由邻域和 23 个定向双对象交换邻域。所有实验
均以 status 8 达到时限，共探索 26,219 个节点、累计求解约 1,141.62 秒；
38 个 incumbent 的离散签名都与严格起点相同，未产生需要进一步严格复核的新布局。

### 精确目标层筛选

[`analysis/objective-layer-screen.json`](analysis/objective-layer-screen.json)
枚举全部 `2^15=32,768` 个 presence masks。由于坐标目标项非负且 slice 成本为零，
每个 mask 的四旋转最小系数之和是严格的目标下界。该筛选证明 31,627 个 masks
不可能严格改善当前严格点，仍有 1,141 个 masks 未排除。

这只是目标层排除，不是原 MIP 的新全局 lower bound，也没有闭合剩余 masks。

## 证据边界

- 严格解为最小化问题提供严格可行上界，不提供下界。
- COPT 的 `best_bound` 是浮点 solver 输出；局部分支中的 bound 还只对应受限邻域。
- status 8 仅表示达到时限，不能解释为邻域最优或不可行。
- fixed-pattern status 1 只对固定离散布局成立。
- 当前没有可移植的全局最优性证明，不得将本实例标为 `optimal`。

## 复现零容差检查

从仓库根目录运行：

```bash
python common/exact_mps_solution_check.py \
  instances/polygonpack5-15/input/polygonpack5-15.mps.gz \
  instances/polygonpack5-15/solutions/polygonpack5-15-strict.sol \
  --tolerance 0

for revision in 1 2 3 4 5 6 7; do
  python common/exact_mps_solution_check.py \
    instances/polygonpack5-15/input/polygonpack5-15.mps.gz \
    instances/polygonpack5-15/input/polygonpack5-15-public-${revision}.sol.gz \
    --tolerance 0
done

python instances/polygonpack5-15/experiments/recover_geometry_xml.py \
  instances/polygonpack5-15/input/polygonpack5-15.mps.gz \
  instances/polygonpack5-15/analysis/reproduced-geometry-and-solution-audit.json \
  --solution instances/polygonpack5-15/solutions/polygonpack5-15-strict.sol \
  --active-limit 1e-8

python instances/polygonpack5-15/experiments/screen_object_subsets15.py \
  instances/polygonpack5-15/input/polygonpack5-15.mps.gz \
  -55494687.647606651289167114364937742743466392774487603790135450562431565816687970 \
  instances/polygonpack5-15/analysis/reproduced-objective-layer-screen.json

(cd instances/polygonpack5-15 && sha256sum -c SHA256SUMS)
```

第一个命令应报告零行、界和整数性违约；revision 循环会复现官方解审计表。
几何恢复和目标筛选命令会创建新的复现输出，
不要覆盖归档文件；生成后可与归档 JSON 的结论字段比较。
Windows PowerShell 没有 `sha256sum` 时，可用 `Get-FileHash -Algorithm SHA256`
逐项核对 `SHA256SUMS`。

## 文件清单与排除项

- `input/`：原始 MPS 与七个官方 solution revisions；
- `analysis/`：Gurobi 只读结构、精确几何结构、七个官方审计、严格点审计和 mask 筛选；
- `solutions/`：最终严格 solution 与第二 checker 日志；
- `experiments/`：结构恢复、目标筛选、COPT 脚本及局部实验摘要；
- `logs/`：Gurobi 读取日志；
- `SHA256SUMS`：除清单自身外，本目录全部归档文件的 SHA-256。

以下旧文件没有归档：

```text
polygonpack5-15-rev7-polished-literal-audit.json
```

该文件来自尚不支持 XML solution 的旧解析器，曾把非空 XML 解误当成全零解。
较早的 `*-polished-literal-audit-v2.json` 是 `1e-5` 安全边距版本，也没有保留；
最终依据是本目录的 `margin1e8` 严格解及两套零容差复核。
