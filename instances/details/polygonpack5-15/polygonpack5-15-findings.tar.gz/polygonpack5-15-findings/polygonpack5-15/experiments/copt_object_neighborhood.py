#!/usr/bin/env python3
"""Optimize one exact one/two-object orientation-presence neighborhood."""

from __future__ import annotations

import argparse
import gzip
import json
import xml.etree.ElementTree as ET
from pathlib import Path

import coptpy as cp
from coptpy import COPT


def read_solution(path: Path) -> dict[str, float]:
    raw = path.read_bytes()
    if raw[:2] == b"\x1f\x8b" or path.suffix == ".gz":
        raw = gzip.decompress(raw)
    text = raw.decode("utf-8", errors="replace")
    values: dict[str, float] = {}
    try:
        root = ET.fromstring(text)
        for node in root.iter():
            name, value = node.attrib.get("name"), node.attrib.get("value")
            if name is not None and value is not None:
                values[name] = float(value)
        if values:
            return values
    except ET.ParseError:
        pass
    for line in text.splitlines():
        fields = line.split()
        if len(fields) >= 2 and not fields[0].startswith(("#", "=")):
            try:
                values[fields[0]] = float(fields[1])
            except ValueError:
                pass
    return values


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("start", type=Path)
    parser.add_argument("outdir", type=Path)
    parser.add_argument("--objects", required=True, help="comma-separated object indices")
    parser.add_argument("--seconds", type=float, default=30.0)
    parser.add_argument("--threads", type=int, default=4)
    args = parser.parse_args()
    free_objects = sorted({int(x) for x in args.objects.split(",")})
    if not free_objects or min(free_objects) < 0 or max(free_objects) >= 15:
        raise ValueError("object indices must be in 0..14")
    args.outdir.mkdir(parents=True, exist_ok=True)

    values = read_solution(args.start)
    model = cp.Envr().createModel("polygonpack-object-neighborhood")
    model.read(str(args.mps))
    variables = model.getVars().getAll()
    orientation_groups = [variables[30 + 4 * i:34 + 4 * i] for i in range(15)]
    for i, group in enumerate(orientation_groups):
        if i in free_objects:
            continue
        for variable in group:
            value = float(round(values.get(variable.name, 0.0)))
            variable.setInfo(COPT.Info.LB, value)
            variable.setInfo(COPT.Info.UB, value)

    model.setMipStart(variables, [values.get(variable.name, 0.0) for variable in variables])
    model.loadMipStart()
    model.setParam(COPT.Param.Logging, 1)
    model.setLogFile(str(args.outdir / "copt.log"))
    model.setParam(COPT.Param.Threads, args.threads)
    model.setParam(COPT.Param.TimeLimit, args.seconds)
    model.setParam(COPT.Param.RelGap, 0.0)
    try:
        model.setParam(COPT.Param.FeasTol, 1e-9)
    except Exception:
        pass
    model.solve()

    result = {
        "free_objects": free_objects,
        "fixed_orientation_objects": [i for i in range(15) if i not in free_objects],
        "slice_variables": "all free",
        "coordinate_variables": "all free",
        "status": int(model.status),
        "has_solution": int(model.hasmipsol),
        "seconds": args.seconds,
        "threads": args.threads,
        "solver": f"COPT {COPT.VERSION_MAJOR}.{COPT.VERSION_MINOR}.{COPT.VERSION_TECHNICAL}",
    }
    for key, attr in (
        ("objective", "objval"), ("best_bound", "bestbnd"),
        ("relative_gap", "mipgap"), ("node_count", "nodecnt"),
        ("runtime", "solvingtime"),
    ):
        try:
            result[key] = float(getattr(model, attr))
        except Exception:
            pass
    if model.hasmipsol:
        model.writeSol(str(args.outdir / "incumbent.sol"))
    (args.outdir / "summary.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print("RESULT_JSON=" + json.dumps(result, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
