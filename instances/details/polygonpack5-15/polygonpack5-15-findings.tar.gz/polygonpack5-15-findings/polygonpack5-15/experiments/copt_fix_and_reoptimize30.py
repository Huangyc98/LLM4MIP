#!/usr/bin/env python3
"""Fix all discrete choices from a rounded solution and reoptimize placement.

This is a CPU-only COPT experiment.  The result is only a floating candidate;
the repository's Decimal replay against the original MPS remains authoritative.
"""

from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path

import coptpy as cp
from coptpy import COPT


def read_solution(path: Path) -> dict[str, float]:
    values: dict[str, float] = {}
    if path.suffix == ".gz":
        text = gzip.decompress(path.read_bytes()).decode("utf-8", errors="replace")
    else:
        text = path.read_text(encoding="utf-8")
    for raw in text.splitlines():
        fields = raw.split()
        if len(fields) < 2 or fields[0].startswith(("#", "=")):
            continue
        try:
            values[fields[0]] = float(fields[1])
        except ValueError:
            pass
    return values


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("pattern", type=Path)
    parser.add_argument("outdir", type=Path)
    parser.add_argument("--seconds", type=float, default=120.0)
    parser.add_argument("--continuous", type=int, default=30)
    args = parser.parse_args()

    args.outdir.mkdir(parents=True, exist_ok=True)
    supplied = read_solution(args.pattern)
    model = cp.Envr().createModel("polygonpack4-7-fixed")
    model.read(str(args.mps))
    variables = model.getVars().getAll()
    fixed = 0
    continuous = 0
    selected_orientation_variables: list[str] = []
    for index, variable in enumerate(variables):
        # MPS order is intentional: the first columns are continuous x/y
        # coordinates; every later column is a 0/1 discrete formulation var.
        if index < args.continuous:
            continuous += 1
            continue
        value = float(round(supplied.get(variable.name, 0.0)))
        variable.setInfo(COPT.Info.LB, value)
        variable.setInfo(COPT.Info.UB, value)
        fixed += 1
        if args.continuous <= index < args.continuous + 60 and value == 1.0:
            selected_orientation_variables.append(variable.name)

    model.setParam(COPT.Param.Logging, 1)
    model.setLogFile(str(args.outdir / "copt.log"))
    model.setParam(COPT.Param.Threads, 32)
    model.setParam(COPT.Param.TimeLimit, args.seconds)
    model.setParam(COPT.Param.RelGap, 0.0)
    try:
        model.setParam(COPT.Param.FeasTol, 1e-9)
    except Exception:
        pass
    model.solve()

    result = {
        "copt_version": [COPT.VERSION_MAJOR, COPT.VERSION_MINOR, COPT.VERSION_TECHNICAL],
        "cpu_only": True,
        "continuous_variables": continuous,
        "fixed_discrete_variables": fixed,
        "selected_orientation_variables": selected_orientation_variables,
        "status": int(model.status),
        "has_solution": int(model.hasmipsol),
    }
    for key, attr in (
        ("objective", "objval"),
        ("best_bound", "bestbnd"),
        ("relative_gap", "mipgap"),
        ("runtime", "solvingtime"),
    ):
        try:
            result[key] = float(getattr(model, attr))
        except Exception:
            pass
    if model.hasmipsol:
        model.writeSol(str(args.outdir / "placement.sol"))
    (args.outdir / "summary.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
