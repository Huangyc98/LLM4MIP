#!/usr/bin/env python3
"""Exact objective-layer screen over all 2^15 object-presence masks.

For a fixed set of selected objects, the sum of the most negative orientation
coefficient per object is a valid lower bound: each object selects at most one
orientation, all coordinate variables are nonnegative with positive objective
coefficients, and every slice variable has zero objective coefficient.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import sys
from decimal import Decimal
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import recover_geometry_xml as recover_geometry  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("incumbent", type=Decimal)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    model = recover_geometry.read_mps(args.mps)
    orientation_groups = []
    for i in range(15):
        row = f"n{i}_only_one_rotation"
        group = [v for v, c in model["rows"][row] if c == 1 and v in model["integer_variables"]]
        if len(group) != 4:
            raise AssertionError((row, group))
        orientation_groups.append(group)
    orientation_set = {v for group in orientation_groups for v in group}
    coordinate_variables = [v for v in model["variables"] if v not in model["integer_variables"]]
    if len(coordinate_variables) != 30:
        raise AssertionError(coordinate_variables)
    if any(model["lower"][v] < 0 or model["objective"].get(v, 0) <= 0 for v in coordinate_variables):
        raise AssertionError("coordinate nonnegativity/positive-cost premise failed")
    if any(
        model["objective"].get(v, 0) != 0
        for v in model["integer_variables"] - orientation_set
    ):
        raise AssertionError("a slice variable has nonzero objective")

    object_bounds = [min(model["objective"][v] for v in group) for group in orientation_groups]
    records = []
    for bits in itertools.product((0, 1), repeat=15):
        mask = "".join(str(bit) for bit in bits)
        lower_bound = sum((bound for bit, bound in zip(bits, object_bounds) if bit), Decimal(0))
        records.append({
            "mask": mask,
            "selected_count": sum(bits),
            "objective_lower_bound": str(lower_bound),
            "can_strictly_improve_incumbent": lower_bound < args.incumbent,
        })
    candidate_masks = [record["mask"] for record in records if record["can_strictly_improve_incumbent"]]
    result = {
        "input_sha256": hashlib.sha256(args.mps.read_bytes()).hexdigest(),
        "incumbent_objective": str(args.incumbent),
        "proof": "sum of minimum orientation coefficients; all remaining objective terms are nonnegative",
        "coordinate_variables_nonnegative_with_positive_cost": True,
        "slice_variables_zero_cost": True,
        "object_orientation_objective_lower_bounds": [str(value) for value in object_bounds],
        "all_32768_masks": records,
        "strict_improvement_candidate_count": len(candidate_masks),
        "strict_improvement_candidate_masks": candidate_masks,
    }
    with args.output.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({
        "incumbent_objective": result["incumbent_objective"],
        "strict_improvement_candidate_count": len(candidate_masks),
        "strict_improvement_candidate_masks": candidate_masks,
    }, indent=2))


if __name__ == "__main__":
    main()
