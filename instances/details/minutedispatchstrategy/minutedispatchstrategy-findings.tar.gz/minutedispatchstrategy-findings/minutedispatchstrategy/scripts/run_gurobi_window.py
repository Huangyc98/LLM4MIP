#!/usr/bin/env python3
"""Reoptimize one contiguous time window of the six primary binary schedules."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


PERIODS = 1440
PRIMARY_SERIES = {16, 17, 18, 19, 28, 29}


def read_solution(path: Path) -> dict[str, float]:
    values: dict[str, float] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        tokens = line.split()
        if len(tokens) >= 2 and not tokens[0].startswith(("=obj=", "#")):
            values[tokens[0]] = float(tokens[1])
    return values


def series_period(name: str) -> tuple[int, int] | None:
    if not name.startswith("x") or not name[1:].isdigit():
        return None
    index = int(name[1:])
    if not 1 <= index <= 29 * PERIODS:
        return None
    return (index - 1) // PERIODS + 1, (index - 1) % PERIODS + 1


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("--start", type=int, required=True)
    parser.add_argument("--end", type=int, required=True)
    parser.add_argument("--seconds", type=float, default=300)
    parser.add_argument("--threads", type=int, default=32)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if not 1 <= args.start <= args.end <= PERIODS:
        raise ValueError("window must satisfy 1 <= start <= end <= 1440")

    args.out.mkdir(parents=True, exist_ok=True)
    values = read_solution(args.solution)
    model = gp.read(str(args.model))
    model.Params.LogFile = str(args.out / "gurobi.log")
    model.Params.Threads = args.threads
    model.Params.TimeLimit = args.seconds
    model.Params.MIPGap = 0
    model.Params.FeasibilityTol = 1e-9
    model.Params.IntFeasTol = 1e-9
    model.Params.NumericFocus = 2
    model.Params.MIPFocus = 1

    fixed_primary = 0
    free_primary = 0
    for variable in model.getVars():
        coordinate = series_period(variable.VarName)
        if coordinate and coordinate[0] in PRIMARY_SERIES:
            if args.start <= coordinate[1] <= args.end:
                variable.BranchPriority = 100 if coordinate[0] in {16, 17, 18, 19} else 50
                free_primary += 1
            else:
                value = float(round(values.get(variable.VarName, 0.0)))
                variable.LB = value
                variable.UB = value
                fixed_primary += 1
        if variable.VarName in values:
            value = values[variable.VarName]
            if variable.VType in (GRB.BINARY, GRB.INTEGER):
                value = round(value)
            variable.Start = value

    model.optimize()
    result = {
        "window_start": args.start,
        "window_end": args.end,
        "fixed_primary_binaries": fixed_primary,
        "free_primary_binaries": free_primary,
        "status": int(model.Status),
        "runtime": model.Runtime,
        "node_count": model.NodeCount,
        "solution_count": model.SolCount,
    }
    if model.SolCount:
        result.update(
            objective=model.ObjVal,
            max_constraint_violation=model.ConstrVio,
            max_bound_violation=model.BoundVio,
            max_integrality_violation=model.IntVio,
        )
        model.write(str(args.out / "incumbent.sol"))
    result["best_bound"] = model.ObjBound
    result["relative_gap"] = model.MIPGap
    (args.out / "summary.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
