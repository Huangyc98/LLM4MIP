#!/usr/bin/env python3
"""Compare the six primary generator/battery schedules in two solution files."""

from __future__ import annotations

import argparse
import json
from decimal import Decimal
from pathlib import Path


PERIODS = 1440
PRIMARY_SERIES = (16, 17, 18, 19, 28, 29)


def read_bits(path: Path) -> dict[str, int]:
    values: dict[str, int] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        tokens = line.split()
        if len(tokens) >= 2 and tokens[0].startswith("x"):
            values[tokens[0]] = int(Decimal(tokens[1]) > Decimal("0.5"))
    return values


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("first", type=Path)
    parser.add_argument("second", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    args = parser.parse_args()
    first = read_bits(args.first)
    second = read_bits(args.second)

    by_series = {}
    differences = []
    for series in PRIMARY_SERIES:
        series_differences = []
        for period in range(1, PERIODS + 1):
            name = f"x{(series - 1) * PERIODS + period}"
            if first.get(name, 0) != second.get(name, 0):
                series_differences.append(period)
                differences.append([series, period])
        by_series[str(series)] = {
            "difference_count": len(series_differences),
            "different_periods": series_differences,
        }
    report = {
        "primary_series": list(PRIMARY_SERIES),
        "total_primary_binary_differences": len(differences),
        "by_series": by_series,
        "differences": differences,
    }
    args.json.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(report, indent=2, sort_keys=True) + "\n"
    args.json.write_text(payload, encoding="utf-8")
    print(payload, end="")


if __name__ == "__main__":
    main()
