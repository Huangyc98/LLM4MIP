#!/usr/bin/env python3
"""Run a reproducible COPT baseline with a supplied MIP start."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import coptpy as cp


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model", type=Path)
    parser.add_argument("--solution", type=Path)
    parser.add_argument("--seconds", type=float, default=1800)
    parser.add_argument("--threads", type=int, default=32)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()

    args.out.mkdir(parents=True, exist_ok=True)
    env = cp.Envr()
    model = env.createModel("minutedispatchstrategy")
    model.read(str(args.model))
    if args.solution:
        values = {}
        for line in args.solution.read_text(encoding="utf-8").splitlines():
            tokens = line.split()
            if len(tokens) >= 2 and not tokens[0].startswith(("=obj=", "#")):
                values[tokens[0]] = float(tokens[1])
        variables = model.getVars().getAll()
        model.setMipStart(variables, [values.get(variable.name, 0.0) for variable in variables])
        model.loadMipStart()
    model.setParam(cp.COPT.Param.Logging, 1)
    model.setLogFile(str(args.out / "copt.log"))
    model.setParam(cp.COPT.Param.Threads, args.threads)
    model.setParam(cp.COPT.Param.TimeLimit, args.seconds)
    model.setParam(cp.COPT.Param.RelGap, 0.0)
    model.solve()

    result = {"status": int(model.status), "solution_count": int(model.hasmipsol)}
    for key, attribute in (
        ("objective", "objval"),
        ("best_bound", "bestbnd"),
        ("relative_gap", "mipgap"),
        ("node_count", "nodecnt"),
        ("runtime", "solvingtime"),
    ):
        try:
            result[key] = float(getattr(model, attribute))
        except Exception:
            pass
    if model.hasmipsol:
        model.writeSol(str(args.out / "incumbent.sol"))
    (args.out / "summary.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
