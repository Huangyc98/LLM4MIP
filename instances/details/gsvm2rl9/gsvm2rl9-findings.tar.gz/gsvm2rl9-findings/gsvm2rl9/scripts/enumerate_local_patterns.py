#!/usr/bin/env python3
"""Enumerate fixed-z LPs in a small Hamming ball around a solution."""

from __future__ import annotations

import argparse
import itertools
import time
from decimal import Decimal
from pathlib import Path

import coptpy as cp
from coptpy import COPT


N = 200


def read_pattern(path: Path) -> list[int]:
    values: dict[str, int] = {}
    with path.open(encoding="utf-8") as handle:
        for raw in handle:
            tokens = raw.split()
            if len(tokens) >= 2 and tokens[0].startswith("z_"):
                values[tokens[0]] = int(Decimal(tokens[1]) > Decimal("0.5"))
    if len(values) != N:
        raise ValueError(f"expected {N} z values, found {len(values)}")
    return [values[f"z_{i + 1}"] for i in range(N)]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("output_solution", type=Path)
    parser.add_argument("--radius", type=int, default=2, choices=[0, 1, 2])
    args = parser.parse_args()
    center = read_pattern(args.solution)

    model = cp.Envr().createModel("gsvm-local-enumeration")
    model.setParam(COPT.Param.Logging, 0)
    model.setParam(COPT.Param.Threads, 1)
    model.readMps(str(args.mps))
    zvars = [model.getVarByName(f"z_{i + 1}") for i in range(N)]
    for var, value in zip(zvars, center):
        var.setType(COPT.CONTINUOUS)
        var.setInfo(COPT.Info.LB, float(value))
        var.setInfo(COPT.Info.UB, float(value))

    best = float("inf")
    best_alternative = float("inf")
    best_flips: tuple[int, ...] = ()
    best_alternative_flips: tuple[int, ...] = ()
    alternative_output = args.output_solution.with_name(
        args.output_solution.stem + "-alternative" + args.output_solution.suffix
    )
    solved = 0
    started = time.monotonic()
    for distance in range(args.radius + 1):
        for flips in itertools.combinations(range(N), distance):
            for index in flips:
                value = 1 - center[index]
                zvars[index].setInfo(COPT.Info.LB, float(value))
                zvars[index].setInfo(COPT.Info.UB, float(value))
            model.solve()
            if model.status == COPT.OPTIMAL:
                objective = float(model.objval)
                if distance > 0 and objective < best_alternative:
                    best_alternative = objective
                    best_alternative_flips = tuple(index + 1 for index in flips)
                    model.writeSol(str(alternative_output))
                if objective < best:
                    best = objective
                    best_flips = tuple(index + 1 for index in flips)
                    model.writeSol(str(args.output_solution))
            elif model.status != COPT.INFEASIBLE:
                raise RuntimeError(f"unexpected LP status {model.status} for flips={flips}")
            for index in flips:
                value = center[index]
                zvars[index].setInfo(COPT.Info.LB, float(value))
                zvars[index].setInfo(COPT.Info.UB, float(value))
            solved += 1
            if solved % 1000 == 0:
                print(
                    f"ENUM solved={solved} distance={distance} best={best:.15g} "
                    f"best_alternative={best_alternative:.15g} elapsed={time.monotonic() - started:.3f}",
                    flush=True,
                )
    print(
        f"FINAL solved={solved} radius={args.radius} best={best:.15g} "
        f"best_flips_1_based={best_flips} best_alternative={best_alternative:.15g} "
        f"best_alternative_flips_1_based={best_alternative_flips} "
        f"elapsed={time.monotonic() - started:.3f}",
        flush=True,
    )


if __name__ == "__main__":
    main()
