#!/usr/bin/env python3
"""Eliminate xi/z and encode the exact ramp loss with four-point SOS2 sets."""

from __future__ import annotations

import argparse
from decimal import Decimal
from pathlib import Path

from analyze_structure import parse_mps, read_solution


BREAKPOINTS = [Decimal(-101), Decimal(-99), Decimal(-1), Decimal(1)]
LOSS_MULTIPLIERS = [Decimal(4), Decimal(2), Decimal(2), Decimal(0)]


def fmt(value: Decimal) -> str:
    return format(value, "f")


def expression(terms: list[tuple[Decimal, str]]) -> str:
    rendered: list[str] = []
    for coefficient, var in terms:
        if coefficient == 0:
            continue
        sign = "+" if coefficient > 0 else "-"
        magnitude = abs(coefficient)
        body = var if magnitude == 1 else f"{fmt(magnitude)} {var}"
        rendered.append(f"{sign} {body}")
    text = " ".join(rendered)
    return text[2:] if text.startswith("+ ") else text


def wrapped(prefix: str, terms: list[tuple[Decimal, str]], suffix: str) -> str:
    tokens = expression(terms).split()
    lines = [prefix]
    for token in tokens:
        if len(lines[-1]) + len(token) + 1 > 110:
            lines.append("    " + token)
        else:
            lines[-1] += " " + token
    lines[-1] += suffix
    return "\n".join(lines)


def adjacent_weights(qvalue: Decimal) -> list[Decimal]:
    qvalue = min(Decimal(1), max(Decimal(-101), qvalue))
    weights = [Decimal(0)] * 4
    for index in range(3):
        left, right = BREAKPOINTS[index], BREAKPOINTS[index + 1]
        if qvalue <= right:
            weights[index + 1] = (qvalue - left) / (right - left)
            weights[index] = Decimal(1) - weights[index + 1]
            return weights
    weights[-1] = Decimal(1)
    return weights


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("output_lp", type=Path)
    parser.add_argument("--solution", type=Path)
    parser.add_argument("--start-output", type=Path)
    parser.add_argument("--objective-cutoff", type=Decimal)
    args = parser.parse_args()
    if bool(args.solution) != bool(args.start_output):
        raise ValueError("--solution and --start-output must be provided together")

    model = parse_mps(args.mps)
    columns = model["columns"]
    objective_row = model["objective_row"]
    assert isinstance(columns, dict) and isinstance(objective_row, str)
    c = [columns[f"xi_{i + 1}"][objective_row] for i in range(200)]

    objective_terms = [(Decimal(1), f"s_{j + 1}") for j in range(200)]
    objective_terms.extend(
        (c[i] * LOSS_MULTIPLIERS[k], f"lam_{i + 1}_{k}")
        for i in range(200)
        for k in range(4)
        if LOSS_MULTIPLIERS[k] != 0
    )
    lines = ["\\ Exact gsvm2rl9 ramp-loss value-function formulation", "Minimize"]
    lines.append(wrapped(" obj:", objective_terms, ""))
    lines.append("Subject To")
    for i in range(200):
        row = f"R{i}"
        # q=sum breakpoint*lambda and q <= signed margin A_i u + y_i b.
        terms = [(BREAKPOINTS[k], f"lam_{i + 1}_{k}") for k in range(4)]
        terms.extend(
            (-entries.get(row, Decimal(0)), var)
            for var, entries in columns.items()
            if (var.startswith("u_") or var == "b") and entries.get(row, Decimal(0)) != 0
        )
        lines.append(wrapped(f" margin_{i + 1}:", terms, " <= 0"))
        lines.append(f" lambda_sum_{i + 1}: " + " + ".join(f"lam_{i + 1}_{k}" for k in range(4)) + " = 1")
    for j in range(200):
        lines.append(f" abs_pos_{j + 1}: s_{j + 1} + u_{j + 1} >= 0")
        lines.append(f" abs_neg_{j + 1}: - s_{j + 1} + u_{j + 1} <= 0")
    if args.objective_cutoff is not None:
        lines.append(wrapped(" incumbent_cutoff:", objective_terms, f" <= {fmt(args.objective_cutoff)}"))
    lines.append("Bounds")
    for j in range(200):
        lines.append(f" u_{j + 1} free")
    lines.append(" b free")
    lines.append("SOS")
    for i in range(200):
        entries = " ".join(f"lam_{i + 1}_{k}:{k + 1}" for k in range(4))
        lines.append(f" ramp_{i + 1}: S2:: {entries}")
    lines.append("End")
    args.output_lp.write_text("\n".join(lines) + "\n", encoding="utf-8")

    if args.solution and args.start_output:
        values, _ = read_solution(args.solution)
        start = ["# SOS2 start derived from the official solution"]
        for j in range(200):
            start.append(f"s_{j + 1} {values.get(f's_{j + 1}', Decimal(0))}")
            start.append(f"u_{j + 1} {values.get(f'u_{j + 1}', Decimal(0))}")
        start.append(f"b {values.get('b', Decimal(0))}")
        for i in range(200):
            row = f"R{i}"
            margin = sum(
                entries.get(row, Decimal(0)) * values.get(var, Decimal(0))
                for var, entries in columns.items()
                if var.startswith("u_") or var == "b"
            )
            for k, weight in enumerate(adjacent_weights(margin)):
                start.append(f"lam_{i + 1}_{k} {weight}")
        args.start_output.write_text("\n".join(start) + "\n", encoding="utf-8")

    print(
        f"wrote {args.output_lp}; sos2=200; objective_cutoff={args.objective_cutoff}; "
        f"start={args.start_output}"
    )


if __name__ == "__main__":
    main()
