#!/usr/bin/env python3
"""Add a rigorous objective cutoff and a partition on z_181,...,z_200."""

from __future__ import annotations

import argparse
from decimal import Decimal
from pathlib import Path


def objective_constraint(source: str, cutoff: Decimal) -> str:
    block = source.split("Minimize\n", 1)[1].split("Subject To\n", 1)[0].strip()
    lines = [line.strip() for line in block.splitlines() if line.strip()]
    result = [f" rigorous_cutoff: {lines[0]}"]
    result.extend(f"  {line}" for line in lines[1:])
    result[-1] += f" <= {cutoff}"
    return "\n".join(result)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("base_lp", type=Path)
    parser.add_argument("case", choices=["none", "all_last20", "not_all_last20"])
    parser.add_argument("output", type=Path)
    parser.add_argument("--cutoff", type=Decimal, default=Decimal("7438.181167768"))
    args = parser.parse_args()
    source = args.base_lp.read_text(encoding="utf-8")
    if "Minimize\n" not in source or "Subject To\n" not in source or "Bounds\n" not in source:
        raise ValueError("unexpected LP sections")
    zsum = " + ".join(f"z_{i}" for i in range(181, 201))
    if args.case == "none":
        partition = ""
    elif args.case == "all_last20":
        partition = f" planted_cluster: {zsum} = 20"
    else:
        partition = f" outside_cluster_pattern: {zsum} <= 19"
    additions = objective_constraint(source, args.cutoff) + "\n"
    if partition:
        additions += partition + "\n"
    args.output.write_text(source.replace("Bounds\n", additions + "Bounds\n", 1), encoding="utf-8")
    print(f"wrote {args.output}; case={args.case}; cutoff={args.cutoff}")


if __name__ == "__main__":
    main()
