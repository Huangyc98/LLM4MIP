#!/usr/bin/env python3
"""Add one exact z fixing to an LP for disjunctive partitioning."""

from __future__ import annotations

import argparse
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("base_lp", type=Path)
    parser.add_argument("index", type=int)
    parser.add_argument("value", type=int, choices=[0, 1])
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    if not 1 <= args.index <= 200:
        raise ValueError("index must be in [1, 200]")
    source = args.base_lp.read_text(encoding="utf-8")
    fixing = f" partition_z_{args.index}: z_{args.index} = {args.value}\n"
    args.output.write_text(source.replace("Bounds\n", fixing + "Bounds\n", 1), encoding="utf-8")
    print(f"wrote {args.output}; z_{args.index}={args.value}")


if __name__ == "__main__":
    main()
