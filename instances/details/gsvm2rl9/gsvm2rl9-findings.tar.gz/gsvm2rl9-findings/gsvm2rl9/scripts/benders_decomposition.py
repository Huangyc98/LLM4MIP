#!/usr/bin/env python3
"""Exact Benders decomposition over the 200 ramp-loss binary variables.

This script requires the COPT 8 Python API.  The master contains only z and a
continuous recourse variable.  The subproblem is the original model with z
fixed and relaxed to continuous, so every optimality cut is valid for the
original MIP.
"""

from __future__ import annotations

import argparse
import time
from pathlib import Path

import coptpy as cp
from coptpy import COPT


N = 200
KNOWN_UB = 7438.181167768


def read_z_start(path: Path) -> list[int]:
    values: dict[str, float] = {}
    with path.open(encoding="utf-8") as handle:
        for raw in handle:
            tokens = raw.split()
            if len(tokens) >= 2 and tokens[0].startswith("z_"):
                values[tokens[0]] = float(tokens[1])
    return [int(values.get(f"z_{i + 1}", 0.0) > 0.5) for i in range(N)]


class RecourseLP:
    def __init__(self, mps: Path, threads: int) -> None:
        self.model = cp.Envr().createModel("gsvm-recourse")
        self.model.setParam(COPT.Param.Logging, 0)
        self.model.setParam(COPT.Param.Threads, threads)
        self.model.readMps(str(mps))
        self.zvars = [self.model.getVarByName(f"z_{i + 1}") for i in range(N)]
        self.rows = [self.model.getConstrByName(f"R{i}") for i in range(N)]
        self.costs = [float(var.getInfo(COPT.Info.Obj)) for var in self.zvars]
        for var in self.zvars:
            var.setType(COPT.CONTINUOUS)
            var.setInfo(COPT.Info.Obj, 0.0)

    def solve(self, zvalue: list[int]) -> tuple[float, list[float]]:
        for var, value in zip(self.zvars, zvalue):
            var.setInfo(COPT.Info.LB, float(value))
            var.setInfo(COPT.Info.UB, float(value))
        self.model.solve()
        if self.model.status != COPT.OPTIMAL:
            raise RuntimeError(f"recourse LP status {self.model.status}")
        qvalue = float(self.model.objval)
        dual = list(self.model.getInfo(COPT.Info.Dual, self.rows))
        gradient = [-100.0 * value for value in dual]
        return qvalue, gradient

    def write_solution(self, path: Path) -> None:
        self.model.writeSol(str(path))


def cut_value(qvalue: float, gradient: list[float], anchor: list[int], point: list[int]) -> float:
    return qvalue + sum(g * (x - x0) for g, x, x0 in zip(gradient, point, anchor))


class BendersCallback(cp.CallbackBase):
    def __init__(
        self,
        recourse: RecourseLP,
        zmaster: object,
        theta: object,
        costs: list[float],
        initial_ub: float,
        output_dir: Path,
        max_callbacks: int,
    ) -> None:
        super().__init__()
        self.recourse = recourse
        self.zmaster = zmaster
        self.theta = theta
        self.costs = costs
        self.best_ub = initial_ub
        self.output_dir = output_dir
        self.max_callbacks = max_callbacks
        self.calls = 0
        self.seen: set[tuple[int, ...]] = set()

    def callback(self) -> None:
        if self.where() != COPT.CBCONTEXT_MIPSOL:
            return
        zvalue = [int(self.getSolution(self.zmaster[i]) > 0.5) for i in range(N)]
        key = tuple(zvalue)
        theta_value = float(self.getSolution(self.theta))
        qvalue, gradient = self.recourse.solve(zvalue)
        zcost = sum(cost * value for cost, value in zip(self.costs, zvalue))
        actual = zcost + qvalue
        self.calls += 1
        self.seen.add(key)
        if actual < self.best_ub - 1e-7:
            self.best_ub = actual
            self.recourse.write_solution(self.output_dir / "benders_best.sol")
            with (self.output_dir / "benders_best_z.mst").open("w", encoding="utf-8") as handle:
                for i, value in enumerate(zvalue, start=1):
                    handle.write(f"z_{i} {value}\n")
        print(
            f"BENDERS call={self.calls} master_inc={self.getInfo(COPT.CBInfo.BestObj):.12g} "
            f"theta={theta_value:.12g} q={qvalue:.12g} zcost={zcost:.12g} "
            f"actual={actual:.12g} best_ub={self.best_ub:.12g} z_ones={sum(zvalue)}",
            flush=True,
        )
        if theta_value + 1e-7 < qvalue:
            rhs = qvalue + cp.quicksum(
                gradient[i] * (self.zmaster[i] - zvalue[i]) for i in range(N)
            )
            self.addLazyConstr(self.theta >= rhs)
        if self.calls >= self.max_callbacks:
            self.interrupt()


def add_cut(master: object, theta: object, zmaster: object, qvalue: float, gradient: list[float], anchor: list[int], name: str) -> None:
    rhs = qvalue + cp.quicksum(gradient[i] * (zmaster[i] - anchor[i]) for i in range(N))
    master.addConstr(theta >= rhs, name)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("z_start", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("--time-limit", type=float, default=900)
    parser.add_argument("--master-threads", type=int, default=24)
    parser.add_argument("--subproblem-threads", type=int, default=4)
    parser.add_argument("--max-callbacks", type=int, default=100000)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    official = read_z_start(args.z_start)
    recourse = RecourseLP(args.mps, args.subproblem_threads)
    q_zero, g_zero = recourse.solve([0] * N)
    q_official, g_official = recourse.solve(official)
    recourse.write_solution(args.output_dir / "official_z_reoptimized.sol")
    costs = recourse.costs

    official_zcost = sum(cost * value for cost, value in zip(costs, official))
    official_total = official_zcost + q_official
    print(
        f"SEED all_zero_q={q_zero:.12g} official_q={q_official:.12g} "
        f"official_zcost={official_zcost:.12g} official_total={official_total:.12g} "
        f"official_z_ones={sum(official)}",
        flush=True,
    )
    if cut_value(q_zero, g_zero, [0] * N, official) > q_official + 1e-5:
        raise RuntimeError("all-zero Benders cut fails at official point")
    if cut_value(q_official, g_official, official, [0] * N) > q_zero + 1e-5:
        raise RuntimeError("official Benders cut fails at all-zero point")

    master = cp.Envr().createModel("gsvm-benders-master")
    master.setParam(COPT.Param.Threads, args.master_threads)
    master.setParam(COPT.Param.TimeLimit, args.time_limit)
    master.setParam(COPT.Param.LazyConstraints, 1)
    master.setParam(COPT.Param.HeurLevel, 2)
    zmaster = master.addVars(N, vtype=COPT.BINARY, nameprefix="z")
    theta = master.addVar(lb=0.0, ub=COPT.INFINITY, name="theta")
    master_objective = cp.quicksum(costs[i] * zmaster[i] for i in range(N)) + theta
    master.setObjective(master_objective, COPT.MINIMIZE)
    master.addConstr(master_objective <= min(KNOWN_UB, official_total) + 1e-6, "known_upper_bound")
    add_cut(master, theta, zmaster, q_zero, g_zero, [0] * N, "seed_zero")
    add_cut(master, theta, zmaster, q_official, g_official, official, "seed_official")
    start_variables = [zmaster[i] for i in range(N)] + [theta]
    start_values = [float(value) for value in official] + [q_official]
    master.setMipStart(start_variables, start_values)
    master.loadMipStart()

    callback = BendersCallback(
        recourse,
        zmaster,
        theta,
        costs,
        min(KNOWN_UB, official_total),
        args.output_dir,
        args.max_callbacks,
    )
    master.setCallback(callback, COPT.CBCONTEXT_MIPSOL)
    started = time.monotonic()
    master.solve()
    elapsed = time.monotonic() - started
    print(
        f"FINAL status={master.status} best_obj={master.getAttr(COPT.Attr.BestObj):.12g} "
        f"best_bound={master.getAttr(COPT.Attr.BestBnd):.12g} "
        f"gap={master.getAttr(COPT.Attr.BestGap):.12g} callbacks={callback.calls} "
        f"unique={len(callback.seen)} best_valid_ub={callback.best_ub:.12g} elapsed={elapsed:.3f}",
        flush=True,
    )


if __name__ == "__main__":
    main()
