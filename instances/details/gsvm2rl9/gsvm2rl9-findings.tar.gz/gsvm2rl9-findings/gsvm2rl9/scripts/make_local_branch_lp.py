#!/usr/bin/env python3
"""Add an objective cutoff and a Hamming ball around a binary solution."""

from __future__ import annotations

import argparse
from decimal import Decimal
from pathlib import Path


def read_binary_pattern(path: Path) -> dict[str, int]:
    values: dict[str, int] = {}
    with path.open(encoding="utf-8") as handle:
        for raw in handle:
            tokens = raw.split()
            if len(tokens) >= 2 and tokens[0].startswith("z_"):
                values[tokens[0]] = int(Decimal(tokens[1]) > Decimal("0.5"))
    expected = {f"z_{i}" for i in range(1, 201)}
    if set(values) != expected:
        missing = sorted(expected - set(values))
        raise ValueError(f"binary pattern is incomplete; first missing names: {missing[:5]}")
    return values


def objective_constraint(source: str, cutoff: Decimal) -> str:
    block = source.split("Minimize\n", 1)[1].split("Subject To\n", 1)[0].strip()
    lines = [line.strip() for line in block.splitlines() if line.strip()]
    result = [f" improve_cutoff: {lines[0]}"]
    result.extend(f"  {line}" for line in lines[1:])
    result[-1] += f" <= {cutoff}"
    return "\n".join(result)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("base_lp", type=Path)
    parser.add_argument("binary_solution", type=Path)
    parser.add_argument("radius", type=int)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "--cutoff",
        type=Decimal,
        default=Decimal("7438.18102117005"),
        help="target below the tolerance-assisted official value",
    )
    args = parser.parse_args()
    if args.radius < 0:
        raise ValueError("radius must be nonnegative")
    source = args.base_lp.read_text(encoding="utf-8")
    if "Minimize\n" not in source or "Subject To\n" not in source or "Bounds\n" not in source:
        raise ValueError("unexpected LP sections")
    pattern = read_binary_pattern(args.binary_solution)
    ones = [name for name, value in pattern.items() if value]
    zeros = [name for name, value in pattern.items() if not value]
    terms = [f"- {name}" for name in ones] + [f"+ {name}" for name in zeros]
    hamming = " local_hamming: " + " ".join(terms) + f" <= {args.radius - len(ones)}"
    additions = objective_constraint(source, args.cutoff) + "\n" + hamming + "\n"
    args.output.write_text(source.replace("Bounds\n", additions + "Bounds\n", 1), encoding="utf-8")
    print(
        f"wrote {args.output}; radius={args.radius}; cutoff={args.cutoff}; "
        f"ones={len(ones)} zeros={len(zeros)}"
    )


if __name__ == "__main__":
    main()
