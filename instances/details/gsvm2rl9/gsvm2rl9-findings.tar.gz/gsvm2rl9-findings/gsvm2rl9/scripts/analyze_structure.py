#!/usr/bin/env python3
"""Recover the ramp-loss SVM structure and independently check a solution."""

from __future__ import annotations

import argparse
import gzip
import re
from collections import Counter, defaultdict
from decimal import Decimal
from pathlib import Path
from typing import TextIO

import numpy as np


INF = Decimal("Infinity")


def number(text: str) -> Decimal:
    return Decimal(text.replace("D", "E").replace("d", "e"))


def open_text(path: Path) -> TextIO:
    if path.suffix.lower() == ".gz":
        return gzip.open(path, "rt", encoding="latin-1")
    return path.open(encoding="latin-1")


def family(name: str) -> str:
    match = re.match(r"([A-Za-z]+)", name)
    return match.group(1) if match else name


def parse_mps(path: Path) -> dict[str, object]:
    section = ""
    objective_row = ""
    row_types: dict[str, str] = {}
    rhs: dict[str, Decimal] = defaultdict(Decimal)
    columns: dict[str, dict[str, Decimal]] = defaultdict(lambda: defaultdict(Decimal))
    integer_variables: set[str] = set()
    bounds: list[list[str]] = []
    integer_mode = False

    with open_text(path) as handle:
        for raw in handle:
            tokens = raw.split()
            if not tokens or tokens[0].startswith("*"):
                continue
            if tokens[0] in {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}:
                section = tokens[0]
                continue
            if section == "ROWS":
                kind, row = tokens[:2]
                row_types[row] = kind
                if kind == "N" and not objective_row:
                    objective_row = row
            elif section == "COLUMNS":
                if "'MARKER'" in tokens:
                    integer_mode = "'INTORG'" in tokens
                    continue
                var = tokens[0]
                if integer_mode:
                    integer_variables.add(var)
                for row, value in zip(tokens[1::2], tokens[2::2]):
                    columns[var][row] += number(value)
            elif section == "RHS":
                for row, value in zip(tokens[1::2], tokens[2::2]):
                    rhs[row] += number(value)
            elif section == "BOUNDS":
                bounds.append(tokens)

    lower = {var: Decimal(0) for var in columns}
    upper = {var: INF for var in columns}
    bound_types: Counter[str] = Counter()
    for tokens in bounds:
        kind, var = tokens[0], tokens[2]
        value = number(tokens[3]) if len(tokens) > 3 else Decimal(0)
        bound_types[kind] += 1
        if kind == "FR":
            lower[var], upper[var] = -INF, INF
        elif kind == "UP":
            upper[var] = value
        elif kind == "LO":
            lower[var] = value
        elif kind == "FX":
            lower[var] = upper[var] = value
        elif kind == "BV":
            lower[var], upper[var] = Decimal(0), Decimal(1)
            integer_variables.add(var)
        elif kind == "LI":
            lower[var] = value
            integer_variables.add(var)
        elif kind == "UI":
            upper[var] = value
            integer_variables.add(var)
        else:
            raise ValueError(f"unsupported bound type {kind}")

    return {
        "objective_row": objective_row,
        "row_types": row_types,
        "rhs": dict(rhs),
        "columns": {var: dict(entries) for var, entries in columns.items()},
        "integer_variables": integer_variables,
        "lower": lower,
        "upper": upper,
        "bound_types": bound_types,
    }


def read_solution(path: Path) -> tuple[dict[str, Decimal], Decimal | None]:
    values: dict[str, Decimal] = {}
    claimed: Decimal | None = None
    with open_text(path) as handle:
        for raw in handle:
            tokens = raw.split()
            if not tokens:
                continue
            if tokens[0] == "=obj=":
                claimed = number(tokens[1])
            elif not tokens[0].startswith("#") and len(tokens) >= 2:
                values[tokens[0]] = number(tokens[1])
    return values, claimed


def specialized_structure(model: dict[str, object]) -> dict[str, object]:
    columns = model["columns"]
    objective_row = model["objective_row"]
    assert isinstance(columns, dict) and isinstance(objective_row, str)
    expected = {"s": 200, "xi": 200, "z": 200, "u": 200, "b": 1}
    families = Counter(family(var) for var in columns)
    if families != Counter(expected):
        raise ValueError(f"unexpected variable families: {families}")

    signed_kernel = np.zeros((200, 200), dtype=np.float64)
    labels = np.zeros(200, dtype=np.int8)
    c = np.zeros(200, dtype=np.float64)
    for i in range(200):
        row = f"R{i}"
        b_coefficient = float(columns["b"].get(row, 0))
        if b_coefficient not in {-1.0, 1.0}:
            raise ValueError(f"unexpected b coefficient in {row}: {b_coefficient}")
        labels[i] = int(b_coefficient)
        for j in range(200):
            signed_kernel[i, j] = float(columns[f"u_{j + 1}"].get(row, 0))
        c[i] = float(columns[f"xi_{i + 1}"].get(objective_row, 0))
        if not np.isclose(
            float(columns[f"z_{i + 1}"].get(objective_row, 0)),
            2 * c[i],
            rtol=0,
            atol=2e-12,
        ):
            raise ValueError(f"z cost is not twice xi cost for sample {i + 1}")

    # The dense classification block stores y_i y_j K_ij.  The b coefficient
    # reveals y_i, so remove both label signs to recover the Gram matrix K.
    kernel = signed_kernel / (labels[:, None] * labels[None, :])
    symmetry_error = float(np.max(np.abs(kernel - kernel.T)))
    eigenvalues = np.linalg.eigvalsh((kernel + kernel.T) / 2)
    singular_values = np.linalg.svd(kernel, compute_uv=False)
    rank_threshold = singular_values[0] * max(kernel.shape) * np.finfo(float).eps
    numerical_rank = int(np.count_nonzero(singular_values > rank_threshold))

    print(f"variable_families={dict(sorted(families.items()))}")
    print(f"class_counts={dict(sorted(Counter(labels.tolist()).items()))}")
    print(f"C_counts={dict(sorted(Counter(c.tolist()).items()))}")
    print(f"kernel_symmetry_max_error={symmetry_error:.12g}")
    print(f"kernel_diagonal_range=({kernel.diagonal().min():.12g}, {kernel.diagonal().max():.12g})")
    print(f"kernel_eigenvalue_range=({eigenvalues[0]:.12g}, {eigenvalues[-1]:.12g})")
    print(f"kernel_negative_eigenvalues_below_-1e-8={int(np.count_nonzero(eigenvalues < -1e-8))}")
    print(f"kernel_numerical_rank={numerical_rank} threshold={rank_threshold:.12g}")
    print(f"smallest_singular_values={singular_values[-10:].tolist()}")
    print(f"last20_class_counts={dict(sorted(Counter(labels[180:].tolist()).items()))}")
    print(
        "kernel_block_means="
        f"first180={kernel[:180, :180].mean():.12g},"
        f"cross={kernel[:180, 180:].mean():.12g},"
        f"last20={kernel[180:, 180:].mean():.12g}"
    )
    return {"labels": labels, "c": c, "signed_kernel": signed_kernel, "kernel": kernel}


def summarize(model: dict[str, object]) -> dict[str, object]:
    row_types = model["row_types"]
    columns = model["columns"]
    integer_variables = model["integer_variables"]
    objective_row = model["objective_row"]
    bound_types = model["bound_types"]
    assert isinstance(row_types, dict) and isinstance(columns, dict)
    assert isinstance(integer_variables, set) and isinstance(objective_row, str)

    constraints = [row for row, kind in row_types.items() if kind != "N"]
    row_sizes: Counter[int] = Counter()
    for row in constraints:
        row_sizes[sum(row in entries for entries in columns.values())] += 1
    objective_counts = Counter(
        (family(var), coefficient)
        for var, entries in columns.items()
        if (coefficient := entries.get(objective_row, Decimal(0))) != 0
    )
    print(f"variables={len(columns)} constraints={len(constraints)}")
    print(f"integer_variables={len(integer_variables)}")
    print(f"row_types={dict(Counter(row_types[row] for row in constraints))}")
    print(f"row_sizes={dict(sorted(row_sizes.items()))}")
    print(f"bound_types={dict(bound_types)}")
    print("objective_family_coefficient_counts:")
    for (var_family, coefficient), count in sorted(objective_counts.items(), key=lambda item: (item[0][0], item[0][1])):
        print(f"  {var_family} coefficient={coefficient} count={count}")
    return specialized_structure(model)


def check_solution(model: dict[str, object], special: dict[str, object], solution_path: Path) -> None:
    columns = model["columns"]
    row_types = model["row_types"]
    rhs = model["rhs"]
    objective_row = model["objective_row"]
    lower = model["lower"]
    upper = model["upper"]
    integer_variables = model["integer_variables"]
    assert isinstance(columns, dict) and isinstance(row_types, dict) and isinstance(rhs, dict)
    assert isinstance(objective_row, str) and isinstance(lower, dict) and isinstance(upper, dict)
    assert isinstance(integer_variables, set)

    sparse, claimed = read_solution(solution_path)
    values = {var: sparse.get(var, Decimal(0)) for var in columns}
    objective = sum(
        entries.get(objective_row, Decimal(0)) * values[var]
        for var, entries in columns.items()
    )
    activities: dict[str, Decimal] = defaultdict(Decimal)
    for var, value in values.items():
        for row, coefficient in columns[var].items():
            if row != objective_row:
                activities[row] += coefficient * value

    violations: list[Decimal] = []
    for row, kind in row_types.items():
        if kind == "N":
            continue
        activity = activities[row]
        target = rhs.get(row, Decimal(0))
        if kind == "E":
            violation = abs(activity - target)
        elif kind == "L":
            violation = max(Decimal(0), activity - target)
        elif kind == "G":
            violation = max(Decimal(0), target - activity)
        else:
            raise ValueError(kind)
        violations.append(violation)

    bound_violations = sum(values[var] < lower[var] or values[var] > upper[var] for var in columns)
    integer_residuals = [abs(values[var] - values[var].to_integral_value()) for var in integer_variables]
    contributions: dict[str, Decimal] = defaultdict(Decimal)
    for var, entries in columns.items():
        contributions[family(var)] += entries.get(objective_row, Decimal(0)) * values[var]

    labels = special["labels"]
    c = special["c"]
    assert isinstance(labels, np.ndarray) and isinstance(c, np.ndarray)
    z_ones = [i for i in range(200) if values[f"z_{i + 1}"] > Decimal("0.5")]
    xi_positive = [i for i in range(200) if values[f"xi_{i + 1}"] > Decimal("1e-12")]
    z_by_class = Counter(int(labels[i]) for i in z_ones)
    xi_by_class = Counter(int(labels[i]) for i in xi_positive)
    margins = []
    for i in range(200):
        row = f"R{i}"
        margins.append(
            sum(
                entries.get(row, Decimal(0)) * values[var]
                for var, entries in columns.items()
                if var.startswith("u_") or var == "b"
            )
        )
    z_margins = [margins[i] for i in z_ones]
    inlier_margins = [margins[i] for i in range(200) if i not in set(z_ones)]
    u_support = [i for i in range(200) if abs(values[f"u_{i + 1}"]) > Decimal("1e-9")]

    print(f"solution={solution_path}")
    print(f"claimed_objective={claimed}")
    print(f"computed_objective={objective}")
    print(f"objective_difference={None if claimed is None else objective - claimed}")
    print(f"objective_contributions={dict(sorted(contributions.items()))}")
    print(f"sparse_entries={len(sparse)}")
    print(f"max_row_violation={max(violations, default=Decimal(0))}")
    print(f"row_violations_above_1e-9={sum(v > Decimal('1e-9') for v in violations)}")
    print(f"row_violations_above_1e-6={sum(v > Decimal('1e-6') for v in violations)}")
    print(
        f"bound_violations={bound_violations} "
        f"max_integrality_residual={max(integer_residuals, default=Decimal(0))} "
        f"integrality_violations_above_1e-9={sum(v > Decimal('1e-9') for v in integer_residuals)}"
    )
    print(f"z_equal_one={len(z_ones)} z_by_class={dict(sorted(z_by_class.items()))}")
    print(f"positive_xi={len(xi_positive)} xi_by_class={dict(sorted(xi_by_class.items()))}")
    print(f"u_support_above_1e-9={len(u_support)} indices_1_based={[i + 1 for i in u_support]}")
    print(
        f"z_margin_range=({min(z_margins, default=Decimal(0))}, {max(z_margins, default=Decimal(0))}) "
        f"inlier_margin_range=({min(inlier_margins, default=Decimal(0))}, "
        f"{max(inlier_margins, default=Decimal(0))})"
    )
    print(f"z_margins_below_-99={sum(value < Decimal(-99) for value in z_margins)}")
    print(f"z_indices_1_based={[i + 1 for i in z_ones]}")
    print(f"sum_C_for_z={sum(Decimal(str(c[i])) for i in z_ones)}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("--solution", type=Path)
    args = parser.parse_args()
    model = parse_mps(args.mps)
    special = summarize(model)
    if args.solution:
        check_solution(model, special, args.solution)


if __name__ == "__main__":
    main()
