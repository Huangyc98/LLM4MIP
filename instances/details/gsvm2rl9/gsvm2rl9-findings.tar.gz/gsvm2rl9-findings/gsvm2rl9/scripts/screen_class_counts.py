#!/usr/bin/env python3
"""Screen every feasible pair of class-specific z counts with an LP bound."""

from __future__ import annotations

import argparse
import csv
from pathlib import Path

import coptpy as cp
from coptpy import COPT


N = 200


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("output_csv", type=Path)
    parser.add_argument("--upper-bound", type=float, default=7438.181167768)
    parser.add_argument(
        "--fix-last20",
        action="store_true",
        help="fix z_181,...,z_200 to one before screening",
    )
    args = parser.parse_args()

    model = cp.Envr().createModel("gsvm-count-screen")
    model.setParam(COPT.Param.Logging, 0)
    model.setParam(COPT.Param.Threads, 1)
    model.readMps(str(args.mps))
    zvars = [model.getVarByName(f"z_{i + 1}") for i in range(N)]
    costs = [float(var.getInfo(COPT.Info.Obj)) for var in zvars]
    for var in zvars:
        var.setType(COPT.CONTINUOUS)
    if args.fix_last20:
        for var in zvars[180:]:
            var.setInfo(COPT.Info.LB, 1.0)
            var.setInfo(COPT.Info.UB, 1.0)
    negative = [i for i, cost in enumerate(costs) if cost > 200]
    positive = [i for i, cost in enumerate(costs) if cost < 200]
    if (len(negative), len(positive)) != (88, 112):
        raise RuntimeError(f"unexpected classes {(len(negative), len(positive))}")
    count_negative = model.addConstr(cp.quicksum(zvars[i] for i in negative) == 0, "count_negative")
    count_positive = model.addConstr(cp.quicksum(zvars[i] for i in positive) == 0, "count_positive")

    pairs = [
        (nneg, npos)
        for nneg in range(len(negative) + 1)
        for npos in range(len(positive) + 1)
        if not args.fix_last20 or npos >= 20
        if costs[negative[0]] * nneg + costs[positive[0]] * npos <= args.upper_bound + 1e-7
    ]
    results: list[tuple[int, int, float, float]] = []
    for index, (nneg, npos) in enumerate(pairs, start=1):
        count_negative.lb = count_negative.ub = float(nneg)
        count_positive.lb = count_positive.ub = float(npos)
        model.solve()
        if model.status != COPT.OPTIMAL:
            raise RuntimeError(f"LP status={model.status} at {(nneg, npos)}")
        bound = float(model.objval)
        zcost = costs[negative[0]] * nneg + costs[positive[0]] * npos
        results.append((nneg, npos, zcost, bound))
        if index % 50 == 0:
            print(f"SCREEN progress={index}/{len(pairs)} last=({nneg},{npos}) bound={bound:.12g}", flush=True)

    args.output_csv.parent.mkdir(parents=True, exist_ok=True)
    with args.output_csv.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["negative_z", "positive_z", "z_cost", "lp_bound", "gap_to_upper_bound"])
        for nneg, npos, zcost, bound in sorted(results, key=lambda row: row[3], reverse=True):
            writer.writerow([nneg, npos, f"{zcost:.15g}", f"{bound:.15g}", f"{args.upper_bound - bound:.15g}"])

    ruled_out = [row for row in results if row[3] >= args.upper_bound - 1e-7]
    candidates = sorted((row for row in results if row[3] < args.upper_bound - 1e-7), key=lambda row: row[3], reverse=True)
    print(
        f"FINAL fix_last20={args.fix_last20} pairs={len(results)} ruled_out_by_lp={len(ruled_out)} "
        f"remaining={len(candidates)} strongest_remaining={candidates[:20]}",
        flush=True,
    )


if __name__ == "__main__":
    main()
