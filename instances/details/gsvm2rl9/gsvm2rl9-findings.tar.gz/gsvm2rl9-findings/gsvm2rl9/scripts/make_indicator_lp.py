#!/usr/bin/env python3
"""Replace the 200 big-M ramp-loss rows by exact Gurobi indicators."""

from __future__ import annotations

import argparse
from decimal import Decimal
from pathlib import Path

from analyze_structure import parse_mps


def coefficient_text(value: Decimal) -> str:
    return format(value, "f")


def expression(terms: list[tuple[Decimal, str]]) -> str:
    rendered: list[str] = []
    for coefficient, var in terms:
        if coefficient == 0:
            continue
        sign = "+" if coefficient > 0 else "-"
        magnitude = abs(coefficient)
        body = var if magnitude == 1 else f"{coefficient_text(magnitude)} {var}"
        rendered.append(f"{sign} {body}")
    if not rendered:
        return "0"
    text = " ".join(rendered)
    return text[2:] if text.startswith("+ ") else text


def wrapped_constraint(prefix: str, terms: list[tuple[Decimal, str]], suffix: str) -> str:
    tokens = expression(terms).split()
    lines = [prefix]
    for token in tokens:
        if len(lines[-1]) + len(token) + 1 > 110:
            lines.append("    " + token)
        else:
            lines[-1] += (" " if lines[-1] else "") + token
    lines[-1] += suffix
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--objective-cutoff", type=Decimal)
    args = parser.parse_args()

    model = parse_mps(args.mps)
    columns = model["columns"]
    objective_row = model["objective_row"]
    rhs = model["rhs"]
    assert isinstance(columns, dict) and isinstance(objective_row, str) and isinstance(rhs, dict)

    objective_terms = [
        (entries.get(objective_row, Decimal(0)), var)
        for var, entries in columns.items()
        if entries.get(objective_row, Decimal(0)) != 0
    ]
    lines = ["\\ gsvm2rl9 indicator relaxation generated from the official MPS", "Minimize"]
    lines.append(wrapped_constraint(" obj:", objective_terms, ""))
    lines.append("Subject To")

    for i in range(200):
        row = f"R{i}"
        row_terms = [
            (entries.get(row, Decimal(0)), var)
            for var, entries in columns.items()
            if var != f"z_{i + 1}" and entries.get(row, Decimal(0)) != 0
        ]
        target = rhs.get(row, Decimal(0))
        lines.append(
            wrapped_constraint(
                f" ind_{i + 1}: z_{i + 1} = 0 ->",
                row_terms,
                f" >= {coefficient_text(target)}",
            )
        )

    for i in range(200):
        lines.append(f" abs_pos_{i + 1}: s_{i + 1} + u_{i + 1} >= 0")
        lines.append(f" abs_neg_{i + 1}: - s_{i + 1} + u_{i + 1} <= 0")
    if args.objective_cutoff is not None:
        lines.append(
            wrapped_constraint(
                " incumbent_cutoff:",
                objective_terms,
                f" <= {coefficient_text(args.objective_cutoff)}",
            )
        )

    lines.append("Bounds")
    for i in range(200):
        lines.append(f" xi_{i + 1} <= 2")
    for i in range(200):
        lines.append(f" u_{i + 1} free")
    lines.append(" b free")
    lines.append("Binaries")
    for start in range(0, 200, 16):
        lines.append(" " + " ".join(f"z_{i + 1}" for i in range(start, min(start + 16, 200))))
    lines.append("End")
    args.output.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(
        f"wrote {args.output}; indicators=200; variables={len(columns)}; "
        f"objective_cutoff={args.objective_cutoff}"
    )


if __name__ == "__main__":
    main()
