#!/usr/bin/env python3
"""Compact a liu solution by longest paths with all binary relations fixed."""

from __future__ import annotations

import argparse
from collections import deque
from pathlib import Path

from analyze_structure import parse_mps, read_solution, recover


def longest_paths(count: int, edges: list[tuple[int, int, int]]) -> list[int]:
    outgoing: list[list[tuple[int, int]]] = [[] for _ in range(count)]
    indegree = [0] * count
    for source, target, weight in edges:
        outgoing[source].append((target, weight))
        indegree[target] += 1
    queue = deque(index for index, degree in enumerate(indegree) if degree == 0)
    distance = [0] * count
    visited = 0
    while queue:
        source = queue.popleft()
        visited += 1
        for target, weight in outgoing[source]:
            distance[target] = max(distance[target], distance[source] + weight)
            indegree[target] -= 1
            if indegree[target] == 0:
                queue.append(target)
    if visited != count:
        raise ValueError("fixed precedence graph contains a cycle")
    return distance


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("solution", type=Path)
    parser.add_argument("output_solution", type=Path)
    args = parser.parse_args()

    model = parse_mps(args.mps)
    structure = recover(model)
    values = read_solution(args.solution)
    modules = structure["modules"]
    widths: list[int] = []
    heights: list[int] = []
    for module in modules:
        rotation = int(values.get(str(module["rotation"]), 0)) if module["rotation"] else 0
        widths.append(int(module["width"]) + int(module["width_delta"]) * rotation)
        heights.append(int(module["height"]) + int(module["height_delta"]) * rotation)

    code_variables = sorted(structure["pair_binary_variables"], key=lambda name: int(name[1:]))
    horizontal: list[tuple[int, int, int]] = []
    vertical: list[tuple[int, int, int]] = []
    cursor = 0
    for i in range(len(modules)):
        for j in range(i + 1, len(modules)):
            code = (
                int(values[code_variables[2 * cursor]]),
                int(values[code_variables[2 * cursor + 1]]),
            )
            if code == (0, 0):
                horizontal.append((i, j, widths[i]))
            elif code == (1, 0):
                horizontal.append((j, i, widths[j]))
            elif code == (0, 1):
                vertical.append((i, j, heights[i]))
            elif code == (1, 1):
                vertical.append((j, i, heights[j]))
            else:
                raise ValueError(code)
            cursor += 1

    xs = longest_paths(len(modules), horizontal)
    ys = longest_paths(len(modules), vertical)
    side = max(
        max(x + width for x, width in zip(xs, widths)),
        max(y + height for y, height in zip(ys, heights)),
    )
    values[str(structure["side"])] = side
    for module, x, y in zip(modules, xs, ys):
        values[str(module["x"])] = x
        values[str(module["y"])] = y

    lines = [
        f"=obj= {side}",
        "# Exact longest-path compaction with all binary relations fixed",
        f"# Objective value = {side}",
    ]
    lines.extend(f"{variable} {values.get(str(variable), 0)}" for variable in model["variables"])
    args.output_solution.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(
        f"wrote {args.output_solution}: side={side}, horizontal_edges={len(horizontal)}, "
        f"vertical_edges={len(vertical)}"
    )


if __name__ == "__main__":
    main()
