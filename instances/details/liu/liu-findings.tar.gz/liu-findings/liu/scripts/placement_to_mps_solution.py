#!/usr/bin/env python3
"""Translate CP-SAT module placements into a complete original-MPS solution."""

from __future__ import annotations

import argparse
import re
from pathlib import Path

from analyze_structure import parse_mps, recover


PLACEMENT = re.compile(
    r"^module=(?P<module>\d+) x=(?P<x>-?\d+) y=(?P<y>-?\d+) "
    r"width=(?P<width>\d+) height=(?P<height>\d+) rotation=(?P<rotation>[01])$"
)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("placement_log", type=Path)
    parser.add_argument("output_solution", type=Path)
    parser.add_argument("--side", type=int, required=True)
    args = parser.parse_args()

    model = parse_mps(args.mps)
    structure = recover(model)
    modules = structure["modules"]
    placed: dict[int, dict[str, int]] = {}
    for line in args.placement_log.read_text(encoding="utf-8").splitlines():
        match = PLACEMENT.match(line.strip())
        if match:
            record = {key: int(value) for key, value in match.groupdict().items()}
            placed[record["module"]] = record
    if sorted(placed) != list(range(1, len(modules) + 1)):
        raise ValueError(f"expected placements 1..{len(modules)}, found {sorted(placed)}")

    values = {str(variable): 0 for variable in model["variables"]}
    values[str(structure["side"])] = args.side
    for index, module in enumerate(modules, start=1):
        record = placed[index]
        rotation = record["rotation"]
        expected_width = int(module["width"]) + int(module["width_delta"]) * rotation
        expected_height = int(module["height"]) + int(module["height_delta"]) * rotation
        if (record["width"], record["height"]) != (expected_width, expected_height):
            raise ValueError(f"dimension mismatch for module {index}")
        values[str(module["x"])] = record["x"]
        values[str(module["y"])] = record["y"]
        if module["rotation"]:
            values[str(module["rotation"])] = rotation

    code_variables = sorted(structure["pair_binary_variables"], key=lambda name: int(name[1:]))
    cursor = 0
    code_counts = {(0, 0): 0, (1, 0): 0, (0, 1): 0, (1, 1): 0}
    for i in range(1, len(modules) + 1):
        first = placed[i]
        for j in range(i + 1, len(modules) + 1):
            second = placed[j]
            if first["x"] + first["width"] <= second["x"]:
                code = (0, 0)
            elif second["x"] + second["width"] <= first["x"]:
                code = (1, 0)
            elif first["y"] + first["height"] <= second["y"]:
                code = (0, 1)
            elif second["y"] + second["height"] <= first["y"]:
                code = (1, 1)
            else:
                raise ValueError(f"modules {i} and {j} overlap")
            values[code_variables[2 * cursor]] = code[0]
            values[code_variables[2 * cursor + 1]] = code[1]
            code_counts[code] += 1
            cursor += 1

    lines = [
        f"=obj= {args.side}",
        "# Complete exact solution translated from a CP-SAT rectangle placement",
        f"# Objective value = {args.side}",
    ]
    lines.extend(f"{variable} {values[str(variable)]}" for variable in model["variables"])
    args.output_solution.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"wrote {args.output_solution}; pair_code_counts={code_counts}")


if __name__ == "__main__":
    main()
