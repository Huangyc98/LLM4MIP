#!/usr/bin/env python3
"""Analyze critical paths, contacts, and saturated slices of a Liu layout."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from analyze_structure import parse_mps, recover


def relation(i, j, positive_rank, negative_rank):
    pi = positive_rank[i] < positive_rank[j]
    ni = negative_rank[i] < negative_rank[j]
    if pi and ni:
        return "left", i, j
    if not pi and not ni:
        return "left", j, i
    if pi and not ni:
        return "below", i, j
    return "below", j, i


def longest_path_data(lengths, edges):
    count = len(lengths)
    successors = [[] for _ in range(count)]
    predecessors = [[] for _ in range(count)]
    indegree = [0] * count
    for u, v in edges:
        successors[u].append(v)
        predecessors[v].append(u)
        indegree[v] += 1
    ready = sorted(i for i, degree in enumerate(indegree) if degree == 0)
    order = []
    while ready:
        u = ready.pop(0)
        order.append(u)
        for v in successors[u]:
            indegree[v] -= 1
            if indegree[v] == 0:
                ready.append(v)
        ready.sort()
    if len(order) != count:
        raise ValueError("precedence graph is cyclic")

    earliest = [0] * count
    chosen_predecessor = [-1] * count
    for v in order:
        for u in predecessors[v]:
            candidate = earliest[u] + lengths[u]
            if candidate > earliest[v]:
                earliest[v] = candidate
                chosen_predecessor[v] = u
    extent = max(earliest[i] + lengths[i] for i in range(count))

    latest = [extent - lengths[i] for i in range(count)]
    for u in reversed(order):
        if successors[u]:
            latest[u] = min(latest[v] - lengths[u] for v in successors[u])
    critical_nodes = [i for i in range(count) if latest[i] == earliest[i]]
    critical_edges = [
        (u, v)
        for u, v in edges
        if latest[u] == earliest[u]
        and latest[v] == earliest[v]
        and earliest[u] + lengths[u] == earliest[v]
    ]
    end = min(
        i for i in range(count) if earliest[i] + lengths[i] == extent
    )
    path = []
    while end >= 0:
        path.append(end)
        end = chosen_predecessor[end]
    path.reverse()
    return {
        "extent": extent,
        "earliest": earliest,
        "latest": latest,
        "node_slack": [latest[i] - earliest[i] for i in range(count)],
        "critical_nodes": critical_nodes,
        "critical_edges": critical_edges,
        "one_critical_path": path,
    }


def saturated_slices(starts, spans, orthogonal_starts, orthogonal_spans):
    boundaries = sorted(
        {0}
        | {value for value in orthogonal_starts}
        | {
            orthogonal_starts[i] + orthogonal_spans[i]
            for i in range(len(starts))
        }
    )
    slices = []
    for lower, upper in zip(boundaries, boundaries[1:]):
        if lower == upper:
            continue
        active = [
            i
            for i in range(len(starts))
            if orthogonal_starts[i] < upper
            and orthogonal_starts[i] + orthogonal_spans[i] > lower
        ]
        used = sum(spans[i] for i in active)
        slices.append(
            {"lower": lower, "upper": upper, "used": used, "modules": active}
        )
    return sorted(slices, key=lambda item: (-item["used"], item["lower"]))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("layout", type=Path)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()

    structure = recover(parse_mps(args.mps))
    modules = structure["modules"]
    layout = json.loads(args.layout.read_text(encoding="utf-8"))
    scale = int(layout["scale"])
    side = int(layout["side"])
    count = len(modules)
    if count != len(layout["x"]):
        raise ValueError("layout/module count mismatch")
    dimension_gcd = math.gcd(
        *(int(value) for m in modules for value in (m["width"], m["height"]))
    )
    if dimension_gcd != scale:
        raise ValueError("layout scale does not equal the dimension gcd")

    widths = []
    heights = []
    for i, module in enumerate(modules):
        rotated = int(layout["rotation"][i])
        width = int(module["height"] if rotated else module["width"]) // scale
        height = int(module["width"] if rotated else module["height"]) // scale
        widths.append(width)
        heights.append(height)
    xs = [int(value) for value in layout["x"]]
    ys = [int(value) for value in layout["y"]]
    positive_rank = [int(value) for value in layout["positive_rank"]]
    negative_rank = [int(value) for value in layout["negative_rank"]]
    if sorted(positive_rank) != list(range(count)) or sorted(negative_rank) != list(range(count)):
        raise ValueError("sequence ranks are not permutations")

    horizontal_edges = []
    vertical_edges = []
    relations = {}
    for i in range(count):
        for j in range(i + 1, count):
            kind, u, v = relation(i, j, positive_rank, negative_rank)
            relations[f"{i + 1}-{j + 1}"] = {"kind": kind, "before": u + 1, "after": v + 1}
            (horizontal_edges if kind == "left" else vertical_edges).append((u, v))

    horizontal = longest_path_data(widths, horizontal_edges)
    vertical = longest_path_data(heights, vertical_edges)
    if horizontal["extent"] > side or vertical["extent"] > side:
        raise ValueError("sequence pair does not fit the claimed side")

    contacts = []
    contact_neighbors = [set() for _ in range(count)]
    for i in range(count):
        for j in range(i + 1, count):
            y_overlap = min(ys[i] + heights[i], ys[j] + heights[j]) - max(ys[i], ys[j])
            x_overlap = min(xs[i] + widths[i], xs[j] + widths[j]) - max(xs[i], xs[j])
            kind = None
            if y_overlap > 0 and (xs[i] + widths[i] == xs[j] or xs[j] + widths[j] == xs[i]):
                kind = "vertical_contact"
            elif x_overlap > 0 and (ys[i] + heights[i] == ys[j] or ys[j] + heights[j] == ys[i]):
                kind = "horizontal_contact"
            if kind:
                contacts.append({"a": i + 1, "b": j + 1, "kind": kind})
                contact_neighbors[i].add(j)
                contact_neighbors[j].add(i)

    border = {
        "left": [i for i in range(count) if xs[i] == 0],
        "right": [i for i in range(count) if xs[i] + widths[i] == side],
        "bottom": [i for i in range(count) if ys[i] == 0],
        "top": [i for i in range(count) if ys[i] + heights[i] == side],
    }
    horizontal_slices = saturated_slices(xs, widths, ys, heights)
    vertical_slices = saturated_slices(ys, heights, xs, widths)
    core = set(horizontal["critical_nodes"]) | set(vertical["critical_nodes"])
    for item in horizontal_slices[:5] + vertical_slices[:5]:
        if item["used"] >= side - 2:
            core.update(item["modules"])
    one_hop = set(core)
    for i in core:
        one_hop.update(contact_neighbors[i])

    def one_based(values):
        return [value + 1 for value in values]

    for path_data in (horizontal, vertical):
        for key in ("critical_nodes", "one_critical_path"):
            path_data[key] = one_based(path_data[key])
        path_data["critical_edges"] = [
            [u + 1, v + 1] for u, v in path_data["critical_edges"]
        ]
    for values in border.values():
        values[:] = one_based(values)
    for slices in (horizontal_slices, vertical_slices):
        for item in slices:
            item["modules"] = one_based(item["modules"])

    report = {
        "side_scaled": side,
        "scale": scale,
        "target_scaled": side - 1,
        "widths": widths,
        "heights": heights,
        "horizontal_precedence": horizontal,
        "vertical_precedence": vertical,
        "border_modules": border,
        "contacts": contacts,
        "top_horizontal_slices": horizontal_slices[:10],
        "top_vertical_slices": vertical_slices[:10],
        "recommended_core_modules": one_based(sorted(core)),
        "recommended_core_plus_contacts": one_based(sorted(one_hop)),
        "relations": relations,
    }
    payload = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(payload, encoding="utf-8")
    print(payload, end="")


if __name__ == "__main__":
    main()
