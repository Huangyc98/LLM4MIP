#!/usr/bin/env python3
"""Translate a CP-SAT sequence-pair JSON payload to the original MPS variables."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from analyze_structure import parse_mps, recover


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("sequence_json", type=Path)
    parser.add_argument("output_solution", type=Path)
    args = parser.parse_args()

    model = parse_mps(args.mps)
    structure = recover(model)
    modules = structure["modules"]
    payload = json.loads(args.sequence_json.read_text(encoding="utf-8"))
    scale = int(payload["scale"])
    side = scale * int(payload["side"])
    if any(len(payload[key]) != len(modules) for key in ("x", "y", "rotation", "positive_rank", "negative_rank")):
        raise ValueError("sequence payload has the wrong module count")

    values = {str(variable): 0 for variable in model["variables"]}
    values[str(structure["side"])] = side
    for index, module in enumerate(modules):
        values[str(module["x"])] = scale * int(payload["x"][index])
        values[str(module["y"])] = scale * int(payload["y"][index])
        if module["rotation"]:
            values[str(module["rotation"])] = int(payload["rotation"][index])

    code_variables = sorted(structure["pair_binary_variables"], key=lambda name: int(name[1:]))
    cursor = 0
    for i in range(len(modules)):
        for j in range(i + 1, len(modules)):
            positive = int(payload["positive_rank"][i] < payload["positive_rank"][j])
            negative = int(payload["negative_rank"][i] < payload["negative_rank"][j])
            if (positive, negative) == (1, 1):
                code = (0, 0)
            elif (positive, negative) == (0, 0):
                code = (1, 0)
            elif (positive, negative) == (1, 0):
                code = (0, 1)
            else:
                code = (1, 1)
            values[code_variables[2 * cursor]] = code[0]
            values[code_variables[2 * cursor + 1]] = code[1]
            cursor += 1

    lines = [
        f"=obj= {side}",
        "# Exact solution translated from a CP-SAT sequence-pair JSON payload",
        f"# Objective value = {side}",
    ]
    lines.extend(f"{variable} {values[str(variable)]}" for variable in model["variables"])
    args.output_solution.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"wrote {args.output_solution}: side={side}")


if __name__ == "__main__":
    main()
