#!/usr/bin/env python3
"""Filter Liu rotations with many orientation-specific 2D DFF inequalities."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from analyze_structure import parse_mps, recover


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("--side", type=int, default=1080)
    parser.add_argument("--hint-json", type=Path)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    modules = recover(parse_mps(args.mps))["modules"]
    scale = math.gcd(
        *(int(value) for module in modules for value in (module["width"], module["height"]))
    )
    if args.side % scale:
        raise ValueError("side is not divisible by the dimension gcd")
    side = args.side // scale
    rectangles = [
        (int(module["width"]) // scale, int(module["height"]) // scale)
        for module in modules
    ]

    functions = [("identity", tuple(range(side + 1)), side)]
    for divisor in range(2, side + 1):
        functions.append(
            (f"floor/{divisor}", tuple(value // divisor for value in range(side + 1)), side // divisor)
        )
    for threshold in range(1, side // 2 + 1):
        functions.append(
            (
                f"threshold/{threshold}",
                tuple(
                    0 if value < threshold else side if value > side - threshold else value
                    for value in range(side + 1)
                ),
                side,
            )
        )
    # Fekete--Schepers stair functions u^(k).  Values use the common
    # denominator k*side, so all transformed-area tests remain integer.
    for k in range(1, side + 1):
        values = []
        for value in range(side + 1):
            scaled = (k + 1) * value
            if scaled % side == 0:
                values.append(value * k)
            else:
                values.append((scaled // side) * side)
        functions.append((f"stair/{k}", tuple(values), k * side))

    # Each valid DFF pair gives base + sum(delta_i r_i) <= capacity,
    # retaining the rotation choice instead of taking a per-item minimum.
    inequalities = {}
    universally_infeasible = None
    for name_x, fx, capacity_x in functions:
        for name_y, fy, capacity_y in functions:
            values0 = [fx[w] * fy[h] for w, h in rectangles]
            values1 = [fx[h] * fy[w] for w, h in rectangles]
            capacity = capacity_x * capacity_y
            minimum = sum(min(a, b) for a, b in zip(values0, values1))
            maximum = sum(max(a, b) for a, b in zip(values0, values1))
            if minimum > capacity:
                universally_infeasible = {
                    "x_function": name_x,
                    "y_function": name_y,
                    "minimum": minimum,
                    "capacity": capacity,
                }
                break
            if maximum <= capacity:
                continue
            delta = tuple(b - a for a, b in zip(values0, values1))
            rhs = capacity - sum(values0)
            previous = inequalities.get(delta)
            if previous is None or rhs < previous[0]:
                inequalities[delta] = (rhs, name_x, name_y)
        if universally_infeasible:
            break

    constraints = [
        (delta, rhs, name_x, name_y)
        for delta, (rhs, name_x, name_y) in inequalities.items()
    ]
    hint = None
    hint_violations = []
    if args.hint_json:
        hint = [
            int(value)
            for value in json.loads(args.hint_json.read_text(encoding="utf-8"))["rotation"]
        ]
        for delta, rhs, name_x, name_y in constraints:
            activity = sum(coefficient * value for coefficient, value in zip(delta, hint))
            if activity > rhs:
                hint_violations.append(
                    {
                        "x_function": name_x,
                        "y_function": name_y,
                        "violation": activity - rhs,
                    }
                )

    # Find one rotation vector satisfying every retained inequality. This is a
    # necessary-condition filter only; a survivor is not a packing.
    survivor = None
    nodes = 0
    if universally_infeasible is None:
        if hint is not None and not hint_violations:
            survivor = hint
        else:
            order = sorted(
                range(len(rectangles)),
                key=lambda i: -sum(abs(delta[i]) for delta, *_ in constraints),
            )
            assignment = [-1] * len(rectangles)

            def dfs(depth):
                nonlocal survivor, nodes
                nodes += 1
                for delta, rhs, *_ in constraints:
                    minimum = 0
                    for i, coefficient in enumerate(delta):
                        if assignment[i] < 0:
                            minimum += min(0, coefficient)
                        else:
                            minimum += coefficient * assignment[i]
                    if minimum > rhs:
                        return False
                if depth == len(order):
                    survivor = list(assignment)
                    return True
                variable = order[depth]
                preferred = hint[variable] if hint is not None else 0
                for value in (preferred, 1 - preferred):
                    assignment[variable] = value
                    if dfs(depth + 1):
                        return True
                assignment[variable] = -1
                return False

            dfs(0)

    report = {
        "side": args.side,
        "scale": scale,
        "function_count": len(functions),
        "function_pairs": len(functions) ** 2,
        "unique_orientation_constraints": len(constraints),
        "universally_infeasible": universally_infeasible,
        "hint_violation_count": len(hint_violations),
        "largest_hint_violations": sorted(
            hint_violations, key=lambda item: -item["violation"]
        )[:20],
        "orientation_dfs_nodes": nodes,
        "survivor": survivor,
        "conclusion": (
            "DFF contradiction for every orientation"
            if universally_infeasible or survivor is None
            else "orientation survives; no packing conclusion"
        ),
    }
    text = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(text, encoding="utf-8")
    print(text)


if __name__ == "__main__":
    main()
