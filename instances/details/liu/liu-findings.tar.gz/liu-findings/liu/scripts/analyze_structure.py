#!/usr/bin/env python3
"""Recover the 33-rectangle floorplan structure and check a solution."""

from __future__ import annotations

import argparse
import gzip
import math
from collections import Counter, defaultdict
from decimal import Decimal, getcontext
from pathlib import Path
from typing import TextIO


getcontext().prec = 80


def number(text: str) -> Decimal:
    return Decimal(text.replace("D", "E").replace("d", "e"))


def open_text(path: Path) -> TextIO:
    if path.suffix.lower() == ".gz":
        return gzip.open(path, "rt", encoding="latin-1")
    return path.open(encoding="latin-1")


def parse_mps(path: Path) -> dict[str, object]:
    section = ""
    objective_row = ""
    row_types: dict[str, str] = {}
    row_order: list[str] = []
    rhs: dict[str, Decimal] = defaultdict(Decimal)
    columns: dict[str, dict[str, Decimal]] = defaultdict(dict)
    variables: list[str] = []
    integer_variables: set[str] = set()
    bounds: list[list[str]] = []
    integer_mode = False

    with open_text(path) as handle:
        for raw in handle:
            tokens = raw.split()
            if not tokens or tokens[0].startswith("*"):
                continue
            if tokens[0] in {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}:
                section = tokens[0]
                if section == "RANGES":
                    raise ValueError("RANGES are not supported")
                continue
            if section == "ROWS":
                kind, row = tokens[:2]
                row_types[row] = kind
                row_order.append(row)
                if kind == "N" and not objective_row:
                    objective_row = row
            elif section == "COLUMNS":
                if "'MARKER'" in tokens:
                    integer_mode = "'INTORG'" in tokens
                    continue
                variable = tokens[0]
                if variable not in columns:
                    variables.append(variable)
                if integer_mode:
                    integer_variables.add(variable)
                for row, value in zip(tokens[1::2], tokens[2::2]):
                    coefficient = number(value)
                    columns[variable][row] = columns[variable].get(row, Decimal(0)) + coefficient
            elif section == "RHS":
                for row, value in zip(tokens[1::2], tokens[2::2]):
                    rhs[row] += number(value)
            elif section == "BOUNDS":
                bounds.append(tokens)

    lower = {variable: Decimal(0) for variable in variables}
    upper: dict[str, Decimal | None] = {variable: None for variable in variables}
    for tokens in bounds:
        kind, variable = tokens[0], tokens[2]
        value = number(tokens[3]) if len(tokens) > 3 else Decimal(0)
        if kind == "LO":
            lower[variable] = value
        elif kind == "UP":
            upper[variable] = value
        elif kind == "FX":
            lower[variable] = upper[variable] = value
        elif kind == "FR":
            lower[variable], upper[variable] = Decimal("-Infinity"), None
        elif kind == "BV":
            lower[variable], upper[variable] = Decimal(0), Decimal(1)
            integer_variables.add(variable)
        elif kind == "LI":
            lower[variable] = value
            integer_variables.add(variable)
        elif kind == "UI":
            upper[variable] = value
            integer_variables.add(variable)
        else:
            raise ValueError(f"unsupported bound type {kind}")

    rows: dict[str, dict[str, Decimal]] = {row: {} for row in row_types}
    for variable, entries in columns.items():
        for row, coefficient in entries.items():
            if coefficient:
                rows[row][variable] = coefficient
    return {
        "objective_row": objective_row,
        "row_types": row_types,
        "row_order": row_order,
        "rhs": dict(rhs),
        "columns": dict(columns),
        "rows": rows,
        "variables": variables,
        "integer_variables": integer_variables,
        "lower": lower,
        "upper": upper,
    }


def read_solution(path: Path) -> dict[str, Decimal]:
    values: dict[str, Decimal] = {}
    with open_text(path) as handle:
        for raw in handle:
            tokens = raw.split()
            if len(tokens) < 2 or tokens[0].startswith(("#", "=")):
                continue
            try:
                values[tokens[0]] = number(tokens[1])
            except Exception:
                continue
    return values


def recover(model: dict[str, object]) -> dict[str, object]:
    objective_row = model["objective_row"]
    columns = model["columns"]
    rows = model["rows"]
    row_types = model["row_types"]
    row_order = model["row_order"]
    rhs = model["rhs"]
    variables = model["variables"]
    integer_variables = model["integer_variables"]
    assert isinstance(objective_row, str) and isinstance(columns, dict)
    assert isinstance(rows, dict) and isinstance(row_types, dict) and isinstance(row_order, list)
    assert isinstance(rhs, dict) and isinstance(variables, list) and isinstance(integer_variables, set)

    objective_variables = [
        variable for variable in variables if columns[variable].get(objective_row, Decimal(0)) != 0
    ]
    if len(objective_variables) != 1:
        raise ValueError(f"expected one objective variable, found {objective_variables}")
    side = objective_variables[0]
    continuous_variables = set(variables) - integer_variables
    constraint_rows = [row for row in row_order if row_types[row] != "N"]
    boundary_rows = [row for row in constraint_rows if rows[row].get(side) == -1]
    if len(boundary_rows) % 2:
        raise ValueError("boundary rows do not occur in pairs")
    module_count = len(boundary_rows) // 2
    pair_count = module_count * (module_count - 1) // 2
    nonoverlap_rows = [row for row in constraint_rows if row not in set(boundary_rows)]
    if len(nonoverlap_rows) != 4 * pair_count:
        raise ValueError("unexpected non-overlap row count")

    big_m = max(abs(coefficient) for row in nonoverlap_rows for coefficient in rows[row].values())
    pair_binary_variables = {
        variable
        for variable in integer_variables
        if any(abs(coefficient) == big_m for coefficient in columns[variable].values())
    }
    orientation_variables = integer_variables - pair_binary_variables
    zero_matrix_variables = {
        variable
        for variable in variables
        if not any(coefficient for coefficient in columns[variable].values())
    }

    modules: list[dict[str, object]] = []
    used_rotations: set[str] = set()
    for index in range(module_count):
        xrow, yrow = boundary_rows[2 * index : 2 * index + 2]
        row_x, row_y = rows[xrow], rows[yrow]
        x_candidates = [variable for variable in row_x if variable in continuous_variables and variable != side]
        y_candidates = [variable for variable in row_y if variable in continuous_variables and variable != side]
        if len(x_candidates) != 1 or len(y_candidates) != 1:
            raise ValueError(f"unexpected coordinate variables in module {index + 1}")
        rotation_candidates = [
            variable
            for variable in set(row_x) | set(row_y)
            if variable in orientation_variables
        ]
        if len(rotation_candidates) > 1:
            raise ValueError(f"multiple rotations in module {index + 1}")
        rotation = rotation_candidates[0] if rotation_candidates else None
        if rotation:
            used_rotations.add(rotation)
        base_width = -rhs.get(xrow, Decimal(0))
        base_height = -rhs.get(yrow, Decimal(0))
        width_delta = row_x.get(rotation, Decimal(0)) if rotation else Decimal(0)
        height_delta = row_y.get(rotation, Decimal(0)) if rotation else Decimal(0)
        if base_width + width_delta != base_height or base_height + height_delta != base_width:
            raise ValueError(f"rotation does not swap dimensions in module {index + 1}")
        modules.append(
            {
                "index": index + 1,
                "x": x_candidates[0],
                "y": y_candidates[0],
                "rotation": rotation,
                "width": base_width,
                "height": base_height,
                "width_delta": width_delta,
                "height_delta": height_delta,
                "area": base_width * base_height,
            }
        )

    inactive_rotations = orientation_variables - used_rotations
    dimensions = Counter(
        tuple(sorted((int(module["width"]), int(module["height"])))) for module in modules
    )
    total_area = sum(int(module["area"]) for module in modules)
    dimension_gcd = math.gcd(
        *(int(value) for module in modules for value in (module["width"], module["height"]))
    )
    area_bound = math.ceil(math.sqrt(total_area))
    print(f"variables={len(variables)} constraints={len(constraint_rows)} nonzeros={sum(len(rows[row]) for row in constraint_rows)}")
    print(
        f"continuous={len(continuous_variables)} integer={len(integer_variables)} "
        f"objective_variable={side}"
    )
    print(
        f"modules={module_count} rectangle_pairs={pair_count} "
        f"nonoverlap_rows={len(nonoverlap_rows)} boundary_rows={len(boundary_rows)}"
    )
    print(
        f"orientation_binaries={len(orientation_variables)} pair_code_binaries={len(pair_binary_variables)} "
        f"inactive_square_rotations={sorted(inactive_rotations)} big_m={big_m}"
    )
    print(f"dimension_multiset={dict(sorted(dimensions.items()))}")
    print(
        f"total_rectangle_area={total_area} dimension_gcd={dimension_gcd} "
        f"area_lower_bound_on_square_side={area_bound}"
    )
    return {
        "side": side,
        "modules": modules,
        "pair_binary_variables": pair_binary_variables,
        "orientation_variables": orientation_variables,
        "nonoverlap_rows": nonoverlap_rows,
        "big_m": big_m,
        "total_area": total_area,
        "dimension_gcd": dimension_gcd,
        "area_bound": area_bound,
    }


def check_solution(model: dict[str, object], structure: dict[str, object], solution: Path) -> None:
    values = read_solution(solution)
    rows = model["rows"]
    row_types = model["row_types"]
    rhs = model["rhs"]
    lower = model["lower"]
    upper = model["upper"]
    integer_variables = model["integer_variables"]
    variables = model["variables"]
    side = structure["side"]
    modules = structure["modules"]
    pair_binary_variables = structure["pair_binary_variables"]
    total_area = structure["total_area"]
    assert isinstance(rows, dict) and isinstance(row_types, dict) and isinstance(rhs, dict)
    assert isinstance(lower, dict) and isinstance(upper, dict) and isinstance(integer_variables, set)
    assert isinstance(variables, list) and isinstance(side, str) and isinstance(modules, list)
    assert isinstance(pair_binary_variables, set) and isinstance(total_area, int)

    violations: list[tuple[Decimal, str]] = []
    for row, kind in row_types.items():
        if kind == "N":
            continue
        activity = sum(coefficient * values.get(variable, Decimal(0)) for variable, coefficient in rows[row].items())
        target = rhs.get(row, Decimal(0))
        if kind == "L":
            violation = max(Decimal(0), activity - target)
        elif kind == "G":
            violation = max(Decimal(0), target - activity)
        elif kind == "E":
            violation = abs(activity - target)
        else:
            raise ValueError(kind)
        if violation:
            violations.append((violation, row))
    violations.sort(reverse=True)
    bound_violation = Decimal(0)
    for variable in variables:
        value = values.get(variable, Decimal(0))
        bound_violation = max(bound_violation, lower[variable] - value)
        if upper[variable] is not None:
            bound_violation = max(bound_violation, value - upper[variable])
    integrality = max(
        (abs(values.get(variable, Decimal(0)) - values.get(variable, Decimal(0)).to_integral_value()) for variable in integer_variables),
        default=Decimal(0),
    )

    placed: list[tuple[Decimal, Decimal, Decimal, Decimal]] = []
    rotation_ones = 0
    for module in modules:
        rotation = module["rotation"]
        rvalue = values.get(rotation, Decimal(0)) if rotation else Decimal(0)
        rotation_ones += int(rvalue > Decimal("0.5"))
        width = module["width"] + module["width_delta"] * rvalue
        height = module["height"] + module["height_delta"] * rvalue
        xvalue = values.get(module["x"], Decimal(0))
        yvalue = values.get(module["y"], Decimal(0))
        placed.append((xvalue, yvalue, width, height))
    max_x = max(x + width for x, _, width, _ in placed)
    max_y = max(y + height for _, y, _, height in placed)
    side_value = values.get(side, Decimal(0))
    code_variables = sorted(pair_binary_variables, key=lambda name: int(name[1:]))
    if len(code_variables) % 2:
        raise ValueError("pair-code binary count is odd")
    code_values = [
        (
            int(values.get(code_variables[index], Decimal(0)) > Decimal("0.5")),
            int(values.get(code_variables[index + 1], Decimal(0)) > Decimal("0.5")),
        )
        for index in range(0, len(code_variables), 2)
    ]
    pair_codes = Counter(code_values)
    module_count = len(modules)
    positive_before: dict[tuple[int, int], int] = {}
    negative_before: dict[tuple[int, int], int] = {}
    cursor = 0
    for i in range(module_count):
        for j in range(i + 1, module_count):
            first, second = code_values[cursor]
            positive_before[i, j] = 1 - first
            negative_before[i, j] = int(first == second)
            cursor += 1
    sequence_cycles = []
    for order in (positive_before, negative_before):
        cycles = 0
        for i in range(module_count):
            for j in range(i + 1, module_count):
                for k in range(j + 1, module_count):
                    cycles += int(order[i, j] == order[j, k] and order[i, k] != order[i, j])
        sequence_cycles.append(cycles)
    tolerance = Decimal("1e-7")
    contacts = 0
    for i, (xi, yi, wi, hi) in enumerate(placed):
        for xj, yj, wj, hj in placed[i + 1 :]:
            vertical_overlap = min(yi + hi, yj + hj) - max(yi, yj)
            horizontal_overlap = min(xi + wi, xj + wj) - max(xi, xj)
            horizontal_touch = min(abs(xi + wi - xj), abs(xj + wj - xi)) <= tolerance and vertical_overlap > tolerance
            vertical_touch = min(abs(yi + hi - yj), abs(yj + hj - yi)) <= tolerance and horizontal_overlap > tolerance
            contacts += int(horizontal_touch or vertical_touch)

    print(f"solution={solution}")
    print(
        f"objective_side={side_value} max_x_extent={max_x} max_y_extent={max_y} "
        f"unused_area={side_value * side_value - total_area}"
    )
    print(
        f"rotation_ones={rotation_ones} pair_code_counts={dict(sorted(pair_codes.items()))} "
        f"touching_pairs={contacts} implied_sequence_cycles={sequence_cycles}"
    )
    print(
        f"exact_row_violations={len(violations)} row_violations_above_1e-6={sum(v > Decimal('1e-6') for v, _ in violations)} "
        f"max_row_violation={violations[0][0] if violations else 0}"
    )
    print(f"max_bound_violation={bound_violation} max_integrality_residual={integrality}")
    if violations:
        print(f"largest_violated_rows={violations[:10]}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("--solution", type=Path)
    args = parser.parse_args()
    model = parse_mps(args.mps)
    structure = recover(model)
    if args.solution:
        check_solution(model, structure, args.solution)


if __name__ == "__main__":
    main()
