#!/usr/bin/env python3
"""Build the exact L <= target feasibility model with a valid tighter big-M.

The original model uses M=8398.  Once the square side is bounded by ``target``,
every placed rectangle satisfies coordinate + extent <= target and every other
coordinate is nonnegative.  Consequently ``target`` itself is a valid M for
each deactivated pairwise separation inequality.
"""

from __future__ import annotations

import argparse
import re
from decimal import Decimal, ROUND_HALF_EVEN
from pathlib import Path


ROW = re.compile(r"^( c(?P<number>\d+):.*?)(?P<sense><=|>=|=)\s*(?P<rhs>-?[0-9.]+)\s*$")


def decimal_text(value: Decimal) -> str:
    integral = value.to_integral_value()
    return str(integral) if value == integral else format(value.normalize(), "f")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input_lp", type=Path)
    parser.add_argument("output_lp", type=Path)
    parser.add_argument("--old-m", type=Decimal, default=Decimal(8398))
    parser.add_argument("--target", type=Decimal, default=Decimal(1083))
    parser.add_argument("--pair-rows", type=int, default=2112)
    args = parser.parse_args()

    if args.target <= 0 or args.target >= args.old_m:
        raise ValueError("target must be positive and smaller than the original M")

    output: list[str] = []
    changed_rows = 0
    cutoff_added = False
    token = re.compile(rf"(?<![0-9.]){re.escape(decimal_text(args.old_m))}(?![0-9.])")

    for line in args.input_lp.read_text(encoding="utf-8").splitlines():
        match = ROW.match(line)
        if match and int(match.group("number")) <= args.pair_rows:
            rhs = Decimal(match.group("rhs"))
            multiple = (rhs / args.old_m).to_integral_value(rounding=ROUND_HALF_EVEN)
            residual = rhs - multiple * args.old_m
            if abs(residual) >= args.old_m / 2:
                raise ValueError(f"cannot identify the M multiple in {line}")
            lhs = token.sub(decimal_text(args.target), match.group(1))
            new_rhs = residual + multiple * args.target
            line = f"{lhs}{match.group('sense')} {decimal_text(new_rhs)}"
            changed_rows += 1
        if line == "Bounds":
            output.append(f" target_side_1083: x1 <= {decimal_text(args.target)}")
            cutoff_added = True
        output.append(line)

    if changed_rows != args.pair_rows:
        raise ValueError(f"changed {changed_rows} pair rows, expected {args.pair_rows}")
    if not cutoff_added:
        raise ValueError("Bounds section not found")
    args.output_lp.write_text("\n".join(output) + "\n", encoding="utf-8")
    print(
        f"wrote {args.output_lp}: tightened {changed_rows} rows from "
        f"M={args.old_m} to M={args.target} and added x1 <= {args.target}"
    )


if __name__ == "__main__":
    main()
