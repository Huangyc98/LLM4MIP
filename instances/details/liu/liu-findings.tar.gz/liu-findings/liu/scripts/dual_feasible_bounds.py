#!/usr/bin/env python3
"""Search rotation-safe dual-feasible-function area bounds for liu."""

from __future__ import annotations

import argparse
import math
from pathlib import Path

from analyze_structure import parse_mps, recover


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("--side", type=int, default=1082)
    args = parser.parse_args()
    modules = recover(parse_mps(args.mps))["modules"]
    scale = math.gcd(
        *(int(value) for module in modules for value in (module["width"], module["height"]))
    )
    side = args.side // scale
    rectangles = [(int(module["width"]) // scale, int(module["height"]) // scale) for module in modules]

    functions: list[tuple[str, list[int], int]] = [("identity", list(range(side + 1)), side)]
    for divisor in range(2, side + 1):
        values = [value // divisor for value in range(side + 1)]
        functions.append((f"floor/{divisor}", values, side // divisor))
    for threshold in range(1, side // 2 + 1):
        values = [
            0 if value < threshold else side if value > side - threshold else value
            for value in range(side + 1)
        ]
        functions.append((f"threshold/{threshold}", values, side))

    best: list[tuple[float, int, int, str, str]] = []
    for name_x, fx, capacity_x in functions:
        for name_y, fy, capacity_y in functions:
            transformed = sum(
                min(fx[width] * fy[height], fx[height] * fy[width])
                for width, height in rectangles
            )
            capacity = capacity_x * capacity_y
            ratio = transformed / capacity if capacity else 0.0
            best.append((ratio, transformed, capacity, name_x, name_y))
    best.sort(reverse=True)
    print(f"side={args.side} scale={scale} searched_function_pairs={len(functions) ** 2}")
    for ratio, transformed, capacity, name_x, name_y in best[:20]:
        print(
            f"ratio={ratio:.9f} transformed={transformed} capacity={capacity} "
            f"x={name_x} y={name_y} proves_infeasible={transformed > capacity}"
        )


if __name__ == "__main__":
    main()
