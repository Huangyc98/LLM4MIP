# `liu` 结构化求解报告

实验日期：2026-09-01；补充实验：2026-09-07（Asia/Shanghai）

## 结论

`liu` 是 33 个可旋转矩形装入最小正方形的 VLSI floorplanning 问题。本轮找到了边长
**1082** 的新解。把 CP-SAT 布局翻译回原始 1,156 个 MPS 变量后，2,178 行约束、变量
边界和整数性都没有违反。该解严格优于官网 exact objective 1084；全局最优仍未证明。

本轮最重要的新结论不是通用求解器的下界，而是一个结构证书：**最优边长一定可以取
偶数**。面积下界为 1073，因此严格全局下界可提高到 **1074**。这个结论先把官网
1084 的改进目标缩减为 1082，sequence-pair 模型随后找到了 1082；下一档唯一需要
判定的改进目标是 1080。

MIPLIB 页面当前显示 `1083.984782*`，但官网同时标注 exact objective 为 1084、最大
约束违反为 `0.007962`。本地十进制逐行重算得到 19 行违反超过 `1e-6`，最大也是
`0.007962`（`c135`）。因此它不是严格意义上优于 1084 的可行解。

## 从 MPS 恢复出的模型

原模型共有 1,156 个变量、2,178 行和 10,626 个非零元：

| 变量/约束 | 数量 | 含义 |
|---|---:|---|
| 连续变量 | 67 | 正方形边长 `x1` 加 33 对坐标 |
| 旋转二元变量 | 33 | 每个矩形一个；两个正方形的旋转变量实际无效 |
| 位置编码二元变量 | 1,056 | 528 对矩形，每对两个 bit |
| 非重叠行 | 2,112 | 每对矩形四行 |
| 边界行 | 66 | 每个矩形的横、纵边界 |

共同 big-M 为 8398。对任意 `i<j`，两个 bit 的解释为：

```text
(0,0): i 在 j 左侧       (1,0): j 在 i 左侧
(0,1): i 在 j 下方       (1,1): j 在 i 下方
```

33 个矩形总面积为 `1,149,192`。新边长 1082 的正方形面积为 `1,170,724`，空余
`21,532`。所有边长的最大公约数为 2。

## 偶数边长证明

固定全部二元变量后，剩余坐标和 `x1` 只出现在差分约束中。其矩阵是节点—弧关联矩阵，
因而全酉。矩形尺寸与 `M=8398` 都是偶数，所以所有右端项都是偶数。把坐标和 `x1`
除以 2 后，得到整数右端项的全酉系统；对每个固定二元模式，最小化 `x1` 总有整数极点。
映回原尺度后，坐标和边长均为偶数。

因此全局最优值可选为偶数。面积给出 `ceil(sqrt(1149192))=1073`，结合偶性得到
下界 1074。1082 已经可行，所以下一个可能的严格改进必须直接达到 1080。

## 精确验解

严格解（官网 solution ID 4）：

```text
objective_side              1084.0000000000007
max_x_extent                1084.00000000000068
max_y_extent                1084.00000000000068
row violations              0
bound violations            0
integrality residual        0
```

本轮新解：

```text
objective_side              1082
max_x_extent                1082
max_y_extent                1082
unused area                 21532
row violations              0
bound violations            0
integrality residual        0
```

Gurobi 13.0.1 与 COPT 8.0.4 又分别把这份新 `.sol` 读回原 MPS；在可行性与整数容差
均设为 `1e-9` 时，两者都接受目标 1082 的 MIP start，COPT 报告 bounds、rows、
integrality violations 全为 0。

当前数值解（官网 solution ID 5）：

```text
objective_side              1083.984782
rows violated > 1e-6       19
maximum row violation       0.007962 at c135
bound violations            0
integrality residual        0
```

## 1082 目标的等价加强

### 1. 收紧 big-M

在 `x1<=1082` 下，每个矩形的“坐标+宽/高”不超过 1082，另一矩形坐标非负。因此
关闭一条分离约束只需要 `M=1082`，原来的 8398 可安全替换。该模型仍保留每对两个
bit 的编码，矩阵系数范围从约 `8.4e3` 降到 `1.1e3`，但根松弛目标仍很弱。

### 2. 原生 indicator

对每对矩形新建 left/right/below/above 四个变量并令其和为 1；每个变量通过原生
indicator 激活相应的几何分离。该模型完全删除 big-M。Gurobi 根节点在多轮切割后经常
只剩十几个未定整数，比收紧 big-M 模型的一百多个明显更强，但全局树仍快速膨胀。

### 3. 全局二维 no-overlap

所有尺寸除以 2，将目标变成 541×541。OR-Tools CP-SAT 直接使用可选方向 interval、
`NoOverlap2D`、两个 cumulative sweep，以及 energetic/timetabling propagation。

### 4. sequence pair

原四种 pair code 正好对应 sequence pair 的四种相对次序，但 MPS 没有显式强制两条
序列的传递性。新模型用两个 0--32 的全排列 rank 向量编码全部关系，再保留冗余的
`NoOverlap2D` 与 cumulative 传播。官网 1084 布局已成功转换为合法 sequence pair，
并作为 1082 搜索的 repair hint。CP-SAT 在 `460.253` 秒找到 1082 布局，共报告
314,800 个 conflicts 和 1,755,079 个 branches。随后按实际几何关系恢复原 pair code，
独立十进制检查全部通过。

## 实验结果

| 方法 | 线程 | 时限 | 结果 |
|---|---:|---:|---|
| Gurobi 13.0.1，原 MPS + 严格起点 | 32 | 约 250 秒后切换 | incumbent 1084；下界 614 |
| COPT 8.0.4，原 MPS + 严格起点 | 32 | 约 250 秒后切换 | incumbent 1084；下界 560 |
| Gurobi，收紧-M 的 1082 target | 32 | 约 186 秒后切换 | 未找到可行点；未闭树 |
| COPT，收紧-M 的 1082 target | 32 | 约 189 秒后切换 | 未找到可行点；未闭树 |
| Gurobi，indicator 1082 target | 32 | 900 秒 | 未找到可行点；达到时限 |
| COPT，indicator 1082 target | 32 | 900 秒 | 未找到可行点；达到时限 |
| Gurobi，indicator + 官网二元起点 | 32 | 300 秒 | 未找到可行点；达到时限 |
| CP-SAT，普通 no-overlap，边长 1084 | 16 | 120 秒 | UNKNOWN；官网解另行严格通过 |
| CP-SAT，sequence pair + 1084 hint，边长 1082 | 64 | 900 秒 | **460.253 秒找到严格可行布局 1082** |
| Gurobi，indicator 1080 + 1082 二元起点 | 64 | 900 秒 | 未找到可行点；3,395,068 节点；达到时限 |
| CP-SAT，sequence pair + 1082 hint，边长 1080 | 96 | 900 秒 | `UNKNOWN`；677,817 conflicts、3,849,381 branches |

以上 COPT 与 CP-SAT 均在 `altman` 上使用 CPU；**没有使用 GPU0**。

固定边长 CP-SAT 的 `OPTIMAL` 表示满足性模型已经找到解，不表示原最小化问题已最优。
Gurobi/COPT 的“未找到可行点”也只描述各自运行，不能覆盖 CP-SAT 随后找到的 1082。
1080 的 Gurobi 与 CP-SAT 又都达到时限，没有找到布局也没有证明不可行。全局结论是
严格上界 1082、严格下界 1074，即 **1074 ≤ optimum ≤ 1082**，最优值仍开放。

## 简单界为何不够

枚举了 floor 与 threshold 两族双可行函数的 657,721 个横纵组合，并对旋转取最有利
方向。最强变换面积比例仍为

```text
287298 / 292681 = 0.981607962
```

即退化为原面积界，没有超过容器容量。困难来自矩形相对位置的组合几何，而不是一个
遗漏的简单一维/面积不等式。

## 2026-09-07：针对 1080 的关键几何实验

从严格 1082 布局恢复出的两条 541 最长路为：

```text
横向：15--21--2--12--6--20--28--16
纵向：4--12--30--7--3
```

此外存在三条用满横向宽度 541 的切片和五条用满纵向高度 541 的切片。因此，把边长
从 541 压到 540 必须同时破坏多条关键链或改变若干矩形朝向，不可能只靠平移现有布局。

本轮先进行了不依赖 MIP/CP 求解器的搜索与筛选：

- 完整枚举两条 sequence-pair 排列中的所有单次插入以及所有单矩形旋转，共 2,143 个
  邻居；最优仍为 541×541，其中 133 个只是等值移动。
- 在 541 平台上广度搜索 50,000 个不同状态，评估 4,329,398 个候选，最深到 3，仍未
  找到 540。
- 修复重启越过屏障的问题后，seed 97 的组合 ILS 在 600 秒内完成 11,202,782 次迭代，
  最优仍为 541×541。
- 对 identity、floor、threshold 和 Fekete--Schepers stair 共 1,350 个双可行函数做全部
  1,822,500 个横纵组合，并保留旋转变量的符号贡献；所有不等式在选择朝向之前就已
  冗余，没有产生超过面积界的新限制。

随后建立了逐层放开的精确受限子问题：

| 子问题 | 结果 |
|---|---|
| 只允许 12 个关键矩形彼此改变相对关系 | presolve 判定 `INFEASIBLE`，0.014527 秒 |
| 允许这 12 个矩形旋转并穿过其余矩形，外部骨架固定 | `INFEASIBLE`，156.092 秒、165,034 conflicts |
| 再加入 5 个满载切片矩形，共放开 17 个 | 900.157 秒后 `UNKNOWN`，1,204,936 conflicts |
| 固定 1082 的全部朝向，但全局重排所有坐标 | 900.040 秒后 `UNKNOWN`，1,896,203 conflicts |
| 所有朝向与坐标均自由的原生二维模型 | 900.110 秒后 `UNKNOWN`，1,180,797 conflicts |
| Gurobi indicator，固定朝向、全局重排 | 900 秒、4,658,131 节点后达到时限，未找到解 |

前两个 `INFEASIBLE` 只严格关闭所描述的 sequence-pair 邻域；17 模块以及两个全局
二维模型都没有闭合。单步枚举、平台搜索、ILS 和双可行函数失败也不能推出 1080
全局不可行。因此本轮没有更改严格结论，仍为 **1074 ≤ optimum ≤ 1082**。全部日志、
机器可读分析和复现命令见
[`../experiments/critical-geometry-20260907/`](../experiments/critical-geometry-20260907/)。

## 下一步建议

1. 以新 1082 sequence pair 为 repair hint，逐档测试 1080、1078 等偶数目标；
2. 对 sequence-pair 的第一条排列做前缀分裂，生成互斥且完备的子任务，再分别长跑；
3. 从 1082 sequence pair 出发，对两条排列做 Kendall 距离局部分支，先证明一个大的
   邻域内 1080 不可行；
4. 在 indicator 模型中加入两条排列的 rank/transitivity 约束，将 Gurobi 的强 LP/切割
   与 sequence-pair 的组合结构合并；
5. 若要追求完整证明，应采用可恢复的多日任务，而不是把 15 分钟“无解”误写成
   infeasible。

## 资料

- [MIPLIB `liu` instance details](https://miplib.zib.de/instance_details_liu.html)
- [Murata et al. (1996), sequence-pair floorplanning](https://doi.org/10.1109/43.552084)
- [OR-Tools NoOverlap2D / CP-SAT parameters](https://or-tools.github.io/docs/javadoc/com/google/ortools/sat/SatParameters.html)
- [PackingSolver rectangle algorithms](https://fontanf.github.io/packingsolver/internals/rectangle.html)
