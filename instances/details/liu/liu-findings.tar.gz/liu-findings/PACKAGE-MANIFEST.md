# Package manifest: liu

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 75
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/bottleneck-analysis-1082.json`
- `artifacts/cpsat-sequence-pair-1082.svg`
- `artifacts/dual-feasible-bound-summary.txt`
- `artifacts/exact-check-1082.txt`
- `artifacts/liu_original.lp`
- `artifacts/liu_target1080_indicator.lp`
- `artifacts/liu_target1080_indicator_fixed1082rot.lp`
- `artifacts/liu_target1082_indicator.lp`
- `artifacts/liu_target1082_tightM.lp`
- `artifacts/liu_target1083_tightM.lp`
- `artifacts/one-move-neighborhood-1082.json`
- `artifacts/orientation-dff-target1080.json`
- `artifacts/packingsolver-target1082/bins.csv`
- `artifacts/packingsolver-target1082/items.csv`
- `artifacts/packingsolver-target1082/parameters.csv`
- `artifacts/structure-summary.txt`
- `experiments/critical-geometry-20260907/README.md`
- `experiments/critical-geometry-20260907/critical12-cross-lns.log`
- `experiments/critical-geometry-20260907/critical12-internal-lns.log`
- `experiments/critical-geometry-20260907/critical17-cross-lns.log`
- `experiments/critical-geometry-20260907/gurobi-fixed-rotation.log`
- `experiments/critical-geometry-20260907/ils-seed97-best.json`
- `experiments/critical-geometry-20260907/no-overlap-all-rotations.log`
- `experiments/critical-geometry-20260907/no-overlap-fixed-rotation.log`
- `experiments/critical-geometry-20260907/plateau-search.log`
- `logs/copt_bound_15m.log`
- `logs/copt_bound_15m.stdout`
- `logs/copt_target1082_indicator_15m.log`
- `logs/copt_target1082_indicator_15m.stdout`
- `logs/copt_target1082_tightM_15m.log`
- `logs/copt_target1082_tightM_15m.stdout`
- `logs/cpsat_sequence_pair_hint_target1080_15m.stdout`
- `logs/cpsat_sequence_pair_hint_target1082_15m.stdout`
- `logs/cpsat_target1084_2m.stdout`
- `logs/extract_cpsat1082_sequence.stdout`
- `logs/extract_official_sequence.stdout`
- `logs/gurobi_bound_15m.log`
- `logs/gurobi_bound_15m.stdout`
- `logs/gurobi_target1080_indicator_start_15m.log`
- `logs/gurobi_target1080_indicator_start_15m.stdout`
- `logs/gurobi_target1082_indicator_15m.log`
- `logs/gurobi_target1082_indicator_15m.stdout`
- `logs/gurobi_target1082_indicator_start_5m.log`
- `logs/gurobi_target1082_indicator_start_5m.stdout`
- `logs/gurobi_target1082_tightM_15m.log`
- `logs/gurobi_target1082_tightM_15m.stdout`
- `reports/liu-study.md`
- `scripts/analyze_1082_bottlenecks.py`
- `scripts/analyze_sequence_neighborhood.py`
- `scripts/analyze_structure.py`
- `scripts/compact_fixed_relations.py`
- `scripts/dual_feasible_bounds.py`
- `scripts/make_indicator_lp.py`
- `scripts/make_indicator_start.py`
- `scripts/make_packingsolver_input.py`
- `scripts/make_target_lp.py`
- `scripts/orientation_dff_filter.py`
- `scripts/placement_to_mps_solution.py`
- `scripts/plot_solution_svg.py`
- `scripts/search_sequence_pair_ils.py`
- `scripts/search_sequence_pair_plateau.py`
- `scripts/sequence_hint_to_mps_solution.py`
- `scripts/solve_no_overlap_cp_sat.py`
- `scripts/solve_sequence_pair_cp_sat.py`
- `solutions/cpsat-sequence-pair-1082.sol`
- `solutions/cpsat-sequence-pair-1082.sol.gz`
- `solutions/cpsat1082-indicator-binaries.mst`
- `solutions/cpsat1082_sequence_hint.json`
- `solutions/official-current-numerical.sol`
- `solutions/official-current-numerical.sol.gz`
- `solutions/official-strict-1084.sol`
- `solutions/official-strict-1084.sol.gz`
- `solutions/official1084-indicator-binaries.mst`
- `solutions/official1084_sequence_hint.json`

## Excluded files

- `input/liu.mps.gz (54453 bytes; raw benchmark input; sha256 50599cbd1c0ea27d88e97fb3a53f1aae3d240a095c8c7baaa1f1408290c8f85f)`
