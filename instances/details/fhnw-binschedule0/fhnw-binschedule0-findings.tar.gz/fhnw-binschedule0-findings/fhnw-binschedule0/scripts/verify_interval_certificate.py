#!/usr/bin/env python3
"""Standard-library checker for the compact interval-order certificate."""

from __future__ import annotations

import argparse
import json
from fractions import Fraction
from pathlib import Path


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("certificate", type=Path)
    args = ap.parse_args()
    data = json.loads(args.certificate.read_text(encoding="utf-8"))
    groups = data["groups"]
    n = len(groups)
    assert [g["id"] for g in groups] == list(range(n))
    intervals = [(Fraction(g["U"]), Fraction(g["L"])) for g in groups]
    assert all(u <= l for u, l in intervals)
    members = [item for g in groups for item in g["members"]]
    assert len(members) == data["forced_items"] == 507
    assert len(set(members)) == len(members)
    assert all(len(g["members"]) == 1 or g["U"] == g["L"] for g in groups)

    arcs = {
        (a, b)
        for a, (_ua, la) in enumerate(intervals)
        for b, (ub, _lb) in enumerate(intervals)
        if a != b and la <= ub
    }
    assert not any((b, a) in arcs for a, b in arcs)

    matching = [tuple(edge) for edge in data["matching"]]
    assert len(matching) == data["matching_size"]
    assert len({a for a, _ in matching}) == len(matching)
    assert len({b for _, b in matching}) == len(matching)
    assert all(edge in arcs for edge in matching)

    cover_left = set(data["minimum_vertex_cover"]["left"])
    cover_right = set(data["minimum_vertex_cover"]["right"])
    assert data["cover_size"] == len(cover_left) + len(cover_right)
    assert data["cover_size"] == data["matching_size"]
    uncovered = [(a, b) for a, b in arcs if a not in cover_left and b not in cover_right]
    assert not uncovered
    assert data["uncovered_compatibility_arcs"] == 0

    paths = n - len(matching)
    bad = paths - data["occupied_segment_cap"]
    endpoint_sum = Fraction(data["fixed_base_cost"]) + Fraction(data["difference_cost"]) * bad
    assert paths == data["minimum_good_paths"] == 66
    assert bad == data["bad_transition_lower_bound"] == 63
    assert endpoint_sum == Fraction(data["endpoint_sum_lower_bound"]) == 31914
    half_ceiling = (endpoint_sum.numerator + 2 * endpoint_sum.denominator - 1) // (2 * endpoint_sum.denominator)
    even_bound = half_ceiling if half_ceiling % 2 == 0 else half_ceiling + 1
    assert even_bound == 15958
    print("certificate_valid=1")
    print(f"groups={n} compatibility_arcs={len(arcs)} matching={len(matching)}")
    print(f"endpoint_sum_lower_bound={endpoint_sum} even_max_load_lower_bound={even_bound}")


if __name__ == "__main__":
    main()
