# `fhnw-binschedule0`

## Result

**Optimal objective: 15,958.** This improves the public MIPLIB incumbent
16,088 by 130 and closes the instance.

The full 319,319-variable model is not solved by a long parameter sweep. The
endpoint portion is projected to a 507-item interval-order problem. A compact
matching/path-cover certificate proves that the two endpoint loads sum to at
least 31,914; both loads are even, so their maximum is at least 15,958. A
constructed solution has the six load values

```text
15956, 2631, 2987/2, 1533, 1187, 15958
```

and satisfies all 58,085 original rows, bounds, and integrality conditions.
Fixing every original variable to the saved solution makes Gurobi report
`OPTIMAL` with objective 15,958.

## Main evidence

- [`certificates/interval-order-certificate.json`](certificates/interval-order-certificate.json):
  128 contracted interval groups, a matching of size 62, and an independently
  checkable minimum vertex cover of size 62.
- [`solutions/optimal-15958.sol`](solutions/optimal-15958.sol): the lifted
  sparse solution for the original MPS.
- [`scripts/derive_interval_core.py`](scripts/derive_interval_core.py): exact
  structural extraction, lower-bound construction, reduced feasibility search,
  lifting, and full-row validation.
- [`scripts/verify_interval_certificate.py`](scripts/verify_interval_certificate.py):
  standard-library verification of every compatibility arc, matching edge,
  vertex-cover edge, and lower-bound arithmetic in the compact certificate.
- [`scripts/verify_fixed_solution.py`](scripts/verify_fixed_solution.py):
  independent fixed-variable check in the original model.

See the [full structural report](reports/structural-investigation.md) for the
proof and the boundary between combinatorial reasoning and solver use.

## Provenance

- Compressed MPS SHA-256:
  `5604233f73f5ff3b6d09e4e72f5763edef7c2c09eebf3610a674198b9709e0f2`
- Previous public solution SHA-256:
  `ac459322370ad10aa1b7c00789a2b0737a81ba0e36060db7417b2dc2e506a77c`
- New solution SHA-256:
  `d3925c25e937e777fbd1d3de1e3ad7e389a2a15fd58593e44e8dcea99097494a`
- Certificate SHA-256:
  `7b4b8bebd35dcf3dd5ad802ff3539a226fe56b2881977b66b425b874b4f14cc2`
- [Official MIPLIB page](https://miplib.zib.de/instance_details_fhnw-binschedule0.html)

## Reproduction

From the repository root, with `gurobipy` available:

```powershell
python instances/fhnw-binschedule0/scripts/derive_interval_core.py `
  instances/fhnw-binschedule0/input/fhnw-binschedule0.mps.gz `
  instances/fhnw-binschedule0/solutions/public-16088.sol.gz `
  --certificate instances/fhnw-binschedule0/certificates/interval-order-certificate.json `
  --solution-out instances/fhnw-binschedule0/solutions/optimal-15958.sol `
  --decision-target 15958
```

The optional reduced feasibility oracle contains 2,033 rows and 217,695
binaries, and closed at its root in 6.95 seconds in this run. It constructs the
upper-bound witness; the global lower bound comes from the interval-order
certificate, not from this oracle's branch-and-bound bound.
