import argparse, gzip, json, os, random, time
from array import array


def open_model(path):
    return gzip.open(path, 'rt', encoding='ascii', errors='replace') if path.endswith('.gz') else open(path, 'r', encoding='ascii', errors='replace')


def read_incumbent(path):
    chosen = set()
    if not path or not os.path.exists(path):
        return chosen
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        for line in f:
            s = line.strip()
            if not s or s.startswith('#'):
                continue
            p = s.split()
            if len(p) >= 2:
                try:
                    if float(p[1]) > 0.5:
                        chosen.add(p[0])
                except ValueError:
                    pass
    return chosen


def parse_mps(path, incumbent_names):
    row_name_to_id = {}
    row_sense = []
    row_names = []
    rhs = []
    objrow = None
    var_names = []
    offsets = array('Q', [0])
    incid = array('I')
    obj = array('d')
    initial = bytearray()
    section = None
    current_var = None
    current_entries = []
    current_obj = 0.0

    def flush_var():
        nonlocal current_var, current_entries, current_obj
        if current_var is None:
            return
        var_names.append(current_var)
        for r in current_entries:
            incid.append(r)
        offsets.append(len(incid))
        obj.append(current_obj)
        initial.append(1 if current_var in incumbent_names else 0)
        current_var = None
        current_entries = []
        current_obj = 0.0

    with open_model(path) as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith('*'):
                continue
            tok = line.split()
            head = tok[0].upper()
            if head in ('NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA','OBJSENSE','OBJNAME'):
                if section == 'COLUMNS' and head != 'COLUMNS':
                    flush_var()
                section = head
                if head == 'ENDATA':
                    break
                continue
            if section == 'ROWS':
                if len(tok) >= 2:
                    sense, name = tok[0].upper(), tok[1]
                    if sense == 'N' and objrow is None:
                        objrow = name
                    elif sense in ('L','G','E'):
                        row_name_to_id[name] = len(row_sense)
                        row_sense.append(sense)
                        row_names.append(name)
                        rhs.append(0.0)
            elif section == 'COLUMNS':
                if 'MARKER' in line.upper():
                    continue
                if len(tok) < 3:
                    continue
                v = tok[0]
                if current_var != v:
                    flush_var()
                    current_var = v
                pairs = tok[1:]
                for k in range(0, len(pairs)-1, 2):
                    rn = pairs[k]
                    try:
                        val = float(pairs[k+1])
                    except ValueError:
                        continue
                    if rn == objrow:
                        current_obj += val
                    elif rn in row_name_to_id and abs(val) > 1e-12:
                        if abs(val - 1.0) > 1e-12:
                            raise RuntimeError('This dry method requires unit structural coefficients; found %s' % val)
                        current_entries.append(row_name_to_id[rn])
            elif section == 'RHS':
                pairs = tok[1:]
                for k in range(0, len(pairs)-1, 2):
                    rn = pairs[k]
                    if rn in row_name_to_id:
                        rhs[row_name_to_id[rn]] = float(pairs[k+1])
    flush_var()
    return row_sense, rhs, var_names, offsets, incid, obj, initial


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--incumbent', default='/resources/best.sol')
    ap.add_argument('--seed', type=int, default=17)
    ap.add_argument('--search-seconds', type=float, default=210.0)
    ap.add_argument('--pivot-limit', type=int, default=250)
    args = ap.parse_args()
    started = time.monotonic()
    rng = random.Random(args.seed)
    target = -73.0
    work = 0
    accepted = 0
    passes = 0
    termination = 'completed_dry_neighborhood'
    result = {
        'status':'error', 'algorithm_family':'slack-preserving exchange local search',
        'algorithm_role':'primal',
        'hypothesis':'The verified 72-variable packing is locally improvable by an equality-signature-compatible replacement that releases enough packing slack for at least one additional insertion.',
        'work_units':1, 'work_unit_name':'candidate feasibility evaluations',
        'termination_reason':'initialization_error', 'target_bound':target,
        'seed':args.seed, 'runtime_seconds':0.0,
        'acceptance_criterion':'Accept only a fully feasible state with strictly more selected variables than before the pivot.',
        'pivot_condition':'Replace one selected variable by a nonselected variable with the identical equality-row signature, then greedily insert equality-free variables exposed by the pivot.'
    }
    try:
        incumbent_names = read_incumbent(args.incumbent)
        senses, rhs, names, off, inc, obj, selected = parse_mps(args.model, incumbent_names)
        n, m = len(names), len(senses)
        eq_rows = [i for i,s in enumerate(senses) if s == 'E']
        eq_set = set(eq_rows)
        activity = [0] * m
        for j in range(n):
            if selected[j]:
                for q in range(off[j], off[j+1]):
                    activity[inc[q]] += 1

        def feasible_add(j):
            nonlocal work
            work += 1
            for q in range(off[j], off[j+1]):
                r = inc[q]
                nv = activity[r] + 1
                if senses[r] == 'L' and nv > rhs[r] + 1e-9:
                    return False
                if senses[r] == 'G':
                    continue
                if senses[r] == 'E' and nv > rhs[r] + 1e-9:
                    return False
            return True

        def add(j):
            selected[j] = 1
            for q in range(off[j], off[j+1]):
                activity[inc[q]] += 1

        def remove(j):
            selected[j] = 0
            for q in range(off[j], off[j+1]):
                activity[inc[q]] -= 1

        def eq_signature(j):
            return tuple(inc[q] for q in range(off[j], off[j+1]) if inc[q] in eq_set)

        initial_count = sum(selected)
        initial_feasible = True
        for r in range(m):
            if senses[r] == 'L' and activity[r] > rhs[r] + 1e-9:
                initial_feasible = False
            elif senses[r] == 'G' and activity[r] < rhs[r] - 1e-9:
                initial_feasible = False
            elif senses[r] == 'E' and abs(activity[r] - rhs[r]) > 1e-9:
                initial_feasible = False
        if not initial_feasible:
            raise RuntimeError('Supplied incumbent is not feasible under parsed rows')

        signatures = {}
        eq_free = []
        for j in range(n):
            sig = eq_signature(j)
            if sig:
                signatures.setdefault(sig, []).append(j)
            else:
                eq_free.append(j)

        order = list(eq_free)
        rng.shuffle(order)
        for j in order:
            if not selected[j] and feasible_add(j):
                add(j)
                accepted += 1

        deadline = started + args.search_seconds
        while time.monotonic() < deadline and passes < args.pivot_limit:
            passes += 1
            base_count = sum(selected)
            selected_ids = [j for j in range(n) if selected[j]]
            rng.shuffle(selected_ids)
            changed = False
            for old in selected_ids:
                if time.monotonic() >= deadline:
                    termination = 'internal_time_budget'
                    break
                sig = eq_signature(old)
                if not sig:
                    continue
                bucket = signatures.get(sig, [])
                if len(bucket) <= 1:
                    continue
                remove(old)
                candidates = bucket[:]
                rng.shuffle(candidates)
                candidates = candidates[:min(len(candidates), 256)]
                pivot = None
                for j in candidates:
                    if j != old and not selected[j] and feasible_add(j):
                        pivot = j
                        break
                if pivot is None:
                    add(old)
                    continue
                add(pivot)
                inserted = []
                scan = eq_free[:]
                rng.shuffle(scan)
                for j in scan:
                    if time.monotonic() >= deadline:
                        break
                    if not selected[j] and feasible_add(j):
                        add(j)
                        inserted.append(j)
                        if sum(selected) > base_count:
                            break
                if sum(selected) > base_count:
                    accepted += 1
                    changed = True
                    break
                for j in reversed(inserted):
                    remove(j)
                remove(pivot)
                add(old)
            if not changed:
                termination = 'one_exchange_neighborhood_exhausted'
                break

        final_count = sum(selected)
        valid = True
        for r in range(m):
            if senses[r] == 'L' and activity[r] > rhs[r] + 1e-9: valid = False
            if senses[r] == 'G' and activity[r] < rhs[r] - 1e-9: valid = False
            if senses[r] == 'E' and abs(activity[r] - rhs[r]) > 1e-9: valid = False
        if not valid:
            raise RuntimeError('Internal final feasibility check failed')
        objective = sum(obj[j] for j in range(n) if selected[j])
        with open('best.sol','w',encoding='utf-8') as f:
            f.write('# Objective value = %.17g\n' % objective)
            for j in range(n):
                if selected[j]:
                    f.write('%s 1\n' % names[j])
        result.update({
            'status':'success', 'work_units':max(1,work),
            'termination_reason':termination, 'runtime_seconds':time.monotonic()-started,
            'objective':objective, 'initial_selected_count':initial_count,
            'final_selected_count':final_count, 'accepted_moves':accepted,
            'passes':passes, 'variables':n, 'rows':m,
            'structural_nonzeros':len(inc), 'equality_rows':len(eq_rows),
            'equality_signature_classes':len(signatures),
            'equality_free_variables':len(eq_free), 'solution_artifact':'best.sol'
        })
    except Exception as e:
        result.update({'status':'error','termination_reason':'exception: '+repr(e),'runtime_seconds':time.monotonic()-started,'work_units':max(1,work)})
    with open('method_result.json','w',encoding='utf-8') as f:
        json.dump(result,f,indent=2,sort_keys=True)

if __name__ == '__main__':
    main()
