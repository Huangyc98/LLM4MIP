import argparse, gzip, hashlib, json, os, subprocess, time
from collections import defaultdict


def tool_exe(root, names):
    if not os.path.exists(root):
        return None
    for base, dirs, files in os.walk(root):
        for f in files:
            if f.lower() in names and os.access(os.path.join(base, f), os.X_OK):
                return os.path.join(base, f)
    return None


def parse_mps(path):
    op = gzip.open if path.endswith('.gz') else open
    section = None
    row_type = {}
    objrow = None
    cols = defaultdict(lambda: defaultdict(float))
    rhs = defaultdict(float)
    bounds = {}
    integer_mode = False
    with op(path, 'rt', errors='replace') as f:
        for raw in f:
            s = raw.strip()
            if not s or s.startswith('*'):
                continue
            p = s.split()
            key = p[0].upper()
            if key in ('NAME','OBJSENSE','OBJNAME'):
                section = key
                continue
            if key in ('ROWS','COLUMNS','RHS','RANGES','BOUNDS'):
                section = key
                continue
            if key == 'ENDATA':
                break
            if section == 'ROWS':
                if len(p) >= 2:
                    row_type[p[1]] = p[0].upper()
                    if p[0].upper() == 'N' and objrow is None:
                        objrow = p[1]
            elif section == 'COLUMNS':
                if 'MARKER' in s.upper():
                    if 'INTORG' in s.upper(): integer_mode = True
                    if 'INTEND' in s.upper(): integer_mode = False
                    continue
                if len(p) < 3: continue
                v = p[0]
                q = p[1:]
                for i in range(0, len(q)-1, 2):
                    try: cols[v][q[i]] += float(q[i+1])
                    except ValueError: pass
            elif section == 'RHS':
                q = p[1:]
                for i in range(0, len(q)-1, 2):
                    try: rhs[q[i]] += float(q[i+1])
                    except ValueError: pass
            elif section == 'BOUNDS' and len(p) >= 3:
                typ, v = p[0].upper(), p[2]
                val = float(p[3]) if len(p) > 3 else None
                lo, hi, binary = bounds.get(v, (0.0, None, False))
                if typ == 'BV': lo, hi, binary = 0.0, 1.0, True
                elif typ == 'FX': lo, hi = val, val
                elif typ == 'LO': lo = val
                elif typ == 'UP': hi = val
                elif typ == 'UI': hi = val
                elif typ == 'LI': lo = val
                bounds[v] = (lo, hi, binary)
    return objrow, row_type, cols, rhs, bounds


def add_atmost(lits, k, add, newvar):
    n = len(lits)
    if k < 0:
        add([]); return
    if k == 0:
        for x in lits: add([-x])
        return
    if k >= n: return
    # Sinz sequential counter.
    s = [[newvar() for j in range(k)] for i in range(n-1)]
    add([-lits[0], s[0][0]])
    for j in range(1, k): add([-s[0][j]])
    for i in range(1, n-1):
        add([-lits[i], s[i][0]])
        add([-s[i-1][0], s[i][0]])
        for j in range(1, k):
            add([-lits[i], -s[i-1][j-1], s[i][j]])
            add([-s[i-1][j], s[i][j]])
        add([-lits[i], -s[i-1][k-1]])
    add([-lits[-1], -s[n-2][k-1]])


def add_atleast_k(lits, k, add, newvar):
    # Exact truncated dynamic counter y(i,j) <=> at least j of first i literals.
    n = len(lits)
    if k <= 0: return
    if k > n: add([]); return
    prev = []
    for i, x in enumerate(lits, 1):
        cur = []
        upto = min(i, k)
        for j in range(1, upto+1):
            y = newvar(); cur.append(y)
            if j == 1:
                if i == 1:
                    add([-y, x]); add([-x, y])
                else:
                    a = prev[0]
                    add([-a, y]); add([-x, y]); add([-y, a, x])
            elif j == i:
                a = prev[j-2]
                add([-y, a]); add([-y, x]); add([-a, -x, y])
            else:
                a, b = prev[j-1], prev[j-2]
                # y <=> a OR (b AND x)
                add([-a, y]); add([-b, -x, y]); add([-y, a, b]); add([-y, a, x])
        prev = cur
    add([prev[k-1]])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--target', type=int, default=-73)
    ap.add_argument('--seed', type=int, default=1)
    ap.add_argument('--internal-seconds', type=int, default=540)
    a = ap.parse_args()
    t0 = time.time()
    result = {'status':'completed','algorithm_family':'exact pseudo-Boolean cardinality encoding with CDCL and checked DRAT','algorithm_role':'proof','hypothesis':'The instance is a unit-coefficient binary packing model and infeasibility of objective at most -73 can be certified by CDCL.','target_bound':a.target,'seed':a.seed,'requested_runtime_seconds':a.internal_seconds,'acceptance_criterion':'Accept a proof only when CaDiCaL returns UNSAT and drat-trim verifies the emitted proof; accept a primal only after external exact solution checking.','pivot_condition':'Scale if encoding is exact and CDCL performs work; abandon this representation if any row, bound, or objective coefficient violates the checked packing assumptions.','work_units':1,'termination_reason':'initialization'}
    try:
        objrow, rtype, cols, rhs, bounds = parse_mps(a.model)
        names = list(cols.keys())
        vid = {v:i+1 for i,v in enumerate(names)}
        reasons = []
        selected = []
        for v in names:
            lo, hi, bv = bounds.get(v, (0.0, None, False))
            if not (bv or (lo >= -1e-9 and hi is not None and hi <= 1+1e-9)):
                reasons.append('nonbinary variable '+v)
                if len(reasons) >= 8: break
            c = cols[v].get(objrow, 0.0)
            if abs(c + 1.0) <= 1e-9: selected.append(vid[v])
            elif abs(c) > 1e-9:
                reasons.append('objective coefficient is not 0 or -1 for '+v)
                if len(reasons) >= 8: break
        rows = defaultdict(list)
        for v in names:
            for r, val in cols[v].items():
                if r != objrow and abs(val) > 1e-12: rows[r].append((vid[v], val))
        normalized = []
        for r, terms in rows.items():
            typ = rtype.get(r)
            b = rhs.get(r, 0.0)
            if typ == 'G':
                terms = [(x,-c) for x,c in terms]; b = -b; typ = 'L'
            if typ != 'L':
                reasons.append('unsupported non-inequality row '+r); continue
            if any(abs(c-1.0)>1e-9 for x,c in terms) or abs(b-round(b))>1e-9:
                reasons.append('non-unit or nonintegral packing row '+r); continue
            normalized.append(([x for x,c in terms], int(round(b)), r))
        if reasons:
            result.update({'status':'unsupported','work_units':max(1,len(rows)+len(names)),'termination_reason':'representation_check_failed','diagnosis':'representation: exact packing assumptions failed','unsupported_examples':reasons[:20],'runtime_seconds':time.time()-t0})
            with open('method_result.json','w') as f: json.dump(result,f,indent=2)
            with open('encoding_stats.txt','w') as f: f.write('\n'.join(reasons))
            return
        clauses=[]
        next_id=[len(names)+1]
        def nv():
            z=next_id[0]; next_id[0]+=1; return z
        def add(c): clauses.append(tuple(c))
        fixed=0
        for v in names:
            lo,hi,bv=bounds.get(v,(0.0,None,False))
            if hi is not None and hi <= 1e-9: add([-vid[v]]); fixed+=1
            if lo >= 1-1e-9: add([vid[v]]); fixed+=1
        for lits,k,r in normalized: add_atmost(lits,k,add,nv)
        K = -a.target
        add_atleast_k(selected,K,add,nv)
        with open('model.cnf','w') as f:
            f.write('p cnf %d %d\n' % (next_id[0]-1,len(clauses)))
            for c in clauses: f.write(' '.join(map(str,c))+' 0\n')
        stats={'original_variables':len(names),'selected_variables':len(selected),'packing_rows':len(normalized),'fixed_variables':fixed,'cnf_variables':next_id[0]-1,'cnf_clauses':len(clauses),'target_selected':K}
        with open('encoding_stats.txt','w') as f: json.dump(stats,f,indent=2)
        result['work_units']=max(1,len(clauses))
        cad=tool_exe('/tools/cadical',{'cadical','cadical.exe'})
        drat=tool_exe('/tools/drat-trim',{'drat-trim','drat-trim.exe'})
        if not cad: raise RuntimeError('CaDiCaL executable not found')
        cmd=[cad,'--seed='+str(a.seed),'model.cnf','proof.drat']
        try:
            cp=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=max(1,a.internal_seconds))
            out=cp.stdout
            rc=cp.returncode
        except subprocess.TimeoutExpired as e:
            out=(e.stdout or '') if isinstance(e.stdout,str) else ''
            rc=124
        with open('cadical.log','w') as f: f.write(out[-200000:])
        if rc==20 or 's UNSATISFIABLE' in out:
            verified=False; verify_out='drat-trim unavailable'
            if drat and os.path.exists('proof.drat'):
                vp=subprocess.run([drat,'model.cnf','proof.drat'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=max(30,min(300,a.internal_seconds)))
                verify_out=vp.stdout
                verified=(vp.returncode==0 and ('VERIFIED' in verify_out.upper() or 's VERIFIED' in verify_out))
            with open('proof_report.txt','w') as f:
                f.write('CNF SHA256: '+hashlib.sha256(open('model.cnf','rb').read()).hexdigest()+'\n')
                if os.path.exists('proof.drat'): f.write('Proof SHA256: '+hashlib.sha256(open('proof.drat','rb').read()).hexdigest()+'\n')
                f.write(verify_out)
            result.update({'status':'proof_verified' if verified else 'unverified_unsat','termination_reason':'checked_unsat' if verified else 'unsat_without_independent_acceptance','certificate_verified':verified,'valid_dual_bound':a.target if verified else None})
        elif rc==10 or 's SATISFIABLE' in out:
            assign={}
            for line in out.splitlines():
                if line.startswith('v '):
                    for q in line.split()[1:]:
                        try:
                            z=int(q)
                            if z: assign[abs(z)]=z>0
                        except: pass
            with open('best.sol','w') as f:
                f.write('# objective value %d\n' % a.target)
                for v in names: f.write('%s %d\n' % (v,1 if assign.get(vid[v],False) else 0))
            result.update({'status':'candidate_found','termination_reason':'sat_assignment_found','candidate_objective_upper_bound':a.target})
        else:
            result.update({'status':'completed','termination_reason':'cdcl_time_limit' if rc==124 else 'solver_exit_'+str(rc)})
        result.update({'runtime_seconds':time.time()-t0,'encoding_statistics':stats})
    except Exception as e:
        result.update({'status':'error','termination_reason':'implementation_or_tool_error','diagnosis':'parsing/tool invocation','error':repr(e),'runtime_seconds':time.time()-t0})
    with open('method_result.json','w') as f: json.dump(result,f,indent=2)

if __name__=='__main__': main()
