# `a2864-99blp`: exact geometry crosswalk and theorem-transfer closure

Date: 2026-09-05

## Conclusion

The MIP optimum is **-257**, conditional only on accepting the published
theorem

\[
A_2(8,6;4)=257.
\]

The previously missing step—an exact map from the MPS matrix to the finite
geometry in that theorem—is now locally verified for every row and every
column.  A dependency-free Python verifier reconstructs `PG(7,2)` from the
matrix incidence relation, coordinatizes all 255 points, maps all 200,787 MPS
variables to distinct 4-dimensional subspaces of `GF(2)^8`, and checks every
line incidence.  It also independently evaluates the official 257-column
solution in all 22,117 MPS rows.

This is an **exact theorem-transfer closure**, not a locally replayed proof of
the external coding-theory theorem.  The distinction matters because that
theorem itself is computational.

## Inputs and identity

- Official compressed MPS SHA-256:
  `fc6534e01c67dcab16d9fd83eaa93c8431ad9783f9039280d2f1a9fb07ee4e4a`
- Decompressed MPS SHA-256:
  `ed2a3c92444592c58c3ae9c5ca40b154d8f7d7d062a63994fb5c798d8ad40a38`
- Official solution SHA-256:
  `e55fed5c29c2c87229c180aaed36912557d3477a995395d5837f4257f818c58f`
- Matrix dimensions: 22,117 rows, 200,787 binary columns, and 20,078,717
  matrix nonzeros.
- Every matrix coefficient is `1`; every objective coefficient is `-1`.

The objective is therefore exactly

\[
\min -\sum_{i=1}^{200787}x_i.
\]

## Exact row reconstruction

The row order and the streamed column supports give the following partition.

| MPS rows | Count | Recovered role | Sense and RHS | Row degree |
|---|---:|---|---|---:|
| `R0`--`R254` | 255 | points | `<= 17` | 11,811 |
| `R255`--`R11049` | 10,795 | lines | `<= 1` | 651 |
| `R11050`--`R21844` | 10,795 | 6-spaces | `<= 1` | 651 |
| `R21845`--`R22099` | 255 | hyperplanes | `<= 17` | 11,811 |
| `R22100`--`R22116` | 17 | prescribed variables | `= 1` | 1 |

Each column has exactly 15 point incidences, 35 line incidences, 35 six-space
incidences, 15 hyperplane incidences, and zero or one prescribed-variable
incidence.

For each alleged line row, the verifier intersects the 15-point supports of
all 651 incident columns.  Every one of the 10,795 intersections contains
exactly three points.  The resulting triples cover each of the

\[
\binom{255}{2}=32,385
\]

unordered pairs of points exactly once.  Thus the line block recovers a
Steiner triple system directly from the MPS; it is not inferred from matching
row counts alone.

## Two independent coordinatizations

Starting only from those recovered triples, the verifier greedily chooses the
following point representatives of a vector-space basis:

`R0,R1,R2,R4,R8,R16,R32,R64`.

Assigning successive unit vectors and using the third-point rule
`v(c)=v(a) xor v(b)` expands the represented span through sizes

`1,3,7,15,31,63,127,255`.

The labels are a bijection onto all nonzero vectors of `GF(2)^8`, and every
recovered line triple XORs to zero.

Independently, the MPS point order has the explicit one-row RREF enumeration.
For pivot position `k=0,...,7`, whose block has size `2^(7-k)`, a row with
within-block offset `j` has vector

\[
(1\ll k)\;\mathbin{|}\;(j\ll(k+1)).
\]

The verifier checks all 255 rows and all 10,795 lines in these explicit
coordinates.  It further verifies point by point that the incidence-derived
coordinates and the RREF coordinates are related by the invertible linear map
whose greedy-basis images are

`01,03,05,09,11,21,41,81` in hexadecimal.

## Exhaustive column crosswalk

For every `x1,...,x200787`, the verifier performs all of the following exact
checks.

1. Convert its 15 point-row incidences to nonzero 8-bit vectors.
2. Check that the 15 vectors are distinct, XOR-closed after adjoining zero,
   and have binary rank 4.
3. Check that its resulting 4-space has not occurred in any earlier column.
4. Derive the 35 projective lines contained in the 4-space from its 105 point
   pairs.
5. Check set equality between those 35 derived lines and the column's 35
   actual line-row incidences.

The rank histogram is exactly `{4: 200787}`.  All 200,787 spaces are distinct,
and

\[
{8\brack4}_2
=\prod_{i=0}^{3}\frac{2^{8-i}-1}{2^{4-i}-1}
=200,787.
\]

Consequently the variables enumerate every 4-dimensional subspace of
`GF(2)^8` exactly once.  Since the actual and derived 35-line sets agree for
every column, every line row's support is exactly the set of columns whose
4-spaces contain that line.

For reproducibility, the SHA-256 digest of the ordered mapping
`variable -> sorted 15 point-coordinate bytes` is

`80d4a2c8c72530509813efbcde8102b7351ebd029bf378efdb260454acd13617`.

The corresponding ordered RREF-basis digest is

`faf4dfe203d414bceb25237d3a91673c120b9b5455f9b2fb983b123e4cc9f520`.

## One-way reduction and optimum

Let `C` be the set of 4-spaces corresponding to the selected MPS columns.  If
two members of `C` intersected in dimension at least 2, their intersection
would contain a projective line.  Both columns would then occur in that
line's `<= 1` row, contradicting feasibility.  Hence, for distinct `U,W` in
`C`,

\[
\dim(U\cap W)\leq1,
\qquad
d_s(U,W)=4+4-2\dim(U\cap W)\geq6.
\]

Thus every feasible MPS solution maps into a binary `(8,N,6;4)`
constant-dimension code.  The extra point, six-space, hyperplane, and
prescription constraints can only restrict that family; no converse mapping
is needed for the upper bound.

Theorem 1 of Heinlein, Honold, Kiermaier, Kurz, and Wassermann states
`A_2(8,6;4)=257`.  It follows that every MPS solution has at most 257 selected
columns and objective at least `-257`.

The official solution contains exactly 257 selected columns.  The local
standard-library audit checks all 200,787 assignments and reports zero row
violations.  Its maximum activities in the point, line, six-space, and
hyperplane blocks are respectively `17,1,1,17`, and all 17 prescribed
equalities have activity one.  It therefore supplies the matching upper
bound `-257` for this minimization problem.

Combining both directions gives

\[
\boxed{\operatorname{OPT}(\texttt{a2864-99blp})=-257}.
\]

## Evidence boundary and computational-circularity caveat

The local audit is exhaustive and exact, uses integer/bit operations only,
and invokes no optimizer.  It closes the MPS-to-geometry crosswalk that was
previously missing.

The external bound is different.  The cited paper says that its classification
and upper bound were obtained using substructure classification plus binary
integer and linear programming; it reports 48,273 computation-hours across
the four proof phases.  Those computations and their underlying archives were
not replayed here.  Moreover, the MIPLIB model belongs to the same
subspace-selection/ILP research program.  Therefore this result must not be
described as an optimizer-independent local proof of the 257 bound, nor as a
new direct solve of the long-open benchmark.  Logically, the transfer is valid
when the peer-reviewed theorem is accepted as an external result; evidentially,
there is a computational-family circularity risk if one wanted to use this
benchmark as an independent validation of that theorem.  I did not establish
that this exact prescribed-variable MPS was itself one of the paper's proof
subproblems.

Primary source:

- https://arxiv.org/abs/1711.06624
- https://doi.org/10.1007/s10623-018-0544-8

## Reproduction artifacts

- `instances/a2864-99blp/scripts/verify_geometry.py` — exact verifier; SHA-256
  `e7d1866bb86f65d832cfb64eb56d37cdacb7009f76e5207b9a3e33e3c2b88025`
- `instances/a2864-99blp/artifacts/exact-geometry-audit.json` —
  machine-readable audit
- `instances/a2864-99blp/artifacts/point-coordinates.tsv` — all 255
  point labels in both coordinate systems
- `instances/a2864-99blp/artifacts/line-coordinates.tsv` — all 10,795
  recovered line triples
- `instances/a2864-99blp/logs/exact-geometry-audit.log` — successful
  68.005-second transcript
- `instances/a2864-99blp/solutions/official-257.sol.gz` — official witness

Reproduction command, run from the workspace root:

```sh
python3 instances/a2864-99blp/scripts/verify_geometry.py \
  instances/a2864-99blp/input/a2864-99blp.mps.gz \
  instances/a2864-99blp/solutions/official-257.sol.gz \
  --output-directory instances/a2864-99blp/artifacts
```

The successful run ends with:

```text
MPS parsed: rows=22117, columns=200787, matrix_nonzeros=20078717
lines reconstructed: triples=10795, point_pairs=32385
vector-space basis representatives: R0,R1,R2,R4,R8,R16,R32,R64; span_sizes=[1, 3, 7, 15, 31, 63, 127, 255]; explicit RREF numbering agrees linearly
columns verified: distinct_4_spaces=200787, all 35-line incidence sets exact=yes
solution verified: objective=-257, row_violations=0
EXACT GEOMETRY AUDIT PASS in 68.005 seconds
```
