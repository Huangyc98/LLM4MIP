# `siena1` experiment archive

2026-09-14 independent dual-bound review: [adopted bound, proof chain, checks, and limitations](../../docs/dual-bound-audit-2026-09-14/cases/siena1.zh.md). Reviewed lower bound: **approximately 10219502.195349596**. This review distinguishes exact, literature, and numerical evidence; historical statements below remain dated records.

## Result

The final outcome is a **partial feasible result**, not a proof of optimality or infeasibility.

| Measure | Value |
|---|---:|
| Objective sense | minimize |
| Best tolerance-verified primal bound | **10,449,008.9** |
| Best dual bound | **10,219,502.195349596** |
| Relative gap | **0.021964447235794975** (about **2.19644%**) |
| Feasibility check | passed at tolerance `1e-9` |
| Optimality proved | no |
| Infeasibility proved | no |

The best result came from Gurobi run `gurobi-20260903-173713-7765ec0a`, which stopped at a time limit after approximately 7,200 seconds. A later 6,000-second Gurobi run reproduced the same incumbent but did not improve the best dual bound.

## Experiment overview

The short generic-solver baseline used Gurobi and COPT. It ended with node-limit or time-limit statuses and produced feasible, tolerance-verified incumbents, but no proof. The research phase also attempted two custom Python methods: one completed without a checked bound or solution, and one ended with an error. Extended Gurobi runs then reduced the gap to approximately 2.19644%.

All seven outcomes are retained in `experiments.md` and `experiments.json`. In particular:

- `NODE_LIMIT`, `TIMEOUT`, and `TIME_LIMIT` are not optimality or infeasibility statuses.
- All ledgered exact-solver incumbents passed the controller check at `1e-9`.
- Neither custom run produced a checked incumbent in the experiment ledger.
- There were no strict optimal or strict infeasible runs.

## Reproducibility notes

The run stacks were Gurobi, COPT, and custom Python. Custom execution was CPU-only in a network-isolated bubblewrap sandbox with controller-enforced time, memory, file-size, and thread limits. CaDiCaL and DRAT-trim were configured capabilities but are not documented as used in the reported runs.

The compressed reporting artifacts do not provide the machine/CPU identifier, solver or Python versions, exact sandbox-limit values, complete solver parameter dictionaries, custom source filenames, or random seeds. This archive leaves those fields explicitly unreported rather than guessing them. Known run limits and runtimes are documented in `final_report.md`; thread counts and log paths were controller-managed.

## Files

- [`final_report.md`](final_report.md): full outcome, run-by-run status review, methods, limitations, and recommendation
- [`experiments.md`](experiments.md): controller-generated experiment table
- `experiments.json`: controller-generated machine-readable experiment ledger
- `reporting_bundle.json`: compressed reporting metadata
- `result.json`: controller-managed final result

## Recommended continuation

If a future solving stage is authorized, reuse the verified incumbent as a warm start and prioritize strengthening the dual bound. First audit the failed custom method and preserve complete source, version, parameter, seed, machine, and sandbox metadata. Repeating the same long-run configuration is not the preferred next step because the last 6,000-second run yielded no improvement.
