# Experiment ledger

This file is generated from `runs/*/result.json` by the controller.

| Run | Solver | Status | Primal | Dual | Gap | Verified | Runtime (s) |
|---|---|---|---:|---:|---:|---|---:|
| `copt-20260903-172236-8ffcecce` | copt | TIMEOUT | 105509471.6663 | 10189660.3678347 | 0.903424211998123 | yes @ 1e-9 | 300.033911943436 |
| `custom-20260903-173117-4a153f49` | custom-python | completed | — | — | — | not checked | 1.32540535926819 |
| `custom-20260903-173325-a1ba44d1` | custom-python | ERROR | — | — | — | not checked | 0.0679681301116943 |
| `gurobi-20260903-172058-f35b1a44` | gurobi | NODE_LIMIT | 1791742081.586 | 10163179.2290023 | 0.994327766628104 | yes @ 1e-9 | 7.22377896308899 |
| `gurobi-20260903-172233-2888c593` | gurobi | TIME_LIMIT | 11554631.5072 | 10187876.428473 | 0.118286340665674 | yes @ 1e-9 | 300.199947834015 |
| `gurobi-20260903-173713-7765ec0a` | gurobi | TIME_LIMIT | 10449008.9 | 10219502.1953496 | 0.021964447235795 | yes @ 1e-9 | 7200.31746506691 |
| `gurobi-20260903-194001-e97cdb36` | gurobi | TIME_LIMIT | 10449008.9 | 10219336.6403565 | 0.0219802913215497 | yes @ 1e-9 | 6000.25161409378 |
