import argparse, gzip, json, math, os, re
from collections import Counter, defaultdict


def op(path):
    return gzip.open(path, 'rt', errors='replace') if path.endswith('.gz') else open(path, 'r', errors='replace')


def prefix(name):
    m = re.match(r'[A-Za-z_]+', name)
    return (m.group(0) if m else '<numeric>')[:32]


class DSU:
    def __init__(self, n):
        self.p = list(range(n)); self.sz = [1] * n
    def find(self, x):
        while self.p[x] != x:
            self.p[x] = self.p[self.p[x]]; x = self.p[x]
        return x
    def union(self, a, b):
        a = self.find(a); b = self.find(b)
        if a == b: return
        if self.sz[a] < self.sz[b]: a, b = b, a
        self.p[b] = a; self.sz[a] += self.sz[b]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--thresholds', default='4,8,16,32,64,128')
    a = ap.parse_args()
    section = None; objrow = None; integer_mode = False
    row_sense = {}; rows = defaultdict(list); obj = defaultdict(float)
    var_index = {}; var_integer = {}; coeff_abs = Counter(); col_nnz = Counter()
    rhs = defaultdict(float); bounds = defaultdict(dict)
    malformed = 0
    with op(a.model) as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith('*'): continue
            tok = line.split()
            head = tok[0].upper()
            if head in ('NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA'):
                section = head
                if head == 'ENDATA': break
                continue
            try:
                if section == 'ROWS':
                    s, r = tok[0], tok[1]; row_sense[r] = s
                    if s == 'N' and objrow is None: objrow = r
                elif section == 'COLUMNS':
                    if len(tok) >= 3 and tok[1].strip("'").upper() == 'MARKER':
                        mark = tok[2].strip("'").upper(); integer_mode = mark == 'INTORG'; continue
                    v = tok[0]
                    if v not in var_index:
                        var_index[v] = len(var_index); var_integer[v] = integer_mode
                    for k in range(1, len(tok) - 1, 2):
                        r = tok[k]; val = float(tok[k+1])
                        if r == objrow: obj[v] += val
                        else:
                            rows[r].append((v, val)); col_nnz[v] += 1
                            if val != 0:
                                e = int(math.floor(math.log10(abs(val))))
                                coeff_abs[e] += 1
                elif section == 'RHS':
                    for k in range(1, len(tok) - 1, 2): rhs[tok[k]] += float(tok[k+1])
                elif section == 'BOUNDS' and len(tok) >= 3:
                    typ, v = tok[0].upper(), tok[2]
                    val = float(tok[3]) if len(tok) > 3 else None
                    bounds[v][typ] = val
            except Exception:
                malformed += 1
    names = list(var_index); n = len(names)
    degrees = sorted(((len(ent), r) for r, ent in rows.items()), reverse=True)
    row_profiles = []
    for d, r in degrees[:100]:
        ni = sum(1 for v, _ in rows[r] if var_integer.get(v, False))
        row_profiles.append({'row':r,'sense':row_sense.get(r),'degree':d,'integer_entries':ni,'continuous_entries':d-ni,'rhs':rhs.get(r,0.0)})
    thresholds = [int(x) for x in a.thresholds.split(',')]
    decompositions = []
    for t in thresholds:
        ds = DSU(n); kept = 0; linking = []
        for r, ent in rows.items():
            ids = [var_index[v] for v, val in ent if val != 0]
            if len(ids) <= t:
                kept += 1
                if ids:
                    q = ids[0]
                    for z in ids[1:]: ds.union(q, z)
            else: linking.append(r)
        comps = Counter(ds.find(i) for i in range(n))
        sizes = sorted(comps.values(), reverse=True)
        nontrivial = [x for x in sizes if x > 1]
        linkvars = set(v for r in linking for v, val in rows[r] if val != 0)
        decompositions.append({'max_kept_row_degree':t,'kept_rows':kept,'linking_rows':len(linking),'linking_variables':len(linkvars),'components':len(sizes),'nontrivial_components':len(nontrivial),'largest_component':sizes[0] if sizes else 0,'top_component_sizes':sizes[:30]})
    objvals = [(abs(c), v, c) for v, c in obj.items() if c != 0]
    objvals.sort(reverse=True)
    result = {
      'model': os.path.basename(a.model), 'variables': n,
      'integer_variables_detected': sum(var_integer.values()),
      'continuous_variables_detected': n-sum(var_integer.values()),
      'rows_with_coefficients': len(rows),
      'row_senses': dict(Counter(row_sense.values())),
      'nonzeros': sum(len(x) for x in rows.values()),
      'malformed_lines': malformed,
      'row_degree_summary': {'min':degrees[-1][0] if degrees else 0,'median':degrees[len(degrees)//2][0] if degrees else 0,'max':degrees[0][0] if degrees else 0},
      'top_coupling_rows': row_profiles,
      'decompositions': decompositions,
      'variable_name_prefixes': Counter(prefix(v) for v in names).most_common(80),
      'row_name_prefixes': Counter(prefix(r) for r in rows).most_common(80),
      'objective_name_prefixes': Counter(prefix(v) for v in obj).most_common(80),
      'largest_objective_coefficients': [{'variable':v,'coefficient':c,'integer':var_integer.get(v,False),'column_degree':col_nnz[v]} for _,v,c in objvals[:100]],
      'coefficient_decimal_exponent_histogram': dict(sorted(coeff_abs.items())),
      'integer_column_degree_histogram': dict(Counter(col_nnz[v] for v in names if var_integer.get(v,False)).most_common()),
      'continuous_column_degree_histogram': dict(Counter(col_nnz[v] for v in names if not var_integer.get(v,False)).most_common())
    }
    with open('decomposition.json','w') as f: json.dump(result,f,indent=2,sort_keys=True)
    useful = any(d['nontrivial_components'] >= 5 and d['largest_component'] < 0.8*n for d in decompositions)
    mr = {'status':'completed','method':'incidence_linking_row_decomposition','produced_solution':False,'block_structure_candidate':useful,'variables':n,'rows':len(rows),'recommended_next':'blockwise neighborhood or repair search' if useful else 'test binary-master/continuous-recourse interface and objective-penalty structure'}
    with open('method_result.json','w') as f: json.dump(mr,f,indent=2,sort_keys=True)
    print(json.dumps(mr,sort_keys=True))

if __name__ == '__main__': main()
