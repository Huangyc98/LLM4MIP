#!/usr/bin/env python3
"""Exact incumbent improvement over classes of identical integer columns.

For each class of integer variables having exactly the same coefficients in every
constraint row, reallocate the incumbent's aggregate value among class members
subject to their individual bounds. This preserves every row activity exactly
while minimizing the class objective contribution.
"""
import argparse
import gzip
import json
import math
from collections import defaultdict
from decimal import Decimal, getcontext

getcontext().prec = 60
INF = None


def dec(s):
    return Decimal(s.replace('D', 'E').replace('d', 'e'))


def open_model(path):
    return gzip.open(path, 'rt', encoding='utf-8', errors='replace') if path.endswith('.gz') else open(path, 'r', encoding='utf-8', errors='replace')


def ceil_dec(x):
    return int(x.to_integral_value(rounding='ROUND_CEILING'))


def floor_dec(x):
    return int(x.to_integral_value(rounding='ROUND_FLOOR'))


def parse_mps(path):
    section = None
    objective_row = None
    row_types = {}
    columns = defaultdict(lambda: defaultdict(Decimal))
    costs = defaultdict(Decimal)
    order = []
    seen = set()
    integer = set()
    integer_mode = False
    lower = defaultdict(lambda: Decimal(0))
    upper = defaultdict(lambda: INF)

    with open_model(path) as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith('*'):
                continue
            toks = line.split()
            head = toks[0].upper()
            if head in ('NAME', 'ROWS', 'COLUMNS', 'RHS', 'RANGES', 'BOUNDS', 'ENDATA', 'OBJSENSE', 'OBJNAME'):
                section = head
                if head == 'ENDATA':
                    break
                continue
            if section == 'ROWS':
                if len(toks) >= 2:
                    typ, name = toks[0].upper(), toks[1]
                    row_types[name] = typ
                    if typ == 'N' and objective_row is None:
                        objective_row = name
            elif section == 'COLUMNS':
                if len(toks) >= 3 and toks[1].strip("'").upper() == 'MARKER':
                    marker = toks[2].strip("'").upper()
                    if marker == 'INTORG':
                        integer_mode = True
                    elif marker == 'INTEND':
                        integer_mode = False
                    continue
                var = toks[0]
                if var not in seen:
                    seen.add(var)
                    order.append(var)
                if integer_mode:
                    integer.add(var)
                pairs = toks[1:]
                for i in range(0, len(pairs) - 1, 2):
                    row, value = pairs[i], dec(pairs[i + 1])
                    if row == objective_row:
                        costs[var] += value
                    elif row_types.get(row) != 'N':
                        columns[var][row] += value
            elif section == 'BOUNDS' and len(toks) >= 3:
                typ = toks[0].upper()
                var = toks[2]
                value = dec(toks[3]) if len(toks) >= 4 else Decimal(0)
                if var not in seen:
                    seen.add(var)
                    order.append(var)
                if typ == 'LO':
                    lower[var] = value
                elif typ == 'UP':
                    upper[var] = value
                elif typ == 'FX':
                    lower[var] = value
                    upper[var] = value
                elif typ == 'FR':
                    lower[var] = None
                    upper[var] = None
                elif typ == 'MI':
                    lower[var] = None
                elif typ == 'PL':
                    upper[var] = None
                elif typ == 'BV':
                    integer.add(var)
                    lower[var] = Decimal(0)
                    upper[var] = Decimal(1)
                elif typ == 'LI':
                    integer.add(var)
                    lower[var] = value
                elif typ == 'UI':
                    integer.add(var)
                    upper[var] = value

    return order, columns, costs, integer, lower, upper


def parse_solution(path, variables):
    values = {v: Decimal(0) for v in variables}
    known = set(variables)
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        for raw in f:
            s = raw.strip()
            if not s or s.startswith('#'):
                continue
            toks = s.split()
            if len(toks) >= 2 and toks[0] in known:
                try:
                    values[toks[0]] = dec(toks[1])
                except Exception:
                    pass
    return values


def objective(values, costs):
    return sum((costs[v] * x for v, x in values.items()), Decimal(0))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--incumbent', required=True)
    args = ap.parse_args()

    order, columns, costs, integer, lower, upper = parse_mps(args.model)
    values = parse_solution(args.incumbent, order)
    before = objective(values, costs)

    groups = defaultdict(list)
    for v in integer:
        signature = tuple(sorted((r, a) for r, a in columns[v].items() if a != 0))
        groups[signature].append(v)

    duplicate_classes = 0
    changed_classes = 0
    changed_variables = 0
    largest_class = 0
    predicted_gain = Decimal(0)

    for members in groups.values():
        if len(members) < 2:
            continue
        duplicate_classes += 1
        largest_class = max(largest_class, len(members))
        # Only process classes with finite, integral effective bounds and an
        # integral incumbent aggregate. Skipping unusual domains is safer than
        # making an unsupported transformation.
        bounds = {}
        safe = True
        for v in members:
            lo = lower[v]
            up = upper[v]
            if lo is None or up is None:
                safe = False
                break
            ilo, iup = ceil_dec(lo), floor_dec(up)
            if ilo > iup:
                safe = False
                break
            bounds[v] = (ilo, iup)
        if not safe:
            continue
        total_d = sum((values[v] for v in members), Decimal(0))
        if total_d != total_d.to_integral_value():
            continue
        total = int(total_d)
        min_total = sum(bounds[v][0] for v in members)
        max_total = sum(bounds[v][1] for v in members)
        if total < min_total or total > max_total:
            continue

        candidate = {v: bounds[v][0] for v in members}
        remaining = total - min_total
        for v in sorted(members, key=lambda z: (costs[z], z)):
            capacity = bounds[v][1] - bounds[v][0]
            take = min(capacity, remaining)
            candidate[v] += take
            remaining -= take
            if remaining == 0:
                break
        if remaining:
            continue

        old_cost = sum((costs[v] * values[v] for v in members), Decimal(0))
        new_cost = sum((costs[v] * Decimal(candidate[v]) for v in members), Decimal(0))
        if new_cost < old_cost:
            changed_classes += 1
            predicted_gain += old_cost - new_cost
            for v in members:
                nv = Decimal(candidate[v])
                if nv != values[v]:
                    changed_variables += 1
                values[v] = nv

    after = objective(values, costs)
    with open('best.sol', 'w', encoding='utf-8') as f:
        f.write('# Duplicate-column exchange candidate\n')
        f.write('# Objective value = %s\n' % format(after, 'f'))
        for v in order:
            x = values[v]
            if x != 0:
                f.write('%s %s\n' % (v, format(x, 'f')))

    result = {
        'method': 'exact_duplicate_integer_column_exchange',
        'status': 'candidate_written',
        'variables': len(order),
        'integer_variables': len(integer),
        'duplicate_classes': duplicate_classes,
        'largest_duplicate_class': largest_class,
        'improved_classes': changed_classes,
        'changed_variables': changed_variables,
        'input_linear_objective': str(before),
        'output_linear_objective': str(after),
        'predicted_gain': str(predicted_gain),
        'feasibility_argument': 'Each processed class has identical coefficients in every constraint row and its aggregate value is preserved.'
    }
    with open('method_result.json', 'w', encoding='utf-8') as f:
        json.dump(result, f, indent=2, sort_keys=True)
    with open('exchange_report.json', 'w', encoding='utf-8') as f:
        json.dump(result, f, indent=2, sort_keys=True)


if __name__ == '__main__':
    main()
