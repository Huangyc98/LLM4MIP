#!/usr/bin/env python3
"""Solver-independent structural inspection of an MPS/MPS.GZ model."""
import argparse, collections, gzip, json, math, os, re

p = argparse.ArgumentParser()
p.add_argument('--model', required=True)
a = p.parse_args()

def opn(path):
    return gzip.open(path, 'rt', errors='replace') if path.endswith('.gz') else open(path, 'rt', errors='replace')

section = None
row_sense = {}
rhs = collections.defaultdict(float)
ranges = {}
bounds = {}
objrow = None
obj = collections.defaultdict(float)
col_rows = collections.defaultdict(dict)
integer_mode = False
integer_cols = set()
section_counts = collections.Counter()
with opn(a.model) as f:
    for raw in f:
        line = raw.rstrip('\n')
        if not line or line.startswith('*'):
            continue
        toks = line.split()
        if not toks:
            continue
        head = toks[0].upper()
        if head in {'NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA','OBJSENSE','OBJNAME'}:
            section = head
            if head == 'ENDATA': break
            continue
        section_counts[section] += 1
        if section == 'ROWS' and len(toks) >= 2:
            typ, name = toks[0], toks[1]
            if typ == 'N' and objrow is None: objrow = name
            else: row_sense[name] = typ
        elif section == 'COLUMNS':
            if len(toks) >= 3 and toks[1].strip("'").upper() == 'MARKER':
                marker = toks[-1].strip("'").upper()
                integer_mode = marker == 'INTORG'
                continue
            col = toks[0]
            if integer_mode: integer_cols.add(col)
            for i in range(1, len(toks)-1, 2):
                r = toks[i]
                try: v = float(toks[i+1])
                except ValueError: continue
                if r == objrow: obj[col] += v
                else: col_rows[col][r] = col_rows[col].get(r, 0.0) + v
        elif section == 'RHS':
            for i in range(1, len(toks)-1, 2):
                try: rhs[toks[i]] = float(toks[i+1])
                except ValueError: pass
        elif section == 'RANGES':
            for i in range(1, len(toks)-1, 2):
                try: ranges[toks[i]] = float(toks[i+1])
                except ValueError: pass
        elif section == 'BOUNDS' and len(toks) >= 3:
            typ, col = toks[0], toks[2]
            val = float(toks[3]) if len(toks) > 3 else None
            bounds.setdefault(col, []).append((typ, val))
            if typ in {'BV','LI','UI','SI'}: integer_cols.add(col)

all_cols = sorted(set(col_rows) | set(obj) | set(bounds))
row_cols = collections.defaultdict(list)
coef_abs = []
coef_sign = collections.Counter()
for c, rs in col_rows.items():
    for r,v in rs.items():
        row_cols[r].append((c,v))
        coef_abs.append(abs(v))
        coef_sign['positive' if v > 0 else 'negative' if v < 0 else 'zero'] += 1

def prefix(s):
    # Preserve informative stem while removing trailing numeric indices.
    z = re.sub(r'([_\.\-]?\d+)+$', '', s)
    return z if z else '<numeric>'

def quantiles(vals):
    if not vals: return {}
    x=sorted(vals)
    def q(fr): return x[min(len(x)-1, int(fr*(len(x)-1)))]
    return {'min':x[0], 'q25':q(.25), 'median':q(.5), 'q75':q(.75), 'q90':q(.9), 'q99':q(.99), 'max':x[-1]}

def top_counter(it, n=30): return [{'key':str(k),'count':v} for k,v in collections.Counter(it).most_common(n)]

row_degree = {r:len(v) for r,v in row_cols.items()}
col_degree = {c:len(col_rows.get(c,{})) for c in all_cols}
obj_abs = [abs(v) for v in obj.values() if v]
coef_classes = collections.Counter()
for v in coef_abs:
    if v == 1: key='1'
    elif v <= 10: key='(1,10]'
    elif v <= 1000: key='(10,1e3]'
    elif v <= 1e6: key='(1e3,1e6]'
    else: key='>1e6'
    coef_classes[key]+=1

# Summaries by name stem reveal repeated time/customer/site blocks.
col_pref = collections.defaultdict(lambda:{'count':0,'integer':0,'objective_nonzero':0,'degrees':[]})
for c in all_cols:
    d=col_pref[prefix(c)]; d['count']+=1; d['integer']+=int(c in integer_cols); d['objective_nonzero']+=int(obj.get(c,0)!=0); d['degrees'].append(col_degree[c])
col_pref_out=[]
for k,d in sorted(col_pref.items(), key=lambda kv:(-kv[1]['count'],kv[0]))[:40]:
    col_pref_out.append({'prefix':k,'count':d['count'],'integer':d['integer'],'objective_nonzero':d['objective_nonzero'],'degree':quantiles(d['degrees'])})
row_pref = top_counter(prefix(r) for r in row_sense)

# Identify likely linking/penalty rows and representative names, without dumping the full model.
large_rows=[]
for r,cv in row_cols.items():
    m=max((abs(v) for _,v in cv),default=0)
    if m>=1e6 or abs(rhs.get(r,0))>=1e6:
        large_rows.append({'row':r,'sense':row_sense.get(r),'degree':len(cv),'max_abs_coef':m,'rhs':rhs.get(r,0)})
large_rows=sorted(large_rows,key=lambda x:(-x['max_abs_coef'],-abs(x['rhs'])))[:30]

out={
 'model_file_basename':os.path.basename(a.model),
 'counts':{'columns':len(all_cols),'rows':len(row_sense),'integer_columns_detected':len(integer_cols),'objective_nonzeros':sum(v!=0 for v in obj.values()),'matrix_nonzeros':sum(len(x) for x in col_rows.values())},
 'row_senses':dict(collections.Counter(row_sense.values())),
 'row_degree_quantiles':quantiles(list(row_degree.values())),
 'column_degree_quantiles':quantiles(list(col_degree.values())),
 'matrix_abs_coefficient_quantiles':quantiles(coef_abs),
 'matrix_coefficient_scale_classes':dict(coef_classes),
 'matrix_signs':dict(coef_sign),
 'objective_abs_quantiles':quantiles(obj_abs),
 'rhs_quantiles':quantiles([v for v in rhs.values()]),
 'column_prefix_groups':col_pref_out,
 'row_prefix_groups':row_pref,
 'largest_or_big_rhs_rows':large_rows,
 'representative_columns':[{'name':c,'integer':c in integer_cols,'objective':obj.get(c,0),'degree':col_degree[c],'bound_records':bounds.get(c,[])} for c in all_cols[:25]],
 'representative_rows':[{'name':r,'sense':row_sense[r],'rhs':rhs.get(r,0),'degree':row_degree.get(r,0)} for r in sorted(row_sense)[:25]],
 'notes':['Prefix grouping removes trailing numeric indices only.','No optimization or solver API is used.']
}
with open('siena-structure-analysis.json','w',encoding='utf-8') as g: json.dump(out,g,indent=2,sort_keys=True)
print(json.dumps({'artifact':'siena-structure-analysis.json','counts':out['counts']}))
