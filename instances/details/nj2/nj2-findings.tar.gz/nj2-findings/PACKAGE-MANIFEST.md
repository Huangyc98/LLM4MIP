# Package manifest: nj2

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 47
Excluded source files: 1

## Included files

- `README.md`
- `analysis/compound-kick-382.0606208032-validation.json`
- `analysis/copt8-direct-two-node-assignment.json`
- `analysis/copt8-followup-438-1800s-result.json`
- `analysis/copt8-post-descent-438.5907110388-validation.json`
- `analysis/copt8-post-descent-archive.json`
- `analysis/copt8-post-one-node-assignment.json`
- `analysis/copt8-post-two-node-assignment.json`
- `analysis/copt8-warmstart-1800s-assignment.json`
- `analysis/copt8-warmstart-1800s-result.json`
- `analysis/copt8-warmstart-1800s-strict-validation.json`
- `analysis/large-neighborhood-403.4107959378-validation.json`
- `analysis/nj1-nj2-projection.json`
- `analysis/nj2-gurobi13-structure.json`
- `analysis/pair-recombination-383.6229250390-validation.json`
- `analysis/steepest-descent-assignment.json`
- `analysis/steepest-descent-validation.json`
- `analysis/structure.json`
- `analysis/tree-partition-assignment.json`
- `analysis/tree-partition-validation.json`
- `analysis/two-node-steepest-descent-assignment.json`
- `analysis/two-node-steepest-descent-validation.json`
- `experiments/district1-oracle-extraction.json`
- `experiments/district1-oracle.mps.gz`
- `experiments/extract_copt_assignment.py`
- `experiments/nj1_nj2_projection.py`
- `input/SHA256SUMS`
- `input/nj2.dec`
- `logs/copt8-followup-438-1800s.log`
- `logs/copt8-warmstart-1800s.log`
- `solutions/compound-kick-382.0606208032.independent-check.log`
- `solutions/compound-kick-382.0606208032.sol`
- `solutions/copt8-post-descent-438.5907110388.independent-check.log`
- `solutions/copt8-post-descent-438.5907110388.sol`
- `solutions/copt8-warmstart-1800s.raw.independent-check.log`
- `solutions/copt8-warmstart-1800s.raw.sol`
- `solutions/copt8-warmstart-1800s.strict.sol`
- `solutions/large-neighborhood-403.4107959378.independent-check.log`
- `solutions/large-neighborhood-403.4107959378.sol`
- `solutions/pair-recombination-383.6229250390.independent-check.log`
- `solutions/pair-recombination-383.6229250390.sol`
- `solutions/steepest-descent-465.1832684642.independent-check.log`
- `solutions/steepest-descent-465.1832684642.sol`
- `solutions/tree-partition-529.9611973238.independent-check.log`
- `solutions/tree-partition-529.9611973238.sol`
- `solutions/two-node-steepest-descent-459.0072494478.independent-check.log`
- `solutions/two-node-steepest-descent-459.0072494478.sol`

## Excluded files

- `input/nj2.mps.gz (2314308 bytes; raw benchmark input; sha256 621fc2f4cc94c0a7188fe243fcdd5782add75ea06fcdf3efaa2e5f922f4fad06)`
