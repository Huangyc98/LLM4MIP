# nj2: improved first strict incumbent, 382.0606208032

## Result and claim boundary

This directory contains a new **strictly feasible original-MPS solution** with
objective `382.0606208032`. The official MIPLIB page still listed `nj2` as
`open`, `no_solution`, and with no objective value when checked on 2026-09-08.
This is therefore a first public incumbent relative to that page, but there is
no global lower bound or optimality claim.

Current artifacts:

- [`solutions/compound-kick-382.0606208032.sol`](solutions/compound-kick-382.0606208032.sol),
  in MIPLIB-compatible `=obj=` format, SHA-256
  `0bc55ce1f872b5b4f1f78e037fe862b9934b5ba78616fbea95eeb140f61de3e6`;
- [`../nj1/analysis/final-assignment-382.0606208032.json`](../nj1/analysis/final-assignment-382.0606208032.json),
  the shared compact 595-label assignment, SHA-256
  `a13e58bd98050c830ca3436eb616410cb60fc64d3b2424f8bf5f29cac6ddeba5`;
- [`analysis/compound-kick-382.0606208032-validation.json`](analysis/compound-kick-382.0606208032-validation.json)
  and [`solutions/compound-kick-382.0606208032.independent-check.log`](solutions/compound-kick-382.0606208032.independent-check.log),
  two full zero-tolerance checks;
- [`../nj1/analysis/continuation-403-to-382.0606208032-archive.json`](../nj1/analysis/continuation-403-to-382.0606208032-archive.json),
  the shared continuation, hash, terminal-neighborhood, and evidence record;
- [`../nj3/analysis/exact-pair-copt8-from382/`](../nj3/analysis/exact-pair-copt8-from382/),
  COPT 8 computational closure of all 21 current adjacent-pair repartition
  subproblems;
- [`../nj3/analysis/exact-triple-copt8-from382/`](../nj3/analysis/exact-triple-copt8-from382/)
  and [`../nj3/analysis/exact-quad-copt8-from382/`](../nj3/analysis/exact-quad-copt8-from382/),
  all 39 current anchor-fixed connected triple and all 67 current anchor-fixed
  connected quad subproblems.

The preceding `383.6229250390` artifacts are retained as:

- [`solutions/pair-recombination-383.6229250390.sol`](solutions/pair-recombination-383.6229250390.sol),
  SHA-256 `819650f41259c7c8bf53e7eeca2babc915b943ae85f9b9bf5bc36c13efea8354`;
- [`../nj3/analysis/district-pair-recombination-from403.json`](../nj3/analysis/district-pair-recombination-from403.json),
  the shared exact 11-step pair-recombination trace;
- [`analysis/pair-recombination-383.6229250390-validation.json`](analysis/pair-recombination-383.6229250390-validation.json)
  and [`solutions/pair-recombination-383.6229250390.independent-check.log`](solutions/pair-recombination-383.6229250390.independent-check.log),
  two full zero-tolerance checks.

The preceding `403.4107959378` artifacts are retained as:

- [`solutions/large-neighborhood-403.4107959378.sol`](solutions/large-neighborhood-403.4107959378.sol),
  in MIPLIB-compatible `=obj=` format, SHA-256
  `154437fc5ba60a1d8d77d4e281166d5365e6f7f6ae8b7af7005e0328dffe6c6e`;
- [`../nj1/analysis/large-neighborhood-chain-403.4107959378.json`](../nj1/analysis/large-neighborhood-chain-403.4107959378.json),
  the shared self-contained 46-move chain and final assignment;
- [`analysis/large-neighborhood-403.4107959378-validation.json`](analysis/large-neighborhood-403.4107959378-validation.json)
  and [`solutions/large-neighborhood-403.4107959378.independent-check.log`](solutions/large-neighborhood-403.4107959378.independent-check.log),
  two full zero-tolerance checks;
- [`../nj1/analysis/large-neighborhood-403.4107959378-archive.json`](../nj1/analysis/large-neighborhood-403.4107959378-archive.json),
  the shared search, hash, terminal-neighborhood and evidence record.

The preceding `438.5907110388` artifacts are retained as:

- [`solutions/copt8-post-descent-438.5907110388.sol`](solutions/copt8-post-descent-438.5907110388.sol),
  in MIPLIB-compatible `=obj=` format, SHA-256
  `e1bed5a9dd958603b797f8c324cdbbd508c9c612ed4c4eb60d9994f4f6eebcf6`;
- [`analysis/copt8-post-two-node-assignment.json`](analysis/copt8-post-two-node-assignment.json),
  the shared improved 595-node assignment and exact move trace, SHA-256
  `35a3bfeca3331fd3c3f09511c56c5509ddabc9da95944f92386e15e60680e760`;
- [`analysis/copt8-post-descent-438.5907110388-validation.json`](analysis/copt8-post-descent-438.5907110388-validation.json),
  full zero-tolerance Decimal reconstruction;
- [`solutions/copt8-post-descent-438.5907110388.independent-check.log`](solutions/copt8-post-descent-438.5907110388.independent-check.log),
  independent repository-wide MPS check;
- [`analysis/copt8-post-descent-archive.json`](analysis/copt8-post-descent-archive.json),
  frozen COPT, extraction, reconstruction, exact-search, hash and evidence record.

The earlier `529.9611973238`, `465.1832684642`, `459.0072494478`,
`438.5907110388`, `403.4107959378`, and `383.6229250390` solutions
remain under their original names as intermediate history.

The independent result is:

```text
objective=382.0606208032
rows=118975 exact_row_violations=0 row_violations_above_0=0 max_row_violation=0
bound_violations_above_0=0 exact_integrality_violations=0
```

All twelve district populations lie in `[696025, 769290]`, and all twelve
selected subgraphs are connected.

## Gurobi 13 read-only structure audit

The original MPS was first read on `euler4` with Gurobi 13.0.1. The run did
not call `optimize()` or `presolve()`; the complete snapshot is
[`analysis/nj2-gurobi13-structure.json`](analysis/nj2-gurobi13-structure.json)
and the reader is
[`../nj1/experiments/gurobi13_structure.py`](../nj1/experiments/gurobi13_structure.py).

Gurobi read:

- 85,224 variables, 118,975 linear rows, and 364,332 nonzeros;
- 70,944 continuous variables and 14,280 integral `[0,1]` variables;
- 52,056 `<=`, 7,747 equality, and 59,172 `>=` rows;
- 18,888 positive nonzero objective coefficients;
- the same 607 unit-coefficient partitioning rows as `nj1`;
- no quadratic, SOS, or general constraints;
- Gurobi fingerprint `349748728`.

## Exact relationship to nj1

[`analysis/nj1-nj2-projection.json`](analysis/nj1-nj2-projection.json) and
[`experiments/nj1_nj2_projection.py`](experiments/nj1_nj2_projection.py)
exhaustively compare the two anonymous MPS files:

- the first 97,579 algebraic rows are coefficient-for-coefficient identical
  after shifting the two binary column families by 7,140;
- bounds, objective coefficients, and integrality agree on all 78,084 common
  variables;
- `nj2` adds 7,140 continuous `q` columns and 21,396 rows, all matching three
  audited monotonic/root templates;
- those rows require the chosen connectivity root to be the minimum-index
  selected unit in its district.

The constructive solver chooses the minimum selected index as every root and
sets the `q` chain exactly, so the `nj1` assignment lifts directly to `nj2`.
The full original-MPS validation above is stronger than relying on this
interpretation alone.

## Method and background

The shared constructive method is documented in
[`../nj1/README.md`](../nj1/README.md). It recursively cuts population-balanced
descendant subtrees from randomized DFS spanning trees, then reconstructs the
original boundary, root, and population-flow variables. The best of 200
deterministic restarts was `529.9611973238` at restart 163. Deterministic exact
steepest descent over all feasible connected one-node boundary moves then
applied 27 moves and improved it by `64.7779288596` to `465.1832684642`.
Exact steepest descent over the union of one-node transfers, cross-district
two-point exchanges, and connected adjacent-pair transfers applied five more
moves and improved it to `459.0072494478`. A terminal exhaustive pass found no
improvement among 114 feasible one-node transfers, 325 exchanges, and 155
adjacent-pair transfers.

A subsequent 1,800-second COPT 8.0.4 warm-start run found a different integer
assignment. Its raw point reported `458.9242116973`, but the archived zero-
tolerance check records nine row residuals up to `2.77e-11` and one assignment
entry `1.1e-16` away from an integer, so the raw file is not claimed as strict.
[`experiments/extract_copt_assignment.py`](experiments/extract_copt_assignment.py)
rounds only that entry within an explicit `1e-9` tolerance. Deterministic exact
lifting removes one redundant boundary variable and gives `458.9185121516`.
One exact single-node move then reaches `458.5271075712`; the joint neighborhood
applies three exchanges and four further single-node moves to reach
`438.5907110388`.

The terminal exact scan finds no improvement among 127 feasible one-node
transfers, 375 exchanges, and 173 adjacent-pair transfers. A second replay is
byte-identical. The total improvement from the original 529.9611973238
construction is `91.3704862850` (17.24098%). This is local, not global,
optimality; the COPT numerical bound is not promoted to a strict lower bound.

The subsequent deterministic large-neighborhood search shared with `nj1`
adds connected three-node transfers, connected two-for-one exchanges, and
three-district one-node cycles. At each local minimum it evaluates feasible
compound kicks and performs an exact one/two-node descent from every retained
kick. Its 46-step exact chain, including deliberate worsening moves used to
cross local basins, improves the objective through

```text
438.5907110388 -> 434.5476868456 -> 430.9422863344
-> 422.6463512340 -> 410.5559967264 -> 403.4107959378.
```

The final exhaustive round checked all 2,322 feasible compound kicks and fully
descended each: none improved `403.4107959378`. The complete method, exact chain,
compressed terminal outcomes, independent verifier and precise evidence boundary
are documented in the
[`nj1` large-neighborhood section](../nj1/README.md#larger-connected-neighborhood-search-403-stage)
and [shared archive](../nj1/analysis/large-neighborhood-403.4107959378-archive.json).
This remains a neighborhood result, not a global lower bound.

District-pair spanning-tree recombination next applies 11 exact accepted
repartitions and improves `403.4107959378` to the historical strict incumbent
`383.6229250390`. An exhaustive compound-kick round from that assignment then
finds the current `382.0606208032`: its best path consists of one deliberately
worsening connected-triple transfer followed by six exact one/two-node descent
moves. At the current assignment a new large scan admits 2,133 exactly feasible
compound kicks; fully descending all of them gives 1,950 equal and 183 worse
outcomes, with no improvement. Three seeded pair scans also find no improving
tree cut among 231,000 trees.

More strongly,
[`exact_district_pair_copt.py`](../nj3/experiments/exact_district_pair_copt.py)
optimizes an arbitrary connected repartition of each current adjacent district
pair's entire node union with all other districts fixed. COPT 8 computationally
closed all 21 of 21 adjacent pairs and reported the incumbent pair cut optimal,
with zero delta, no timeout, and no unproved pair. This is a solver-backed
computational certificate of complete two-district-repartition local optimality
for the current adjacent pairs, not a separately formalized proof checker,
global optimality result, or full-instance lower bound. The exact paths, full
compressed outcomes, proof
manifest, hashes, and evidence boundaries are documented in the
[`nj1` continuation section](../nj1/README.md#district-pair-recombination-and-compound-continuation)
and
[`shared continuation archive`](../nj1/analysis/continuation-403-to-382.0606208032-archive.json).

The same assignment was also tested in every connected three- and
four-district union of its current district-adjacency graph. COPT 8 closed all
39 anchor-fixed triples and all 67 anchor-fixed quads with exact objective
delta zero; one quad needed a longer retry. The archived
[`triple`](../nj3/analysis/exact-triple-copt8-from382/) and
[`quad`](../nj3/analysis/exact-quad-copt8-from382/) evidence fixes one current
anchor per district, so it is local computational evidence rather than a
global lower bound or a proof against repartitions that merge anchors.

A new 1,800-second, 16-thread COPT 8.0.4 full-MPS run warm-started from the
current `382.0606208032` witness and found no improvement. It stopped at the
time limit after one node with numerical best bound
`4.440892098500626e-16`; the shared
[`full-model archive`](../nj3/analysis/copt8-full-model-from382/) preserves the
result and log. This numerical bound is not a strict certificate.

The earlier COPT result, raw point, and log that seeded the `438.5907110388`
stage are
[`analysis/copt8-warmstart-1800s-result.json`](analysis/copt8-warmstart-1800s-result.json),
[`solutions/copt8-warmstart-1800s.raw.sol`](solutions/copt8-warmstart-1800s.raw.sol),
and [`logs/copt8-warmstart-1800s.log`](logs/copt8-warmstart-1800s.log).
A second 1,800-second, 32-thread follow-up warm-started at the preceding strict
`438.5907110388` solution and found no improvement.  It processed one node and
again ended with a near-zero numerical bound.  The compact
[`result`](analysis/copt8-followup-438-1800s-result.json) and
[`log`](logs/copt8-followup-438-1800s.log) are archived; this run adds no
strict lower-bound information.

Authoritative sources:

- MIPLIB page and decomposition:
  <https://miplib.zib.de/instance_details_nj2.html> and
  <https://miplib.zib.de/WebData/decomps_orig/nj2.dec>;
- Validi and Buchanan (2022),
  <https://doi.org/10.1007/s12532-022-00221-5>, which explicitly discusses the
  unresolved `nj1`--`nj3` family and relevant cut/flow/symmetry techniques.

Exact hashes are in [`input/SHA256SUMS`](input/SHA256SUMS). The archived
`nj2.mps.gz` SHA-256 is
`621fc2f4cc94c0a7188fe243fcdd5782add75ea06fcdf3efaa2e5f922f4fad06`.

## Reproduce

```bash
python instances/nj2/experiments/nj1_nj2_projection.py \
  instances/nj1/input/nj1.mps.gz \
  instances/nj2/input/nj2.mps.gz \
  instances/nj2/analysis/nj1-nj2-projection.json

python instances/nj2/experiments/extract_copt_assignment.py \
  instances/nj2/solutions/copt8-warmstart-1800s.raw.sol \
  instances/nj2/analysis/copt8-warmstart-1800s-assignment.json

python instances/nj1/experiments/connected_boundary_steepest_descent.py \
  instances/nj1/input/nj1.mps.gz \
  instances/nj2/analysis/copt8-warmstart-1800s-assignment.json \
  instances/nj2/analysis/copt8-post-one-node-assignment.json

python instances/nj1/experiments/connected_two_node_steepest_descent.py \
  instances/nj1/input/nj1.mps.gz \
  instances/nj2/analysis/copt8-post-one-node-assignment.json \
  instances/nj2/analysis/copt8-post-two-node-assignment.json

# Rebuild the historical 438.5907110388 stage.
python instances/nj1/experiments/build_and_check_nj_solution.py \
  instances/nj2/input/nj2.mps.gz \
  instances/nj2/analysis/copt8-post-two-node-assignment.json \
  instances/nj2/solutions/copt8-post-descent-438.5907110388.sol \
  instances/nj2/analysis/copt8-post-descent-438.5907110388-validation.json

python common/exact_mps_solution_check.py \
  instances/nj2/input/nj2.mps.gz \
  instances/nj2/solutions/copt8-post-descent-438.5907110388.sol \
  --tolerance 0

# Rebuild and independently check the current strict incumbent.
python instances/nj1/experiments/build_and_check_nj_solution.py \
  instances/nj2/input/nj2.mps.gz \
  instances/nj1/analysis/final-assignment-382.0606208032.json \
  instances/nj2/solutions/compound-kick-382.0606208032.sol \
  instances/nj2/analysis/compound-kick-382.0606208032-validation.json

python common/exact_mps_solution_check.py \
  instances/nj2/input/nj2.mps.gz \
  instances/nj2/solutions/compound-kick-382.0606208032.sol \
  --tolerance 0
```
