#!/usr/bin/env python3
"""Prove the anonymous-column mapping between nj1 and nj2.

nj2 inserts 595 period-12 continuous q layers and 1,783 period-12 rows.
After shifting the two binary families, its original district core is exactly
nj1.  The added rows are audited against their closed-form symmetry templates.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from decimal import Decimal
from pathlib import Path


THIS = Path(__file__).resolve()
NJ1_EXPERIMENTS = THIS.parents[2] / "nj1" / "experiments"
sys.path.insert(0, str(NJ1_EXPERIMENTS))
from nj_block_forensics import numeric_suffix, parse_mps, sha256  # noqa: E402


def cname(index: int) -> str:
    return f"C{index:04d}"


def rname(index: int) -> str:
    return f"R{index:04d}"


def mapped_column(variable: str) -> str:
    index = numeric_suffix(variable)
    return variable if index <= 63804 else cname(index + 7140)


def normalized_terms(terms: list[tuple[str, Decimal]], mapping) -> list[tuple[str, Decimal]]:
    return sorted((mapping(variable), coefficient) for variable, coefficient in terms)


def audit_added_rows(nj2: dict) -> dict:
    rows = nj2["rows"]
    rhs = nj2["rhs"]
    failures: list[dict] = []

    def check(row_index: int, sense: str, row_rhs: Decimal, expected: list[tuple[str, Decimal]], label: str) -> None:
        row = rname(row_index)
        actual = sorted(rows[row]["terms"])
        if rows[row]["sense"] != sense or rhs.get(row, Decimal(0)) != row_rhs or actual != sorted(expected):
            failures.append({
                "row": row,
                "template": label,
                "expected_sense": sense,
                "actual_sense": rows[row]["sense"],
                "expected_rhs": str(row_rhs),
                "actual_rhs": str(rhs.get(row, Decimal(0))),
                "expected_terms": [(var, str(value)) for var, value in expected],
                "actual_terms": [(var, str(value)) for var, value in actual],
            })

    first = 97580
    for unit in range(1, 595):
        for district in range(1, 13):
            offset = (unit - 1) * 12 + district - 1
            q_next = cname(63805 + unit * 12 + district - 1)
            assignment = cname(70945 + (unit - 1) * 12 + district - 1)
            check(first + offset, "G", Decimal(0), [(q_next, Decimal(1)), (assignment, Decimal(-1))],
                  "q_(i+1,d) - x_(i,d) >= 0")

    first = 104708
    for unit in range(1, 595):
        for district in range(1, 13):
            offset = (unit - 1) * 12 + district - 1
            q_here = cname(63805 + (unit - 1) * 12 + district - 1)
            q_next = cname(63805 + unit * 12 + district - 1)
            check(first + offset, "G", Decimal(0), [(q_next, Decimal(1)), (q_here, Decimal(-1))],
                  "q_(i+1,d) - q_(i,d) >= 0")

    first = 111836
    for unit in range(1, 596):
        for district in range(1, 13):
            offset = (unit - 1) * 12 + district - 1
            q_here = cname(63805 + (unit - 1) * 12 + district - 1)
            root = cname(78085 + (unit - 1) * 12 + district - 1)
            check(first + offset, "L", Decimal(1), [(q_here, Decimal(1)), (root, Decimal(1))],
                  "q_(i,d) + root_(i,d) <= 1")

    return {
        "new_q_variable_range": ["C63805", "C70944"],
        "new_q_variable_count": 7140,
        "new_row_range": ["R97580", "R118975"],
        "new_row_count": 21396,
        "template_rows_checked": 21396,
        "template_failure_count": len(failures),
        "template_failure_sample": failures[:10],
        "logical_consequence": (
            "If root_(j,d)=1, monotonicity gives q_(i,d)=0 for i<=j; "
            "x_(i,d)<=q_(i+1,d) therefore forbids every selected i<j. "
            "The chosen root is the minimum-index selected unit."
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("nj1_mps", type=Path)
    parser.add_argument("nj2_mps", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    nj1 = parse_mps(args.nj1_mps)
    nj2 = parse_mps(args.nj2_mps)

    row_failures = []
    for index in range(1, 97580):
        left_name = rname(index)
        right_name = left_name
        left = nj1["rows"][left_name]
        right = nj2["rows"][right_name]
        if (
            left["sense"] != right["sense"]
            or nj1["rhs"].get(left_name, Decimal(0)) != nj2["rhs"].get(right_name, Decimal(0))
            or normalized_terms(left["terms"], mapped_column) != normalized_terms(right["terms"], lambda value: value)
        ):
            row_failures.append(left_name)

    objective_failures = []
    left_objective = nj1["rows"]["R97580"]
    right_objective = nj2["rows"]["R118976"]
    if normalized_terms(left_objective["terms"], mapped_column) != normalized_terms(right_objective["terms"], lambda value: value):
        objective_failures.append("objective coefficients")

    variable_failures = []
    for variable, left in nj1["variables"].items():
        mapped = mapped_column(variable)
        right = nj2["variables"][mapped]
        if (
            left["integer"] != right["integer"]
            or left["lower"] != right["lower"]
            or left["upper"] != right["upper"]
        ):
            variable_failures.append(variable)

    added = audit_added_rows(nj2)
    result = {
        "evidence_level": "exact Decimal matrix isomorphism for the common core plus exhaustive added-row template audit",
        "sha256": {"nj1_mps_gz": sha256(args.nj1_mps), "nj2_mps_gz": sha256(args.nj2_mps)},
        "mapping": {
            "rows": "R0001..R97579 map identically; nj1 objective R97580 maps to nj2 R118976",
            "continuous_columns": "C0001..C63804 map identically",
            "binary_columns": "nj1 C63805..C78084 map to nj2 C70945..C85224 by adding 7140",
            "district_index": "1 + ((column_number - 1) mod 12)",
        },
        "common_core": {
            "algebraic_rows_checked": 97579,
            "row_failure_count": len(row_failures),
            "row_failure_sample": row_failures[:20],
            "variables_checked": 78084,
            "bound_or_integrality_failure_count": len(variable_failures),
            "bound_or_integrality_failure_sample": variable_failures[:20],
            "objective_failure_count": len(objective_failures),
            "exact_under_mapping": not row_failures and not variable_failures and not objective_failures,
        },
        "nj2_extension": added,
        "interpretation": {
            "exact": "nj2 is nj1's anonymous algebraic core plus the audited q/root symmetry rows",
            "inference": (
                "The extra system is a root-index symmetry breaker.  Projection equivalence of complete "
                "district assignments additionally uses the connectivity fact that a connected selected "
                "district can re-root its flow at its minimum-index selected unit; that re-rooting theorem "
                "is not claimed as an independently machine-checked certificate here."
            ),
            "solution_status": (
                "This projection audit alone makes no feasibility claim.  The repository's separately "
                "constructed 529.9611973238 solutions are checked against each full original MPS."
            ),
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({
        "common_core_exact": result["common_core"]["exact_under_mapping"],
        "common_rows": result["common_core"]["algebraic_rows_checked"],
        "added_template_failures": added["template_failure_count"],
    }, indent=2))


if __name__ == "__main__":
    main()
