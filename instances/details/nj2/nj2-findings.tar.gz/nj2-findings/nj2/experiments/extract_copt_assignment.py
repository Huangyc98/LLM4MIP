#!/usr/bin/env python3
"""Extract and exactly audit the 595-by-12 district assignment from a COPT .sol."""

from __future__ import annotations

import argparse
import hashlib
import json
from decimal import Decimal
from pathlib import Path


NODES = 595
DISTRICTS = 12
ASSIGNMENT_BASE = 70_945


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_solution(path: Path) -> tuple[str | None, dict[str, Decimal]]:
    objective = None
    values: dict[str, Decimal] = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        tokens = raw.split()
        if raw.startswith("# Objective value") and tokens:
            objective = tokens[-1]
        if len(tokens) < 2 or tokens[0].startswith(("#", "=")):
            continue
        try:
            values[tokens[0]] = Decimal(tokens[1])
        except Exception as exc:
            raise ValueError(f"invalid solution line: {raw!r}") from exc
    return objective, values


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("solution", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--integrality-tolerance", type=Decimal, default=Decimal("1e-9"))
    args = parser.parse_args()

    reported_objective, values = read_solution(args.solution)
    assignment = []
    selected_names = []
    rounded_value_count = 0
    maximum_rounding_distance = Decimal(0)
    for node in range(NODES):
        raw_row = [
            values.get(f"C{ASSIGNMENT_BASE + DISTRICTS * node + district:04d}", Decimal(0))
            for district in range(DISTRICTS)
        ]
        row = []
        for value in raw_row:
            nearest = Decimal(0) if abs(value) <= abs(value - 1) else Decimal(1)
            distance = abs(value - nearest)
            if distance > args.integrality_tolerance:
                raise ValueError(
                    f"node {node} value {value} is {distance} from the nearest binary value"
                )
            rounded_value_count += distance != 0
            maximum_rounding_distance = max(maximum_rounding_distance, distance)
            row.append(nearest)
        if sum(row) != 1:
            raise ValueError(f"node {node} assignment row sums to {sum(row)}, not 1")
        district = row.index(Decimal(1))
        assignment.append(district)
        selected_names.append(f"C{ASSIGNMENT_BASE + DISTRICTS * node + district:04d}")

    report = {
        "schema": "nj2-copt-assignment-extraction-v1",
        "evidence_level": "exact extraction of integer assignment only; full original-MPS feasibility requires the separate deterministic lift/check",
        "source_solution": args.solution.as_posix(),
        "source_solution_sha256": sha256(args.solution),
        "reported_copt_objective": reported_objective,
        "solution_entries": len(values),
        "assignment_rows_checked": NODES,
        "assignment_columns_checked": NODES * DISTRICTS,
        "integrality_tolerance_used_for_extraction": str(args.integrality_tolerance),
        "values_rounded_to_binary": rounded_value_count,
        "maximum_rounding_distance": str(maximum_rounding_distance),
        "exactly_one_binary_value_per_node_after_rounding": True,
        "selected_assignment_variables": selected_names,
        "assignment_zero_based_district": assignment,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(report, indent=2) + "\n", encoding="utf-8", newline="\n"
    )
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
