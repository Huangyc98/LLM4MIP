#!/usr/bin/env python3
"""Parse milo-v13-4-3d-4-0 and exactly check a sparse solution."""

from __future__ import annotations

import argparse
import gzip
import itertools
import re
from collections import Counter, defaultdict
from dataclasses import dataclass
from decimal import Decimal
from pathlib import Path
from typing import TextIO


INF = Decimal("Infinity")


def number(text: str) -> Decimal:
    return Decimal(text.replace("D", "E").replace("d", "e"))


def open_text(path: Path) -> TextIO:
    if path.suffix.lower() == ".gz":
        return gzip.open(path, "rt", encoding="latin-1")
    return path.open(encoding="latin-1")


def variable_family(name: str) -> str:
    match = re.match(r"([A-Za-z]+)", name)
    return match.group(1) if match else name


def row_family(name: str) -> str:
    return re.sub(r"_?\d+$", "", name)


@dataclass
class Model:
    name: str
    objective_row: str
    row_types: dict[str, str]
    rhs: dict[str, Decimal]
    columns: dict[str, dict[str, Decimal]]
    integer_variables: set[str]
    lower: dict[str, Decimal]
    upper: dict[str, Decimal]
    bound_types: Counter[str]


def parse_mps(path: Path) -> Model:
    section = ""
    name = path.stem
    objective_row = ""
    row_types: dict[str, str] = {}
    rhs: dict[str, Decimal] = defaultdict(Decimal)
    columns: dict[str, dict[str, Decimal]] = defaultdict(lambda: defaultdict(Decimal))
    integer_variables: set[str] = set()
    bounds: list[list[str]] = []
    integer_mode = False

    with open_text(path) as handle:
        for raw in handle:
            tokens = raw.split()
            if not tokens or tokens[0].startswith("*"):
                continue
            if tokens[0] in {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"}:
                section = tokens[0]
                if section == "NAME" and len(tokens) > 1:
                    name = tokens[1]
                continue
            if section == "ROWS":
                kind, row = tokens[:2]
                row_types[row] = kind
                if kind == "N" and not objective_row:
                    objective_row = row
            elif section == "COLUMNS":
                if "'MARKER'" in tokens:
                    if "'INTORG'" in tokens:
                        integer_mode = True
                    elif "'INTEND'" in tokens:
                        integer_mode = False
                    continue
                var = tokens[0]
                if integer_mode:
                    integer_variables.add(var)
                for row, value in zip(tokens[1::2], tokens[2::2]):
                    columns[var][row] += number(value)
            elif section == "RHS":
                for row, value in zip(tokens[1::2], tokens[2::2]):
                    rhs[row] += number(value)
            elif section == "BOUNDS":
                bounds.append(tokens)

    lower = {var: Decimal(0) for var in columns}
    upper = {var: INF for var in columns}
    bound_types: Counter[str] = Counter()
    for tokens in bounds:
        kind, var = tokens[0], tokens[2]
        value = number(tokens[3]) if len(tokens) > 3 else Decimal(0)
        bound_types[kind] += 1
        if kind == "FR":
            lower[var], upper[var] = -INF, INF
        elif kind == "UP":
            upper[var] = value
        elif kind == "LO":
            lower[var] = value
        elif kind == "FX":
            lower[var] = upper[var] = value
        elif kind == "BV":
            lower[var], upper[var] = Decimal(0), Decimal(1)
            integer_variables.add(var)
        elif kind == "LI":
            lower[var] = value
            integer_variables.add(var)
        elif kind == "UI":
            upper[var] = value
            integer_variables.add(var)
        elif kind == "MI":
            lower[var] = -INF
        elif kind == "PL":
            upper[var] = INF
        else:
            raise ValueError(f"unsupported bound type {kind}")
    if not objective_row:
        raise ValueError("no objective row found")
    return Model(
        name,
        objective_row,
        row_types,
        dict(rhs),
        {var: dict(entries) for var, entries in columns.items()},
        integer_variables,
        lower,
        upper,
        bound_types,
    )


def row_number(row: str) -> tuple[int, str]:
    match = re.search(r"(\d+)$", row)
    return (int(match.group(1)), row) if match else (10**18, row)


def summarize(model: Model) -> None:
    constraints = [row for row, kind in model.row_types.items() if kind != "N"]
    row_entries: dict[str, list[tuple[str, Decimal]]] = defaultdict(list)
    matrix_nonzeros = 0
    objective_nonzeros = 0
    for var, entries in model.columns.items():
        for row, coefficient in entries.items():
            if row == model.objective_row:
                objective_nonzeros += coefficient != 0
            elif row in model.row_types:
                row_entries[row].append((var, coefficient))
                matrix_nonzeros += coefficient != 0

    families = Counter(variable_family(var) for var in model.columns)
    integer_families = Counter(variable_family(var) for var in model.integer_variables)
    objective_families = Counter(
        variable_family(var)
        for var, entries in model.columns.items()
        if entries.get(model.objective_row, Decimal(0)) != 0
    )
    row_sizes = Counter(len(row_entries[row]) for row in constraints)

    print(f"model={model.name}")
    print(f"variables={len(model.columns)} families={dict(sorted(families.items()))}")
    print(f"integer_variables={len(model.integer_variables)} families={dict(integer_families)}")
    print(f"constraints={len(constraints)} row_types={Counter(model.row_types[r] for r in constraints)}")
    print(f"matrix_nonzeros={matrix_nonzeros} objective_nonzeros={objective_nonzeros}")
    print(f"objective_families={dict(objective_families)}")
    print(f"bounds={dict(model.bound_types)}")
    print(f"row_sizes={dict(sorted(row_sizes.items()))}")

    signatures: Counter[tuple[object, ...]] = Counter()
    family_signatures: dict[str, Counter[tuple[object, ...]]] = defaultdict(Counter)
    for row in constraints:
        prefix_counts = tuple(sorted(Counter(variable_family(var) for var, _ in row_entries[row]).items()))
        signature = (
            model.row_types[row],
            len(row_entries[row]),
            prefix_counts,
            "zero_rhs" if model.rhs.get(row, Decimal(0)) == 0 else "nonzero_rhs",
        )
        signatures[signature] += 1
        family_signatures[row_family(row)][signature] += 1

    print(f"row_name_families={dict(sorted(Counter(row_family(r) for r in constraints).items()))}")
    print("row_signature_counts:")
    for signature, count in signatures.most_common():
        print(f"  count={count} signature={signature}")
    print("row_family_signatures:")
    for family in sorted(family_signatures):
        rendered = "; ".join(
            f"{count} x {signature}" for signature, count in family_signatures[family].most_common()
        )
        print(f"  {family}: {rendered}")


def read_solution(path: Path) -> tuple[dict[str, Decimal], Decimal | None]:
    values: dict[str, Decimal] = {}
    claimed_objective: Decimal | None = None
    with open_text(path) as handle:
        for raw in handle:
            tokens = raw.split()
            if not tokens:
                continue
            if tokens[0] == "=obj=" and len(tokens) >= 2:
                claimed_objective = number(tokens[1])
            elif tokens[0].startswith("#"):
                continue
            elif len(tokens) >= 2:
                values[tokens[0]] = number(tokens[1])
    return values, claimed_objective


def check_solution(model: Model, solution_path: Path) -> None:
    sparse_values, claimed_objective = read_solution(solution_path)
    values = {var: sparse_values.get(var, Decimal(0)) for var in model.columns}
    unknown_variables = sorted(set(sparse_values) - set(model.columns))
    objective = sum(
        model.columns[var].get(model.objective_row, Decimal(0)) * value
        for var, value in values.items()
    )

    activities: dict[str, Decimal] = defaultdict(Decimal)
    for var, value in values.items():
        for row, coefficient in model.columns[var].items():
            if row != model.objective_row:
                activities[row] += coefficient * value

    row_violations: list[tuple[str, Decimal]] = []
    for row, kind in model.row_types.items():
        if kind == "N":
            continue
        activity = activities[row]
        rhs = model.rhs.get(row, Decimal(0))
        if kind == "E":
            violation = abs(activity - rhs)
        elif kind == "L":
            violation = max(Decimal(0), activity - rhs)
        elif kind == "G":
            violation = max(Decimal(0), rhs - activity)
        else:
            raise ValueError(f"unsupported row type {kind}")
        if violation:
            row_violations.append((row, violation))

    bound_violations = [
        var
        for var, value in values.items()
        if value < model.lower[var] or value > model.upper[var]
    ]
    integrality_violations = [
        var for var in model.integer_variables if values[var] != values[var].to_integral_value()
    ]
    z_values = {var: value for var, value in values.items() if variable_family(var) == "z"}
    z_one = sum(value == 1 for value in z_values.values())

    member_coefficients = {
        member: model.columns[f"x_{member}"][model.objective_row] for member in range(80)
    }
    coefficient_counts = Counter(member_coefficients.values())
    thick_counts = Counter(
        member_coefficients[member]
        for member in range(80)
        if values[f"z_{member}_1"] == 1
    )
    base_objective = Decimal(2) * sum(member_coefficients.values())
    representable_below: tuple[Decimal, tuple[int, ...]] | None = None
    coefficients = sorted(coefficient_counts)
    for counts in itertools.product(*(range(coefficient_counts[coefficient] + 1) for coefficient in coefficients)):
        candidate = base_objective + Decimal(98) * sum(
            count * coefficient for count, coefficient in zip(counts, coefficients)
        )
        if candidate < objective and (representable_below is None or candidate > representable_below[0]):
            representable_below = candidate, counts

    print(f"solution={solution_path}")
    print(f"claimed_objective={claimed_objective}")
    print(f"computed_objective={objective}")
    print(f"objective_difference={None if claimed_objective is None else objective - claimed_objective}")
    print(f"sparse_entries={len(sparse_values)} unknown_variables={unknown_variables}")
    tolerance = Decimal("1e-9")
    solver_tolerance = Decimal("1e-6")
    violations_above_tolerance = [(row, value) for row, value in row_violations if value > tolerance]
    violations_above_solver_tolerance = [
        (row, value) for row, value in row_violations if value > solver_tolerance
    ]
    print(
        f"nonzero_row_residuals={len(row_violations)} "
        f"max={max((v for _, v in row_violations), default=0)}"
    )
    print(f"row_violations_above_1e-9={len(violations_above_tolerance)}")
    print(f"row_violations_above_1e-6={len(violations_above_solver_tolerance)}")
    print(f"bound_violations={len(bound_violations)}")
    print(f"integrality_violations={len(integrality_violations)}")
    print(f"z_variables={len(z_values)} z_equal_one={z_one}")
    print(f"objective_coefficient_counts={dict(coefficient_counts)}")
    print(f"incumbent_thick_choice_counts={dict(thick_counts)}")
    if representable_below is not None:
        print(f"nearest_representable_lower_objective={representable_below[0]}")
        print(f"nearest_lower_counts={representable_below[1]}")
        print(f"representable_objective_gap={objective - representable_below[0]}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mps", type=Path)
    parser.add_argument("--solution", type=Path)
    args = parser.parse_args()
    model = parse_mps(args.mps)
    summarize(model)
    if args.solution:
        check_solution(model, args.solution)


if __name__ == "__main__":
    main()
