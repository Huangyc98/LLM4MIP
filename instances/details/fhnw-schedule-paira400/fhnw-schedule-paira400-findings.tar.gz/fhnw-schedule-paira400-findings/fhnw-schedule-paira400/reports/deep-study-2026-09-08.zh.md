# `fhnw-schedule-paira400` 独立最优性验证（2026-09-08）

## 结论

本轮得到并独立验证了一个 **solver-verified global optimum**：

```text
最优目标值       -36.27696674236886
选择作业数        60
master primal     -36.27696674236886
master dual       -36.27696674236886
gap                0
```

相对于此前已通过原 MPS 审计的中间严格可行值
`-36.276622209826776`，改善量为 `0.000344532542084`。相对于 MIPLIB
公布的 Pair-A 容差解目标 `-35.54680465280395`，数值改善量为
`0.73016208956491`；该公开解本身含容差整数值，其直接舍入选择曾被证明
不可排程，所以对外报告时应明确区分“公开容差目标”和“严格可行基准”。
另一个数值 `-35.45840605462827` 是 Pair-B400 public variables 的重算值，
并非 Pair-A400 的严格基准。

这不是 DRAT/LRAT 形式化证书。准确说法是：从原始 MPS 逐行恢复出的一个
全局有效 0-1 松弛被 Gurobi 两次独立求到 primal=dual，同时相同目标的解被
构造回两个官方 formulation，并通过高精度原 MPS 全行审计。

## 1. 原模型结构审计

### Pair A

- 80,600 个变量：400 个选择二元变量、400 个连续开始时间变量、
  `C(400,2)=79,800` 个先后顺序二元变量；
- 160,000 条约束、479,504 个非零元；
- 159,600 条两两不重叠约束全部逐行核对；
- 96 条单变量等式把相应选择变量固定为 0；
- 其余 304 条作业约束给出“被选择时的最晚开始时间”。

### Pair B

- 160,400 个变量、399,096 条约束、1,197,096 个非零元；
- 每个无序作业对有两个辅助二元变量和五条约束；
- 399,000 条 pair 行全部逐行核对；
- 固定为 0 的 96 个作业与 Pair A 完全一致。

两个模型中 304 个可选作业的目标系数、release time、processing time 和
latest start 一致，最大处理时间恢复差为 `2.84e-14`，来自大 M 系数的浮点
消去。完成截止期按下式计算：

```text
d_i = latest_start_i + processing_time_i.
```

304 个可选作业的 `d_i` 均为 1（Pair A 的 MPS 浮点恢复范围为
`[0.999999999999994, 1.0000000000000568]`）。

## 2. 后缀容量松弛

令安全共同截止期

```text
D_safe = 1.000000000001057,
```

它比 Pair A 中恢复出的最大完成截止期大至少 `1.00009e-12`，从而避免把
MPS 的约 `1e-14` 舍入误差误当成数学强化。

对于每个 release threshold `t`，任何原问题可行解都必须满足：

```text
sum_{i: r_i >= t} p_i z_i <= D_safe - t.
```

原因是这些作业都不能在 `t` 前处理，又必须不晚于 `D_safe` 完成；单机在
`[t,D_safe]` 中的总容量只有 `D_safe-t`。因此这些约束是原问题的全局有效
必要条件，使用它们组成的选择模型是原 MIP 的松弛。对于最小化问题，松弛
最优值是合法全局下界。

独立构造的 master 包含：

- 400 个二元选择变量；
- 96 条原始固定零约束；
- 304 条完整 release-suffix 容量约束；
- 与原始 Pair A 完全相同的目标函数。

逐条检查了 master 的 400 个变量、400 条约束、46,456 个非零元；没有发现
变量映射、系数、支持集、方向或右端项错误。

## 3. 两次独立 master 求解

第一次运行（2 threads，Seed 29，NumericFocus 2）：

```text
status   OPTIMAL
primal   -36.27696674236886
dual     -36.27696674236886
gap      0
nodes    61
runtime  0.130 s
```

保存 proof MPS 后重新读取，并改变为 1 thread、Seed 73、NumericFocus 3、
MIPFocus 3，得到：

```text
status   OPTIMAL
primal   -36.27696674236886
dual     -36.27696674236886
gap      0
nodes    35
runtime  0.154 s
```

此外，从 Pair B 直接生成 suffix master，并把安全共同截止期放宽
`1e-12`，逐条复核其 400 条约束；使用 Seed 101/149、不同线程重跑，也得到
同一个零 gap 最优值。先前恰用 `D=1` 的 Pair B 数值重跑因 Decimal 恢复出
`1.0000000000000002` 的边界值，只保留为数值交叉检查，不再作为证明依据。

## 4. 从选择集合构造严格排程

master 选择 60 个作业。将这些作业按 release time 非降序排列，并依次采用
最早可行开始时间：

```text
s_k = max(r_k, s_{k-1}+p_{k-1}).
```

最后一个被选择作业在 `0.9993391698566962` 完成，严格早于所有完成截止期。

### 回代 Pair A

保留这 60 个作业的顺序，再把未选择作业依次附加在其后，完整 400-job
序列的 makespan 为 `99.21017075197013 < 400`。由完整顺序设置 79,800 个
Pair-A order binaries。用 60 位 Decimal 累加重新检查原始 160,000 行：

```text
目标值                 -36.27696674236886495400
最大变量界违反           0
最大整数性违反           0
最大行违反               3.406e-14
超过 1e-9 的行违反       0
```

### 回代 Pair B

对每个作业对重新构造 joint-selection 和 direction 二元变量，并将未选择作业
开始时间放在各自原始 release time。重新检查原始 399,096 行：

```text
目标值                 -36.27696674236886495400
最大变量界违反           0
最大整数性违反           0
最大行违反               3.0e-16
超过 1e-9 的行违反       0
```

因为 master 的全局下界与原模型严格可行解的目标相等，Pair A 的全局最优性
由此闭合；Pair B 的独立 suffix master 和原 MPS 回代也给出同一结论。

## 5. 对旧 750 条 cuts 的纠错

早期 `method02` 实验把 start variable 的上界误称为 completion deadline，
漏掉了 processing time：

```text
错误：d_i = UB(start_i)
正确：d_i = UB(start_i) + p_i
```

因此从该文件转移的 750 条 energetic cuts 不能用于证明最优。已经找到一个
可复核反例：旧 `energy_lp_44` 对作业 `{108,335}` 给出

```text
错误 cut LHS  0.9950234323134086
RHS            0.9948513622720969
表面违反       0.0001720700413117
```

但这两个作业按 `108 -> 335` 排程在两个原始 MPS 中都严格可行。按正确完成
截止期重算，同一区间的必要处理量只有 `0.9880390761480027 <= RHS`。因此旧
proof model 的 dual、zero gap 和 `OPTIMAL` 标签全部撤销；它产生的
`-36.276622209826776` 解因独立通过原 MPS 检查仍可保留为中间 primal。

最终 `-36.27696674236886` 的证明完全不依赖这 750 条错误 cuts。

## 6. 关键证据

- [`../artifacts/independent-cross-audit.json`](../artifacts/independent-cross-audit.json)：完整结构、映射、原 MPS 和证明链审计；
- [`../artifacts/safe-suffix-master-proof.json`](../artifacts/safe-suffix-master-proof.json)：Pair A 安全 suffix master 的两次求解；
- [`../../fhnw-schedule-pairb400/artifacts/`](../../fhnw-schedule-pairb400/artifacts/)：带 `1e-12`
  deadline 安全余量的 Pair B master、日志与逐条语义审计；
- [`../artifacts/paira400-safe-suffix-master.mps.gz`](../artifacts/paira400-safe-suffix-master.mps.gz)：可重跑的 Pair A 松弛模型；
- [`../solutions/global-optimal.sol`](../solutions/global-optimal.sol)：Pair A 严格最优解；
- [`../../fhnw-schedule-pairb400/solutions/global-optimal.sol`](../../fhnw-schedule-pairb400/solutions/global-optimal.sol)：Pair B 交叉验证解；
- [`../artifacts/invalid-old-cut-counterexample.json`](../artifacts/invalid-old-cut-counterexample.json)：旧 energetic cut 的原模型可行反例。
