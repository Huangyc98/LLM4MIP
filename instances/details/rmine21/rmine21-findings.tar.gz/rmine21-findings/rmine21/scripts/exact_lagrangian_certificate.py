#!/usr/bin/env python3
"""Exact Lagrangian lower-bound certificates for cumulative rmine MPS files.

The only relaxed rows are the non-precedence rows (22 ``tcap`` rows in
rmine11).  For a supplied nonnegative multiplier vector, the remaining binary
problem is a minimum-weight closure problem.  It is solved with an integer
max-flow/min-cut computation after all MPS decimals and multipliers have been
converted to exact fractions.

The generated certificate contains a feasible max flow and a cut of the same
capacity.  ``verify`` checks that witness without running a max-flow algorithm.
Thus the reported rational number is reproducible independently of floating
point tolerances.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
import sys
from collections import defaultdict, deque
from dataclasses import dataclass
from decimal import Decimal
from fractions import Fraction
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, MutableMapping, Sequence, Tuple


SOURCE = "@source"
SINK = "@sink"


def number(token: str) -> Fraction:
    """Parse an MPS/JSON decimal exactly (including scientific notation)."""
    if "/" in token:
        numerator, denominator = token.split("/", 1)
        return Fraction(int(numerator), int(denominator))
    return Fraction(Decimal(token.replace("D", "E").replace("d", "e")))


def frac_text(value: Fraction) -> str:
    return str(value.numerator) if value.denominator == 1 else f"{value.numerator}/{value.denominator}"


def open_mps(path: Path):
    return gzip.open(path, "rt", encoding="ascii") if path.suffix.lower() == ".gz" else path.open("rt", encoding="ascii")


@dataclass
class ClosureModel:
    source_path: Path
    sha256: str
    name: str
    variables: List[str]
    objective: Dict[str, Fraction]
    arcs: List[Tuple[str, str]]
    side_rows: List[str]
    side_rhs: Dict[str, Fraction]
    side_columns: Dict[str, Dict[str, Fraction]]


def parse_mps(path_like: str | Path) -> ClosureModel:
    """Parse the exact subset of MPS used by rmine and validate its structure."""
    path = Path(path_like).resolve()
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    row_types: Dict[str, str] = {}
    row_terms: MutableMapping[str, MutableMapping[str, Fraction]] = defaultdict(lambda: defaultdict(Fraction))
    rhs: MutableMapping[str, Fraction] = defaultdict(Fraction)
    variables: List[str] = []
    seen_variables = set()
    integer_variables = set()
    lower: MutableMapping[str, Fraction] = defaultdict(Fraction)
    upper: Dict[str, Fraction] = {}
    objective_row = None
    model_name = path.stem
    section = None
    integer_mode = False
    objective_sense = "MIN"

    headers = {"ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA", "OBJSENSE"}
    with open_mps(path) as stream:
        for raw in stream:
            line = raw.strip()
            if not line or line.startswith("*"):
                continue
            fields = line.split()
            head = fields[0].upper()
            if head == "NAME":
                if len(fields) > 1:
                    model_name = fields[1]
                section = "NAME"
                continue
            if head in headers and (len(fields) == 1 or head == "ENDATA"):
                section = head
                if head == "ENDATA":
                    break
                continue
            if section == "OBJSENSE":
                objective_sense = fields[0].upper()
                continue
            if section == "ROWS":
                if len(fields) != 2:
                    raise ValueError(f"unsupported ROWS record: {line}")
                kind, row = fields
                row_types[row] = kind.upper()
                if kind.upper() == "N" and objective_row is None:
                    objective_row = row
                continue
            if section == "COLUMNS":
                if len(fields) >= 3 and fields[1].strip("'\"").upper() == "MARKER":
                    marker = fields[2].strip("'\"").upper()
                    if marker == "INTORG":
                        integer_mode = True
                    elif marker == "INTEND":
                        integer_mode = False
                    continue
                if len(fields) not in (3, 5):
                    raise ValueError(f"unsupported COLUMNS record: {line}")
                var = fields[0]
                if var in (SOURCE, SINK):
                    raise ValueError(f"reserved variable name: {var}")
                if var not in seen_variables:
                    variables.append(var)
                    seen_variables.add(var)
                if integer_mode:
                    integer_variables.add(var)
                for pos in range(1, len(fields), 2):
                    row, value = fields[pos], number(fields[pos + 1])
                    row_terms[row][var] += value
                continue
            if section == "RHS":
                if len(fields) not in (3, 5):
                    raise ValueError(f"unsupported RHS record: {line}")
                for pos in range(1, len(fields), 2):
                    rhs[fields[pos]] += number(fields[pos + 1])
                continue
            if section == "RANGES":
                raise ValueError("RANGES are not supported (and are absent from rmine11)")
            if section == "BOUNDS":
                if len(fields) not in (3, 4):
                    raise ValueError(f"unsupported BOUNDS record: {line}")
                kind, var = fields[0].upper(), fields[2]
                value = number(fields[3]) if len(fields) == 4 else Fraction(0)
                if kind == "UP":
                    upper[var] = value
                elif kind == "LO":
                    lower[var] = value
                elif kind == "BV":
                    lower[var], upper[var] = Fraction(0), Fraction(1)
                    integer_variables.add(var)
                elif kind == "FX":
                    lower[var] = upper[var] = value
                else:
                    raise ValueError(f"unsupported bound type {kind}; expected a binary rmine model")

    if objective_sense not in ("MIN", "MINIMIZE"):
        raise ValueError(f"expected a minimization MPS, got {objective_sense}")
    if objective_row is None:
        raise ValueError("no objective row found")
    if set(variables) != integer_variables:
        missing = sorted(set(variables) - integer_variables)[:5]
        raise ValueError(f"not every column is marked integer; examples: {missing}")
    bad_bounds = [v for v in variables if lower[v] != 0 or upper.get(v) != 1]
    if bad_bounds:
        raise ValueError(f"expected 0/1 bounds; bad examples: {bad_bounds[:5]}")

    objective = {v: a for v, a in row_terms.get(objective_row, {}).items() if a}
    arcs = set()
    side_rows: List[str] = []
    side_columns: Dict[str, Dict[str, Fraction]] = {}
    for row, kind in row_types.items():
        if kind == "N":
            continue
        terms = {v: a for v, a in row_terms.get(row, {}).items() if a}
        values = sorted(terms.values())
        is_precedence = kind == "L" and rhs[row] == 0 and len(terms) == 2 and values == [Fraction(-1), Fraction(1)]
        if is_precedence:
            tail = next(v for v, a in terms.items() if a == 1)
            head_var = next(v for v, a in terms.items() if a == -1)
            arcs.add((tail, head_var))  # x_tail <= x_head_var
        else:
            if kind != "L":
                raise ValueError(f"side row {row} has sense {kind}; only <= rows are supported")
            side_rows.append(row)
            side_columns[row] = terms

    return ClosureModel(
        source_path=path,
        sha256=digest,
        name=model_name,
        variables=variables,
        objective=objective,
        arcs=sorted(arcs),
        side_rows=side_rows,
        side_rhs={r: rhs[r] for r in side_rows},
        side_columns=side_columns,
    )


class Edge:
    __slots__ = ("to", "rev", "cap", "original")

    def __init__(self, to: int, rev: int, cap: int, original: int):
        self.to, self.rev, self.cap, self.original = to, rev, cap, original


class Dinic:
    def __init__(self, n: int):
        self.graph: List[List[Edge]] = [[] for _ in range(n)]
        self.forward: List[Tuple[int, int, Edge]] = []

    def add(self, u: int, v: int, cap: int) -> None:
        if cap < 0:
            raise ValueError("negative network capacity")
        fwd = Edge(v, len(self.graph[v]), cap, cap)
        rev = Edge(u, len(self.graph[u]), 0, 0)
        self.graph[u].append(fwd)
        self.graph[v].append(rev)
        self.forward.append((u, v, fwd))

    def maxflow(self, source: int, sink: int) -> int:
        total = 0
        n = len(self.graph)
        sys.setrecursionlimit(max(sys.getrecursionlimit(), n * 3))
        while True:
            level = [-1] * n
            level[source] = 0
            queue = deque([source])
            while queue:
                u = queue.popleft()
                for edge in self.graph[u]:
                    if edge.cap and level[edge.to] < 0:
                        level[edge.to] = level[u] + 1
                        queue.append(edge.to)
            if level[sink] < 0:
                return total
            cursor = [0] * n

            def send(u: int, amount: int) -> int:
                if u == sink:
                    return amount
                while cursor[u] < len(self.graph[u]):
                    edge = self.graph[u][cursor[u]]
                    if edge.cap and level[edge.to] == level[u] + 1:
                        pushed = send(edge.to, min(amount, edge.cap))
                        if pushed:
                            edge.cap -= pushed
                            self.graph[edge.to][edge.rev].cap += pushed
                            return pushed
                    cursor[u] += 1
                return 0

            while True:
                pushed = send(source, 10**100)
                if not pushed:
                    break
                total += pushed

    def reachable(self, source: int) -> set[int]:
        seen = {source}
        queue = deque([source])
        while queue:
            u = queue.popleft()
            for edge in self.graph[u]:
                if edge.cap and edge.to not in seen:
                    seen.add(edge.to)
                    queue.append(edge.to)
        return seen


@dataclass
class NetworkData:
    names: List[str]
    capacities: Dict[Tuple[str, str], int]
    modified_costs: Dict[str, Fraction]
    scale: int
    constant_scaled: int
    positive_profit_scaled: int
    infinity: int


def make_network_data(model: ClosureModel, multipliers: Mapping[str, Fraction]) -> NetworkData:
    unknown = set(multipliers) - set(model.side_rows)
    if unknown:
        raise ValueError(f"unknown multiplier rows: {sorted(unknown)[:5]}")
    if any(value < 0 for value in multipliers.values()):
        raise ValueError("all <=-row multipliers must be nonnegative")

    modified = {v: model.objective.get(v, Fraction(0)) for v in model.variables}
    constant = Fraction(0)
    for row in model.side_rows:
        lam = multipliers.get(row, Fraction(0))
        constant -= lam * model.side_rhs[row]
        if lam:
            for var, coefficient in model.side_columns[row].items():
                modified[var] += lam * coefficient

    scale = constant.denominator
    for value in modified.values():
        scale = math.lcm(scale, value.denominator)
    costs = {v: int(value * scale) for v, value in modified.items()}
    constant_scaled = int(constant * scale)
    positive_profit = sum(-cost for cost in costs.values() if cost < 0)
    finite_sum = sum(abs(cost) for cost in costs.values())
    infinity = finite_sum + 1
    capacities: Dict[Tuple[str, str], int] = {}
    for var, cost in costs.items():
        if cost < 0:  # profit -cost > 0
            capacities[(SOURCE, var)] = -cost
        elif cost > 0:
            capacities[(var, SINK)] = cost
    for tail, head in model.arcs:
        capacities[(tail, head)] = infinity
    return NetworkData(model.variables, capacities, modified, scale, constant_scaled, positive_profit, infinity)


def solve_network(data: NetworkData):
    index = {name: i for i, name in enumerate(data.names)}
    source, sink = len(index), len(index) + 1
    label_to_index = {**index, SOURCE: source, SINK: sink}
    index_to_label = {value: key for key, value in label_to_index.items()}
    network = Dinic(len(index) + 2)
    for (u, v), capacity in data.capacities.items():
        network.add(label_to_index[u], label_to_index[v], capacity)
    value = network.maxflow(source, sink)
    reachable = network.reachable(source)
    selected = [name for name in data.names if index[name] in reachable]
    flow = []
    for u, v, edge in network.forward:
        amount = edge.original - edge.cap
        if amount:
            flow.append([index_to_label[u], index_to_label[v], str(amount)])
    cut = sum(
        edge.original
        for u, _v, edge in network.forward
        if u in reachable and edge.to not in reachable
    )
    if cut != value:
        raise AssertionError("internal max-flow/min-cut mismatch")
    return value, selected, flow


def load_multipliers(path: str | Path, model: ClosureModel) -> Dict[str, Fraction]:
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    if "multipliers" in raw:
        raw = raw["multipliers"]
    result = {row: number(str(value)) for row, value in raw.items()}
    for row in model.side_rows:
        result.setdefault(row, Fraction(0))
    return result


def write_json(path: Path, payload) -> None:
    if path.suffix.lower() == ".gz":
        with gzip.open(path, "wt", encoding="utf-8") as stream:
            json.dump(payload, stream, ensure_ascii=False, separators=(",", ":"))
    else:
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def read_json(path: Path):
    if path.suffix.lower() == ".gz":
        with gzip.open(path, "rt", encoding="utf-8") as stream:
            return json.load(stream)
    return json.loads(path.read_text(encoding="utf-8"))


def build_certificate(model: ClosureModel, multipliers: Mapping[str, Fraction], include_flow: bool = True):
    data = make_network_data(model, multipliers)
    flow_value, selected, flow = solve_network(data)
    minimum_closure_scaled = flow_value - data.positive_profit_scaled
    bound_num = data.constant_scaled + minimum_closure_scaled
    bound = Fraction(bound_num, data.scale)
    side_activity = {row: Fraction(0) for row in model.side_rows}
    selected_set = set(selected)
    for row in model.side_rows:
        side_activity[row] = sum((a for v, a in model.side_columns[row].items() if v in selected_set), Fraction(0))
    certificate = {
        "format": "rmine-exact-lagrangian-v1",
        "model": {
            "name": model.name,
            "sha256": model.sha256,
            "variables": len(model.variables),
            "precedence_arcs": len(model.arcs),
            "side_rows": len(model.side_rows),
        },
        "multipliers": {row: frac_text(multipliers.get(row, Fraction(0))) for row in model.side_rows},
        "integer_scale": str(data.scale),
        "infinite_arc_capacity": str(data.infinity),
        "positive_profit_scaled": str(data.positive_profit_scaled),
        "lagrangian_constant_scaled": str(data.constant_scaled),
        "maxflow_equals_mincut_scaled": str(flow_value),
        "minimum_closure_scaled": str(minimum_closure_scaled),
        "bound_scaled_numerator": str(bound_num),
        "certified_lower_bound": frac_text(bound),
        "certified_lower_bound_decimal": format(Decimal(bound.numerator) / Decimal(bound.denominator), ".15f"),
        "selected_variables": selected,
        "side_activity_at_oracle": {row: frac_text(side_activity[row]) for row in model.side_rows},
        "supergradient_Ax_minus_b": {
            row: frac_text(side_activity[row] - model.side_rhs[row]) for row in model.side_rows
        },
    }
    if include_flow:
        certificate["positive_flow"] = flow
    else:
        certificate["positive_flow"] = None
        certificate["warning"] = "compact certificate omits the independently checkable max-flow witness"
    return certificate


def verify_certificate(model: ClosureModel, certificate) -> dict:
    if certificate.get("format") != "rmine-exact-lagrangian-v1":
        raise ValueError("unrecognized certificate format")
    if certificate["model"]["sha256"] != model.sha256:
        raise ValueError("MPS SHA-256 does not match certificate")
    if certificate.get("positive_flow") is None:
        raise ValueError("certificate has no max-flow witness; regenerate without --compact")
    multipliers = {row: number(str(value)) for row, value in certificate["multipliers"].items()}
    data = make_network_data(model, multipliers)
    if int(certificate["integer_scale"]) != data.scale:
        raise ValueError("integer scale mismatch")

    selected = set(certificate["selected_variables"])
    unknown_selected = selected - set(model.variables)
    if unknown_selected:
        raise ValueError(f"unknown selected variables: {sorted(unknown_selected)[:5]}")
    source_side = selected | {SOURCE}
    cut_value = sum(cap for (u, v), cap in data.capacities.items() if u in source_side and v not in source_side)

    aggregate: MutableMapping[Tuple[str, str], int] = defaultdict(int)
    for record in certificate["positive_flow"]:
        if len(record) != 3:
            raise ValueError("malformed flow record")
        u, v, raw_amount = record
        amount = int(raw_amount)
        if amount <= 0:
            raise ValueError("only positive flow records are allowed")
        aggregate[(u, v)] += amount
    balance: MutableMapping[str, int] = defaultdict(int)
    for edge, amount in aggregate.items():
        capacity = data.capacities.get(edge)
        if capacity is None:
            raise ValueError(f"flow uses nonexistent edge {edge}")
        if amount > capacity:
            raise ValueError(f"flow exceeds capacity on {edge}")
        u, v = edge
        balance[u] -= amount
        balance[v] += amount
    bad_conservation = {v: value for v, value in balance.items() if v not in (SOURCE, SINK) and value}
    if bad_conservation:
        raise ValueError(f"flow conservation failed; examples: {list(bad_conservation.items())[:5]}")
    flow_value = -balance[SOURCE]
    if balance[SINK] != flow_value:
        raise ValueError("source/sink flow values disagree")
    if flow_value != cut_value:
        raise ValueError("feasible-flow value and feasible-cut capacity differ")
    if flow_value != int(certificate["maxflow_equals_mincut_scaled"]):
        raise ValueError("reported max-flow value mismatch")

    closure_min = flow_value - data.positive_profit_scaled
    bound_num = data.constant_scaled + closure_min
    bound = Fraction(bound_num, data.scale)
    if str(bound_num) != certificate["bound_scaled_numerator"]:
        raise ValueError("reported bound numerator mismatch")
    if frac_text(bound) != certificate["certified_lower_bound"]:
        raise ValueError("reported rational bound mismatch")
    return {
        "verified": True,
        "sha256": model.sha256,
        "flow_equals_cut_scaled": str(flow_value),
        "certified_global_lower_bound": frac_text(bound),
        "certified_global_lower_bound_decimal": format(Decimal(bound.numerator) / Decimal(bound.denominator), ".15f"),
    }


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("make", help="solve the closure oracle and emit an exact certificate")
    make.add_argument("mps")
    make.add_argument("multipliers", help="JSON map row -> nonnegative decimal/rational")
    make.add_argument("output")
    make.add_argument("--compact", action="store_true", help="omit flow witness (not independently verifiable)")
    verify = sub.add_parser("verify", help="verify flow/cut witness without solving max flow")
    verify.add_argument("mps")
    verify.add_argument("certificate")
    inspect = sub.add_parser("inspect", help="print the detected closure/side-row structure")
    inspect.add_argument("mps")
    args = parser.parse_args(argv)

    model = parse_mps(args.mps)
    if args.command == "inspect":
        print(json.dumps({
            "name": model.name,
            "sha256": model.sha256,
            "variables": len(model.variables),
            "precedence_arcs": len(model.arcs),
            "side_rows": model.side_rows,
            "side_rhs": {r: frac_text(model.side_rhs[r]) for r in model.side_rows},
        }, indent=2))
        return 0
    if args.command == "make":
        multipliers = load_multipliers(args.multipliers, model)
        certificate = build_certificate(model, multipliers, include_flow=not args.compact)
        write_json(Path(args.output), certificate)
        print(json.dumps({k: certificate[k] for k in (
            "certified_lower_bound", "certified_lower_bound_decimal", "maxflow_equals_mincut_scaled"
        )}, indent=2))
        return 0
    result = verify_certificate(model, read_json(Path(args.certificate)))
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
