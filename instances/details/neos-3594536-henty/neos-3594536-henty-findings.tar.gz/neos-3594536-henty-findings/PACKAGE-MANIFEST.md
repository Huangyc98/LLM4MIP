# Package manifest: neos-3594536-henty

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 20
Excluded source files: 1

## Included files

- `README.md`
- `artifacts/result.json`
- `artifacts/signed_postman_report.json`
- `artifacts/structural-report.json`
- `artifacts/structure.json`
- `experiments/component-parity-optimal-20260907/README.md`
- `experiments/component-parity-optimal-20260907/build-report.json`
- `experiments/component-parity-optimal-20260907/copt-result.json`
- `experiments/component-parity-optimal-20260907/copt-solver.log`
- `experiments/component-parity-optimal-20260907/result.json`
- `experiments/component-parity-optimal-20260907/solver.log`
- `logs/oracle.log`
- `scripts/henty_component_parity.py`
- `scripts/henty_copt_recheck.py`
- `scripts/henty_cycle_reducer.py`
- `scripts/henty_parity_oracle.py`
- `scripts/henty_signed_postman.py`
- `solutions/neos-3594536-henty-401092.sol`
- `solutions/neos-3594536-henty-401154.sol`
- `solutions/neos-3594536-henty-public-5.sol.gz`

## Excluded files

- `input/neos-3594536-henty.mps.gz (563870 bytes; raw benchmark input; sha256 60a07357c9a195bdc23c6fc67a8aa72598df5aa699c3b480ada8013d42c3d74a)`
