# Component-balance/parity optimum run (2026-09-07)

This directory records the decisive solve of the exact Henty reduction.

## Model

The generated model has 29,306 integer variables (4,966 binary), 18,024 rows,
and 72,294 nonzeros. Its coefficients are integral: matrix coefficients are in
`{1,2}`, and the constant objective offset is 347,717. The generated `.mps`
is excluded by the repository-wide ignore rule because it is reproducible from
the original compressed MPS and `scripts/henty_component_parity.py`.

`build-report.json` records the structural counts and the exact audit of the
401,092 start. The generated reduced `.mps` and `.mst` are omitted because the
script reconstructs both from the archived original MPS and solution.

## Independent solver runs

| Solver | Parameters | Nodes | Time | Objective | Bound |
|---|---|---:|---:|---:|---:|
| Gurobi 13.0.1 on `euler4` | 32 threads, `MIPGap=0` | 64,057 | 188.34 s | 401,092 | 401,092 |
| COPT 8.0.4 on `altman` | 32 threads, `RelGap=0`, CPU only | 14,715 | 155.08 s | 401,092 | 401,092 |

The Gurobi run began from the previously audited 401,145 solution and found
nine incumbents before closing. `solver.log` and `result.json` are its raw log
and summary. `copt-solver.log` and `copt-result.json` record the independent
zero-gap COPT rerun from the final start.

The Gurobi reduced solution was reconstructed over a spanning forest. Its
published original-space copy is `../../solutions/neos-3594536-henty-401092.sol`;
the reconstruction audit in `result.json` reports no missing or extra variables
and zero bound, equality, or cover violations.

## Reproduction

From the repository root, build and solve with Gurobi:

```powershell
python .\instances\neos-3594536-henty\scripts\henty_component_parity.py `
  .\instances\neos-3594536-henty\input\neos-3594536-henty.mps.gz `
  --solution .\instances\neos-3594536-henty\solutions\neos-3594536-henty-401092.sol `
  --out henty-reproduction --seconds 600 --threads 32
```

Then run the generated `component_parity.mps` and `.mst` through COPT:

```text
python henty_copt_recheck.py component_parity.mps \
  --start component_parity.mst --out copt-recheck \
  --seconds 600 --threads 32
```

The two branch-and-bound logs are conventional floating-point MILP evidence;
they are independent corroboration, not independently replayable exact proof
traces.
