#!/usr/bin/env python3
"""Exact canonical-parity oracle for MIPLIB neos-3594536-henty.

The original pair (x,y) of free antiparallel integer variables is replaced by
binary p and free integer k:

    x = k + 1,  y = 1 - k - p.

This is exact at optimum because positive equal pair costs imply
x+y is 1 (odd) or 2 (even), hence p=2-(x+y).  The transformation removes all
9,932 duplicate cover rows and 4,966 original variables.  Gurobi is invoked
only on this derived parity model and is capped at 1,800 seconds.
"""

import argparse
import collections
import json
import math
import os
import time

import gurobipy as gp
from gurobipy import GRB

from henty_cycle_reducer import (
    as_int,
    audit_vector,
    finite_lb,
    finite_ub,
    identify_network,
    load_and_classify,
    read_solution,
    write_plain_solution,
)


def build_pairs(data, net):
    grouped = collections.defaultdict(list)
    for row, a, b in data["covers"]:
        grouped[tuple(sorted((a, b)))].append(row)

    pairs = []
    cover_var = {}
    for (u, v), rows in sorted(grouped.items()):
        if len(rows) != 2:
            raise ValueError(f"cover pair {(u, v)} occurs in {len(rows)} rows")
        if not (
            net["tails"][u] == net["heads"][v]
            and net["heads"][u] == net["tails"][v]
        ):
            raise ValueError(f"cover pair {(u, v)} is not antiparallel")
        if data["obj"][u] != data["obj"][v] or data["obj"][u] <= 0:
            raise ValueError(f"cover pair {(u, v)} lacks equal positive costs")
        if any(
            finite_lb(data["lb"][j]) or finite_ub(data["ub"][j])
            for j in (u, v)
        ):
            raise ValueError(f"cover pair {(u, v)} is not free")
        idx = len(pairs)
        pairs.append((u, v))
        cover_var[u] = (idx, 1)
        cover_var[v] = (idx, -1)
    return pairs, cover_var


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mps")
    ap.add_argument("--solution", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--seconds", type=float, default=1800.0)
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)
    started = time.time()

    original, data = load_and_classify(args.mps)
    net = identify_network(data)
    if not net["confirmed"]:
        raise ValueError("equality matrix is not directed incidence")
    pairs, cover_var = build_pairs(data, net)
    directed = [j for j in range(len(data["var_names"])) if j not in cover_var]
    for j in directed:
        if not finite_lb(data["lb"][j]) or finite_ub(data["ub"][j]):
            raise ValueError(f"directed variable {data['var_names'][j]} has bad bounds")
        as_int(data["lb"][j], f"lower bound {data['var_names'][j]}")
        if data["obj"][j] <= 0:
            raise ValueError(f"directed variable {data['var_names'][j]} has nonpositive cost")

    incumbent_sparse = read_solution(args.solution)
    incumbent = {
        name: int(incumbent_sparse.get(name, 0)) for name in data["var_names"]
    }
    incumbent_audit = audit_vector(data, incumbent)
    if not incumbent_audit["feasible"]:
        raise ValueError("supplied incumbent is not feasible")

    reduced = gp.Model("henty_exact_canonical_parity")
    q = {}
    for j in directed:
        q[j] = reduced.addVar(
            lb=0.0,
            ub=GRB.INFINITY,
            vtype=GRB.INTEGER,
            obj=data["obj"][j],
            name=f"q_{data['var_names'][j]}",
        )
    k = []
    p = []
    for i, (u, _) in enumerate(pairs):
        k.append(
            reduced.addVar(
                lb=-GRB.INFINITY,
                ub=GRB.INFINITY,
                vtype=GRB.INTEGER,
                obj=0.0,
                name=f"k_{data['var_names'][u]}",
            )
        )
        p.append(
            reduced.addVar(
                vtype=GRB.BINARY,
                obj=-data["obj"][u],
                name=f"p_{data['var_names'][u]}",
            )
        )
    reduced.update()

    constant_objective = data["objcon"]
    constant_objective += sum(
        data["obj"][j] * as_int(data["lb"][j], "directed lower bound")
        for j in directed
    )
    constant_objective += 2 * sum(data["obj"][u] for u, _ in pairs)
    reduced.ObjCon = constant_objective
    reduced.ModelSense = GRB.MINIMIZE

    # Each pair is added exactly once per conservation row, using the
    # coefficient of its selected u column.  Its v coefficient is its negative.
    for row, terms in data["eq_terms"].items():
        expr = gp.LinExpr()
        rhs = 0
        for j, a in terms:
            if j in q:
                expr.addTerms(a, q[j])
                rhs -= a * as_int(data["lb"][j], "directed lower bound")
            elif cover_var[j][1] == 1:
                i = cover_var[j][0]
                expr.addTerms(2 * a, k[i])
                expr.addTerms(a, p[i])
            else:
                # The antiparallel partner has already been represented by d.
                continue
        reduced.addConstr(expr == rhs, name=f"flow_{data['row_names'][row]}")

    # Exact incumbent mapping and warm start.
    for j in directed:
        q[j].Start = incumbent[data["var_names"][j]] - as_int(
            data["lb"][j], "directed lower bound"
        )
    start_pair_hist = collections.Counter()
    for i, (u, v) in enumerate(pairs):
        x = incumbent[data["var_names"][u]]
        y = incumbent[data["var_names"][v]]
        s = x + y
        if s not in (1, 2):
            raise ValueError(f"incumbent pair {(u, v)} is not canonical: sum {s}")
        p[i].Start = 2 - s
        k[i].Start = x - 1
        start_pair_hist[s] += 1

    reduced.update()
    reduced.write(os.path.join(args.out, "canonical_parity.mps"))
    reduced.write(os.path.join(args.out, "canonical_parity.mst"))

    seconds = min(max(float(args.seconds), 0.0), 1800.0)
    reduced.Params.TimeLimit = seconds
    reduced.Params.MIPGap = 0.0
    reduced.Params.LogFile = os.path.join(args.out, "oracle.log")
    reduced.optimize()

    result = {
        "instance": original.ModelName,
        "transformation": {
            "directed_augmentation_integer_variables": len(q),
            "free_parity_flow_integer_variables": len(k),
            "binary_parity_variables": len(p),
            "conservation_equalities": len(data["eq_terms"]),
            "cover_rows_remaining": 0,
            "objective_constant": constant_objective,
            "proof": [
                "positive equal pair costs imply every optimum has x+y in {1,2}",
                "p=2-(x+y), k=x-1 gives x=k+1 and y=1-k-p",
                "antiparallel incidence gives B_u*x+B_v*y=B_u*(2k+p)",
                "the mapping is integral and bijective between canonical original pairs and (k,p)",
            ],
        },
        "supplied_incumbent_audit": incumbent_audit,
        "supplied_pair_sum_histogram": dict(sorted(start_pair_hist.items())),
        "solver": {
            "time_limit_seconds": seconds,
            "status": int(reduced.Status),
            "runtime": float(reduced.Runtime),
            "node_count": float(reduced.NodeCount),
            "solution_count": int(reduced.SolCount),
            "objective_bound": float(reduced.ObjBound),
        },
    }

    if reduced.SolCount:
        mapped = {}
        for j in directed:
            mapped[data["var_names"][j]] = as_int(
                data["lb"][j], "directed lower bound"
            ) + as_int(q[j].X, f"q solution {j}", 1e-5)
        for i, (u, v) in enumerate(pairs):
            kval = as_int(k[i].X, f"k solution {i}", 1e-5)
            pval = as_int(p[i].X, f"p solution {i}", 1e-5)
            mapped[data["var_names"][u]] = kval + 1
            mapped[data["var_names"][v]] = 1 - kval - pval
        mapped_audit = audit_vector(data, mapped)
        result["solver"]["objective"] = float(reduced.ObjVal)
        result["mapped_solution_audit"] = mapped_audit
        path = os.path.join(args.out, "mapped_original.sol")
        write_plain_solution(path, mapped, mapped_audit["objective"])
        result["mapped_solution_path"] = path
        if not mapped_audit["feasible"]:
            raise AssertionError("derived solution did not map to original feasibility")
        if abs(mapped_audit["objective"] - reduced.ObjVal) > 1e-5:
            raise AssertionError("mapped and derived objective values differ")

    # Integer-valued original objective makes ceil(dual bound - tolerance) a
    # conservative reported integer bound.  The raw floating bound is retained.
    if math.isfinite(float(reduced.ObjBound)):
        result["solver"]["conservative_integer_lower_bound"] = int(
            math.ceil(float(reduced.ObjBound) - 1e-6)
        )
    if reduced.SolCount:
        iub = int(round(reduced.ObjVal))
        ilb = result["solver"].get("conservative_integer_lower_bound")
        result["certificate_status"] = (
            "optimal" if ilb is not None and ilb >= iub else "finite_gap"
        )
        result["integer_gap"] = None if ilb is None else max(0, iub - ilb)
    else:
        result["certificate_status"] = "lower_bound_only"

    result["elapsed_seconds"] = time.time() - started
    with open(os.path.join(args.out, "result.json"), "wt", encoding="utf-8") as f:
        json.dump(result, f, indent=2, sort_keys=True)
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
