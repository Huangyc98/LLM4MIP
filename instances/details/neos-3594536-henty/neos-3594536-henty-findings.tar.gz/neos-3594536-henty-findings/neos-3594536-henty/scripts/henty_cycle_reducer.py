#!/usr/bin/env python3
"""
Exact structural reduction for MIPLIB neos-3594536-henty.

Default behavior is read-only with respect to optimization:
  * reads the original MPS;
  * verifies all structural claims;
  * analyzes the equality/circulation and cover graphs;
  * constructs an exact integer fundamental-cycle basis;
  * writes an equality-free reduced MIP.

Optional --solve-seconds S invokes Gurobi only on the reduced oracle, with
S capped at 1800 seconds. No presolve or optimization is called on the
original model.

Outputs in --out:
  report.json
  reduced.mps
  cycle_basis.tsv
  oracle.log              if --solve-seconds > 0
  reduced.sol             if the oracle finds an incumbent
  original_candidate.sol  if the oracle finds an incumbent
  candidate_audit.json    if the oracle finds an incumbent

Optional incumbent formats accepted by --solution:
  * ordinary "variable value" .sol text;
  * Gurobi XML .sol;
  * JSON containing either {"Vars":[{"VarName":...,"X":...},...]}
    or a direct {"C0001": 2, ...} mapping.

Requires:
  Python 3, gurobipy, scipy
"""

import argparse
import collections
import gzip
import json
import math
import os
import re
import sys
import time

import gurobipy as gp
from gurobipy import GRB


INF_CUTOFF = 1e90


class DSU:
    def __init__(self, n):
        self.p = list(range(n))
        self.sz = [1] * n

    def find(self, a):
        while self.p[a] != a:
            self.p[a] = self.p[self.p[a]]
            a = self.p[a]
        return a

    def union(self, a, b):
        a, b = self.find(a), self.find(b)
        if a == b:
            return False
        if self.sz[a] < self.sz[b]:
            a, b = b, a
        self.p[b] = a
        self.sz[a] += self.sz[b]
        return True


def finite_lb(x):
    return x > -INF_CUTOFF


def finite_ub(x):
    return x < INF_CUTOFF


def as_int(x, what, tol=1e-9):
    r = int(round(float(x)))
    if abs(float(x) - r) > tol:
        raise ValueError(f"{what} is not integral: {x}")
    return r


def stats(values):
    if not values:
        return {"count": 0}
    a = sorted(values)
    n = len(a)
    return {
        "count": n,
        "min": a[0],
        "max": a[-1],
        "mean": sum(a) / n,
        "median": a[n // 2] if n % 2 else (a[n // 2 - 1] + a[n // 2]) / 2,
    }


def components_from_edges(n, edges):
    dsu = DSU(n)
    for u, v in edges:
        dsu.union(u, v)
    groups = collections.Counter(dsu.find(i) for i in range(n))
    return dsu, sorted(groups.values(), reverse=True)


def graph_analysis(n, edges):
    degree = [0] * n
    adjacency = [[] for _ in range(n)]
    loops = 0
    for eid, (u, v) in enumerate(edges):
        degree[u] += 1
        degree[v] += 1
        adjacency[u].append((v, eid))
        adjacency[v].append((u, eid))
        loops += int(u == v)

    dsu, component_sizes = components_from_edges(n, edges)
    roots_with_edges = set()
    for u, v in edges:
        roots_with_edges.add(dsu.find(u))
        roots_with_edges.add(dsu.find(v))

    color = [-1] * n
    bipartite = loops == 0
    odd_cycle_witness = None
    for s in range(n):
        if color[s] != -1 or not adjacency[s]:
            continue
        color[s] = 0
        q = collections.deque([s])
        while q and bipartite:
            u = q.popleft()
            for v, _ in adjacency[u]:
                if color[v] == -1:
                    color[v] = color[u] ^ 1
                    q.append(v)
                elif color[v] == color[u]:
                    bipartite = False
                    odd_cycle_witness = [u, v]
                    break

    active_vertices = sum(d > 0 for d in degree)
    active_components = len(roots_with_edges)
    cyclomatic = len(edges) - active_vertices + active_components

    return {
        "vertices": n,
        "edges": len(edges),
        "loops": loops,
        "active_vertices": active_vertices,
        "isolated_vertices": n - active_vertices,
        "components_including_isolates": len(component_sizes),
        "largest_component_sizes": component_sizes[:25],
        "degree_stats": stats(degree),
        "degree_histogram": {
            str(k): v for k, v in sorted(collections.Counter(degree).items())
        },
        "bipartite": bipartite,
        "odd_cycle_endpoint_witness": odd_cycle_witness,
        "cyclomatic_number_on_active_subgraph": cyclomatic,
    }


def read_solution(path):
    if path is None:
        return None
    opener = gzip.open if path.endswith(".gz") else open
    with opener(path, "rt", encoding="utf-8", errors="replace") as f:
        text = f.read()

    stripped = text.lstrip()
    if stripped.startswith("{"):
        data = json.loads(text)
        if isinstance(data, dict) and "Vars" in data:
            ans = {}
            for item in data["Vars"]:
                name = item.get("VarName", item.get("name"))
                val = item.get("X", item.get("value"))
                if name is not None and val is not None:
                    ans[name] = as_int(val, f"solution value {name}", 1e-6)
            return ans
        if isinstance(data, dict):
            ans = {}
            for k, v in data.items():
                if isinstance(v, (int, float)):
                    ans[k] = as_int(v, f"solution value {k}", 1e-6)
            return ans

    xml_matches = re.findall(
        r'<variable\s+name="([^"]+)"\s+index="[^"]+"\s+value="([^"]+)"',
        text,
    )
    if not xml_matches:
        xml_matches = re.findall(
            r'<variable\s+name="([^"]+)".*?value="([^"]+)"', text
        )
    if xml_matches:
        return {
            n: as_int(float(v), f"solution value {n}", 1e-6)
            for n, v in xml_matches
        }

    ans = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        fields = line.split()
        if len(fields) >= 2:
            try:
                ans[fields[0]] = as_int(
                    float(fields[1]), f"solution value {fields[0]}", 1e-6
                )
            except ValueError:
                pass
    if not ans:
        raise ValueError(f"Could not parse any variable values from {path}")
    return ans


def audit_vector(model_data, x):
    names = model_data["var_names"]
    name_to_i = {n: i for i, n in enumerate(names)}
    missing = [n for n in names if n not in x]
    extra = sorted(set(x) - set(name_to_i))
    vals = [int(x.get(n, 0)) for n in names]

    bound_violations = []
    for j, value in enumerate(vals):
        lb = model_data["lb"][j]
        ub = model_data["ub"][j]
        if finite_lb(lb) and value < lb:
            bound_violations.append(
                {"var": names[j], "value": value, "lb": lb, "ub": ub}
            )
        if finite_ub(ub) and value > ub:
            bound_violations.append(
                {"var": names[j], "value": value, "lb": lb, "ub": ub}
            )

    equality_violations = []
    for r, terms in model_data["eq_terms"].items():
        lhs = sum(a * vals[j] for j, a in terms)
        if lhs != 0:
            equality_violations.append(
                {"row": model_data["row_names"][r], "lhs": lhs, "rhs": 0}
            )

    cover_violations = []
    cover_slacks = []
    for r, u, v in model_data["covers"]:
        lhs = vals[u] + vals[v]
        cover_slacks.append(lhs - 1)
        if lhs < 1:
            cover_violations.append(
                {
                    "row": model_data["row_names"][r],
                    "u": names[u],
                    "v": names[v],
                    "lhs": lhs,
                    "rhs": 1,
                }
            )

    obj = model_data["objcon"] + sum(
        model_data["obj"][j] * vals[j] for j in range(len(vals))
    )
    return {
        "missing_variables": missing[:100],
        "missing_variable_count": len(missing),
        "extra_variables": extra[:100],
        "extra_variable_count": len(extra),
        "bound_violation_count": len(bound_violations),
        "bound_violations": bound_violations[:100],
        "equality_violation_count": len(equality_violations),
        "equality_violations": equality_violations[:100],
        "cover_violation_count": len(cover_violations),
        "cover_violations": cover_violations[:100],
        "minimum_cover_slack": min(cover_slacks) if cover_slacks else None,
        "objective": obj,
        "feasible": (
            not bound_violations
            and not equality_violations
            and not cover_violations
        ),
    }


def load_and_classify(path):
    model = gp.read(path)
    model.update()

    if model.ModelSense != GRB.MINIMIZE:
        raise ValueError("Expected minimization model")

    variables = model.getVars()
    constraints = model.getConstrs()
    var_names = [v.VarName for v in variables]
    row_names = [r.ConstrName for r in constraints]

    if any(v.VType != GRB.INTEGER for v in variables):
        raise ValueError("Not all original variables are general integer")

    lb = [float(v.LB) for v in variables]
    ub = [float(v.UB) for v in variables]
    obj = [as_int(v.Obj, f"objective coefficient {v.VarName}") for v in variables]
    objcon = as_int(model.ObjCon, "objective constant")

    eq_terms = {}
    covers = []
    malformed = []

    for i, con in enumerate(constraints):
        row = model.getRow(con)
        idx = [row.getVar(p).index for p in range(row.size())]
        coef = [
            as_int(row.getCoeff(p), f"coefficient in {con.ConstrName}")
            for p in range(row.size())
        ]
        rhs = as_int(con.RHS, f"RHS of {con.ConstrName}")

        if con.Sense == GRB.EQUAL:
            if rhs != 0 or any(a not in (-1, 1) for a in coef):
                malformed.append(
                    {"row": con.ConstrName, "reason": "non-homogeneous equality"}
                )
            eq_terms[i] = list(zip(idx, coef))
        elif con.Sense == GRB.GREATER_EQUAL:
            if len(idx) != 2 or coef != [1, 1] or rhs != 1:
                malformed.append(
                    {"row": con.ConstrName, "reason": "not x_u+x_v>=1"}
                )
            else:
                covers.append((i, idx[0], idx[1]))
        else:
            malformed.append(
                {"row": con.ConstrName, "reason": f"unexpected sense {con.Sense}"}
            )

    if malformed:
        raise ValueError(
            "Unexpected original structure:\n" + json.dumps(malformed[:20], indent=2)
        )

    return model, {
        "var_names": var_names,
        "row_names": row_names,
        "lb": lb,
        "ub": ub,
        "obj": obj,
        "objcon": objcon,
        "eq_terms": eq_terms,
        "covers": covers,
    }


def identify_network(data):
    nvar = len(data["var_names"])
    eq_rows = sorted(data["eq_terms"])
    eq_pos = {r: i for i, r in enumerate(eq_rows)}
    col_entries = [[] for _ in range(nvar)]

    for r, terms in data["eq_terms"].items():
        node = eq_pos[r]
        for j, a in terms:
            col_entries[j].append((node, a))

    bad = []
    tails = [-1] * nvar
    heads = [-1] * nvar
    for j, entries in enumerate(col_entries):
        entries = sorted(entries)
        if (
            len(entries) != 2
            or entries[0][0] == entries[1][0]
            or sorted(a for _, a in entries) != [-1, 1]
        ):
            bad.append(
                {
                    "var": data["var_names"][j],
                    "equality_entries": entries,
                }
            )
            continue
        for node, a in entries:
            if a == -1:
                tails[j] = node
            else:
                heads[j] = node

    return {
        "confirmed": not bad,
        "bad_columns": bad[:100],
        "bad_column_count": len(bad),
        "eq_rows": eq_rows,
        "tails": tails,
        "heads": heads,
        "node_names": [data["row_names"][r] for r in eq_rows],
        "equality_nnz": sum(len(v) for v in col_entries),
        "equality_column_degree_histogram": {
            str(k): v
            for k, v in sorted(
                collections.Counter(len(e) for e in col_entries).items()
            )
        },
    }


def build_spanning_forest(tails, heads, nnode):
    nedge = len(tails)
    adjacency = [[] for _ in range(nnode)]
    dsu = DSU(nnode)
    is_tree = [False] * nedge

    # Kruskal on an unweighted multigraph gives a spanning forest.
    for e, (u, v) in enumerate(zip(tails, heads)):
        if u == v:
            continue
        if dsu.union(u, v):
            is_tree[e] = True
            adjacency[u].append((v, e))
            adjacency[v].append((u, e))

    parent = [-1] * nnode
    parent_edge = [-1] * nnode
    depth = [0] * nnode
    roots = []

    for s in range(nnode):
        if parent[s] != -1:
            continue
        roots.append(s)
        parent[s] = s
        q = collections.deque([s])
        while q:
            u = q.popleft()
            for v, e in adjacency[u]:
                if parent[v] == -1:
                    parent[v] = u
                    parent_edge[v] = e
                    depth[v] = depth[u] + 1
                    q.append(v)

    chords = [e for e in range(nedge) if not is_tree[e]]
    return is_tree, chords, parent, parent_edge, depth, roots


def add_traversal_coefficient(edge_expr, edge, a, b, tails, heads, zidx, amount=1):
    """
    Add amount units of flow traversing tree edge 'edge' from node a to node b.
    Original edge orientation is tail -> head.
    """
    sign = amount if tails[edge] == a and heads[edge] == b else -amount
    edge_expr[edge][zidx] = edge_expr[edge].get(zidx, 0) + sign
    if edge_expr[edge][zidx] == 0:
        del edge_expr[edge][zidx]


def construct_cycle_basis(tails, heads, nnode):
    (
        is_tree,
        chords,
        parent,
        parent_edge,
        depth,
        roots,
    ) = build_spanning_forest(tails, heads, nnode)

    nedge = len(tails)
    edge_expr = [dict() for _ in range(nedge)]

    # z_k is exactly the value on chord chords[k].
    for k, e in enumerate(chords):
        edge_expr[e][k] = 1

        # Chord is tail u -> head v. To close the circulation, send one
        # unit along the unique tree path v -> u.
        u = tails[e]
        v = heads[e]
        a, b = v, u

        path_a = []
        path_b = []
        aa, bb = a, b

        while depth[aa] > depth[bb]:
            pe = parent_edge[aa]
            p = parent[aa]
            path_a.append((pe, aa, p))
            aa = p
        while depth[bb] > depth[aa]:
            pe = parent_edge[bb]
            p = parent[bb]
            # Stored upward now; reversed later to obtain LCA -> b.
            path_b.append((pe, bb, p))
            bb = p
        while aa != bb:
            pea = parent_edge[aa]
            pa = parent[aa]
            path_a.append((pea, aa, pa))
            aa = pa

            peb = parent_edge[bb]
            pb = parent[bb]
            path_b.append((peb, bb, pb))
            bb = pb

        # a -> LCA
        for te, frm, to in path_a:
            add_traversal_coefficient(
                edge_expr, te, frm, to, tails, heads, k
            )
        # LCA -> b: reverse the upward b -> LCA list.
        for te, child, par in reversed(path_b):
            add_traversal_coefficient(
                edge_expr, te, par, child, tails, heads, k
            )

    # Exact verification B*C=0 and identity on chord rows.
    balance = [collections.defaultdict(int) for _ in range(nnode)]
    for e, expr in enumerate(edge_expr):
        for k, a in expr.items():
            balance[tails[e]][k] -= a
            balance[heads[e]][k] += a

    nonzero_balance = []
    for node, row in enumerate(balance):
        for k, value in row.items():
            if value != 0:
                nonzero_balance.append((node, k, value))

    if nonzero_balance:
        raise AssertionError(
            f"Cycle basis failed B*C=0: {nonzero_balance[:20]}"
        )

    for k, e in enumerate(chords):
        if edge_expr[e] != {k: 1}:
            raise AssertionError("Chord identity block was not preserved")

    return {
        "edge_expr": edge_expr,
        "chords": chords,
        "is_tree": is_tree,
        "parent": parent,
        "parent_edge": parent_edge,
        "depth": depth,
        "roots": roots,
    }


def combine_expr(a, b):
    out = dict(a)
    for k, value in b.items():
        out[k] = out.get(k, 0) + value
        if out[k] == 0:
            del out[k]
    return out


def write_basis_tsv(path, data, basis):
    with open(path, "wt", encoding="utf-8") as f:
        f.write("original_variable\tcycle_variable\tcoefficient\n")
        for e, expr in enumerate(basis["edge_expr"]):
            for k, a in sorted(expr.items()):
                f.write(
                    f"{data['var_names'][e]}\t"
                    f"Z{k:05d}_{data['var_names'][basis['chords'][k]]}\t{a}\n"
                )


def build_reduced_model(data, basis, out_mps):
    rm = gp.Model("neos-3594536-henty-cycle-reduced")
    rm.Params.OutputFlag = 0

    chords = basis["chords"]
    z = []
    for k, e in enumerate(chords):
        z.append(
            rm.addVar(
                lb=-GRB.INFINITY,
                ub=GRB.INFINITY,
                vtype=GRB.INTEGER,
                name=f"Z{k:05d}_{data['var_names'][e]}",
            )
        )
    rm.update()

    def linexpr(coeffs):
        return gp.LinExpr(
            [int(a) for _, a in coeffs.items()],
            [z[k] for k in coeffs],
        )

    transformed_obj = [0] * len(chords)
    for e, expr in enumerate(basis["edge_expr"]):
        ce = data["obj"][e]
        for k, a in expr.items():
            transformed_obj[k] += ce * a

    rm.setObjective(
        gp.LinExpr(transformed_obj, z) + data["objcon"], GRB.MINIMIZE
    )

    bound_rows = 0
    zero_expr_infeasibility = []
    for e, expr in enumerate(basis["edge_expr"]):
        lb = data["lb"][e]
        ub = data["ub"][e]
        xexpr = linexpr(expr)
        if finite_lb(lb):
            ilb = as_int(lb, f"lower bound {data['var_names'][e]}")
            if expr:
                rm.addConstr(xexpr >= ilb, name=f"LB_{data['var_names'][e]}")
            elif 0 < ilb:
                zero_expr_infeasibility.append(
                    f"{data['var_names'][e]} fixed to 0 but lower bound is {ilb}"
                )
            bound_rows += 1
        if finite_ub(ub):
            iub = as_int(ub, f"upper bound {data['var_names'][e]}")
            if expr:
                rm.addConstr(xexpr <= iub, name=f"UB_{data['var_names'][e]}")
            elif 0 > iub:
                zero_expr_infeasibility.append(
                    f"{data['var_names'][e]} fixed to 0 but upper bound is {iub}"
                )
            bound_rows += 1

    for r, u, v in data["covers"]:
        expr = combine_expr(basis["edge_expr"][u], basis["edge_expr"][v])
        if not expr:
            zero_expr_infeasibility.append(
                f"{data['row_names'][r]} reduces to 0 >= 1"
            )
        else:
            rm.addConstr(
                linexpr(expr) >= 1,
                name=f"CV_{data['row_names'][r]}",
            )

    if zero_expr_infeasibility:
        raise ValueError(
            "Original model would be structurally infeasible:\n"
            + "\n".join(zero_expr_infeasibility[:20])
        )

    rm.update()
    rm.write(out_mps)
    return rm, transformed_obj, bound_rows


def recover_original(data, basis, zvalues):
    ans = {}
    for e, expr in enumerate(basis["edge_expr"]):
        value = sum(a * zvalues[k] for k, a in expr.items())
        ans[data["var_names"][e]] = int(value)
    return ans


def write_plain_solution(path, values, objective=None):
    with open(path, "wt", encoding="utf-8") as f:
        if objective is not None:
            f.write(f"# objective {objective}\n")
        for name in sorted(values):
            f.write(f"{name} {values[name]}\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "mps",
        help="Path to neos-3594536-henty.mps or .mps.gz",
    )
    ap.add_argument(
        "--out",
        default="henty_analysis",
        help="Output directory (default: henty_analysis)",
    )
    ap.add_argument(
        "--solution",
        default=None,
        help="Optional public incumbent to audit",
    )
    ap.add_argument(
        "--solve-seconds",
        type=float,
        default=0.0,
        help="Solve reduced oracle for at most this many seconds; capped at 1800",
    )
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    report_path = os.path.join(args.out, "report.json")
    reduced_path = os.path.join(args.out, "reduced.mps")
    basis_path = os.path.join(args.out, "cycle_basis.tsv")

    started = time.time()
    original, data = load_and_classify(args.mps)
    net = identify_network(data)

    report = {
        "instance": original.ModelName,
        "original": {
            "variables": original.NumVars,
            "constraints": original.NumConstrs,
            "equalities": len(data["eq_terms"]),
            "covers": len(data["covers"]),
            "nonzeros": original.NumNZs,
            "objective_constant": data["objcon"],
        },
        "network_incidence": {
            k: v
            for k, v in net.items()
            if k not in ("tails", "heads", "eq_rows", "node_names")
        },
    }

    if args.solution:
        incumbent = read_solution(args.solution)
        report["supplied_solution_audit"] = audit_vector(data, incumbent)

    if not net["confirmed"]:
        report["conclusion"] = (
            "Equality matrix is not a directed node-arc incidence matrix; "
            "cycle-space reduction was not generated."
        )
        report["elapsed_seconds"] = time.time() - started
        with open(report_path, "wt", encoding="utf-8") as f:
            json.dump(report, f, indent=2, sort_keys=True)
        print(json.dumps(report, indent=2, sort_keys=True))
        sys.exit(2)

    tails, heads = net["tails"], net["heads"]
    nnode = len(net["eq_rows"])

    circulation_edges = list(zip(tails, heads))
    report["circulation_graph"] = graph_analysis(nnode, circulation_edges)

    cover_edges = [(u, v) for _, u, v in data["covers"]]
    report["cover_graph"] = graph_analysis(len(data["var_names"]), cover_edges)

    cover_degree = [0] * len(data["var_names"])
    equal_cost_cover_edges = 0
    both_free_cover_edges = 0
    for _, u, v in data["covers"]:
        cover_degree[u] += 1
        cover_degree[v] += 1
        equal_cost_cover_edges += int(data["obj"][u] == data["obj"][v])
        both_free_cover_edges += int(
            not finite_lb(data["lb"][u])
            and not finite_ub(data["ub"][u])
            and not finite_lb(data["lb"][v])
            and not finite_ub(data["ub"][v])
        )

    report["cover_edge_attributes"] = {
        "equal_objective_edges": equal_cost_cover_edges,
        "both_endpoints_free_edges": both_free_cover_edges,
        "total_edges": len(data["covers"]),
    }

    basis = construct_cycle_basis(tails, heads, nnode)
    write_basis_tsv(basis_path, data, basis)

    expected_dimension = (
        len(data["var_names"])
        - nnode
        + len(basis["roots"])
    )
    if expected_dimension != len(basis["chords"]):
        raise AssertionError(
            f"Cycle dimension mismatch: expected {expected_dimension}, "
            f"constructed {len(basis['chords'])}"
        )

    report["cycle_reduction"] = {
        "equality_graph_components": len(basis["roots"]),
        "tree_arcs_eliminated": sum(basis["is_tree"]),
        "cycle_variables": len(basis["chords"]),
        "expected_kernel_dimension": expected_dimension,
        "basis_nonzeros": sum(len(e) for e in basis["edge_expr"]),
        "basis_row_nnz_stats": stats(
            [len(e) for e in basis["edge_expr"]]
        ),
        "proof_properties_checked": [
            "each equality column has exactly one -1 and one +1",
            "B*C = 0 by exact integer arithmetic",
            "cycle-basis chord submatrix is the identity",
            "therefore z -> C z maps Z^k bijectively onto ker(B) intersect Z^m",
        ],
    }

    reduced, transformed_obj, bound_rows = build_reduced_model(
        data, basis, reduced_path
    )
    report["reduced_model"] = {
        "variables": reduced.NumVars,
        "constraints": reduced.NumConstrs,
        "bound_rows_requested": bound_rows,
        "cover_rows": len(data["covers"]),
        "equalities": 0,
        "transformed_objective_stats": stats(transformed_obj),
        "path": reduced_path,
    }

    if args.solve_seconds > 0:
        seconds = min(max(float(args.solve_seconds), 0.0), 1800.0)
        log_path = os.path.join(args.out, "oracle.log")
        reduced.Params.OutputFlag = 1
        reduced.Params.LogFile = log_path
        reduced.Params.TimeLimit = seconds
        reduced.Params.MIPGap = 0.0
        reduced.optimize()

        oracle = {
            "time_limit_seconds": seconds,
            "status": int(reduced.Status),
            "runtime": float(reduced.Runtime),
            "solution_count": int(reduced.SolCount),
        }
        if reduced.Status not in (GRB.LOADED, GRB.INPROGRESS):
            try:
                oracle["objective_bound"] = float(reduced.ObjBound)
            except gp.GurobiError:
                pass

        if reduced.SolCount > 0:
            zvalues = [
                as_int(v.X, f"reduced solution {v.VarName}", 1e-5)
                for v in reduced.getVars()
            ]
            candidate = recover_original(data, basis, zvalues)
            audit = audit_vector(data, candidate)
            oracle["incumbent_objective"] = float(reduced.ObjVal)
            oracle["mapped_candidate_feasible"] = audit["feasible"]
            oracle["mapped_candidate_objective"] = audit["objective"]

            reduced.write(os.path.join(args.out, "reduced.sol"))
            write_plain_solution(
                os.path.join(args.out, "original_candidate.sol"),
                candidate,
                audit["objective"],
            )
            with open(
                os.path.join(args.out, "candidate_audit.json"),
                "wt",
                encoding="utf-8",
            ) as f:
                json.dump(audit, f, indent=2, sort_keys=True)

        report["reduced_oracle"] = oracle

    report["conclusion"] = (
        "The homogeneous equality system is an exact directed-incidence "
        "circulation system. The model has been transformed bijectively over "
        "the integers to an equality-free cycle-space MIP. The remaining "
        "obstruction is the interaction of original arc bounds and the "
        "pairwise cover graph after projection into cycle coordinates."
    )
    report["elapsed_seconds"] = time.time() - started

    with open(report_path, "wt", encoding="utf-8") as f:
        json.dump(report, f, indent=2, sort_keys=True)

    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
