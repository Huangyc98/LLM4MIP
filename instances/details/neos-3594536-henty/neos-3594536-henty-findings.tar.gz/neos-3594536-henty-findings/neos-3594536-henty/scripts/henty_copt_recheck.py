#!/usr/bin/env python3
"""Independent zero-gap COPT recheck of the Henty reduced MPS."""

from __future__ import annotations

import argparse
import json
import math
import os
from pathlib import Path

import coptpy as cp
from coptpy import COPT


def attr(model, name):
    """Return a COPT attribute when exposed by the installed binding."""
    enum = getattr(COPT.Attr, name, None)
    return model.getAttr(enum) if enum is not None else None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("model")
    parser.add_argument("--start", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--seconds", type=float, default=1800.0)
    parser.add_argument("--threads", type=int, default=32)
    args = parser.parse_args()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    if os.environ.get("CUDA_VISIBLE_DEVICES") not in {"", "-1"}:
        raise RuntimeError("set CUDA_VISIBLE_DEVICES='' for this CPU experiment")

    env = cp.Envr()
    model = env.createModel("henty_component_parity_copt")
    model.readMps(args.model)
    model.readSol(args.start)
    model.setParam(COPT.Param.TimeLimit, max(1.0, min(args.seconds, 3600.0)))
    model.setParam(COPT.Param.Threads, max(1, args.threads))
    model.setParam(COPT.Param.RelGap, 0.0)
    if hasattr(COPT.Param, "GPUMode"):
        model.setParam(COPT.Param.GPUMode, 0)
    model.setLogFile(str(out / "solver.log"))
    model.solve()

    best_objective_raw = attr(model, "BestObj")
    best_objective = (
        float(best_objective_raw) if best_objective_raw is not None else None
    )
    best_bound = float(attr(model, "BestBnd"))
    result = {
        "solver": "COPT",
        "version": [
            int(COPT.VERSION_MAJOR),
            int(COPT.VERSION_MINOR),
            int(COPT.VERSION_TECHNICAL),
        ],
        "status": int(model.status),
        "optimal_status": bool(model.status == COPT.OPTIMAL),
        "relative_gap_parameter": 0.0,
        "objective": best_objective,
        "best_bound": best_bound,
        "conservative_integer_lower_bound": int(math.ceil(best_bound - 1e-6)),
        "nodes": float(attr(model, "NodeCnt")),
        "runtime_seconds": float(attr(model, "SolvingTime")),
    }
    if best_objective is not None:
        model.writeSol(str(out / "best.sol"))
    (out / "result.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
