#!/usr/bin/env python3
"""Exact component-balance plus parity reduction for neos-3594536-henty.

The free antiparallel required pairs are eliminated.  Starting from one copy
of every required edge and all directed lower bounds, q adds directed arcs and
r duplicates required edges.  Feasibility is equivalent to:

* exact directed-flow balance after contracting each required-edge component;
* the correct degree parity at every original node.

The omitted signed pair flows are reconstructed over a spanning forest using
integer arithmetic.  Gurobi is used only for the reduced optimization oracle.
"""

from __future__ import annotations

import argparse
from collections import defaultdict
import json
import math
import os
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB

from henty_cycle_reducer import (
    DSU,
    as_int,
    audit_vector,
    finite_lb,
    finite_ub,
    identify_network,
    load_and_classify,
    read_solution,
    write_plain_solution,
)
from henty_parity_oracle import build_pairs


def build_components(node_count, pairs, net):
    dsu = DSU(node_count)
    for u, _ in pairs:
        dsu.union(net["tails"][u], net["heads"][u])
    roots = sorted({dsu.find(v) for v in range(node_count)})
    root_index = {root: i for i, root in enumerate(roots)}
    component = [root_index[dsu.find(v)] for v in range(node_count)]
    nodes = [[] for _ in roots]
    for v, c in enumerate(component):
        nodes[c].append(v)
    return component, nodes


def derive_data(data, net, pairs, cover_var):
    node_count = len(net["eq_rows"])
    directed = [j for j in range(len(data["var_names"])) if j not in cover_var]
    lower = {}
    rhs = [0] * node_count
    base = data["objcon"]
    for j in directed:
        if not finite_lb(data["lb"][j]) or finite_ub(data["ub"][j]):
            raise ValueError(f"directed variable {data['var_names'][j]} has invalid bounds")
        lower[j] = as_int(data["lb"][j], f"lower bound {data['var_names'][j]}")
        base += data["obj"][j] * lower[j]
        rhs[net["tails"][j]] += lower[j]
        rhs[net["heads"][j]] -= lower[j]
    # Incidence convention in identify_network is -1 at tail and +1 at head;
    # rhs is minus the mandatory directed contribution.
    required_degree = [0] * node_count
    for u, _ in pairs:
        required_degree[net["tails"][u]] += 1
        required_degree[net["heads"][u]] += 1
        base += data["obj"][u]
    parity = [(rhs[v] - required_degree[v]) & 1 for v in range(node_count)]
    component, component_nodes = build_components(node_count, pairs, net)
    component_rhs = [sum(rhs[v] for v in nodes) for nodes in component_nodes]
    assert sum(component_rhs) == 0
    return {
        "directed": directed,
        "lower": lower,
        "rhs": rhs,
        "required_degree": required_degree,
        "parity": parity,
        "component": component,
        "component_nodes": component_nodes,
        "component_rhs": component_rhs,
        "base_objective": base,
    }


def incumbent_reduction(data, net, pairs, derived, solution_path):
    sparse = read_solution(str(solution_path))
    original = {name: int(sparse.get(name, 0)) for name in data["var_names"]}
    audit = audit_vector(data, original)
    if not audit["feasible"]:
        raise ValueError("supplied incumbent is not feasible")
    q_start = {
        j: original[data["var_names"][j]] - derived["lower"][j]
        for j in derived["directed"]
    }
    assert min(q_start.values()) >= 0
    r_start = []
    for u, v in pairs:
        total = original[data["var_names"][u]] + original[data["var_names"][v]]
        assert total in (1, 2)
        r_start.append(total - 1)
    return original, audit, q_start, r_start


def reconstruct_original(data, net, pairs, derived, q_values, r_values):
    node_count = len(net["eq_rows"])
    aq = [0] * node_count
    mapped = {}
    for j in derived["directed"]:
        q = int(q_values[j])
        assert q >= 0
        aq[net["tails"][j]] -= q
        aq[net["heads"][j]] += q
        mapped[data["var_names"][j]] = derived["lower"][j] + q

    bp = [0] * node_count
    adjacency = [[] for _ in range(node_count)]
    for i, (u, _) in enumerate(pairs):
        p = 1 - int(r_values[i])
        assert p in (0, 1)
        tail, head = net["tails"][u], net["heads"][u]
        bp[tail] -= p
        bp[head] += p
        adjacency[tail].append((head, i))
        adjacency[head].append((tail, i))

    residual = [derived["rhs"][v] - aq[v] - bp[v] for v in range(node_count)]
    assert all(value % 2 == 0 for value in residual)
    demand = [value // 2 for value in residual]
    k_values = [0] * len(pairs)
    seen = [False] * node_count
    parent = [-1] * node_count
    parent_edge = [-1] * node_count
    order = []
    for root in range(node_count):
        if seen[root]:
            continue
        seen[root] = True
        stack = [root]
        component_order = []
        while stack:
            node = stack.pop()
            component_order.append(node)
            for other, edge in adjacency[node]:
                if not seen[other]:
                    seen[other] = True
                    parent[other] = node
                    parent_edge[other] = edge
                    stack.append(other)
        for node in reversed(component_order[1:]):
            edge = parent_edge[node]
            u, _ = pairs[edge]
            coefficient = -1 if net["tails"][u] == node else 1
            k_values[edge] = demand[node] * coefficient
            demand[parent[node]] += demand[node]
            demand[node] = 0
        assert demand[root] == 0
        order.extend(component_order)

    for i, (u, v) in enumerate(pairs):
        k = k_values[i]
        r = int(r_values[i])
        mapped[data["var_names"][u]] = k + 1
        mapped[data["var_names"][v]] = r - k
    audit = audit_vector(data, mapped)
    assert audit["feasible"]
    return mapped, audit


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mps")
    parser.add_argument("--solution", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--seconds", type=float, default=0.0)
    parser.add_argument("--threads", type=int, default=8)
    parser.add_argument("--improve-only", action="store_true")
    args = parser.parse_args()
    os.makedirs(args.out, exist_ok=True)

    original_model, data = load_and_classify(args.mps)
    net = identify_network(data)
    assert net["confirmed"]
    pairs, cover_var = build_pairs(data, net)
    derived = derive_data(data, net, pairs, cover_var)
    original_start, start_audit, q_start, r_start = incumbent_reduction(
        data, net, pairs, derived, args.solution
    )

    model = gp.Model("henty_component_parity")
    q = {
        j: model.addVar(vtype=GRB.INTEGER, lb=0, obj=data["obj"][j], name=f"q_{data['var_names'][j]}")
        for j in derived["directed"]
    }
    r = [
        model.addVar(vtype=GRB.BINARY, obj=data["obj"][u], name=f"r_{data['var_names'][u]}")
        for u, _ in pairs
    ]
    h = [model.addVar(vtype=GRB.INTEGER, lb=0, obj=0, name=f"h_{v}") for v in range(len(net["eq_rows"]))]
    model.ModelSense = GRB.MINIMIZE
    model.ObjCon = derived["base_objective"]
    model.update()

    component_expr = [gp.LinExpr() for _ in derived["component_nodes"]]
    parity_expr = [gp.LinExpr() for _ in range(len(net["eq_rows"]))]
    for j in derived["directed"]:
        tail, head = net["tails"][j], net["heads"][j]
        ct, ch = derived["component"][tail], derived["component"][head]
        if ct != ch:
            component_expr[ct].addTerms(-1, q[j])
            component_expr[ch].addTerms(1, q[j])
        parity_expr[tail].addTerms(1, q[j])
        parity_expr[head].addTerms(1, q[j])
    for i, (u, _) in enumerate(pairs):
        tail, head = net["tails"][u], net["heads"][u]
        parity_expr[tail].addTerms(1, r[i])
        parity_expr[head].addTerms(1, r[i])
    for c, rhs in enumerate(derived["component_rhs"]):
        model.addConstr(component_expr[c] == rhs, name=f"component_balance_{c}")
    for v, target in enumerate(derived["parity"]):
        model.addConstr(parity_expr[v] - 2 * h[v] == target, name=f"node_parity_{v}")

    for j, value in q_start.items():
        q[j].Start = value
    for i, value in enumerate(r_start):
        r[i].Start = value
    incident_q = [0] * len(net["eq_rows"])
    incident_r = [0] * len(net["eq_rows"])
    for j, value in q_start.items():
        incident_q[net["tails"][j]] += value
        incident_q[net["heads"][j]] += value
    for i, value in enumerate(r_start):
        u, _ = pairs[i]
        incident_r[net["tails"][u]] += value
        incident_r[net["heads"][u]] += value
    for v in range(len(h)):
        numerator = incident_q[v] + incident_r[v] - derived["parity"][v]
        assert numerator >= 0 and numerator % 2 == 0
        h[v].Start = numerator // 2

    model.update()
    if args.improve_only:
        target = int(start_audit["objective"]) - 1
        # getObjective() already contains ObjCon.  Keeping the constant here is
        # important: this mode is the explicit integer target test
        # objective <= incumbent - 1.
        model.addConstr(model.getObjective() <= target, name="strict_improvement")
    model.write(os.path.join(args.out, "component_parity.mps"))
    model.write(os.path.join(args.out, "component_parity.mst"))

    build_report = {
        "instance": original_model.ModelName,
        "exact_reduction": True,
        "base_objective": derived["base_objective"],
        "directed_augmentation_variables": len(q),
        "required_edge_duplication_variables": len(r),
        "parity_quotient_variables": len(h),
        "required_edge_components": len(derived["component_nodes"]),
        "component_balance_constraints": len(component_expr),
        "node_parity_constraints": len(parity_expr),
        "start_original_audit": start_audit,
        "start_augmentation_cost": int(start_audit["objective"] - derived["base_objective"]),
        "start_directed_augmentation_cost": int(
            sum(data["obj"][j] * value for j, value in q_start.items())
        ),
        "start_required_duplication_cost": int(
            sum(data["obj"][pairs[i][0]] * value for i, value in enumerate(r_start))
        ),
        "start_positive_directed_augmentations": sum(value > 0 for value in q_start.values()),
        "start_duplicated_required_edges": sum(r_start),
        "proof": [
            "one mandatory copy of every required pair costs the base objective",
            "component balances are necessary and sufficient for the omitted pair-flow residual to lie in the real incidence image",
            "node parity makes that residual even",
            "a connected graph incidence matrix spans every integral zero-sum vector, so the halved residual has an integer pair-flow reconstruction",
        ],
    }
    with open(os.path.join(args.out, "build-report.json"), "w", encoding="utf-8") as stream:
        json.dump(build_report, stream, indent=2, sort_keys=True)

    seconds = max(0.0, min(float(args.seconds), 3600.0))
    if seconds <= 0:
        print(json.dumps(build_report, indent=2, sort_keys=True))
        return
    model.Params.TimeLimit = seconds
    model.Params.Threads = max(1, args.threads)
    model.Params.MIPGap = 0
    model.Params.LogFile = os.path.join(args.out, "solver.log")
    model.optimize()
    objective_bound = float(model.ObjBound)
    conservative_lower_bound = (
        int(math.ceil(objective_bound - 1e-6))
        if math.isfinite(objective_bound)
        else None
    )
    result = {
        **build_report,
        "solver": {
            "status": int(model.Status),
            "runtime": float(model.Runtime),
            "nodes": float(model.NodeCount),
            "solution_count": int(model.SolCount),
            "objective_bound": objective_bound if math.isfinite(objective_bound) else None,
            "conservative_integer_lower_bound": conservative_lower_bound,
        },
    }
    if model.SolCount:
        q_value = {j: as_int(q[j].X, f"q {j}", 1e-5) for j in q}
        r_value = [as_int(var.X, f"r {i}", 1e-5) for i, var in enumerate(r)]
        mapped, mapped_audit = reconstruct_original(data, net, pairs, derived, q_value, r_value)
        result["solver"]["objective"] = float(model.ObjVal)
        result["mapped_original_audit"] = mapped_audit
        solution_out = os.path.join(args.out, "mapped_original.sol")
        write_plain_solution(solution_out, mapped, mapped_audit["objective"])
        result["mapped_original_solution"] = solution_out
        assert abs(mapped_audit["objective"] - model.ObjVal) <= 1e-5
    with open(os.path.join(args.out, "result.json"), "w", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2, sort_keys=True)
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
