# Sources

- MIPLIB official instance page: https://miplib.zib.de/instance_details_cmflsp40-36-2-10.html
- Andrea L. Arias and Ricardo A. Gatica, “A comparative analysis of mixed-integer linear formulations for the multi-family capacitated lot-sizing problem,” Journal of Industrial and Production Engineering 35(4), 2018, DOI: https://doi.org/10.1080/21681015.2018.1446461
- The paper describes MFCLSP as a capacitated lot-sizing model with setup times in which items are organized into families, and compares MF-TRAD, MF-ARBNET and MF-EXREQ formulations. The recovered variable dimensions and row names identify this MPS as an extended-requirement style formulation.
- MIPLIB reports 28,152 variables, 4,266 constraints and a tolerance-accepted objective of `66452234.49456009`.
