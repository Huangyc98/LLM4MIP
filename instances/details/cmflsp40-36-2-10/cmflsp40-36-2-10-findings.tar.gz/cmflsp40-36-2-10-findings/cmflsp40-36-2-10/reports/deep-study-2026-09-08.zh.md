# cmflsp40-36-2-10 深度研究报告（2026-09-08）

## 结论

本轮没有找到优于 MIPLIB tolerance solution 的严格可行解，也没有证明全局最优。得到的是一个经严格修复和独立审计的 incumbent，以及相当完整的局部最优证据：

```text
MIPLIB 公布目标值       66,452,234.49456009
严格修复后的目标值     66,452,236.45360000
1200 秒全局 dual bound 65,928,415.30680852
严格 incumbent 的 gap              0.7883%
```

这里必须区分：MIPLIB 公布值在默认容差下可接受，但直接代回原 MPS 时存在约 `7.5e-7` 的小偏差；把整数变量严格舍入后目标变差约 `1.95904`。因此本轮不能声称 primal 改进。

## 1. Gurobi 结构读取与问题背景

- 28,152 个变量、4,266 个约束、386,432 个非零元。
- 1,512 个 0/1 整数变量，26,640 个连续变量。
- 1,350 个等式和 2,916 个小于等于约束。
- `Y_i_t`：40×36=1,440 个 item-period setup 变量。
- `Z_f_t`：2×36=72 个 family-period setup 变量。
- `X_i_s_t`：26,640 个 extended-requirement 生产/需求覆盖变量。
- 约束名分为 `Balance`、`Setup1`、`Setup2`、`Capacidad`。

MIPLIB 将其归类为 capacitated multi-family lot-sizing。Arias 与 Gatica（2018）讨论了同类问题的 MF-TRAD、MF-ARBNET 和 MF-EXREQ formulation；本实例的变量维度和行名与 extended-requirement 风格一致。其困难来自跨期需求覆盖、产能、item setup 与 family setup 的联动。

## 2. 公布解严格化

公布 solution 的目标值约 `66,452,234.49456`，最大变量界/行偏差约为 `7.4e-7`。把 1,512 个整数变量全部舍入固定，再优化全部 26,640 个连续 `X` 变量，得到：

- 目标值 `66,452,236.4536`；
- 最大变量界违约 `0`；
- 最大整数性违约 `0`；
- 最大行违约 `2.27e-13`；
- 没有大于 `1e-9` 的违约。

该解是后续所有邻域与全局实验的严格基准。

## 3. item block 完全枚举邻域

对每次试验：固定邻域外的 item setup `Y`，释放被选 item 的所有 36 个 `Y`、全部 72 个 family setup `Z`，并释放全部 26,640 个连续 `X`。这不是简单变量翻转，而是每次都重新优化所有连续 recourse 和全局 family 层。

完整枚举了：

- 40 个单 item block；
- `C(40,2)=780` 个双 item block；
- 合计 820 个邻域。

820/820 均被 Gurobi 精确求到 OPTIMAL，没有一个产生改进，总用时约 359 秒。因此严格 incumbent 对所有单 item 和双 item setup block 都是条件局部最优。

## 4. contiguous period 邻域

固定窗口外的 `Y/Z`，释放连续 2、3、4、5、6 个时期内的全部 item/family setup，并再次释放所有 `X` 变量。完整枚举 36 期上的所有这些窗口：

- 共 165 个窗口；
- 165/165 精确求到 OPTIMAL；
- 没有改进；
- 总用时约 215 秒。

所以 incumbent 对所有长度 2–6 的连续时期 setup 重排也是条件局部最优。

## 5. 固定 family pattern 的大邻域

仅固定 72 个 `Z_f_t`，同时优化全部 1,440 个 item setup `Y` 和 26,640 个 `X`。这是比前两组大得多的邻域。600 秒后：

```text
incumbent  66,452,236.45360000
bound      66,439,354.39233170
gap                      0.0194%
nodes                    13,556
```

没有发现更优解，但未完全闭合，所以不能把“固定 family pattern 下最优”当作已证明结论。它仍说明当前解在该大邻域内很强，剩余证据缺口已小于 0.02%。

## 6. 全局长跑

原始模型采用严格容差、强化 cuts 和 bound-oriented search，运行 1,200 秒：

```text
incumbent  66,452,236.45360000
dual bound 65,928,415.30680852
gap                       0.7883%
nodes                      1,296
```

没有新解。全局 bound 明显好于完全没有分析，但仍不足以证明 MIPLIB 公布值或严格修复值最优。

## 7. 结果边界

本轮能够严格声称：

- 构造了无 `1e-9` 级违约的 incumbent；
- 它是全部 820 个一/二 item block 邻域的精确局部最优；
- 它是全部 165 个长度 2–6 连续 period 邻域的精确局部最优；
- 固定 family setup 后，大邻域 600 秒的剩余 gap 为 `0.0194%`；
- 原问题 1,200 秒的 global gap 为 `0.7883%`。

本轮不能声称：

- 相对于 MIPLIB 有 primal 改进；
- 已证明原问题全局最优；
- 已证明固定 family pattern 下全局最优。

## 8. 关键文件

- 严格 incumbent：`../solutions/strict-repaired.sol`
- 独立原 MPS 审计：`../artifacts/strict-incumbent-independent-audit.json`
- 820 个 item 邻域：`../artifacts/all-item-pairs-900s.json`
- 165 个 period 邻域：`../artifacts/period-neighborhoods-900s.json`
- fixed-family 大邻域：`../artifacts/fixed-family-600s.json`
- 1,200 秒全局搜索：`../artifacts/global-bound-1200s.json`
- 实验代码：`../scripts/cmflsp_item_neighborhoods.py`、`../scripts/cmflsp_period_neighborhoods.py`、`../scripts/cmflsp_fixed_family.py`

## 9. 下一步建议

最有希望的方向不是继续做更小的 LNS，而是针对 72 个 family-period setup 做分解或逻辑 Benders：把 `Z` 作为 master，`Y/X` 作为 subproblem，并从 capacity shortfall 与 setup coupling 中提取 cuts。现有 fixed-family gap 已很小，说明给定 family pattern 的内部优化相对可控；真正困难更可能集中在 family pattern 的全局组合。
