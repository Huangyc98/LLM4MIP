from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def read_values(path: Path) -> dict[str, float]:
    values: dict[str, float] = {}
    with path.open("rt", encoding="utf-8", errors="replace") as handle:
        for raw in handle:
            if raw.lstrip().startswith("#"):
                continue
            fields = raw.split()
            if len(fields) >= 2:
                try:
                    values[fields[0]] = float(fields[1])
                except ValueError:
                    pass
    return values


def integer_period(name: str) -> int | None:
    if name.startswith("Y_") or name.startswith("Z_"):
        return int(name.rsplit("_", 1)[1])
    return None


def audit(model: gp.Model) -> dict[str, float | int]:
    max_bound = max_integer = max_row = 0.0
    row_count = 0
    for variable in model.getVars():
        max_bound = max(max_bound, variable.LB - variable.X, variable.X - variable.UB, 0.0)
        if variable.VType in (GRB.BINARY, GRB.INTEGER, GRB.SEMIINT):
            max_integer = max(max_integer, abs(variable.X - round(variable.X)))
    for constraint in model.getConstrs():
        row = model.getRow(constraint)
        lhs = math.fsum(row.getCoeff(k) * row.getVar(k).X for k in range(row.size()))
        if constraint.Sense == GRB.LESS_EQUAL:
            violation = max(lhs - constraint.RHS, 0.0)
        elif constraint.Sense == GRB.GREATER_EQUAL:
            violation = max(constraint.RHS - lhs, 0.0)
        else:
            violation = abs(lhs - constraint.RHS)
        max_row = max(max_row, violation)
        row_count += violation > 1e-9
    return {"max_bound_violation": max_bound, "max_integrality_violation": max_integer, "max_row_violation": max_row, "row_violations_over_1e_9": row_count}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("seed", type=Path)
    parser.add_argument("summary", type=Path)
    parser.add_argument("solution_out", type=Path)
    parser.add_argument("--total-time", type=float, default=900.0)
    parser.add_argument("--per-trial", type=float, default=20.0)
    parser.add_argument("--threads", type=int, default=1)
    parser.add_argument("--max-width", type=int, default=6)
    args = parser.parse_args()

    started = time.monotonic()
    base = gp.read(str(args.mps))
    best_values = read_values(args.seed)
    incumbent = base.ObjCon + math.fsum(v.Obj * best_values.get(v.VarName, 0.0) for v in base.getVars())
    initial = incumbent
    windows = [(start, start + width - 1) for width in range(2, args.max_width + 1) for start in range(1, 38 - width)]
    trials = []
    improvements = []
    for index, (left, right) in enumerate(windows):
        elapsed = time.monotonic() - started
        if elapsed >= args.total_time:
            break
        model = base.copy()
        for variable in model.getVars():
            value = best_values.get(variable.VarName, 0.0)
            variable.Start = value
            period = integer_period(variable.VarName)
            if period is not None and not left <= period <= right:
                rounded = round(value)
                variable.LB = rounded
                variable.UB = rounded
        model.Params.OutputFlag = 0
        model.Params.Threads = args.threads
        model.Params.TimeLimit = min(args.per_trial, max(1.0, args.total_time - elapsed))
        model.Params.MIPFocus = 1
        model.Params.FeasibilityTol = 1e-9
        model.Params.IntFeasTol = 1e-9
        model.Params.MIPGap = 1e-9
        model.optimize()
        record = {"index": index, "window": [left, right], "status": int(model.Status), "status_name": {GRB.OPTIMAL: "OPTIMAL", GRB.TIME_LIMIT: "TIME_LIMIT"}.get(model.Status, str(model.Status)), "runtime": model.Runtime, "nodes": model.NodeCount, "solutions": model.SolCount, "objective": model.ObjVal if model.SolCount else None, "bound": model.ObjBound}
        trials.append(record)
        if model.SolCount and model.ObjVal < incumbent - 1e-7:
            previous = incumbent
            incumbent = model.ObjVal
            best_values = {variable.VarName: variable.X for variable in model.getVars()}
            improvements.append({"window": [left, right], "previous": previous, "objective": incumbent})

    final = base.copy()
    for variable in final.getVars():
        variable.Start = best_values.get(variable.VarName, 0.0)
    final.Params.OutputFlag = 0
    final.Params.SolutionLimit = 1
    final.Params.FeasibilityTol = 1e-9
    final.Params.IntFeasTol = 1e-9
    final.optimize()
    if final.SolCount:
        incumbent = final.ObjVal
        final.write(str(args.solution_out))
    report = {
        "instance": "cmflsp40-36-2-10",
        "method": "exact contiguous-period fix-and-optimize; all item/family setups inside the window and every X recourse variable are free",
        "initial_objective": initial,
        "final_objective": incumbent,
        "elapsed": time.monotonic() - started,
        "trial_count": len(trials),
        "optimal_trials": sum(row["status"] == GRB.OPTIMAL for row in trials),
        "time_limit_trials": sum(row["status"] == GRB.TIME_LIMIT for row in trials),
        "improvements": improvements,
        "final_audit": audit(final) if final.SolCount else None,
        "trials": trials,
    }
    args.summary.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in report.items() if key != "trials"}, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
