#!/usr/bin/env python3
"""
waima_build_reduced.py

Usage:
    python waima_build_reduced.py MODEL SOL OUTPUT_DIR

This program consumes the exact, verified reduction exported by
waima_pairgraph.py, builds the exact S70-aggregated Gurobi model without
optimizing or presolving, reconstructs the public solution, and audits that
solution independently against a fresh exact parse of the original model.

Required waima_pairgraph.py library entry points:

    build_verified_reduction(model_path, sol_path) -> mapping/object
    parse_model_exact(model_path)                  -> mapping/object

The reduction object must expose the canonical fields validated in
_normalize_reduction(). Attribute-based objects and dictionaries are both
accepted. No unsupported case is silently approximated.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
import os
import shutil
import sys
import tempfile
from fractions import Fraction
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, MutableMapping, Sequence, Tuple

import gurobipy as gp
from gurobipy import GRB

import waima_pairgraph as pairgraph


EXPECTED_GROUPS = 12
EXPECTED_COSTLY = 45_732
EXPECTED_COPY = 45_732
EXPECTED_AUX = 1_840
EXPECTED_REPORTING = 14
EXPECTED_ORIGINAL_ROWS = 52_983
EXPECTED_PROJECTED_ROWS = 7_237
EXPECTED_LOCAL_ROWS = 6_632
EXPECTED_PAIR_ROWS = 584
EXPECTED_COVER_ROWS = 21
EXPECTED_PUBLIC_OBJECTIVE = 4_870
EXPECTED_GROUP_SIZE = 3_811
S70_SIZE = 70


class BuildError(RuntimeError):
    pass


def fail(message: str) -> None:
    raise BuildError(message)


def field(obj: Any, name: str, default: Any = None, required: bool = False) -> Any:
    if isinstance(obj, Mapping):
        if name in obj:
            return obj[name]
    elif hasattr(obj, name):
        return getattr(obj, name)
    if required:
        fail(f"Missing required field {name!r}")
    return default


def first_field(
    obj: Any,
    names: Sequence[str],
    default: Any = None,
    required: bool = False,
) -> Any:
    for name in names:
        marker = object()
        value = field(obj, name, marker)
        if value is not marker:
            return value
    if required:
        fail(f"Missing required field; expected one of {list(names)!r}")
    return default


def exact(value: Any) -> Fraction:
    if isinstance(value, Fraction):
        return value
    if isinstance(value, bool):
        return Fraction(int(value), 1)
    if isinstance(value, int):
        return Fraction(value, 1)
    if isinstance(value, str):
        text = value.strip()
        if text.lower() in {"inf", "+inf", "infinity", "+infinity"}:
            fail("Positive infinity passed to exact(); use bound_value()")
        if text.lower() in {"-inf", "-infinity"}:
            fail("Negative infinity passed to exact(); use bound_value()")
        return Fraction(text)
    if isinstance(value, float):
        if not math.isfinite(value):
            fail("Non-finite float passed to exact(); use bound_value()")
        return Fraction(str(value))
    fail(f"Cannot convert {type(value).__name__} to an exact rational")


def bound_value(value: Any) -> Fraction | None:
    """None denotes an infinite bound."""
    if value is None:
        return None
    if isinstance(value, str):
        text = value.strip().lower()
        if text in {"inf", "+inf", "infinity", "+infinity", "-inf", "-infinity"}:
            return None
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return exact(value)


def exact_json(value: Any) -> Any:
    if isinstance(value, Fraction):
        return value.numerator if value.denominator == 1 else f"{value.numerator}/{value.denominator}"
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, Mapping):
        return {str(k): exact_json(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [exact_json(v) for v in value]
    return value


def as_name(value: Any) -> str:
    if isinstance(value, str):
        return value
    name = first_field(value, ("name", "var_name", "column_name"), required=True)
    return str(name)


def normalize_terms(raw: Any) -> Dict[str, Fraction]:
    if raw is None:
        return {}
    result: Dict[str, Fraction] = {}
    items: Iterable[Any]
    if isinstance(raw, Mapping):
        items = raw.items()
    else:
        items = raw

    for item in items:
        if isinstance(item, tuple) and len(item) == 2:
            key, coefficient = item
        elif isinstance(item, list) and len(item) == 2:
            key, coefficient = item
        else:
            key = first_field(item, ("var", "name", "column"), required=True)
            coefficient = first_field(item, ("coef", "coefficient", "value"), required=True)
        name = as_name(key)
        result[name] = result.get(name, Fraction(0)) + exact(coefficient)

    return {name: coefficient for name, coefficient in result.items() if coefficient != 0}


def normalize_variable(raw: Any) -> Dict[str, Any]:
    name = as_name(raw)
    vtype_raw = str(first_field(raw, ("vtype", "type", "vartype"), required=True)).upper()
    aliases = {
        "B": "B",
        "BINARY": "B",
        "I": "I",
        "INTEGER": "I",
        "C": "C",
        "CONTINUOUS": "C",
    }
    if vtype_raw not in aliases:
        fail(f"Unsupported variable type {vtype_raw!r} for {name}")
    return {
        "name": name,
        "lb": bound_value(first_field(raw, ("lb", "lower", "lower_bound"), required=True)),
        "ub": bound_value(first_field(raw, ("ub", "upper", "upper_bound"), required=True)),
        "vtype": aliases[vtype_raw],
        "obj": exact(first_field(raw, ("obj", "objective", "cost"), required=True)),
    }


def normalize_row(raw: Any, fallback_index: int) -> Dict[str, Any]:
    index = int(first_field(raw, ("original_index", "index", "row_index"), default=fallback_index))
    name = str(first_field(raw, ("name", "row_name"), default=f"r{index}"))
    terms = normalize_terms(first_field(raw, ("terms", "coefficients", "coefs"), required=True))

    values_raw = first_field(raw, ("allowed_values", "rhs_values", "equality_values"))
    if values_raw is not None:
        values = sorted(set(exact(v) for v in values_raw))
        if not values:
            fail(f"Row {name}: empty equality-value set")
        return {
            "index": index,
            "name": name,
            "terms": terms,
            "kind": "eqset",
            "values": values,
            "lb": values[0],
            "ub": values[-1],
        }

    sense = first_field(raw, ("sense", "kind"))
    rhs = first_field(raw, ("rhs", "right_hand_side"))
    lb = bound_value(first_field(raw, ("lb", "lower", "lower_bound")))
    ub = bound_value(first_field(raw, ("ub", "upper", "upper_bound")))

    if sense is not None:
        s = str(sense).strip().lower()
        if s in {"<", "<=", "l", "le"}:
            if rhs is None:
                fail(f"Row {name}: <= row has no RHS")
            lb, ub, kind = None, exact(rhs), "le"
        elif s in {">", ">=", "g", "ge"}:
            if rhs is None:
                fail(f"Row {name}: >= row has no RHS")
            lb, ub, kind = exact(rhs), None, "ge"
        elif s in {"=", "e", "eq"}:
            if rhs is None:
                fail(f"Row {name}: equality has no RHS")
            lb = ub = exact(rhs)
            kind = "eq"
        elif s in {"range", "interval", "r"}:
            if lb is None or ub is None:
                fail(f"Row {name}: interval row lacks a finite endpoint")
            kind = "interval"
        else:
            fail(f"Row {name}: unsupported sense {sense!r}")
    else:
        if lb is None and ub is None:
            fail(f"Row {name}: unconstrained row is unsupported")
        if lb is None:
            kind = "le"
        elif ub is None:
            kind = "ge"
        elif lb == ub:
            kind = "eq"
        else:
            kind = "interval"

    if lb is not None and ub is not None and lb > ub:
        fail(f"Row {name}: lower bound exceeds upper bound")

    return {
        "index": index,
        "name": name,
        "terms": terms,
        "kind": kind,
        "values": None,
        "lb": lb,
        "ub": ub,
    }


def normalize_model(raw: Any) -> Dict[str, Any]:
    variables_raw = first_field(raw, ("variables", "vars", "columns"), required=True)
    rows_raw = first_field(raw, ("rows", "constraints"), required=True)
    variables = [normalize_variable(v) for v in variables_raw]
    rows = [normalize_row(r, i) for i, r in enumerate(rows_raw)]
    names = [v["name"] for v in variables]
    if len(names) != len(set(names)):
        fail("Original model contains duplicate variable names")
    return {"variables": variables, "rows": rows}


def normalize_name_map(raw: Any, label: str) -> Dict[str, str]:
    if isinstance(raw, Mapping):
        result = {as_name(k): as_name(v) for k, v in raw.items()}
    else:
        result = {}
        for entry in raw:
            left = first_field(entry, ("copy", "target", "eliminated", "var"), required=True)
            right = first_field(entry, ("source", "representative", "kept"), required=True)
            result[as_name(left)] = as_name(right)
    if len(result) != len(set(result)):
        fail(f"{label}: duplicate map keys")
    return result


def normalize_witnesses(raw: Any, label: str) -> List[Dict[str, Any]]:
    result = []
    for item in raw:
        var = as_name(first_field(item, ("var", "variable", "name"), required=True))
        row = int(first_field(item, ("row", "row_index", "original_row_index"), required=True))
        result.append({"var": var, "row": row})
    if len({x["var"] for x in result}) != len(result):
        fail(f"{label}: duplicate witness variables")
    return result


def normalize_public_values(raw: Any) -> Dict[str, Fraction]:
    if isinstance(raw, Mapping):
        return {as_name(k): exact(v) for k, v in raw.items()}
    result = {}
    for item in raw:
        name = as_name(first_field(item, ("var", "name", "variable"), required=True))
        value = exact(first_field(item, ("value", "x"), required=True))
        result[name] = value
    return result


def normalize_color_classes(raw_group: Any) -> List[Dict[str, Any]]:
    raw = first_field(raw_group, ("color_classes", "classes", "refined_classes"), required=True)
    result = []
    if isinstance(raw, Mapping):
        iterable = raw.items()
    else:
        iterable = enumerate(raw)

    for fallback, item in iterable:
        if isinstance(item, tuple) and len(item) == 2:
            key, value = item
        else:
            key, value = fallback, item

        if isinstance(value, Mapping) or hasattr(value, "__dict__"):
            ordinal = int(first_field(value, ("ordinal", "color", "index"), default=key))
            members_raw = first_field(value, ("members", "variables", "vars"), required=True)
        else:
            ordinal = int(key)
            members_raw = value

        result.append({
            "ordinal": ordinal,
            "members": sorted(as_name(v) for v in members_raw),
        })
    return result


def _normalize_reduction(raw: Any) -> Dict[str, Any]:
    projected_variables_raw = first_field(
        raw, ("projected_variables", "costly_variables", "kept_variables"), required=True
    )
    projected_rows_raw = first_field(
        raw, ("projected_rows", "reduced_rows", "constraints"), required=True
    )
    groups_raw = first_field(raw, ("groups", "variable_groups"), required=True)

    projected_variables = [normalize_variable(v) for v in projected_variables_raw]
    projected_rows = [normalize_row(r, i) for i, r in enumerate(projected_rows_raw)]

    groups = []
    for fallback, group in enumerate(groups_raw):
        group_index = int(first_field(group, ("index", "group", "group_index"), default=fallback))
        members = sorted(
            as_name(v)
            for v in first_field(group, ("members", "variables", "costly_variables"), required=True)
        )
        groups.append({
            "index": group_index,
            "members": members,
            "color_classes": normalize_color_classes(group),
        })
    groups.sort(key=lambda g: g["index"])

    copy_map = normalize_name_map(
        first_field(raw, ("copy_map", "equality_copy_map", "copies"), required=True),
        "copy_map",
    )
    aux = normalize_witnesses(
        first_field(raw, ("auxiliary_witnesses", "aux_witnesses", "auxiliaries"), required=True),
        "auxiliary_witnesses",
    )
    reporting = normalize_witnesses(
        first_field(raw, ("reporting_witnesses", "reporting_variables", "reporting"), required=True),
        "reporting_witnesses",
    )
    public_values = normalize_public_values(
        first_field(raw, ("public_values", "public_solution", "solution_values"), required=True)
    )

    row_classes_raw = first_field(raw, ("row_classes", "classification"), required=True)
    if not isinstance(row_classes_raw, Mapping):
        fail("row_classes must be a mapping")
    row_classes = {str(k): int(v) for k, v in row_classes_raw.items()}

    return {
        "projected_variables": projected_variables,
        "projected_rows": projected_rows,
        "groups": groups,
        "copy_map": copy_map,
        "auxiliary_witnesses": aux,
        "reporting_witnesses": reporting,
        "public_values": public_values,
        "row_classes": row_classes,
    }


def call_reduction_builder(model_path: str, sol_path: str) -> Any:
    builder = getattr(pairgraph, "build_verified_reduction", None)
    if not callable(builder):
        fail(
            "waima_pairgraph.py must export "
            "build_verified_reduction(model_path, sol_path)"
        )
    return builder(model_path, sol_path)


def parse_original_fresh(model_path: str) -> Dict[str, Any]:
    parser = getattr(pairgraph, "parse_model_exact", None)
    if not callable(parser):
        fail("waima_pairgraph.py must export parse_model_exact(model_path)")
    return normalize_model(parser(model_path))


def integer_value(value: Fraction, context: str) -> int:
    if value.denominator != 1:
        fail(f"{context} is not integral: {value}")
    return value.numerator


def gurobi_number(value: Fraction, context: str) -> float:
    converted = float(value)
    if not math.isfinite(converted):
        fail(f"{context} cannot be represented by Gurobi")
    if value.denominator == 1 and abs(value.numerator) > 2**53:
        fail(f"{context} exceeds exact IEEE-754 integer range")
    if Fraction.from_float(converted) != value and value.denominator == 1:
        fail(f"{context} lost integral precision in Gurobi conversion")
    return converted


def atomic_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
            json.dump(exact_json(data), handle, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    except BaseException:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
        raise


def atomic_gzip_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    os.close(fd)
    try:
        with gzip.open(temporary, "wt", encoding="utf-8", newline="\n") as handle:
            handle.write(text)
        os.replace(temporary, path)
    except BaseException:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
        raise


def atomic_gurobi_write(model: gp.Model, destination: Path, suffix: str) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    workdir = Path(tempfile.mkdtemp(prefix=f".{destination.name}.", dir=str(destination.parent)))
    try:
        raw = workdir / f"artifact{suffix}"
        model.write(str(raw))
        if destination.name.endswith(".gz"):
            uncompressed = destination.name[:-3]
            if suffix.endswith(".gz"):
                produced = raw
            else:
                produced = raw
                compressed = workdir / (Path(uncompressed).name + ".gz")
                with produced.open("rb") as source, gzip.open(compressed, "wb") as target:
                    shutil.copyfileobj(source, target)
                produced = compressed
        else:
            produced = raw
        os.replace(produced, destination)
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def assert_verified_counts(reduction: Dict[str, Any], original: Dict[str, Any]) -> None:
    variables = reduction["projected_variables"]
    groups = reduction["groups"]
    rows = reduction["projected_rows"]
    classes = reduction["row_classes"]

    if len(groups) != EXPECTED_GROUPS:
        fail(f"Expected {EXPECTED_GROUPS} groups, found {len(groups)}")
    if len(variables) != EXPECTED_COSTLY:
        fail(f"Expected {EXPECTED_COSTLY} costly variables, found {len(variables)}")
    if len(rows) != EXPECTED_PROJECTED_ROWS:
        fail(f"Expected {EXPECTED_PROJECTED_ROWS} projected rows, found {len(rows)}")
    if len(reduction["copy_map"]) != EXPECTED_COPY:
        fail(f"Expected {EXPECTED_COPY} equality copies")
    if len(reduction["auxiliary_witnesses"]) != EXPECTED_AUX:
        fail(f"Expected {EXPECTED_AUX} auxiliary witnesses")
    if len(reduction["reporting_witnesses"]) != EXPECTED_REPORTING:
        fail(f"Expected {EXPECTED_REPORTING} reporting variables")
    if len(original["rows"]) != EXPECTED_ORIGINAL_ROWS:
        fail(f"Expected {EXPECTED_ORIGINAL_ROWS} original rows, found {len(original['rows'])}")

    if [g["index"] for g in groups] != list(range(EXPECTED_GROUPS)):
        fail("Group indices are not exactly 0..11")
    for group in groups:
        if len(group["members"]) != EXPECTED_GROUP_SIZE:
            fail(
                f"Group {group['index']} has {len(group['members'])} members; "
                f"expected {EXPECTED_GROUP_SIZE}"
            )

    expected_classes = {
        "local": EXPECTED_LOCAL_ROWS,
        "pair": EXPECTED_PAIR_ROWS,
        "cover": EXPECTED_COVER_ROWS,
    }
    for key, expected in expected_classes.items():
        aliases = {
            "local": ("local", "local_rows"),
            "pair": ("pair", "pair_rows", "compatibility"),
            "cover": ("cover", "cover_rows", "global_cover"),
        }[key]
        found = None
        for alias in aliases:
            if alias in classes:
                found = classes[alias]
                break
        if found != expected:
            fail(f"Expected {expected} {key} rows, found {found}")

    variable_names = {v["name"] for v in variables}
    grouped = [name for group in groups for name in group["members"]]
    if len(grouped) != EXPECTED_COSTLY or set(grouped) != variable_names:
        fail("Groups do not partition the 45,732 projected costly variables")


def recover_and_prove_s70(
    reduction: Dict[str, Any],
) -> Tuple[Dict[int, List[str]], Dict[str, int], Dict[str, Any]]:
    variables = {v["name"]: v for v in reduction["projected_variables"]}
    rows = sorted(reduction["projected_rows"], key=lambda r: r["index"])
    if len({r["index"] for r in rows}) != len(rows):
        fail("Projected rows do not have unique fixed original projected-row indices")

    row_indices = tuple(r["index"] for r in rows)
    sparse_vectors: Dict[str, List[Tuple[int, Fraction]]] = {
        name: [] for name in variables
    }
    for row in rows:
        for name, coefficient in row["terms"].items():
            if name not in sparse_vectors:
                fail(f"Projected row {row['name']} references unknown variable {name}")
            sparse_vectors[name].append((row["index"], coefficient))
    signatures: Dict[str, Tuple[Any, ...]] = {}
    for name, var in variables.items():
        signatures[name] = (
            var["obj"],
            var["vtype"],
            var["lb"],
            var["ub"],
            tuple(sparse_vectors[name]),
        )

    s70: Dict[int, List[str]] = {}
    membership: Dict[str, int] = {}
    proofs: Dict[str, Any] = {}

    for group in reduction["groups"]:
        candidates = [
            c for c in group["color_classes"]
            if len(c["members"]) == S70_SIZE
        ]
        if len(candidates) != 1:
            fail(
                f"Group {group['index']}: expected exactly one non-singleton "
                f"color class of size {S70_SIZE}, found {len(candidates)}"
            )
        members = candidates[0]["members"]
        if not set(members).issubset(set(group["members"])):
            fail(f"Group {group['index']}: S70 contains a member outside its group")
        reference = signatures[members[0]]
        for member in members:
            if signatures[member] != reference:
                fail(
                    f"Group {group['index']}: S70 member {member} is not exactly "
                    f"interchangeable with {members[0]}"
                )
            membership[member] = group["index"]

        var = variables[members[0]]
        if var["vtype"] not in {"B", "I"} or var["lb"] != 0 or var["ub"] != 1:
            fail(
                f"Group {group['index']}: S70 members are not 0/1 binary "
                f"variables; reference={members[0]!r}, vtype={var['vtype']!r}, "
                f"lb={var['lb']!r}, ub={var['ub']!r}"
            )

        s70[group["index"]] = members
        proofs[str(group["index"])] = {
            "color_id": candidates[0]["ordinal"],
            "multiplicity": len(members),
            "reference": members[0],
            "objective": var["obj"],
            "type": var["vtype"],
            "lb": var["lb"],
            "ub": var["ub"],
            "projected_row_indices_sha256": hashlib.sha256(
                ",".join(str(i) for i in row_indices).encode("ascii")
            ).hexdigest(),
            "full_coefficient_vector_sha256": hashlib.sha256(
                ",".join(
                    f"{row_index}:{coefficient}"
                    for row_index, coefficient in reference[-1]
                ).encode("ascii")
            ).hexdigest(),
        }

    copies = reduction["copy_map"]
    if len(set(copies.keys())) != EXPECTED_COPY:
        fail("Equality-copy mapping is not one-to-one on copy variables")
    if len(set(copies.values())) != EXPECTED_COPY:
        fail("Equality-copy mapping is not one-to-one on representatives")
    if set(copies.values()) != set(variables):
        fail("Equality-copy map does not map bijectively onto all costly representatives")

    for group_index, members in s70.items():
        if len(members) < 5:
            fail(
                f"Group {group_index}: S70 multiplicity {len(members)} is too small "
                "to expand every count k <= 5"
            )

    return s70, membership, proofs


def add_projected_rows(
    model: gp.Model,
    rows: Sequence[Dict[str, Any]],
    aggregate_vars: Mapping[str, gp.Var],
    s70_by_name: Mapping[str, int],
    z_vars: Mapping[int, gp.Var],
) -> int:
    added = 0
    for row in sorted(rows, key=lambda r: r["index"]):
        expression = gp.LinExpr()
        z_coefficients: Dict[int, Fraction] = {}

        for name, coefficient in row["terms"].items():
            if name in s70_by_name:
                group = s70_by_name[name]
                existing = z_coefficients.get(group)
                if existing is None:
                    z_coefficients[group] = coefficient
                elif existing != coefficient:
                    fail(
                        f"Row {row['name']}: S70 coefficients differ inside group {group}"
                    )
            else:
                if name not in aggregate_vars:
                    fail(f"Row {row['name']}: unknown projected variable {name}")
                expression.add(
                    aggregate_vars[name],
                    gurobi_number(coefficient, f"coefficient {row['name']}/{name}"),
                )

        for group, coefficient in z_coefficients.items():
            expression.add(
                z_vars[group],
                gurobi_number(coefficient, f"S70 coefficient {row['name']}/group {group}"),
            )

        base = f"p{row['index']}__{row['name']}"
        if row["kind"] == "eqset":
            values = row["values"]
            for left, right in zip(values, values[1:]):
                if right - left != 1:
                    fail(
                        f"Row {row['name']}: non-contiguous equality set "
                        f"{[str(v) for v in values]}"
                    )
            if len(values) == 1:
                model.addConstr(
                    expression == gurobi_number(values[0], f"RHS {row['name']}"),
                    name=base,
                )
                added += 1
            else:
                model.addConstr(
                    expression >= gurobi_number(values[0], f"lower RHS {row['name']}"),
                    name=base + "__lo",
                )
                model.addConstr(
                    expression <= gurobi_number(values[-1], f"upper RHS {row['name']}"),
                    name=base + "__hi",
                )
                added += 2
        elif row["kind"] == "le":
            model.addConstr(
                expression <= gurobi_number(row["ub"], f"RHS {row['name']}"),
                name=base,
            )
            added += 1
        elif row["kind"] == "ge":
            model.addConstr(
                expression >= gurobi_number(row["lb"], f"RHS {row['name']}"),
                name=base,
            )
            added += 1
        elif row["kind"] == "eq":
            model.addConstr(
                expression == gurobi_number(row["lb"], f"RHS {row['name']}"),
                name=base,
            )
            added += 1
        elif row["kind"] == "interval":
            if row["lb"] is None or row["ub"] is None:
                fail(f"Row {row['name']}: malformed interval")
            model.addConstr(
                expression >= gurobi_number(row["lb"], f"lower RHS {row['name']}"),
                name=base + "__lo",
            )
            model.addConstr(
                expression <= gurobi_number(row["ub"], f"upper RHS {row['name']}"),
                name=base + "__hi",
            )
            added += 2
        else:
            fail(f"Row {row['name']}: unsupported normalized kind {row['kind']}")
    return added


def build_aggregated_model(
    reduction: Dict[str, Any],
    s70: Mapping[int, List[str]],
    s70_by_name: Mapping[str, int],
) -> Tuple[gp.Model, Dict[str, gp.Var], Dict[int, gp.Var], Dict[str, Fraction], int]:
    variables = {v["name"]: v for v in reduction["projected_variables"]}
    model = gp.Model("neos-4533806-waima-exact-aggregated")

    aggregate_vars: Dict[str, gp.Var] = {}
    objective_coefficients: Dict[str, Fraction] = {}

    for name in sorted(variables):
        if name in s70_by_name:
            continue
        var = variables[name]
        if var["vtype"] not in {"B", "I"} or var["lb"] != 0 or var["ub"] != 1:
            fail(f"Retained costly representative {name} is not a 0/1 binary")
        coefficient = integer_value(var["obj"], f"objective coefficient of {name}")
        if coefficient <= 0:
            fail(f"Retained costly representative {name} lacks positive integer cost")
        aggregate_vars[name] = model.addVar(
            lb=0.0,
            ub=1.0,
            obj=float(coefficient),
            vtype=GRB.BINARY,
            name=name,
        )
        objective_coefficients[name] = var["obj"]

    z_vars: Dict[int, gp.Var] = {}
    for group in range(EXPECTED_GROUPS):
        members = s70[group]
        reference = variables[members[0]]
        coefficient = integer_value(
            reference["obj"], f"S70 objective coefficient for group {group}"
        )
        if coefficient <= 0:
            fail(f"Group {group}: S70 lacks positive integer cost")
        z_vars[group] = model.addVar(
            lb=0.0,
            ub=5.0,
            obj=float(coefficient),
            vtype=GRB.INTEGER,
            name=f"z_S70_g{group}",
        )
        objective_coefficients[f"z_S70_g{group}"] = reference["obj"]

    model.ModelSense = GRB.MINIMIZE
    model.update()
    added_rows = add_projected_rows(
        model,
        reduction["projected_rows"],
        aggregate_vars,
        s70_by_name,
        z_vars,
    )
    model.update()
    return model, aggregate_vars, z_vars, objective_coefficients, added_rows


def make_public_start(
    reduction: Dict[str, Any],
    s70: Mapping[int, List[str]],
    s70_by_name: Mapping[str, int],
    aggregate_vars: Mapping[str, gp.Var],
    z_vars: Mapping[int, gp.Var],
) -> Tuple[Dict[str, Fraction], Dict[int, int]]:
    public = reduction["public_values"]
    start: Dict[str, Fraction] = {}
    z_counts: Dict[int, int] = {}

    for name, variable in aggregate_vars.items():
        if name not in public:
            fail(f"Public solution does not provide costly variable {name}")
        value = public[name]
        if value not in {0, 1}:
            fail(f"Public costly variable {name} is not binary: {value}")
        variable.Start = float(value)
        start[name] = value

    for group, members in s70.items():
        missing = [name for name in members if name not in public]
        if missing:
            fail(
                f"Public solution lacks {len(missing)} S70 member values in group {group}"
            )
        count = sum(integer_value(public[name], f"public value {name}") for name in members)
        if count < 0 or count > 5:
            fail(f"Public S70 count for group {group} is outside 0..5: {count}")
        for name in members:
            if public[name] not in {0, 1}:
                fail(f"Public S70 member {name} is not binary")
        z_vars[group].Start = float(count)
        start[f"z_S70_g{group}"] = Fraction(count)
        z_counts[group] = count

    return start, z_counts


def expand_costly_start(
    reduction: Dict[str, Any],
    s70: Mapping[int, List[str]],
    z_counts: Mapping[int, int],
) -> Tuple[Dict[str, Fraction], Dict[int, List[str]], Dict[int, str]]:
    public = reduction["public_values"]
    expanded: Dict[str, Fraction] = {}
    chosen: Dict[int, List[str]] = {}
    expansion_mode: Dict[int, str] = {}

    s70_names = {name for members in s70.values() for name in members}
    for variable in reduction["projected_variables"]:
        name = variable["name"]
        if name in s70_names:
            continue
        if name not in public:
            fail(f"Cannot expand public start: missing costly variable {name}")
        expanded[name] = public[name]

    for group, members in s70.items():
        count = z_counts[group]
        exact_selected = [
            name for name in members
            if name in public and public[name] == 1
        ]
        complete = all(name in public and public[name] in {0, 1} for name in members)
        if complete and len(exact_selected) == count:
            selected = sorted(exact_selected)
            expansion_mode[group] = "exact-original-public-members"
        else:
            selected = sorted(members)[:count]
            expansion_mode[group] = "deterministic-distinct-representatives"
        if len(selected) != count or len(set(selected)) != count:
            fail(f"Group {group}: failed deterministic distinct S70 expansion")
        selected_set = set(selected)
        chosen[group] = selected
        for name in members:
            expanded[name] = Fraction(int(name in selected_set))

    if len(expanded) != EXPECTED_COSTLY:
        fail(f"Expanded costly vector has {len(expanded)} values, expected {EXPECTED_COSTLY}")
    return expanded, chosen, expansion_mode


def original_rows_by_index(original: Dict[str, Any]) -> Dict[int, Dict[str, Any]]:
    result = {}
    for row in original["rows"]:
        if row["index"] in result:
            fail(f"Original rows have duplicate index {row['index']}")
        result[row["index"]] = row
    return result


def solve_degree_one_witnesses(
    values: MutableMapping[str, Fraction],
    witnesses: Sequence[Dict[str, Any]],
    rows: Mapping[int, Dict[str, Any]],
    label: str,
) -> None:
    pending = list(witnesses)
    while pending:
        progress = False
        next_pending = []
        for witness in pending:
            name = witness["var"]
            row_index = witness["row"]
            if row_index not in rows:
                fail(f"{label} witness {name}: original row {row_index} does not exist")
            row = rows[row_index]
            coefficient = row["terms"].get(name, Fraction(0))
            if coefficient == 0:
                fail(f"{label} witness {name}: row {row_index} has zero coefficient")

            unknown_others = [
                other for other in row["terms"]
                if other != name and other not in values
            ]
            if unknown_others:
                next_pending.append(witness)
                continue

            residual = sum(
                coefficient_other * values[other]
                for other, coefficient_other in row["terms"].items()
                if other != name
            )
            if row["lb"] is None or row["ub"] is None or row["lb"] != row["ub"]:
                fail(
                    f"{label} witness {name}: row {row_index} is not a singleton equality"
                )
            values[name] = (row["lb"] - residual) / coefficient
            progress = True

        if not progress:
            descriptions = [
                f"{w['var']}@row{w['row']}" for w in next_pending[:10]
            ]
            fail(
                f"Cannot reconstruct {label} witnesses; unresolved dependency cycle or "
                f"non-degree-one rows: {descriptions}"
            )
        pending = next_pending


def reconstruct_original_solution(
    reduction: Dict[str, Any],
    original: Dict[str, Any],
    costly_values: Mapping[str, Fraction],
) -> Dict[str, Fraction]:
    values: Dict[str, Fraction] = dict(costly_values)

    for copy_name, representative in sorted(reduction["copy_map"].items()):
        if representative not in costly_values:
            fail(f"Copy {copy_name} maps to unknown representative {representative}")
        if copy_name in values:
            fail(f"Copy variable {copy_name} collides with a costly representative")
        values[copy_name] = costly_values[representative]

    # This module round-trips the supplied public witness.  Some projected
    # degree-one auxiliaries occur in inequalities, so they cannot be recovered
    # by treating every witness row as an equality.  Preserve their exact
    # supplied values here; the independent original-row audit below proves
    # that the reconstructed public vector is valid.  A future candidate
    # decoder must choose inequality endpoints/subset-sum witnesses explicitly.
    public = reduction["public_values"]
    for witness in (
        list(reduction["auxiliary_witnesses"])
        + list(reduction["reporting_witnesses"])
    ):
        name = witness["var"]
        if name not in public:
            fail(f"Public solution lacks eliminated variable {name}")
        if name in values:
            fail(f"Eliminated variable {name} collides during reconstruction")
        values[name] = public[name]

    original_names = {v["name"] for v in original["variables"]}
    missing = sorted(original_names - set(values))
    extra = sorted(set(values) - original_names)
    if missing or extra:
        fail(
            f"Reconstruction does not match original variables: "
            f"missing={missing[:10]}, extra={extra[:10]}"
        )
    return values


def row_violation(row: Dict[str, Any], activity: Fraction) -> Fraction:
    if row["kind"] == "eqset":
        if activity in set(row["values"]):
            return Fraction(0)
        return min(abs(activity - value) for value in row["values"])
    violation = Fraction(0)
    if row["lb"] is not None and activity < row["lb"]:
        violation = max(violation, row["lb"] - activity)
    if row["ub"] is not None and activity > row["ub"]:
        violation = max(violation, activity - row["ub"])
    return violation


def independently_audit(
    original: Dict[str, Any],
    values: Mapping[str, Fraction],
    expected_objective: Fraction | None = EXPECTED_PUBLIC_OBJECTIVE,
) -> Dict[str, Any]:
    variables = {v["name"]: v for v in original["variables"]}
    if set(values) != set(variables):
        fail("Independent audit received an incomplete or oversized variable vector")

    bound_violations = []
    integrality_violations = []
    for name, var in variables.items():
        value = values[name]
        if var["lb"] is not None and value < var["lb"]:
            bound_violations.append((name, value, var["lb"], var["ub"]))
        if var["ub"] is not None and value > var["ub"]:
            bound_violations.append((name, value, var["lb"], var["ub"]))
        if var["vtype"] in {"B", "I"} and value.denominator != 1:
            integrality_violations.append((name, value))
        if var["vtype"] == "B" and value not in {0, 1}:
            integrality_violations.append((name, value))

    row_violations = []
    maximum_row_violation = Fraction(0)
    for row in original["rows"]:
        activity = sum(
            coefficient * values[name]
            for name, coefficient in row["terms"].items()
        )
        violation = row_violation(row, activity)
        maximum_row_violation = max(maximum_row_violation, violation)
        if violation:
            row_violations.append((row["index"], row["name"], activity, violation))

    objective = sum(var["obj"] * values[name] for name, var in variables.items())
    if expected_objective is not None and objective != expected_objective:
        fail(
            f"Independent original-model objective is {objective}, "
            f"expected {expected_objective}"
        )
    if bound_violations:
        fail(f"Independent audit found bound violations: {bound_violations[:10]}")
    if integrality_violations:
        fail(
            f"Independent audit found integrality violations: "
            f"{integrality_violations[:10]}"
        )
    if row_violations:
        fail(f"Independent audit found row violations: {row_violations[:10]}")

    return {
        "original_rows_checked": len(original["rows"]),
        "original_variables_checked": len(original["variables"]),
        "row_violations": 0,
        "bound_violations": 0,
        "integrality_violations": 0,
        "maximum_row_violation": maximum_row_violation,
        "objective": objective,
    }


def write_reconstructed_solution(path: Path, values: Mapping[str, Fraction]) -> None:
    lines = [
        "# Exact reconstructed public solution for neos-4533806-waima",
        f"# Objective value = {EXPECTED_PUBLIC_OBJECTIVE}",
    ]
    for name in sorted(values):
        value = values[name]
        rendered = (
            str(value.numerator)
            if value.denominator == 1
            else f"{value.numerator}/{value.denominator}"
        )
        lines.append(f"{name} {rendered}")
    atomic_gzip_text(path, "\n".join(lines) + "\n")


def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("MODEL")
    parser.add_argument("SOL")
    parser.add_argument("OUTPUT_DIR")
    return parser.parse_args()


def main() -> int:
    args = parse_arguments()
    model_path = Path(args.MODEL).resolve()
    solution_path = Path(args.SOL).resolve()
    output_dir = Path(args.OUTPUT_DIR).resolve()

    if not model_path.is_file():
        fail(f"MODEL does not exist or is not a file: {model_path}")
    if not solution_path.is_file():
        fail(f"SOL does not exist or is not a file: {solution_path}")
    output_dir.mkdir(parents=True, exist_ok=True)
    if not output_dir.is_dir():
        fail(f"OUTPUT_DIR is not a directory: {output_dir}")

    reduction = _normalize_reduction(
        call_reduction_builder(str(model_path), str(solution_path))
    )

    # Deliberately parse the original model again. The final audit therefore
    # reads original rows directly and is independent of projected feasibility.
    original = parse_original_fresh(str(model_path))

    assert_verified_counts(reduction, original)
    s70, s70_by_name, aggregation_proofs = recover_and_prove_s70(reduction)

    model, aggregate_vars, z_vars, objective_coefficients, emitted_rows = (
        build_aggregated_model(reduction, s70, s70_by_name)
    )
    public_start, z_counts = make_public_start(
        reduction, s70, s70_by_name, aggregate_vars, z_vars
    )

    costly_values, selected_s70, expansion_mode = expand_costly_start(
        reduction, s70, z_counts
    )
    reconstructed = reconstruct_original_solution(reduction, original, costly_values)
    audit = independently_audit(original, reconstructed)

    aggregated_mps = output_dir / "aggregated.mps.gz"
    public_mst = output_dir / "public-start.mst"
    aggregation_map_path = output_dir / "aggregation-map.json"
    report_path = output_dir / "build-report.json"
    reconstructed_path = output_dir / "reconstructed-public.sol.gz"

    # No optimize(), presolve(), relax(), fixed(), or parameter tuning occurs.
    atomic_gurobi_write(model, aggregated_mps, ".mps")
    atomic_gurobi_write(model, public_mst, ".mst")
    write_reconstructed_solution(reconstructed_path, reconstructed)

    aggregation_map = {
        "schema": 1,
        "aggregation": "exact-S70-count",
        "groups": {
            str(group): {
                "aggregate_variable": f"z_S70_g{group}",
                "lower_bound": 0,
                "upper_bound": 5,
                "multiplicity": len(s70[group]),
                "members": s70[group],
                "public_count": z_counts[group],
                "public_expansion_mode": expansion_mode[group],
                "public_selected_members": selected_s70[group],
                "proof": aggregation_proofs[str(group)],
            }
            for group in range(EXPECTED_GROUPS)
        },
        "copy_bijection": {
            "copy_count": len(reduction["copy_map"]),
            "representative_count": len(set(reduction["copy_map"].values())),
            "map": reduction["copy_map"],
        },
    }
    atomic_json(aggregation_map_path, aggregation_map)

    checksums_before_report = {
        "input_model_sha256": sha256_file(model_path),
        "input_solution_sha256": sha256_file(solution_path),
        "aggregated_mps_gz_sha256": sha256_file(aggregated_mps),
        "public_start_mst_sha256": sha256_file(public_mst),
        "aggregation_map_json_sha256": sha256_file(aggregation_map_path),
        "reconstructed_public_sol_gz_sha256": sha256_file(reconstructed_path),
    }

    report = {
        "schema": 1,
        "instance": "neos-4533806-waima",
        "status": "success",
        "verified_counts": {
            "groups": len(reduction["groups"]),
            "costly_representatives": len(reduction["projected_variables"]),
            "costly_per_group": EXPECTED_GROUP_SIZE,
            "equality_copies": len(reduction["copy_map"]),
            "degree_one_auxiliary_witnesses": len(reduction["auxiliary_witnesses"]),
            "reporting_continuous_values": len(reduction["reporting_witnesses"]),
            "projected_constraints": len(reduction["projected_rows"]),
            "local_rows": EXPECTED_LOCAL_ROWS,
            "pair_rows": EXPECTED_PAIR_ROWS,
            "positive_unit_covering_rows": EXPECTED_COVER_ROWS,
            "original_rows": len(original["rows"]),
        },
        "aggregated_model": {
            "variables": model.NumVars,
            "binary_variables": sum(
                1 for variable in model.getVars() if variable.VType == GRB.BINARY
            ),
            "integer_count_variables": len(z_vars),
            "projected_constraint_objects": len(reduction["projected_rows"]),
            "emitted_linear_rows": emitted_rows,
            "gurobi_constraints": model.NumConstrs,
            "objective_sense": "minimize",
            "objective_coefficients_positive_integers": all(
                coefficient.denominator == 1 and coefficient > 0
                for coefficient in objective_coefficients.values()
            ),
        },
        "s70_multiplicities": {
            str(group): len(s70[group]) for group in range(EXPECTED_GROUPS)
        },
        "public_start": {
            "aggregated_values": public_start,
            "z_counts": z_counts,
            "expanded_costly_variables": len(costly_values),
            "reconstructed_original_variables": len(reconstructed),
        },
        "independent_original_model_audit": audit,
        "checksums": checksums_before_report,
        "solver_optimization_seconds": 0,
        "optimize_called": False,
        "presolve_called": False,
    }
    atomic_json(report_path, report)

    final_summary = {
        "status": "success",
        "output_dir": str(output_dir),
        "aggregated_variables": model.NumVars,
        "aggregated_rows": model.NumConstrs,
        "s70_multiplicities": {
            str(group): len(s70[group]) for group in range(EXPECTED_GROUPS)
        },
        "violations": 0,
        "objective": EXPECTED_PUBLIC_OBJECTIVE,
        "solver_optimization_seconds": 0,
        "build_report_sha256": sha256_file(report_path),
    }
    print(json.dumps(final_summary, sort_keys=True))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except BuildError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(2)
