#!/usr/bin/env python3
from __future__ import annotations

import argparse
import gzip
import inspect
import json
import math
import os
import shutil
import sys
import tempfile
import time
from fractions import Fraction
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence, Tuple

import gurobipy as gp
from gurobipy import GRB

import waima_pairgraph as pairgraph
import waima_build_reduced as builder
import waima_solve_reduced as reduced_solver


PUBLIC_OBJECTIVE = Fraction(4870)
INT_TOL = 1e-6
EXPECTED_GROUPS = 12
PATHS: Tuple[Tuple[int, int, int], ...] = (
    (0, 1, 2),
    (3, 4, 5),
    (6, 7, 8),
    (9, 10, 11),
)


class HeuristicError(RuntimeError):
    pass


def fail(message: str) -> None:
    raise HeuristicError(message)


def json_value(value: Any) -> Any:
    if isinstance(value, Fraction):
        return value.numerator if value.denominator == 1 else f"{value.numerator}/{value.denominator}"
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, Mapping):
        return {str(k): json_value(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_value(v) for v in value]
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def atomic_bytes(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    except BaseException:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
        raise


def atomic_text(path: Path, text: str) -> None:
    atomic_bytes(path, text.encode("utf-8"))


def atomic_json(path: Path, data: Any) -> None:
    atomic_text(
        path,
        json.dumps(json_value(data), indent=2, sort_keys=True) + "\n",
    )


def atomic_copy(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(
        prefix=f".{destination.name}.", dir=str(destination.parent)
    )
    os.close(fd)
    try:
        shutil.copyfile(source, temporary)
        os.replace(temporary, destination)
    except BaseException:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
        raise


def atomic_gzip_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as raw:
            with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as compressed:
                compressed.write(text.encode("utf-8"))
            raw.flush()
            os.fsync(raw.fileno())
        os.replace(temporary, path)
    except BaseException:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
        raise


def normalize_reduction(raw: Any) -> Mapping[str, Any]:
    normalizer = getattr(builder, "_normalize_reduction", None)
    return normalizer(raw) if callable(normalizer) else raw


def build_reduction(model_path: Path, solution_path: Path) -> Mapping[str, Any]:
    function = getattr(builder, "build_verified_reduction", None)
    if not callable(function):
        function = getattr(builder, "call_reduction_builder", None)
    if not callable(function):
        function = getattr(pairgraph, "build_verified_reduction", None)
    if not callable(function):
        fail("No verified build_verified_reduction entry point is available")
    return normalize_reduction(function(str(model_path), str(solution_path)))


def parse_original(model_path: Path) -> Any:
    function = getattr(builder, "parse_original_fresh", None)
    if callable(function):
        return function(str(model_path))

    parser = getattr(pairgraph, "parse_model_exact", None)
    normalizer = getattr(builder, "normalize_model", None)
    if not callable(parser) or not callable(normalizer):
        fail("Verified exact original-model parser is unavailable")
    return normalizer(parser(str(model_path)))


def recover_s70(reduction: Mapping[str, Any]) -> Mapping[int, Sequence[str]]:
    function = getattr(builder, "recover_and_prove_s70", None)
    if callable(function):
        result = function(reduction)
        if not isinstance(result, tuple) or not result:
            fail("recover_and_prove_s70 returned an unsupported result")
        return result[0]

    groups: Dict[int, Sequence[str]] = {}
    for group in reduction["groups"]:
        index = int(group["index"])
        classes = [
            color_class
            for color_class in group["color_classes"]
            if int(color_class["ordinal"]) == 70 and len(color_class["members"]) > 1
        ]
        if len(classes) != 1:
            fail(f"Group {index} does not have one verified non-singleton S70 class")
        groups[index] = tuple(classes[0]["members"])
    return groups


def exact_integral(value: float, name: str) -> int:
    if not math.isfinite(value):
        fail(f"{name}: non-finite solution value")
    rounded = round(value)
    if abs(value - rounded) > INT_TOL:
        fail(f"{name}: value {value!r} is not integral within tolerance {INT_TOL}")
    return int(rounded)


def initial_start(model: gp.Model) -> Dict[str, int]:
    values: Dict[str, int] = {}
    for variable in model.getVars():
        start = variable.Start
        if start == GRB.UNDEFINED or not math.isfinite(start) or abs(start) >= 1e100:
            fail(f"Public MIP start is incomplete at {variable.VarName}")
        value = exact_integral(start, variable.VarName)
        if variable.VType == GRB.BINARY and value not in (0, 1):
            fail(f"Binary start {variable.VarName} has value {value}")
        if (
            variable.VType == GRB.INTEGER
            and abs(variable.LB) <= INT_TOL
            and abs(variable.UB - 1.0) <= INT_TOL
            and value not in (0, 1)
        ):
            fail(f"0/1 integer start {variable.VarName} has value {value}")
        if value < math.ceil(variable.LB - INT_TOL):
            fail(f"Start for {variable.VarName} is below its lower bound")
        if value > math.floor(variable.UB + INT_TOL):
            fail(f"Start for {variable.VarName} is above its upper bound")
        values[variable.VarName] = value
    return values


def construct_group_map(
    reduction: Mapping[str, Any],
    aggregation_map: Mapping[str, Any],
    model: gp.Model,
) -> Dict[str, int]:
    group_of: Dict[str, int] = {}

    for group in reduction["groups"]:
        index = int(group["index"])
        if index not in range(EXPECTED_GROUPS):
            fail(f"Unexpected group index {index}")
        for member in group["members"]:
            name = str(member)
            if name in group_of and group_of[name] != index:
                fail(f"Projected variable {name} occurs in multiple groups")
            group_of[name] = index

    for group_text, info in aggregation_map["groups"].items():
        index = int(group_text)
        z_name = str(info["aggregate_variable"])
        group_of[z_name] = index

    model_names = {variable.VarName for variable in model.getVars()}
    unknown = sorted(model_names - set(group_of))
    if unknown:
        fail(
            "Aggregated model contains variables without verified group membership: "
            + ", ".join(unknown[:10])
        )
    return {name: group_of[name] for name in model_names}


def status_name(status: int) -> str:
    names = {
        GRB.LOADED: "LOADED",
        GRB.OPTIMAL: "OPTIMAL",
        GRB.INFEASIBLE: "INFEASIBLE",
        GRB.INF_OR_UNBD: "INF_OR_UNBD",
        GRB.UNBOUNDED: "UNBOUNDED",
        GRB.CUTOFF: "CUTOFF",
        GRB.ITERATION_LIMIT: "ITERATION_LIMIT",
        GRB.NODE_LIMIT: "NODE_LIMIT",
        GRB.TIME_LIMIT: "TIME_LIMIT",
        GRB.SOLUTION_LIMIT: "SOLUTION_LIMIT",
        GRB.INTERRUPTED: "INTERRUPTED",
        GRB.NUMERIC: "NUMERIC",
        GRB.SUBOPTIMAL: "SUBOPTIMAL",
        GRB.USER_OBJ_LIMIT: "USER_OBJ_LIMIT",
        GRB.WORK_LIMIT: "WORK_LIMIT",
        GRB.MEM_LIMIT: "MEM_LIMIT",
    }
    return names.get(status, f"STATUS_{status}")


def extract_integer_incumbent(model: gp.Model) -> Dict[str, int]:
    if model.SolCount <= 0:
        fail("Cannot extract an incumbent from a model with no solutions")

    result: Dict[str, int] = {}
    for variable in model.getVars():
        if variable.VType not in (GRB.BINARY, GRB.INTEGER):
            fail(
                f"Unexpected nonintegral aggregated variable {variable.VarName} "
                f"with type {variable.VType}"
            )
        value = exact_integral(variable.X, variable.VarName)
        if variable.VType == GRB.BINARY and value not in (0, 1):
            fail(f"Binary incumbent {variable.VarName} has value {value}")
        if (
            variable.VType == GRB.INTEGER
            and abs(variable.LB) <= INT_TOL
            and abs(variable.UB - 1.0) <= INT_TOL
            and value not in (0, 1)
        ):
            fail(f"0/1 integer incumbent {variable.VarName} has value {value}")
        if value < math.ceil(variable.LB - INT_TOL):
            fail(f"Incumbent {variable.VarName} violates its lower bound")
        if value > math.floor(variable.UB + INT_TOL):
            fail(f"Incumbent {variable.VarName} violates its upper bound")
        result[variable.VarName] = value
    return result


def reconstruction_function():
    function = getattr(reduced_solver, "reconstruct", None)
    if not callable(function):
        fail("waima_solve_reduced.reconstruct is unavailable")
    return function


def reconstruct_candidate(
    reduction: Mapping[str, Any],
    original: Any,
    solved_model: gp.Model,
    aggregation_map: Mapping[str, Any],
) -> Tuple[Mapping[str, Fraction], Mapping[str, Fraction]]:
    result = reconstruction_function()(reduction, original, solved_model, aggregation_map)
    if isinstance(result, tuple) and len(result) == 2:
        aggregate_values, original_values = result
        return aggregate_values, original_values
    if isinstance(result, Mapping):
        return {}, result
    fail("The verified reconstruction routine returned an unsupported result")


def audit_candidate(
    model_path: Path,
    original: Any,
    assignments: Mapping[str, Fraction],
) -> Mapping[str, Any]:
    function = getattr(builder, "independently_audit", None)
    if not callable(function):
        fail("waima_build_reduced.independently_audit is unavailable")

    parameters = list(inspect.signature(function).parameters)
    first_name = parameters[0].lower() if parameters else ""
    if "path" in first_name or first_name in {"model", "model_file", "mps"}:
        report = function(str(model_path), assignments, expected_objective=None)
    else:
        # Improvements must not be compared with the public objective 4,870.
        # The independent checker still recomputes the exact objective and all
        # original rows, bounds, and integrality conditions.
        report = function(original, assignments, expected_objective=None)

    if report is False or report is None:
        fail("Independent audit did not return a successful report")
    if not isinstance(report, Mapping):
        report = {"success": bool(report)}
    if report.get("success") is False:
        fail(f"Independent audit rejected candidate: {report}")

    for key, value in report.items():
        lowered = str(key).lower()
        if "violation" in lowered and value not in (0, 0.0, "0", None, []):
            fail(f"Independent audit reports {key}={value}")
    return report


def recompute_objective(
    original: Mapping[str, Any],
    assignments: Mapping[str, Fraction],
) -> Fraction:
    helper = getattr(reduced_solver, "exact_objective", None)
    if callable(helper):
        return helper(original, assignments)
    return sum(
        variable["obj"] * assignments[variable["name"]]
        for variable in original["variables"]
    )


def solution_text(assignments: Mapping[str, Fraction], objective: Fraction) -> str:
    lines = [f"# Objective value = {objective}"]
    for name in sorted(assignments):
        value = assignments[name]
        if not isinstance(value, Fraction):
            value = Fraction(value)
        rendered = (
            str(value.numerator)
            if value.denominator == 1
            else f"{value.numerator}/{value.denominator}"
        )
        lines.append(f"{name} {rendered}")
    return "\n".join(lines) + "\n"


def make_schedule(total_budget: Fraction) -> Sequence[Tuple[Tuple[int, ...], Fraction]]:
    neighborhoods: list[Tuple[Tuple[int, ...], Fraction]] = []

    # Four path neighborhoods receive weight 1.
    for path in PATHS:
        neighborhoods.append((path, Fraction(1)))

    # Every pair of complete paths receives weight 8/3. At 900 seconds this
    # gives 45 seconds to each single path and 120 seconds to each path pair.
    for left in range(len(PATHS)):
        for right in range(left + 1, len(PATHS)):
            groups = tuple(sorted(PATHS[left] + PATHS[right]))
            neighborhoods.append((groups, Fraction(8, 3)))

    total_weight = sum(weight for _, weight in neighborhoods)
    schedule: list[Tuple[Tuple[int, ...], Fraction]] = []
    allocated = Fraction(0)
    for index, (groups, weight) in enumerate(neighborhoods):
        if index + 1 == len(neighborhoods):
            budget = total_budget - allocated
        else:
            budget = total_budget * weight / total_weight
            allocated += budget
        if budget <= 0:
            fail("A neighborhood received a nonpositive optimization budget")
        schedule.append((groups, budget))

    if sum(budget for _, budget in schedule) > total_budget:
        fail("Internal error: scheduled TimeLimit sum exceeds total budget")
    return schedule


def make_subproblem(
    base: gp.Model,
    incumbent: Mapping[str, int],
    group_of: Mapping[str, int],
    open_groups: Sequence[int],
    time_limit: float,
    seed: int,
    log_path: Path,
) -> gp.Model:
    subproblem = base.copy()
    open_set = set(open_groups)

    for variable in subproblem.getVars():
        name = variable.VarName
        value = incumbent[name]
        variable.Start = float(value)
        if group_of[name] not in open_set:
            variable.LB = float(value)
            variable.UB = float(value)

    subproblem.Params.TimeLimit = time_limit
    subproblem.Params.Seed = seed
    subproblem.Params.LogFile = str(log_path)
    subproblem.update()
    return subproblem


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Deterministic path-component large-neighborhood heuristic"
    )
    parser.add_argument("MODEL", help="Original MPS/MPS.GZ model")
    parser.add_argument("SOL", help="Public original-space SOL/SOL.GZ")
    parser.add_argument("BUILD_DIR", help="Verified reduced-build directory")
    parser.add_argument("OUTPUT_DIR", help="Output directory")
    parser.add_argument("--total-budget", type=float, default=900.0)
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()

    if not math.isfinite(args.total_budget) or not (0 < args.total_budget <= 900):
        fail("--total-budget must satisfy 0 < total-budget <= 900")
    if args.seed < 0 or args.seed > 2_000_000_000:
        fail("--seed must be between 0 and 2,000,000,000")

    model_path = Path(args.MODEL).resolve()
    public_solution_path = Path(args.SOL).resolve()
    build_dir = Path(args.BUILD_DIR).resolve()
    output_dir = Path(args.OUTPUT_DIR).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    if not model_path.is_file():
        fail(f"Original model not found: {model_path}")
    if not public_solution_path.is_file():
        fail(f"Public solution not found: {public_solution_path}")

    required_artifacts = {
        "model": build_dir / "aggregated.mps.gz",
        "start": build_dir / "public-start.mst",
        "map": build_dir / "aggregation-map.json",
        "report": build_dir / "build-report.json",
        "public_original": build_dir / "reconstructed-public.sol.gz",
    }
    for label, path in required_artifacts.items():
        if not path.is_file():
            fail(f"Missing verified build artifact {label}: {path}")

    best_original_path = output_dir / "best-original.sol.gz"
    result_path = output_dir / "result.json"
    atomic_copy(required_artifacts["public_original"], best_original_path)

    with required_artifacts["map"].open("r", encoding="utf-8") as handle:
        aggregation_map = json.load(handle)

    reduction = build_reduction(model_path, public_solution_path)
    original = parse_original(model_path)
    s70 = recover_s70(reduction)
    if sorted(int(group) for group in s70) != list(range(EXPECTED_GROUPS)):
        fail("Verified S70 groups are not exactly 0..11")

    base = gp.read(str(required_artifacts["model"]))
    base.read(str(required_artifacts["start"]))
    base.update()

    if base.NumVars != 44_904 or base.NumConstrs != 7_621:
        fail(
            f"Unexpected aggregated dimensions {base.NumVars} x {base.NumConstrs}; "
            "expected 44,904 variables and 7,621 constraints"
        )

    incumbent = initial_start(base)
    group_of = construct_group_map(reduction, aggregation_map, base)
    best_objective = PUBLIC_OBJECTIVE
    best_original_assignments: Mapping[str, Fraction] | None = None

    requested_budget = Fraction(str(args.total_budget))
    schedule = make_schedule(requested_budget)
    assigned_budget = Fraction(0)
    calls: list[Dict[str, Any]] = []

    result: Dict[str, Any] = {
        "instance": "neos-4533806-waima",
        "heuristic": "deterministic-complete-path-large-neighborhood-search",
        "seed": args.seed,
        "requested_total_time_limit_seconds": requested_budget,
        "assigned_time_limit_seconds": Fraction(0),
        "optimize_calls": calls,
        "best_verified_objective": best_objective,
        "classification": "matched_public",
        "best_solution_source": "verified_public_start",
        "best_numerical_bound": None,
        "best_numerical_bound_is_formal_certificate": False,
        "solver_reported_global_optimal": False,
        "formal_certificate": False,
        "complete": False,
    }
    atomic_json(result_path, result)

    for call_index, (open_groups, exact_budget) in enumerate(schedule, start=1):
        if assigned_budget + exact_budget > requested_budget:
            fail("Refusing optimize call because TimeLimit sum would exceed total budget")

        log_path = output_dir / (
            f"neighborhood-{call_index:02d}-groups-"
            + "-".join(str(group) for group in open_groups)
            + ".log"
        )
        time_limit = float(exact_budget)
        if not math.isfinite(time_limit) or time_limit <= 0:
            fail(f"Invalid TimeLimit for optimize call {call_index}")

        subproblem = make_subproblem(
            base=base,
            incumbent=incumbent,
            group_of=group_of,
            open_groups=open_groups,
            time_limit=time_limit,
            seed=args.seed,
            log_path=log_path,
        )

        assigned_budget += exact_budget
        if assigned_budget > requested_budget:
            fail("Internal budget enforcement failure before optimize()")

        wall_start = time.monotonic()
        subproblem.optimize()
        wall_seconds = time.monotonic() - wall_start

        record: Dict[str, Any] = {
            "call": call_index,
            "open_groups": list(open_groups),
            "open_paths": [
                path_index
                for path_index, path in enumerate(PATHS)
                if set(path).issubset(set(open_groups))
            ],
            "time_limit_seconds": exact_budget,
            "cumulative_assigned_time_limit_seconds": assigned_budget,
            "runtime_seconds": subproblem.Runtime,
            "wall_seconds": wall_seconds,
            "status_code": subproblem.Status,
            "status": status_name(subproblem.Status),
            "solution_count": subproblem.SolCount,
            "nodes": subproblem.NodeCount,
            "incumbent_objective_numerical": (
                subproblem.ObjVal if subproblem.SolCount > 0 else None
            ),
            "best_bound_numerical_for_fixed_neighborhood": (
                subproblem.ObjBound
                if subproblem.Status not in (GRB.LOADED, GRB.INF_OR_UNBD)
                else None
            ),
            "gap_numerical_for_fixed_neighborhood": (
                subproblem.MIPGap if subproblem.SolCount > 0 else None
            ),
            "bound_scope": "fixed-neighborhood-only",
            "formal_rational_certificate": False,
            "candidate_reconstructed": False,
            "candidate_independently_audited": False,
            "accepted": False,
            "log": log_path.name,
        }

        if subproblem.SolCount > 0:
            candidate_aggregate = extract_integer_incumbent(subproblem)
            _, candidate_original = reconstruct_candidate(
                reduction, original, subproblem, aggregation_map
            )
            audit = audit_candidate(model_path, original, candidate_original)
            candidate_objective = recompute_objective(original, candidate_original)

            record["candidate_reconstructed"] = True
            record["candidate_independently_audited"] = True
            record["verified_original_objective"] = candidate_objective
            record["audit"] = audit

            if candidate_objective < best_objective:
                incumbent = candidate_aggregate
                best_objective = candidate_objective
                best_original_assignments = candidate_original
                record["accepted"] = True
                record["improvement_over_previous"] = (
                    result["best_verified_objective"] - candidate_objective
                )
                atomic_gzip_text(
                    best_original_path,
                    solution_text(candidate_original, candidate_objective),
                )
                result["best_verified_objective"] = candidate_objective
                result["classification"] = (
                    "verified_improvement"
                    if candidate_objective < PUBLIC_OBJECTIVE
                    else "matched_public"
                )
                result["best_solution_source"] = f"neighborhood-{call_index:02d}"

        calls.append(record)
        result["assigned_time_limit_seconds"] = assigned_budget
        result["best_verified_objective"] = best_objective
        atomic_json(result_path, result)

        # These neighborhoods fix at least two complete path components, so
        # even an OPTIMAL status proves only the restricted subproblem.
        opens_all_groups = set(open_groups) == set(range(EXPECTED_GROUPS))
        valid_zero_gap_global_proof = (
            opens_all_groups
            and subproblem.Status == GRB.OPTIMAL
            and subproblem.SolCount > 0
            and abs(subproblem.ObjVal - subproblem.ObjBound) <= 1e-8
        )
        if valid_zero_gap_global_proof:
            result["solver_reported_global_optimal"] = True
            result["formal_certificate"] = False
            result["stopped_after_valid_solver_zero_gap"] = True
            break

        subproblem.dispose()

    if assigned_budget > requested_budget:
        fail("Sum of optimize-call TimeLimit values exceeded the requested budget")

    result["assigned_time_limit_seconds"] = assigned_budget
    result["optimize_call_count"] = len(calls)
    result["best_verified_objective"] = best_objective
    result["classification"] = (
        "verified_improvement" if best_objective < PUBLIC_OBJECTIVE else "matched_public"
    )
    result["preserved_public_solution"] = best_objective == PUBLIC_OBJECTIVE
    result["best_original_solution"] = best_original_path.name
    result["ordinary_bounds_are_numerical_not_formal_certificates"] = True
    result["complete"] = True
    atomic_json(result_path, result)

    print(json.dumps(json_value(result), sort_keys=True))
    base.dispose()
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (HeuristicError, gp.GurobiError, OSError, ValueError, KeyError) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        raise SystemExit(2)
