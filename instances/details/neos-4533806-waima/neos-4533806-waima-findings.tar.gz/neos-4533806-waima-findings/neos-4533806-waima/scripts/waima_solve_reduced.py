#!/usr/bin/env python3
from __future__ import annotations

import argparse
import gzip
import json
import math
import os
import shutil
import sys
import tempfile
import time
from fractions import Fraction
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Sequence

import gurobipy as gp
from gurobipy import GRB

import waima_pairgraph as pg
import waima_build_reduced as br


INT_TOL = 1e-7
VALUE_TOL = 1e-7
PUBLIC_OBJECTIVE = Fraction(4870)


def die(message: str) -> None:
    raise RuntimeError(message)


def atomic_bytes(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temporary, path)
    except BaseException:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
        raise


def atomic_text(path: Path, text: str) -> None:
    atomic_bytes(path, text.encode("utf-8"))


def atomic_gzip(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    os.close(fd)
    try:
        with gzip.open(temporary, "wt", encoding="utf-8", newline="\n") as f:
            f.write(text)
        os.replace(temporary, path)
    except BaseException:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
        raise


def atomic_model_write(model: gp.Model, path: Path, suffix: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    directory = Path(tempfile.mkdtemp(prefix=f".{path.name}.", dir=str(path.parent)))
    try:
        raw = directory / ("artifact" + suffix)
        model.write(str(raw))
        os.replace(raw, path)
    finally:
        shutil.rmtree(directory, ignore_errors=True)


def as_fraction(value: float, name: str) -> Fraction:
    if not math.isfinite(value):
        die(f"{name} is non-finite")
    nearest = round(value)
    if abs(value - nearest) <= INT_TOL:
        return Fraction(int(nearest), 1)
    return Fraction(str(value))


def integer_solution_value(value: float, name: str) -> int:
    if not math.isfinite(value):
        die(f"{name} is non-finite")
    nearest = round(value)
    if abs(value - nearest) > INT_TOL:
        die(f"{name} is not integral within tolerance: {value!r}")
    return int(nearest)


def variable_name(raw: Any) -> str:
    if isinstance(raw, str):
        return raw
    return str(br.first_field(raw, ("name", "var_name", "variable"), required=True))


def row_terms(row: Mapping[str, Any]) -> Mapping[str, Fraction]:
    return row["terms"]


def row_type(row: Mapping[str, Any]) -> str:
    return row["kind"]


def exact_objective(original: Mapping[str, Any], values: Mapping[str, Fraction]) -> Fraction:
    return sum(v["obj"] * values[v["name"]] for v in original["variables"])


def solve_binary_row(
    row: Mapping[str, Any],
    fixed: Mapping[str, Fraction],
    unknown: Sequence[str],
) -> Dict[str, Fraction]:
    if not unknown:
        die(f"Row {row['name']} has no auxiliary variables")
    coefficients = [row["terms"][name] for name in unknown]
    if any(c.denominator != 1 for c in coefficients):
        die(f"Row {row['name']} has nonintegral auxiliary coefficients")

    fixed_activity = sum(
        coefficient * fixed[name]
        for name, coefficient in row["terms"].items()
        if name not in unknown
    )

    if row_type(row) == "le":
        target_ok = lambda s: fixed_activity + s <= row["ub"]
        prefer_max = False
    elif row_type(row) == "ge":
        target_ok = lambda s: fixed_activity + s >= row["lb"]
        prefer_max = True
    elif row_type(row) == "eq":
        target_ok = lambda s: fixed_activity + s == row["lb"]
        prefer_max = False
    else:
        die(f"Auxiliary witness row {row['name']} is not <=, >=, or singleton equality")

    # Dynamic programming over exact integer auxiliary activities.
    states: Dict[int, tuple[int, int | None]] = {0: (0, None)}
    parents: list[Dict[int, tuple[int, int]]] = []
    for coefficient in coefficients:
        c = int(coefficient)
        new: Dict[int, tuple[int, int | None]] = {}
        parent: Dict[int, tuple[int, int]] = {}
        for total, (cost, _) in states.items():
            for bit in (0, 1):
                candidate = total + bit * c
                candidate_cost = cost + bit
                old = new.get(candidate)
                better = old is None or (
                    (candidate_cost > old[0]) if prefer_max else (candidate_cost < old[0])
                )
                if better:
                    new[candidate] = (candidate_cost, total)
                    parent[candidate] = (total, bit)
        states = new
        parents.append(parent)

    candidates = [s for s in states if target_ok(Fraction(s, 1))]
    if not candidates:
        die(f"No exact binary witness exists for auxiliary row {row['name']}")
    if prefer_max:
        chosen_sum = max(candidates, key=lambda s: states[s][0])
    else:
        chosen_sum = min(candidates, key=lambda s: states[s][0])

    bits = [0] * len(unknown)
    total = chosen_sum
    for i in range(len(unknown) - 1, -1, -1):
        previous, bit = parents[i][total]
        bits[i] = bit
        total = previous

    return {name: Fraction(bit, 1) for name, bit in zip(unknown, bits)}


def reconstruct(
    reduction: Mapping[str, Any],
    original: Mapping[str, Any],
    model: gp.Model,
    aggregate_map: Mapping[str, Any],
) -> tuple[Dict[str, Fraction], Dict[str, Fraction]]:
    model_vars = {v.VarName: v for v in model.getVars()}
    aggregate_values: Dict[str, Fraction] = {}

    for name, variable in model_vars.items():
        if variable.SolCount if hasattr(variable, "SolCount") else False:
            pass
        value = variable.X
        if variable.VType in (GRB.BINARY, GRB.INTEGER):
            integer_solution_value(value, name)
        aggregate_values[name] = as_fraction(value, name)

    costly: Dict[str, Fraction] = {}
    s70_members: Dict[int, list[str]] = {}
    for group_text, info in aggregate_map["groups"].items():
        group = int(group_text)
        members = [str(x) for x in info["members"]]
        zname = str(info["aggregate_variable"])
        count = integer_solution_value(float(aggregate_values[zname]), zname)
        if not 0 <= count <= 5 or count > len(members):
            die(f"{zname} has invalid value {count}")
        public_selected = [
            str(x) for x in info.get("public_selected_members", [])
        ]
        ordered = public_selected + [x for x in sorted(members) if x not in public_selected]
        selected = ordered[:count]
        s70_members[group] = selected
        for name in members:
            costly[name] = Fraction(int(name in selected))

    s70_names = {x for xs in s70_members.values() for x in xs}
    all_s70 = {
        str(x)
        for info in aggregate_map["groups"].values()
        for x in info["members"]
    }
    for name, value in aggregate_values.items():
        if name not in all_s70 and not name.startswith("z_S70_"):
            costly[name] = value

    for copy, representative in reduction["copy_map"].items():
        if representative not in costly:
            die(f"Copy representative {representative} is unavailable")
        costly[copy] = costly[representative]

    rows = {r["index"]: r for r in original["rows"]}
    values = dict(costly)
    aux_names = {w["var"] for w in reduction["auxiliary_witnesses"]}

    by_row: Dict[int, list[str]] = {}
    for witness in reduction["auxiliary_witnesses"]:
        by_row.setdefault(int(witness["row"]), []).append(witness["var"])

    for row_index, names in sorted(by_row.items()):
        row = rows[row_index]
        if any(name in values for name in names):
            die(f"Auxiliary variable already assigned in row {row['name']}")
        assignment = solve_binary_row(row, values, names)
        values.update(assignment)

    reporting_names = {w["var"] for w in reduction["reporting_witnesses"]}
    for witness in reduction["reporting_witnesses"]:
        name = witness["var"]
        row = rows[int(witness["row"])]
        unknown = [
            n for n in row["terms"]
            if n not in values and n in reporting_names
        ]
        if unknown != [name]:
            die(f"Reporting row {row['name']} is not an exact singleton definition")
        coefficient = row["terms"][name]
        if coefficient == 0 or row["kind"] != "eq":
            die(f"Reporting row {row['name']} is not a singleton equality")
        residual = sum(
            c * values[n] for n, c in row["terms"].items() if n != name
        )
        values[name] = (row["lb"] - residual) / coefficient

    return aggregate_values, values


def solution_text(values: Mapping[str, Fraction], objective: Fraction) -> str:
    out = [f"# Objective value = {objective}"]
    for name in sorted(values):
        value = values[name]
        rendered = (
            str(value.numerator)
            if value.denominator == 1
            else f"{value.numerator}/{value.denominator}"
        )
        out.append(f"{name} {rendered}")
    return "\n".join(out) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("MODEL")
    parser.add_argument("SOL")
    parser.add_argument("BUILD_DIR")
    parser.add_argument("OUTPUT_DIR")
    parser.add_argument("--time-limit", type=float, required=True)
    parser.add_argument("--seed", type=int, required=True)
    args = parser.parse_args()

    if not (0 < args.time_limit <= 1800):
        die("--time-limit must satisfy 0 < time-limit <= 1800")

    build_dir = Path(args.BUILD_DIR).resolve()
    output_dir = Path(args.OUTPUT_DIR).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    log_path = output_dir / "solver.log"

    for filename in (
        "aggregated.mps.gz",
        "public-start.mst",
        "aggregation-map.json",
        "build-report.json",
    ):
        if not (build_dir / filename).is_file():
            die(f"Missing build artifact: {build_dir / filename}")

    model = gp.read(str(build_dir / "aggregated.mps.gz"))
    model.read(str(build_dir / "public-start.mst"))
    model.Params.TimeLimit = args.time_limit
    model.Params.Seed = args.seed
    model.Params.LogFile = str(log_path)

    start = time.monotonic()
    model.optimize()
    elapsed = time.monotonic() - start

    status_name = {
        GRB.OPTIMAL: "OPTIMAL",
        GRB.TIME_LIMIT: "TIME_LIMIT",
        GRB.INTERRUPTED: "INTERRUPTED",
        GRB.INFEASIBLE: "INFEASIBLE",
        GRB.UNBOUNDED: "UNBOUNDED",
        GRB.INF_OR_UNBD: "INF_OR_UNBD",
    }.get(model.Status, f"STATUS_{model.Status}")

    result: Dict[str, Any] = {
        "status": status_name,
        "runtime_seconds": model.Runtime,
        "solver_optimization_seconds": elapsed,
        "solver_bound_is_numerical_not_formal_rational_certificate": True,
        "nodes": model.NodeCount,
        "solution_count": model.SolCount,
        "seed": args.seed,
        "time_limit": args.time_limit,
    }

    if model.SolCount:
        result["incumbent_objective"] = model.ObjVal
        result["best_numerical_bound"] = model.ObjBound
        result["gap"] = model.MIPGap

        reduction = br._normalize_reduction(
            br.call_reduction_builder(args.MODEL, args.SOL)
        )
        original = br.parse_original_fresh(args.MODEL)
        s70, s70_by_name, _ = br.recover_and_prove_s70(reduction)
        with (build_dir / "aggregation-map.json").open(
            "r", encoding="utf-8"
        ) as f:
            aggregation_map = json.load(f)

        aggregate_values, original_values = reconstruct(
            reduction, original, model, aggregation_map
        )
        objective = exact_objective(original, original_values)
        audit = br.independently_audit(
            original, original_values, expected_objective=objective
        )

        atomic_model_write(model, output_dir / "best-aggregated.sol", ".sol")
        atomic_gzip(
            output_dir / "best-original.sol.gz",
            solution_text(original_values, objective),
        )

        result["verified_objective"] = str(objective)
        result["audit"] = audit
        if objective < PUBLIC_OBJECTIVE:
            result["classification"] = "verified_improvement"
        elif objective == PUBLIC_OBJECTIVE:
            result["classification"] = "matched_public"
        else:
            result["classification"] = "feasible_not_better"
        if status_name == "OPTIMAL":
            result["solver_reported_optimal"] = True
            result["formal_certificate"] = False
        else:
            result["solver_reported_optimal"] = False
    else:
        result["classification"] = "no_aggregated_incumbent"

    atomic_text(
        output_dir / "result.json",
        json.dumps(result, indent=2, sort_keys=True, default=str) + "\n",
    )
    print(json.dumps(result, sort_keys=True, default=str))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (RuntimeError, gp.GurobiError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(2)
