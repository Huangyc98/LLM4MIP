# neos-4533806-waima

Status: **feasible solution 4,870 independently verified; global optimum still
open**. This study neither improved the public upper bound nor produced a
global optimality certificate.

[MIPLIB instance page](https://miplib.zib.de/instance_details_neos-4533806-waima.html)

## Verified structure

The original model has 93,318 variables, 52,983 rows, and 1,250,570 nonzeros.
Exact projection identifies 45,732 costly binary variables in 12 groups of
3,811. The remaining binary columns are copies, reporting variables, or
inequality auxiliaries that can be reconstructed and checked in the original
model.

After removing those reconstructible columns and aggregating one proven
70-member fixed-row-identical class per group, the exact reduced model has
44,904 integer variables and 7,621 constraints. The only pairwise group graph
is four disjoint paths:

```text
0--1--2    3--4--5    6--7--8    9--10--11
```

There are also 21 global positive unit-coefficient covering rows. Within each
group, the dominant local rows are balanced directed-network constraints. The
aggregation preserves the public objective 4,870 and reconstructs a complete
original-space solution with zero row, bound, or integrality violations.

## Experiments

An exact-reduction baseline used one 900-second Gurobi call. It retained the
4,870 incumbent and reached global numerical lower bound 3,956, a gap of
18.768%. This is a floating-point solver bound, not a portable exact
certificate.

The follow-up was a structure-driven large-neighborhood search, not a solver
parameter portfolio. It opened each complete three-group path, then every pair
of paths, while fixing the other groups to the incumbent. The ten neighborhoods
had a total assigned TimeLimit of 899 seconds after a one-second end-to-end
smoke test. Actual optimization time in the final run was 818.748 seconds.

All ten candidates reconstructed to objective 4,870 and passed an independent
exact audit of all 93,318 original variables and 52,983 original rows. No
candidate was accepted as an improvement. The single-path neighborhoods
`0--1--2` and `6--7--8` were solved to local optimality at 4,870; this is only
local information because the other groups were fixed. The remaining eight
neighborhood results and their bounds are likewise restricted-subproblem
results, not global lower bounds.

The two optimization stages plus the smoke test used exactly 1,800 seconds of
assigned `Model.optimize()` TimeLimit and approximately 1,720 seconds of actual
optimization runtime. No additional generic solver parameter tuning was used.

## Reproduction and evidence

- `scripts/waima_pairgraph.py` recovers and verifies the exact projection and
  inter-group graph.
- `scripts/waima_build_reduced.py` constructs the exact aggregated model and
  audits the public reconstruction.
- `scripts/waima_solve_reduced.py` runs the bounded global baseline and maps an
  incumbent back to the original model.
- `scripts/waima_path_lns.py` implements the deterministic path-based LNS,
  enforces its aggregate TimeLimit, and audits every candidate.
- `artifacts/reduced-build/` contains the aggregated MPS, aggregation map,
  public MIP start, build report, and reconstructed public solution.
- `artifacts/baseline-result.json` and
  `artifacts/path-lns-run/result.json` are the machine-readable conclusions;
  all neighborhood traces are retained beside the latter.
- `logs/` contains the baseline and LNS driver traces.

The investigation used nine substantive direct-API turns totaling 180,370
tokens. One additional deliberately short segmented request returned no
content and used 738 tokens. Long requests that hit the gateway timeout are not
counted because their billing status is unknown. Raw API conversations and
credentials are deliberately excluded.

SHA-256:

- MPS: `D5DFD8C8EDB4EA12626E11277ECCEA8CCA593D6B74C34D5E7403ADC6DDDC9BDB`
- public solution: `3F7C447602BBE5765902731F096C8E9CEC0196FFC50186091A2D21155649E32B`
- audited 4,870 solution: `2CEA5668698A8E429475EA02E92E5B6EB4D146F44B88FE1523D11D9F73F96810`
- aggregated MPS: `98D3FB9C712C55FA9E131293370893D7411DF7A378EF7843F9EDD5D6D5DC2771`
