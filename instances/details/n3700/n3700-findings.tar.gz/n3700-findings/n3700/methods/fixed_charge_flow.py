#!/usr/bin/env python3
import argparse,gzip,json,math,random,os
from collections import defaultdict,deque

def opn(p): return gzip.open(p,'rt',errors='replace') if p.endswith('.gz') else open(p,'r',errors='replace')

def parse(path):
 sec=''; sense={}; rhs=defaultdict(float); bnd={}; obj={}; cols=defaultdict(dict); ints=set(); marker=False; objrow=None
 with opn(path) as f:
  for raw in f:
   s=raw.strip()
   if not s or s.startswith('*'): continue
   t=s.split(); h=t[0].upper()
   if h in ('NAME','ROWS','COLUMNS','RHS','RANGES','BOUNDS','ENDATA','OBJSENSE'):
    sec=h
    if h=='ENDATA': break
    continue
   if sec=='OBJSENSE': continue
   if sec=='ROWS':
    typ,name=t[0],t[1]; sense[name]=typ
    if typ=='N' and objrow is None: objrow=name
   elif sec=='COLUMNS':
    if len(t)>=3 and t[1].strip("'").upper()=='MARKER': marker=t[2].strip("'").upper()=='INTORG'; continue
    v=t[0]
    if marker: ints.add(v)
    for i in range(1,len(t)-1,2):
     r=t[i]; a=float(t[i+1]);
     if r==objrow: obj[v]=a
     else: cols[v][r]=cols[v].get(r,0.0)+a
   elif sec=='RHS':
    for i in range(1,len(t)-1,2): rhs[t[i]]=float(t[i+1])
   elif sec=='BOUNDS':
    typ=t[0].upper(); v=t[2]; val=float(t[3]) if len(t)>3 else 0.0
    lo,up=bnd.get(v,(0.0,math.inf))
    if typ in ('BV',): lo,up=0.0,1.0; ints.add(v)
    elif typ in ('UP','UI'): up=val
    elif typ in ('LO','LI'): lo=val
    elif typ=='FX': lo=up=val
    elif typ=='FR': lo,up=-math.inf,math.inf
    elif typ=='MI': lo=-math.inf
    elif typ=='PL': up=math.inf
    bnd[v]=(lo,up)
 for v in cols:
  bnd.setdefault(v,(0.0,math.inf)); obj.setdefault(v,0.0)
 return sense,rhs,bnd,obj,cols,ints

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--model',required=True); ap.add_argument('--seed',type=int,default=7); ap.add_argument('--trials',type=int,default=300); a=ap.parse_args()
 S,R,B,C,A,I=parse(a.model); rows=defaultdict(list)
 for v,dd in A.items():
  for r,x in dd.items(): rows[r].append((v,x))
 bins=[v for v in A if v in I and B[v][0]>=-1e-12 and B[v][1]<=1+1e-12]
 cont=[v for v in A if v not in I]
 # Linking row detection: exactly one binary and one continuous variable.
 links={}; linkrows=[]
 for r,ls in rows.items():
  if S.get(r) not in ('L','G'): continue
  bb=[z for z in ls if z[0] in bins]; cc=[z for z in ls if z[0] in cont]
  if len(bb)==1 and len(cc)==1 and len(ls)==2:
   y,ay=bb[0]; x,ax=cc[0]; cap=None
   # Normalize ax*x + ay*y <=/>= rhs and derive x <= cap*y, requiring zero RHS.
   if abs(R[r])<1e-8:
    if S[r]=='L' and ax>0 and ay<0: cap=-ay/ax
    if S[r]=='G' and ax<0 and ay>0: cap=-ay/ax
   if cap is not None and cap>=0: links[x]=(y,cap,r); linkrows.append(r)
 eq=[r for r in rows if S.get(r)=='E']
 incidence={}; arcs=[]
 for x in cont:
  q=[(r,z) for r,z in A[x].items() if r in eq and abs(z)>1e-12]
  if len(q)==2 and q[0][1]*q[1][1]<0 and x in links:
   # Orient tail at negative coefficient and scale flow contribution.
   neg=[p for p in q if p[1]<0][0]; pos=[p for p in q if p[1]>0][0]
   arcs.append((x,neg[0],pos[0],-neg[1],pos[1],links[x][1],links[x][0]))
 report={'variables':len(A),'binary':len(bins),'continuous':len(cont),'equalities':len(eq),'link_pairs':len(links),'two_endpoint_linked_columns':len(arcs),'link_rows':len(linkrows),'equality_row_sizes':sorted([len(rows[r]) for r in eq])[:10]}
 # Construct only for a canonical incidence network: equal magnitudes on both endpoints and no non-arc continuous equality terms.
 canonical=[z for z in arcs if abs(z[3]-z[4])<=1e-9*max(1,z[3],z[4])]
 covered=set(z[0] for z in canonical)
 extra=[x for x in cont if any(r in eq for r in A[x]) and x not in covered]
 report['canonical_arcs']=len(canonical); report['uncovered_continuous_in_equalities']=len(extra)
 best=None; bestobj=math.inf
 if len(canonical)>=max(1,int(.9*len(cont))) and not extra:
  # Convert row RHS into supply: out-in = -rhs after orientation used above.
  nodes=eq; supply={r:-R[r] for r in nodes}
  # Repeated residual shortest augmentations. Costs combine variable and fixed cost amortized over capacity.
  outgoing=defaultdict(list)
  for x,u,v,scale1,scale2,cap,y in canonical:
   capeff=cap*scale1; unit=(C[x]/scale1)+(C[y]/max(capeff,1e-9)); outgoing[u].append((v,x,y,capeff,scale1,unit))
  rng=random.Random(a.seed)
  for tr in range(a.trials):
   rem=dict(supply); flow=defaultdict(float)
   # Positive supply rows need outgoing flow, negative rows receive it.
   ok=True
   while True:
    srcs=[n for n in nodes if rem[n]>1e-7]
    if not srcs: break
    src=max(srcs,key=lambda n:rem[n]); dist={src:0.0}; prev={}; q=set(nodes)
    while q:
     u=min(q,key=lambda z:dist.get(z,math.inf)); q.remove(u)
     if dist.get(u,math.inf)==math.inf: break
     if rem[u]<-1e-7: break
     edges=list(outgoing[u]); rng.shuffle(edges)
     for v,x,y,cap,sc,cost in edges:
      residual=cap-flow[x]*sc
      if residual>1e-8:
       jitter=(1+0.12*rng.random()) if tr else 1.0; nd=dist[u]+cost*jitter
       if nd<dist.get(v,math.inf): dist[v]=nd; prev[v]=(u,x,y,cap,sc)
    sinks=[n for n in nodes if rem[n]<-1e-7 and n in dist]
    if not sinks: ok=False; break
    dst=min(sinks,key=lambda n:dist[n]); path=[]; z=dst; bott=min(rem[src],-rem[dst])
    while z!=src:
     if z not in prev: ok=False; break
     p=prev[z]; path.append(p); bott=min(bott,p[3]-flow[p[1]]*p[4]); z=p[0]
    if not ok or bott<=1e-9: ok=False; break
    for p in path: flow[p[1]]+=bott/p[4]
    rem[src]-=bott; rem[dst]+=bott
   if ok:
    val={v:0.0 for v in A}
    for x,f in flow.items(): val[x]=f
    for x,(y,cap,r) in links.items():
     if val.get(x,0)>1e-8: val[y]=1.0
    # Full model check.
    feas=True; mv=0.0
    for v,(lo,up) in B.items():
     q=val.get(v,0.0); mv=max(mv,max(lo-q,0),max(q-up,0));
     if v in I: mv=max(mv,abs(q-round(q)))
    for r,ls in rows.items():
     lhs=sum(co*val.get(v,0.0) for v,co in ls); rr=R[r]; typ=S[r]
     viol=abs(lhs-rr) if typ=='E' else max(lhs-rr,0) if typ=='L' else max(rr-lhs,0) if typ=='G' else 0
     mv=max(mv,viol)
    if mv<=1e-7:
     ob=sum(C[v]*val.get(v,0.0) for v in A)
     if ob<bestobj: bestobj=ob; best=val
  report['best_objective']=None if best is None else bestobj
 if best is not None:
  with open('best.sol','w') as f:
   f.write('# Objective value = %.15g\n'%bestobj)
   for v in A: f.write('%s %.17g\n'%(v,best.get(v,0.0)))
  report['solution_written']=True
 else: report['solution_written']=False
 with open('structure_report.json','w') as f: json.dump(report,f,indent=2,sort_keys=True)
 with open('method_result.json','w') as f: json.dump({'status':'feasible' if best is not None else 'no_solution','objective':None if best is None else bestobj,'report':report},f,indent=2)
if __name__=='__main__': main()
