# Experiment ledger

This file is generated from `runs/*/result.json` by the controller.

| Run | Solver | Status | Primal | Dual | Gap | Verified | Runtime (s) |
|---|---|---|---:|---:|---:|---|---:|
| `copt-20260903-164526-3f442fef` | copt | TIMEOUT | 1311206 | 1058140.76389077 | 0.193001889946532 | yes @ 1e-9 | 300.029860973358 |
| `copt-20260903-183923-a1e7b088` | copt | TIMEOUT | 1271940 | 1063103.14706162 | 0.164187660533027 | yes @ 1e-9 | 7000.027135849 |
| `custom-20260903-165248-dda2b247` | custom-python | no_solution | — | — | — | not checked | 1.17441534996033 |
| `gurobi-20260903-164522-ea83e8ee` | gurobi | TIME_LIMIT | 1247295 | 1055832.74399599 | 0.153501983094623 | yes @ 1e-9 | 300.012118816376 |
| `gurobi-20260903-165613-d591f6a3` | gurobi | TIME_LIMIT | 1244035.98328589 | 1062790.15238174 | 0.145691791346278 | no | 6000.03638291359 |
| `gurobi-20260903-203825-f63dcad5` | gurobi | TIME_LIMIT | 1263637 | 1044095.91729942 | 0.173737459967207 | yes @ 1e-9 | 400.01149392128 |
