# Method selection

## Structural evidence

The model has 5,000 binary and 5,000 nonnegative continuous variables, 5,000 inequality rows, 150 equality rows, and only 20,000 matrix coefficients. The exact symmetry in variable counts and the row pattern indicate a likely fixed-charge design formulation: each continuous activity is linked to one binary activation by a sparse inequality, while the 150 equalities impose flow, demand, or balance conditions. All objective coefficients are positive and the model is a minimization problem.

## Candidate algorithms

1. **Fixed-charge network construction and repair.** Detect binary/continuous pairs from linking inequalities, recover the equality-column incidence pattern, open a sparse set of activities, and solve or construct the induced continuous flow. This directly exploits the likely mathematical structure and can improve the incumbent without generic branch-and-bound.
2. **Lagrangian relaxation of balance or linking constraints.** Relax balances or fixed-charge links, solve separable arc decisions, and update multipliers by subgradient or volume-style steps. This can produce a useful lower bound and guide primal repair, but implementing a strong bound requires reliable recovery of the network semantics.
3. **Local branching around a structurally generated design.** Once a good activation vector is generated, pass it as a verified warm start to a proof solver and constrain or prioritize a neighborhood. This is valuable as a second phase, not as the initial custom method.
4. **Generic SAT encoding.** Rejected at this stage: continuous flows and large coefficients make direct bit-blasting unattractive, despite CaDiCaL availability.

## Selected first experiment

Implement a solver-independent MPS parser and a fixed-charge network heuristic. It will detect one-to-one linking rows and two-nonzero balance incidence columns, infer capacities from linking inequalities, then run randomized greedy path/transport construction with residual-capacity repair when the recovered structure supports it. Every candidate is checked against all original linear rows before writing a solution. Even if no feasible solution is produced, the emitted report will quantify the recovered abstraction and determine whether a min-cost-flow/Lagrangian implementation is justified.

No external tool is required for this diagnostic and constructive phase. CaDiCaL and drat-trim do not match the continuous network structure. Gurobi/COPT will be reserved for validation, warm-start improvement, or proof after the custom structural method has been tested.