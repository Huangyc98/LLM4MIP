# Sources for `neos-2978205-isar`

Research start: 2026-09-09T01:30:05+08:00

## Authoritative instance sources

- MIPLIB 2017 instance page: https://miplib.zib.de/instance_details_neos-2978205-isar.html
  - Status shown on the page: open.
  - Submitter: Jeff Linderoth.
  - Group: `neos-pseudoapplication-77`.
  - Best public primal objective: `-11.92580869` (asterisked/open).
  - Original size: 104,000 variables, 652 constraints, 208,000 nonzeros.
  - Variable split: 320 binary and 103,680 continuous.
  - Row classification: 8 cardinality and 644 mixed-binary rows.
  - The page provides no bibliographic reference.
- Official original MPS: https://miplib.zib.de/WebData/instances/neos-2978205-isar.mps.gz
  - Local SHA-256: `4022931069021dc2667b4decb8a84bfcd42925c3e55386550402980205c938b9`.
- Official public incumbent solution (ID 1):
  https://miplib.zib.de/downloads/solutions/neos-2978205-isar/1/neos-2978205-isar.sol.gz
  - Local SHA-256: `e9045e30921c3eb67d645664772c124bb011a1fc8c7fbbd673cedcf02e820c54`.

## Closest same-formulation sibling

- MIPLIB instance page: https://miplib.zib.de/instance_details_neos-2978193-inde.html
  - Status: easy; objective `-2.38806169`.
  - Size: 20,800 variables = 64 binary + 20,736 continuous, 396 rows,
    41,600 nonzeros.
  - It has the same eight cardinality rows and the same exact two-incidence
    pattern for the continuous assignment variables, at one fifth the number
    of facility/configuration columns.
- Official sibling MPS: https://miplib.zib.de/WebData/instances/neos-2978193-inde.mps.gz
- Official sibling solution (ID 1):
  https://miplib.zib.de/downloads/solutions/neos-2978193-inde/1/neos-2978193-inde.sol.gz

## Background search result

No application description or paper was found under the exact instance name.
Therefore, all semantic labels in this study must be treated as structural
inferences and checked directly against the MPS. The recovered matrix is a
capacitated assignment / facility-selection form: 324 demand rows, 320
capacity-link rows, 320 binary selectors, and eight disjoint selector-cardinality
rows. For fixed selectors, the remaining problem is a transportation LP. This
supports exact decomposition and combinatorial approaches but is not, by itself,
evidence of the anonymous underlying application.

