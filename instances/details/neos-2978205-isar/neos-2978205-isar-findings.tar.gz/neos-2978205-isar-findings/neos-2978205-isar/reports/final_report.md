# `neos-2978205-isar`: exact symmetry quotient proves optimality

## Result

**Status: OPTIMAL.** The optimal objective is

```text
-11.925808687
```

This equals the public incumbent (the MIPLIB page rounds it to
`-11.92580869`). The claim is supported by an exact, independently checked
symmetry quotient, a quotient solve with matching primal and dual bounds, a
constructive lift, and a zero-violation audit against all rows of the original
MPS. This is not a conclusion from solving a fixed-incumbent model or from
adding an assumed objective cut.

## Authoritative background

The [MIPLIB instance page](https://miplib.zib.de/instance_details_neos-2978205-isar.html)
labels the instance open, lists Jeff Linderoth as submitter, and reports 104,000
variables, 652 rows, 208,000 nonzeros, 320 binary variables, 103,680 continuous
variables, and the public objective `-11.92580869`. MIPLIB provides no
bibliographic description, so the application semantics below were not guessed;
only matrix-derived structure was used. The official MPS SHA-256 is
`4022931069021dc2667b4decb8a84bfcd42925c3e55386550402980205c938b9`.

The [same-formulation sibling `neos-2978193-inde`](https://miplib.zib.de/instance_details_neos-2978193-inde.html)
has 64 selectors and is solved. It was used only as a diagnostic control, not
as evidence for the target objective.

## Exact structure recovered from the MPS

Let `i=1,...,324` index client/assignment rows and `j=1,...,320` index
selectors. Direct incidence inspection gives

```text
min  sum(i,j) c[i,j] x[i,j]
s.t. sum(j) x[i,j] = 1                         for every i
     sum(i) x[i,j] <= 10 y[j]                  for every j
     sum(j in G[g]) y[j] = k[g]                for g=1,...,8
     x >= 0, y binary,
```

where every group has 40 selectors and

```text
k = (5, 5, 4, 5, 3, 4, 4, 4).
```

The parser verifies coefficients, senses, bounds, incidence counts, objective
support, and group membership without calling `optimize`. For fixed selectors,
the continuous model is a transportation problem and has an integral optimum.

## Decisive reduction

The cost matrix has **exactly 40 distinct columns**, each repeated exactly
eight times. More strongly, every selector group contains exactly one one copy
of every cost type. Let `t=1,...,40` be these types,

```text
z[t]   = number of selected copies of type t,
X[i,t] = sum of x[i,j] over the eight copies of type t.
```

Aggregation preserves the objective and produces

```text
sum(t) X[i,t] = 1,
sum(i) X[i,t] <= 10 z[t],
0 <= z[t] <= 8 integer,
sum(t) z[t] = 34.
```

The remaining question is whether the type multiplicities `z` can be realized
by an 8-by-40 zero-one group/type incidence matrix with row degrees
`(5,5,5,4,4,4,4,3)` and column degrees `z`. Gale-Ryser gives the first five
right-hand sides

```text
8, 16, 24, 31, 34,
```

and all later values remain 34. Bounds imply the first three inequalities and
the total-degree equation implies all inequalities from five onward. Thus the
only additional condition is that the four largest `z` values sum to at most
31, equivalently: **at most three types may have `z[t]=8`**.

The exact quotient therefore contains 12,960 continuous assignments, 40 small
integer multiplicities, and 40 indicators encoding this one margin condition.
It is not a relaxation:

1. every original solution projects to a quotient solution of equal cost;
2. every quotient multiplicity vector has a valid group/type realization by
   Gale-Ryser;
3. every aggregate assignment can be split across selected identical copies,
   each of capacity 10, without changing its objective.

The executable proof and mapping checks are in
`scripts/solve_aggregated.py`; the exact parsed mapping and cost matrix are in
`artifacts/mapping_certificate.npz`.

## Computation and certificate

Gurobi 13.0.2 solved the exported exact quotient (`artifacts/exact_quotient.mps`)
at the root:

```text
quotient variables       13,040 (12,960 continuous, 80 integer)
quotient constraints     406
nodes                    1
runtime                  0.278 seconds (reproducibility run)
best objective           -11.925808687000004
best bound               -11.925808687000004
reported gap             0
```

The quotient solution was lifted by a deterministic Havel-Hakimi margin
realization and capacity-respecting assignment split. The resulting sparse
original solution is `solutions/aggregated_lifted.sol.gz`. A separate evaluator
then read the original MPS and found:

```text
recomputed objective          -11.925808686999998
maximum row violation          0
maximum bound violation        0
maximum integrality violation  0
```

The complete solver transcript is in `logs/aggregated_gurobi_repro.log`, and
the independent audit is `artifacts/independent_solution_audit.json`.

## Other attempts and why they were superseded

The first API research segment proposed capacity Lagrangian dualization,
exact-flow neighborhood search, and logic-based Benders. The public selector
set was independently re-evaluated by a rectangular assignment algorithm and
matched its objective exactly. A 100,000-iteration Lagrangian diagnostic gave
only the root-style bound `-12.415306729`; it did not close the gap. Its more
important output was the discovery that 320 cost columns collapse to 40 exact
types. The exact quotient then made the harder generic approaches unnecessary.

Three oversized API segments returned HTTP 524 and were not committed or
credited. Two bounded calls succeeded. The last one acted as a skeptical
referee and confirmed the quotient/lifting logic conditional on the recorded
structural checks. API usage for successful calls was 20,034 total tokens
(10,392 plus 9,642).

## Reproduction

From a Python environment containing Gurobi, NumPy, and SciPy:

```powershell
python scripts\analyze_lagrangian.py input\neos-2978205-isar.mps.gz input\neos-2978205-isar.public.sol.gz artifacts\main_lagrangian.json --iterations 100000
python scripts\solve_aggregated.py input\neos-2978205-isar.mps.gz input\neos-2978205-isar.public.sol.gz artifacts\aggregated_solve.json solutions\aggregated_lifted.sol.gz logs\aggregated_gurobi_repro.log --time-limit 600
```

The second command automatically rejects any failure of the 40-type copy and
group-transversal assumptions before constructing the quotient.

