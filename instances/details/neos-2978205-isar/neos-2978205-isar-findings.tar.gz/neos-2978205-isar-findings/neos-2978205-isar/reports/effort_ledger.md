# Effort ledger — `neos-2978205-isar`

| Start (Asia/Shanghai) | End | Activity | Solver time counted | Evidence |
|---|---|---|---:|---|
| 2026-09-09 01:30:05 | 2026-09-09 01:36 | Created isolated directory, downloaded official MPS and incumbent, extracted read-only Gurobi structure, opened official MIPLIB page and same-family sibling | 0 s | `input/`, `structure/`, `sources/sources.md` |
| 2026-09-09 01:33 | 2026-09-09 01:36 | First direct API segment with `gpt-5.6-sol` at `xhigh` and a 10k completion allowance; gateway returned HTTP 524 and `call_direct.py` correctly committed neither response nor session | 0 s | `logs/api_failures.md` |
| 2026-09-09 01:36 | 2026-09-09 01:40 | Retried the initial segment at high reasoning with a 6k allowance; gateway again returned HTTP 524 with no state committed | 0 s | `logs/api_failures.md` |
| 2026-09-09 01:40 | 2026-09-09 01:44 | Successful bounded API research segment: recovered capacitated assignment formulation, proposed exact-flow evaluation, Lagrangian certificate, and Benders route | 0 s | `responses/01a_bounded_structural_plan.json` |
| 2026-09-09 01:44 | 2026-09-09 01:49 | Implemented and ran structure-driven incumbent audit, exact fixed-selector assignment, cost-rank/duplication diagnostics, and 100,000-iteration Lagrangian experiment; also calibrated on the solved sibling | 0 s | `scripts/analyze_lagrangian.py`, `artifacts/main_lagrangian.json`, `artifacts/sibling_lagrangian.json` |
| 2026-09-09 01:49 | 2026-09-09 01:53 | Stateful API implementation request returned HTTP 524; state remained intact | 0 s | `logs/api_failures.md` |
| 2026-09-09 01:53 | 2026-09-09 02:10 | Derived and implemented the exact 40-type symmetry quotient, including the Gale-Ryser margin condition and a constructive lift; prototype and reproducibility quotient solves both proved optimal at the root | 0.565 s | `scripts/solve_aggregated.py`, `artifacts/aggregated_solve.json`, `artifacts/exact_quotient.mps`, `logs/aggregated_gurobi*.log` |
| 2026-09-09 02:10 | 2026-09-09 02:12 | Independent original-MPS solution audit (read/evaluate only, no optimize) | 0 s | `artifacts/independent_solution_audit.json` |
| 2026-09-09 02:12 | 2026-09-09 02:14 | Successful stateful API referee pass over the quotient/lifting proof | 0 s | `responses/04_certificate_audit.json` |
| 2026-09-09 02:14 | 2026-09-09 02:16 | Exported exact quotient, mapping certificate, lifted solution, and final report | 0 s | `artifacts/`, `solutions/`, `reports/final_report.md` |

Minimum required research wall time: 60 minutes, unless a strict optimality
certificate is obtained earlier. General-purpose optimizer budget: at most
1,800 seconds total for this instance.

Terminal condition: strict optimality was obtained before 60 minutes. Total
wall-clock research interval was approximately 46 minutes. Total generic MIP
optimization time was approximately 0.565 seconds across the prototype and the
reproducibility replay; both solved the exact quotient at the root.
