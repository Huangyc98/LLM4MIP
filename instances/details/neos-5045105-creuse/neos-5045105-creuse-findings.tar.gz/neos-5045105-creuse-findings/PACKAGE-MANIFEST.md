# Package manifest: neos-5045105-creuse

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 39
Excluded source files: 1

## Included files

- `README.md`
- `background.md`
- `runs/gurobi-20260902-204410-d74449a4/driver.stderr`
- `runs/gurobi-20260902-204410-d74449a4/driver.stdout`
- `runs/gurobi-20260902-204410-d74449a4/result.json`
- `runs/gurobi-20260902-204410-d74449a4/solver.log`
- `runs/gurobi-20260902-204428-b88d3796/best.sol`
- `runs/gurobi-20260902-204428-b88d3796/driver.stderr`
- `runs/gurobi-20260902-204428-b88d3796/driver.stdout`
- `runs/gurobi-20260902-204428-b88d3796/result.json`
- `runs/gurobi-20260902-204428-b88d3796/solver.log`
- `runs/gurobi-20260902-205003-cf1c753a/best.sol`
- `runs/gurobi-20260902-205003-cf1c753a/driver.stderr`
- `runs/gurobi-20260902-205003-cf1c753a/driver.stdout`
- `runs/gurobi-20260902-205003-cf1c753a/result.json`
- `runs/gurobi-20260902-205003-cf1c753a/solver.log`
- `runs/gurobi-20260902-212226-7722ecb5/best.sol`
- `runs/gurobi-20260902-212226-7722ecb5/driver.stderr`
- `runs/gurobi-20260902-212226-7722ecb5/driver.stdout`
- `runs/gurobi-20260902-212226-7722ecb5/result.json`
- `runs/gurobi-20260902-212226-7722ecb5/solver.log`
- `runs/gurobi-20260902-222829-456717a3/best.sol`
- `runs/gurobi-20260902-222829-456717a3/driver.stderr`
- `runs/gurobi-20260902-222829-456717a3/driver.stdout`
- `runs/gurobi-20260902-222829-456717a3/result.json`
- `runs/gurobi-20260902-222829-456717a3/solver.log`
- `runs/gurobi-20260902-233933-05942c62/best.sol`
- `runs/gurobi-20260902-233933-05942c62/driver.stderr`
- `runs/gurobi-20260902-233933-05942c62/driver.stdout`
- `runs/gurobi-20260902-233933-05942c62/result.json`
- `runs/gurobi-20260902-233933-05942c62/solver.log`
- `runs/gurobi-20260903-004608-22a6b1d3/best.sol`
- `runs/gurobi-20260903-004608-22a6b1d3/driver.stderr`
- `runs/gurobi-20260903-004608-22a6b1d3/driver.stdout`
- `runs/gurobi-20260903-004608-22a6b1d3/result.json`
- `runs/gurobi-20260903-004608-22a6b1d3/solver.log`
- `strategy.md`
- `structure-gurobi.log`
- `structure.json`

## Excluded files

- `input/neos-5045105-creuse.mps.gz (86564 bytes; raw benchmark input; sha256 e97c1d05f8d41bcebd795035b657d9e841e3db82b88a02e8e252d75f488e87c0)`
