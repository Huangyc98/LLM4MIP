# `genus-sym-g31-8`

## Result

**Current exact-decimal MPS status: global lower bound -23; optimum unresolved.**
The native graph has orientable genus 3.

The model encodes a 31-vertex, 58-edge graph with interchangeable face labels
and valid ordering constraints. A fresh specialized serial `multi_genus`
computation reports orientable genus **3**, while a separate exhaustive
decision run rules out genus at most 2. This confirms the original-MPS global
lower bound **-23**.

The archived objective `-23` point is integral and within bounds, but it
violates seven literal decimal MPS rows by `1e-15`: each active triangular face
evaluates `1 - 3*0.333333333333333 = 1e-15`. It is tolerance-feasible, not a
zero-tolerance rational witness. The native graph optimum is established, but
the literal exact-decimal MPS optimum is not closed until a strict `-23`
witness or another complete upper-bound argument is supplied. The detailed
recheck is in the
[rows 6–20 independent review](../../docs/rows-06-20-dual-bound-review-2026-09-18/genus-sym-g31-8/README.md).

## Provenance

- Compressed MPS SHA-256: `2D5B09C516C8600EDA8E805DECEF9B092CD0875C7D42875FFB51AA490BC96555`
- Official compressed solution SHA-256: `7DE38A334B705C65C871B75971BE2512510EEB457D22A12CFCB5C669A46ED2F6`
- [MIPLIB instance page](https://miplib.zib.de/instance_details_genus-sym-g31-8.html)

Reproduction inputs and transcripts are in [`artifacts/`](artifacts/) and
[`logs/`](logs/). Shared source-recovery tooling is in
[`common/reproduce_genus_artifacts.py`](../../common/reproduce_genus_artifacts.py).
