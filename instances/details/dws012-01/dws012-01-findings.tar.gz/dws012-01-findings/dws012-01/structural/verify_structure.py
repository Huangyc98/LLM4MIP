#!/usr/bin/env python3
"""Structural and incumbent checks for MIPLIB dws012-01.

No optimizer is called.  The script verifies the official bordered
decomposition, reconstructs its 7x7 Freudenthal blocks, and checks the exact
finite-state counts used in the logarithmic reformulation described in
README.md.
"""

from __future__ import annotations

import argparse
import collections
import gzip
import hashlib
import json
import math
from pathlib import Path


def parse_mps(path: Path):
    senses, rhs = {}, {}
    cols, rows = collections.defaultdict(dict), collections.defaultdict(dict)
    bounds, integer = {}, set()
    section, int_mode = None, False
    headers = {
        "NAME", "OBJSENSE", "ROWS", "COLUMNS", "RHS", "RANGES",
        "BOUNDS", "SOS", "INDICATORS", "ENDATA",
    }
    with gzip.open(path, "rt", encoding="latin-1") as fh:
        for raw in fh:
            line = raw.strip()
            if not line or line.startswith("*"):
                continue
            p = line.split()
            is_header = p[0] in headers and (
                p[0] not in {"RHS", "RANGES"} or len(p) == 1
            )
            if is_header:
                section = p[0]
                continue
            if section == "ROWS":
                senses[p[1]] = p[0]
            elif section == "COLUMNS":
                if len(p) >= 3 and p[1].strip("'") == "MARKER":
                    int_mode = p[2].strip("'") == "INTORG"
                    continue
                v = p[0]
                if int_mode:
                    integer.add(v)
                for k in range(1, len(p), 2):
                    r, a = p[k], float(p[k + 1])
                    cols[v][r] = cols[v].get(r, 0.0) + a
                    rows[r][v] = rows[r].get(v, 0.0) + a
            elif section == "RHS":
                for k in range(1, len(p), 2):
                    rhs[p[k]] = float(p[k + 1])
            elif section == "BOUNDS":
                typ, v = p[0], p[2]
                val = float(p[3]) if len(p) > 3 else None
                lo, up = bounds.get(v, (0.0, math.inf))
                if typ in {"UP", "UI"}:
                    up = val
                elif typ in {"LO", "LI"}:
                    lo = val
                elif typ == "FX":
                    lo = up = val
                elif typ == "BV":
                    lo, up = 0.0, 1.0
                elif typ == "FR":
                    lo, up = -math.inf, math.inf
                elif typ == "MI":
                    lo = -math.inf
                elif typ == "PL":
                    up = math.inf
                else:
                    raise ValueError(typ)
                if typ in {"UI", "LI", "BV"}:
                    integer.add(v)
                bounds[v] = lo, up
    return senses, cols, rows, rhs, bounds, integer


def read_solution(path: Path):
    values, declared = {}, None
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8") as fh:
        for raw in fh:
            p = raw.split()
            if not p:
                continue
            if p[0] == "=obj=":
                declared = float(p[-1])
            elif raw.startswith("# Objective value ="):
                declared = float(raw.split("=", 1)[1])
            elif not raw.startswith("#") and len(p) >= 2:
                values[p[0]] = float(p[1])
    return values, declared


def parse_dec(path: Path):
    blocks, master = collections.defaultdict(list), []
    current, nblocks, expect_count = None, None, False
    with path.open() as fh:
        for raw in fh:
            s = raw.strip()
            if not s or s.startswith("\\"):
                continue
            if s == "NBLOCKS":
                expect_count = True
                continue
            if expect_count:
                nblocks, expect_count = int(s), False
                continue
            if s.startswith("BLOCK "):
                current = int(s.split()[1])
            elif s == "MASTERCONSS":
                current = "master"
            elif s.startswith("c"):
                (master if current == "master" else blocks[current]).append(s)
    return nblocks, dict(blocks), master


def vid(v):
    return int(v[3:])


def expected_triangles():
    ans = []
    for i in range(6):
        for j in range(6):
            a, b = 7 * i + j, 7 * i + j + 1
            c, d = 7 * (i + 1) + j, 7 * (i + 1) + j + 1
            ans.extend(({a, b, c}, {b, c, d}))
    return ans


def main():
    here = Path(__file__).resolve().parent
    ap = argparse.ArgumentParser()
    ap.add_argument("--mps", type=Path, default=here.parent / "input" / "dws012-01.mps.gz")
    ap.add_argument("--solution", type=Path, default=here.parent / "solutions" / "strict-repaired.sol")
    ap.add_argument("--dec", type=Path, default=here / "official_original.dec")
    ap.add_argument("--presolved-dec", type=Path, default=here / "official_presolved.dec")
    args = ap.parse_args()

    senses, cols, rows, rhs, bounds, integer = parse_mps(args.mps)
    obj = next(r for r, typ in senses.items() if typ == "N")
    conrows = [r for r, typ in senses.items() if typ != "N"]
    binary = {v for v in integer if bounds.get(v, (0.0, math.inf)) == (0.0, 1.0)}
    assert (len(cols), len(conrows), len(binary), len(cols) - len(integer)) == (26148, 14280, 15576, 10572)
    assert sum(len(rows[r]) for r in conrows) == 132936
    assert len(rows[obj]) == 462

    # There are repeated *templates*, but no literal duplicate row or column
    # that can be removed by a coefficient-signature test.
    full_column_signatures = collections.Counter(
        tuple(sorted(column.items())) for column in cols.values()
    )
    matrix_column_signatures = collections.Counter(
        tuple(sorted((r, a) for r, a in column.items() if r != obj))
        for column in cols.values()
    )
    row_signatures = collections.Counter(
        (senses[r], rhs.get(r, 0.0), tuple(sorted(rows[r].items())))
        for r in conrows
    )
    assert max(full_column_signatures.values()) == 1
    assert max(matrix_column_signatures.values()) == 1
    assert max(row_signatures.values()) == 1

    # The six binary families exhaust the integer variables exactly.
    families = {
        "pipe": {f"VAR{i}" for i in range(739, 805)},
        "pump_install": {f"VAR{i}" for i in range(805, 1003)},
        "pump_operate": {f"VAR{i}" for i in range(1003, 1201)},
        "diameter_interval": {f"VAR{i}" for i in range(1333, 2125)},
        "flow_sign": {f"VAR{i}" for i in range(2191, 2257)},
        "triangle": {f"VAR{i}" for i in range(11959, 26215)},
    }
    assert set().union(*families.values()) == binary
    assert sum(map(len, families.values())) == len(binary)

    # Numerical validation of MIPLIB solution 2.  The archive itself reports a
    # ~7e-7 feasibility residual, so this is deliberately not called exact.
    values, declared = read_solution(args.solution)
    objective = sum(cols[v].get(obj, 0.0) * values.get(v, 0.0) for v in cols)
    max_row_violation, violated_rows = 0.0, 0
    for r in conrows:
        activity = sum(a * values.get(v, 0.0) for v, a in rows[r].items())
        b = rhs.get(r, 0.0)
        violation = (max(0.0, activity - b) if senses[r] == "L" else
                     max(0.0, b - activity) if senses[r] == "G" else
                     abs(activity - b))
        max_row_violation = max(max_row_violation, violation)
        violated_rows += violation > 0
    bound_violations = 0
    integer_violations = 0
    for v in cols:
        x = values.get(v, 0.0)
        lo, up = bounds.get(v, (0.0, math.inf))
        bound_violations += x < lo or x > up
        integer_violations += v in integer and x != round(x)
    assert abs(objective - declared) < 1e-8
    assert max_row_violation < 7.0e-7
    assert not bound_violations and not integer_violations

    def objective_between(lo, hi):
        return sum(cols[f"VAR{i}"].get(obj, 0.0) * values.get(f"VAR{i}", 0.0)
                   for i in range(lo, hi + 1))

    objective_split = {
        "operating_power": objective_between(1, 198),
        "pipes": objective_between(739, 804),
        "pump_investment": objective_between(805, 1002),
    }
    assert abs(sum(objective_split.values()) - objective) < 1e-8

    # Verify the official bordered decomposition.
    nblocks, blocks, master = parse_dec(args.dec)
    assert nblocks == len(blocks) == 199
    assert collections.Counter(map(len, blocks.values())) == {49: 198, 3192: 1}
    assert len(master) == 1386
    assert sum(map(len, blocks.values())) + len(master) == len(conrows)
    row_block = {r: b for b, rr in blocks.items() for r in rr}
    master_set = set(master)
    block_vars = collections.defaultdict(set)
    master_only, multiblock = set(), set()
    for v, column in cols.items():
        memberships = {row_block[r] for r, a in column.items() if r in row_block and a}
        if len(memberships) == 1:
            block_vars[next(iter(memberships))].add(v)
        elif len(memberships) > 1:
            multiblock.add(v)
        elif any(r in master_set and a for r, a in column.items()):
            master_only.add(v)
    assert not multiblock
    assert len(block_vars[1]) == 1992
    assert {vid(v) for v in master_only} == set(range(1, 199))
    assert all(len(block_vars[b]) == 121 for b in range(2, 200))

    # SCIP's published presolved decomposition preserves the 198 local pump
    # blocks and the complete 1,386-row border; only the core block shrinks.
    pnblocks, pblocks, pmaster = parse_dec(args.presolved_dec)
    assert pnblocks == len(pblocks) == 199
    assert collections.Counter(map(len, pblocks.values())) == {49: 198, 2453: 1}
    assert len(pmaster) == 1386

    # Each of the 198 small blocks is exactly a 7x7 grid (49 convex weights)
    # with the 72 triangles of a Freudenthal triangulation.
    target_triangles = expected_triangles()
    for b in range(2, 200):
        vv = block_vars[b]
        lam = sorted((v for v in vv if v not in integer), key=vid)
        tri = sorted((v for v in vv if v in integer), key=vid)
        assert len(lam) == 49 and len(tri) == 72
        assert not any(cols[v].get(obj, 0.0) for v in vv)
        local_rows = blocks[b]
        lambda_row = {}
        for r in local_rows:
            ll = [(v, a) for v, a in rows[r].items() if v in lam and a]
            zz = [(v, a) for v, a in rows[r].items() if v in tri and a]
            assert len(ll) == 1 and ll[0][1] == 1.0
            assert zz and all(a == -1.0 for _, a in zz)
            lambda_row[ll[0][0]] = r
        supports = []
        for z in tri:
            support = {lam.index(v) for v, r in lambda_row.items() if rows[r].get(z) == -1.0}
            assert len(support) == 3
            supports.append(support)
        assert supports == target_triangles

        touched_master = {r for v in vv for r, a in cols[v].items() if r in master_set and a}
        assert len(touched_master) == 7
        activation = f"VAR{1003 + (b - 2)}"
        lambda_sum = [r for r in touched_master
                      if sum(rows[r].get(v) == 1.0 for v in lam) == 49]
        triangle_sum = [r for r in touched_master
                        if sum(rows[r].get(v) == 1.0 for v in tri) == 72]
        assert len(lambda_sum) == len(triangle_sum) == 1
        assert rows[lambda_sum[0]].get(activation) == -1.0
        assert rows[triangle_sum[0]].get(activation) == -1.0

    # One load case makes all 198 operational activation binaries exact copies
    # of the corresponding first-stage installation binaries.
    equality_pairs = 0
    for p in range(198):
        install, operate = f"VAR{805 + p}", f"VAR{1003 + p}"
        signature = {install: -1.0, operate: 1.0}
        found = collections.Counter()
        for r in set(cols[install]).intersection(cols[operate]):
            if rows[r] == signature and rhs.get(r, 0.0) == 0.0:
                found[senses[r]] += 1
        assert found == {"G": 1, "L": 1}
        equality_pairs += 1

    # Per candidate pipe: at most one of three pump types and installation
    # implies the pipe exists.
    for a in range(66):
        pipe = f"VAR{739 + a}"
        installs = [f"VAR{805 + 3 * a + t}" for t in range(3)]
        assert any(senses[r] == "L" and rhs.get(r, 0.0) == 1.0 and
                   rows[r] == {v: 1.0 for v in installs} for r in conrows)
        for install in installs:
            assert any(senses[r] == "L" and rhs.get(r, 0.0) == 0.0 and
                       rows[r] == {pipe: -1.0, install: 1.0} for r in conrows)

    # The sign binaries are explicitly fixed to one.  They then make the
    # auxiliary absolute-flow variables equal the already nonnegative flows.
    for a in range(66):
        q, aq, sign = f"VAR{661 + a}", f"VAR{2125 + a}", f"VAR{2191 + a}"
        base = 1 + 28 * a
        assert senses[f"c{base}"] == "L" and rows[f"c{base}"] == {q: 1.0, aq: -1.0}
        assert senses[f"c{base+1}"] == "L" and rhs[f"c{base+1}"] == 61.0
        assert rows[f"c{base+1}"] == {q: -1.0, aq: 1.0, sign: 61.0}
        assert senses[f"c{base+2}"] == "E" and rhs[f"c{base+2}"] == 1.0
        assert rows[f"c{base+2}"] == {sign: 1.0}

    # Recover the exact finite-state set of the 12 pipe-diameter selectors.
    lower = [0.0, 0.5, 0.7, 1.1, 1.8, 2.9, 4.3, 7.4, 10.2, 14.7, 20.4, 30.6]
    upper = [0.5, 0.7, 1.1, 1.8, 2.9, 4.3, 7.4, 10.2, 14.7, 20.4, 30.6, 60.0]
    diameter = [10.0, 13.0, 16.0, 19.6, 25.6, 32.0, 39.0, 51.0, 60.0, 72.1, 84.9, 104.0]
    feasible_diameter_states = []
    for mask in range(1, 1 << 12):
        selected = tuple(j for j in range(12) if mask & (1 << j))
        if (max(lower[j] for j in selected) <= min(upper[j] for j in selected) and
                9.0 <= sum(diameter[j] for j in selected) <= 105.0):
            feasible_diameter_states.append(selected)
    assert len(feasible_diameter_states) == 19
    assert collections.Counter(map(len, feasible_diameter_states)) == {1: 12, 2: 7}

    # The direct row-variable graph is connected; the 199-way structure is a
    # bordered decomposition, not a connected-component split.
    unseen = set(conrows)
    components = []
    while unseen:
        seed = unseen.pop()
        rr, vv, queue = {seed}, set(), [seed]
        while queue:
            r = queue.pop()
            for v, a in rows[r].items():
                if not a or v in vv:
                    continue
                vv.add(v)
                for r2, a2 in cols[v].items():
                    if r2 != obj and a2 and r2 in unseen:
                        unseen.remove(r2)
                        rr.add(r2)
                        queue.append(r2)
        components.append((len(rr), len(vv)))
    assert components == [(14280, 26148)]

    # Information-theoretically minimal generic binary code lengths for the
    # exact per-pipe configuration embeddings described in README.md.
    pump_states_per_pipe = 1 + 3 * 72  # off, or type x triangle
    pump_code_bits = math.ceil(math.log2(pump_states_per_pipe))
    diameter_code_bits = math.ceil(math.log2(len(feasible_diameter_states)))
    encoded_binary_count = 66 * (1 + pump_code_bits + diameter_code_bits)
    assert (pump_states_per_pipe, pump_code_bits, diameter_code_bits) == (217, 8, 5)
    assert encoded_binary_count == 924

    out = {
        "status": "PASS",
        "sha256_mps": hashlib.sha256(args.mps.read_bytes()).hexdigest(),
        "sha256_solution": hashlib.sha256(args.solution.read_bytes()).hexdigest(),
        "sha256_original_decomposition": hashlib.sha256(args.dec.read_bytes()).hexdigest(),
        "sha256_presolved_decomposition": hashlib.sha256(args.presolved_dec.read_bytes()).hexdigest(),
        "incumbent": {
            "declared": declared,
            "recomputed": objective,
            "listed_nonzeros": len(values),
            "max_constraint_residual": max_row_violation,
            "rows_with_nonzero_floating_residual": violated_rows,
            "bound_violations": bound_violations,
            "integer_violations": integer_violations,
            "objective_split": objective_split,
        },
        "decomposition": {
            "blocks": nblocks,
            "core_rows": len(blocks[1]),
            "core_variables": len(block_vars[1]),
            "pump_blocks": 198,
            "rows_per_pump_block": 49,
            "variables_per_pump_block": 121,
            "master_rows": len(master),
            "master_only_power_variables": len(master_only),
            "cross_block_variables": len(multiblock),
            "presolved_core_rows": len(pblocks[1]),
            "presolved_master_rows": len(pmaster),
        },
        "exact_reduction_evidence": {
            "operate_equals_install_pairs": equality_pairs,
            "fixed_flow_sign_binaries": 66,
            "triangles_per_pump_block": 72,
            "joint_pump_states_per_pipe_including_off": pump_states_per_pipe,
            "joint_pump_code_bits_per_pipe": pump_code_bits,
            "exact_diameter_states_per_pipe": len(feasible_diameter_states),
            "diameter_state_histogram": dict(collections.Counter(map(len, feasible_diameter_states))),
            "diameter_code_bits_per_pipe": diameter_code_bits,
            "projected_binary_count": encoded_binary_count,
            "original_binary_count": len(binary),
            "literal_duplicate_full_column_groups": sum(
                n > 1 for n in full_column_signatures.values()
            ),
            "literal_duplicate_matrix_column_groups": sum(
                n > 1 for n in matrix_column_signatures.values()
            ),
            "literal_duplicate_row_groups": sum(n > 1 for n in row_signatures.values()),
        },
    }
    print(json.dumps(out, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
