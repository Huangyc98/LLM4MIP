# `dws012-01` — strict recourse repair and structural projection

Official MIPLIB page: <https://miplib.zib.de/instance_details_dws012-01.html>

## Result

`dws012-01` remains **globally open**.

| quantity | value | evidence |
|---|---:|---|
| numerically strict feasible UB | **`82030.55222224`** | original MPS; max Decimal row residual `1.825e-12`; zero bound/integrality violation |
| numerical LB | **`44641.72316928`** | Gurobi 13.0.2, 600 s, two threads |
| numerical gap | `45.5792%` | time-limit result |
| fixed-design recourse | `82030.55222224` | continuous LP optimal for the fixed integer design only |

The official headline `82030.53014261134` has a maximum row violation of
about `6.94e-7`.  The two official records use the same 15,576 binary
assignments; their objective difference comes from the displayed continuous
realization.  Reoptimizing continuous recourse for that common design produces
[`strict-repaired.sol`](solutions/strict-repaired.sol), accepted at
`1e-9` feasibility and integrality tolerances.

“Strict” here means a strong numerical `1e-9` check.  The serialized decimal
vector has tiny nonzero residuals and is not described as an exact-zero
rational certificate.

## Recovered structure

The water-network design model contains 66 candidate pipes and 198 pump
blocks.  Each pump block has a 7-by-7 ACC grid and 72 triangle selectors.
The supplied [structural verifier](structural/verify_structure.py) confirms:

- 198 operation binaries equal the corresponding installation binaries;
- 66 flow-sign binaries are fixed;
- each pipe has 217 joint pump states, encodable with eight bits;
- each pipe has 19 feasible diameter states, encodable with five bits; and
- the resulting exact projection blueprint uses **924 binaries**, down from
  15,576.

This is a proved projection/lift blueprint, but no 924-binary reduced model was
generated or solved.  It therefore adds no global bound by itself.

## Reproduction and evidence boundary

The original MPS is downloaded separately as described in
[`input/README.md`](input/README.md).  The [fixed-recourse
log](logs/fixed-integer-recourse.log) and [600-second original-model
log](logs/original-proof-600s.log) are public, sanitized copies.

The incumbent is independently checkable.  The lower bound is floating-point
solver evidence without a portable proof trace, so this package does not
claim global optimality.
