#!/usr/bin/env python3
"""Fix every integer variable in an MPS to values from a complete .sol start."""

from __future__ import annotations

import gzip
import sys

from make_complete_integer_start import integer_variables, read_solution


def open_input(path: str):
    return gzip.open(path, "rt", encoding="iso-8859-1") if path.endswith(".gz") else open(path, encoding="iso-8859-1")


def open_output(path: str):
    return gzip.open(path, "wt", encoding="iso-8859-1") if path.endswith(".gz") else open(path, "w", encoding="iso-8859-1")


def main(mps_path: str, integer_solution: str, output_path: str) -> None:
    integers = set(integer_variables(mps_path))
    values = read_solution(integer_solution)
    missing = integers - set(values)
    if missing:
        raise ValueError(f"integer start is incomplete: {len(missing)} missing values")
    section = ""
    fixed = set()
    with open_input(mps_path) as source, open_output(output_path) as out:
        for raw in source:
            fields = raw.split()
            if fields and fields[0] in {"ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA"} and len(fields) == 1:
                section = fields[0]
            if section == "BOUNDS" and len(fields) >= 3 and fields[0] not in {"BOUNDS", "ENDATA"}:
                _, bound_name, var = fields[:3]
                if var in integers:
                    value = values[var]
                    if abs(value - round(value)) > 1e-9:
                        raise ValueError(f"nonintegral value for {var}: {value}")
                    out.write(f" FX {bound_name:<18} {var:<40} {round(value)}\n")
                    fixed.add(var)
                    continue
            out.write(raw)
    if fixed != integers:
        raise ValueError(f"could not replace bounds for {len(integers-fixed)} integer variables")
    print(f"fixed_integer_variables={len(fixed)}")
    print(f"output={output_path}")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], sys.argv[3])
