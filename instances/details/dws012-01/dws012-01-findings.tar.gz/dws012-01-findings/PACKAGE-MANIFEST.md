# Package manifest: dws012-01

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 16
Excluded source files: 0

## Included files

- `README.md`
- `analysis/compare_solutions.py`
- `analysis/fix_integer_assignment.py`
- `analysis/make_complete_integer_start.py`
- `artifacts/result.json`
- `input/README.md`
- `input/SHA256SUMS`
- `logs/fixed-integer-recourse.log`
- `logs/original-proof-600s.log`
- `solutions/official-id1.sol.gz`
- `solutions/official-id2.sol.gz`
- `solutions/strict-repaired.sol`
- `structural/README.md`
- `structural/official_original.dec`
- `structural/official_presolved.dec`
- `structural/verify_structure.py`

## Excluded files

- None
