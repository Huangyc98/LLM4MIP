# fhnw-schedule-paira200：冲突约束与区间能量约束证明报告

日期：2026-09-08

## 结论

本实验在未经修改的官方 Pair A MPS 上恢复调度语义，加入只对原问题整数可行解有效的两类不等式后，由 Gurobi 两次独立得到同一个全局最优值：

```text
新最优值                  -19.369961204645204
MIPLIB 当前公开 primal     -19.2298568218154
改进量                      0.140104382829804
```

第一次运行在根节点闭合；保存 proof MPS 后，使用不同 seed、单线程和不同求解参数重新读取求解，也得到相同 primal、dual 与零 gap。因此应表述为 **solver-verified global optimum**。这不是 DRAT/LRAT 或有理数形式化证明证书。

## 1. Gurobi 结构读取与语义恢复

原始模型包含：

- 20,300 个变量：20,100 个二进制变量和 200 个连续变量；
- 40,000 条约束、119,746 个非零元；
- 前 200 个二进制变量 `z_i` 是作业选择变量；
- 接下来的 200 个连续变量 `s_i` 是开始时间；
- 其余 19,900 个二进制变量对应 `C(200,2)` 个作业对的先后顺序。

对每个 `i<j`，原 MPS 恰有两条不重叠约束：

```text
s_i - s_j - 200 y_ij <= -p_i
-s_i + s_j + 200 y_ij <= 200-p_j
```

全部 39,800 条 pair rows 的变量支持、系数和右端项均按这一语义逐条核对，失败数为 0。

每个作业的开始时间下界给出 release time `r_i`。146 个可选择作业有 activation row：

```text
200 z_i + s_i <= 200 + latest_start_i
```

因此当 `z_i=1` 时，必须满足 `s_i<=latest_start_i`；真正的完成截止期是

```text
d_i = latest_start_i + p_i
```

而不是直接把 `latest_start_i` 当成 deadline。本实例 146 个可选作业恢复出的完成截止期都约等于 1（数值误差不超过 `1.42e-14`）。另有 54 个作业由 singleton row 直接固定为 `z_i=0`。

恢复出的处理时间范围为 `0.0005362652184326902` 至 `0.8985983014865992`，处理时间总和为 `48.32872394118571`。对 146 个可选作业，Pair A 与 Pair B 独立恢复的 release time 完全一致，处理时间最大差 `1.11e-16`，完成截止期最大差 `1.42e-14`。

## 2. 加入的有效不等式

### 2.1 确定性 pair-conflict 约束

对两个可选作业 `i,j`，分别检查 `i` 在 `j` 前和 `j` 在 `i` 前能否满足 release time、processing time 与 completion deadline。两个顺序都不可能时加入：

```text
z_i + z_j <= 1
```

Pair A 中加入了 708 条非冗余冲突约束。Pair B 实验报告过 4,368 条；差异来自本次先剔除了 54 个已被原 MPS 固定为 0 的选择变量，涉及这些变量的冲突约束本身是冗余的。

### 2.2 区间能量约束

对时间区间 `[a,b]`，作业 `i` 无论如何调度都必须落入该区间的最少处理量为：

```text
e_i(a,b) = max(0,
               p_i - max(0,a-r_i) - max(0,d_i-b))
```

单机在该区间只有 `b-a` 的容量，所以所有原问题整数可行解都满足：

```text
sum_i e_i(a,b) z_i <= b-a
```

由 146 个可选作业的 release/deadline 端点生成 23,158 个候选区间，在 LP 解上选择 1,500 条最强违反不等式。为避免浮点舍入误删边界可行解，写入模型时将右端放宽 `1e-11`。

## 3. 全局最优闭合

增强后的 Pair A 模型包含：

- 原始 40,000 条约束；
- 708 条非冗余 pair-conflict 约束；
- 1,500 条 energetic 约束；
- 合计 42,208 条约束、338,015 个非零元。

完整的 20,300 变量可行解作为 MIP start 加载。第一次运行使用 2 个线程、seed 23、`MIPFocus=3`、`Cuts=3`：

```text
status     OPTIMAL
primal     -19.369961204645204
dual       -19.369961204645204
gap        0
nodes      1
runtime    10.521 s
```

随后把增强模型保存为 `paira-energy-proof.mps.gz`，使用单线程、seed 71、`MIPFocus=2`、`Cuts=2`、关闭启发式重新读取求解：

```text
status     OPTIMAL
primal     -19.369961204645204
dual       -19.369961204645204
gap        0
nodes      1232
runtime    47.725 s
```

不同算法路径得到同一闭合结果。

## 4. 为什么有效不等式是关键

将同一完整最优解送入未经增强的原始 Pair A MPS，Gurobi 在 120 秒后仍停留在根节点：

```text
status     TIME_LIMIT
primal     -19.369961204645204
dual       -53.63840367317024
gap        176.9154%
nodes      1
```

因此困难主要不是找到该可行解，而是原始 pairwise big-M formulation 的 LP 松弛太弱。显式加入区间总体容量限制后，dual bound 才能闭合。

## 5. 独立审计

### 5.1 Proof model 语义审计

- proof MPS 中原始 40,000 行逐行与官方 MPS 比较，支持、系数、sense、RHS 差异均为 0；
- 708 条冲突约束逐条重新检查“两种顺序都不可能”，错误数为 0；
- 1,500 条能量约束按独立公式重算支持、系数和 RHS，差异均为 0；
- proof MPS 不存在其他无法解释的附加行；
- 语义审计结论：`semantic_audit_passed = true`。

### 5.2 最优解代回原始 Pair A

将最终 20,300 个变量值直接代回未经增强的官方 Pair A MPS，并以高精度十进制累加检查全部 40,000 行：

```text
目标值（十进制重算）       -19.3699612046452061500
选择作业数                  30
最大变量界违反              0
最大整数性违反              0
最大原始约束违反            2.842170943040401e-14
超过 1e-9 的约束违反        0
最大 selected deadline 违反 4.884981308350689e-15
最大 selected overlap       1.6653345369377348e-16
```

严格 `1e-9` 容差审计通过。

## 6. 文件与哈希

关键证据：

- [`../artifacts/structure.json`](../artifacts/structure.json)：原始结构和 39,800 条 pair rows 的语义审计；
- [`../artifacts/paira-energy-proof.mps.gz`](../artifacts/paira-energy-proof.mps.gz)：增强后的 proof MPS；
- [`../experiments/paira-energy-proof.log`](../experiments/paira-energy-proof.log)：第一次闭合日志；
- [`../artifacts/paira-energy-proof.json`](../artifacts/paira-energy-proof.json)：第一次闭合结果与全部能量区间；
- [`../solutions/global-optimal.sol`](../solutions/global-optimal.sol)：完整最优解；
- [`../artifacts/semantic-audit.json`](../artifacts/semantic-audit.json)：有效不等式与原始行语义审计；
- [`../artifacts/original-solution-audit.json`](../artifacts/original-solution-audit.json)：最终解在原 MPS 上的独立审计；
- [`../artifacts/independent-proof-rerun.json`](../artifacts/independent-proof-rerun.json)：单线程不同参数重跑；
- [`../experiments/original-baseline.json`](../experiments/original-baseline.json)：未经增强模型的 120 秒对照。

SHA-256：

```text
官方 Pair A MPS   7885f1890b486001d9ce113c02de48c12c54bb6bcd22b10db985cf74208e13d2
proof MPS         d39f95aa9d5a0a31bc9cd7f788a39477df78e21193b2801cfe8f82d8d4a2f202
最终 solution     b89dba78c1bb4b8c8df54d7dcc787ac6e03919f0b46e1c958cea61ac3753e630
```

## 7. 准确的对外表述

可以表述为：

> 对 `fhnw-schedule-paira200`，从官方 MPS 恢复单机可选作业调度结构，加入经逐条审计的冲突约束和区间能量有效不等式后，Gurobi 两次独立得到 `primal=dual=-19.369961204645204`。最终解在未经修改的原始 Pair A MPS 上通过全部约束、边界和整数性检查，因此得到 solver-verified global optimum。

不能表述为“仅凭 120 秒原模型运行证明最优”，因为该运行状态是 `TIME_LIMIT`；也不能称为独立形式化证书，因为仍依赖 Gurobi 对增强 MIP 的分支切割证明。

## 参考

- MIPLIB instance page: https://miplib.zib.de/instance_details_fhnw-schedule-paira200.html
- MIPLIB 描述该实例为带价值、deadline 与 earliest start date 的连续时间项目选择/调度问题，并说明 Pair A、Pair B、Slot 是同一问题的三个 formulation。
