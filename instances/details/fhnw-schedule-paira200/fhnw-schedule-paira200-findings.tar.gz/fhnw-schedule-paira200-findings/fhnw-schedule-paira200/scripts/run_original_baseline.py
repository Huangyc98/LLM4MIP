from __future__ import annotations

import argparse
import json
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB

from paira_common import load_complete_start, numerical_audit, sha256


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("original", type=Path)
    parser.add_argument("start", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("--time-limit", type=float, default=120.0)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    model = gp.read(str(args.original))
    loaded = load_complete_start(model, args.start)
    model.Params.LogFile = str(args.output_dir / "original-baseline.log")
    model.Params.TimeLimit = args.time_limit
    model.Params.Threads = 2
    model.Params.Seed = 19
    model.Params.MIPFocus = 3
    model.Params.Cuts = 3
    model.Params.FeasibilityTol = 1e-9
    model.Params.IntFeasTol = 1e-9
    model.Params.MIPGap = 1e-9
    model.optimize()
    report = {
        "instance": "fhnw-schedule-paira200",
        "model": "unaltered original MPS",
        "original_sha256": sha256(args.original),
        "complete_start_values_read": loaded,
        "status": int(model.Status),
        "status_name": {GRB.OPTIMAL: "OPTIMAL", GRB.TIME_LIMIT: "TIME_LIMIT", GRB.INFEASIBLE: "INFEASIBLE"}.get(model.Status, str(model.Status)),
        "runtime": model.Runtime,
        "nodes": model.NodeCount,
        "solutions": model.SolCount,
        "objective": model.ObjVal if model.SolCount else None,
        "bound": model.ObjBound,
        "gap": model.MIPGap if model.SolCount else None,
        "audit": numerical_audit(model) if model.SolCount else None,
    }
    (args.output_dir / "original-baseline.json").write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
