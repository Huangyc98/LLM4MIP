from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB

from paira_common import N_JOBS, energy_coefficients, feasible_before, load_complete_start, numerical_audit, recover_paira_data, selectable_jobs


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mps", type=Path)
    parser.add_argument("start", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("--time-limit", type=float, default=900.0)
    parser.add_argument("--threads", type=int, default=2)
    parser.add_argument("--max-energy-cuts", type=int, default=6000)
    parser.add_argument("--lp-rounds", type=int, default=4)
    parser.add_argument("--seed", type=int, default=17)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    model = gp.read(str(args.mps))
    variables = model.getVars()
    data = recover_paira_data(model)
    selectable = selectable_jobs(data)
    loaded_values = load_complete_start(model, args.start)

    conflicts: list[tuple[int, int]] = []
    for position, i in enumerate(selectable):
        for j in selectable[position + 1 :]:
            if not feasible_before(i, j, data) and not feasible_before(j, i, data):
                model.addConstr(variables[i] + variables[j] <= 1.0, name=f"pair_conflict_{i}_{j}")
                conflicts.append((i, j))
    model.update()

    endpoints = sorted(
        set(data.releases[i] for i in selectable)
        | set(data.deadlines[i] for i in selectable if data.deadlines[i] is not None)
    )
    intervals: list[tuple[float, float, dict[int, float]]] = []
    for left, a in enumerate(endpoints):
        for b in endpoints[left + 1 :]:
            coeffs = energy_coefficients(a, b, data)
            if len(coeffs) >= 2:
                intervals.append((a, b, coeffs))

    relaxation = model.relax()
    relaxation.Params.OutputFlag = 0
    relaxation.Params.Method = 1
    relaxation.Params.Threads = args.threads
    relaxation_vars = relaxation.getVars()
    added: set[tuple[float, float]] = set()
    energy_records: list[dict[str, float | int]] = []
    remaining = args.max_energy_cuts
    for round_index in range(args.lp_rounds):
        relaxation.optimize()
        z = [relaxation_vars[i].X for i in range(N_JOBS)]
        violations = []
        for a, b, coeffs in intervals:
            if (a, b) in added:
                continue
            violation = math.fsum(value * z[i] for i, value in coeffs.items()) - (b - a)
            if violation > 1e-8:
                norm = math.sqrt(math.fsum(value * value for value in coeffs.values()))
                violations.append((violation / max(norm, 1e-12), violation, a, b, coeffs))
        violations.sort(reverse=True, key=lambda row: row[0])
        take = min(remaining, 1500, len(violations))
        for _, violation, a, b, coeffs in violations[:take]:
            expression_mip = gp.LinExpr()
            expression_lp = gp.LinExpr()
            for i, coefficient in coeffs.items():
                expression_mip.add(variables[i], coefficient)
                expression_lp.add(relaxation_vars[i], coefficient)
            rhs = (b - a) + 1e-11
            cut_index = len(added)
            model.addConstr(expression_mip <= rhs, name=f"energy_{cut_index}")
            relaxation.addConstr(expression_lp <= rhs)
            added.add((a, b))
            energy_records.append({
                "index": cut_index,
                "round": round_index,
                "a": a,
                "b": b,
                "initial_violation": violation,
                "support": len(coeffs),
            })
        remaining -= take
        if take == 0 or remaining == 0:
            break
    model.update()

    proof_model = args.output_dir / "paira-energy-proof.mps.gz"
    log_path = args.output_dir / "paira-energy-proof.log"
    solution_path = args.output_dir / "paira-energy-proof.sol"
    summary_path = args.output_dir / "paira-energy-proof.json"
    model.write(str(proof_model))
    model.Params.LogFile = str(log_path)
    model.Params.TimeLimit = args.time_limit
    model.Params.Threads = args.threads
    model.Params.Seed = args.seed
    model.Params.MIPFocus = 3
    model.Params.Cuts = 3
    model.Params.Heuristics = 0.1
    model.Params.FeasibilityTol = 1e-9
    model.Params.IntFeasTol = 1e-9
    model.Params.MIPGap = 1e-9
    model.optimize()

    report: dict[str, object] = {
        "instance": "fhnw-schedule-paira200",
        "method": "Pair-A plus explicit pair conflicts and iteratively separated energetic cuts",
        "complete_start_source": str(args.start.resolve()),
        "explicit_start_values_read": loaded_values,
        "missing_start_values_filled_with_zero": model.NumVars - loaded_values,
        "pair_conflict_cuts": len(conflicts),
        "candidate_intervals": len(intervals),
        "energetic_cuts": len(added),
        "energy_cut_intervals": energy_records,
        "proof_model": str(proof_model.resolve()),
        "status": int(model.Status),
        "status_name": {GRB.OPTIMAL: "OPTIMAL", GRB.TIME_LIMIT: "TIME_LIMIT", GRB.INFEASIBLE: "INFEASIBLE"}.get(model.Status, str(model.Status)),
        "runtime": model.Runtime,
        "nodes": model.NodeCount,
        "solutions": model.SolCount,
        "objective": model.ObjVal if model.SolCount else None,
        "bound": model.ObjBound,
        "gap": model.MIPGap if model.SolCount else None,
    }
    if model.SolCount:
        report["original_model_audit"] = numerical_audit(model)
        model.write(str(solution_path))
    summary_path.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in report.items() if key != "energy_cut_intervals"}, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
