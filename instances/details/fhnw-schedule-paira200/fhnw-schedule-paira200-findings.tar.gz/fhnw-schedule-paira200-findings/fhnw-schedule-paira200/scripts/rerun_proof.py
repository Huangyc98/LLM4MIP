from __future__ import annotations

import argparse
import json
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB

from paira_common import load_complete_start, numerical_audit, sha256


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("proof", type=Path)
    parser.add_argument("start", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("--time-limit", type=float, default=900.0)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    model = gp.read(str(args.proof))
    loaded = load_complete_start(model, args.start)
    log_path = args.output_dir / "independent-proof-rerun.log"
    solution_path = args.output_dir / "independent-proof-rerun.sol"
    model.Params.LogFile = str(log_path)
    model.Params.TimeLimit = args.time_limit
    model.Params.Threads = 1
    model.Params.Seed = 71
    model.Params.MIPFocus = 2
    model.Params.Cuts = 2
    model.Params.Heuristics = 0.0
    model.Params.FeasibilityTol = 1e-9
    model.Params.IntFeasTol = 1e-9
    model.Params.MIPGap = 1e-9
    model.optimize()
    report = {
        "instance": "fhnw-schedule-paira200",
        "proof_model_sha256": sha256(args.proof),
        "complete_start_values_read": loaded,
        "status": int(model.Status),
        "status_name": {GRB.OPTIMAL: "OPTIMAL", GRB.TIME_LIMIT: "TIME_LIMIT", GRB.INFEASIBLE: "INFEASIBLE"}.get(model.Status, str(model.Status)),
        "runtime": model.Runtime,
        "nodes": model.NodeCount,
        "solutions": model.SolCount,
        "objective": model.ObjVal if model.SolCount else None,
        "bound": model.ObjBound,
        "gap": model.MIPGap if model.SolCount else None,
        "original_model_audit": numerical_audit(model) if model.SolCount else None,
    }
    if model.SolCount:
        model.write(str(solution_path))
    (args.output_dir / "independent-proof-rerun.json").write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(report, indent=2, sort_keys=True))
    if model.Status != GRB.OPTIMAL:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
