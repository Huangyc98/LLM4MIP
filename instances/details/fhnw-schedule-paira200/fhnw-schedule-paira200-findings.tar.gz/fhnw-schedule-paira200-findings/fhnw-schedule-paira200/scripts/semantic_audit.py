from __future__ import annotations

import argparse
import json
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB

from paira_common import (
    BIG_M,
    N_JOBS,
    PAIR_ROWS,
    energy_coefficients,
    feasible_before,
    recover_paira_data,
    row_coefficients,
    sha256,
)


def compare_rows(original: gp.Model, proof: gp.Model) -> tuple[int, float, float]:
    support_failures = 0
    max_coefficient_error = 0.0
    max_rhs_error = 0.0
    original_rows = original.getConstrs()
    proof_rows = proof.getConstrs()
    for index, left in enumerate(original_rows):
        right = proof_rows[index]
        left_coeff = row_coefficients(original, left)
        right_coeff = row_coefficients(proof, right)
        if set(left_coeff) != set(right_coeff) or left.Sense != right.Sense:
            support_failures += 1
        for variable_index in set(left_coeff) | set(right_coeff):
            max_coefficient_error = max(
                max_coefficient_error,
                abs(left_coeff.get(variable_index, 0.0) - right_coeff.get(variable_index, 0.0)),
            )
        max_rhs_error = max(max_rhs_error, abs(left.RHS - right.RHS))
    return support_failures, max_coefficient_error, max_rhs_error


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("original", type=Path)
    parser.add_argument("proof", type=Path)
    parser.add_argument("proof_json", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    original = gp.read(str(args.original))
    proof = gp.read(str(args.proof))
    data = recover_paira_data(original)
    metadata = json.loads(args.proof_json.read_text(encoding="utf-8"))
    proof_rows = {row.ConstrName: row for row in proof.getConstrs()}

    original_support_failures, original_max_coeff_error, original_max_rhs_error = compare_rows(original, proof)

    conflict_rows = [row for row in proof.getConstrs() if row.ConstrName.startswith("pair_conflict_")]
    bad_conflicts = 0
    max_conflict_rhs_error = 0.0
    for row in conflict_rows:
        fields = row.ConstrName.split("_")
        i, j = int(fields[-2]), int(fields[-1])
        expected = {i: 1.0, j: 1.0}
        if (
            i in data.forced_zero
            or j in data.forced_zero
            or feasible_before(i, j, data)
            or feasible_before(j, i, data)
            or row.Sense != GRB.LESS_EQUAL
            or row_coefficients(proof, row) != expected
        ):
            bad_conflicts += 1
        max_conflict_rhs_error = max(max_conflict_rhs_error, abs(row.RHS - 1.0))

    energy_records = metadata["energy_cut_intervals"]
    bad_energy_support = 0
    max_energy_coefficient_error = 0.0
    max_energy_rhs_error = 0.0
    missing_energy_rows = 0
    for record in energy_records:
        name = f"energy_{record['index']}"
        row = proof_rows.get(name)
        if row is None:
            missing_energy_rows += 1
            continue
        actual = row_coefficients(proof, row)
        expected = energy_coefficients(record["a"], record["b"], data)
        if set(actual) != set(expected) or row.Sense != GRB.LESS_EQUAL:
            bad_energy_support += 1
        for variable_index in set(actual) | set(expected):
            max_energy_coefficient_error = max(
                max_energy_coefficient_error,
                abs(actual.get(variable_index, 0.0) - expected.get(variable_index, 0.0)),
            )
        max_energy_rhs_error = max(
            max_energy_rhs_error,
            abs(row.RHS - ((record["b"] - record["a"]) + 1e-11)),
        )

    named_cut_rows = len(conflict_rows) + sum(row.ConstrName.startswith("energy_") for row in proof.getConstrs())
    unexplained_extra_rows = proof.NumConstrs - original.NumConstrs - named_cut_rows
    passed = (
        original_support_failures == 0
        and original_max_coeff_error <= 1e-12
        and original_max_rhs_error <= 1e-12
        and len(conflict_rows) == metadata["pair_conflict_cuts"]
        and bad_conflicts == 0
        and max_conflict_rhs_error <= 1e-12
        and len(energy_records) == metadata["energetic_cuts"]
        and missing_energy_rows == 0
        and bad_energy_support == 0
        and max_energy_coefficient_error <= 1e-12
        and max_energy_rhs_error <= 1e-12
        and unexplained_extra_rows == 0
    )
    report = {
        "instance": "fhnw-schedule-paira200",
        "original_sha256": sha256(args.original),
        "proof_model_sha256": sha256(args.proof),
        "original_rows_checked": original.NumConstrs,
        "original_row_support_failures": original_support_failures,
        "original_row_max_coefficient_error": original_max_coeff_error,
        "original_row_max_rhs_error": original_max_rhs_error,
        "pair_disjunction_rows": PAIR_ROWS,
        "job_activation_rows": N_JOBS,
        "big_m": BIG_M,
        "conflict_rows_checked": len(conflict_rows),
        "bad_conflict_rows": bad_conflicts,
        "max_conflict_rhs_error": max_conflict_rhs_error,
        "energy_rows_checked": len(energy_records),
        "missing_energy_rows": missing_energy_rows,
        "bad_energy_support": bad_energy_support,
        "max_energy_coefficient_error": max_energy_coefficient_error,
        "max_energy_rhs_error": max_energy_rhs_error,
        "unexplained_extra_rows": unexplained_extra_rows,
        "semantic_audit_passed": passed,
        "validity_note": (
            "For every selectable job, Pair A bounds its start below by r_i and the activation row "
            "bounds it above by d_i-p_i when z_i=1. Its pair rows impose a non-overlap order. "
            "Therefore pair-conflict inequalities and mandatory-overlap energetic inequalities "
            "sum_i e_i(a,b) z_i <= b-a are globally valid for every original integer-feasible solution."
        ),
    }
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))
    if not passed:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
