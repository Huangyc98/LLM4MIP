from __future__ import annotations

import gzip
import hashlib
import math
from dataclasses import dataclass
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


N_JOBS = 200
BIG_M = 200.0
PAIR_COUNT = N_JOBS * (N_JOBS - 1) // 2
PAIR_ROWS = 2 * PAIR_COUNT


@dataclass(frozen=True)
class PairAData:
    releases: list[float]
    durations: list[float]
    latest_starts: list[float | None]
    deadlines: list[float | None]
    forced_zero: list[int]


def pair_offset(i: int, j: int, n: int = N_JOBS) -> int:
    if not 0 <= i < j < n:
        raise ValueError((i, j, n))
    return i * (2 * n - i - 1) // 2 + j - i - 1


def row_coefficients(model: gp.Model, constraint: gp.Constr) -> dict[int, float]:
    row = model.getRow(constraint)
    return {row.getVar(k).index: row.getCoeff(k) for k in range(row.size())}


def recover_paira_data(model: gp.Model) -> PairAData:
    if model.NumVars != 2 * N_JOBS + PAIR_COUNT:
        raise RuntimeError(f"unexpected variable count {model.NumVars}")
    if model.NumConstrs != PAIR_ROWS + N_JOBS:
        raise RuntimeError(f"unexpected row count {model.NumConstrs}")
    variables = model.getVars()
    constraints = model.getConstrs()
    releases = [variables[N_JOBS + i].LB for i in range(N_JOBS)]

    durations: list[float | None] = [None] * N_JOBS
    for i in range(N_JOBS):
        if i < N_JOBS - 1:
            row = constraints[2 * pair_offset(i, i + 1)]
            durations[i] = -row.RHS
        else:
            row = constraints[2 * pair_offset(N_JOBS - 2, N_JOBS - 1) + 1]
            durations[i] = BIG_M - row.RHS
    if any(value is None or value <= 0.0 for value in durations):
        raise RuntimeError("failed to recover all positive processing times")
    duration_values = [float(value) for value in durations]

    forced_zero: list[int] = []
    latest_starts: list[float | None] = [None] * N_JOBS
    deadlines: list[float | None] = [None] * N_JOBS
    for i in range(N_JOBS):
        row = constraints[PAIR_ROWS + i]
        coeff = row_coefficients(model, row)
        if row.Sense == GRB.EQUAL and coeff == {i: 1.0} and abs(row.RHS) <= 1e-12:
            forced_zero.append(i)
            continue
        expected = {i: BIG_M, N_JOBS + i: 1.0}
        if row.Sense != GRB.LESS_EQUAL or coeff != expected:
            raise RuntimeError(f"unexpected job row {row.ConstrName}: {coeff}, {row.Sense}, {row.RHS}")
        latest_starts[i] = row.RHS - BIG_M
        deadlines[i] = latest_starts[i] + duration_values[i]
    return PairAData(releases, duration_values, latest_starts, deadlines, forced_zero)


def selectable_jobs(data: PairAData) -> list[int]:
    forced = set(data.forced_zero)
    return [i for i in range(N_JOBS) if i not in forced]


def feasible_before(i: int, j: int, data: PairAData) -> bool:
    if data.deadlines[i] is None or data.deadlines[j] is None:
        return False
    completion_i = data.releases[i] + data.durations[i]
    completion_j = max(data.releases[j], completion_i) + data.durations[j]
    return completion_i <= data.deadlines[i] + 1e-12 and completion_j <= data.deadlines[j] + 1e-12


def energy_coefficients(a: float, b: float, data: PairAData) -> dict[int, float]:
    result: dict[int, float] = {}
    for i in selectable_jobs(data):
        deadline = data.deadlines[i]
        assert deadline is not None
        outside_left = max(0.0, a - data.releases[i])
        outside_right = max(0.0, deadline - b)
        value = max(0.0, data.durations[i] - outside_left - outside_right)
        if value > 1e-12:
            result[i] = value
    return result


def read_solution(path: Path) -> dict[str, float]:
    opener = gzip.open if path.suffix == ".gz" else open
    values: dict[str, float] = {}
    with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
        for raw in handle:
            stripped = raw.strip()
            if not stripped or stripped.startswith("#"):
                continue
            fields = stripped.split()
            if len(fields) >= 2:
                try:
                    values[fields[0]] = float(fields[1])
                except ValueError:
                    continue
    return values


def load_complete_start(model: gp.Model, path: Path) -> int:
    values = read_solution(path)
    for variable in model.getVars():
        variable.Start = values.get(variable.VarName, 0.0)
    return len(values)


def numerical_audit(model: gp.Model) -> dict[str, float | int | bool]:
    max_bound = max_integer = max_row = 0.0
    row_count = 0
    for variable in model.getVars():
        max_bound = max(max_bound, variable.LB - variable.X, variable.X - variable.UB, 0.0)
        if variable.VType in (GRB.BINARY, GRB.INTEGER, GRB.SEMIINT):
            max_integer = max(max_integer, abs(variable.X - round(variable.X)))
    for constraint in model.getConstrs()[: PAIR_ROWS + N_JOBS]:
        row = model.getRow(constraint)
        activity = math.fsum(row.getCoeff(k) * row.getVar(k).X for k in range(row.size()))
        if constraint.Sense == GRB.LESS_EQUAL:
            violation = max(activity - constraint.RHS, 0.0)
        elif constraint.Sense == GRB.GREATER_EQUAL:
            violation = max(constraint.RHS - activity, 0.0)
        else:
            violation = abs(activity - constraint.RHS)
        max_row = max(max_row, violation)
        row_count += int(violation > 1e-9)
    return {
        "max_bound_violation": max_bound,
        "max_integrality_violation": max_integer,
        "max_original_row_violation": max_row,
        "original_row_violations_over_1e_9": row_count,
        "strictly_feasible_1e_9": max(max_bound, max_integer, max_row) <= 1e-9,
    }


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()
