#!/usr/bin/env python3
"""Strengthen the original incremental model with redundant local hull variables."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import gurobipy as gp


SIZES = (2.0, 10.0, 25.0, 100.0, 200.0, 500.0)
GLOBAL_STRESS = 2.76


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("--output-model", type=Path, required=True)
    parser.add_argument("--summary", type=Path, required=True)
    args = parser.parse_args()

    model = gp.read(str(args.model))
    member_count = sum(var.VarName.startswith("x_") for var in model.getVars())
    compression = {}
    for constraint in model.getConstrs():
        expression = model.getRow(constraint)
        if expression.size() != 2 or constraint.Sense != "<" or constraint.RHS != 0:
            continue
        terms = {expression.getVar(position).VarName: expression.getCoeff(position) for position in range(2)}
        for index in range(member_count):
            if set(terms) == {f"x_{index}", f"sigma_{index}"} and terms[f"sigma_{index}"] == -1:
                compression[index] = -terms[f"x_{index}"]
                break
    if set(compression) != set(range(member_count)):
        raise RuntimeError("failed to recover compression coefficients")

    y = {}
    stress_piece = {}
    for index in range(member_count):
        for level, size in enumerate(SIZES):
            y[index, level] = model.addVar(lb=0.0, ub=1.0, name=f"hull_y_{index}_{level}")
            lower = max(-GLOBAL_STRESS, -compression[index] * size)
            stress_piece[index, level] = model.addVar(
                lb=lower,
                ub=GLOBAL_STRESS,
                name=f"hull_stress_piece_{index}_{level}",
            )
    model.update()

    for index in range(member_count):
        z = [model.getVarByName(f"z_{index}_{level}") for level in range(5)]
        model.addConstr(y[index, 0] == 1 - z[0], name=f"hull_level_link_{index}_0")
        for level in range(1, 5):
            model.addConstr(y[index, level] == z[level - 1] - z[level], name=f"hull_level_link_{index}_{level}")
        model.addConstr(y[index, 5] == z[4], name=f"hull_level_link_{index}_5")
        model.addConstr(
            model.getVarByName(f"sigma_{index}")
            == gp.quicksum(stress_piece[index, level] for level in range(6)),
            name=f"hull_disaggregate_stress_{index}",
        )
        model.addConstr(
            model.getVarByName(f"q_{index}")
            == gp.quicksum(SIZES[level] * stress_piece[index, level] for level in range(6)),
            name=f"hull_disaggregate_force_{index}",
        )
        for level, size in enumerate(SIZES):
            lower = max(-GLOBAL_STRESS, -compression[index] * size)
            model.addConstr(
                stress_piece[index, level] >= lower * y[index, level],
                name=f"hull_stress_piece_lb_{index}_{level}",
            )
            model.addConstr(
                stress_piece[index, level] <= GLOBAL_STRESS * y[index, level],
                name=f"hull_stress_piece_ub_{index}_{level}",
            )

    model.ModelName = "milo-v12-6-r1-75-1-augmented-hull"
    model.update()
    args.output_model.parent.mkdir(parents=True, exist_ok=True)
    model.write(str(args.output_model))
    report = {
        "instance": "milo-v12-6-r1-75-1",
        "method": "original incremental model intersected with redundant local disaggregated hull",
        "sizes": SIZES,
        "members": member_count,
        "result_variables": model.NumVars,
        "result_constraints": model.NumConstrs,
        "result_nonzeros": model.NumNZs,
    }
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
