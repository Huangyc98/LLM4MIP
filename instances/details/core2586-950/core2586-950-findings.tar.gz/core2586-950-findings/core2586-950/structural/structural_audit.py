#!/usr/bin/env python3
"""Read-only structural audit for the MIPLIB core2586-950 MPS file."""

from __future__ import annotations

import argparse
import collections
import gzip
import hashlib
import json
import math
import statistics
from pathlib import Path


def parse_mps(path: Path):
    rows: dict[str, str] = {}
    col_rows: dict[str, dict[str, float]] = collections.defaultdict(dict)
    row_cols: dict[str, dict[str, float]] = collections.defaultdict(dict)
    rhs: dict[str, float] = {}
    bounds: dict[str, tuple[float, float]] = {}
    integer_vars: set[str] = set()
    section = None
    integer_mode = False

    with gzip.open(path, "rt") as fh:
        for raw in fh:
            line = raw.strip()
            if not line or line.startswith("*"):
                continue
            parts = line.split()
            head = parts[0]
            if head in {"NAME", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "ENDATA", "OBJSENSE"}:
                section = head
                continue
            if section == "ROWS":
                rows[parts[1]] = parts[0]
            elif section == "COLUMNS":
                if len(parts) >= 3 and parts[1].strip("'") == "MARKER":
                    marker = parts[2].strip("'")
                    integer_mode = marker == "INTORG"
                    continue
                var = parts[0]
                if integer_mode:
                    integer_vars.add(var)
                for i in range(1, len(parts), 2):
                    row = parts[i]
                    val = float(parts[i + 1])
                    col_rows[var][row] = col_rows[var].get(row, 0.0) + val
                    row_cols[row][var] = row_cols[row].get(var, 0.0) + val
            elif section == "RHS":
                for i in range(1, len(parts), 2):
                    rhs[parts[i]] = float(parts[i + 1])
            elif section == "BOUNDS":
                code = parts[0]
                var = parts[2]
                val = float(parts[3]) if len(parts) > 3 else None
                lo, up = bounds.get(var, (0.0, math.inf))
                if code == "UP":
                    up = val
                elif code == "LO":
                    lo = val
                elif code == "FX":
                    lo = up = val
                elif code == "FR":
                    lo, up = -math.inf, math.inf
                elif code == "MI":
                    lo = -math.inf
                elif code == "PL":
                    up = math.inf
                elif code == "BV":
                    integer_vars.add(var)
                    lo, up = 0.0, 1.0
                else:
                    raise ValueError(f"Unsupported bound code {code}")
                bounds[var] = (lo, up)
    return rows, col_rows, row_cols, rhs, bounds, integer_vars


def q(values, probs=(0, .25, .5, .75, .9, .99, 1)):
    values = sorted(values)
    if not values:
        return {}
    return {str(p): values[round(p * (len(values) - 1))] for p in probs}


def hist(values):
    return {str(k): v for k, v in sorted(collections.Counter(values).items(), key=lambda kv: kv[0])}


def signature(coeffs, excluded=()):
    return tuple(sorted((r, round(a, 12)) for r, a in coeffs.items() if r not in excluded))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mps", type=Path)
    args = ap.parse_args()
    rows, col_rows, row_cols, rhs, bounds, integer_vars = parse_mps(args.mps)
    vars_ = sorted(col_rows)
    obj_rows = [r for r, t in rows.items() if t == "N"]
    assert len(obj_rows) == 1
    obj = obj_rows[0]
    con_rows = [r for r, t in rows.items() if t != "N"]
    cover_rows = [r for r in con_rows if rows[r] == "G" and rhs.get(r, 0.0) == 1.0]
    special_rows = [r for r in con_rows if r not in cover_rows]
    binaries = [v for v in vars_ if v in integer_vars and bounds.get(v, (0, math.inf)) == (0.0, 1.0)]

    prefix = collections.Counter(v.rstrip("0123456789") for v in vars_)
    costs = [col_rows[v].get(obj, 0.0) for v in vars_]
    cover_degs = [len(row_cols[r]) for r in cover_rows]
    col_cover_degs = [sum(r in row_cols and v in row_cols[r] for r in cover_rows) for v in vars_]

    exact_groups = collections.defaultdict(list)
    incidence_groups = collections.defaultdict(list)
    for v in vars_:
        exact_groups[signature(col_rows[v])].append(v)
        incidence_groups[signature(col_rows[v], excluded=(obj, "UB"))].append(v)
    exact_dups = [g for g in exact_groups.values() if len(g) > 1]
    incidence_dups = [g for g in incidence_groups.values() if len(g) > 1]

    data = {
        "file": str(args.mps),
        "sha256": hashlib.sha256(args.mps.read_bytes()).hexdigest(),
        "rows_total_including_objective": len(rows),
        "constraint_rows": len(con_rows),
        "row_sense_counts": dict(collections.Counter(rows[r] for r in con_rows)),
        "variables": len(vars_),
        "integer_variables": len(integer_vars),
        "binary_variables": len(binaries),
        "prefix_counts": dict(prefix),
        "matrix_nonzeros_including_objective": sum(len(c) for c in col_rows.values()),
        "objective": {
            "row": obj,
            "nonzeros": sum(c != 0 for c in costs),
            "coefficient_histogram": hist(costs),
            "coefficient_quantiles": q(costs),
        },
        "covering_block": {
            "rows": len(cover_rows),
            "all_coefficients_one": all(a == 1.0 for r in cover_rows for a in row_cols[r].values()),
            "row_degree_quantiles": q(cover_degs),
            "row_degree_histogram": hist(cover_degs),
            "column_cover_degree_quantiles": q(col_cover_degs),
            "uncovered_columns": sum(d == 0 for d in col_cover_degs),
        },
        "special_rows": {},
        "duplicate_columns": {
            "exact_groups": len(exact_dups),
            "exact_variables": sum(len(g) for g in exact_dups),
            "largest_exact_group": max(map(len, exact_dups), default=1),
            "same_nonobjective_incidence_groups": len(incidence_dups),
            "same_nonobjective_incidence_variables": sum(len(g) for g in incidence_dups),
            "largest_nonobjective_incidence_group": max(map(len, incidence_dups), default=1),
            "sample_exact_groups": exact_dups[:20],
            "sample_nonobjective_incidence_groups": incidence_dups[:20],
        },
    }
    for r in special_rows:
        vals = list(row_cols[r].values())
        data["special_rows"][r] = {
            "sense": rows[r],
            "rhs": rhs.get(r, 0.0),
            "nonzeros": len(vals),
            "coefficient_histogram": hist(vals),
            "coefficient_quantiles": q(vals),
            "prefix_nonzeros": dict(collections.Counter(v.rstrip("0123456789") for v in row_cols[r])),
        }

    print(json.dumps(data, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
