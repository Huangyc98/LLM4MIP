#!/usr/bin/env python3
"""Project an original feasible solution through the exact kernel mapping."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from structural_audit import parse_mps


def selected_from_solution(path: Path):
    selected = set()
    declared = None
    for raw in path.read_text().splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("=obj="):
            declared = float(line.split()[-1])
            continue
        if line.startswith("# Objective value ="):
            declared = float(line.split("=", 1)[1])
            continue
        if line.startswith("#"):
            continue
        name, value = line.split()[:2]
        if float(value) > 0.5:
            selected.add(name)
    return selected, declared


def write_sol(path: Path, model: str, objective: float, selected):
    lines = [f"# Projected start for model {model}", f"# Objective value = {objective:.15g}"]
    lines.extend(f"{v} 1" for v in sorted(selected))
    path.write_text("\n".join(lines) + "\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("original_mps", type=Path)
    ap.add_argument("mapping", type=Path)
    ap.add_argument("original_solution", type=Path)
    ap.add_argument("output_dir", type=Path)
    args = ap.parse_args()

    mapping = json.loads(args.mapping.read_text())
    senses, col_coeff, row_coeff, rhs, bounds, integer = parse_mps(args.original_mps)
    objrow = next(r for r, t in senses.items() if t == "N")
    cost = {v: col_coeff[v].get(objrow, 0.0) for v in col_coeff}
    original_selected, declared = selected_from_solution(args.original_solution)
    active = set(mapping["active_columns"])
    forced = set(mapping["forced_columns"])
    empty = set(mapping["empty_columns"])
    witness = mapping["dominated_column_witness"]

    projected = set(forced)
    paths = {}
    dropped_as_empty = set()
    for source in original_selected:
        if source == "OFFSET" or source.startswith("S"):
            continue
        current = source
        chain = [current]
        seen = set()
        while current in witness:
            if current in seen:
                raise RuntimeError(f"dominance witness cycle at {current}")
            seen.add(current)
            current = witness[current]
            chain.append(current)
        paths[source] = chain
        if current in active or current in forced:
            projected.add(current)
        elif current in empty:
            dropped_as_empty.add(source)
        else:
            raise RuntimeError(f"selected column {source} maps to unclassified {current}")

    active_projected = projected & active
    missing_active_rows = [
        r for r in mapping["active_rows"]
        if not (set(row_coeff[r]) & active_projected)
    ]
    if missing_active_rows:
        raise RuntimeError(f"projection fails {len(missing_active_rows)} active rows")

    args.output_dir.mkdir(parents=True, exist_ok=True)
    fixed_cost = mapping["fixed_cost"]
    kernel_obj = fixed_cost + sum(cost[v] for v in active_projected)
    write_sol(
        args.output_dir / "official_944_projected_kernel.sol",
        "core2586-950-kernel", kernel_obj,
        active_projected | {"OFFSET"},
    )
    component_rows = []
    for component in mapping["components"]:
        k = component["id"]
        chosen = active_projected & set(component["columns"])
        obj = sum(cost[v] for v in chosen)
        write_sol(
            args.output_dir / f"official_944_projected_component-{k}.sol",
            f"core2586-950-c{k}", obj, chosen,
        )
        component_rows.append({"id": k, "selected": len(chosen), "objective": obj})

    result = {
        "declared_original_objective": declared,
        "original_selected_columns": len(original_selected),
        "original_recomputed_objective": sum(cost.get(v, 0.0) for v in original_selected),
        "forced_columns": len(forced),
        "fixed_cost": fixed_cost,
        "projected_active_columns": len(active_projected),
        "projected_kernel_objective": kernel_obj,
        "components": component_rows,
        "selected_columns_replaced": sum(len(chain) > 1 for chain in paths.values()),
        "selected_columns_dropped_empty": len(dropped_as_empty),
        "active_rows_missing": len(missing_active_rows),
    }
    (args.output_dir / "official_944_projection_summary.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n"
    )
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
