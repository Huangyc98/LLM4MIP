#!/usr/bin/env python3
"""Lift a reduced core2586-950 solution and check it against the original MPS."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from structural_audit import parse_mps


def read_sol(path: Path):
    values = {}
    declared_objective = None
    for raw in path.read_text().splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("# Objective value ="):
            declared_objective = float(line.split("=", 1)[1])
            continue
        if line.startswith("#"):
            continue
        name, value = line.split()[:2]
        values[name] = float(value)
    return values, declared_objective


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("original_mps", type=Path)
    ap.add_argument("mapping", type=Path)
    ap.add_argument("--kernel-solution", type=Path)
    ap.add_argument(
        "--component-solution", action="append", default=[], metavar="ID=PATH",
        help="may be repeated; providing every component enables a full original-model check",
    )
    ap.add_argument("--write-lifted", type=Path)
    args = ap.parse_args()
    if bool(args.kernel_solution) == bool(args.component_solution):
        ap.error("provide either --kernel-solution or one or more --component-solution entries")

    mapping = json.loads(args.mapping.read_text())
    senses, col_coeff, row_coeff, rhs, bounds, integer = parse_mps(args.original_mps)
    objective_row = next(r for r, t in senses.items() if t == "N")
    active = set(mapping["active_columns"])
    selected_values = {}
    declared = []
    full = False

    if args.kernel_solution:
        values, obj = read_sol(args.kernel_solution)
        selected_values.update({v: x for v, x in values.items() if v in active})
        declared.append(obj)
        full = True
    else:
        seen_components = set()
        for spec in args.component_solution:
            sid, raw_path = spec.split("=", 1)
            k = int(sid)
            if k in seen_components:
                raise ValueError(f"component {k} supplied twice")
            seen_components.add(k)
            allowed = set(mapping["components"][k]["columns"])
            values, obj = read_sol(Path(raw_path))
            unknown = set(values) - allowed
            if unknown:
                raise ValueError(f"component {k} solution has variables outside component: {sorted(unknown)[:5]}")
            selected_values.update(values)
            declared.append(obj)
        full = seen_components == set(range(len(mapping["components"])))

    tol = 1e-7
    invalid_binary = {
        v: x for v, x in selected_values.items()
        if v != "OFFSET" and (x < -tol or x > 1 + tol or abs(x - round(x)) > tol)
    }
    if invalid_binary:
        raise ValueError(f"invalid binary values: {list(invalid_binary.items())[:5]}")

    x = {v: 0.0 for v in col_coeff}
    for v in mapping["forced_columns"]:
        x[v] = 1.0
    for v, value in selected_values.items():
        if v in x:
            x[v] = round(value)

    objective = sum(col_coeff[v].get(objective_row, 0.0) * x[v] for v in col_coeff)
    violations = []
    checked_rows = []
    if full:
        checked_rows = [r for r, t in senses.items() if t != "N"]
    else:
        component_ids = {int(spec.split("=", 1)[0]) for spec in args.component_solution}
        checked_rows = [
            r for k in component_ids for r in mapping["components"][k]["rows"]
        ]
    for r in checked_rows:
        activity = sum(a * x[v] for v, a in row_coeff[r].items())
        target = rhs.get(r, 0.0)
        sense = senses[r]
        bad = (
            (sense == "G" and activity < target - tol)
            or (sense == "L" and activity > target + tol)
            or (sense == "E" and abs(activity - target) > tol)
        )
        if bad:
            violations.append({"row": r, "sense": sense, "activity": activity, "rhs": target})

    component_objective = sum(
        col_coeff[v].get(objective_row, 0.0) * x[v] for v in selected_values if v in col_coeff
    )
    result = {
        "full_original_check": full,
        "checked_rows": len(checked_rows),
        "violations": violations[:20],
        "violation_count": len(violations),
        "selected_forced_columns": len(mapping["forced_columns"]),
        "selected_solution_columns": sum(round(z) for v, z in selected_values.items() if v in active),
        "component_objective_without_fixed_cost": component_objective,
        "objective_with_fixed_cost_and_provided_components": objective,
        "lifted_original_objective": objective if full else None,
        "declared_reduced_objectives": declared,
        "status": "PASS" if not violations and not invalid_binary else "FAIL",
    }
    print(json.dumps(result, indent=2, sort_keys=True))

    if args.write_lifted:
        if not full or violations:
            raise ValueError("will only write a complete, feasible lifted solution")
        lines = ["# Lifted and independently checked against core2586-950.mps.gz", f"# Objective value = {objective:.15g}"]
        lines.extend(f"{v} {x[v]:.0f}" for v in sorted(x) if abs(x[v]) > tol)
        args.write_lifted.parent.mkdir(parents=True, exist_ok=True)
        args.write_lifted.write_text("\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
