# Input provenance

The original MPS is intentionally not stored in this repository.

- MIPLIB page: <https://miplib.zib.de/instance_details_core2586-950.html>
- Official MPS: <https://miplib.zib.de/WebData/instances/core2586-950.mps.gz>
- Expected SHA-256: `a906fd42549287b0604e682167fe867f81ba2b41c2ed76ec4f2fa8e24f5f6dc5`

Download it as `input/core2586-950.mps.gz` before regenerating the reduction.
