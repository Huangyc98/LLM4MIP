#!/usr/bin/env python3
"""Lift a solution of the identical-column quotient to original binaries."""

from __future__ import annotations

import csv
import pathlib
import sys


def main(aggregate_solution: str, mapping_path: str, output_path: str) -> None:
    values: dict[str, float] = {}
    objective = None
    with open(aggregate_solution, encoding="ascii") as stream:
        for line in stream:
            if line.startswith("# Objective value ="):
                objective = float(line.rsplit("=", 1)[1])
            fields = line.split()
            if len(fields) == 2 and not fields[0].startswith("#"):
                values[fields[0]] = float(fields[1])

    groups: dict[str, list[str]] = {}
    with open(mapping_path, encoding="ascii") as stream:
        for row in csv.DictReader(stream, delimiter="\t"):
            groups[row["aggregate_var"]] = row["original_vars"].split()

    chosen: set[str] = set()
    for var, value in values.items():
        if var in groups:
            count = round(value)
            if abs(value - count) > 1e-6 or not 0 <= count <= len(groups[var]):
                raise RuntimeError(f"invalid aggregate value {var}={value}")
            chosen.update(groups[var][:count])
        elif var.startswith("x") and value > 0.5:
            chosen.add(var)

    with pathlib.Path(output_path).open("w", encoding="ascii") as out:
        if objective is not None:
            out.write(f"# Objective value = {objective:.15g}\n")
        for var in sorted(chosen, key=lambda name: int(name[1:])):
            out.write(f"{var} 1\n")
    print(f"aggregate_nonzeros={sum(abs(v) > 1e-9 for v in values.values())}")
    print(f"original_selected_binaries={len(chosen)}")
    print(f"objective={objective}")
    print(f"output={output_path}")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], sys.argv[3])
