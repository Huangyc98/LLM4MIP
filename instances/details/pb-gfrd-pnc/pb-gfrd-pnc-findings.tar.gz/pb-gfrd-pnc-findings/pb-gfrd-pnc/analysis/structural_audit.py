#!/usr/bin/env python3
"""Read-only MPS and symmetry audit for pb-gfrd-pnc."""

from __future__ import annotations

import argparse
import collections
import gzip
import hashlib
import json
import math
from pathlib import Path


def parse_mps(path: Path):
    senses = {}
    col_coeff = collections.defaultdict(dict)
    row_coeff = collections.defaultdict(dict)
    rhs = {}
    bounds = {}
    integer = set()
    section = None
    int_mode = False
    with gzip.open(path, "rt") as fh:
        for raw in fh:
            line = raw.strip()
            if not line or line.startswith("*"):
                continue
            p = line.split()
            headers = {"NAME", "OBJSENSE", "ROWS", "COLUMNS", "RHS", "RANGES", "BOUNDS", "SOS", "INDICATORS", "ENDATA"}
            # The RHS vector itself is also named "RHS", so only a one-token
            # RHS line is a section header.
            is_header = p[0] in headers and (p[0] not in {"RHS", "RANGES"} or len(p) == 1)
            if is_header:
                section = p[0]
                continue
            if section == "ROWS":
                senses[p[1]] = p[0]
            elif section == "COLUMNS":
                if len(p) >= 3 and p[1].strip("'") == "MARKER":
                    int_mode = p[2].strip("'") == "INTORG"
                    continue
                v = p[0]
                if int_mode:
                    integer.add(v)
                for k in range(1, len(p), 2):
                    r, a = p[k], float(p[k + 1])
                    col_coeff[v][r] = col_coeff[v].get(r, 0.0) + a
                    row_coeff[r][v] = row_coeff[r].get(v, 0.0) + a
            elif section == "RHS":
                for k in range(1, len(p), 2):
                    rhs[p[k]] = float(p[k + 1])
            elif section == "BOUNDS":
                typ, v = p[0], p[2]
                val = float(p[3]) if len(p) > 3 else None
                lo, up = bounds.get(v, (0.0, math.inf))
                if typ == "BV":
                    lo, up = 0.0, 1.0
                    integer.add(v)
                elif typ == "UP":
                    up = val
                elif typ == "LO":
                    lo = val
                elif typ == "FX":
                    lo = up = val
                elif typ == "FR":
                    lo, up = -math.inf, math.inf
                else:
                    raise ValueError(typ)
                bounds[v] = lo, up
    return senses, col_coeff, row_coeff, rhs, bounds, integer


def quantiles(a, probs=(0, .25, .5, .75, .9, .99, 1)):
    a = sorted(a)
    return {str(p): a[round(p * (len(a) - 1))] for p in probs} if a else {}


def hist(a):
    return {str(k): v for k, v in sorted(collections.Counter(a).items(), key=lambda z: z[0])}


def coeff_signature(d):
    return tuple(sorted((k, round(v, 12)) for k, v in d.items()))


def contiguous_runs(rows, senses, rhs, row_coeff):
    numbered = sorted((int(r[1:]), r) for r in rows if r.startswith("c") and r[1:].isdigit())
    runs = []
    start = prev = numbered[0][0]
    first = numbered[0][1]
    key = (senses[first], rhs.get(first, 0.0), len(row_coeff[first]))
    for n, r in numbered[1:]:
        k = (senses[r], rhs.get(r, 0.0), len(row_coeff[r]))
        if n != prev + 1 or k != key:
            runs.append({"first": start, "last": prev, "count": prev - start + 1,
                         "sense": key[0], "rhs": key[1], "degree": key[2]})
            start, key = n, k
        prev = n
    runs.append({"first": start, "last": prev, "count": prev - start + 1,
                 "sense": key[0], "rhs": key[1], "degree": key[2]})
    return runs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mps", type=Path)
    args = ap.parse_args()
    senses, col_coeff, row_coeff, rhs, bounds, integer = parse_mps(args.mps)
    obj = next(r for r, t in senses.items() if t == "N")
    rows = [r for r, t in senses.items() if t != "N"]
    cols = list(col_coeff)

    full_groups = collections.defaultdict(list)
    matrix_groups = collections.defaultdict(list)
    for v in cols:
        full_groups[coeff_signature(col_coeff[v])].append(v)
        matrix_groups[coeff_signature({r: a for r, a in col_coeff[v].items() if r != obj})].append(v)
    full_dups = [g for g in full_groups.values() if len(g) > 1]
    matrix_dups = [g for g in matrix_groups.values() if len(g) > 1]

    row_groups = collections.defaultdict(list)
    for r in rows:
        row_groups[(senses[r], rhs.get(r, 0.0), coeff_signature(row_coeff[r]))].append(r)
    row_dups = [g for g in row_groups.values() if len(g) > 1]

    group_size_hist = collections.Counter(len(g) for g in full_dups)
    expected_sym = {8: 2, 11: 16, 12: 198, 13: 468, 14: 152}
    exact_expected = {k: group_size_hist.get(k, 0) for k in expected_sym}

    out = {
        "file": str(args.mps),
        "sha256": hashlib.sha256(args.mps.read_bytes()).hexdigest(),
        "constraints": len(rows),
        "variables": len(cols),
        "integer_variables": len(integer),
        "binary_variables": sum(v in integer and bounds.get(v) == (0.0, 1.0) for v in cols),
        "nonzeros_constraints": sum(len(row_coeff[r]) for r in rows),
        "row_sense_histogram": dict(collections.Counter(senses[r] for r in rows)),
        "row_degree_quantiles": quantiles([len(row_coeff[r]) for r in rows]),
        "row_degree_histogram": hist([len(row_coeff[r]) for r in rows]),
        "rhs_histogram": hist([rhs.get(r, 0.0) for r in rows]),
        "objective": {
            "nonzeros": len(row_coeff[obj]),
            "coefficient_histogram": hist(row_coeff[obj].values()),
            "degree_by_variable": quantiles([len(col_coeff[v]) - (obj in col_coeff[v]) for v in cols]),
        },
        "coefficient_histogram": hist(a for r in rows for a in row_coeff[r].values()),
        "contiguous_row_runs_same_sense_rhs_degree": contiguous_runs(rows, senses, rhs, row_coeff),
        "identical_columns_full": {
            "groups": len(full_dups),
            "variables": sum(len(g) for g in full_dups),
            "size_histogram": {str(k): v for k, v in sorted(group_size_hist.items())},
            "counts_at_published_symmetry_sizes": exact_expected,
            "samples": sorted(full_dups, key=lambda g: (-len(g), g[0]))[:20],
        },
        "identical_columns_ignoring_objective": {
            "groups": len(matrix_dups),
            "variables": sum(len(g) for g in matrix_dups),
            "size_histogram": hist(len(g) for g in matrix_dups),
        },
        "identical_rows": {
            "groups": len(row_dups),
            "rows": sum(len(g) for g in row_dups),
            "samples": row_dups[:20],
        },
    }
    print(json.dumps(out, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
