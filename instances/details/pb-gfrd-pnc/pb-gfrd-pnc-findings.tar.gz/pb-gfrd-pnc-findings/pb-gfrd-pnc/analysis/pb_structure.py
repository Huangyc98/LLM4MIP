#!/usr/bin/env python3
"""Structural audit of the pure-binary pb-gfrd-pnc MPS."""

from __future__ import annotations

import collections
import gzip
import math
import sys


def main(mps_path: str, solution_path: str) -> None:
    rows: dict[str, str] = {}
    rhs: dict[str, float] = {}
    columns: dict[str, dict[str, float]] = collections.defaultdict(dict)
    section = ""
    with gzip.open(mps_path, "rt", encoding="ascii") as stream:
        for raw in stream:
            fields = raw.split()
            if not fields:
                continue
            if fields[0] in {"ROWS", "COLUMNS", "RHS", "BOUNDS", "ENDATA"} and len(fields) == 1:
                section = fields[0]
                continue
            if fields[0] == "NAME":
                section = "NAME"
                continue
            if section == "ROWS":
                rows[fields[1]] = fields[0]
            elif section == "COLUMNS":
                if len(fields) >= 3 and fields[1] == "'MARKER'":
                    continue
                var = fields[0]
                for pos in range(1, len(fields), 2):
                    columns[var][fields[pos]] = float(fields[pos + 1])
            elif section == "RHS":
                for pos in range(1, len(fields), 2):
                    rhs[fields[pos]] = float(fields[pos + 1])

    with open(solution_path, encoding="ascii") as stream:
        selected = {
            fields[0]
            for line in stream
            if len(fields := line.split()) == 2
            and fields[0].startswith("x")
            and float(fields[1]) > 0.5
        }

    constraint_rows = set(rows) - {"Obj"}
    row_to_cols = {row: [] for row in constraint_rows}
    for var, entries in columns.items():
        for row, value in entries.items():
            if row != "Obj":
                row_to_cols[row].append((var, value))

    print(f"constraints={len(constraint_rows)} variables={len(columns)} constraint_nonzeros={sum(len(e) - ('Obj' in e) for e in columns.values())}")
    print(f"row_senses={sorted(collections.Counter(rows[r] for r in constraint_rows).items())}")
    print(f"rhs_histogram={sorted(collections.Counter(rhs.get(r, 0.0) for r in constraint_rows).items())}")
    objective_hist = collections.Counter(columns[var].get("Obj", 0.0) for var in columns)
    print(f"objective_histogram={sorted(objective_hist.items())}")
    print(f"column_constraint_degree_histogram={sorted(collections.Counter(len(e) - ('Obj' in e) for e in columns.values()).items())}")
    print(f"row_nnz_histogram={sorted(collections.Counter(len(e) for e in row_to_cols.values()).items())}")
    print(f"incumbent_selected={len(selected)} objective={sum(columns[v].get('Obj', 0.0) for v in selected)}")
    print(f"incumbent_objective_coeff_histogram={sorted(collections.Counter(columns[v].get('Obj', 0.0) for v in selected).items())}")
    slacks = []
    for row in constraint_rows:
        lhs = sum(value for var, value in row_to_cols[row] if var in selected)
        if rows[row] == "G":
            slacks.append((lhs - rhs.get(row, 0.0), row, lhs, rhs.get(row, 0.0)))
        else:
            slacks.append((abs(lhs - rhs.get(row, 0.0)), row, lhs, rhs.get(row, 0.0)))
    print(f"incumbent_min_G_slack={min(s for s, r, lhs, rr in slacks if rows[r] == 'G')}")
    print(f"incumbent_binding_G_rows={sum(abs(s) < 1e-9 for s, r, lhs, rr in slacks if rows[r] == 'G')}")
    violations = [(r, lhs, rr) for s, r, lhs, rr in slacks if s > 1e-9 and rows[r] == "E"]
    print(f"incumbent_equality_violations={len(violations)}")

    # Variables having identical full columns are pure permutation symmetries.
    signatures: dict[tuple, list[str]] = collections.defaultdict(list)
    for var, entries in columns.items():
        signatures[tuple(sorted(entries.items()))].append(var)
    duplicate_classes = sorted((members for members in signatures.values() if len(members) > 1), key=len, reverse=True)
    print(f"identical_column_classes={len(duplicate_classes)} variables_in_classes={sum(map(len, duplicate_classes))}")
    print(f"identical_column_size_histogram={sorted(collections.Counter(map(len, duplicate_classes)).items())}")
    print("largest_identical_columns=" + repr([group[:20] for group in duplicate_classes[:10]]))

    # Summarize row families by sense, RHS, number and multiset of coefficients.
    family_hist: dict[tuple, list[str]] = collections.defaultdict(list)
    for row, entries in row_to_cols.items():
        coeff_hist = tuple(sorted(collections.Counter(value for _, value in entries).items()))
        family_hist[(rows[row], rhs.get(row, 0.0), len(entries), coeff_hist)].append(row)
    families = sorted(family_hist.items(), key=lambda item: len(item[1]), reverse=True)
    print(f"row_family_count={len(families)}")
    for signature, members in families[:30]:
        print(f"  rows={len(members)} examples={members[:5]} signature={signature}")

    # Bipartite connected components.
    unseen_rows = set(constraint_rows)
    components = []
    while unseen_rows:
        seed = unseen_rows.pop()
        comp_rows = {seed}
        comp_cols = set()
        frontier = [seed]
        while frontier:
            row = frontier.pop()
            for var, _ in row_to_cols[row]:
                if var in comp_cols:
                    continue
                comp_cols.add(var)
                for nxt in columns[var]:
                    if nxt != "Obj" and nxt in unseen_rows:
                        unseen_rows.remove(nxt)
                        comp_rows.add(nxt)
                        frontier.append(nxt)
        components.append((comp_rows, comp_cols))
    components.sort(key=lambda pair: len(pair[1]), reverse=True)
    print(f"connected_components={len(components)} sizes={[(len(r), len(c)) for r, c in components[:30]]}")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
