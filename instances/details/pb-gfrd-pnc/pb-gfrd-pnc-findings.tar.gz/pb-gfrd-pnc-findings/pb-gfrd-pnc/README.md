# `pb-gfrd-pnc` — exact symmetry quotient; global optimum open

Official MIPLIB page: <https://miplib.zib.de/instance_details_pb-gfrd-pnc.html>

## Result

The instance remains **globally open**.

| quantity | value | evidence |
|---|---:|---|
| strict feasible UB | **`8844`** | exact-decimal replay on all 874 original rows |
| numerical LB | **`8566`** | Gurobi 13.0.2 on the exact quotient, 600 s, two threads |
| numerical gap | `3.1434%` | time-limit result |
| portable global LB | none | no exact proof trace |

The full lifted vector is
[`strict-8844-lifted.sol`](solutions/strict-8844-lifted.sol). Missing entries
are interpreted as zero; objective, every row, every bound and integrality all
replay exactly.

## Exact identical-column quotient

The downloaded MPS is a pure binary model with 27,888 columns, 874 rows and
60,737 nonzeros. An exact full-column signature audit finds 836 symmetry
classes containing 10,780 binaries. Replacing each class of size `k` by a
bounded integer count in `[0,k]` gives:

- 17,108 unchanged binaries;
- 836 bounded integer counts;
- 17,944 total quotient variables; and
- 40,849 constraint nonzeros.

This removes 9,944 interchangeable columns without changing the feasible
objectives. The generator, inverse mapping and generated quotient are under
[`analysis/`](analysis/) and [`model/aggregated/`](model/aggregated/).
Regeneration differs from the retained files only by line endings.

The sanitized [600-second log](logs/aggregated-proof-600s.log) ends at
incumbent 8844 and lower bound 8566. That lower bound is numerical solver
evidence. Exact reformulation does not turn a floating-point branch-and-bound
log into a portable certificate, so no optimality claim is made.
