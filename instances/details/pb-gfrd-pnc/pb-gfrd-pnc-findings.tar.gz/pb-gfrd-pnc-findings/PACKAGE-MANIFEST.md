# Package manifest: pb-gfrd-pnc

Generated for the LLM4MIP site from the 2026-09-18 research snapshot.
Source base commit: 89a8abd0847941bdf774353a1983d5e6a00457a0 plus the disclosed 18 September working-tree reconciliation.
Archive timestamps and ownership are normalized for reproducible packaging.

Included source files: 12
Excluded source files: 0

## Included files

- `README.md`
- `analysis/aggregate_identical_columns.py`
- `analysis/disaggregate_solution.py`
- `analysis/pb_structure.py`
- `analysis/structural_audit.py`
- `artifacts/result.json`
- `input/README.md`
- `input/SHA256SUMS`
- `logs/aggregated-proof-600s.log`
- `model/aggregated/aggregation_map.tsv`
- `model/aggregated/pb-gfrd-pnc-aggregated.lp`
- `solutions/strict-8844-lifted.sol`

## Excluded files

- None
