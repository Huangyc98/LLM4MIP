# Primal 搜索操作手册

以下是从案例抽象的可执行决策规则；参数需通过当前实例 pilot 调整。MIP/CP/自写算法不是质量排名，而是不同结构的后端。

默认只围绕更好的已验证 primal 分配研究预算，可以完全不做 dual 改进。LP/定价/cuts 仅在能直接帮助构造、选邻域或修复时使用；不单独追求更强下界，不以 gap 下降代替可行解改善。子问题附带的 bound 或局部关闭可记录，但无需为了获取它们延长运行。用户另行要求 dual 或最优性证明时再扩展任务。

搜索采用持续外层循环：`候选生成 → 原模型验证 → 更新best与解池 → 更新中心/cutoff/算子 → 下一轮`。首次可行或首次改善只触发保存和阶段汇报；总预算未耗尽时继续。单轮停滞时改邻域、构造、表示或重组种子，不把单轮结束当整个任务结束。总预算未指定时按有界批次推进并询问预算，不能把示例的30分钟擅自当总停止条件。

## 1. 最便宜的有效种子：迁移 + 目标模型补全

按已有仓库解、官方各 revision、兄弟 formulation、原应用 benchmark 的顺序检索。比较数据、成本、约束、变量域和标签对称；不要只比较名字或目标值。若只有启发性对应，也可以提出候选设计，但称为启发式迁移，并在目标模型验证，不能宣称等价。

- **完整映射**：能确定所有原变量时，直接 lift 后检查。bley 的额外上界也要检查。
- **核心映射**：只迁移物理设计/类别，重新解目标模型中的剩余离散运作和连续 recourse。dws 的设计与 operation 不能误当成同一组变量。
- **外部数据**：CVRP 先核对客户、距离取整、需求、容量、车数语义。给定路线只要 lift 后可行即可提供 UB；求 UB 不需要先证明所有原解都能投影回外部模型。
- **对称标签**：nj 的相同分区先重标号满足目标 formulation，重新生成根和流；不要随意额外加所有根排序约束。

一个很强的外部解可以帮助用户更快获得更好 primal，但不能把来源标成 GPT 原创。

## 2. 无 incumbent：把可行性拆成可构造不变量

先保持最容易精确实现的硬条件：one-of-k、容量、连通性、先序或边界。将剩余不满足度作为辅助搜索分数；原目标不能抵消硬约束违约。

1. 从 LP、贪心、历史近可行解或领域构造得到核心状态。
2. 识别困难块，而非一律固定 LP argmax。ns1905797 的 24-task 块反复超时，重新均衡分配才打通。
3. 固定 master 分配，解局部路线/排程/流；给每块保存同一个 master-assignment hash，防止跨分配拼接。
4. 合并所有块并验证 coupling rows。得到第一份完整可行向量后，立刻做有界 warm-start improvement。

如果没有领域结构，可以试 feasibility pump、diving 或 RENS。RENS 不要求已有 incumbent：固定 LP 中已整数的变量，其他整数变量收紧到相邻整数；子问题失败不能证明原问题不可行。过多错误固定时减少固定或换 rounding，避免盲目延长时间。[SCIP RENS 官方说明](https://scipopt.org/doc-9.2.4/html/heur__rens_8h.php)

## 3. 消除辅助变量，但保留可行性桥梁

识别真实状态 `y`（选择、路线、构型、次序、开采时期），建立 `lift(y)` 或 completion oracle。辅助变量即使目标为零，也可能耦合多个决策；不能未经验证删除。

针对 primal，足够的逻辑是：**找到的特定核心候选能被补全为原模型可行点**。如果要声称等价或从缩减模型不可行推导全局结论，才需要更强的覆盖证明。这样既保证 UB 正确，又避免为一次候选构造支付不必要的全局证明成本。

- 排程：选 job、开始时刻和次序，CP/匹配生成 schedule，再回填 pair variables。release-suffix master 可能仅是松弛；master 可行不等于 schedule 可行。
- 布局：sequence-pair、离散坐标/NoOverlap、朝向代替独立 pair bits；检查旋转、边界、障碍和所有原 non-overlap 语义。
- 网络：在 component balance/parity、路径或树上搜索；spanning-forest/flow 补全恢复原变量。
- 构型：允许新构型和容量，避免只在已有有限列池里搜索。池不可行只说明当前池不够。
- 类型计数：必须检查完整列系数、成本和所有 side rows；用确定性整数分配 lift multiplicity。名字相似不够。

若连续变量只组成差分约束，可寻找经过证明的整数缩放。这在 liu 和 ns1905797 成功；不能因为小数位有限就任意把一般连续模型离散化。

## 4. 以可行解为中心的结构 LNS

设核心整数变量集合为 `I`、中心为 `xbar`。选语义相关的释放集 `F⊆I`，固定 `I\F`，其余变量保持原域和原约束。连续变量通常全部放开，或在可证明局部分离时只放开受影响 recourse。

选择 F 的可计算线索：

- 接近紧约束的资源争用：紧行支持上的变量及其先序/连通邻接；
- LP 与 incumbent 不一致的位置、两个好解之间的差异；
- 高成本的实际业务决策，但必须包括其零成本可行性辅助决策；
- 几何边界、临界路径、相邻时期、共享需求的车辆/机组；
- 过去成功 move 涉及的结构，同时保留其他结构探索。

不要固定“90% 变量”作为通用真理。释放一个关联完整块通常比释放同样数量的随机变量更有意义；是否更快仍需比较。

**RINS**：固定 incumbent 与 LP 解相同（在记录容差内）的整数变量，释放不同处；需要 LP 和 incumbent。**Crossover**：固定多个好解一致的部分，重组差异。二者都应避免把高度相关辅助编码冻结成偶然阻碍。[SCIP primal heuristics](https://www.scipopt.org/download/slides/SCIP-primalHeuristics.pdf)

对二元核心的 local branching 可用

`sum_{i:xbar_i=0} x_i + sum_{i:xbar_i=1}(1-x_i) <= k`。

一般整数不能直接套二元式。用精确编码的 `d_i = [x_i != xbar_i]` 计类别改变，或明确使用 L1 距离。one-hot 从一个选项换到另一选项等于两个 bit flips；报表要同时记录 semantic moves 和 bit changes。

每轮保存原域，在下轮正确恢复；不能累积上轮固定、cutoff 或 no-good 而仍称为同一邻域。候选的连续 recourse 和全部 coupling rows 要重新评价。对大型模型优先增量更新合法邻域、缓存受影响行和系数；独立验收仍覆盖整个原模型。

## 5. 停滞后怎样换路

维护两个对象：只单调改善的 `best_verified` 与允许探索的 `current`。

| pilot 现象 | 下一步 |
|---|---|
| 小邻域很快完整返回无改进 | 增大语义半径、合并相关块；记住该中心已排除的范围 |
| 大邻域频繁超时、没有可行候选 | 更强构造 hint、保持配额/连通、缩小释放；换紧凑表示 |
| 很多可行候选但目标不变 | 支持去重、扩大离散差异；kick/tabu/recombination |
| 不同整数模式的 recourse 全不可行 | 由冲突/紧行定位共同阻碍，联合释放相关变量 |
| 只出现浮点小改进 | 先严格取整、recourse repair、原行审计；若消失，归档数值原因 |
| 同一结构已经有精确局部关闭记录 | 仅跳过相同中心、固定条件和目标阈值下被覆盖的搜索 |

nj 允许一次可行但更差的 compound kick，然后局部下降，best 始终不变直到找到更好解。如果实现允许 infeasible current，它必须存入独立 near-feasible 池，只有零硬违约的完整点才能成为 incumbent。

自适应算子分配可先等额跑少量可比 pilot，再按验证后收益/时间更新权重，并保留探索份额。收益小并不一定无效（rmine15），变化大也不一定有效（容差假象）。不用 22/112 当某算子的命中概率。[SCIP ALNS 的算子组合实现](https://www.scipopt.org/doc/html/heur__alns_8c_source.php)

## 6. 与通用求解器合作

保留一个有界强基线。用户明确指定后端时先判断这是硬性要求还是偏好：硬性要求不可用时停止相关求解并报告，不自行回退；偏好不可用时记录原因后继续。只有用户没有指定后端时，才按以下默认顺序选择：

1. **先探测 COPT。** 同时检查 API/CLI、版本、许可证、模型读入、当前约束类型、start 接口和资源限制；用当前模型或语义等价的小测试确认能实际开始求解。默认把第一个通用 MILP baseline、MILP 邻域和 LP/MILP recourse 交给 COPT。COPT 提供 `MipStartMode`、`HeurLevel`、`PreRootHeurLevel`、`DivingHeurLevel`、`SubMipHeurLevel` 和 `MipRepair` 等能力，但先保留自动参数基线，再用短 pilot 调整；`MipRepair` 可能延长求解器内部时限，因此必须由外层硬截止时间兜底。[COPT 参数文档](https://guide.coap.online/copt/en-doc/parameter.html)
2. **COPT 不可用或不兼容时主动回退。** 对一般线性 MILP，优先探测 Gurobi 并记录 COPT 的具体失败原因。Gurobi 的 `MIPFocus=1` 面向快速找可行解，MIP starts 可作为候选输入并由后端补全或修复；这些参数名只属于 Gurobi。[Gurobi 参数指南](https://docs.gurobi.com/projects/optimizer/en/current/concepts/parameters/guidelines.html)、[MIP starts](https://support.gurobi.com/hc/en-us/articles/360043834831-How-do-I-use-MIP-starts)
3. **cuOPT 是有条件的 primal 后端。** 仅在 NVIDIA GPU/驱动与 cuOPT 可用、模型属于当前支持的线性 MIP 范围、数据转换和变量顺序已核对时使用。其 MIP 求解器仍为 beta，但 GPU primal heuristics 适合本 skill 的候选发现目标；可以评估 heuristics-only 模式和 MIP starts。当前文档说明部分 MIP-start 接口与 presolve 组合存在限制，必须以实际安装版本为准。[cuOPT MIP 范围](https://docs.nvidia.com/cuopt/user-guide/latest/milp-features.html)、[MIP 设置](https://docs.nvidia.com/cuopt/user-guide/latest/mip-settings.html)、[MIP start](https://docs.nvidia.com/cuopt/user-guide/latest/cuopt-python/mip/mip-api.html)
4. **继续按兼容性寻找其它后端。** SCIP、HiGHS、CBC、CP-SAT 或结构专用代码可以承接剩余路线。回退顺序服务于保留原模型语义、及时获得 primal 和遵守预算，不以软件名替代能力检查。

每个被探测或跳过的后端都写一条 `backend_probe` 对象，至少包含 `backend, probe_command_or_api, executable_or_module, version, license_status, model_features, probe_result, fallback_reason, probe_wall_s`；manifest 顶层另记 `requested_backend, preferred_backend, backend_selection_order, selected_backend/version`。一个后端在 pilot 中较慢不等于不可用；可以基于相同 start、预算和验证口径安排后续跨后端比较，但要限制探测成本，避免把整个研究预算消耗在安装、许可证重试或 solver hopping 上。

先处理目标、约束和整数容差，再选择更偏 primal 的配置。没有必要为了找到更好解强迫每个 sub-MIP 都证明 `MIPGap=0`；设置有限节点/时间，可以在有效改进后结束该次子问题求解，但外层必须验证、更新 incumbent 并继续下一轮搜索。若需要“邻域已完整排除”的结论，则必须保存完整终止及相应容差/证据。

一个可调的 30 分钟首轮预算例子：3 分钟读取/种子与结构，5 分钟验证 baseline 和短基线，17 分钟做 2–3 条结构 pilot 与有效路线延伸，5 分钟预留 lift/独立验收。大模型读取或 exact checker 很慢时先测成本再调整；这个比例未经该 112 题对照验证。
