# 20 个 MIPLIB Open 实例的受控、可审计结构研究实验

**实验 ID：** `controlled_miplib20_20260911_1451`
**公共基线与模型冻结日期：** 2026-09-11
**终稿整理时间：** 2026-09-12
**本地证据根目录：** `D:\sufe\code\AI+MIP\controlled_miplib20_20260911_1451`
**远端证据根目录：** `/data1/wyc/controlled_miplib20_20260911_1451`

## 1. 执行摘要

本实验按预先固定的五个批次，对 20 个精确命名的 [MIPLIB](https://miplib.zib.de/) open 实例完成了结构分析、公开背景检索、原始模型基线、结构驱动试验、原空间解复核、全局界转移审计及证据封存。

“实验完成”在这里表示该实例已达到时间门槛、停止新增试验并完成证据 closeout；它不等于该 MIP 已被全局求解。最终数学结论为：

- 20/20 个实例完成实验与审计闭环；
- 20/20 个实例保留了非空、对原问题有效的全局下界证据；
- 4 个实例得到相对于本实验冻结的 MIPLIB 公共记录更好的严格原始-MPS incumbent；
- 2 个实例得到可移植的精确全局最优证书；
- 其余 18 个实例仍保留正的全局 gap，未声称最优；
- 最终 `summary.csv` 为固定顺序 20 行、16 列，JSON→CSV 的十进制词法零损失审计通过；
- euler4 上整个实验根目录的实例进程最终为 0，核心交付文件本地/远端 SHA-256 一致。

四个新严格 incumbent 是：

| 实例 | 冻结的公共基线 | 新严格原始-MPS primal | 改善量（最小化） |
|---|---:|---:|---:|
| `graphdraw-grafo2` | 68613.5 | 68595.5 | 18 |
| `r4l4-02-tree-bounds-50` | 499132179 | 499097063 | 35,116 |
| `ns1856153` | 34.16346179965939 | 34.01697312588408 | 0.14648867377531 |
| `neos-5221106-oparau` | 52.66999999999962 | 52.07 | 0.59999999999962 |

“新”仅表示相对于 2026-09-11 本实验检索并冻结的公开记录；本实验未声称这些结果已经被 MIPLIB 官方接收，也未声称它们是历史上的首次发现。

两个精确闭合实例是：

| 实例 | 精确 primal | 精确 global dual | 证明形式 |
|---|---:|---:|---|
| `ns1456591` | 988.14128344 | 988.14128344 | 完备路线商、Held–Karp/集合划分 DP、完整主问题有理对偶、原 MPS lift |
| `neos-3682128-sandon` | 34666770 | 34666770 | 完备机器配置枚举、精确有理对偶、严格原 MPS lift、跨主机标准库复核 |

## 2. 实验范围与控制

### 2.1 固定批次

1. `graphdraw-grafo2`、`polygonpack4-10`、`scpm1`、`ger50-17-trans-dfn-3t`
2. `eva1aprime6x6opt`、`cmflsp60-36-2-6`、`r4l4-02-tree-bounds-50`、`sct1`
3. `shipsched`、`rocII-8-11`、`ns1856153`、`dc1l`
4. `neos-5221106-oparau`、`zeil`、`cdma`、`ns1456591`
5. `seqsolve1`、`stockholm`、`supportcase22`、`neos-3682128-sandon`

严格执行批次屏障：后一批在前一批四个实例全部停止、保存证据并通过门禁后才开始。每批至多四个实例并行，不把未使用时间转移给其他实例。

### 2.2 时间规则

- Batch 1 使用最初的每实例 40–120 分钟有效研究规则。
- 用户后续修订后，Batch 2–5 使用每实例 90–150 分钟有效研究规则。
- `elapsed_minutes` 表示排除纯等待后的 active research 时间；包含结构分析、来源研究、模型构造、求解监督、结果解释、复核与报告工作。
- `solver_minutes` 是保留日志中可核对的求解器/搜索工作量，可与 active research 重叠，不能与 `elapsed_minutes` 相加解释为墙钟时间。

累计实例有效研究量为 **1729.5301 分钟（28.8255 小时）**；记录的求解器工作量为 **1010.2245 分钟（16.8371 小时）**。

| 批次 | 累计 active 分钟 | active 范围 | 累计 solver 分钟 | 门禁 |
|---:|---:|---:|---:|---|
| 1 | 195.7145 | 42.071–58.033 | 104.9060 | 40–120，PASS |
| 2 | 406.3483 | 91.343–117.861 | 280.3282 | 90–150，PASS |
| 3 | 403.9161 | 90.036–106.696 | 304.0170 | 90–150，PASS |
| 4 | 362.7722 | 90.097–92.239 | 190.0737 | 90–150，PASS |
| 5 | 360.7789 | 90.114–90.260 | 130.8996 | 90–150，PASS |

### 2.3 计算环境

| 项目 | 冻结值 |
|---|---|
| Manifest 主要求解主机 | euler4，用户 `wyc`，数据盘 `/data1` |
| 操作系统 | Ubuntu 20.04.6 LTS，Linux 5.4.0-216-generic，x86_64 |
| CPU | 2×32 物理核、128 逻辑 CPU，Intel Xeon Platinum 8358 @ 2.60 GHz |
| 内存 | 540,659,212,288 bytes |
| Gurobi | 13.0.1，NODE 文件许可证 |
| Python | `/home/wyc/miniconda3/envs/gen-milp-instance/bin/python` |
| 每实例线程 | `Threads=8` |
| 每实例软内存限制 | `SoftMemLimit=32` GiB |
| 随机种子 | `Seed=20260911` |
| 数值基线 | `FeasibilityTol=IntFeasTol=OptimalityTol=1e-6`，更严格复核逐实例另记 |
| Codex | `gpt-5.6-sol`，reasoning=`ultra` |

绝大多数实例在上述 euler4/Gurobi 13.0.1 环境运行。两个有明确审计记录的执行例外是 `zeil` 和 `cdma`：其最终试验在本地 `huangyicheng` 主机上运行，环境为 Windows 11 build 26200、Python 3.13.5、Gurobi 13.0.2 build `v13.0.2rc1`；二者仍使用 `Threads=8`、`SoftMemLimit=32` GiB 和 `Seed=20260911`，并在各自 environment/ledger 中保留版本证据。该差异没有被静默归并为 euler4 结果。

原始 `.mps.gz` 从 MIPLIB WebData 获取，逐实例计算 SHA-256 并设置为只读；任何派生模型都使用新文件，未覆盖原件。本实验的优化证据使用 Gurobi；未把 COPT 输出纳入这 20 个实例的最终界或证明链。

## 3. 证据和数值口径

### 3.1 结果字段

- `official_primal`：冻结页面、solution table 或公开解文件中记录的值；若来源冲突则保留冲突文本。
- `best_verified_primal`（下文记作 `P*`）：`summary.csv` 选定的、按该实例明确容差复核的原空间候选。它不是跨 20 个实例统一的“零容差严格 primal”。
- `best_valid_dual`（下文记作 `D`）：对未经改变的原问题有效的全局下界。它可能是原模型求解器界、经等价/放松方向审计的计算界，或可移植精确证书。
- `final_gap = |P* - D| / max(|P*|, 1e-10)`。负目标实例出现大于 1 的 gap 是正常的。
- `official_dual` 在冻结的 20 行中均为 `null`/CSV 空白，表示权威页面没有可用官方全局对偶值，不表示 0。因此本报告不虚构“相对官方 dual 的改善量”。

### 3.2 证据等级

由弱到强区分：

1. 公开元数据或求解器观察；
2. 受限邻域、固定模式或局部搜索结论；
3. 对原问题有效的计算型全局界；
4. 独立复核的原始-MPS primal 或精确有理界；
5. 完备性证明、相等的精确 primal/dual、原空间映射和独立重放共同组成的全局最优证书。

受限模型的 `OPTIMAL`、infeasible 或 cutoff 只在其声明域内有效；除非映射、放松方向或等价性经过单独审计，否则绝不提升为全局结论。

## 4. 二十个实例的最终结果

表中 † 表示 `P*` 属于逐实例的容差分层口径，不能解释为统一零容差严格值。所有精确十进制词法以 `summary.csv` 为准。

| B | 实例 | `P*` | `D` | 相对 gap | 数学结论 |
|---:|---|---:|---:|---:|---|
| 1 | `graphdraw-grafo2` | 68595.5 | 36159.784210526326 | 47.2855% | 新严格 incumbent，开放 |
| 1 | `polygonpack4-10` | -53594508.70758325† | -93676450.23559369 | 74.7874% | 容差分层 P，开放 |
| 1 | `scpm1` | 537 | 414 | 22.9050% | 精确有理下界，开放 |
| 1 | `ger50-17-trans-dfn-3t` | 3969.433399999999 | 3929.073502371996 | 1.0168% | 开放 |
| 2 | `eva1aprime6x6opt` | -18.101002981361386† | -495.3702539490355 | 2636.7006% | 容差分层 P，开放 |
| 2 | `cmflsp60-36-2-6` | 73891244.22159792† | 71322258.264677 | 3.4767% | 无严格改善，开放 |
| 2 | `r4l4-02-tree-bounds-50` | 499097063 | 479452299.6156765 | 3.9361% | 新严格 incumbent，开放 |
| 2 | `sct1` | -187.52765083903063† | -201.483830038592 | 7.4422% | 容差分层 P，开放 |
| 3 | `shipsched` | 111919.8337342348† | 79152.37747691161 | 29.2776% | 容差分层 P，开放 |
| 3 | `rocII-8-11` | -8.739845027008393† | -11.854388559168083 | 35.6361% | 容差分层 P，开放 |
| 3 | `ns1856153` | 34.01697312588408 | 28.900000000000006 | 15.0424% | 新严格 incumbent，开放 |
| 3 | `dc1l` | 1758647.6801 | 1748341.9142596035 | 0.5860% | 开放 |
| 4 | `neos-5221106-oparau` | 52.07 | 42.54 | 18.3023% | 新严格 incumbent，开放 |
| 4 | `zeil` | 1081.3585 | 833.8312541332446 | 22.8904% | 开放 |
| 4 | `cdma` | -24778478399999989.93240 | -63828901980830619.66410742284140406012091284602512785 | 157.5982% | 开放 |
| 4 | `ns1456591` | 988.14128344 | 988.14128344 | 0 | **精确全局最优** |
| 5 | `seqsolve1` | 4277 | 4269 | 0.1870% | 开放 |
| 5 | `stockholm` | 122 | 104 | 14.7541% | 开放 |
| 5 | `supportcase22` | 110 | 6.0 | 94.5455% | 开放 |
| 5 | `neos-3682128-sandon` | 34666770 | 34666770 | 0 | **精确全局最优** |

## 5. 逐实例结论、方法与失败路线

### Batch 1

#### `graphdraw-grafo2`

目标图的度结构和断开分量支持按分量设计 LNS。实验生成并在原 MPS 上独立复核了 68595.5，相对冻结公共 incumbent 改善 18；未经修改的原模型给出全局下界 36159.784210526326。更宽的分量邻域在时限内没有继续改善，因此结果仍开放。详见 `instances/graphdraw-grafo2/instance_report.md`。

#### `polygonpack4-10`

主路线是投影等价的 canonical-slice linking 与核心局部分支。公共 primal -53594508.70758325 被保留；该点通过 `1e-6`、在 `1e-7` 下失败，最大原始行违反为 9.569714620738523e-7，因此不称为零容差严格点。等价模型产生可转移的计算型全局下界 -93676450.23559369。成对冲突搜索没有发现有效冲突，半径 2 搜索超时且没有 primal 进展。详见 `instances/polygonpack4-10/instance_report.md`。

#### `scpm1`

公开来源存在 540 与 solution table ID8 的 537 冲突，实验保留差异并严格回放 537。原 LP 的精确有理对偶证书给出 413.781670848；利用整数目标格点安全上取整为全局下界 414。确定性 cost-1 RWLS 没有改善 537。详见 `instances/scpm1/instance_report.md`。

#### `ger50-17-trans-dfn-3t`

12 条独立推导并审计的 rounded logical cutset 用于同预算强化；最终 primal 基本保持公共 3969.4334，全局计算界提升到 3929.073502371996。该切割试验为正，但 gap 仍为 1.0168%，继续做无结构依据的参数扫掠被停止。详见 `instances/ger50-17-trans-dfn-3t/final_report.md`。

### Batch 2

#### `eva1aprime6x6opt`

恢复了 material-choice、冗余 indicator、冲突 clique 和对称结构，并测试固定模式 recourse、对称精确/局部邻域及 cardinality shell。页面/solution ID6 的 -18.10146978964996 在冻结的 `1e-6` 原 MPS 审计下失败；ID5 的 -18.100995280293 是严格参考。CSV 的 `P*=-18.101002981361386` 是 `1e-6` 容差索引候选；另有 `1e-9` 候选 -18.100995282203325 和更稳健的 `1e-10` 固定模式值 -18.10099528029322。未发现新的严格整数拓扑；经等价 indicator 审计的计算界为 -495.3702539490355。详见 `instances/eva1aprime6x6opt/final_report.md`。

#### `cmflsp60-36-2-6`

测试精确固定模式 LP recourse、Y/Z 邻域和未经修改原模型的确认运行。CSV 候选 73891244.22159792 通过冻结 `1e-6` 门槛但在 `1e-7` 下失败；严格固定模式 recourse 为 73891245.64760002，因此不声称严格 primal 改善。原模型运行给出全局下界 71322258.264677；whole family 1 仍未解决。详见 `instances/cmflsp60-36-2-6/final_report.md`。

#### `r4l4-02-tree-bounds-50`

图/树结构导出五条经独立复核的 BFS fundamental-cycle inequalities。结构化求解获得严格原始-MPS primal 499097063，相对冻结公共值改善 35,116；有效全局下界为 479452299.6156765。强化后的有限试验仍以 TIME_LIMIT 停止，未证明最优。详见 `instances/r4l4-02-tree-bounds-50/final_report.md`。

#### `sct1`

测试固定外部变量的精确邻域、局部分支、LP 精确有理证书和最终原模型全局控制。CSV 保留公共容差级 `P*=-187.52765083903063`；严格修复值 -187.52764944960396 略差，因此无 primal 改善。原 MPS 计算下界为 -201.483830038592，另保留较弱但可移植的精确 LP 证书 -218.139003128115。详见 `instances/sct1/final_report.md`。

### Batch 3

#### `shipsched`

依据 precedence/scheduling 结构测试固定模式 recourse、文献启发邻域及 3,892 条独立验证的 directed-cycle inequalities。CSV 的 111919.8337342348 是转移的 `1e-6` 容差候选；更严格的原始-MPS witness 为 111920。2400 秒切割运行把可转移全局下界提高到 79152.37747691161，但没有严格 primal 改善。详见 `instances/shipsched/final_report.md`。

#### `rocII-8-11`

主要路线是公共整数模式修复、时间结构限制和最终未经修改原模型控制。CSV 的 `1e-6` 候选为 -8.739845027008393；固定模式 recourse 得到 `1e-9` witness -8.739844934961763。所有结构搜索都没有改变整数拓扑；原模型全局下界为 -11.854388559168083。详见 `instances/rocII-8-11/final_report.md`。

#### `ns1856153`

建立了精确 connectivity projection、transpose/tree 最优值等价关系，并在 incumbent cutoff 下收紧 1,568 条 big-M 行。得到严格 primal 34.01697312588408，相对冻结公共记录改善 0.14648867377531；计算型全局下界为 28.900000000000006。最终强化路线未超越前一结构路线，实例仍开放。详见 `instances/ns1856153/final_report.md`。

#### `dc1l`

完成结构商、精确映射和有理证书链，并审计多个受限邻域和 matched original control。公共 primal 1758647.6801 保留；未经修改原模型的最强计算下界为 1748341.9142596035，另有较弱但可移植的精确下界 1744591.69295。商模型加速假设未成立，受限邻域界未被提升为全局界。详见 `instances/dc1l/final_report.md`。

### Batch 4

#### `neos-5221106-oparau`

基于 routing/mode-4 结构建立 incumbent-capped 精确投影，并测试 route exchange、two-for-one 和 assignment-radius 邻域。严格 primal 52.07 相对公共 52.67 改善 0.60；经映射审计的计算型全局下界为 42.54，另有可移植精确 Lagrangian 下界 36.24。最初的无条件 MTZ 路线被严格门禁证伪，相关 29.84 数值已隔离且从未作为最终界使用。详见 `instances/neos-5221106-oparau/final_report.md`。

#### `zeil`

对 timetable 模式做精确连续 recourse，并建立带 support cuts 的 `w` 投影。严格 primal 为 1081.3585；经审计投影模型给出计算型全局下界 833.8312541332446，另有精确有理 projected-LP 证书 771.534476759。八前缀 cutoff 只关闭受限域，未被错误转移为全局结论。详见 `instances/zeil/final_report.md`。

#### `cdma`

公共近整数点未通过严格政策；固定模式原空间 recourse 给出严格 primal -24778478399999989.93240。对原 LP 加 3,600 条独立验证的 OR-hull 不等式后，有限 Decimal bounded-box Lagrangian 证书给出全局下界 -63828901980830619.66410742284140406012091284602512785。该界可移植但 gap 仍很大，局部结构反证没有闭合问题。详见 `instances/cdma/final_report.md`。

#### `ns1456591`

公共数值更优的 ID3 未通过严格 `1e-9` 政策，严格 primal 为 988.14128344。完整路线商产生 387 个完整 route columns；Held–Karp/集合划分 DP、完整主问题精确有理对偶和全系数 crosswalk 共同给出相同下界。原始 witness 在 8,399 个变量、1,997 条行上通过严格复核，因此原问题精确最优为 988.14128344。详见 `instances/ns1456591/final_report.md`。

### Batch 5

#### `seqsolve1`

原 MPS 含 207,665 个变量、242,243 条行和 1,027,681 个非零。结构核心包括 person/site/day 小块、site coupling 与 shortage/excess 目标。公开 4277 witness 经全部 1,027,681 个整数矩阵项的零容差复核；未经修改原模型的单次 300 秒 baseline 给出全局下界 4269。activation hull、half-rounding 和 Hall projection 三组独立审计强化均未超过 4269，最终 gap 为 8/4277。详见 `instances/seqsolve1/final_report.md`。

#### `stockholm`

结构恢复为 416 节点、962 条弧、45 个 OD 对的 minimum-toll-design 模型。页面数值 120.9999950202855 对应的公开 solution 4 在 `1e-6` 下违反二元性；公开 solution 3 和两个独立构造点以严格 primal 122 通过原 MPS。原模型 baseline 下界为 104。两阶段 monotone combinatorial Benders 共生成并逐条原模型重放 815 条有效 cut，但没有改善 104，也没有排除目标 121。详见 `instances/stockholm/final_report.md`。

#### `supportcase22`

7,129 个变量全部为二元；640 条等式形成可精确替换的变量别名，145 组 support indicator 需要保留五条不可省略的容量行。严格公共 primal 110 通过零容差回放。以全部 DEC master rows 开始、20 轮加入 96 条被违反原始行后，最终 27,657-row 子集 relaxation 的 raw bound 为 5.999999999998181。安全向下取 5.999，再利用完整目标审计得到的 `(1/5)Z` 格点，推出原问题全局下界 6.0。该 relaxation 点恰违反五条原始行，因此从未被当作 primal。详见 `instances/supportcase22/final_report.md`。

#### `neos-3682128-sandon`

原 MPS 有 7,880 个整数变量、14,920 条约束和 50,438 个约束非零；语义核心是五个有序 job、四台 machine、三道 operation 和 120 个时间槽。页面显示的 34666767.4743958 对应点违反严格整数/行复核；严格参考为 34666770。实验枚举全部 admissible type sequences 与 82,794 个机器配置列，逐列检查精确有理对偶，并把配置解 lift 回所有原变量。Windows Python 3.13.5 与 euler4 Python 3.8.10 的标准库 checker 均返回 primal=dual=34666770；单 bit 负控制能正确拒绝损坏 witness。全局最优因此为 34666770。详见 `instances/neos-3682128-sandon/final_report.md`。

## 6. 容差与公共来源差异

以下情况解释了为什么 `P*` 不能在全部实例中简称为“严格 primal”：

| 实例 | CSV `P*` 与相关公共值 | 更严格复核或结论 |
|---|---|---|
| `polygonpack4-10` | 公共 `1e-6` 候选 -53594508.70758325 | 在 `1e-7` 失败；无新严格 primal |
| `eva1aprime6x6opt` | `1e-6` 候选 -18.101002981361386 | `1e-9` 为 -18.100995282203325；稳健 `1e-10` 为 -18.10099528029322；无新严格拓扑 |
| `cmflsp60-36-2-6` | `1e-6` 候选 73891244.22159792 | 在 `1e-7` 失败；严格 recourse 73891245.64760002；不计严格改善 |
| `sct1` | 公共容差级 -187.52765083903063 | 严格修复 -187.52764944960396，数值略差 |
| `shipsched` | 公共 `1e-6` 候选 111919.8337342348 | 严格 witness 111920 |
| `rocII-8-11` | `1e-6` 候选 -8.739845027008393 | `1e-9` witness -8.739844934961763 |
| `ns1456591` | 页面 ID3 数值更优 | ID3 严格失败；988.14128344 的 primal/dual 证书闭合原问题 |
| `stockholm` | 页面 120.9999950202855 | 对应点在 `1e-6` 违反二元性；严格 primal 122 |
| `neos-3682128-sandon` | 页面 34666767.4743958 | 对应点严格失败；34666770 获精确证明 |

这一区分避免把舍入显示、默认 solver tolerance 或未复核的 solution header 错当成数学证明。

## 7. 跨实例方法发现

1. **有限结构商可以闭合原问题，但完备性必须单独证明。** `ns1456591` 和 Sandon 的成功不仅来自“小模型”，还来自完整列集合、精确 primal/dual、原模型 crosswalk 和独立重放。
2. **计算型强化是否有用取决于证明轨迹，而不只看根 LP。** `seqsolve1` 的 activation hull 提高 LP，但同预算 MIP bound 反而不如未经修改 baseline；`stockholm` 的 815 条有效 Benders cut 也未超过原模型下界 104。
3. **安全 relaxation 加目标格点可把数值界变成严格全局界。** `supportcase22` 的 5.999→6.0 是删除约束方向、逐行身份审计和 `(1/5)Z` 目标格点共同作用的结果。
4. **严格原空间复核经常比新整数搜索更重要。** 多个页面/solver 点在默认容差下看似更优，却在更严格 replay 中消失；因此所有贡献必须写明 tolerance 和 provenance。
5. **受限邻域的负结果仍有价值，但不能全局化。** 多个 radius、fixed-pattern、prefix 和 union-core 试验证明了特定域内没有改善，帮助停止低价值路线，却没有证明全局最优。
6. **失败路线必须留存。** Oparau 的无条件 MTZ、Sandon 的错误时间方向 DP、Supportcase22 的首次名称解析错误均被保留、解释并排除在最终结论之外。

## 8. 审计、复现与完整性

核心交付：

- `summary.csv`：20×16 最终结果表；SHA-256 `7b1df6d2b6a9441cf16f2a82d2b7b77e782cb7ab73ea73b72c556718dd7934e7`
- `summary_rows_batch5.audit.json`：固定顺序、字段、模型 hash、证据路径、时间门与 gap 审计；PASS
- `summary_csv_batch5_exact.audit.json`：JSON→CSV Decimal 词法复核；20/20、零失败
- `batch5_root_review.json`：Batch 5 数学主张、manifest、权限、进程和 root manifest 同步审计；PASS
- `final_delivery_manifest.json`：核心交付清单；旁路 `final_delivery_manifest.sha256` 记录并校验其 SHA-256
- `protocol_events.md`：所有已知协议事件及影响判定

Batch 5 另经两个只读独立复核任务检查，没有发现界方向、gap 算术、严格/官方 primal 分离或受限结论提升方面的数学 overclaim。该独立 claim review 明确覆盖 Batch 5；Batch 1–2 的汇总行审计保存在 `summary_rows_batch1.audit.json`、`summary_rows_batch2.audit.json`，数学证据位于实例目录；Batch 3–4 另有 `batch3_root_review.json`、`batch4_root_review.json`。本报告不把 Batch 5 review 夸大为对前 16 个实例全部数学论证的重新审查。

最终远端状态：四个 Batch-5 实例的 summary/time/report 均存在，原始 archive 为 mode `0444`；Sandon 135/135 文件全树 SHA-256 一致；整个实验根的精确实例路径进程匹配数为 0。根 `manifest.md` 的 90–150 分钟修订已同步，本地/远端 SHA-256 均为 `1fdde8d8ea9937ec3c7f0af68128806956cc4b60550f900626d820bd0d32d3c4`。

## 9. 协议事件与影响

`protocol_events.md` 完整披露：

- 两次过宽的只读进程名过滤看到了实验根之外的命令行；没有打开、复制、修改或使用外部文件；
- `supportcase22` closeout 的绝对根 `rg` 排除 glob 失效，返回中出现 `cdma` 匹配；停止后未进一步读取，也未用于结论；
- 远端根 manifest 一度仍是旧时间规则，Batch 5 实际使用了用户明确的新规则；最终已同步并哈希一致；
- Sandon 增量同步遇到远端原件 `0444` 拒绝覆盖、一个临时误放审计副本和一个自动生成 pycache；均按精确路径清理，最终全树 parity 通过。

这些事件均为只读或行政 closeout 事件，没有给任何 primal、dual、gap 或最优性结论提供证据。

## 10. 局限与后续优先级

- 除两个精确闭合实例外，18 个实例仍开放；较小 gap 也不能替代证明。
- 多数 `best_valid_dual` 是可复现的计算型全局界，而非可移植精确有理证书；其证据等级逐实例标注。
- 公开页面和 incumbent 可能在冻结日期后变化；本报告只比较 2026-09-11 冻结快照。
- 求解器时间是已记录工作量，不保证涵盖每个极短、未单独计时的诊断阶段。
- 累计 active/solver 时间是实例工作量总和；四实例并行时不能解释为整个实验的单一墙钟耗时。

建议优先继续：

1. `seqsolve1`：gap 仅 8 个整数目标单位，优先研究可证明的 site-coupling 分解或 4269–4277 区间排除；
2. `dc1l`：0.5860% gap，优先强化已有 exact quotient/certificate 链，而非重复参数扫掠；
3. `ger50-17-trans-dfn-3t`：扩展已显示正作用的独立 cutset 家族；
4. `cmflsp60-36-2-6`：先建立统一严格 primal 口径，再探索尚未闭合的 whole-family 结构；
5. `r4l4-02-tree-bounds-50`：围绕新 incumbent 与 fundamental-cycle cuts 做证明导向的分支/分解；
6. `stockholm`：研究能提高 master lower bound 的更强 toll-design 投影，而非继续累积同类 IIS cut。

其余开放实例的下一条建议路线、精确命令和失败边界保存在各自 final report 与 chronological ledger 中。

## 11. 实例证据索引

| 实例 | 主报告 |
|---|---|
| `graphdraw-grafo2` | `instances/graphdraw-grafo2/instance_report.md` |
| `polygonpack4-10` | `instances/polygonpack4-10/instance_report.md` |
| `scpm1` | `instances/scpm1/instance_report.md` |
| `ger50-17-trans-dfn-3t` | `instances/ger50-17-trans-dfn-3t/final_report.md` |
| `eva1aprime6x6opt` | `instances/eva1aprime6x6opt/final_report.md` |
| `cmflsp60-36-2-6` | `instances/cmflsp60-36-2-6/final_report.md` |
| `r4l4-02-tree-bounds-50` | `instances/r4l4-02-tree-bounds-50/final_report.md` |
| `sct1` | `instances/sct1/final_report.md` |
| `shipsched` | `instances/shipsched/final_report.md` |
| `rocII-8-11` | `instances/rocII-8-11/final_report.md` |
| `ns1856153` | `instances/ns1856153/final_report.md` |
| `dc1l` | `instances/dc1l/final_report.md` |
| `neos-5221106-oparau` | `instances/neos-5221106-oparau/final_report.md` |
| `zeil` | `instances/zeil/final_report.md` |
| `cdma` | `instances/cdma/final_report.md` |
| `ns1456591` | `instances/ns1456591/final_report.md` |
| `seqsolve1` | `instances/seqsolve1/final_report.md` |
| `stockholm` | `instances/stockholm/final_report.md` |
| `supportcase22` | `instances/supportcase22/final_report.md` |
| `neos-3682128-sandon` | `instances/neos-3682128-sandon/final_report.md` |

## 12. 权威原始 archive SHA-256

以下 hash 对应每个精确实例名的权威 `.mps.gz` archive，而非派生模型：

| 实例 | SHA-256 |
|---|---|
| `graphdraw-grafo2` | `a5528a5b80f4405206449e26933e69eb5c2465bceff303a5086a572b80bdbfed` |
| `polygonpack4-10` | `c77946405fd9fc1a53aa56dec82a1dcdef9932248c15ecc17e1ea05d49ab0969` |
| `scpm1` | `fef145329bf9dd25fd9ff59a51816c044adf41ae627a23ab8c93eeb31cffed41` |
| `ger50-17-trans-dfn-3t` | `fd05921bf1e954a9123a8d686f1610c00f03f700235910962220b1f3b8d20704` |
| `eva1aprime6x6opt` | `32ac7ea0015a16edc5058a6c6c2c9e8d79262b170888fc806304aaa2a51e0161` |
| `cmflsp60-36-2-6` | `ce7f3600260baaf5e8cea531d616e212723875003366014af17d8802d2909da4` |
| `r4l4-02-tree-bounds-50` | `f6dedac412b6d9e9c6ee4ad0a91c92c27027d031efcd25a62dc4a26eb39d33f3` |
| `sct1` | `49423b96c7a5f3c64590ec8f283d0111e4a7730348693e5c1f53df09542fb7a2` |
| `shipsched` | `152d733821a90eae633bef181fe0e0907dc23e6a8afa8413bc98c22cc115b9f1` |
| `rocII-8-11` | `8d0f3e5aacd9ceec0e0c2618d96ba00ad87803b457adaac4542b4393af5155b1` |
| `ns1856153` | `f52ae202906c0df1bcc804b679c647cff2e62607c2b78301dff8b5d9f51a13b4` |
| `dc1l` | `49d40810273a4948b8b56be538b46575b566afa2f133094a4a687f05ab7604f5` |
| `neos-5221106-oparau` | `788ac2b03e5a11b39b58e616663ed598cc9523e64ff195c7c8d038e3b4459d2d` |
| `zeil` | `0a841d40523d10b0b66ebd2b3ad2a24baba5a351148b6bdf77685669a513bebe` |
| `cdma` | `84775da3b8e919cd5363bbe3f2a170a126b379f1f2d9cdf4b7ac70bbb93384fb` |
| `ns1456591` | `acc4972ca3c3f59ab052d7b39ca1ded34d5a685f82e0a64a95dc317839594ccf` |
| `seqsolve1` | `4aa946b2d01a7f6d700cbd35194b8938961b6e872f0deca4ac16b7268f43b1aa` |
| `stockholm` | `42f1fa8ba37eaf11999579b09562be30d6b26df151b06dcbaa710dab0eb82498` |
| `supportcase22` | `69b86a13d312e6531d03cd93f31d13e4b8db01dd4093761b72acdefeb38bd8a3` |
| `neos-3682128-sandon` | `8f2b0f9f2ca63ed893a5524279d98a983b967276f9bcbb278301fb146ca2f71c` |

## 13. 本次实验实际读取的 SKILL.md

- 绝对路径：`C:\Users\huangyicheng\.agents\skills\milp-structure-research\SKILL.md`
- SHA-256：`f8a09b104f0af3786b2e702f60dde3de7fd54a1aac581dff9bdd8a3325c84b4f`

每个实例开始前均重新执行并记录该 skill 的门禁；对应时间戳、文件字节数、引用文件 hash 和 `read_before_instance_access=true` 保存在实例证据目录中。支持材料清单见 `shared/skills_read.md`。
