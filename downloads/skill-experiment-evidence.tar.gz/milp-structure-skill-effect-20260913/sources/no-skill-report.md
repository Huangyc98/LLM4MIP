# MIPLIB 20例上下界与COPT表比较报告

编制日期：2026-09-13（Asia/Shanghai）。比较对象为前四批16例封存结果与干净Batch5四例的最终结果，以及用户提供的COPT表。本文是历史证据比较，不启动新求解、不修改原始模型，不读取其他实验臂的内部提示、日志或结果目录。附件内容仅作为数据处理。

## 1. 执行摘要

全部20例都是最小化：上界P越小越好，下界D越大越好，包括负数。本实验20个最终可行点均有原始空间检查；COPT数值仅有表内记录，尚未独立核验其向量和下界来源。以下“更好”首先是显示数值比较，不是同条件求解器胜负、世界纪录或新的证明。

| 比较项 | 本实验更好 | COPT更好 | 相同 | COPT缺失 | 可配对例数 |
| --- | --- | --- | --- | --- | --- |
| 上界P | 16 | 0 | 1 | 3 | 17 |
| 下界D | 13 | 5 | 1 | 1 | 19 |
| 统一gap | 16 | 1 | 0 | 3 | 17 |

在双方上下界均有限的17例中，本实验11例严格双界更好；sandon上界相同、下界更好；5例为本实验上界更好但COPT下界更好。COPT没有双界支配本实验的实例。统一gap只有dc1l为COPT更小。另3例COPT缺失上界，不能与有限值相减计算改进幅度。

16个数值更好的上界中，5个来自本实验搜索，11个来自外部解复验、外部离散模式补全或公开水平保留。另有cdma搜索生成但COPT缺失，sandon独立再发现且持平。全部20个最终点的来源构成为7个搜索产生、13个外部/派生；超过实验冻结公开headline的新贡献仍仅2例（graphdraw、r4l4），另有shipsched的严格参考改进。本实验全局最优证明0；COPT本20例子集为19个stop、1个abort，没有显示最优完成的实例。

## 2. 来源、匹配与比较方法

本实验采用[既有20例汇总报告](D:/sufe/AI4MIP/reports/miplib20_aggregate_20260913/report.md)及[独立验证记录](D:/sufe/AI4MIP/reports/miplib20_aggregate_20260913/report_validation.json)，不使用旧Batch5的失败/中间记录覆盖干净Batch5最终结果。COPT采用[用户提供的原始PDF](D:/sufe/AI4MIP/output/pdf/copt_bounds_source.pdf)：1页、217行，20个精确实例名称全部唯一匹配；按名称而不是行号连接。表中完整行号、节点数、Res、Sol、短Hash、P/D/gap保存在[原表结构化提取](D:/sufe/AI4MIP/reports/miplib20_vs_copt_20260913/copt_source_extraction.json)。

PDF证据路径缩写（Markdown及comparison.json仍保留绝对路径）：OLD=`D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/`；B5=`D:/sufe/AI4MIP/batch5_clean_20260913T0052CST/`；AGG=`D:/sufe/AI4MIP/reports/miplib20_aggregate_20260913/`；CMP=`D:/sufe/AI4MIP/reports/miplib20_vs_copt_20260913/`。将缩写替换为此根路径即可恢复逐例完整证据文件位置。

COPT PDF SHA-256：`d34798161c0535ba22595ffc1cc8c1dfb40a86d5b21963a542297330db65589f`。元数据生成日期为2026-09-07 02:18:14 UTC，仅证明PDF生成时间字段，不证明求解运行日期；macOS Quartz生产器也不证明求解机器操作系统。短Hash字段只有7-8位十六进制，含义未知，不能替代原MPS SHA-256。本实验原始文件哈希见附录。双方模型身份目前只能按名称匹配，不能称为已证明字节相同。

统一gap（百分比）定义为 `100 × abs(P-D) / max(abs(P), abs(D))`；两者都为0时按0处理，缺失任一有限界时不计算。此分母与[COPT官方参数文档](https://guide.coap.online/copt/en-doc/parameter.html#relgap)一致（访问2026-09-13）。本实验旧汇总采用`abs(P)`分母，本报告保留旧公式值供追溯，但主比较重新计算两边；不能把旧报告gap直接与COPT印刷gap相比较。目标跨零时gap可超过100%，不裁剪。

所有差值采用60位Decimal精度从源字符串计算；“相同”的绝对比较门槛为1e-7。差值定义：上界优势= COPT P - 本实验P；下界优势= 本实验D - COPT D。正数表示本实验更好，负数表示COPT更好。源表本实验P/D保留原记录精度，COPT保留其显示精度；差值更多位数只来自显示数值运算，不意味着COPT有相同有效精度。gap显示6位小数，完整运算结果在comparison.json。

COPT表中的P=1e20及D=-1e20按无有限解/界占位符处理；不把它们当作真实有限上界/下界，不据此证明不可行或无界。`--`表示原表未显示gap，不等于0。ns1856153原表gap为`--`，但由有限P=49.1310069、D=0可计算100%；因此17例gap配对包含此项自行计算。若只统计PDF已显示gap的16例，则本实验15例更小、COPT1例更小。

## 3. 20例上界P比较

越小越好；优势为COPT P减本实验P。缺失行保留占位原文，不纳入有限值胜负。

| 实例（批次） | 本实验已验证P | COPT表P | 本实验上界优势 | 判定 |
| --- | --- | --- | --- | --- |
| graphdraw-grafo2（1） | 68609.5 | 109951.5 | 41342 | 本实验更好 |
| polygonpack4-10（1） | -53594508.70758318 | -51836818.8 | 1757689.90758318 | 本实验更好 |
| scpm1（1） | 537 | 630 | 93 | 本实验更好 |
| ger50-17-trans-dfn-3t（1） | 3969.433399999997 | 4352.9664 | 383.533000000003 | 本实验更好 |
| eva1aprime6x6opt（2） | -18.100995280293148 | 1.71485284 | 19.815848120293148 | 本实验更好 |
| cmflsp60-36-2-6（2） | 73891245.64760005 | 74492812.1 | 601566.45239995 | 本实验更好 |
| r4l4-02-tree-bounds-50（2） | 499110528 | 512613056 | 13502528 | 本实验更好 |
| sct1（2） | -187.52764944960393 | -170.822429 | 16.70522044960393 | 本实验更好 |
| shipsched（3） | 111919.9869111547 | 130497.996 | 18578.0090888453 | 本实验更好 |
| rocII-8-11（3） | -8.739844934961763 | -4.72446527 | 4.015379664961763 | 本实验更好 |
| ns1856153（3） | 34.16347439886857 | 49.1310069 | 14.96753250113143 | 本实验更好 |
| dc1l（3） | 1758647.6800999984 | 1760000.09 | 1352.4099000016 | 本实验更好 |
| neos-5221106-oparau（4） | 52.669999994631496 | 1e+20 | -- | COPT缺失 |
| zeil（4） | 1081.3585000000078 | 1363.5585 | 282.1999999999922 | 本实验更好 |
| cdma（4） | -22966095679999980 | 1e+20 | -- | COPT缺失 |
| ns1456591（4） | 988.1412834399998 | 1307.35364 | 319.2123565600002 | 本实验更好 |
| seqsolve1（5） | 4279 | 4371 | 92 | 本实验更好 |
| stockholm（5） | 129 | 137 | 8 | 本实验更好 |
| supportcase22（5） | 110 | 1e+20 | -- | COPT缺失 |
| neos-3682128-sandon（5） | 34666770 | 34666770 | 0 | 相同 |

cdma、oparau、supportcase22是“本实验有已检查可行点，COPT表未记录有限可行上界”，不是3个可量化的有限上界改进。sandon唯一持平，双方P=34666770。

## 4. 20例下界D比较

越大越好；优势为本实验D减COPT D。COPT下界在本报告中属于未独立核验的表内报告值。

| 实例（批次） | 本实验数值D | COPT表D | 本实验下界优势 | 判定 |
| --- | --- | --- | --- | --- |
| graphdraw-grafo2（1） | 36415.8465747 | 36314.1643 | 101.6822747 | 本实验更好 |
| polygonpack4-10（1） | -93676649.5393 | -93676573.4 | -76.1393 | COPT更好 |
| scpm1（1） | 415 | 415.555435 | -0.555435 | COPT更好 |
| ger50-17-trans-dfn-3t（1） | 3917.155362335 | 3831.36744 | 85.787922335 | 本实验更好 |
| eva1aprime6x6opt（2） | -239.4227696265 | -140.895641 | -98.5271286265 | COPT更好 |
| cmflsp60-36-2-6（2） | 73188341.59842 | 72075510.1 | 1112831.49842 | 本实验更好 |
| r4l4-02-tree-bounds-50（2） | 480648435.4129 | 478217938 | 2430497.4129 | 本实验更好 |
| sct1（2） | -200.2450490980 | -202.560756 | 2.315706902 | 本实验更好 |
| shipsched（3） | 81014.60455187 | 67029.7019 | 13984.90265187 | 本实验更好 |
| rocII-8-11（3） | -11.8377922287 | -11.889881 | 0.0520887713 | 本实验更好 |
| ns1856153（3） | 0.003362513402564 | 0 | 0.003362513402564 | 本实验更好 |
| dc1l（3） | 1749186.534225 | 1751049.95 | -1863.415775 | COPT更好 |
| neos-5221106-oparau（4） | 0.0 | 0 | 0 | 相同 |
| zeil（4） | 815.3797428765 | 834.502247 | -19.1225041235 | COPT更好 |
| cdma（4） | -31763448000000000 | -1e+20 | -- | COPT缺失 |
| ns1456591（4） | 473.415027263 | 459.574181 | 13.840846263 | 本实验更好 |
| seqsolve1（5） | 4272 | 4268.52039 | 3.47961 | 本实验更好 |
| stockholm（5） | 106 | 93.5364881 | 12.4635119 | 本实验更好 |
| supportcase22（5） | 1.4000000000000001 | 0.88353308 | 0.5164669200000001 | 本实验更好 |
| neos-3682128-sandon（5） | 21672926.242906883 | 21531270.9 | 141655.342906883 | 本实验更好 |

COPT下界较好的5例为polygonpack4-10、scpm1、eva1aprime6x6opt、dc1l、zeil。oparau双方为0；cdma缺失。polygonpack的76.1393差别在巨大目标尺度下非常接近，不升级为确定实质数学界改善。

## 5. 统一gap、原表gap与结果来源

单位均为%；gap优势为COPT统一gap减本实验统一gap，单位为百分点。以下原表gap只保留来源，不用于代替从显示P/D重算的统一值。来源标签“搜索”不等于超过公开纪录。

| 实例 | 本实验统一gap | COPT统一gap | COPT原表gap | gap优势（百分点） | 最终点来源 |
| --- | --- | --- | --- | --- | --- |
| graphdraw-grafo2 | 46.923026 | 66.972561 | 67.0 | 20.049535 | 搜索 |
| polygonpack4-10 | 42.787761 | 44.664053 | 44.7 | 1.876292 | 外部/派生 |
| scpm1 | 22.718808 | 34.038820 | 34.0 | 11.320012 | 外部/派生 |
| ger50-17-trans-dfn-3t | 1.317015 | 11.982609 | 12.0 | 10.665594 | 外部/派生 |
| eva1aprime6x6opt | 92.439735 | 101.217109 | 101.2 | 8.777373 | 外部/派生 |
| cmflsp60-36-2-6 | 0.951268 | 3.245014 | 3.2 | 2.293745 | 外部/派生 |
| r4l4-02-tree-bounds-50 | 3.698999 | 6.709762 | 6.7 | 3.010764 | 搜索 |
| sct1 | 6.350918 | 15.668547 | 15.7 | 9.317628 | 外部/派生 |
| shipsched | 27.613819 | 48.635455 | 48.6 | 21.021636 | 搜索 |
| rocII-8-11 | 26.169975 | 60.264823 | 60.3 | 34.094848 | 外部/派生 |
| ns1856153 | 99.990158 | 100.000000 | -- | 0.009842 | 外部/派生 |
| dc1l | 0.537978 | 0.508531 | 0.5085 | -0.029448 | 外部/派生 |
| neos-5221106-oparau | 100.000000 | -- | -- | -- | 外部/派生 |
| zeil | 24.596723 | 38.799674 | 38.8 | 14.202951 | 外部/派生 |
| cdma | 27.696465 | -- | -- | -- | 搜索 |
| ns1456591 | 52.090350 | 64.846988 | 64.8 | 12.756638 | 外部/派生 |
| seqsolve1 | 0.163590 | 2.344535 | 2.3 | 2.180945 | 搜索 |
| stockholm | 17.829457 | 31.725191 | 31.7 | 13.895734 | 搜索 |
| supportcase22 | 98.727273 | -- | -- | -- | 外部/派生 |
| neos-3682128-sandon | 37.482130 | 37.890750 | 37.9 | 0.408620 | 搜索 |

EVA的本实验旧primal分母gap约1222.705000%，统一后为92.439735%；这只是口径更正，不是新求解进展。COPT的上界为正而下界为负，统一gap约101.217109%。dc1l则COPT统一gap约0.508531%，本实验约0.537978%；上界胜负不能代替gap胜负。不能将不同目标尺度的绝对差值相加、也不以平均gap宣布总体算法获胜。

## 6. 五例互补结果及条件数值包络

若未来确认COPT与本实验使用同一个原问题，且其下界具有可追溯的原问题有效证据，才可把本实验较好的P与COPT较好的D组成更窄参考区间。下表仅是“待核验跨来源数值包络”，不是任何一方单次运行结果，不写回本实验best_valid_dual，不计新下界、新求解或最优证明。

| 实例 | 本实验已检查P | COPT报告D | COPT D优势 | 本实验gap | 条件包络gap |
| --- | --- | --- | --- | --- | --- |
| polygonpack4-10 | -53594508.70758318 | -93676573.4 | 76.1393 | 42.787761 | 42.787714 |
| scpm1 | 537 | 415.555435 | 0.555435 | 22.718808 | 22.615375 |
| eva1aprime6x6opt | -18.100995280293148 | -140.895641 | 98.5271286265 | 92.439735 | 87.152906 |
| dc1l | 1758647.6800999984 | 1751049.95 | 1863.415775 | 0.537978 | 0.432021 |
| zeil | 1081.3585000000078 | 834.502247 | 19.1225041235 | 24.596723 | 22.828345 |

其余实例没有更强COPT下界可补入。所有条件包络仍未闭合；即使有限数值界一致，仍需原始模型身份、可行性和下界证据审计，不能凭表格或舍入gap证明最优。

## 7. 实验条件与证据等级

| 项目 | 本实验Batch1-4 | 本实验干净Batch5 | COPT提供表 |
| --- | --- | --- | --- |
| 主求解器 | Gurobi CLI13.0.1；核验13.0.2 | Gurobi/gurobipy13.0.2 | 版本未提供 |
| 每实例搜索线程 | 16 | 8 | 8 |
| 研究/运行时间 | 有效90.003-107.520分钟 | 有效90.322-99.823分钟 | 19例36000秒；cdma0.1秒abort |
| 内存参数 | SoftMemLimit=96 GB | SoftMemLimit=32 GB | 未知 |
| 随机种子 | 默认20260911；ger预注册一次20260912 | 20260911 | 未知 |
| 候选起点 | 部分使用验证公开解/离散模式 | 仅本轮搜索基线；support110未热启动 | 未提供 |
| 主机 | 共享euler4，64物理核/128线程，约503GiB RAM | 同主机 | 未知 |
| 接受/检查 | 原始空间1e-7数值门槛、固定向量重放 | 原始MPS十进制/Fraction精确可行性 | 只有Sol ok标记，容差/向量未知 |
| 其他参数 | 逐运行日志保存 | 搜索1e-7，验证LP/recourse1e-9 | WriteSolZeros=0; RelGap=0 |

本实验模型/设置记录为5.6Sol / Ultra，系用户界面确认及原清单记录，不是本报告运行时独立识别。COPT许可证、版本、硬件、内存、种子、热启动和容差均未知；旧清单检测到辅助COPT8.0.4不能推断此PDF的版本。PDF的RelGap=0是参数要求，不能证明19个stop达到最优；全表217例的“solved=2”也不能套到这20例。Sol ok不能等同于本实验1e-7门槛或Batch5精确复验。

证据等级：本实验前16点具有原始界限、整数性、约束和目标重算的数值检查及固定向量可行性重放；它们不是全模型精确有理可行证明。Batch5四点有完整原始MPS十进制有理精确检查。原始/合法增广模型的Gurobi数值全局D有日志/割有效性证据，但不是精确完整分支树证明。Batch5精确下界单列为seq=4250、stockholm=16、supportcase22=0、sandon=4737730，不能将表内更强数值D称为同级精确证书。

本实验最终P和D可能来自不同阶段，且13个P利用外部公开结果；COPT每行则只有一个汇总记录。故“较短时间获得较好最终汇总界”不等于公平的速度或求解器性能优势。应在同MPS哈希、同起点政策、同资源、同预算和同核验门槛下另做预注册对照；本报告不擅自启动该对照。

历史控制偏差仍保留：Batch3曾短暂增加第五个验证进程（roc约0.133249秒，ships两次合计约0.052451秒），以及不足2秒跨已完成批证据重读；这些未产生新结果/时间信用，但违反保守并发控制。部分旧gate脚本历史字节和新Batch5早期manifest/基线驱动启动时哈希有归档缺口。源表solver_minutes口径并不统一，scpm等未涵盖全部受限/中断调用，不能直接计算公平时间加速比。详细台账见[协议偏差记录](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/meta/protocol_deviations.md)和既有汇总报告。

## 8. 逐例分析与证据导航

### Batch 1

#### graphdraw-grafo2

本实验区间 `[36415.8465747, 68609.5]`；COPT原表 `[36314.1643, 109951.5]`。上界：本实验更好；下界：本实验更好。本实验统一gap=46.923026%，COPT统一gap=66.972561%。

搜索生成68609.5，比实验冻结公开primal低约4。后续证明阶段未加强最强下界。本次比COPT的优势不依赖把外部解复验误算成新解。

方法：incumbent-centered MIPFocus=1/RINS followed by symmetry/bound focus。来源：new experiment-generated primal; untouched-original Gurobi tree bound。记录有效研究90.003分钟，源表solver时间90.003分钟（不是重新测量的全部优化调用总时长）。COPT行号62，Time=36000.0秒，Nodes=4222，Res=stop，Sol=ok，短Hash=2e8f8787。

原实验停止理由：all preregistered stages completed and 90-minute floor reached。仍开放，没有本实例全局最优证明。核验等级：原始空间1e-7数值检查 + 固定向量可行性重放；非全模型精确有理证明。

证据：[个例最终报告](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch1/graphdraw-grafo2/final_report.md)；[原始空间检查](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch1/graphdraw-grafo2/verification/primal/verification.json)；[最终原始空间向量](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch1/graphdraw-grafo2/solutions/primal_canonical.sol)。检查和解文件SHA-256及原始MPS哈希记录在[comparison.json](D:/sufe/AI4MIP/reports/miplib20_vs_copt_20260913/comparison.json)；本次只做其字节完整性重验，不冒充重新求解或重新运行可行性算法。

#### polygonpack4-10

本实验区间 `[-93676649.5393, -53594508.70758318]`；COPT原表 `[-93676573.4, -51836818.8]`。上界：本实验更好；下界：COPT更好。本实验统一gap=42.787761%，COPT统一gap=44.664053%。

最终点是外部整数模式的连续坐标补全，不是新装箱设计。COPT下界只高76.1393；相对其约9.37e7的尺度，差异约0.0000813%，数值非常接近，需原始日志和数值审计确认。

方法：external integer-pattern continuous repair plus numeric/bound and diversification runs。来源：transferred external integer pattern with recomputed continuous completion; untouched-original Gurobi tree bound。记录有效研究95.024分钟，源表solver时间95.024分钟（不是重新测量的全部优化调用总时长）。COPT行号156，Time=36000.0秒，Nodes=4384348，Res=stop，Sol=ok，短Hash=5b22e33。

原实验停止理由：four disjoint formal runs exceeded 90 minutes; later bound directions showed low marginal value。仍开放，没有本实例全局最优证明。核验等级：原始空间1e-7数值检查 + 固定向量可行性重放；非全模型精确有理证明。

证据：[个例最终报告](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch1/polygonpack4-10/final_report.md)；[原始空间检查](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch1/polygonpack4-10/verification/tailored_numeric_bound/verification.json)；[最终原始空间向量](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch1/polygonpack4-10/solutions/tailored_numeric_bound.sol)。检查和解文件SHA-256及原始MPS哈希记录在[comparison.json](D:/sufe/AI4MIP/reports/miplib20_vs_copt_20260913/comparison.json)；本次只做其字节完整性重验，不冒充重新求解或重新运行可行性算法。

#### scpm1

本实验区间 `[415, 537]`；COPT原表 `[415.555435, 630]`。上界：本实验更好；下界：COPT更好。本实验统一gap=22.718808%，COPT统一gap=34.038820%。

537来自外部解复验。成本1限制模型中的418不是原问题下界，不能用于本表。合法原问题415比COPT的415.555435稍弱。

方法：cost-1 restriction diagnosis and original-model primal-focused continuation。来源：transferred external primal; untouched-original Gurobi baseline bound。记录有效研究95.633分钟，源表solver时间83.530分钟（不是重新测量的全部优化调用总时长）。COPT行号177，Time=36000.0秒，Nodes=1118，Res=stop，Sol=ok，短Hash=7d7d27f。

原实验停止理由：external 537 remained best; original continuation and restricted experiment exhausted useful directions above time floor。仍开放，没有本实例全局最优证明。核验等级：原始空间1e-7数值检查 + 固定向量可行性重放；非全模型精确有理证明。

证据：[个例最终报告](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch1/scpm1/reports/final_report.md)；[原始空间检查](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch1/scpm1/verification/original_primal_resume_537/verification.json)；[最终原始空间向量](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch1/scpm1/experiments/original_primal_resume_2100s/best.sol)。检查和解文件SHA-256及原始MPS哈希记录在[comparison.json](D:/sufe/AI4MIP/reports/miplib20_vs_copt_20260913/comparison.json)；本次只做其字节完整性重验，不冒充重新求解或重新运行可行性算法。

#### ger50-17-trans-dfn-3t

本实验区间 `[3917.155362335, 3969.433399999997]`；COPT原表 `[3831.36744, 4352.9664]`。上界：本实验更好；下界：本实验更好。本实验统一gap=1.317015%，COPT统一gap=11.982609%。

固定外部整数设计重算连续流后通过严格门槛。没有生成新网络设计；上下界虽都优于COPT表，贡献来源仍是外部模式补全和原始求解器界。

方法：external integer-pattern flow completion plus network-cut and proof-focused runs。来源：transferred external design pattern with recomputed continuous flows; untouched-original Gurobi baseline bound。记录有效研究95.003分钟，源表solver时间83.530分钟（不是重新测量的全部优化调用总时长）。COPT行号55，Time=36000.0秒，Nodes=268285，Res=stop，Sol=ok，短Hash=e5aa5752。

原实验停止理由：two complementary bound runs were weaker than baseline after the amended time floor。仍开放，没有本实例全局最优证明。核验等级：原始空间1e-7数值检查 + 固定向量可行性重放；非全模型精确有理证明。

证据：[个例最终报告](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch1/ger50-17-trans-dfn-3t/final_report.md)；[原始空间检查](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch1/ger50-17-trans-dfn-3t/verification/repaired_external_pattern/verification.json)；[最终原始空间向量](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch1/ger50-17-trans-dfn-3t/solutions/repaired_external_pattern.sol)。检查和解文件SHA-256及原始MPS哈希记录在[comparison.json](D:/sufe/AI4MIP/reports/miplib20_vs_copt_20260913/comparison.json)；本次只做其字节完整性重验，不冒充重新求解或重新运行可行性算法。

### Batch 2

#### eva1aprime6x6opt

本实验区间 `[-239.4227696265, -18.100995280293148]`；COPT原表 `[-140.895641, 1.71485284]`。上界：本实验更好；下界：COPT更好。本实验统一gap=92.439735%，COPT统一gap=101.217109%。

最小化负目标时，上界越负越好。最终-18.100995280293148来自公开ID5模式连续补全，不等于未通过实验门槛的headline -18.101469789649965。COPT下界更强，但其正上界使统一gap仍较大。

方法：paired primal and bound focus plus preregistered discrete-pattern continuous repair。来源：strict realization of transferred MIPLIB ID5 pattern; untouched-original Gurobi bound。记录有效研究107.520分钟，源表solver时间91.002分钟（不是重新测量的全部优化调用总时长）。COPT行号33，Time=36000.0秒，Nodes=9725，Res=stop，Sol=ok，短Hash=97bda2ae。

原实验停止理由：three preregistered runs exhausted 5460.10 solver seconds; no new discrete pattern or proof。仍开放，没有本实例全局最优证明。核验等级：原始空间1e-7数值检查 + 固定向量可行性重放；非全模型精确有理证明。

证据：[个例最终报告](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch2/eva1aprime6x6opt/final_report.md)；[原始空间检查](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch2/eva1aprime6x6opt/verification/tailored_primal_repaired/verification.json)；[最终原始空间向量](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch2/eva1aprime6x6opt/solutions/tailored_primal_repaired.sol)。检查和解文件SHA-256及原始MPS哈希记录在[comparison.json](D:/sufe/AI4MIP/reports/miplib20_vs_copt_20260913/comparison.json)；本次只做其字节完整性重验，不冒充重新求解或重新运行可行性算法。

#### cmflsp60-36-2-6

本实验区间 `[73188341.59842, 73891245.64760005]`；COPT原表 `[72075510.1, 74492812.1]`。上界：本实验更好；下界：本实验更好。本实验统一gap=0.951268%，COPT统一gap=3.245014%。

外部设置模式重算流获得最终上界，略差于名义公开headline，不算新公开primal。设施/流割方向的原始模型数值界优于COPT表。

方法：setup-pattern continuous repair followed by facility/flow cut proof run。来源：transferred external setup pattern with recomputed flows; untouched-original Gurobi bound。记录有效研究91.004分钟，源表solver时间91.004分钟（不是重新测量的全部优化调用总时长）。COPT行号13，Time=36000.0秒，Nodes=2300311，Res=stop，Sol=ok，短Hash=ffb30933。

原实验停止理由：all preregistered runs completed; strict public headline remained slightly infeasible at 1e-7。仍开放，没有本实例全局最优证明。核验等级：原始空间1e-7数值检查 + 固定向量可行性重放；非全模型精确有理证明。

证据：[个例最终报告](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch2/cmflsp60-36-2-6/final_report.md)；[原始空间检查](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch2/cmflsp60-36-2-6/verification/tailored_proof/verification.json)；[最终原始空间向量](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch2/cmflsp60-36-2-6/solutions/tailored_proof_normalized.sol)。检查和解文件SHA-256及原始MPS哈希记录在[comparison.json](D:/sufe/AI4MIP/reports/miplib20_vs_copt_20260913/comparison.json)；本次只做其字节完整性重验，不冒充重新求解或重新运行可行性算法。

#### r4l4-02-tree-bounds-50

本实验区间 `[480648435.4129, 499110528]`；COPT原表 `[478217938, 512613056]`。上界：本实验更好；下界：本实验更好。本实验统一gap=3.698999%，COPT统一gap=6.709762%。

新搜索解499110528比规范化公开参考499132179低21651。下界使用源JSON和日志的480648435.4129，不采用个例Markdown中舍入的480648435.413。

方法：PESP structure audit followed by public-started MIPFocus=3/Cuts=2 proof run。来源：new experiment-generated primal; untouched-original Gurobi tree bound。记录有效研究90.008分钟，源表solver时间90.008分钟（不是重新测量的全部优化调用总时长）。COPT行号162，Time=36000.0秒，Nodes=2373819，Res=stop，Sol=ok，短Hash=2c127925。

原实验停止理由：baseline and single preregistered treatment reached time floor with open gap。仍开放，没有本实例全局最优证明。核验等级：原始空间1e-7数值检查 + 固定向量可行性重放；非全模型精确有理证明。

证据：[个例最终报告](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch2/r4l4-02-tree-bounds-50/reports/final_report.md)；[原始空间检查](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch2/r4l4-02-tree-bounds-50/verification/tailored_bound_3000s_strict/verification.json)；[最终原始空间向量](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch2/r4l4-02-tree-bounds-50/experiments/tailored_bound_3000s/best.complete.sol)。检查和解文件SHA-256及原始MPS哈希记录在[comparison.json](D:/sufe/AI4MIP/reports/miplib20_vs_copt_20260913/comparison.json)；本次只做其字节完整性重验，不冒充重新求解或重新运行可行性算法。

#### sct1

本实验区间 `[-200.2450490980, -187.52764944960393]`；COPT原表 `[-202.560756, -170.822429]`。上界：本实验更好；下界：本实验更好。本实验统一gap=6.350918%，COPT统一gap=15.668547%。

最终点归于公开离散模式的连续补全。Symmetry配对试验仅是一轮有限预算结果，不能从本表推断普遍算法优势。负目标gap已统一分母。

方法：public-pattern continuous repair and paired Symmetry=2 versus Symmetry=0 proof runs。来源：strict realization of transferred public pattern; untouched-original Gurobi symmetry-arm bound。记录有效研究94.339分钟，源表solver时间90.004分钟（不是重新测量的全部优化调用总时长）。COPT行号179，Time=36000.0秒，Nodes=520251，Res=stop，Sol=ok，短Hash=1d1866b2。

原实验停止理由：paired preregistered arms completed; Symmetry=2 stronger but gap remained open。仍开放，没有本实例全局最优证明。核验等级：原始空间1e-7数值检查 + 固定向量可行性重放；非全模型精确有理证明。

证据：[个例最终报告](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch2/sct1/reports/final_report.md)；[原始空间检查](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch2/sct1/verification/public_id2_repaired/verification.json)；[最终原始空间向量](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch2/sct1/solutions/public_id2_repaired_explicit.sol)。检查和解文件SHA-256及原始MPS哈希记录在[comparison.json](D:/sufe/AI4MIP/reports/miplib20_vs_copt_20260913/comparison.json)；本次只做其字节完整性重验，不冒充重新求解或重新运行可行性算法。

### Batch 3

#### shipsched

本实验区间 `[81014.60455187, 111919.9869111547]`；COPT原表 `[67029.7019, 130497.996]`。上界：本实验更好；下界：本实验更好。本实验统一gap=27.613819%，COPT统一gap=48.635455%。

新解比严格接受参考111920低0.0130888453，但未低于未过门槛的公开headline111919.8337342348。小于1e-7的整数误差通过数值检查，并非精确整数证明。

方法：public-ID5-started primal neighborhood followed by numeric proof focus and sealed ID4 pattern-completion check。来源：new experiment-generated primal; untouched-original Gurobi proof-stage bound。记录有效研究91.023分钟，源表solver时间90.007分钟（不是重新测量的全部优化调用总时长）。COPT行号186，Time=36000.0秒，Nodes=2796250，Res=stop，Sol=ok，短Hash=ff00f02f。

原实验停止理由：fixed baseline/primal/bound program and strict repair gate completed above the 90-minute floor。仍开放，没有本实例全局最优证明。核验等级：原始空间1e-7数值检查 + 固定向量可行性重放；非全模型精确有理证明。

证据：[个例最终报告](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch3/shipsched/reports/final_report.md)；[原始空间检查](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch3/shipsched/verification/tailored_primal/verification.json)；[最终原始空间向量](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch3/shipsched/solutions/tailored_primal.sol)。检查和解文件SHA-256及原始MPS哈希记录在[comparison.json](D:/sufe/AI4MIP/reports/miplib20_vs_copt_20260913/comparison.json)；本次只做其字节完整性重验，不冒充重新求解或重新运行可行性算法。

#### rocII-8-11

本实验区间 `[-11.8377922287, -8.739844934961763]`；COPT原表 `[-11.889881, -4.72446527]`。上界：本实验更好；下界：本实验更好。本实验统一gap=26.169975%，COPT统一gap=60.264823%。

保留公开整数值重算连续轨迹，属于外部派生结果；证明方向加强数值下界但未闭合。负目标的gap不能直接使用旧报告的primal分母与COPT相比较。

方法：public-ID2 integer-only repair followed by aggressive-presolve proof run on the untouched original。来源：external-derived integer pattern with original-model continuous recomputation; untouched-original Gurobi bound。记录有效研究92.478分钟，源表solver时间91.022分钟（不是重新测量的全部优化调用总时长）。COPT行号171，Time=36000.0秒，Nodes=5489573，Res=stop，Sol=ok，短Hash=2640afb6。

原实验停止理由：all three preregistered stages completed and strict evidence was sealed above the time floor。仍开放，没有本实例全局最优证明。核验等级：原始空间1e-7数值检查 + 固定向量可行性重放；非全模型精确有理证明。

证据：[个例最终报告](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch3/rocII-8-11/reports/final_report.md)；[原始空间检查](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch3/rocII-8-11/verification/tailored_proof/verification.json)；[最终原始空间向量](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch3/rocII-8-11/solutions/tailored_proof.sol)。检查和解文件SHA-256及原始MPS哈希记录在[comparison.json](D:/sufe/AI4MIP/reports/miplib20_vs_copt_20260913/comparison.json)；本次只做其字节完整性重验，不冒充重新求解或重新运行可行性算法。

#### ns1856153

本实验区间 `[0.003362513402564, 34.16347439886857]`；COPT原表 `[0, 49.1310069]`。上界：本实验更好；下界：本实验更好。本实验统一gap=99.990158%，COPT统一gap=100.000000%。

固定外部整数模式重算42个连续变量。下界虽略高于COPT的0，仍十分弱。COPT原表gap为--；本报告的100%是由其有限P和D重新计算，并非原表已报告数值。

方法：certified symmetry analysis, fixed-integer public-pattern completion, and one Symmetry=2/MIPFocus=3 treatment。来源：external-derived pattern with recomputed continuous completion; untouched-original Gurobi tailored bound。记录有效研究93.660分钟，源表solver时间90.394分钟（不是重新测量的全部优化调用总时长）。COPT行号143，Time=36000.0秒，Nodes=55836，Res=stop，Sol=ok，短Hash=3fe1c0af。

原实验停止理由：baseline and single preregistered symmetry/bound treatment completed and passed all strict gates。仍开放，没有本实例全局最优证明。核验等级：原始空间1e-7数值检查 + 固定向量可行性重放；非全模型精确有理证明。

证据：[个例最终报告](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch3/ns1856153/reports/final_report.md)；[原始空间检查](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch3/ns1856153/verification/external_integer_pattern_completion_strict/verification.json)；[最终原始空间向量](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch3/ns1856153/solutions/miplib_id4_integer_pattern_continuous_completion.sol)。检查和解文件SHA-256及原始MPS哈希记录在[comparison.json](D:/sufe/AI4MIP/reports/miplib20_vs_copt_20260913/comparison.json)；本次只做其字节完整性重验，不冒充重新求解或重新运行可行性算法。

#### dc1l

本实验区间 `[1749186.534225, 1758647.6800999984]`；COPT原表 `[1751049.95, 1760000.09]`。上界：本实验更好；下界：COPT更好。本实验统一gap=0.537978%，COPT统一gap=0.508531%。

公开水平primal复验后保留。COPT下界比本实验高1863.415775，抵消其上界较差的部分，因此它是17个可计算gap中唯一COPT gap更小的实例。

方法：baseline, incumbent neighborhood, and symmetry-aware dual-proof stages。来源：strictly verified transferred public primal; untouched-original Gurobi proof-stage bound。记录有效研究90.021分钟，源表solver时间90.004分钟（不是重新测量的全部优化调用总时长）。COPT行号24，Time=36000.0秒，Nodes=974875，Res=stop，Sol=ok，短Hash=7a697fc1。

原实验停止理由：three preregistered stages completed, time floor met, and remaining gap stayed open。仍开放，没有本实例全局最优证明。核验等级：原始空间1e-7数值检查 + 固定向量可行性重放；非全模型精确有理证明。

证据：[个例最终报告](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch3/dc1l/reports/final_report.md)；[原始空间检查](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch3/dc1l/verification/final_best/verification.json)；[最终原始空间向量](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch3/dc1l/solutions/best_original_space.sol)。检查和解文件SHA-256及原始MPS哈希记录在[comparison.json](D:/sufe/AI4MIP/reports/miplib20_vs_copt_20260913/comparison.json)；本次只做其字节完整性重验，不冒充重新求解或重新运行可行性算法。

### Batch 4

#### neos-5221106-oparau

本实验区间 `[0.0, 52.669999994631496]`；COPT原表 `[0, 1e+20]`。上界：COPT缺失；下界：相同。本实验统一gap=100.000000%，COPT统一gap=未计算（缺少有限界）。

最终点为公开水平保留，约5.37e-9的显示差不算新贡献。COPT没有有限上界；双方下界同为0。只能判断解可获得性不同，不能计算有限上界改进幅度。

方法：strict public-ID3 start followed by one symmetry/aggressive-cut proof treatment。来源：public incumbent provenance inherited at 1e-7; untouched-original Gurobi bound。记录有效研究90.060分钟，源表solver时间90.025分钟（不是重新测量的全部优化调用总时长）。COPT行号131，Time=36000.0秒，Nodes=9323762，Res=stop，Sol=ok，短Hash=a5647de6。

原实验停止理由：fresh baseline, sole preregistered treatment, and strict candidate audits completed above the 90-minute floor with the gap open。仍开放，没有本实例全局最优证明。核验等级：原始空间1e-7数值检查 + 固定向量可行性重放；非全模型精确有理证明。

证据：[个例最终报告](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch4/neos-5221106-oparau/reports/final_report.md)；[原始空间检查](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch4/neos-5221106-oparau/verification/final_treatment_strict/verification.json)；[最终原始空间向量](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch4/neos-5221106-oparau/experiments/public_id3_symmetry_cut_bound_3000s/solution.sol)。检查和解文件SHA-256及原始MPS哈希记录在[comparison.json](D:/sufe/AI4MIP/reports/miplib20_vs_copt_20260913/comparison.json)；本次只做其字节完整性重验，不冒充重新求解或重新运行可行性算法。

#### zeil

本实验区间 `[815.3797428765, 1081.3585000000078]`；COPT原表 `[834.502247, 1363.5585]`。上界：本实验更好；下界：COPT更好。本实验统一gap=24.596723%，COPT统一gap=38.799674%。

最终点与公开解约2.27e-13的差不算新贡献。原始模型数值界有所提高，但COPT表仍高19.1225041235；来源更正后的标签为外部/公开保留。

方法：strict public-ID6 start followed by one MIPFocus=3 proof treatment。来源：public incumbent provenance inherited at 1e-7; new untouched-original Gurobi treatment bound。记录有效研究90.165分钟，源表solver时间90.014分钟（不是重新测量的全部优化调用总时长）。COPT行号216，Time=36000.0秒，Nodes=862，Res=stop，Sol=ok，短Hash=4e5ce3a5。

原实验停止理由：baseline, strict start gate, sole preregistered treatment, and final strict audit completed above the 90-minute floor with the gap open。仍开放，没有本实例全局最优证明。核验等级：原始空间1e-7数值检查 + 固定向量可行性重放；非全模型精确有理证明。

证据：[个例最终报告](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch4/zeil/reports/final_report.md)；[原始空间检查](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch4/zeil/verification/final_treatment_strict/verification.json)；[最终原始空间向量](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch4/zeil/experiments/tailored_bound_focus_3000s/solution.sol)。检查和解文件SHA-256及原始MPS哈希记录在[comparison.json](D:/sufe/AI4MIP/reports/miplib20_vs_copt_20260913/comparison.json)；本次只做其字节完整性重验，不冒充重新求解或重新运行可行性算法。

#### cdma

本实验区间 `[-31763448000000000, -22966095679999980]`；COPT原表 `[-1e+20, 1e+20]`。上界：COPT缺失；下界：COPT缺失。本实验统一gap=27.696465%，COPT统一gap=未计算（缺少有限界）。

COPT在0.1秒abort，P=1e20、D=-1e20按缺失处理，不是正常10小时可比运行，也不证明不可行或无界。实验搜索生成点差于公开primal；4单位目标头部修正未改变赋值，不是新primal改进。

方法：sealed external-pattern completion gate, one untouched-original numeric/symmetry treatment, and append-only objective-header normalization without changing assignments。来源：fresh experiment-generated phase-B primal; untouched-original Gurobi baseline bound。记录有效研究90.023分钟，源表solver时间89.925分钟（不是重新测量的全部优化调用总时长）。COPT行号10，Time=0.1秒，Nodes=0，Res=abort，Sol=ok，短Hash=bebab67e。

原实验停止理由：baseline, append-only hash recovery, unchanged preregistered treatment, header-only normalization, and final strict checks completed above the 90-minute floor。仍开放，没有本实例全局最优证明。核验等级：原始空间1e-7数值检查 + 固定向量可行性重放；非全模型精确有理证明。

证据：[个例最终报告](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch4/cdma/reports/final_report.md)；[原始空间检查](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch4/cdma/verification/final_treatment_header_normalized_strict/verification.json)；[最终原始空间向量](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch4/cdma/solutions/treatment_header_normalized.sol)。检查和解文件SHA-256及原始MPS哈希记录在[comparison.json](D:/sufe/AI4MIP/reports/miplib20_vs_copt_20260913/comparison.json)；本次只做其字节完整性重验，不冒充重新求解或重新运行可行性算法。

#### ns1456591

本实验区间 `[473.415027263, 988.1412834399998]`；COPT原表 `[459.574181, 1307.35364]`。上界：本实验更好；下界：本实验更好。本实验统一gap=52.090350%，COPT统一gap=64.846988%。

使用严格接受的公开ID2；headline ID3的约8.2757e-7违规超过1e-7而被拒。拒绝仅指向量未达实验门槛，不等于实例不可行或作者结论错误。

方法：strict public-ID2 start followed by one MIPFocus=3/CliqueCuts=2 proof treatment。来源：transferred public ID2 primal; untouched-original Gurobi baseline bound。记录有效研究90.022分钟，源表solver时间90.003分钟（不是重新测量的全部优化调用总时长）。COPT行号137，Time=36000.0秒，Nodes=14365855，Res=stop，Sol=ok，短Hash=929a7bd。

原实验停止理由：baseline, sole preregistered treatment, and strict candidate audits completed above the 90-minute floor without primal or dual improvement。仍开放，没有本实例全局最优证明。核验等级：原始空间1e-7数值检查 + 固定向量可行性重放；非全模型精确有理证明。

证据：[个例最终报告](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch4/ns1456591/reports/final_report.md)；[原始空间检查](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch4/ns1456591/verification/public_id2_strict/verification.json)；[最终原始空间向量](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/batch4/ns1456591/solutions/public_id2.explicit.sol)。检查和解文件SHA-256及原始MPS哈希记录在[comparison.json](D:/sufe/AI4MIP/reports/miplib20_vs_copt_20260913/comparison.json)；本次只做其字节完整性重验，不冒充重新求解或重新运行可行性算法。

### Batch 5

#### seqsolve1

本实验区间 `[4272, 4279]`；COPT原表 `[4268.52039, 4371]`。上界：本实验更好；下界：本实验更好。本实验统一gap=0.163590%，COPT统一gap=2.344535%。

本轮人周Partition邻域生成并精确复验4279，未优于冻结公开4277。数值界4272强于COPT表4268.52039；精确流/割证书仅4250。历史README的4275单独保留，不冒充当前官方界。

方法：Original MIP + whole-person-week Partition LNS; exact original-mapped capacity and minimum-activation flow certificates。来源：newly generated verified feasible point, not a public primal improvement; independently established exact original-valid bound (current official dual unknown); standard numerical original-valid global solver bound, not an exact tree proof。记录有效研究93.670分钟，源表solver时间89.925分钟（不是重新测量的全部优化调用总时长）。COPT行号181，Time=36000.0秒，Nodes=40998，Res=stop，Sol=ok，短Hash=b5a46ce1。

原实验停止理由：Completed precommitted30-minute original baseline and60-minute structure-specific treatment, then original-space/proof audits; no audited global closure. Stop at verified minimum after the tested direction produced no further demonstrated public improvement; unresolved cases and next tests documented.。仍开放，没有本实例全局最优证明。核验等级：完整原始MPS 十进制/有理精确可行性复验。

证据：[个例最终报告](D:/sufe/AI4MIP/batch5_clean_20260913T0052CST/seqsolve1/final_report.md)；[原始空间检查](D:/sufe/AI4MIP/batch5_clean_20260913T0052CST/seqsolve1/verification/postsolve/candidate_0/decimal_check.json)；[最终原始空间向量](D:/sufe/AI4MIP/batch5_clean_20260913T0052CST/seqsolve1/verification/postsolve/candidate_0/canonical.sol)。检查和解文件SHA-256及原始MPS哈希记录在[comparison.json](D:/sufe/AI4MIP/reports/miplib20_vs_copt_20260913/comparison.json)；本次只做其字节完整性重验，不冒充重新求解或重新运行可行性算法。

#### stockholm

本实验区间 `[106, 129]`；COPT原表 `[93.5364881, 137]`。上界：本实验更好；下界：本实验更好。本实验统一gap=17.829457%，COPT统一gap=31.725191%。

本轮生成129并恢复为原始MPS精确可行。406个精确Farkas覆盖和实际增广模型经审计；数值界提高到106，16个不相交cover仅给精确16。未优于公开primal约121。

方法：Original MIP + exact Farkas activation-cover separation; fixed-discrete continuous recourse verification。来源：newly generated verified feasible point, not a public primal improvement; independently established exact original-valid bound (current official dual unknown); standard numerical original-valid global solver bound, not an exact tree proof。记录有效研究99.823分钟，源表solver时间86.300分钟（不是重新测量的全部优化调用总时长）。COPT行号199，Time=36000.0秒，Nodes=459573，Res=stop，Sol=ok，短Hash=3f10d68f。

原实验停止理由：Completed precommitted30-minute original baseline and60-minute structure-specific treatment, then original-space/proof audits; no audited global closure. Stop at verified minimum after the tested direction produced no further demonstrated public improvement; unresolved cases and next tests documented.。仍开放，没有本实例全局最优证明。核验等级：完整原始MPS 十进制/有理精确可行性复验。

证据：[个例最终报告](D:/sufe/AI4MIP/batch5_clean_20260913T0052CST/stockholm/final_report.md)；[原始空间检查](D:/sufe/AI4MIP/batch5_clean_20260913T0052CST/stockholm/verification/final_rational_recovery/decimal_check.json)；[最终原始空间向量](D:/sufe/AI4MIP/batch5_clean_20260913T0052CST/stockholm/verification/final_rational_recovery/exact_decimal_original_space.sol)。检查和解文件SHA-256及原始MPS哈希记录在[comparison.json](D:/sufe/AI4MIP/reports/miplib20_vs_copt_20260913/comparison.json)；本次只做其字节完整性重验，不冒充重新求解或重新运行可行性算法。

#### supportcase22

本实验区间 `[1.4000000000000001, 110]`；COPT原表 `[0.88353308, 1e+20]`。上界：COPT缺失；下界：本实验更好。本实验统一gap=98.727273%，COPT统一gap=未计算（缺少有限界）。

本轮搜索未产生可行解；最终110为Taylor Solver公开解的精确复验，未用于搜索热启动。180个OR割和232400个守卫收紧有原始有效性审计；数值界1.4，精确可计下界仍0。COPT上界缺失。

方法：Original MIP + exact Boolean OR implications and232400 box-certified16-to1 guard tightenings。来源：transferred external exact-verified Taylor Solver110; NOT a newly generated contribution; independently established exact original-valid bound (current official dual unknown); standard numerical original-valid global solver bound, not an exact tree proof。记录有效研究92.353分钟，源表solver时间89.612分钟（不是重新测量的全部优化调用总时长）。COPT行号200，Time=36000.0秒，Nodes=765，Res=stop，Sol=ok，短Hash=c8e22663。

原实验停止理由：Completed precommitted30-minute original baseline and60-minute structure-specific treatment, then original-space/proof audits; no audited global closure. Stop at verified minimum after the tested direction produced no further demonstrated public improvement; unresolved cases and next tests documented.。仍开放，没有本实例全局最优证明。核验等级：完整原始MPS 十进制/有理精确可行性复验。

证据：[个例最终报告](D:/sufe/AI4MIP/batch5_clean_20260913T0052CST/supportcase22/final_report.md)；[原始空间检查](D:/sufe/AI4MIP/batch5_clean_20260913T0052CST/supportcase22/external/public110_native_header_retry/decimal_check.json)；[最终原始空间向量](D:/sufe/AI4MIP/batch5_clean_20260913T0052CST/supportcase22/external/public110_native_header_retry/public_complete_original_space.sol)。检查和解文件SHA-256及原始MPS哈希记录在[comparison.json](D:/sufe/AI4MIP/reports/miplib20_vs_copt_20260913/comparison.json)；本次只做其字节完整性重验，不冒充重新求解或重新运行可行性算法。

#### neos-3682128-sandon

本实验区间 `[21672926.242906883, 34666770]`；COPT原表 `[21531270.9, 34666770]`。上界：相同；下界：本实验更好。本实验统一gap=37.482130%，COPT统一gap=37.890750%。

本轮无公开热启动，独立重获34666770，与COPT上界完全相同。浮点headline回到5单位目标格点不是新改进。数值下界较强；原始行精确锚定证书仅4737730。

方法：Original MIP + five matrix-linked hub neighborhoods and assignment branching; exact five-unit objective audit。来源：independently rediscovered public primal value; no external vector transfer; independently established exact original-valid bound (current official dual unknown); standard numerical original-valid global solver bound, not an exact tree proof。记录有效研究90.322分钟，源表solver时间89.981分钟（不是重新测量的全部优化调用总时长）。COPT行号106，Time=36000.0秒，Nodes=2246715，Res=stop，Sol=ok，短Hash=d3e90886。

原实验停止理由：Completed precommitted30-minute original baseline and60-minute structure-specific treatment, then original-space/proof audits; no audited global closure. Stop at verified minimum after the tested direction produced no further demonstrated public improvement; unresolved cases and next tests documented.。仍开放，没有本实例全局最优证明。核验等级：完整原始MPS 十进制/有理精确可行性复验。

证据：[个例最终报告](D:/sufe/AI4MIP/batch5_clean_20260913T0052CST/neos-3682128-sandon/final_report.md)；[原始空间检查](D:/sufe/AI4MIP/batch5_clean_20260913T0052CST/neos-3682128-sandon/verification/postsolve/candidate_0/decimal_check.json)；[最终原始空间向量](D:/sufe/AI4MIP/batch5_clean_20260913T0052CST/neos-3682128-sandon/verification/postsolve/candidate_0/canonical.sol)。检查和解文件SHA-256及原始MPS哈希记录在[comparison.json](D:/sufe/AI4MIP/reports/miplib20_vs_copt_20260913/comparison.json)；本次只做其字节完整性重验，不冒充重新求解或重新运行可行性算法。

## 9. 结论与下一步

可以可靠报告的是：基于双方已报告最终数值，本实验大部分上界和下界更强，五例COPT下界形成互补；本实验有20点的原始空间检查，而COPT没有随表提供同级原始证据。不能可靠报告的是：Gurobi或GPT在公平对照下整体胜过COPT、16项新公开primal成果、5项已独立认证COPT下界改进，或任何本组最优证明。

最有价值的后续工作依次为：（1）获取COPT20例原MPS SHA、完整解向量、原始日志、版本/资源/容差/起点设置；（2）用统一原始空间门槛核验17个有限COPT向量和19个有限下界来源，优先eva、dc1l、polygonpack等五例互补界；（3）若需算法性能结论，再设计同条件重复对照，禁止用本次历史结果的优势倒推公平性。以上建议尚未执行。

## 附录A. 原始模型哈希与来源完整性

本次重新计算并匹配20个原始模型文件、20个最终向量、20个检查输出及20份个例报告的SHA-256；前16哈希对象为压缩.mps.gz字节，Batch5为解压.mps字节，二者类型不可混淆。COPT未提供对应模型哈希，因此未核定跨来源相同模型。

| 实例 | 哈希对象 | 本实验原MPS SHA-256 |
| --- | --- | --- |
| graphdraw-grafo2 | compressed .mps.gz bytes | a5528a5b80f4405206449e26933e69eb5c2465bceff303a5086a572b80bdbfed |
| polygonpack4-10 | compressed .mps.gz bytes | c77946405fd9fc1a53aa56dec82a1dcdef9932248c15ecc17e1ea05d49ab0969 |
| scpm1 | compressed .mps.gz bytes | fef145329bf9dd25fd9ff59a51816c044adf41ae627a23ab8c93eeb31cffed41 |
| ger50-17-trans-dfn-3t | compressed .mps.gz bytes | fd05921bf1e954a9123a8d686f1610c00f03f700235910962220b1f3b8d20704 |
| eva1aprime6x6opt | compressed .mps.gz bytes | 32ac7ea0015a16edc5058a6c6c2c9e8d79262b170888fc806304aaa2a51e0161 |
| cmflsp60-36-2-6 | compressed .mps.gz bytes | ce7f3600260baaf5e8cea531d616e212723875003366014af17d8802d2909da4 |
| r4l4-02-tree-bounds-50 | compressed .mps.gz bytes | f6dedac412b6d9e9c6ee4ad0a91c92c27027d031efcd25a62dc4a26eb39d33f3 |
| sct1 | compressed .mps.gz bytes | 49423b96c7a5f3c64590ec8f283d0111e4a7730348693e5c1f53df09542fb7a2 |
| shipsched | compressed .mps.gz bytes | 152d733821a90eae633bef181fe0e0907dc23e6a8afa8413bc98c22cc115b9f1 |
| rocII-8-11 | compressed .mps.gz bytes | 8d0f3e5aacd9ceec0e0c2618d96ba00ad87803b457adaac4542b4393af5155b1 |
| ns1856153 | compressed .mps.gz bytes | f52ae202906c0df1bcc804b679c647cff2e62607c2b78301dff8b5d9f51a13b4 |
| dc1l | compressed .mps.gz bytes | 49d40810273a4948b8b56be538b46575b566afa2f133094a4a687f05ab7604f5 |
| neos-5221106-oparau | compressed .mps.gz bytes | 788ac2b03e5a11b39b58e616663ed598cc9523e64ff195c7c8d038e3b4459d2d |
| zeil | compressed .mps.gz bytes | 0a841d40523d10b0b66ebd2b3ad2a24baba5a351148b6bdf77685669a513bebe |
| cdma | compressed .mps.gz bytes | 84775da3b8e919cd5363bbe3f2a170a126b379f1f2d9cdf4b7ac70bbb93384fb |
| ns1456591 | compressed .mps.gz bytes | acc4972ca3c3f59ab052d7b39ca1ded34d5a685f82e0a64a95dc317839594ccf |
| seqsolve1 | decompressed .mps bytes | 3a5b3c7a8a168ee2999013f233bd1df0a0937c2cf811bbe886d607e8123318d6 |
| stockholm | decompressed .mps bytes | 20790418ce711a9fcd3b2eae5dca34d232f6831a84830165172d01077593c23e |
| supportcase22 | decompressed .mps bytes | 92be5f19939945c6efa5dd5c1f2ea7bca2625c1b90d0127ef2a14e2bafb81e7b |
| neos-3682128-sandon | decompressed .mps bytes | 44935d053c0df7a6cbd28db175f324bbdfb5fa88cf0edd6d09ffc1b14bacb9b9 |

本实验数据表SHA-256（本次读取前后匹配）：

- [源结果表](D:/sufe/AI4MIP/miplib20_controlled_20260911T1453CST/summary.interim.csv)：`9fa44e9ef31602d9c3d456b6ded606b6efd806a6c6c11567b4fc32229dd34346`；行数16。

- [源结果表](D:/sufe/AI4MIP/batch5_clean_20260913T0052CST/summary.csv)：`2dfcce4b5b5cdb0a8e77c251655dac9aa0cdc766c52ff11601cf7fbff2e882cd`；行数4。

- 既有汇总报告：`b823d230cbce5926e05f32924384211a8c10a48f1e4526e1ee2c5b1ca2dbd28d`；既有聚合JSON：`27231fc944ff3b0edd8a85420b3d79e22fa03a37f2e0cf4731993880d34010c7`；既有独立核验JSON：`dafd79585aff0db57d0e50bdcc4ec9db11135f9ec3ad6904f9bede8436810959`。

本次输出位置：[Markdown完整报告](D:/sufe/AI4MIP/reports/miplib20_vs_copt_20260913/report.md)；[PDF完整报告](D:/sufe/AI4MIP/output/pdf/miplib20_vs_copt_report.pdf)；[精确比较数据和路径/hash](D:/sufe/AI4MIP/reports/miplib20_vs_copt_20260913/comparison.json)。原表完整文字：[copt_source_text.txt](D:/sufe/AI4MIP/reports/miplib20_vs_copt_20260913/copt_source_text.txt)。复现命令：使用已装pdfplumber/pypdf/reportlab的Python运行`extract_copt.py`后运行`build_report.py --pdf`；这两个脚本不调用任何MIP求解器。

## 附录B. gap口径追溯

这里只列改变分母后明显不同的负目标案例；完整旧/新公式值在comparison.json。旧公式数值不代表此次新结果。

| 实例 | 旧本实验abs(P)分母gap | 统一max分母gap |
| --- | --- | --- |
| polygonpack4-10 | 74.787775 | 42.787761 |
| eva1aprime6x6opt | 1222.705000 | 92.439735 |
| sct1 | 6.781613 | 6.350918 |
| rocII-8-11 | 35.446250 | 26.169975 |
| cdma | 38.305825 | 27.696465 |

## 附录C. 本次实际读取的SKILL.md审计

PDF技能用于完整原表提取、视觉核对和最终报告渲染复核；表格技能用于只读历史表分析、缺失值/来源保持和统一gap复算。没有创建新的工作簿，也未为了审计读取无关skill。技能促使本报告保留原显示值、占位符和证据等级，并在交付前核对所有最终PDF页。

- 绝对路径：`C:/Users/user/.codex/plugins/cache/openai-primary-runtime/pdf/26.909.12148/skills/pdf/SKILL.md`；SHA-256：`a13d2f878d6f79df9ebba91901c0b09bf799e83973b47ebba2104e385b6e4ede`。

- 绝对路径：`C:/Users/user/.codex/plugins/cache/openai-primary-runtime/spreadsheets/26.909.12148/skills/spreadsheets/SKILL.md`；SHA-256：`8815ade7bd0544d1c03deefd2627c9b0ba888ddf24d13a2d0bb3490f0c5505be`。
