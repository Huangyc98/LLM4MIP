from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
from collections import Counter
from decimal import Decimal, getcontext
from pathlib import Path


getcontext().prec = 80
BOUND_TOL = Decimal("1e-7")
GAP_TOL = Decimal("1e-12")

SKILL_TOLERANCE_INDEXED = {
    "polygonpack4-10",
    "eva1aprime6x6opt",
    "cmflsp60-36-2-6",
    "sct1",
    "shipsched",
    "rocII-8-11",
}
SKILL_NEW_STRICT = {
    "graphdraw-grafo2",
    "r4l4-02-tree-bounds-50",
    "ns1856153",
    "neos-5221106-oparau",
}
NO_SKILL_NEW_STRICT = {
    "graphdraw-grafo2",
    "r4l4-02-tree-bounds-50",
}
SKILL_EXACT_OPTIMA = {"ns1456591", "neos-3682128-sandon"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def decimal_text(value: Decimal) -> str:
    text = format(value, "f")
    if "." in text:
        text = text.rstrip("0").rstrip(".")
    return "0" if text in {"", "-0"} else text


def common_gap(primal: Decimal, dual: Decimal) -> Decimal:
    return abs(primal - dual) / max(Decimal(1), abs(primal), abs(dual))


def compare_lower(candidate: Decimal, baseline: Decimal, tolerance: Decimal) -> str:
    delta = baseline - candidate
    if delta > tolerance:
        return "skill_better"
    if delta < -tolerance:
        return "no_skill_better"
    return "tie"


def compare_higher(candidate: Decimal, baseline: Decimal, tolerance: Decimal) -> str:
    delta = candidate - baseline
    if delta > tolerance:
        return "skill_better"
    if delta < -tolerance:
        return "no_skill_better"
    return "tie"


def section(text: str, start: str, end: str) -> str:
    return text.split(start, 1)[1].split(end, 1)[0]


def markdown_rows(text: str, start: str, end: str) -> list[list[str]]:
    block = section(text, start, end)
    rows: list[list[str]] = []
    for line in block.splitlines():
        if not line.startswith("|") or line.startswith("| ---"):
            continue
        cells = [cell.strip() for cell in line.strip().strip("|").split("|")]
        if not cells or cells[0].startswith("实例"):
            continue
        rows.append(cells)
    return rows


def parse_name_batch(cell: str) -> tuple[str, str]:
    match = re.fullmatch(r"(.+)（([1-5])）", cell)
    if not match:
        raise ValueError(f"Cannot parse instance/batch cell: {cell!r}")
    return match.group(1), match.group(2)


def parse_no_skill_report(path: Path) -> dict[str, dict[str, str]]:
    text = path.read_text(encoding="utf-8")
    primal_rows = markdown_rows(text, "## 3. 20例上界P比较", "## 4. 20例下界D比较")
    dual_rows = markdown_rows(text, "## 4. 20例下界D比较", "## 5. 统一gap、原表gap与结果来源")
    source_rows = markdown_rows(text, "## 5. 统一gap、原表gap与结果来源", "## 6. 五例互补结果及条件数值包络")
    if not (len(primal_rows) == len(dual_rows) == len(source_rows) == 20):
        raise ValueError(
            f"Expected three 20-row no-skill tables, got {len(primal_rows)}, "
            f"{len(dual_rows)}, {len(source_rows)}"
        )
    parsed: dict[str, dict[str, str]] = {}
    for cells in primal_rows:
        name, batch = parse_name_batch(cells[0])
        parsed[name] = {"batch": batch, "primal": cells[1]}
    for cells in dual_rows:
        name, batch = parse_name_batch(cells[0])
        if name not in parsed or parsed[name]["batch"] != batch:
            raise ValueError(f"Dual table mismatch for {name}")
        parsed[name]["dual"] = cells[1]
    for cells in source_rows:
        name = cells[0]
        if name not in parsed:
            raise ValueError(f"Source table mismatch for {name}")
        parsed[name]["final_point_source"] = cells[5]
    return parsed


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--no-skill-report", type=Path, required=True)
    parser.add_argument("--skill-summary", type=Path, required=True)
    parser.add_argument("--skill-report", type=Path, required=True)
    parser.add_argument("--skill-file", type=Path, required=True)
    parser.add_argument("--csv-out", type=Path, required=True)
    parser.add_argument("--audit-out", type=Path, required=True)
    args = parser.parse_args()

    no_skill = parse_no_skill_report(args.no_skill_report)
    with args.skill_summary.open("r", encoding="utf-8-sig", newline="") as stream:
        skill_rows = list(csv.DictReader(stream))
    if len(skill_rows) != 20:
        raise ValueError(f"Expected 20 skill rows, got {len(skill_rows)}")
    skill_names = {row["instance"] for row in skill_rows}
    if skill_names != set(no_skill):
        raise ValueError(
            f"Instance-set mismatch: missing from skill={sorted(set(no_skill)-skill_names)}, "
            f"missing from no-skill={sorted(skill_names-set(no_skill))}"
        )

    output_rows: list[dict[str, str]] = []
    for skill in skill_rows:
        name = skill["instance"]
        baseline = no_skill[name]
        p0 = Decimal(baseline["primal"])
        d0 = Decimal(baseline["dual"])
        p1 = Decimal(skill["best_verified_primal"])
        d1 = Decimal(skill["best_valid_dual"])
        g0 = common_gap(p0, d0)
        g1 = common_gap(p1, d1)
        p_adv = p0 - p1
        d_adv = d1 - d0
        g_adv_pp = (g0 - g1) * 100
        output_rows.append(
            {
                "instance": name,
                "batch": skill["batch"],
                "no_skill_primal": baseline["primal"],
                "skill_selected_primal": skill["best_verified_primal"],
                "skill_primal_is_tolerance_indexed": str(name in SKILL_TOLERANCE_INDEXED).lower(),
                "no_skill_minus_skill_primal": decimal_text(p_adv),
                "selected_primal_comparison_at_1e_7": compare_lower(p1, p0, BOUND_TOL),
                "no_skill_dual": baseline["dual"],
                "skill_dual": skill["best_valid_dual"],
                "skill_minus_no_skill_dual": decimal_text(d_adv),
                "dual_comparison_at_1e_7": compare_higher(d1, d0, BOUND_TOL),
                "no_skill_common_gap_fraction": decimal_text(g0),
                "skill_common_gap_fraction": decimal_text(g1),
                "no_skill_minus_skill_gap_percentage_points": decimal_text(g_adv_pp),
                "common_gap_comparison": compare_lower(g1, g0, GAP_TOL),
                "no_skill_final_point_source": baseline["final_point_source"],
                "skill_main_method": skill["main_method"],
                "skill_final_status": skill["final_status"],
                "skill_new_strict_vs_frozen_public_baseline": str(name in SKILL_NEW_STRICT).lower(),
                "no_skill_new_strict_vs_frozen_public_baseline": str(name in NO_SKILL_NEW_STRICT).lower(),
                "skill_exact_global_optimum": str(name in SKILL_EXACT_OPTIMA).lower(),
                "no_skill_exact_global_optimum": "false",
            }
        )

    args.csv_out.parent.mkdir(parents=True, exist_ok=True)
    with args.csv_out.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(output_rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(output_rows)

    primal_counts = Counter(row["selected_primal_comparison_at_1e_7"] for row in output_rows)
    dual_counts = Counter(row["dual_comparison_at_1e_7"] for row in output_rows)
    gap_counts = Counter(row["common_gap_comparison"] for row in output_rows)
    audit = {
        "schema": "controlled_miplib20.milp_structure_skill_effect_comparison.v1",
        "comparison_design": {
            "label_skill_arm": "User-designated milp-structure-research run",
            "label_no_skill_arm": "User-designated report without milp-structure-research",
            "causal_limit": "Historical, non-randomized comparison with differing resources, baselines, and verification workflows; observed differences are not a controlled causal effect estimate.",
            "bound_tie_tolerance": "1e-7",
            "common_gap_formula": "abs(P-D)/max(1,abs(P),abs(D))",
        },
        "inputs": {
            "no_skill_report": {
                "path": str(args.no_skill_report),
                "bytes": args.no_skill_report.stat().st_size,
                "sha256": sha256(args.no_skill_report),
            },
            "skill_summary": {
                "path": str(args.skill_summary),
                "bytes": args.skill_summary.stat().st_size,
                "sha256": sha256(args.skill_summary),
                "rows": len(skill_rows),
            },
            "skill_report": {
                "path": str(args.skill_report),
                "bytes": args.skill_report.stat().st_size,
                "sha256": sha256(args.skill_report),
            },
            "skill_file": {
                "path": str(args.skill_file),
                "bytes": args.skill_file.stat().st_size,
                "sha256": sha256(args.skill_file),
            },
        },
        "output_csv": {
            "path": str(args.csv_out),
            "bytes": args.csv_out.stat().st_size,
            "sha256": sha256(args.csv_out),
            "rows": len(output_rows),
        },
        "counts": {
            "instances": len(output_rows),
            "selected_primal_comparison_at_1e_7": dict(sorted(primal_counts.items())),
            "dual_comparison_at_1e_7": dict(sorted(dual_counts.items())),
            "common_gap_comparison": dict(sorted(gap_counts.items())),
            "skill_new_strict_vs_frozen_public_baseline": len(SKILL_NEW_STRICT),
            "no_skill_new_strict_vs_frozen_public_baseline": len(NO_SKILL_NEW_STRICT),
            "skill_exact_global_optima": len(SKILL_EXACT_OPTIMA),
            "no_skill_exact_global_optima": 0,
            "skill_tolerance_indexed_selected_primals": len(SKILL_TOLERANCE_INDEXED),
        },
        "pass": True,
    }
    args.audit_out.write_text(json.dumps(audit, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
